load i18n
function number(value):
    digits = String(Int(value))
    groups = []
    loop:
        if len(digits) <= 3:
            groups.insert(0, digits)
            break
        end
        groups.insert(0, digits[len(digits) - 3:len(digits)])
        digits = digits[0:len(digits) - 3]
    end
    return " ".join(groups)
end

function render(info, estimate, last_request):
    lines = [i18n.t("**Paměť konverzace**"), "Model: **" + info["model"] + "**", ""]
    limit = info.get("context_tokens", 0)
    if info.get("known", False) and limit > 0:
        percent = Int(estimate * 100 / limit)
        filled = min(20, max(0, Int(estimate * 20 / limit)))
        bar = ""
        for index in range(20):
            if index < filled:
                bar += "█"
            else:
                bar += "░"
            end
        end
        lines.append(bar + "  ~" + String(percent) + i18n.t(" % využito"))
        lines.append(i18n.t("V konverzaci: přibližně **") + number(estimate) + i18n.t("** tokenů"))
        lines.append(i18n.t("Kapacita modelu: **") + number(limit) + i18n.t("** tokenů"))
        lines.append(i18n.t("Do limitu zbývá přibližně **") + number(max(0, limit - estimate)) + i18n.t("** tokenů; část potřebuje model na odpověď."))
    else:
        lines.append(i18n.t("V konverzaci: přibližně **") + number(estimate) + i18n.t("** tokenů"))
        lines.append(i18n.t("Kapacitu tohoto modelu služba neuvádí, proto nelze určit procento využití."))
    end
    lines.append("")
    lines.append(i18n.t("Tokeny jsou malé části textu. Do paměti se počítá konverzace, instrukce a výsledky nástrojů."))
    if last_request > 0:
        lines.append(i18n.t("Poslední požadavek podle API: **") + number(last_request) + i18n.t("** vstupních tokenů, včetně případných obrázků."))
    end
    lines.append(i18n.t("Aktuální využití je odhad; u obrázků se může lišit. Při zaplnění se starší zprávy automaticky shrnou. Ručně: `/compact`."))
    return "\n".join(lines)
end
