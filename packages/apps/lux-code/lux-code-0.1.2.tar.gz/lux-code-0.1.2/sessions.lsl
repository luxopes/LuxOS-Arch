load i18n
load activity
load text_codec as codec
load common as core
load screen as ui
load workspace as files
load json
load jobs
load review
load time
load context_policy as policy

function filename(id):
    for ch in id:
        if ch not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_":
            Error(SessionError: "Invalid session ID")
        end
    end
    if id == "":
        Error(SessionError: "Empty session ID")
    end
    return core.state["home"] + "/sessions/" + id + ".json"
end

function persisted_messages(messages):
    saved = []
    for message in messages:
        copy = {}
        for key in message:
            copy[key] = message[key]
        end
        content = message.get("content", None)
        if type(content) == "List":
            saved_content = []
            for item in content:
                if item.get("type", "") == "image_url":
                    saved_content.append({"type": "text", "text": "[Image payload no longer retained; use view_image to reopen the source file named in the preceding tool result or attachment note if another inspection is needed.]"})
                else:
                    saved_content.append(item)
                end
            end
            copy["content"] = saved_content
        end
        saved.append(copy)
    end
    return saved
end

function has_content(messages, changes, tasks):
    if len(changes) > 0 or len(tasks) > 0:
        return True
    end
    for message in messages:
        if message.get("role", "") in ["user", "assistant", "tool"]:
            content = message.get("content", "")
            if type(content) == "String":
                if content.strip() != "":
                    return True
                end
            elif type(content) == "List" and len(content) > 0:
                return True
            end
            if len(message.get("tool_calls", [])) > 0:
                return True
            end
        end
    end
    return False
end

function save_data(messages):
    if not has_content(messages, files.changes, ui.tasks):
        return
    end
    services = []
    for job in jobs.owned:
        if job["name"] != "model request":
            services.append(job)
        end
    end
    title = ui.view["title"]
    if title in ["Nové sezení", "New session"]:
        title = title_for(messages)
        ui.view["title"] = title
    end
    data = {"events": activity.events, "queued_prompts": ui.queue, "draft": ui.view["input"], "title_source": core.state.get("title_source", "fallback"), "text_encoding": "lossless-utf8-v1", "instruction_policy": core.state.get("instruction_policy", "legacy"), "title": title, "review_observed": review.state["observed"], "review_baseline": review.state["baseline"], "review_known": review.state["known"], "review_captured": review.state["captured"], "version": 1, "id": core.state["session"], "cwd": core.state["cwd"], "model": ui.view["model"], "reasoning": ui.view["reasoning"], "messages": persisted_messages(messages), "entries": ui.entries, "tasks": ui.tasks, "changes": files.changes, "services": services}
    call core.atomic(filename(core.state["session"]), json.encode(codec.pack(data)))
    call core.run("chmod 600 -- " + core.quote(filename(core.state["session"])))
    meta = {"id": core.state["session"], "title": title, "cwd": core.state["cwd"], "model": ui.view["model"], "updated": time.time(), "turns": count_turns(messages)}
    call core.atomic(filename(core.state["session"]) + ".meta", json.encode(codec.safe(meta)))
end

function list():
    return core.checked("ls -1t " + core.quote(core.state["home"] + "/sessions") + "/*.json 2>/dev/null || true")
end

function load_session(id, messages):
    data = json.decode(readfile(filename(id)))
    if data.get("text_encoding", "") == "lossless-utf8-v1":
        data = codec.unpack(data)
    end
    if data.get("version", None) != 1 or type(data.get("messages", None)) != "List":
        Error(SessionError: "Unsupported session format")
    end
    directory = data["cwd"]
    call core.checked("test -d " + core.quote(directory))
    active = data["messages"]
    migrated = data.get("instruction_policy", "legacy") != policy.version
    if migrated:
        archive = core.state["home"] + "/artifacts/session-before-cwd-policy-" + id + ".json"
        if not exists(archive):
            call core.atomic(archive, readfile(filename(id)))
        end
        active = policy.legacy_tasks(active)
    end
    messages.clear()
    for message in active:
        messages.append(message)
    end
    core.state["instruction_policy"] = policy.version
    call ui.import_entries(codec.safe(data.get("entries", [])))
    ui.tasks.clear()
    for task in codec.safe(data.get("tasks", [])):
        ui.tasks.append(task)
    end
    files.changes.clear()
    for change in data.get("changes", []):
        files.changes.append(change)
    end
    activity.events.clear()
    for notice in data.get("events", []):
        activity.events.append(notice)
    end
    ui.queue.clear()
    for pending in data.get("queued_prompts", []):
        ui.queue.append(pending)
    end
    ui.view["input"] = data.get("draft", "")
    ui.view["cursor"] = len(ui.view["input"])
    jobs.owned.clear()
    for job in data.get("services", []):
        jobs.owned.append(job)
    end
    core.state["cwd"] = directory
    core.state["session"] = id
    core.state["usage_model"] = ""
    ui.view["model"] = data.get("model", ui.view["model"])
    ui.view["reasoning"] = data.get("reasoning", ui.view["reasoning"])
    ui.view["title"] = data.get("title", title_for(messages))
    inferred_source = "fallback"
    if ui.view["title"] != title_for(messages):
        inferred_source = "manual"
    end
    core.state["title_source"] = data.get("title_source", inferred_source)
    call review.reset()
    review.state["observed"] = data.get("review_observed", {})
    review.state["baseline"] = data.get("review_baseline", {})
    review.state["captured"] = data.get("review_captured", False)
    review.state["known"] = data.get("review_known", {})
    call review.refresh()
    if migrated:
        call ui.add("system", i18n.t("Starý kontext instrukcí archivován. Obnovena zadání; projekt se ověří z aktuální složky."))
    end
end

function export_markdown(filename):
    content = "# Lux Code session " + core.state["session"] + "\n\n"
    for entry in ui.entries:
        content += "## " + entry["kind"] + "\n\n" + entry["text"] + "\n\n"
    end
    call core.atomic(core.path(filename), content)
end

function count_turns(messages):
    count = 0
    for message in messages:
        if message.get("role", "") == "user" and type(message.get("content", None)) == "String":
            count += 1
        end
    end
    return count
end

function name(text):
    words = []
    for word in core.clean(text).replace("\n", " ").replace("\t", " ").split(" "):
        if word != "":
            words.append(word)
        end
    end
    title = " ".join(words)
    if len(title) > 72:
        short = title[0:69].split(" ")
        if len(short) > 1:
            title = " ".join(short[0:len(short) - 1]) + "…"
        else:
            title = title[0:69] + "…"
        end
    end
    if title == "":
        return i18n.t("Nové sezení")
    end
    return title
end

function smalltalk(text):
    text = core.clean(text).lower().strip()
    for punctuation in ["!", "?", ".", ",", ";", ":", "👋", "🙂", "😊"]:
        text = text.replace(punctuation, " ")
    end
    words = []
    for word in text.replace("\n", " ").replace("\t", " ").split(" "):
        if word != "":
            words.append(word)
        end
    end
    text = " ".join(words)
    return text in ["", "ahoj", "ahoj ahoj", "čau", "cau", "čauky", "cus", "čus", "zdar", "nazdar", "zdravím", "zdravim", "dobrý den", "dobry den", "dobré ráno", "dobrý večer", "hi", "hello", "hey", "hey there", "hi there", "hello there", "good morning", "good evening", "ahoj jak se máš", "ahoj jak se mas", "jak se máš", "jak se mas", "how are you", "hi how are you", "hello how are you", "díky", "diky", "děkuji", "dekuji", "thanks", "thank you", "ok", "okay", "ano", "ne", "yes", "no"]
end

function has_topic(messages):
    for message in messages:
        if message.get("role", "") == "user" and type(message.get("content", None)) == "String":
            text = message["content"]
            if not text.startswith("Previous session context:") and not smalltalk(text):
                return True
            end
        end
    end
    return False
end

function title_for(messages):
    for message in messages:
        if message.get("role", "") == "user" and type(message.get("content", None)) == "String":
            text = message["content"]
            if not text.startswith("Previous session context:") and not smalltalk(text):
                return name(text)
            end
        end
    end
    return i18n.t("Nové sezení")
end

function autoname(text):
    if ui.view["title"] in ["Nové sezení", "New session"] and not smalltalk(text):
        ui.view["title"] = name(text)
    end
end

function catalog():
    found = []
    listing = list()
    for path in listing.split("\n"):
        if path == "" or len(found) >= 100:
            continue
        end
        try:
            if exists(path + ".meta"):
                meta = json.decode(readfile(path + ".meta"))
            else:
                data = json.decode(readfile(path))
                meta = {"id": data["id"], "title": data.get("title", title_for(data["messages"])), "cwd": data["cwd"], "model": data.get("model", ""), "turns": count_turns(data["messages"])}
                call core.atomic(path + ".meta", json.encode(codec.safe(meta)))
            end
            if meta.get("turns", 0) == 0:
                data = json.decode(readfile(path))
                if not has_content(data["messages"], data.get("changes", []), data.get("tasks", [])):
                    continue
                end
            end
            id = meta["id"]
            stamp = id
            if len(id) >= 15:
                stamp = id[6:8] + "." + id[4:6] + "." + id[0:4] + " " + id[9:11] + ":" + id[11:13]
            end
            found.append({"value": id, "label": meta["title"], "detail": stamp + " · " + meta.get("model", ""), "hint": meta["cwd"] + " · " + String(meta.get("turns", 0)) + i18n.t(" zadání")})
        else:
            continue
        end
    end
    return found
end

function save(messages):
    try:
        call save_data(messages)
        core.state["save_error"] = ""
        return True
    else:
        failure = core.clean(String(last_error()))
        call core.record_error("session.save", failure)
        if core.state.get("save_error", "") != failure:
            call ui.add("error", i18n.t("Sezení se nepodařilo uložit: ") + failure + i18n.t("\nKonverzace zůstává v paměti. /save zkusí uložení znovu."))
        end
        core.state["save_error"] = failure
        ui.view["status"] = i18n.t("Chyba ukládání · /save pro opakování")
        return False
    end
end

function model_title(text):
    if core.state.get("title_source", "fallback") == "manual":
        return {"ok": True, "title": ui.view["title"], "preserved_manual_title": True}
    end
    if core.state.get("title_deferred", False):
        return {"ok": True, "title": ui.view["title"], "deferred": True, "reason": "No task or conversation topic yet. Reply naturally; name the session after a real topic appears."}
    end
    title = name(text.split("\n")[0]).strip().replace("**", "").replace("`", "").strip()
    for prefix in ["Název:", "Title:"]:
        if title.startswith(prefix):
            title = title[len(prefix):len(title)].strip()
        end
    end
    if len(title) >= 2 and title[0] in "'" + chr(34) and title[len(title) - 1] == title[0]:
        title = title[1:len(title) - 1]
    end
    if len(title) > 42:
        words = title.split(" ")
        short = ""
        for word in words:
            if len(short) + len(word) + 1 > 42:
                break
            end
            if short != "":
                short += " "
            end
            short += word
        end
        title = short
    end
    if title.lower() in ["nové sezení", "nova konverzace", "nová konverzace", "untitled", "ai chat", "session", "konverzace", ""]:
        Error(ToolError: "Session title must describe the task")
    end
    ui.view["title"] = title
    core.state["title_source"] = "model"
    return {"ok": True, "title": title}
end
