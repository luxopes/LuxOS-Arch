load common as core

function width(text):
    count = 0
    for ch in text:
        cp = ord(ch)
        if cp >= 768 and cp <= 879 or cp >= 65024 and cp <= 65039:
            continue
        elif cp >= 4352 and cp <= 4607 or cp >= 11904 and cp <= 42191 or cp >= 44032 and cp <= 55203 or cp >= 127744 and cp <= 129791:
            count += 2
        else:
            count += 1
        end
    end
    return count
end

function fit(text, limit):
    result = ""
    used = 0
    for ch in text:
        size = width(ch)
        if used + size > limit:
            break
        end
        result += ch
        used += size
    end
    while used < limit:
        result += " "
        used += 1
    end
    return result
end

function find(text, needle, start):
    i = start
    while i <= len(text) - len(needle):
        if text[i:i + len(needle)] == needle:
            return i
        end
        i += 1
    end
    return -1
end

function spans(text, base="38;5;252"):
    result = []
    buffer = ""
    i = 0
    while i < len(text):
        if text[i] == chr(92) and i + 1 < len(text) and text[i + 1] in "*_'`|" :
            buffer += text[i + 1]
            i += 2
            continue
        end
        delimiter = ""
        style = base
        if text[i:i + 2] == "**":
            delimiter = "**"
            style = base + ";1"
        elif text[i] == "`":
            delimiter = "`"
            style = base + ";38;5;117"
        elif text[i] == "'" and (i == 0 or text[i - 1] in " ([{:"):
            delimiter = "'"
            style = base + ";38;5;117"
        elif text[i] == "*" or text[i] == "_":
            if i == 0 or text[i - 1] == " ":
                delimiter = text[i]
                style = base + ";3"
            end
        end
        closing = -1
        if delimiter != "":
            closing = find(text, delimiter, i + len(delimiter))
        end
        if closing > i + len(delimiter):
            if buffer != "":
                result.append({"text": buffer, "style": base})
                buffer = ""
            end
            content = text[i + len(delimiter):closing]
            if delimiter == "`":
                # Kód zůstává doslovný, kromě explicitního obalu **slovo**.
                if content.startswith("**") and content.endswith("**") and len(content) > 4:
                    content = content[2:len(content) - 2]
                    style += ";1"
                end
                result.append({"text": content, "style": style})
            else:
                for nested in spans(content, style):
                    result.append(nested)
                end
            end
            i = closing + len(delimiter)
        else:
            buffer += text[i]
            i += 1
        end
    end
    if buffer != "":
        result.append({"text": buffer, "style": base})
    end
    return result
end

function plain(items):
    text = ""
    for item in items:
        text += item["text"]
    end
    return text
end

function wrapped(items, limit):
    rows = []
    current = []
    used = 0
    for item in items:
        buffer = ""
        for ch in item["text"]:
            size = width(ch)
            if used + size > limit and used > 0:
                if buffer != "":
                    current.append({"text": buffer, "style": item["style"]})
                    buffer = ""
                end
                rows.append({"spans": current, "plain": plain(current)})
                current = []
                used = 0
            end
            buffer += ch
            used += size
        end
        if buffer != "":
            current.append({"text": buffer, "style": item["style"]})
        end
    end
    rows.append({"spans": current, "plain": plain(current)})
    return rows
end

function render(text, limit):
    rows = []
    code = False
    source = core.clean(text).replace("\t", "    ").split("\n")
    index = 0
    while index < len(source):
        raw = source[index]
        if not code and index + 1 < len(source) and "|" in raw:
            headers = table_cells(raw)
            alignment = table_alignment(source[index + 1])
            if len(headers) > 0 and len(alignment) == len(headers):
                data = []
                index += 2
                while index < len(source) and "|" in source[index] and source[index].strip() != "":
                    cells = table_cells(source[index])
                    if len(cells) != len(headers):
                        break
                    end
                    data.append(cells)
                    index += 1
                end
                for row in table(headers, data, alignment, max(1, limit)):
                    rows.append(row)
                end
                continue
            end
        end
        index += 1
        line = raw
        style = "38;5;252"
        if line.strip().startswith("```"):
            code = not code
            label = "╰─"
            if code:
                label = "╭─ " + line.strip()[3:len(line.strip())]
            end
            items = [{"text": label, "style": "38;5;243"}]
        elif code:
            style = "38;5;188;48;5;235"
            if line.strip().startswith("#") or line.strip().startswith("//"):
                style = "3;38;5;244;48;5;235"
            end
            items = [{"text": "│ " + line, "style": style}]
        else:
            if line.startswith("#"):
                count = 0
                while count < len(line) and line[count] == "#":
                    count += 1
                end
                if count < len(line) and line[count] == " ":
                    line = line[count + 1:len(line)]
                    style = "1;38;5;117"
                end
            elif line.startswith("- "):
                line = "• " + line[2:len(line)]
            elif line.startswith("> "):
                line = "│ " + line[2:len(line)]
                style = "3;38;5;245"
            end
            items = spans(line, style)
        end
        for row in wrapped(items, max(1, limit)):
            rows.append(row)
        end
    end
    return rows
end

function table_cells(raw):
    text = raw.strip()
    if text.startswith("|"):
        text = text[1:len(text)]
    end
    if text.endswith("|") and not text.endswith(chr(92) + "|"):
        text = text[0:len(text) - 1]
    end
    result = []
    cell = ""
    code = False
    index = 0
    while index < len(text):
        ch = text[index]
        if ch == chr(92) and index + 1 < len(text):
            cell += ch + text[index + 1]
            index += 2
            continue
        elif ch == "`":
            code = not code
        elif ch == "|" and not code:
            result.append(cell.strip())
            cell = ""
            index += 1
            continue
        end
        cell += ch
        index += 1
    end
    result.append(cell.strip())
    return result
end

function table_alignment(raw):
    result = []
    for cell in table_cells(raw):
        value = cell.strip()
        align = "left"
        if value.startswith(":") and value.endswith(":"):
            align = "center"
        elif value.endswith(":"):
            align = "right"
        end
        value = value.replace(":", "")
        if len(value) < 3 or value.replace("-", "") != "":
            return []
        end
        result.append(align)
    end
    return result
end

function table_border(widths, left, middle, right):
    text = left
    for index in rang(len(widths)):
        if index > 0:
            text += middle
        end
        text += fit("", widths[index] + 2).replace(" ", "─")
    end
    return {"spans": [{"text": text + right, "style": "38;5;75"}], "plain": text + right}
end

function table(headers, data, alignment, limit):
    rows = []
    count = len(headers)
    if limit < count * 5 + 1:
        for cells in data:
            for index in rang(count):
                items = spans(headers[index], "1;38;5;75")
                items.append({"text": ": ", "style": "38;5;248"})
                for item in spans(cells[index]):
                    items.append(item)
                end
                for row in wrapped(items, limit):
                    rows.append(row)
                end
            end
        end
        if len(data) == 0:
            for row in wrapped(spans(" · ".join(headers)), limit):
                rows.append(row)
            end
        end
        return rows
    end
    widths = []
    all = [headers]
    for cells in data:
        all.append(cells)
    end
    for index in rang(count):
        natural = 2
        for cells in all:
            natural = max(natural, width(plain(spans(cells[index]))))
        end
        widths.append(natural)
    end
    budget = limit - count * 3 - 1
    total = 0
    for value in widths:
        total += value
    end
    while total > budget:
        largest = 0
        for index in rang(count):
            if widths[index] > widths[largest]:
                largest = index
            end
        end
        widths[largest] -= 1
        total -= 1
    end
    rows.append(table_border(widths, "┌", "┬", "┐"))
    for number in rang(len(all)):
        cells = all[number]
        height = 1
        columns = []
        for index in rang(count):
            style = "38;5;252"
            if number == 0:
                style = "1;38;5;75"
            end
            column = wrapped(spans(cells[index], style), widths[index])
            columns.append(column)
            height = max(height, len(column))
        end
        for y in rang(height):
            items = [{"text": "│", "style": "38;5;75"}]
            for index in rang(count):
                content = []
                used = 0
                if y < len(columns[index]):
                    content = columns[index][y]["spans"]
                    used = width(columns[index][y]["plain"])
                end
                padding = max(0, widths[index] - used)
                left = 0
                if alignment[index] == "right":
                    left = padding
                elif alignment[index] == "center":
                    left = Int(padding / 2)
                end
                items.append({"text": fit("", left + 1), "style": "38;5;252"})
                for item in content:
                    items.append(item)
                end
                items.append({"text": fit("", padding - left + 1), "style": "38;5;252"})
                items.append({"text": "│", "style": "38;5;75"})
            end
            rows.append({"spans": items, "plain": plain(items)})
        end
        if number == 0:
            rows.append(table_border(widths, "├", "┼", "┤"))
        end
    end
    rows.append(table_border(widths, "└", "┴", "┘"))
    return rows
end
