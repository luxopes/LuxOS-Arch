load common as core
load text_codec as codec
load env as runtime_env
load i18n

# Obrázky, které uživatel vložil (schránka, cesta, file:// URI) a které se
# pošlou s jeho příští zprávou. Zprávu samotnou drží chat/engine.
pending = []
limits = {"max_bytes": 4194304, "target_bytes": 1048576, "max_side": 2048, "read_limit": 67108864}
mimes = {"png": "image/png", "jpeg": "image/jpeg", "webp": "image/webp", "gif": "image/gif"}
clipboard_types = ["image/png", "image/jpeg", "image/webp", "image/gif", "image/bmp", "image/x-bmp", "image/tiff"]

function has_tool(name):
    return core.run("command -v " + core.quote(name) + " >/dev/null 2>&1")["ok"]
end

function magick():
    if has_tool("magick"):
        return "magick"
    elif has_tool("convert"):
        return "convert"
    end
    return ""
end

function file_size(filename):
    return Int(core.checked("stat -L -c %s -- " + core.quote(filename)).strip())
end

function be16(data, i):
    return data[i] * 256 + data[i + 1]
end

function le16(data, i):
    return data[i] + data[i + 1] * 256
end

function le24(data, i):
    return data[i] + data[i + 1] * 256 + data[i + 2] * 65536
end

function starts(data, signature):
    if len(data) < len(signature):
        return False
    end
    for i in rang(len(signature)):
        if data[i] != signature[i]:
            return False
        end
    end
    return True
end

function sniff(data):
    # Formát a rozměry čteme přímo z hlavičky; nevyžaduje ImageMagick.
    result = {"format": "", "width": 0, "height": 0}
    count = len(data)
    if starts(data, [137, 80, 78, 71, 13, 10, 26, 10]):
        result["format"] = "png"
        if count >= 24:
            result["width"] = be16(data, 16) * 65536 + be16(data, 18)
            result["height"] = be16(data, 20) * 65536 + be16(data, 22)
        end
    elif starts(data, [71, 73, 70, 56]):
        result["format"] = "gif"
        if count >= 10:
            result["width"] = le16(data, 6)
            result["height"] = le16(data, 8)
        end
    elif count >= 30 and starts(data, [82, 73, 70, 70]) and data[8] == 87 and data[9] == 69 and data[10] == 66 and data[11] == 80:
        result["format"] = "webp"
        chunk = chr(data[12]) + chr(data[13]) + chr(data[14]) + chr(data[15])
        if chunk == "VP8 ":
            result["width"] = le16(data, 26) & 16383
            result["height"] = le16(data, 28) & 16383
        elif chunk == "VP8L":
            b0 = data[21]
            b1 = data[22]
            b2 = data[23]
            b3 = data[24]
            result["width"] = 1 + (b1 & 63) * 256 + b0
            result["height"] = 1 + (b3 & 15) * 1024 + b2 * 4 + (b1 >> 6)
        elif chunk == "VP8X":
            result["width"] = 1 + le24(data, 24)
            result["height"] = 1 + le24(data, 27)
        end
    elif starts(data, [255, 216]):
        result["format"] = "jpeg"
        i = 2
        while i + 9 < count:
            if data[i] != 255:
                i += 1
                continue
            end
            marker = data[i + 1]
            if marker >= 192 and marker <= 207 and marker != 196 and marker != 200 and marker != 204:
                result["height"] = be16(data, i + 5)
                result["width"] = be16(data, i + 7)
                break
            elif marker == 255:
                i += 1
            elif marker == 216 or marker == 1 or marker >= 208 and marker <= 215:
                i += 2
            else:
                i += 2 + be16(data, i + 2)
            end
        end
    end
    return result
end

function header(filename, size):
    # Hlavička stačí na formát i rozměry; velké soubory nečteme celé.
    if size <= 262144:
        return readbytes(filename)
    end
    temporary = core.checked("mktemp " + core.quote(core.state["home"] + "/artifacts/header-XXXXXX")).strip()
    try:
        call core.checked("head -c 262144 -- " + core.quote(filename) + " > " + core.quote(temporary))
        data = readbytes(temporary)
    else:
        call core.run("rm -f -- " + core.quote(temporary))
        Error(AttachmentError: String(last_error()))
    end
    call core.run("rm -f -- " + core.quote(temporary))
    return data
end

function inspect(filename):
    size = file_size(filename)
    if size > limits["read_limit"]:
        Error(AttachmentError: i18n.t("Obrázek je příliš velký: ") + human(size))
    end
    info = sniff(header(filename, size))
    info["bytes"] = size
    info["path"] = filename
    return info
end

function stamp():
    return core.checked("date +%Y%m%d-%H%M%S-%N").strip()
end

function artifact(extension):
    call core.ensure(core.state["home"] + "/artifacts")
    return core.state["home"] + "/artifacts/paste-" + stamp() + "." + extension
end

function shrink(info):
    # Velké obrázky zmenšíme, pokud je k dispozici ImageMagick; originál zůstane.
    tool = magick()
    big = info["bytes"] > limits["target_bytes"] or max(info["width"], info["height"]) > limits["max_side"]
    if tool == "" or info["format"] != "" and not big:
        return info
    end
    side = String(limits["max_side"])
    output = artifact("png")
    result = core.cli([tool, info["path"] + "[0]", "-auto-orient", "-resize", side + "x" + side + ">", "-strip", output])
    if result["ok"] and exists(output) and file_size(output) > limits["target_bytes"]:
        call core.run("rm -f -- " + core.quote(output))
        output = artifact("jpg")
        result = core.cli([tool, info["path"] + "[0]", "-auto-orient", "-resize", side + "x" + side + ">", "-strip", "-background", "white", "-flatten", "-quality", "85", output])
    end
    if not result["ok"] or not exists(output):
        return info
    end
    resized = inspect(output)
    if resized["format"] == "":
        return info
    end
    resized["resized"] = True
    resized["original_bytes"] = info["bytes"]
    return resized
end

function add_file(filename, source=""):
    filename = core.path(filename)
    if not exists(filename):
        Error(AttachmentError: i18n.t("Soubor neexistuje: ") + filename)
    end
    info = shrink(inspect(filename))
    if info["format"] == "":
        Error(AttachmentError: i18n.t("Nepodporovaný formát obrázku (použij PNG, JPEG, WebP nebo GIF): ") + filename)
    end
    if info["bytes"] > limits["max_bytes"]:
        Error(AttachmentError: i18n.t("Obrázek je větší než 4 MiB; pro automatické zmenšení nainstaluj imagemagick: ") + human(info["bytes"]))
    end
    if source == "":
        source = filename
    end
    info["source"] = source
    info["mime"] = mimes[info["format"]]
    pending.append(info)
    return info
end

function human(size):
    if size < 1024:
        return String(size) + " B"
    elif size < 1048576:
        return String((size + 512) // 1024) + " KB"
    end
    tenths = (size * 10 + 524288) // 1048576
    return String(tenths // 10) + "." + String(tenths % 10) + " MB"
end

function label(info):
    dims = "?"
    if info.get("width", 0) > 0:
        dims = String(info["width"]) + "×" + String(info["height"])
    end
    text = "📎 " + i18n.t("obrázek přiložen") + " (" + dims + ", " + human(info["bytes"]) + ")"
    if info.get("resized", False):
        text += " · " + i18n.t("zmenšeno z ") + human(info["original_bytes"])
    end
    return text
end

function chip():
    if len(pending) == 0:
        return ""
    elif len(pending) == 1:
        return label(pending[0])
    end
    return "📎 " + String(len(pending)) + i18n.t(" obrázky přiloženy") + " (" + human(total_bytes()) + ")"
end

function total_bytes():
    total = 0
    for item in pending:
        total += item["bytes"]
    end
    return total
end

function remove_last():
    if len(pending) == 0:
        return False
    end
    call pending.pop(len(pending) - 1)
    return True
end

function clear():
    pending.clear()
end

function hexval(code):
    if code >= 48 and code <= 57:
        return code - 48
    elif code >= 65 and code <= 70:
        return code - 55
    elif code >= 97 and code <= 102:
        return code - 87
    end
    return -1
end

function percent_decode(text):
    count = codec.size(text)
    bytes = ByteArray()
    i = 0
    while i < count:
        value = codec.byte(text, i)
        if value == 37 and i + 2 < count:
            high = hexval(codec.byte(text, i + 1))
            low = hexval(codec.byte(text, i + 2))
            if high >= 0 and low >= 0:
                bytes.append(high * 16 + low)
                i += 3
                continue
            end
        end
        bytes.append(value)
        i += 1
    end
    return codec.raw(bytes)
end

function tokens(text):
    # Rozdělení jako v shellu: terminál při přetažení cesty uvozuje ('a b.png').
    result = []
    current = ""
    active = False
    quote = ""
    escaped = False
    for ch in text:
        if escaped:
            current += ch
            escaped = False
        elif quote != "":
            if ch == quote:
                quote = ""
            else:
                current += ch
            end
        elif ch == "\\":
            escaped = True
            active = True
        elif ch == "'" or ch == "\"":
            quote = ch
            active = True
        elif ch == " " or ch == "\n" or ch == "\t" or ch == "\r":
            if active:
                result.append(current)
            end
            current = ""
            active = False
        else:
            current += ch
            active = True
        end
    end
    if quote != "":
        return []
    end
    if active:
        result.append(current)
    end
    return result
end

function local_path(token):
    value = token
    if value.startswith("file://"):
        value = value[7:len(value)]
        if not value.startswith("/"):
            slash = value.find("/")
            if slash < 0:
                return ""
            end
            host = value[0:slash]
            if host != "localhost":
                return ""
            end
            value = value[slash:len(value)]
        end
        value = percent_decode(value)
    elif not (value.startswith("/") or value.startswith("~/") or value.startswith("./") or value.startswith("../")):
        return ""
    end
    return core.path(value)
end

function image_paths(text):
    # Vrací cesty jen tehdy, když CELÝ text tvoří existující obrázky; jinak [].
    stripped = text.strip()
    if stripped == "" or len(stripped) > 8192:
        return []
    end
    found = []
    pieces = tokens(stripped)
    if len(pieces) == 0 or len(pieces) > 20:
        return []
    end
    for piece in pieces:
        filename = local_path(piece)
        if filename == "" or not exists(filename):
            return []
        end
        try:
            if not core.run("test -f " + core.quote(filename))["ok"]:
                return []
            end
            if file_size(filename) > limits["read_limit"]:
                return []
            end
            if sniff(header(filename, file_size(filename)))["format"] == "":
                return []
            end
        else:
            return []
        end
        found.append(filename)
    end
    return found
end

function add_paths(text):
    added = []
    for filename in image_paths(text):
        added.append(add_file(filename))
    end
    return added
end

function uri_list(text):
    lines = []
    for raw in text.replace("\r", "").split("\n"):
        line = raw.strip()
        if line.startswith("file://") or line.startswith("/"):
            lines.append(core.quote(line))
        end
    end
    return " ".join(lines)
end

function backend():
    if runtime_env.get("DISPLAY", "") != "" and has_tool("xclip"):
        return "xclip"
    elif runtime_env.get("WAYLAND_DISPLAY", "") != "" and has_tool("wl-paste"):
        return "wl-paste"
    elif has_tool("xclip") and runtime_env.get("DISPLAY", "") != "":
        return "xclip"
    end
    return ""
end

function read_command(tool, mime):
    if tool == "xclip":
        return "timeout 5 xclip -selection clipboard -t " + core.quote(mime) + " -o"
    end
    return "timeout 5 wl-paste --no-newline --type " + core.quote(mime)
end

function clipboard():
    # Výsledek: {"added": [...]} nebo {"text": "..."}; chyby vyvolá AttachmentError.
    tool = backend()
    if tool == "":
        if runtime_env.get("DISPLAY", "") == "" and runtime_env.get("WAYLAND_DISPLAY", "") == "":
            Error(AttachmentError: i18n.t("Schránka není dostupná: chybí grafické sezení (DISPLAY/WAYLAND_DISPLAY)."))
        end
        Error(AttachmentError: i18n.t("Pro vložení obrázku ze schránky nainstaluj xclip (X11) nebo wl-clipboard (Wayland)."))
    end
    listing = ""
    if tool == "xclip":
        listing = core.run("timeout 5 xclip -selection clipboard -t TARGETS -o")
    else:
        listing = core.run("timeout 5 wl-paste --list-types")
    end
    if not listing["ok"]:
        Error(AttachmentError: i18n.t("Schránka je prázdná."))
    end
    targets = []
    for raw in listing["stdout"].split("\n"):
        if raw.strip() != "":
            targets.append(raw.strip())
        end
    end
    for mime in clipboard_types:
        if mime in targets:
            extension = mime.split("/")[1].replace("x-", "")
            if extension == "jpeg":
                extension = "jpg"
            end
            filename = artifact(extension)
            result = core.run(read_command(tool, mime) + " > " + core.quote(filename))
            if not result["ok"] or file_size(filename) == 0:
                call core.run("rm -f -- " + core.quote(filename))
                Error(AttachmentError: i18n.t("Obrázek ze schránky se nepodařilo přečíst."))
            end
            call core.checked("chmod 600 -- " + core.quote(filename))
            return {"added": [add_file(filename, i18n.t("schránka"))]}
        end
    end
    for mime in ["text/uri-list", "x-special/gnome-copied-files"]:
        if mime in targets:
            result = core.run(read_command(tool, mime))
            if result["ok"]:
                listed = uri_list(result["stdout"])
                if listed != "" and len(image_paths(listed)) > 0:
                    return {"added": add_paths(listed)}
                end
            end
        end
    end
    text = ""
    for mime in ["UTF8_STRING", "text/plain;charset=utf-8", "text/plain", "STRING", "TEXT"]:
        if text == "" and mime in targets:
            result = core.run(read_command(tool, mime))
            if result["ok"]:
                text = result["stdout"]
            end
        end
    end
    if text == "":
        Error(AttachmentError: i18n.t("Ve schránce není obrázek ani text."))
    end
    if len(image_paths(text)) > 0:
        return {"added": add_paths(text)}
    end
    return {"text": text}
end

function payload(info):
    data = core.checked("base64 -w0 -- " + core.quote(info["path"]))
    return {"type": "image_url", "image_url": {"url": "data:" + info["mime"] + ";base64," + data}}
end

function take():
    # Vytvoří obsah zprávy s obrázky a vyprázdní frontu příloh.
    if len(pending) == 0:
        return None
    end
    names = []
    for info in pending:
        names.append(info["path"] + " (" + String(info.get("width", 0)) + "x" + String(info.get("height", 0)) + ", " + human(info["bytes"]) + ")")
    end
    content = [{"type": "text", "text": "Images attached by the user to the preceding message. Source files (reopen with view_image if needed): " + "; ".join(names)}]
    for info in pending:
        content.append(payload(info))
    end
    pending.clear()
    return {"role": "user", "content": content}
end
