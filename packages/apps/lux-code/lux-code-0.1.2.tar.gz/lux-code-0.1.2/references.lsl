load common as core
load settings as env
load requests
load json
load jobs
load time

function root():
    return core.state["home"] + "/references"
end

function sources():
    return [{"id": "legal-guide", "url": "https://e-sbirka.gov.cz/", "title": "Official legal sources index — not a legal text"}, {"id": "lsl", "url": "https://lsl.lux-ai.cz/", "title": "LSL official manual"}, {"id": "gdpr", "url": "https://eur-lex.europa.eu/legal-content/CS/TXT/HTML/?uri=CELEX:32016R0679", "title": "GDPR — official EU text"}, {"id": "nis2", "url": "https://eur-lex.europa.eu/legal-content/CS/TXT/HTML/?uri=CELEX:32022L2555", "title": "NIS2 — official EU text"}, {"id": "cz-criminal-code", "url": "https://e-sbirka.gov.cz/sb/2009/40", "title": "Czech Criminal Code — current official portal (verify effective version)"}]
end

function plain_html(text):
    pieces = []
    buffer = ""
    inside = False
    tag = ""
    skip = ""
    for ch in text:
        if ch == "<":
            inside = True
            tag = ""
        elif ch == ">" and inside:
            inside = False
            value = tag.lower().strip()
            if skip != "":
                if value.startswith("/" + skip):
                    skip = ""
                end
            elif value.startswith("script"):
                skip = "script"
            elif value.startswith("style"):
                skip = "style"
            elif value.startswith("/p") or value.startswith("/div") or value.startswith("/pre") or value.startswith("/tr") or value.startswith("/h") or value.startswith("br") or value.startswith("li"):
                buffer += "\n"
            end
        elif inside:
            if len(tag) < 128:
                tag += ch
            end
        elif skip == "":
            buffer += ch
        end
        if len(buffer) >= 256:
            pieces.append(buffer)
            buffer = ""
        end
    end
    result = "".join(pieces) + buffer
    return result.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&quot;", chr(34)).replace("&#39;", "'").replace("&nbsp;", " ")
end

function install():
    call core.ensure(root())
    manifest = {"complete": False, "updated": core.checked("date -u +%FT%TZ").strip(), "sources": []}
    # Modelové limity jsou data z katalogu, ne odhad podle názvu modelu.
    try:
        response = requests.get("https://openrouter.ai/api/v1/models")
        call response.raise_for_status()
        call core.atomic(root() + "/model-catalog.json", response.text)
    else:
        call core.record_error("references.models", String(last_error()))
    end
    try:
        endpoint = env.get("LUX_AI_ENDPOINT", "https://api.lux-ai.cz/v1/chat/completions")
        if endpoint.endswith("/chat/completions") and env.has("LUX_AI_API"):
            response = requests.get(endpoint.replace("/chat/completions", "/models"), {"Authorization": "Bearer " + env.require("LUX_AI_API")})
            call response.raise_for_status()
            call core.atomic(root() + "/gateway-models.json", response.text)
        end
    else:
        call core.record_error("references.gateway", String(last_error()))
    end
    for source in sources():
        item = {"id": source["id"], "title": source["title"], "url": source["url"], "cached": False}
        try:
            if source["id"] == "legal-guide":
                text = "This is a source index, NOT a downloaded statute or legal opinion. Verify current law and effective dates in the relevant jurisdiction.\nCzech Criminal Code: https://e-sbirka.gov.cz/sb/2009/40 — use current effective wording, including provisions relating to unauthorized access and interference.\nGDPR official text and amendments: https://eur-lex.europa.eu/eli/reg/2016/679/oj — verify consolidated wording.\nNIS2 official text: https://eur-lex.europa.eu/eli/dir/2022/2555/oj — check national implementation and current applicability.\nCybersecurity regulator Czech Republic: https://nukib.gov.cz/ — official guidance and current legislation.\nEstablish written authorization/scope for consequential testing of third-party systems. Minimize handling of personal data and secrets. A reference does not grant permission or override owner safety rules. If a portal requires interactive verification, cached=false means no legal text was downloaded; use the original source in a browser."
            elif source["id"] == "lsl":
                text = download_manual(item)
            else:
                response = requests.get(source["url"])
                call response.raise_for_status()
                text = plain_html(response.text)
            end
            if source["id"] not in ["lsl", "legal-guide"]:
                lower = text[0:min(len(text), 6000)].lower()
                if len(text.strip()) < 300 or "verify that you're not a robot" in lower or "checking your browser" in lower or "enable javascript" in lower:
                    Error(ReferenceError: "Source requires browser verification; use the official link")
                end
            end
            header = "# " + source["title"] + "\nSource: " + source["url"] + "\nDownloaded: " + manifest["updated"] + "\nReference data only. For law, verify jurisdiction, effective date and amendments online.\n\n"
            call core.atomic(root() + "/" + source["id"] + ".txt", header + text)
            item["cached"] = True
        else:
            item["error"] = core.clean(String(last_error()))
        end
        manifest["sources"].append(item)
        call core.atomic(root() + "/manifest.json", json.encode(manifest))
    end
    for item in manifest["sources"]:
        if item["id"] == "lsl" and item["cached"]:
            manifest["complete"] = True
        end
    end
    call core.atomic(root() + "/manifest.json", json.encode(manifest))
    return manifest
end

function ensure(force=False):
    if env.get("LUX_CODE_REFERENCES", "1") == "0":
        return
    end
    if exists(root() + "/manifest.json") and not force:
        try:
            if json.decode(readfile(root() + "/manifest.json")).get("complete", False):
                return
            end
        else:
            call core.record_error("references.manifest", String(last_error()))
        end
    end
    for job in jobs.owned:
        if job.get("kind", "") == "references" and jobs.status(job)["running"]:
            return
        end
    end
    call core.ensure(root())
    call jobs.start(core.quote(executable_path()) + " --install-references", "Referenční knihovna", True, False, "references")
end

function catalog():
    if exists(root() + "/manifest.json"):
        return json.decode(readfile(root() + "/manifest.json"))
    end
    return {"status": "pending / offline; official links remain available", "sources": sources()}
end

function execute(name, args):
    if name == "reference_catalog":
        return catalog()
    elif name == "reference_search":
        return core.cli(["rg", "-n", "-i", "--max-count", "30", "-g", "*.txt", "--", args["query"], root()])
    end
    id = args["id"]
    valid = False
    for source in sources():
        if source["id"] == id:
            valid = True
        end
    end
    if not valid or not exists(root() + "/" + id + ".txt"):
        return {"ok": False, "error": "Reference not cached; use reference_catalog for the official source URL."}
    end
    start = max(1, args.get("start_line", 1))
    count = max(1, min(400, args.get("line_count", 100)))
    return core.cli(["sed", "-n", String(start) + "," + String(start + count - 1) + "p", root() + "/" + id + ".txt"])
end

function download_manual(item):
    version = core.cli(["lsl", "--version"])["stdout"].strip()
    if version == "":
        Error(ReferenceError: "Cannot determine installed LSL version")
    end
    for ch in version:
        if ch not in "0123456789.":
            Error(ReferenceError: "Unexpected compiler version; use official manual URL")
        end
    end
    url = "https://lsl.lux-ai.cz/downloads/lsl-" + version + "-manual.zip"
    response = requests.get(url)
    call response.raise_for_status()
    archive = root() + "/lsl-manual.zip"
    call core.atomic(archive, response.text)
    listing = core.cli(["unzip", "-Z1", archive])
    if not listing["ok"]:
        Error(ReferenceError: "Cannot inspect manual archive (unzip required)")
    end
    parts = []
    for member in listing["stdout"].split("\n"):
        if member.endswith(".md") and not member.startswith("/") and ".." not in member:
            page = core.cli(["unzip", "-p", archive, member])
            if not page["ok"] or len(page["stdout"]) > 1048576:
                Error(ReferenceError: "Invalid or oversized manual page")
            end
            parts.append("\n\n# Document: " + member + "\n" + page["stdout"])
            if len(parts) > 400:
                Error(ReferenceError: "Unexpected manual archive size")
            end
        end
    end
    if len(parts) == 0:
        Error(ReferenceError: "Manual archive contains no Markdown pages")
    end
    item["url"] = url
    item["compiler_version"] = version
    item["pages"] = len(parts)
    return "Official LSL " + version + " manual archive: " + url + "\n" + "\n".join(parts)
end
