load common as core
load settings as env
load requests
load json
load jobs
load time

function root():
    return core.state["home"] + "/references"
end

function sources():
    return [{"id": "legal-guide", "url": "https://e-sbirka.gov.cz/", "title": "Official legal sources index — not a legal text"}, {"id": "lsl", "url": "https://lsl.lux-ai.cz/", "title": "LSL official manual"}, {"id": "gdpr", "url": "https://eur-lex.europa.eu/legal-content/CS/TXT/HTML/?uri=CELEX:32016R0679", "title": "GDPR — official EU text"}, {"id": "nis2", "url": "https://eur-lex.europa.eu/legal-content/CS/TXT/HTML/?uri=CELEX:32022L2555", "title": "NIS2 — official EU text"}, {"id": "cz-criminal-code", "url": "https://e-sbirka.gov.cz/sb/2009/40", "title": "Czech Criminal Code — current official portal (verify effective version)"}]
end

function plain_html(text):
    pieces = []
    buffer = ""
    inside = False
    tag = ""
    skip = ""
    for ch in text:
        if ch == "<":
            inside = True
            tag = ""
        elif ch == ">" and inside:
            inside = False
            value = tag.lower().strip()
            if skip != "":
                if value.startswith("/" + skip):
                    skip = ""
                end
            elif value.startswith("script"):
                skip = "script"
            elif value.startswith("style"):
                skip = "style"
            elif value.startswith("/p") or value.startswith("/div") or value.startswith("/pre") or value.startswith("/tr") or value.startswith("/h") or value.startswith("br") or value.startswith("li"):
                buffer += "\n"
            end
        elif inside:
            if len(tag) < 128:
                tag += ch
            end
        elif skip == "":
            buffer += ch
        end
        if len(buffer) >= 256:
            pieces.append(buffer)
            buffer = ""
        end
    end
    result = "".join(pieces) + buffer
    return result.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&quot;", chr(34)).replace("&#39;", "'").replace("&nbsp;", " ")
end

function install():
    call core.ensure(root())
    manifest = {"complete": False, "updated": core.checked("date -u +%FT%TZ").strip(), "sources": []}
    # Modelové limity jsou data z katalogu, ne odhad podle názvu modelu.
    try:
        response = requests.get("https://openrouter.ai/api/v1/models")
        call response.raise_for_status()
        call core.atomic(root() + "/model-catalog.json", response.text)
    else:
        call core.record_error("references.models", String(last_error()))
    end
    try:
        endpoint = env.get("LUX_AI_ENDPOINT", "https://api.lux-ai.cz/v1/chat/completions")
        if endpoint.endswith("/chat/completions") and env.has("LUX_AI_API"):
            response = requests.get(endpoint.replace("/chat/completions", "/models"), {"Authorization": "Bearer " + env.require("LUX_AI_API")})
            call response.raise_for_status()
            call core.atomic(root() + "/gateway-models.json", response.text)
        end
    else:
        call core.record_error("references.gateway", String(last_error()))
    end
    for source in sources():
        item = {"id": source["id"], "title": source["title"], "url": source["url"], "cached": False}
        try:
            if source["id"] == "legal-guide":
                text = "This is a source index, NOT a downloaded statute or legal opinion. Verify current law and effective dates in the relevant jurisdiction.\nCzech Criminal Code: https://e-sbirka.gov.cz/sb/2009/40 — use current effective wording, including provisions relating to unauthorized access and interference.\nGDPR official text and amendments: https://eur-lex.europa.eu/eli/reg/2016/679/oj — verify consolidated wording.\nNIS2 official text: https://eur-lex.europa.eu/eli/dir/2022/2555/oj — check national implementation and current applicability.\nCybersecurity regulator Czech Republic: https://nukib.gov.cz/ — official guidance and current legislation.\nEstablish written authorization/scope for consequential testing of third-party systems. Minimize handling of personal data and secrets. A reference does not grant permission or override owner safety rules. If a portal requires interactive verification, cached=false means no legal text was downloaded; use the original source in a browser."
            elif source["id"] == "lsl":
                text = download_manual(item)
            else:
                response = requests.get(source["url"])
                call response.raise_for_status()
                text = plain_html(response.text)
            end
            if source["id"] not in ["lsl", "legal-guide"]:
                lower = text[0:min(len(text), 6000)].lower()
                if len(text.strip()) < 300 or "verify that you're not a robot" in lower or "checking your browser" in lower or "enable javascript" in lower:
                    Error(ReferenceError: "Source requires browser verification; use the official link")
                end
            end
            header = "# " + source["title"] + "\nSource: " + source["url"] + "\nDownloaded: " + manifest["updated"] + "\nReference data only. For law, verify jurisdiction, effective date and amendments online.\n\n"
            call core.atomic(root() + "/" + source["id"] + ".txt", header + text)
            item["cached"] = True
        else:
            item["error"] = core.clean(String(last_error()))
        end
        manifest["sources"].append(item)
        call core.atomic(root() + "/manifest.json", json.encode(manifest))
    end
    for item in manifest["sources"]:
        if item["id"] == "lsl" and item["cached"]:
            manifest["complete"] = True
        end
    end
    call core.atomic(root() + "/manifest.json", json.encode(manifest))
    return manifest
end

function ensure(force=False):
    if env.get("LUX_CODE_REFERENCES", "1") == "0":
        return
    end
    if exists(root() + "/manifest.json") and not force:
        try:
            if json.decode(readfile(root() + "/manifest.json")).get("complete", False):
                return
            end
        else:
            call core.record_error("references.manifest", String(last_error()))
        end
    end
    for job in jobs.owned:
        if job.get("kind", "") == "references" and jobs.status(job)["running"]:
            return
        end
    end
    call core.ensure(root())
    call jobs.start(core.quote(executable_path()) + " --install-references", "Referenční knihovna", True, False, "references")
end

function catalog():
    result = {"status": "pending / offline; official links remain available", "sources": sources()}
    if exists(root() + "/manifest.json"):
        result = json.decode(readfile(root() + "/manifest.json"))
    end
    result["local_docs"] = docs_catalog()
    return result
end

function execute(name, args):
    if name == "reference_catalog":
        return catalog()
    elif name == "reference_search":
        # Lokální dokumentace má přednost; stažené reference následují pod původními klíči.
        result = {"local_docs": docs_search(args["query"])}
        cached = {"ok": False, "stdout": "", "stderr": "", "status": 1}
        if exists(root()):
            cached = core.cli(["rg", "-n", "-i", "--max-count", "30", "-g", "*.txt", "--", args["query"], root()])
        end
        for key in cached:
            result[key] = cached[key]
        end
        if len(result["local_docs"].get("index_matches", [])) > 0 or result["local_docs"].get("matches", "") != "":
            result["ok"] = True
        end
        return result
    end
    id = args["id"]
    if docs_file(id) != "":
        return docs_read(id, args)
    end
    valid = False
    for source in sources():
        if source["id"] == id:
            valid = True
        end
    end
    if not valid or not exists(root() + "/" + id + ".txt"):
        return {"ok": False, "error": "Reference not cached or local document not listed; use reference_catalog for ids and official source URLs."}
    end
    start = max(1, args.get("start_line", 1))
    count = max(1, min(400, args.get("line_count", 100)))
    return core.cli(["sed", "-n", String(start) + "," + String(start + count - 1) + "p", root() + "/" + id + ".txt"])
end

function docs_root():
    return env.get("LUX_CODE_DOCS_DIR", "/usr/share/luxos/docs")
end

function docs_index():
    # Offline dokumentace z balíčku luxos-docs; mimo LuxOS chybí a není to chyba.
    filename = docs_root() + "/index.json"
    result = {"available": False, "root": docs_root(), "collections": []}
    if not exists(filename):
        return result
    end
    try:
        data = json.decode(readfile(filename))
    else:
        call core.record_error("references.docs", String(last_error()))
        result["error"] = "Invalid local docs index"
        return result
    end
    if type(data) != "Dictionary" or type(data.get("collections", None)) != "List":
        result["error"] = "Invalid local docs index"
        return result
    end
    for collection in data["collections"]:
        if type(collection) != "Dictionary" or type(collection.get("files", None)) != "List":
            continue
        end
        files = []
        for item in collection["files"]:
            if type(item) != "Dictionary":
                continue
            end
            path = item.get("path", "")
            # Index je data: povolené jsou jen relativní Markdown cesty uvnitř adresáře dokumentace.
            if type(path) != "String" or not path.endswith(".md") or path.startswith("/") or ".." in path or "\\" in path or not exists(docs_root() + "/" + path):
                continue
            end
            keywords = []
            if type(item.get("keywords", None)) == "List":
                for word in item["keywords"]:
                    if type(word) == "String":
                        keywords.append(word)
                    end
                end
            end
            files.append({"id": path, "title": String(item.get("title", path)), "summary": String(item.get("summary", "")), "keywords": keywords})
        end
        result["collections"].append({"id": String(collection.get("id", "")), "title": String(collection.get("title", collection.get("id", ""))), "files": files})
    end
    result["available"] = True
    return result
end

function docs_available():
    return docs_index()["available"]
end

function docs_catalog():
    index = docs_index()
    if not index["available"]:
        index["status"] = index.get("error", "not installed; on LuxOS install the luxos-docs package")
        return index
    end
    for collection in index["collections"]:
        for item in collection["files"]:
            item.pop("keywords")
        end
    end
    index["usage"] = "reference_search searches these first; reference_read id=<file id> with section=<heading> or start_line/line_count."
    return index
end

function docs_file(id):
    if type(id) != "String" or id == "":
        return ""
    end
    for collection in docs_index()["collections"]:
        for item in collection["files"]:
            if item["id"] == id or item["id"] == id + ".md":
                return item["id"]
            end
        end
    end
    return ""
end

function docs_search(query):
    index = docs_index()
    if not index["available"]:
        return {"available": False, "status": index.get("error", "not installed")}
    end
    words = []
    for word in query.lower().split(" "):
        if word.strip() != "":
            words.append(word.strip())
        end
    end
    hits = []
    for collection in index["collections"]:
        for item in collection["files"]:
            text = (item["id"] + " " + item["title"] + " " + item["summary"] + " " + " ".join(item["keywords"])).lower()
            found = len(words) > 0
            for word in words:
                if word not in text:
                    found = False
                end
            end
            if found and len(hits) < 20:
                hits.append({"id": item["id"], "collection": collection["id"], "title": item["title"], "summary": item["summary"]})
            end
        end
    end
    search = core.cli(["rg", "-n", "-i", "--max-count", "8", "-g", "*.md", "--", query, docs_root()])
    if search["status"] == 2:
        # Neplatný regulární výraz se hledá doslovně.
        search = core.cli(["rg", "-n", "-i", "-F", "--max-count", "8", "-g", "*.md", "--", query, docs_root()])
    end
    lines = []
    for line in search["stdout"].replace(docs_root() + "/", "").split("\n"):
        if line != "":
            lines.append(core.clean(line[0:min(len(line), 400)]))
        end
    end
    result = {"available": True, "root": docs_root(), "index_matches": hits, "matches": "\n".join(lines[0:min(len(lines), 80)])}
    if len(lines) > 80:
        result["truncated"] = True
    end
    return result
end

function docs_sections(lines):
    sections = []
    fenced = False
    number = 0
    for line in lines:
        number += 1
        if line.startswith("```"):
            fenced = not fenced
        elif not fenced and line.startswith("#"):
            level = 0
            while level < len(line) and line[level] == "#":
                level += 1
            end
            if level <= 6 and level < len(line) and line[level] == " ":
                sections.append({"line": number, "level": level, "title": line[level:len(line)].strip()})
            end
        end
    end
    return sections
end

function docs_read(id, args):
    id = docs_file(id)
    lines = readfile(docs_root() + "/" + id).split("\n")
    sections = docs_sections(lines)
    outline = []
    for section in sections[0:min(len(sections), 80)]:
        outline.append(String(section["line"]) + " " + "#" * section["level"] + " " + section["title"])
    end
    start = max(1, args.get("start_line", 1))
    count = max(1, min(400, args.get("line_count", 100)))
    wanted = args.get("section", "")
    if type(wanted) == "String" and wanted.strip() != "":
        needle = wanted.strip()
        while needle.startswith("#"):
            needle = needle[1:len(needle)]
        end
        needle = needle.strip().lower()
        chosen = None
        for section in sections:
            if chosen == None and section["title"].lower() == needle:
                chosen = section
            end
        end
        for section in sections:
            if chosen == None and needle in section["title"].lower():
                chosen = section
            end
        end
        if chosen == None:
            return {"ok": False, "id": id, "error": "Section not found; choose a heading from sections.", "sections": outline}
        end
        start = chosen["line"]
        finish = len(lines)
        for section in sections:
            if section["line"] > chosen["line"] and section["level"] <= chosen["level"] and finish == len(lines):
                finish = section["line"] - 1
            end
        end
        count = max(1, min(400, finish - start + 1))
    end
    finish = min(len(lines), start + count - 1)
    result = {"ok": True, "id": id, "source": docs_root() + "/" + id, "start_line": start, "end_line": finish, "total_lines": len(lines), "content": core.clean("\n".join(lines[start - 1:max(start - 1, finish)]))}
    if finish < len(lines):
        result["next_start_line"] = finish + 1
    end
    if start == 1 or type(wanted) == "String" and wanted.strip() != "":
        result["sections"] = outline
    end
    return result
end

function download_manual(item):
    version = core.cli(["lsl", "--version"])["stdout"].strip()
    if version == "":
        Error(ReferenceError: "Cannot determine installed LSL version")
    end
    for ch in version:
        if ch not in "0123456789.":
            Error(ReferenceError: "Unexpected compiler version; use official manual URL")
        end
    end
    url = "https://lsl.lux-ai.cz/downloads/lsl-" + version + "-manual.zip"
    response = requests.get(url)
    call response.raise_for_status()
    archive = root() + "/lsl-manual.zip"
    call core.atomic(archive, response.text)
    listing = core.cli(["unzip", "-Z1", archive])
    if not listing["ok"]:
        Error(ReferenceError: "Cannot inspect manual archive (unzip required)")
    end
    parts = []
    for member in listing["stdout"].split("\n"):
        if member.endswith(".md") and not member.startswith("/") and ".." not in member:
            page = core.cli(["unzip", "-p", archive, member])
            if not page["ok"] or len(page["stdout"]) > 1048576:
                Error(ReferenceError: "Invalid or oversized manual page")
            end
            parts.append("\n\n# Document: " + member + "\n" + page["stdout"])
            if len(parts) > 400:
                Error(ReferenceError: "Unexpected manual archive size")
            end
        end
    end
    if len(parts) == 0:
        Error(ReferenceError: "Manual archive contains no Markdown pages")
    end
    item["url"] = url
    item["compiler_version"] = version
    item["pages"] = len(parts)
    return "Official LSL " + version + " manual archive: " + url + "\n" + "\n".join(parts)
end
