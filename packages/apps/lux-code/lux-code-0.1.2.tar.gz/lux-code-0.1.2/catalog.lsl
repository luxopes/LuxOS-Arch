load tools
call tools.init()
content = "# Nástroje Lux Code\n\nCelkem " + String(len(tools.tools)) + "; API přímo dostává " + String(len(tools.request_tools())) + ". Celý katalog je dostupný přes tool_search a call_tool.\n\n"
for tool in tools.tools:
    fn = tool["function"]
    content += "## " + fn["name"] + "\n\n" + fn["description"] + "\n\n"
    spec = fn["parameters"]
    for name in spec["properties"]:
        required = "optional"
        if name in spec["required"]:
            required = "required"
        end
        content += "- `" + name + "`: " + spec["properties"][name]["type"] + " (" + required + ")\n"
    end
    content += "\n"
end
writefile("TOOLS.md", content)
printl "Generated TOOLS.md: {len(tools.tools)} tools / {len(tools.request_tools())} direct API definitions"
