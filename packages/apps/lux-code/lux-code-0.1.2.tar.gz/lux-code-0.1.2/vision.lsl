load sessions
load json
load text_codec as codec

function count(messages):
    total = 0
    for message in messages:
        content = message.get("content", None)
        if type(content) == "List":
            for item in content:
                if item.get("type", "") == "image_url":
                    total += 1
                end
            end
        end
    end
    return total
end

function context_chars(messages):
    # Encoded bytes are transport, not text tokens. Vision pricing depends on
    # provider, dimensions and detail; 4096 tokens is only a fallback estimate.
    return len(json.encode(codec.safe(sessions.persisted_messages(messages)))) + count(messages) * 16384
end

function retire(messages):
    total = count(messages)
    if total > 0:
        projected = sessions.persisted_messages(messages)
        for index in range(len(messages)):
            messages[index]["content"] = projected[index].get("content", None)
        end
    end
    return total
end
