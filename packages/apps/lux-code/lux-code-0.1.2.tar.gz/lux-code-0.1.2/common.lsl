load text_codec as codec
load shell
load process
load os
load settings as env
load json

# Soukromý stav a kontext mohou přesahovat limit malého obecného JSON dokumentu.
json.JSON_MAX_BYTES = 67108864
json.JSON_MAX_ITEMS = 2097152

state = {"cwd": process.check("/bin/pwd", []).strip(), "home": "", "session": "", "cancelled": False}
state["home"] = env.get("LUX_CODE_HOME", env.get("HOME", "/tmp") + "/.local/state/lux-code")

function quote(value):
    return shell.quote(String(value))
end

function run(command):
    return process.capture_result("/bin/sh", ["-c", "cd " + quote(state["cwd"]) + " && " + command])
end

function cli(arguments):
    return run(shell.quote_all(arguments))
end

function checked(command):
    result = run(command)
    if not result["ok"]:
        Error(AgentError: result["stderr"] + result["stdout"])
    end
    return result["stdout"]
end

function path(value):
    if value.startswith("~/"):
        return env.get("HOME", "/tmp") + value[1:len(value)]
    elif value.startswith("/"):
        return value
    end
    return state["cwd"] + "/" + value
end

function text(args, key):
    value = args.get(key, None)
    if type(value) != "String" or value == "":
        Error(ToolError: key + " must be a non-empty String")
    end
    return value
end

function number(args, key, fallback):
    value = args.get(key, fallback)
    if type(value) != "Int":
        Error(ToolError: key + " must be an Int")
    end
    return value
end

function ensure(directory):
    call checked("mkdir -p -- " + quote(directory))
end

function atomic(filename, content):
    call ensure(checked("dirname -- " + quote(filename)).strip())
    temporary = checked("mktemp " + quote(filename + ".lux-XXXXXX")).strip()
    writefile(temporary, content)
    if exists(filename):
        call checked("chmod --reference=" + quote(filename) + " -- " + quote(temporary))
    end
    call checked("mv -- " + quote(temporary) + " " + quote(filename))
end

function clean(value):
    # Výstup nástrojů nesmí do terminálu propašovat escape sekvence.
    result = ""
    for ch in codec.repair(String(value)):
        code = ord(ch)
        if code == 10 or code == 9 or code >= 32 and (code < 127 or code >= 160):
            result += ch
        end
    end
    return result
end

function init():
    call ensure(state["home"] + "/sessions")
    call checked("chmod 700 -- " + quote(state["home"]) + " " + quote(state["home"] + "/sessions"))
    call ensure(state["home"] + "/artifacts")
    call ensure(state["home"] + "/jobs")
    state["last_job_poll"] = 0.0
    state["running_jobs"] = 0
    state["job_counts"] = {}
    state["usage_model"] = ""
    state["prompt_tokens"] = 0
    state["usage_chars"] = 0
    state["title_source"] = "fallback"
    state["session"] = checked("date +%Y%m%d-%H%M%S-%N").strip()
end

function record_error(stage, failure):
    # Diagnostika nesmí sama shodit proces při chybě disku/oprávnění.
    try:
        filename = state["home"] + "/artifacts/errors.log"
        stamp = checked("date -u +%FT%TZ").strip()
        appendfile(filename, stamp + " [" + stage + "] " + clean(failure).replace("\n", " ") + "\n")
        call checked("chmod 600 -- " + quote(filename))
    else:
        return
    end
end
