load env as runtime_env
load process

function load_values():
    directory = process.check("/usr/bin/dirname", [executable_path()]).strip()
    if directory.endswith("/.build"):
        directory = process.check("/usr/bin/dirname", [directory]).strip()
    end
    config_home = runtime_env.get("XDG_CONFIG_HOME", runtime_env.get("HOME", "/tmp") + "/.config")
    filename = directory + "/.env"
    if not exists(filename):
        filename = config_home + "/lux-code/.env"
    end
    filename = runtime_env.get("LUX_CODE_CONFIG", filename)
    result = {}
    if not exists(filename):
        return result
    end
    for raw in readfile(filename).split("\n"):
        line = raw.strip()
        if line == "" or line.startswith("#"):
            continue
        end
        if line.startswith("export "):
            line = line[7:len(line)].strip()
        end
        parts = line.split("=")
        if len(parts) < 2:
            continue
        end
        name = parts[0].strip()
        value = "=".join(parts[1:len(parts)]).strip()
        if len(value) >= 2:
            first = value[0]
            last = value[len(value) - 1]
            if first == chr(34) and last == chr(34) or first == "'" and last == "'":
                value = value[1:len(value) - 1]
            end
        end
        result[name] = value
    end
    return result
end

values = load_values()

function has(name):
    return runtime_env.has(name) or name in values
end

function get(name, fallback):
    if runtime_env.has(name):
        return runtime_env.get(name, fallback)
    end
    return values.get(name, fallback)
end

function require(name):
    if not has(name):
        Error(EnvironmentError: "Missing " + name + "; configure ~/.config/lux-code/.env, use .env beside chat.lsl, or set LUX_CODE_CONFIG.")
    end
    return get(name, "")
end
