# Jednobarevné ASCII logo LuxAI; funguje i bez fontů s Braille znaky.
variants = {}
variants["48"] = []
variants["48"].append({"plain": "                                                ", "spans": [{"text": "                                                ", "style": "38;5;75"}]})
variants["48"].append({"plain": "                     ::::::                     ", "spans": [{"text": "                     ::::::                     ", "style": "38;5;75"}]})
variants["48"].append({"plain": "                  ::::::::::::                  ", "spans": [{"text": "                  ::::::::::::                  ", "style": "38;5;75"}]})
variants["48"].append({"plain": "              ::::::::    ::::::::              ", "spans": [{"text": "              ::::::::    ::::::::              ", "style": "38;5;75"}]})
variants["48"].append({"plain": "           ::::::::          ::::::::           ", "spans": [{"text": "           ::::::::          ::::::::           ", "style": "38;5;75"}]})
variants["48"].append({"plain": "       ::::::::      ::          ::::::::       ", "spans": [{"text": "       ::::::::      ::          ::::::::       ", "style": "38;5;75"}]})
variants["48"].append({"plain": "    ::::::::      :::::             ::::::::    ", "spans": [{"text": "    ::::::::      :::::             ::::::::    ", "style": "38;5;75"}]})
variants["48"].append({"plain": "    :::::      ::::::::                :::::    ", "spans": [{"text": "    :::::      ::::::::                :::::    ", "style": "38;5;75"}]})
variants["48"].append({"plain": "    ::::       ::::::::                 ::::    ", "spans": [{"text": "    ::::       ::::::::                 ::::    ", "style": "38;5;75"}]})
variants["48"].append({"plain": "    ::::       ::::::::                 ::::    ", "spans": [{"text": "    ::::       ::::::::                 ::::    ", "style": "38;5;75"}]})
variants["48"].append({"plain": "    ::::       ::::::::                 ::::    ", "spans": [{"text": "    ::::       ::::::::                 ::::    ", "style": "38;5;75"}]})
variants["48"].append({"plain": "    ::::       ::::::::                 ::::    ", "spans": [{"text": "    ::::       ::::::::                 ::::    ", "style": "38;5;75"}]})
variants["48"].append({"plain": "    ::::       ::::::::                 ::::    ", "spans": [{"text": "    ::::       ::::::::                 ::::    ", "style": "38;5;75"}]})
variants["48"].append({"plain": "    ::::       ::::::::                 ::::    ", "spans": [{"text": "    ::::       ::::::::                 ::::    ", "style": "38;5;75"}]})
variants["48"].append({"plain": "    ::::       :::::::::::::::::::::::  ::::    ", "spans": [{"text": "    ::::       :::::::::::::::::::::::  ::::    ", "style": "38;5;75"}]})
variants["48"].append({"plain": "    ::::       ::::::::::::::::::::::   ::::    ", "spans": [{"text": "    ::::       ::::::::::::::::::::::   ::::    ", "style": "38;5;75"}]})
variants["48"].append({"plain": "    :::::      ::::::::::::::::::::    :::::    ", "spans": [{"text": "    :::::      ::::::::::::::::::::    :::::    ", "style": "38;5;75"}]})
variants["48"].append({"plain": "    ::::::::   ::::::::::::::::::   ::::::::    ", "spans": [{"text": "    ::::::::   ::::::::::::::::::   ::::::::    ", "style": "38;5;75"}]})
variants["48"].append({"plain": "       :::::::::                :::::::::       ", "spans": [{"text": "       :::::::::                :::::::::       ", "style": "38;5;75"}]})
variants["48"].append({"plain": "           ::::::::          ::::::::           ", "spans": [{"text": "           ::::::::          ::::::::           ", "style": "38;5;75"}]})
variants["48"].append({"plain": "              :::::::::  :::::::::              ", "spans": [{"text": "              :::::::::  :::::::::              ", "style": "38;5;75"}]})
variants["48"].append({"plain": "                  ::::::::::::                  ", "spans": [{"text": "                  ::::::::::::                  ", "style": "38;5;75"}]})
variants["48"].append({"plain": "                     ::::::                     ", "spans": [{"text": "                     ::::::                     ", "style": "38;5;75"}]})
variants["48"].append({"plain": "                                                ", "spans": [{"text": "                                                ", "style": "38;5;75"}]})
variants["36"] = []
variants["36"].append({"plain": "                                    ", "spans": [{"text": "                                    ", "style": "38;5;75"}]})
variants["36"].append({"plain": "              ::::::::              ", "spans": [{"text": "              ::::::::              ", "style": "38;5;75"}]})
variants["36"].append({"plain": "           ::::::  ::::::           ", "spans": [{"text": "           ::::::  ::::::           ", "style": "38;5;75"}]})
variants["36"].append({"plain": "       :::::::        :::::::       ", "spans": [{"text": "       :::::::        :::::::       ", "style": "38;5;75"}]})
variants["36"].append({"plain": "    :::::::    ::        :::::::    ", "spans": [{"text": "    :::::::    ::        :::::::    ", "style": "38;5;75"}]})
variants["36"].append({"plain": "   ::::     :::::            ::::   ", "spans": [{"text": "   ::::     :::::            ::::   ", "style": "38;5;75"}]})
variants["36"].append({"plain": "   :::     ::::::             :::   ", "spans": [{"text": "   :::     ::::::             :::   ", "style": "38;5;75"}]})
variants["36"].append({"plain": "   :::     ::::::             :::   ", "spans": [{"text": "   :::     ::::::             :::   ", "style": "38;5;75"}]})
variants["36"].append({"plain": "   :::     ::::::             :::   ", "spans": [{"text": "   :::     ::::::             :::   ", "style": "38;5;75"}]})
variants["36"].append({"plain": "   :::     ::::::             :::   ", "spans": [{"text": "   :::     ::::::             :::   ", "style": "38;5;75"}]})
variants["36"].append({"plain": "   :::     ::::::             :::   ", "spans": [{"text": "   :::     ::::::             :::   ", "style": "38;5;75"}]})
variants["36"].append({"plain": "   :::     :::::::::::::::::  :::   ", "spans": [{"text": "   :::     :::::::::::::::::  :::   ", "style": "38;5;75"}]})
variants["36"].append({"plain": "   ::::    :::::::::::::::   ::::   ", "spans": [{"text": "   ::::    :::::::::::::::   ::::   ", "style": "38;5;75"}]})
variants["36"].append({"plain": "    :::::::::::::::::::: :::::::    ", "spans": [{"text": "    :::::::::::::::::::: :::::::    ", "style": "38;5;75"}]})
variants["36"].append({"plain": "        ::::::        ::::::        ", "spans": [{"text": "        ::::::        ::::::        ", "style": "38;5;75"}]})
variants["36"].append({"plain": "           ::::::::::::::           ", "spans": [{"text": "           ::::::::::::::           ", "style": "38;5;75"}]})
variants["36"].append({"plain": "              ::::::::              ", "spans": [{"text": "              ::::::::              ", "style": "38;5;75"}]})
variants["36"].append({"plain": "                                    ", "spans": [{"text": "                                    ", "style": "38;5;75"}]})
variants["26"] = []
variants["26"].append({"plain": "            ::            ", "spans": [{"text": "            ::            ", "style": "38;5;75"}]})
variants["26"].append({"plain": "         ::::::::         ", "spans": [{"text": "         ::::::::         ", "style": "38;5;75"}]})
variants["26"].append({"plain": "     :::::     ::::::     ", "spans": [{"text": "     :::::     ::::::     ", "style": "38;5;75"}]})
variants["26"].append({"plain": "  :::::   :::      :::::  ", "spans": [{"text": "  :::::   :::      :::::  ", "style": "38;5;75"}]})
variants["26"].append({"plain": "  ::    :::::         ::  ", "spans": [{"text": "  ::    :::::         ::  ", "style": "38;5;75"}]})
variants["26"].append({"plain": "  ::    :::::         ::  ", "spans": [{"text": "  ::    :::::         ::  ", "style": "38;5;75"}]})
variants["26"].append({"plain": "  ::    :::::         ::  ", "spans": [{"text": "  ::    :::::         ::  ", "style": "38;5;75"}]})
variants["26"].append({"plain": "  ::    :::::         ::  ", "spans": [{"text": "  ::    :::::         ::  ", "style": "38;5;75"}]})
variants["26"].append({"plain": "  ::    ::::::::::::  ::  ", "spans": [{"text": "  ::    ::::::::::::  ::  ", "style": "38;5;75"}]})
variants["26"].append({"plain": "  ::::: ::::::::::::::::  ", "spans": [{"text": "  ::::: ::::::::::::::::  ", "style": "38;5;75"}]})
variants["26"].append({"plain": "     ::::::    ::::::     ", "spans": [{"text": "     ::::::    ::::::     ", "style": "38;5;75"}]})
variants["26"].append({"plain": "         ::::::::         ", "spans": [{"text": "         ::::::::         ", "style": "38;5;75"}]})
variants["26"].append({"plain": "            ::            ", "spans": [{"text": "            ::            ", "style": "38;5;75"}]})
variants["18"] = []
variants["18"].append({"plain": "       ::::       ", "spans": [{"text": "       ::::       ", "style": "38;5;75"}]})
variants["18"].append({"plain": "    ::::: ::::    ", "spans": [{"text": "    ::::: ::::    ", "style": "38;5;75"}]})
variants["18"].append({"plain": "  ::: :::    :::  ", "spans": [{"text": "  ::: :::    :::  ", "style": "38;5;75"}]})
variants["18"].append({"plain": " ::   :::      :: ", "spans": [{"text": " ::   :::      :: ", "style": "38;5;75"}]})
variants["18"].append({"plain": " ::   :::      :: ", "spans": [{"text": " ::   :::      :: ", "style": "38;5;75"}]})
variants["18"].append({"plain": " ::   :::::::  :: ", "spans": [{"text": " ::   :::::::  :: ", "style": "38;5;75"}]})
variants["18"].append({"plain": "  ::::::::::::::  ", "spans": [{"text": "  ::::::::::::::  ", "style": "38;5;75"}]})
variants["18"].append({"plain": "    ::::  ::::    ", "spans": [{"text": "    ::::  ::::    ", "style": "38;5;75"}]})
variants["18"].append({"plain": "       ::::       ", "spans": [{"text": "       ::::       ", "style": "38;5;75"}]})
variants["12"] = []
variants["12"].append({"plain": "    ::::    ", "spans": [{"text": "    ::::    ", "style": "38;5;75"}]})
variants["12"].append({"plain": " :::::  ::: ", "spans": [{"text": " :::::  ::: ", "style": "38;5;75"}]})
variants["12"].append({"plain": " :  ::    : ", "spans": [{"text": " :  ::    : ", "style": "38;5;75"}]})
variants["12"].append({"plain": " :  ::::  : ", "spans": [{"text": " :  ::::  : ", "style": "38;5;75"}]})
variants["12"].append({"plain": " :::::::::: ", "spans": [{"text": " :::::::::: ", "style": "38;5;75"}]})
variants["12"].append({"plain": "    ::::    ", "spans": [{"text": "    ::::    ", "style": "38;5;75"}]})

function rows(height):
    if height >= 34:
        return variants["48"]
    elif height >= 26:
        return variants["36"]
    elif height >= 21:
        return variants["26"]
    elif height >= 16:
        return variants["18"]
    end
    return variants["12"]
end
