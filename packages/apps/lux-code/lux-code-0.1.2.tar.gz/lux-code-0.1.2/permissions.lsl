load i18n
load common as core
load json

state = {"mode": "full"}
read_tools = ["reference_catalog", "reference_search", "reference_read","read_file", "file_info", "list_directory", "list_files", "file_hash", "read_json", "working_directory", "change_directory", "find_files", "search_text", "directory_tree", "compare_files", "git_status", "git_diff", "git_log", "git_show", "system_info", "runtime_status", "process_list", "list_ports", "disk_usage", "current_time", "web_search", "web_extract", "web_fetch", "service_logs", "service_status", "list_services", "memory_read", "todo_read", "todo_write", "todo_complete", "ask_user", "tool_search", "tool_catalog", "session_title", "view_image", "call_tool"]

function choices():
    return [{"value": "readonly", "label": i18n.t("Pouze čtení"), "detail": i18n.t("Čtení souborů a webu; bez shellu, úprav a ovládání PC.")}, {"value": "ask", "label": i18n.t("Potvrzovat akce"), "detail": i18n.t("Čtení automaticky; změny, shell a ovládání PC vždy potvrdit.")}, {"value": "full", "label": i18n.t("Plný přístup"), "detail": i18n.t("Nástroje bez jednotlivého potvrzování (dosavadní chování).")}]
end

function init():
    try:
        filename = core.state["home"] + "/permissions.json"
        if exists(filename):
            value = json.decode(readfile(filename))["mode"]
            if value not in ["readonly", "ask", "full"]:
                Error(PermissionError: "Invalid stored permission mode")
            end
            state["mode"] = value
        end
    else:
        state["mode"] = "ask"
        call core.record_error("permissions.load", String(last_error()))
    end
    core.state["permissions_mode"] = state["mode"]
end

function set(mode):
    if mode not in ["readonly", "ask", "full"]:
        Error(PermissionError: i18n.t("Použij readonly, ask nebo full."))
    end
    call core.atomic(core.state["home"] + "/permissions.json", json.encode({"mode": mode}))
    state["mode"] = mode
    core.state["permissions_mode"] = mode
end

function decision(name):
    if state["mode"] == "full" or name in read_tools:
        return "allow"
    elif state["mode"] == "readonly":
        return "deny"
    end
    return "ask"
end
