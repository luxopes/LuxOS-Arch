# shell 1.1.0: plnohodnotný shell (/bin/sh -c) s potlačeným prostředím.
# Proč: modul os záměrně nikdy nespouští shell (execve only, bez pipes/for/redirect).
# shell je explicitní, ohraničený protějšek: spouští /bin/sh -c a vrací strukturovaný výsledek.
# Použití: load shell
#
#   shell.run("ls | wc -l")                  -> Int (exit status, stdio se zachytí)
#   shell.capture("ls | wc -l")              -> String (stdout)
#   shell.capture_result("find . | head")    -> {stdout, stderr, status, ok}
#   shell.quote("a; rm -rf x")               -> String (bezpečný jeden argument pro shell)
#   shell.quote_all(["a", "b"])              -> String (mezera-spojené quote)
#
# Bezpečnost: příkaz se spouští v omezeném prostředí (env -i, HOME, PATH, IFS reset),
# bez TERM a jiných proměnných. Timeout volitelný (sekundy).

load process
load os
load env

version = "1.1.0"
_SHELL = "/bin/sh"
_PATH = "/usr/local/bin:/usr/bin:/bin"
_MAX_COMMAND_BYTES = 65536

function help():
    return "shell " + version + "\nload shell\n\nrun(command) -> Int\ncapture(command) -> String\ncapture_result(command) -> Dictionary {stdout, stderr, status, ok}\nrun_t(command, timeout) / capture_t / capture_result_t: varianty s timeoutem v sekundách\nquote(value) -> String\nquote_all(values) -> String\nChyby (ShellError) zachytíte přes try/else; zpráva je v last_error().\nPozor: command se interpretuje shellem; nikdy do něj nesklaďte nedůvěryhodný vstup (použijte quote)."
end

function _checked(command, timeout):
    if type(command) != "String" or len(command) == 0:
        Error(ShellError: "shell command must be a non-empty String")
    end
    if len(command) > _MAX_COMMAND_BYTES:
        Error(ShellError: "shell command exceeds " + String(_MAX_COMMAND_BYTES) + " bytes")
    end
    if "\0" in command:
        Error(ShellError: "shell command must not contain NUL bytes")
    end
    if timeout != None and (type(timeout) != "Int" or timeout < 1 or timeout > 86400):
        Error(ShellError: "timeout must be an Int between 1 and 86400")
    end
end

# shell.quote: jeden argument uvozený tak, aby ho shell neinterpretoval.
# Používá jednoduché uvozovky; vnitřní ' se zapíše jako '\''.
function quote(value):
    text = String(value)
    if "\0" in text:
        Error(ShellError: "quote value must not contain NUL bytes")
    end
    return "'" + text.replace("'", "'\\''") + "'"
end

function quote_all(values):
    if type(values) != "List":
        Error(ShellError: "quote_all expects a List")
    end
    parts = []
    for value in values:
        parts.append(quote(value))
    end
    return " ".join(parts)
end

# Omezené prostředí: env -i, jen HOME a PATH. Skrze env(1) se sh spustí čistě,
# bez děděných proměnných (TERM, IFS, …).
function _argv(command, timeout):
    home = "/tmp"
    if env.has("HOME"):
        home = env.get("HOME", "/tmp")
        if len(home) == 0:
            home = "/tmp"
        end
    end
    prefix = ["/usr/bin/env", "-i", "HOME=" + os.checked_argument(home, "HOME"), "PATH=" + _PATH]
    if timeout != None:
        # timeout(1) před shellem; při vypršení vrací status 124
        prefix.append("/usr/bin/timeout")
        prefix.append(String(timeout))
    end
    prefix.append(_SHELL)
    prefix.append("-c")
    prefix.append(command)
    return prefix
end

function _execute(command, timeout):
    call _checked(command, timeout)
    arguments = _argv(command, timeout)
    return process.capture_result("/usr/bin/env", arguments[1:len(arguments)])
end

function run_t(command, timeout):
    return _execute(command, timeout)["status"]
end

function capture_t(command, timeout):
    return _execute(command, timeout)["stdout"]
end

function capture_result_t(command, timeout):
    return _execute(command, timeout)
end

function run(command):
    return run_t(command, None)
end

function capture(command):
    return capture_t(command, None)
end

function capture_result(command):
    return capture_result_t(command, None)
end
