load common as core
load json

state = {"language": "en"}
translations = {
    "Nové sezení": "New session",
    "Běžící shelly, služby a monitoring": "Running shells, services and monitors",
    "Referenční knihovna / update": "Reference library / update",
    "Oprávnění nástrojů: readonly / ask / full": "Tool permissions: readonly / ask / full",
    "Pokračovat v pojmenovaném sezení": "Resume a named session",
    "Úroveň přemýšlení": "Reasoning effort",
    "Prohlédnout změněné soubory": "Review changed files",
    "Katalog nástrojů": "Tool catalog",
    "Zobrazit / skrýt reasoning": "Show / hide reasoning",
    "Vybrat uložené sezení": "Choose a saved session",
    "Začít nové sezení": "Start a new session",
    "Přejmenovat sezení": "Rename session",
    "Uložit sezení": "Save session",
    "Vrátit poslední editaci": "Undo the last edit",
    "Zobrazit plán": "Show plan",
    "Změnit pracovní složku": "Change working directory",
    "Shrnout dlouhý kontext": "Summarize long context",
    "Pokračovat po přerušení": "Continue after interruption",
    "Vyčistit obrazovku": "Clear screen",
    "Nápověda a klávesové zkratky": "Help and keyboard shortcuts",
    "Uložit a ukončit": "Save and quit",
    "přerušeno": "interrupted",
    " řádků / ": " lines / ",
    " znaků": " characters",
    " řádků": " lines",
    " nástrojů": " tools",
    "výstup v artefaktu": "output saved to artifact",
    "žádné shody": "no matches",
    "nalezeny rozdíly": "differences found",
    " položek": " items",
    "neplatná odpověď nástroje": "invalid tool response",
    "Oprávnění nástrojů": "Tool permissions",
    "◌ Přemýšlení": "◌ Reasoning",
    "PLÁN": "PLAN",
    "Zatím žádný plán.": "No plan yet.",
    " změněných souborů": " changed files",
    "F2 změny / plán": "F2 changes / plan",
    "ZMĚNY · ": "CHANGES · ",
    " ↑↓ výběr · Enter potvrdit · Tab doplnit · Esc zavřít": " ↑↓ select · Enter confirm · Tab complete · Esc close",
    "Napiš zadání  ·  /model  ·  /resume": "Enter a task  ·  /model  ·  /resume",
    "  Enter odeslat · Alt+Enter nový řádek · Ctrl+V obrázek · / příkazy · F2 změny/plán · F3 detaily": "  Enter send · Alt+Enter new line · Ctrl+V image · / commands · F2 changes/plan · F3 details",
    " zadání ve frontě  ·  PgUp/PgDn historie  ·  Ctrl+C přerušit": " queued prompts  ·  PgUp/PgDn history  ·  Ctrl+C interrupt",
    "Příkazy": "Commands",
    "  Žádné shody. Změň filtr nebo stiskni Esc.": "  No matches. Change the filter or press Esc.",
    " ↑↓ výběr  ·  Enter potvrdit  ·  Esc zpět": " ↑↓ select  ·  Enter confirm  ·  Esc back",
    "Vyber číslo nebo napiš hodnotu": "Select a number or enter a value",
    "služby": "services",
    "stahování": "downloads",
    "Žádné úlohy na pozadí": "No background jobs",
    "Oprávnění: ": "Permissions: ",
    "Načítám katalog modelů…": "Loading model catalog…",
    "Použij auto, none, low, medium, high, xhigh nebo max.": "Use auto, none, low, medium, high, xhigh or max.",
    "Pokračovat v sezení": "Resume session",
    "Pokračujete: ": "Resumed: ",
    "Název sezení": "Session title",
    "Sezení: ": "Session: ",
    "Prázdné sezení se neukládá.": "Empty sessions are not saved.",
    "Žádné změny souborů.": "No file changes.",
    "Změněné soubory": "Changed files",
    "Složka: ": "Directory: ",
    "Neznámý příkaz. /help zobrazí nápovědu.": "Unknown command. Type /help for help.",
    "Chyba · připraveno pokračovat": "Error · ready to continue",
    "Pouze čtení": "Read only",
    "Čtení souborů a webu; bez shellu, úprav a ovládání PC.": "Read files and web pages; no shell, edits or computer control.",
    "Potvrzovat akce": "Ask before actions",
    "Čtení automaticky; změny, shell a ovládání PC vždy potvrdit.": "Read automatically; confirm edits, shell commands and computer control.",
    "Plný přístup": "Full access",
    "Nástroje bez jednotlivého potvrzování (dosavadní chování).": "Use tools without individual confirmation.",
    "Použij readonly, ask nebo full.": "Use readonly, ask or full.",
    "**Paměť konverzace**": "**Conversation memory**",
    " % využito": " % used",
    "V konverzaci: přibližně **": "Conversation: approximately **",
    "** tokenů": "** tokens",
    "Kapacita modelu: **": "Model capacity: **",
    "Do limitu zbývá přibližně **": "Approximately **",
    "** tokenů; část potřebuje model na odpověď.": "** tokens left; some space is needed for the reply.",
    "Kapacitu tohoto modelu služba neuvádí, proto nelze určit procento využití.": "The service does not report this model's capacity, so the usage percentage is unavailable.",
    "Tokeny jsou malé části textu. Do paměti se počítá konverzace, instrukce a výsledky nástrojů.": "Tokens are small pieces of text. Memory includes the conversation, instructions and tool results.",
    "Poslední požadavek podle API: **": "Last request reported by the API: **",
    "** vstupních tokenů, včetně případných obrázků.": "** input tokens, including any images.",
    "Aktuální využití je odhad; u obrázků se může lišit. Při zaplnění se starší zprávy automaticky shrnou. Ručně: `/compact`.": "Current usage is estimated; images may vary. Older messages are summarized automatically as memory fills up. To do this manually, use `/compact`.",
    "Starý kontext instrukcí archivován. Obnovena zadání; projekt se ověří z aktuální složky.": "Old instruction context archived. Tasks restored; the project will be checked from the current directory.",
    " zadání": " prompts",
    "Sezení se nepodařilo uložit: ": "Could not save session: ",
    "Chyba ukládání · /save pro opakování": "Save failed · /save to retry",
    "LuxAI · katalog ověřit přes /model": "LuxAI · refresh catalog with /model",
    "Dostupnost určuje API": "Availability depends on the API",
    "Připojení je přerušené. Automaticky počkám a zkusím požadavek znovu. Esc / Ctrl+C čekání přeruší.": "Connection lost. Waiting and retrying automatically. Press Esc / Ctrl+C to stop waiting.",
    "Čekám na připojení · pokus ": "Waiting for connection · attempt ",
    " s · Esc přerušit": " s · Esc to interrupt",
    "přerušeno · výsledek neznámý": "interrupted · outcome unknown",
    "Úloha dokončena: ": "Job completed: ",
    "hotovo": "done",
    "❯ Vy": "❯ You",
    "✗ Chyba": "✗ Error",
    "Ctrl+←→ soubor · Ctrl+↑↓ diff": "Ctrl+←→ file · Ctrl+↑↓ diff",
    "Limit kontextu a metadata modelu": "Context usage and model capacity",
    "Vybrat model": "Choose model",
    "Export do Markdownu": "Export to Markdown",
    "Jazyk rozhraní": "Interface language",
    "Rozhraní je nyní česky.": "The interface is now in English.",
    "Použij /lang en nebo /lang cs.": "Use /lang en or /lang cs.",
    "Připraveno": "Ready",
    "Zastaveno": "Stopped",
    "Co dnes postavíme?\nNapiš úkol nebo / pro příkazy. Změny souborů uvidíš vpravo.": "What shall we build today?\nEnter a task or / for commands. File changes appear on the right.",
    "\nAplikace pokračuje. /retry zopakuje požadavek.": "\nThe application is still running. Use /retry to repeat the request.",
    "\nKonverzace zůstává v paměti. /save zkusí uložení znovu.": "\nThe conversation remains in memory. Use /save to try again.",
    "\n/retry zopakuje poslední požadavek; /model může změnit model.": "\nUse /retry to repeat the last request, or /model to change the model.",
    "/help — příkazy\n/lang [en|cs] — jazyk rozhraní\n/tools [filter] — katalog nástrojů\n/permissions [readonly|ask|full] — přístup k nástrojům\n/references [update] — referenční knihovna\n/context — skutečný limit kontextu\n/jobs — úlohy na pozadí\n/model [name] — interaktivní výběr modelu\n/reasoning [auto|none|low|medium|high|xhigh|max] — úroveň reasoningu\n/think — zobrazit / skrýt reasoning\n/rename název — přejmenovat sezení\n/new — nové sezení\n/sessions — interaktivní výběr sezení\n/resume [ID / hledání] — pokračovat v pojmenovaném sezení\n/save — uložit sezení\n/export path.md — export konverzace\n/paste [cesta|clear] — přiložit obrázek ze schránky nebo souboru\n/compact — shrnout kontext a archivovat původní\n/retry — pokračovat po chybě/přerušení\n/cd path — změnit pracovní adresář a načíst instrukce\n/diff [all] — změny sezení / celý workspace\n/undo — vrátit poslední editaci souboru\n/plan — zobrazit plán\n/clear — vyčistit obrazovku (historie zůstane)\n/quit — uložit a skončit\n\nEditor: šipky, Home/End, Ctrl+A/E/U, historie ↑↓, Alt+Enter nový řádek, vložení více řádků, Ctrl+V/Alt+V obrázek ze schránky (vložená/přetažená cesta k obrázku se přiloží, Backspace v prázdném řádku přílohu odebere), PgUp/PgDn. Ctrl+C/Esc přeruší API nebo běžící shell. Návrhy příkazů se ukazují při psaní /. F2 přepíná změny/plán; F3 rozbalí nástroje. Ctrl+←/→ vybírá soubor a Ctrl+↑/↓ posouvá diff.": "/help — commands\n/lang [en|cs] — interface language\n/tools [filter] — tool catalog\n/permissions [readonly|ask|full] — tool access\n/references [update] — reference library\n/context — conversation memory and model capacity\n/jobs — background jobs\n/model [name] — interactive model picker\n/reasoning [auto|none|low|medium|high|xhigh|max] — reasoning effort\n/think — show / hide reasoning\n/rename title — rename session\n/new — new session\n/sessions — interactive session picker\n/resume [ID / search] — resume a named session\n/save — save session\n/export path.md — export conversation\n/paste [path|clear] — attach an image from the clipboard or a file\n/compact — summarize context and archive the original\n/retry — continue after an error or interruption\n/cd path — change working directory and reload instructions\n/diff [all] — session changes / entire workspace\n/undo — undo last file edit\n/plan — show plan\n/clear — clear screen (history is retained)\n/quit — save and quit\n\nEditor: arrows, Home/End, Ctrl+A/E/U, history ↑↓, Alt+Enter new line, multiline paste, Ctrl+V/Alt+V image from the clipboard (a pasted or dropped image path is attached; Backspace on an empty line removes the attachment), PgUp/PgDn. Ctrl+C/Esc interrupts the API or running shell. Type / for command suggestions. F2 switches changes/plan; F3 expands tool details. Ctrl+←/→ selects a file; Ctrl+↑/↓ scrolls the diff.",
    "Žádost o jednorázové povolení: ": "One-time permission request: ",
    "Povolit ": "Allow ",
    "Zamítnout": "Deny",
    "Nástroj se nespustí.": "The tool will not run.",
    "Povolit jednou": "Allow once",
    "Spustit tuto konkrétní akci.": "Run this specific action.",
    " za ": " in ",
    "Přemýšlím · ": "Thinking · ",
    "Pracuji · kolo ": "Working · round ",
    "Zastaveno · požadavek selhal": "Stopped · request failed",
    "Hotovo · ": "Done · ",
    " kol": " rounds",
    "Nástroj · ": "Tool · ",
    "Zastaveno · historie uložena": "Stopped · history saved",
    "Shrnuji kontext · originál archivován lokálně": "Compacting context · original archived locally",
    "Kontext shrnut. Celá předchozí historie je archivována lokálně.": "Context compacted. Full preceding context archived locally.",
    "Uloženo ": "Saved ",
    "Exportováno ": "Exported ",
    "Nové sezení ": "New session ",
    "účet LuxAI": "LuxAI account",
    "API klíč": "API key",
    "API klíč chybí": "API key missing",
    "Přihlášení: ": "Auth: ",
    "Přihlášení k účtu LuxAI vypršelo nebo je neplatné. Spusťte `luxos-account login` a zkuste to znovu (/retry).": "Your LuxAI account session has expired or is invalid. Run `luxos-account login` and try again (/retry).",
    "Měsíční limit modelu Flash na účtu LuxAI je vyčerpán. Přepněte /model lite nebo počkejte na nový měsíc.": "The monthly Flash limit of your LuxAI account is used up. Switch with /model lite or wait for the next month.",
    "Měsíční limit modelu Lite na účtu LuxAI je vyčerpán.": "The monthly Lite limit of your LuxAI account is used up.",
    "LuxAI účet · měsíční limit Flash": "LuxAI account · monthly Flash limit",
    "LuxAI účet · měsíční limit Lite": "LuxAI account · monthly Lite limit",
    "Účtováno na účet LuxAI": "Charged to your LuxAI account",
    "Obrázek je příliš velký: ": "Image is too large: ",
    "Soubor neexistuje: ": "File does not exist: ",
    "Nepodporovaný formát obrázku (použij PNG, JPEG, WebP nebo GIF): ": "Unsupported image format (use PNG, JPEG, WebP or GIF): ",
    "Obrázek je větší než 4 MiB; pro automatické zmenšení nainstaluj imagemagick: ": "Image is larger than 4 MiB; install imagemagick for automatic downscaling: ",
    "obrázek přiložen": "image attached",
    "zmenšeno z ": "downscaled from ",
    " obrázky přiloženy": " images attached",
    "Schránka není dostupná: chybí grafické sezení (DISPLAY/WAYLAND_DISPLAY).": "Clipboard unavailable: no graphical session (DISPLAY/WAYLAND_DISPLAY).",
    "Pro vložení obrázku ze schránky nainstaluj xclip (X11) nebo wl-clipboard (Wayland).": "Install xclip (X11) or wl-clipboard (Wayland) to paste images from the clipboard.",
    "Schránka je prázdná.": "The clipboard is empty.",
    "Obrázek ze schránky se nepodařilo přečíst.": "Could not read the image from the clipboard.",
    "schránka": "clipboard",
    "Ve schránce není obrázek ani text.": "The clipboard contains neither an image nor text.",
    "Ve schránce není obrázek ani soubor s obrázkem.": "The clipboard contains no image or image file.",
    "Přiložit obrázek ze schránky / soubor / clear": "Attach an image from the clipboard / a file / clear",
    "  ·  Backspace odebere": "  ·  Backspace removes",
    "Příloha odebrána.": "Attachment removed.",
    "Přílohy odebrány.": "Attachments removed.",
    "\nObrázek se pošle s příští zprávou; /paste clear jej odebere.": "\nThe image will be sent with your next message; /paste clear removes it.",
    " nepřijímá obrázky. Přepni /model flash, nebo přílohu odeber (Backspace v prázdném řádku, /paste clear).": " does not accept images. Switch with /model flash, or remove the attachment (Backspace on an empty line, /paste clear).",
    "Podívej se na přiložený obrázek.": "Please look at the attached image."
}

function t(text):
    if state["language"] == "en":
        return translations.get(text, text)
    end
    for original in translations:
        if translations[original] == text:
            return original
        end
    end
    return text
end

function init():
    state["language"] = "en"
    try:
        filename = core.state["home"] + "/language.json"
        if exists(filename):
            language = json.decode(readfile(filename)).get("language", "en")
            if language in ["en", "cs"]:
                state["language"] = language
            end
        end
    else:
        call core.record_error("language.load", String(last_error()))
    end
end

function set(language):
    if language == "cz":
        language = "cs"
    end
    if language not in ["en", "cs"]:
        Error(CommandError: t("Použij /lang en nebo /lang cs."))
    end
    call core.atomic(core.state["home"] + "/language.json", json.encode({"language": language}))
    state["language"] = language
end

function choices():
    return [{"value": "en", "label": "English", "detail": "English"}, {"value": "cs", "label": "Čeština", "detail": "Czech"}]
end
