load i18n
load text_codec as codec
load aikit as ai
load common as core
load settings as env
load auth
load json
load jobs
load screen as ui
load time

worker_state = {"base": ""}

function event(kind, text):
    appendfile(worker_state["base"] + ".events", json.encode({"kind": kind, "text": codec.repair(text)}) + "\n")
end

function receive(text):
    call event("text", text)
end

function reasoning(text):
    call event("reasoning", text)
end

# Tentýž LSL executable běží jako izolovaný síťový worker. Klíč čte z env/.env
# a session účtu LuxAI z account.json; neukládají se do request souboru ani do
# argumentů procesu.
function run(filename):
    request = json.decode(readfile(filename))
    base = request["base"]
    worker_state["base"] = base
    options = request["options"]
    options["on_reasoning"] = reasoning
    try:
        access = auth.credentials(request["endpoint"])
        if len(access["headers"]) > 0:
            options["headers"] = access["headers"]
        end
        result = ai.stream(request["endpoint"], access["token"], request["model"], request["messages"], options, receive)
        response = {"ok": True, "result": result}
    else:
        response = {"ok": False, "error": String(last_error())}
    end
    call core.atomic(base + ".result", json.encode(codec.safe(response)))
end

function stream_once(endpoint, model, messages, options, on_text, on_reasoning):
    base = core.state["home"] + "/jobs/model-" + core.checked("date +%s%N").strip()
    request = {"base": base, "endpoint": endpoint, "model": model, "messages": messages, "options": options}
    call core.atomic(base + ".request", json.encode(codec.safe(request)))
    writefile(base + ".events", "")
    job = jobs.start(core.quote(executable_path()) + " --worker " + core.quote(base + ".request"), "model request")
    offset = 0
    buffered = ""
    loop:
        if ui.cancel():
            call jobs.stop(job)
            call core.cli(["rm", "-f", "--", base + ".request"])
            Error(AICancelled: "Stopped by user")
        end
        content = readfile(base + ".events")
        buffered += content[offset:len(content)]
        offset = len(content)
        lines = buffered.split("\n")
        buffered = lines[len(lines) - 1]
        for i in rang(len(lines) - 1):
            entry = json.decode(lines[i])
            if entry["kind"] == "text":
                call on_text(entry["text"])
            else:
                call on_reasoning(entry["text"])
            end
        end
        if exists(base + ".result"):
            # Další iterace přečte i poslední event zapsaný těsně před result.
            latest = readfile(base + ".events")
            if len(latest) > offset:
                continue
            end
            result = json.decode(readfile(base + ".result"))
            call core.cli(["rm", "-f", "--", base + ".request"])
            if not result["ok"]:
                Error(AIProviderError: result["error"])
            end
            return result["result"]
        end
        if not jobs.status(job)["running"]:
            if exists(base + ".result"):
                continue
            end
            log = core.checked("tail -c 3000 -- " + core.quote(job["base"] + ".log"))
            call core.cli(["rm", "-f", "--", base + ".request"])
            Error(AIProviderError: "Model worker exited without a result: " + log)
        end
        call time.sleep(0.04)
    end
end

function transient(failure):
    text = failure.lower()
    if "aicancelled" in text or "jsonerror" in text or "callbackerror" in text:
        return False
    end
    for marker in ["ssl certificate problem", "certificate verify failed", "unsupported protocol", "url rejected", "curl: (3)", "curl: (60)", "curl: (77)"]:
        if marker in text:
            return False
        end
    end
    # HTTP stav má přednost před textem těla odpovědi.
    if "http " in text:
        for status in [0, 408, 429, 500, 502, 503, 504, 520, 521, 522, 523, 524]:
            if "http " + String(status) + ":" in text:
                return True
            end
        end
        return False
    end
    for marker in ["could not resolve", "couldn't resolve", "could not connect", "couldn't connect", "failed to connect", "connection refused", "connection reset", "network is unreachable", "network unreachable", "temporary failure", "name resolution", "dns", "eai_again", "timed out", "timeout", "broken pipe", "recv failure", "empty reply", "stream ended before [done]", "unexpected eof", "curl error 6", "curl error 7", "curl error 28", "curl error 56"]:
        if marker in text:
            return True
        end
    end
    return False
end

function stream(endpoint, model, messages, options, on_text, on_reasoning, on_restart=None):
    attempt = 0
    loop:
        checkpoint = len(ui.entries)
        try:
            result = stream_once(endpoint, model, messages, options, on_text, on_reasoning)
            return result
        else:
            failure = String(last_error())
            if auth.is_account():
                # 401/403 a vycerpany limit uctu nejsou prechodne chyby site.
                message = auth.account_failure(failure)
                if message != None:
                    Error(AIAuthError: message)
                end
            end
            if core.state["cancelled"] or not transient(failure) or env.get("LUX_CODE_RECONNECT", "1") == "0":
                Error(AIProviderError: failure)
            end
            call core.record_error("network.retry", failure)
            # Z nedokončeného streamu se nikdy nespustí tool call. Při opakování
            # zahodíme i částečný text a reasoning, aby se obsah nezdvojoval.
            while len(ui.entries) > checkpoint:
                call ui.entries.pop()
            end
            ui.view["stream"] = ""
            if on_restart != None:
                call on_restart()
            end
            attempt += 1
            if attempt == 1:
                call ui.add("system", i18n.t("Připojení je přerušené. Automaticky počkám a zkusím požadavek znovu. Esc / Ctrl+C čekání přeruší."))
            end
            delay = min(30, attempt * 2)
            deadline = time.monotonic() + Float(delay)
            while time.monotonic() < deadline:
                remaining = max(1, Int(deadline - time.monotonic()) + 1)
                ui.view["status"] = i18n.t("Čekám na připojení · pokus ") + String(attempt + 1) + i18n.t(" za ") + String(remaining) + i18n.t(" s · Esc přerušit")
                if ui.cancel():
                    Error(AICancelled: "Stopped while waiting for connection")
                end
                call time.sleep(0.1)
            end
        end
    end
end
