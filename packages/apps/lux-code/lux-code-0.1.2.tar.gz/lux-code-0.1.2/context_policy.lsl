load common as core

version = "cwd-only-v2"

function legacy_tasks(messages):
    clean = [{"role": "system", "content": "Current workspace instructions will be rebuilt before the next model request."}]
    for message in messages:
        content = message.get("content", None)
        if message.get("role", "") == "user" and type(content) == "String":
            if not content.startswith("Previous session context:"):
                clean.append({"role": "user", "content": content})
            end
        end
    end
    return clean
end

function refresh(messages, prompt):
    # Jediný systémový prompt se sestaví znovu před KAŽDÝM požadavkem.
    # Historické system/developer zprávy se už nikdy nepřehrají jako instrukce.
    active = [{"role": "system", "content": prompt}]
    for message in messages:
        if message.get("role", "") not in ["system", "developer"]:
            active.append(message)
        end
    end
    messages.clear()
    for message in active:
        messages.append(message)
    end
    core.state["instruction_policy"] = version
end
