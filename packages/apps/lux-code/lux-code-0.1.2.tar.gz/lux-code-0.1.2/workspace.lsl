load time
load common as core
load json

changes = []

function snapshot(filename):
    present = exists(filename)
    before = ""
    if present:
        before = readfile(filename)
    end
    mode = ""
    if present:
        mode = core.checked("stat -c %a -- " + core.quote(filename)).strip()
    end
    change = {"order": time.time(), "path": filename, "existed": present, "before": before, "after": "", "after_exists": True, "mode": mode}
    changes.append(change)
    return change
end

function write(filename, content):
    filename = core.checked("readlink -m -- " + core.quote(filename)).strip()
    change = snapshot(filename)
    try:
        call core.atomic(filename, content)
    else:
        failure = String(last_error())
        call changes.pop()
        Error(ToolError: failure)
    end
    change["after"] = content
    return {"ok": True, "path": filename, "characters": len(content), "undo": len(changes)}
end

function undo():
    if len(changes) == 0:
        Error(ToolError: "No file edits to undo in this session.")
    end
    change = changes[len(changes) - 1]
    current = ""
    if exists(change["path"]):
        current = readfile(change["path"])
    end
    if current != change["after"] or exists(change["path"]) != change.get("after_exists", True):
        Error(ToolError: "File changed since this edit; refusing to overwrite newer changes.")
    end
    if change["existed"]:
        call core.atomic(change["path"], change["before"])
        if change.get("mode", "") != "":
            call core.checked("chmod " + change["mode"] + " -- " + core.quote(change["path"]))
        end
    else:
        call core.checked("rm -- " + core.quote(change["path"]))
    end
    call changes.pop()
    return {"ok": True, "path": change["path"]}
end

function execute(name, args):
    filename = core.path(args.get("path", "."))
    if name == "read_file":
        content = readfile(filename)
        lines = content.split("\n")
        start = max(1, core.number(args, "start_line", 1))
        count = max(1, core.number(args, "line_count", 200))
        output = []
        for i in rang(start - 1, min(len(lines), start - 1 + count)):
            output.append(String(i + 1) + "  " + lines[i])
        end
        return {"path": filename, "total_lines": len(lines), "content": "\n".join(output)}
    elif name == "write_file":
        return write(filename, args["content"])
    elif name == "append_file":
        before = ""
        if exists(filename):
            before = readfile(filename)
        end
        return write(filename, before + args["content"])
    elif name == "edit_file":
        before = readfile(filename)
        old = core.text(args, "old_text")
        new = args["new_text"]
        occurrences = len(before.split(old)) - 1
        if occurrences == 0 or occurrences > 1 and not args.get("replace_all", False):
            Error(ToolError: "Expected unique old_text; found " + String(occurrences) + ". Supply more context or replace_all=true.")
        end
        return write(filename, before.replace(old, new))
    elif name == "insert_lines" or name == "delete_lines":
        lines = readfile(filename).split("\n")
        start = core.number(args, "line", 1)
        if start < 1 or start > len(lines) + 1:
            Error(ToolError: "line outside file")
        end
        finish = start - 1
        middle = []
        if name == "insert_lines":
            middle = args["content"].split("\n")
        else:
            finish += max(1, core.number(args, "count", 1))
        end
        merged = lines[0:start - 1] + middle + lines[finish:len(lines)]
        return write(filename, "\n".join(merged))
    elif name == "apply_diff":
        patch = args["patch"]
        artifact = core.state["home"] + "/artifacts/patch-" + core.checked("date +%s%N").strip() + ".diff"
        writefile(artifact, patch)
        checked = core.cli(["git", "apply", "--check", "--", artifact])
        if not checked["ok"]:
            return checked
        end
        names = {}
        for line in patch.split("\n"):
            if line.startswith("+++ b/") or line.startswith("--- a/"):
                target = core.path(line[6:len(line)].split("\t")[0])
                names[target] = True
            end
        end
        if len(names) == 0:
            Error(ToolError: "Expected textual unified diff with a/ and b/ paths")
        end
        previous = len(changes)
        for target in names:
            call snapshot(target)
        end
        result = core.cli(["git", "apply", "--", artifact])
        if not result["ok"]:
            while len(changes) > previous:
                call changes.pop()
            end
            return result
        end
        for i in rang(previous, len(changes)):
            change = changes[i]
            change["after_exists"] = exists(change["path"])
            if change["after_exists"]:
                change["after"] = readfile(change["path"])
            end
        end
        return {"ok": True, "files": len(names), "patch": artifact}
    elif name == "undo_edit":
        return undo()
    elif name == "file_info":
        return core.cli(["stat", "--", filename])
    elif name == "list_directory":
        return core.cli(["ls", "-lah", "--", filename])
    elif name == "list_files":
        return core.cli(["rg", "--files", "--hidden", "-g", "!.git", "-g", "!node_modules", "--", filename])
    elif name == "find_files":
        return core.cli(["rg", "--files", "--hidden", "-g", args["pattern"], "-g", "!.git", "--", filename])
    elif name == "search_text":
        return core.cli(["rg", "-n", "--hidden", "--max-count", String(core.number(args, "max_matches", 100)), "-g", "!.git", "-g", "!node_modules", "--", args["pattern"], filename])
    elif name == "directory_tree":
        return core.cli(["find", filename, "-maxdepth", String(core.number(args, "depth", 3)), "-not", "-path", "*/.git/*", "-not", "-path", "*/node_modules/*"])
    elif name == "make_directory":
        return core.cli(["mkdir", "-p", "--", filename])
    elif name == "copy_file":
        return core.cli(["cp", "-n", "--", filename, core.path(args["destination"])])
    elif name == "move_file":
        return core.cli(["mv", "-n", "--", filename, core.path(args["destination"])])
    elif name == "delete_file":
        link = core.cli(["test", "-L", filename])
        if link["ok"]:
            Error(ToolError: "delete_file undo supports regular files only; handle symbolic links explicitly through bash.")
        end
        if not exists(filename):
            Error(ToolError: "File does not exist")
        end
        change = snapshot(filename)
        change["after_exists"] = False
        result = core.cli(["rm", "--", filename])
        if not result["ok"]:
            call changes.pop()
        end
        return result
    elif name == "file_hash":
        return core.cli(["sha256sum", "--", filename])
    elif name == "compare_files":
        return core.cli(["diff", "-u", "--", filename, core.path(args["other"])])
    elif name == "read_json":
        return json.decode(readfile(filename))
    elif name == "write_json":
        return write(filename, json.pretty(args["value"]) + "\n")
    elif name == "working_directory":
        return {"cwd": core.state["cwd"]}
    elif name == "change_directory":
        directory = core.checked("cd " + core.quote(filename) + " && pwd -P").strip()
        core.state["cwd"] = directory
        return {"cwd": directory}
    end
    Error(ToolError: "Unknown workspace tool: " + name)
end
