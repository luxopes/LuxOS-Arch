load i18n
load tui
load fd
load time
load os
load json
load common as core
load rich
load review
load theme
load logo
load activity

term = tui.Terminal()
esc = chr(27)
view = {"active": False, "plain": False, "input": "", "cursor": 0, "scroll": 0, "status": i18n.t("Připraveno"), "model": "flash", "reasoning": "low", "tools": 0, "calls": 0, "show_reasoning": False, "stream": "", "stream_kind": "assistant", "last_paint": 0.0, "palette": False, "context": 0, "title": i18n.t("Nové sezení"), "details": False, "menu_index": 0, "menu_query": "", "menu_hidden": "", "modal": None}
entries = []
input_history = []
tasks = []
model_items = []
session_items = []
queue = []
commands = [
    {"value": "/lang", "label": "/lang", "detail": i18n.t("Jazyk rozhraní"), "arguments": True},
    {"value": "/jobs", "label": "/jobs", "detail": i18n.t("Běžící shelly, služby a monitoring")},
    {"value": "/context", "label": "/context", "detail": i18n.t("Limit kontextu a metadata modelu")},
    {"value": "/references", "label": "/references", "detail": i18n.t("Referenční knihovna / update"), "arguments": True},
    {"value": "/permissions", "label": "/permissions", "detail": i18n.t("Oprávnění nástrojů: readonly / ask / full"), "arguments": True},
    {"value": "/model", "label": "/model", "detail": i18n.t("Vybrat model"), "arguments": True},
    {"value": "/resume", "label": "/resume", "detail": i18n.t("Pokračovat v pojmenovaném sezení"), "arguments": True},
    {"value": "/reasoning", "label": "/reasoning", "detail": i18n.t("Úroveň přemýšlení"), "arguments": True},
    {"value": "/diff", "label": "/diff", "detail": i18n.t("Prohlédnout změněné soubory")},
    {"value": "/tools", "label": "/tools", "detail": i18n.t("Katalog nástrojů"), "arguments": True},
    {"value": "/think", "label": "/think", "detail": i18n.t("Zobrazit / skrýt reasoning")},
    {"value": "/sessions", "label": "/sessions", "detail": i18n.t("Vybrat uložené sezení")},
    {"value": "/new", "label": "/new", "detail": i18n.t("Začít nové sezení")},
    {"value": "/rename", "label": "/rename", "detail": i18n.t("Přejmenovat sezení"), "arguments": True},
    {"value": "/save", "label": "/save", "detail": i18n.t("Uložit sezení")},
    {"value": "/undo", "label": "/undo", "detail": i18n.t("Vrátit poslední editaci")},
    {"value": "/plan", "label": "/plan", "detail": i18n.t("Zobrazit plán")},
    {"value": "/cd", "label": "/cd", "detail": i18n.t("Změnit pracovní složku"), "arguments": True},
    {"value": "/compact", "label": "/compact", "detail": i18n.t("Shrnout dlouhý kontext")},
    {"value": "/retry", "label": "/retry", "detail": i18n.t("Pokračovat po přerušení")},
    {"value": "/export", "label": "/export", "detail": i18n.t("Export do Markdownu"), "arguments": True},
    {"value": "/clear", "label": "/clear", "detail": i18n.t("Vyčistit obrazovku")},
    {"value": "/help", "label": "/help", "detail": i18n.t("Nápověda a klávesové zkratky")},
    {"value": "/quit", "label": "/quit", "detail": i18n.t("Uložit a ukončit")}
]

function add(kind, text):
    entries.append({"kind": kind, "text": core.clean(text)})
    if view["plain"] and kind != "assistant" and (kind != "reasoning" or view["show_reasoning"]):
        printl "[{kind}] {text}"
    end
end

function wrap(text, width):
    lines = []
    for row in rich.render(text, width):
        lines.append(row["plain"])
    end
    return lines
end

function summary(name, arguments):
    try:
        args = json.decode(arguments)
        if name == "call_tool":
            return summary(args.get("tool_name", name), args.get("arguments", "{}"))
        end
        for field in ["path", "command", "pattern", "selector", "url", "query", "question", "title", "id"]:
            value = args.get(field, "")
            if type(value) == "String" and value != "":
                return core.clean(value).replace("\n", " ↵ ")[0:110]
            end
        end
    else:
        return ""
    end
    return ""
end

function tool_start(name, arguments):
    label = name.replace("_", " ")
    labels = {"read_file": "Read", "edit_file": "Update", "write_file": "Write", "append_file": "Append", "apply_diff": "Patch", "bash": "Bash", "run_tests": "Test", "search_text": "Search", "list_files": "Files"}
    if name == "call_tool":
        try:
            data = json.decode(arguments)
            label = data.get("tool_name", name).replace("_", " ")
        else:
            label = name
        end
    elif name in labels:
        label = labels[name]
    end
    card = {"kind": "tool", "text": "", "name": name, "label": label, "summary": summary(name, arguments), "arguments": arguments, "result": "", "state": "running", "note": "", "started": time.monotonic(), "elapsed": 0.0}
    entries.append(card)
    return card
end

function tool_finish(card, result, announce=True):
    card["result"] = result
    card["elapsed"] = max(0.0, time.monotonic() - card["started"])
    card["state"] = "success"
    note = i18n.t("hotovo")
    try:
        data = json.decode(result)
        if type(data) == "Dictionary":
            if not data.get("ok", True) or data.get("cancelled", False):
                card["state"] = "error"
                note = String(data.get("error", "exit " + String(data.get("status", "?"))))
                if data.get("cancelled", False):
                    note = i18n.t("přerušeno")
                end
            elif "total_lines" in data:
                note = String(len(data["content"].split("\n"))) + i18n.t(" řádků / ") + String(data["total_lines"])
            elif "characters" in data:
                note = String(data["characters"]) + i18n.t(" znaků")
            elif "stdout" in data:
                output = data["stdout"].strip()
                count = 0
                if output != "":
                    count = len(output.split("\n"))
                end
                note = String(count) + i18n.t(" řádků")
            elif "tools" in data:
                note = String(len(data["tools"])) + i18n.t(" nástrojů")
            elif data.get("truncated", False):
                note = i18n.t("výstup v artefaktu")
            end
            if data.get("status", 0) == 1 and card["name"] in ["search_text", "compare_files"]:
                card["state"] = "success"
                note = i18n.t("žádné shody")
                if card["name"] == "compare_files":
                    note = i18n.t("nalezeny rozdíly")
                end
            end
        elif type(data) == "List":
            note = String(len(data)) + i18n.t(" položek")
        end
    else:
        card["state"] = "error"
        note = i18n.t("neplatná odpověď nástroje")
    end
    card["note"] = core.clean(note).replace("\n", " ")[0:140]
    card["text"] = card["label"] + " " + card["summary"] + " · " + card["note"]
    if announce and view["plain"]:
        mark = "✓"
        if card["state"] == "error":
            mark = "✗"
        end
        printl "{mark} {card[\"label\"]} {card[\"summary\"]} · {card[\"note\"]}"
    end
end

function import_entries(saved):
    entries.clear()
    previous = None
    for entry in saved:
        kind = entry.get("kind", "system")
        if kind == "tool" and "label" not in entry:
            parts = entry.get("text", "").split("\n")
            previous = tool_start(parts[0], "\n".join(parts[1:len(parts)]))
            previous["state"] = "success"
        elif kind == "result" and previous != None:
            call tool_finish(previous, entry.get("text", "{}"), False)
            previous = None
        else:
            entries.append(entry)
            previous = None
        end
    end
end

function matches(item, query):
    haystack = (item["label"] + " " + item.get("detail", "") + " " + item.get("hint", "") + " " + item["value"]).lower()
    for word in query.lower().split(" "):
        if word != "" and word not in haystack:
            return False
        end
    end
    return True
end

function filtered(items, query):
    first = []
    rest = []
    prefix = query.lower()
    for item in items:
        if matches(item, query):
            if item["label"].lower().startswith(prefix) or item["value"].lower().startswith(prefix):
                first.append(item)
            else:
                rest.append(item)
            end
        end
    end
    return first + rest
end

function suggestions(value):
    if not value.startswith("/") or "\n" in value or value == view["menu_hidden"]:
        return []
    end
    split = value.split(" ")
    name = split[0]
    if len(split) == 1:
        found = []
        for item in commands:
            if item["value"].startswith(name):
                found.append(item)
            end
        end
        return found
    end
    query = " ".join(split[1:len(split)])
    source = []
    if name == "/model":
        source = model_items
    elif name == "/resume" or name == "/sessions":
        source = session_items
    elif name == "/lang":
        source = i18n.choices()
    elif name == "/permissions":
        for mode in ["readonly", "ask", "full"]:
            source.append({"value": mode, "label": mode, "detail": i18n.t("Oprávnění nástrojů")})
        end
    elif name == "/reasoning":
        for effort in ["auto", "none", "low", "medium", "high", "xhigh", "max"]:
            source.append({"value": effort, "label": effort, "detail": "Reasoning"})
        end
    end
    found = []
    for item in filtered(source, query):
        found.append({"value": name + " " + item["value"], "label": item["label"], "detail": item.get("detail", ""), "hint": item.get("hint", "")})
    end
    return found
end

function row(y, x, text, width, style="38;5;252"):
    if y < 1 or y > term.rows or width < 1:
        return
    end
    call term.move(y, x)
    text = core.clean(text).replace("\n", " ").replace("\t", " ")
    call term.emit(theme.ansi(style) + rich.fit(text, width))
end

function rich_row(y, x, line, width):
    call term.move(y, x)
    used = 0
    for span in line["spans"]:
        call term.emit(theme.ansi(span["style"]) + span["text"])
        used += rich.width(span["text"])
    end
    call term.emit(theme.ansi("") + rich.fit("", max(0, width - used)))
end

function line(text, style):
    return {"spans": [{"text": text, "style": style}], "plain": text}
end

function transcript(width):
    lines = []
    for entry in entries:
        kind = entry.get("kind", "system")
        text = entry.get("text", "")
        if kind == "welcome":
            continue
        elif kind == "reasoning" and not view["show_reasoning"]:
            continue
        elif kind == "tool" and "label" in entry:
            style = "38;5;150"
            mark = "✓"
            if entry["state"] == "running":
                style = "38;5;179"
                mark = "◌"
            elif entry["state"] == "error":
                style = "38;5;203"
                mark = "✗"
            end
            heading = entry["label"] + "(" + entry["summary"] + ")"
            heading = rich.fit(heading, max(1, width - 2))
            lines.append({"spans": [{"text": "● ", "style": style}, {"text": heading, "style": "1;38;5;252"}], "plain": "● " + heading})
            if entry.get("note", "") != "":
                lines.append(line(rich.fit("  └ " + entry["note"], width), "38;5;245"))
            end
            if not view["details"]:
                for preview in entry.get("preview", []):
                    lines.append(line(rich.fit("    " + preview["text"], width), preview["style"]))
                end
            end
            if view["details"]:
                detail = "arguments: " + entry.get("arguments", "") + "\nresult: " + entry.get("result", "")
                for item in rich.wrapped([{"text": detail.replace("\n", " ")[0:5000], "style": "38;5;248"}], width - 2):
                    lines.append(item)
                end
            end
            continue
        elif kind == "result" and not view["details"]:
            continue
        end
        if kind == "assistant":
            lines.append(line("● Lux", "1;38;5;75"))
        elif kind == "user":
            lines.append(line(i18n.t("❯ Vy"), "1;38;5;117"))
        elif kind == "reasoning":
            lines.append(line(i18n.t("◌ Přemýšlení"), "38;5;103"))
        elif kind == "error":
            lines.append(line(i18n.t("✗ Chyba"), "38;5;203"))
        else:
            lines.append(line("· " + kind, "38;5;245"))
        end
        if kind == "user":
            for raw in text.split("\n"):
                for item in rich.wrapped([{"text": raw, "style": "38;5;252"}], width):
                    lines.append(item)
                end
            end
        else:
            for item in rich.render(text, width):
                lines.append(item)
            end
        end
        lines.append(line("", "0"))
    end
    if view["stream"] != "" and (view["stream_kind"] != "reasoning" or view["show_reasoning"]):
        lines.append(line("● Lux  · streaming", "38;5;75"))
        for item in rich.render(view["stream"], width):
            lines.append(item)
        end
    end
    return lines
end

function side(x, width, bottom):
    for y in rang(4, bottom + 1):
        call row(y, x, "│", width, "38;5;237")
    end
    left = x + 2
    width -= 3
    if review.state["tab"] == "plan" or len(review.items) == 0:
        call row(4, left, i18n.t("PLÁN"), width, "1;38;5;179")
        y = 6
        for task in tasks:
            if y > bottom - 5:
                break
            end
            mark = "○ "
            style = "38;5;245"
            if task.get("done", False):
                mark = "✓ "
                style = "38;5;150"
            end
            for part in rich.wrapped([{"text": mark + task["text"], "style": style}], width):
                if y <= bottom - 5:
                    call rich_row(y, left, part, width)
                    y += 1
                end
            end
        end
        if len(tasks) == 0:
            call row(6, left, i18n.t("Zatím žádný plán."), width, "38;5;250")
        end
        call row(bottom - 3, left, String(len(review.items)) + i18n.t(" změněných souborů"), width, "38;5;245")
        call row(bottom - 1, left, i18n.t("F2 změny / plán"), width, "38;5;250")
        return
    end
    total_added = 0
    total_removed = 0
    for item in review.items:
        total_added += item["added"]
        total_removed += item["removed"]
    end
    call row(4, left, i18n.t("ZMĚNY · ") + review.state["scope"] + "  " + String(len(review.items)), width, "1;38;5;75")
    call rich_row(5, left, {"spans": [{"text": "+" + String(total_added) + " ", "style": "38;5;150"}, {"text": "−" + String(total_removed), "style": "38;5;203"}]}, width)
    first = max(0, review.state["selected"] - 2)
    y = 7
    for i in rang(first, min(len(review.items), first + 4)):
        item = review.items[i]
        style = "38;5;245"
        mark = "  "
        if i == review.state["selected"]:
            style = "1;38;5;255;48;5;237"
            mark = "› "
        end
        call row(y, left, mark + item["name"] + "  +" + String(item["added"]) + " −" + String(item["removed"]), width, style)
        y += 1
    end
    y += 1
    item = review.items[review.state["selected"]]
    call row(y, left, "─ " + item["name"], width, "38;5;248")
    y += 1
    patch = review.numbered(item["diff"])
    offset = min(review.state["offset"], max(0, len(patch) - 3))
    for i in rang(offset, len(patch)):
        if y >= bottom - 1:
            break
        end
        raw = patch[i]
        if raw.startswith("---") or raw.startswith("+++"):
            continue
        end
        style = "38;5;245"
        if review.diff_kind(raw) == "+":
            style = "38;5;150;48;5;22"
        elif review.diff_kind(raw) == "-":
            style = "38;5;203;48;5;52"
        elif raw.startswith("@@"):
            style = "38;5;110"
        end
        call row(y, left, raw, width, style)
        y += 1
    end
    call row(bottom, left, i18n.t("Ctrl+←→ soubor · Ctrl+↑↓ diff"), width, "38;5;250")
end

function menu(items, selected, title, x, bottom, width, maximum=6):
    count = min(maximum, len(items))
    start = max(0, selected - count + 1)
    top = bottom - count - 1
    call row(top, x, " " + title, width, "1;38;5;75;48;5;235")
    for offset in rang(count):
        index = start + offset
        item = items[index]
        style = "38;5;245;48;5;235"
        marker = "  "
        if index == selected:
            style = "1;38;5;255;48;5;238"
            marker = "› "
        end
        label_width = min(28, max(12, Int(width / 3)))
        text = marker + rich.fit(item["label"], label_width) + "  " + item.get("detail", "")
        call row(top + offset + 1, x, text, width, style)
    end
    call row(bottom, x, i18n.t(" ↑↓ výběr · Enter potvrdit · Tab doplnit · Esc zavřít"), width, "38;5;250;48;5;235")
end

function paint(force=False):
    if not view["active"]:
        return
    end
    now = time.monotonic()
    if not force and now - view["last_paint"] < 0.05:
        return
    end
    view["last_paint"] = now
    rows = term.rows
    cols = term.cols
    sidebar = 0
    welcome = True
    for entry in entries:
        if entry.get("kind", "system") != "welcome":
            welcome = False
        end
    end
    if cols >= 108 and not welcome:
        sidebar = max(36, min(64, Int(cols * 0.38)))
    end
    left_width = cols - sidebar
    content_width = max(10, left_width - 5)
    bottom = rows - 7
    height = max(1, bottom - 3)
    call term.emit(esc + "[?25l")
    call row(1, 1, "  LUX CODE  /  " + view["title"], cols, "1;38;5;75")
    call row(2, 1, "  " + core.state["cwd"], cols, "38;5;248")
    call row(3, 1, "  " + view["model"] + "  ·  " + view["reasoning"] + "  ·  " + view.get("auth", "") + "  ·  " + String(view["tools"]) + " tools  ·  permissions: " + core.state.get("permissions_mode", "full"), cols, "38;5;75")
    lines = transcript(content_width)
    if welcome:
        lines = []
    end
    view["scroll"] = min(view["scroll"], max(0, len(lines) - height))
    start = max(0, len(lines) - height - view["scroll"])
    for offset in rang(height):
        call row(4 + offset, 1, "", left_width)
        index = start + offset
        if index < len(lines):
            call rich_row(4 + offset, 3, lines[index], content_width)
        end
    end
    if welcome:
        artwork = logo.rows(height)
        art_width = rich.width(artwork[0]["plain"])
        art_x = max(1, Int((cols - art_width) / 2) + 1)
        art_y = max(4, 4 + Int((height - len(artwork) - 3) / 2))
        for i in rang(len(artwork)):
            if art_y + i <= bottom - 2:
                call rich_row(art_y + i, art_x, artwork[i], art_width)
            end
        end
        call row(min(bottom - 1, art_y + len(artwork)), max(1, Int((cols - 9) / 2) + 1), "L U X A I", 9, "1;38;5;81")
        call row(bottom, max(1, Int((cols - 40) / 2)), i18n.t("Napiš zadání  ·  /model  ·  /resume"), min(40, cols), "38;5;110")
    end
    if sidebar > 0:
        call side(left_width + 1, sidebar, bottom)
    end
    indicator = "●"
    if view["status"].startswith(i18n.t("Pracuji · kolo ")) or view["status"].startswith(i18n.t("Přemýšlím · ")) or view["status"].startswith("Running"):
        spinner = ["◐", "◓", "◑", "◒"]
        indicator = spinner[Int(now * 8) % 4]
    end
    call row(rows - 6, 1, "  " + indicator + " " + view["status"] + "   ·   ~" + String(view.get("context_tokens", Int(view["context"] / 4))) + " tokens", cols, "38;5;248")
    call row(rows - 5, 1, "  " + divider(max(0, cols - 4)) + "  ", cols, "38;5;240")
    input_width = max(10, cols - 6)
    # Editor ponechává skutečné nové řádky; zalomení zohledňuje pozici kurzoru.
    input_lines = []
    for raw in view["input"].replace("\t", "    ").split("\n"):
        for item in rich.wrapped([{"text": raw, "style": "38;5;255"}], input_width):
            input_lines.append(item)
        end
    end
    prefix = view["input"][0:view["cursor"]].replace("\t", "    ")
    cursor_lines = []
    for raw in prefix.split("\n"):
        for item in rich.wrapped([{"text": raw, "style": "0"}], input_width):
            cursor_lines.append(item)
        end
    end
    editor_start = max(0, len(cursor_lines) - 3)
    for i in rang(3):
        call row(rows - 4 + i, 1, "", cols)
        if editor_start + i < len(input_lines):
            marker = "  "
            if i == 0:
                marker = "❯ "
            end
            call row(rows - 4 + i, 2, marker, 2, "38;5;75")
            call rich_row(rows - 4 + i, 5, input_lines[editor_start + i], input_width)
        end
    end
    call row(rows - 1, 1, i18n.t("  Enter odeslat · Alt+Enter nový řádek · / příkazy · F2 změny/plán · F3 detaily"), cols, "38;5;250")
    call row(rows, 1, "  " + job_badges() + "  ·  " + String(len(queue)) + i18n.t(" zadání ve frontě  ·  PgUp/PgDn historie  ·  Ctrl+C přerušit"), cols, "38;5;250")
    if view["modal"] == None:
        choices = suggestions(view["input"])
        if len(choices) > 0:
            selected = min(view["menu_index"], len(choices) - 1)
            call menu(choices, selected, i18n.t("Příkazy"), 3, rows - 7, max(20, left_width - 5))
        end
    else:
        modal = view["modal"]
        choices = modal["items"]
        width = min(90, cols - 6)
        x = max(2, Int((cols - width) / 2))
        count = min(max(1, rows - 12), 8)
        bottom = min(rows - 7, 8 + count * 2)
        top = max(4, bottom - count * 2 - 4)
        for y in rang(top, bottom + 1):
            call row(y, x, "", width, "48;5;235")
        end
        call row(top, x, " " + modal["title"], width, "1;38;5;255;48;5;235")
        call row(top + 1, x, " / " + modal["query"] + "▏", width, "38;5;75;48;5;235")
        first = max(0, modal["selected"] - count + 1)
        y = top + 3
        for i in rang(first, min(len(choices), first + count)):
            item = choices[i]
            mark = "  "
            style = "38;5;252;48;5;235"
            if i == modal["selected"]:
                mark = "› "
                style = "1;38;5;255;48;5;238"
            end
            label_width = min(46, max(16, Int(width * 0.55)))
            call row(y, x, mark + rich.fit(item["label"], label_width) + "  " + item.get("detail", ""), width, style)
            call row(y + 1, x, "  " + item.get("hint", item["value"]), width, "38;5;248;48;5;235")
            y += 2
        end
        if len(choices) == 0:
            call row(top + 3, x, i18n.t("  Žádné shody. Změň filtr nebo stiskni Esc."), width, "38;5;248;48;5;235")
        end
        call row(bottom, x, i18n.t(" ↑↓ výběr  ·  Enter potvrdit  ·  Esc zpět"), width, "38;5;248;48;5;235")
    end
    cy = rows - 4 + min(2, max(0, len(cursor_lines) - editor_start - 1))
    cx = 5
    if len(cursor_lines) > 0:
        cx += rich.width(cursor_lines[len(cursor_lines) - 1]["plain"])
    end
    call term.move(min(rows - 2, cy), min(cols, cx))
    if view["modal"] == None:
        call term.emit(esc + "[?25h")
    end
    call term.flush()
end
function available():
    if not view["active"]:
        return 0
    end
    count = ByteArray()
    for i in rang(4):
        count.append(0)
    end
    call fd.ioctl(0, 21531, count)
    return count[0] + 256 * count[1] + 65536 * count[2]
end

function byte():
    buffer = ByteArray()
    buffer.append(0)
    count = fd.read(0, buffer, 1)
    if count <= 0:
        return -1
    end
    return buffer[0]
end

function key():
    first = byte()
    if first < 0:
        return "eof"
    elif first == 27:
        call time.sleep(0.01)
        if available() == 0:
            return "esc"
        end
        second = byte()
        if second == 10 or second == 13:
            return "newline"
        elif second == 91 or second == 79:
            seq = ""
            while available() > 0:
                ch = byte()
                seq += chr(ch)
                if ch >= 64 and ch <= 126:
                    break
                end
            end
            return "seq:" + seq
        end
        return "esc"
    elif first == 13 or first == 10:
        return "enter"
    elif first == 127 or first == 8:
        return "backspace"
    elif first == 9:
        return "tab"
    elif first == 3:
        return "cancel"
    elif first == 4:
        return "eof"
    elif first == 1:
        return "home"
    elif first == 5:
        return "end"
    elif first == 21:
        return "clear"
    elif first < 32:
        return "none"
    elif first < 128:
        return "char:" + chr(first)
    end
    if first < 194 or first > 244:
        return "none"
    end
    # Zachováme celý UTF-8 znak i při čtení po bajtech.
    count = 1
    cp = first - 192
    if first >= 240:
        count = 3
        cp = first - 240
    elif first >= 224:
        count = 2
        cp = first - 224
    end
    for i in rang(count):
        next = byte()
        if next < 128 or next > 191:
            return "none"
        end
        cp = cp * 64 + next - 128
    end
    if cp > 1114111 or cp >= 55296 and cp <= 57343 or count == 1 and cp < 128 or count == 2 and cp < 2048 or count == 3 and cp < 65536:
        return "none"
    end
    return "char:" + chr(cp)
end

function navigation(pressed):
    if pressed == "seq:Q" or pressed == "seq:12~":
        if review.state["tab"] == "changes":
            review.state["tab"] = "plan"
        else:
            review.state["tab"] = "changes"
        end
        return True
    elif pressed == "seq:R" or pressed == "seq:13~":
        view["details"] = not view["details"]
        return True
    elif pressed == "seq:1;5C":
        call review.move_file(1)
        return True
    elif pressed == "seq:1;5D":
        call review.move_file(-1)
        return True
    elif pressed == "seq:1;5A":
        review.state["offset"] = max(0, review.state["offset"] - 3)
        return True
    elif pressed == "seq:1;5B":
        review.state["offset"] += 3
        return True
    elif pressed == "seq:5~":
        view["scroll"] += 10
        return True
    elif pressed == "seq:6~":
        view["scroll"] = max(0, view["scroll"] - 10)
        return True
    end
    return False
end

function cancel():
    if core.state["cancelled"]:
        return True
    end
    count = 0
    while available() > 0 and count < 256:
        pressed = key()
        count += 1
        if pressed == "cancel" or pressed == "esc":
            core.state["cancelled"] = True
            view["status"] = i18n.t("Zastaveno")
            break
        elif not navigation(pressed):
            call compose(pressed)
        end
    end
    call tick()
    call paint()
    return core.state["cancelled"]
end

function tick():
    hook = view.get("poll_hook", None)
    if hook != None:
        call hook()
    end
end

function compose(pressed):
    value = view["input"]
    cursor = view["cursor"]
    choices = suggestions(value)
    if pressed == "seq:200~":
        view["pasting"] = True
    elif pressed == "seq:201~":
        view["pasting"] = False
    elif pressed == "enter" and not view.get("pasting", False):
        if len(choices) > 0:
            value = choices[min(view["menu_index"], len(choices) - 1)]["value"]
        end
        if value.strip() != "":
            queue.append(value)
            input_history.append(value)
            view["input"] = ""
            view["cursor"] = 0
            view["menu_index"] = 0
            view["menu_hidden"] = ""
        end
    elif pressed == "newline" or pressed == "enter":
        view["input"] = value[0:cursor] + "\n" + value[cursor:len(value)]
        view["cursor"] += 1
    elif pressed.startswith("char:"):
        text = pressed[5:len(pressed)]
        view["input"] = value[0:cursor] + text + value[cursor:len(value)]
        view["cursor"] += len(text)
        view["menu_index"] = 0
    elif pressed == "backspace" and cursor > 0:
        view["input"] = value[0:cursor - 1] + value[cursor:len(value)]
        view["cursor"] -= 1
    elif pressed == "seq:3~":
        view["input"] = value[0:cursor] + value[cursor + 1:len(value)]
    elif pressed == "seq:D":
        view["cursor"] = max(0, cursor - 1)
    elif pressed == "seq:C":
        view["cursor"] = min(len(value), cursor + 1)
    elif pressed == "home" or pressed == "seq:H":
        view["cursor"] = 0
    elif pressed == "end" or pressed == "seq:F":
        view["cursor"] = len(value)
    elif pressed == "clear":
        view["input"] = ""
        view["cursor"] = 0
    elif pressed == "seq:A" and len(choices) > 0:
        view["menu_index"] = (view["menu_index"] + len(choices) - 1) % len(choices)
    elif pressed == "seq:B" and len(choices) > 0:
        view["menu_index"] = (view["menu_index"] + 1) % len(choices)
    elif pressed == "tab" and len(choices) > 0:
        view["input"] = choices[min(view["menu_index"], len(choices) - 1)]["value"]
        view["cursor"] = len(view["input"])
    end
end

function select(title, items, query="", current=""):
    if view["plain"]:
        choices = filtered(items, query)
        if len(choices) == 0:
            return None
        end
        print title
        for i in rang(len(choices)):
            printl "{i + 1}. {choices[i][\"label\"]}  {choices[i].get(\"detail\", \"\")}"
        end
        answer = prompt(i18n.t("Vyber číslo nebo napiš hodnotu"))
        for i in rang(len(choices)):
            if answer == String(i + 1) or answer == choices[i]["value"]:
                return choices[i]["value"]
            end
        end
        return None
    end
    selected = 0
    choices = filtered(items, query)
    for i in rang(len(choices)):
        if choices[i]["value"] == current:
            selected = i
        end
    end
    last_resize = time.monotonic()
    loop:
        view["modal"] = {"title": title, "items": choices, "selected": selected, "query": query}
        call paint(True)
        while available() == 0:
            call time.sleep(0.02)
            if time.monotonic() - last_resize > 0.5:
                call term.query_size()
                last_resize = time.monotonic()
                call paint(True)
            end
        end
        pressed = key()
        if pressed == "esc" or pressed == "cancel" or pressed == "eof":
            view["modal"] = None
            call paint(True)
            return None
        elif pressed == "enter" and len(choices) > 0:
            result = choices[selected]["value"]
            view["modal"] = None
            call paint(True)
            return result
        elif pressed == "seq:A" and len(choices) > 0:
            selected = (selected + len(choices) - 1) % len(choices)
        elif pressed == "seq:B" or pressed == "tab":
            if len(choices) > 0:
                selected = (selected + 1) % len(choices)
            end
        elif pressed.startswith("char:"):
            query += pressed[5:len(pressed)]
            choices = filtered(items, query)
            selected = 0
        elif pressed == "backspace" and len(query) > 0:
            query = query[0:len(query) - 1]
            choices = filtered(items, query)
            selected = 0
        elif pressed == "clear":
            query = ""
            choices = filtered(items, query)
            selected = 0
        end
    end
end

function prompt(label="Ready", main=False):
    draft = view["input"]
    cursor = view["cursor"]
    if not main:
        view["input"] = ""
        view["cursor"] = 0
    end
    answer = prompt_inner(label, main)
    if not main:
        view["input"] = draft
        view["cursor"] = cursor
    end
    return answer
end

function prompt_inner(label, main):
    view["status"] = i18n.t(label)
    view["menu_index"] = 0
    view["menu_hidden"] = ""
    if view["plain"]:
        call term.emit("lux> ")
        call term.flush()
        line = ""
        loop:
            pressed = key()
            if pressed == "eof":
                if line == "":
                    return "/quit"
                end
                return line
            elif pressed == "enter":
                return line
            elif pressed == "cancel":
                return "/quit"
            elif pressed.startswith("char:"):
                line += pressed[5:len(pressed)]
            elif pressed == "tab":
                line += "\t"
            end
        end
    end
    if main and len(queue) > 0:
        return queue.pop(0)
    end
    history_index = len(input_history)
    pasting = False
    last_resize = time.monotonic()
    loop:
        if view["menu_query"] != view["input"]:
            view["menu_index"] = 0
            view["menu_query"] = view["input"]
        end
        choices = []
        if not pasting:
            choices = suggestions(view["input"])
        end
        view["menu_index"] = min(view["menu_index"], max(0, len(choices) - 1))
        if available() == 0:
            call paint(True)
            while available() == 0:
                call tick()
                if main and len(activity.events) > 0:
                    return "__background_event__"
                end
                call time.sleep(0.02)
                if time.monotonic() - last_resize > 0.5:
                    call term.query_size()
                    last_resize = time.monotonic()
                    call paint(True)
                end
            end
        else:
            call paint()
        end
        pressed = key()
        value = view["input"]
        cursor = view["cursor"]
        if navigation(pressed):
            continue
        elif pressed == "eof":
            return "/quit"
        elif pressed == "esc":
            view["menu_hidden"] = value
        elif pressed == "cancel":
            if value == "":
                return "/quit"
            end
            view["input"] = ""
            view["cursor"] = 0
        elif pressed == "seq:200~":
            pasting = True
        elif pressed == "seq:201~":
            pasting = False
        elif pressed == "enter" and not pasting:
            if len(choices) > 0:
                value = choices[view["menu_index"]]["value"]
            end
            if value.strip() != "":
                input_history.append(value)
                view["input"] = ""
                view["cursor"] = 0
                view["menu_index"] = 0
                view["menu_query"] = ""
                view["menu_hidden"] = ""
                call paint(True)
                return value
            end
        elif pressed == "newline" or pressed == "enter" and pasting:
            view["input"] = value[0:cursor] + "\n" + value[cursor:len(value)]
            view["cursor"] += 1
        elif pressed.startswith("char:"):
            text = pressed[5:len(pressed)]
            view["input"] = value[0:cursor] + text + value[cursor:len(value)]
            view["cursor"] += len(text)
        elif pressed == "backspace" and cursor > 0:
            view["input"] = value[0:cursor - 1] + value[cursor:len(value)]
            view["cursor"] -= 1
        elif pressed == "seq:3~":
            view["input"] = value[0:cursor] + value[cursor + 1:len(value)]
        elif pressed == "seq:D":
            view["cursor"] = max(0, cursor - 1)
        elif pressed == "seq:C":
            view["cursor"] = min(len(value), cursor + 1)
        elif pressed == "home" or pressed == "seq:H":
            view["cursor"] = 0
        elif pressed == "end" or pressed == "seq:F":
            view["cursor"] = len(value)
        elif pressed == "clear":
            view["input"] = ""
            view["cursor"] = 0
        elif pressed == "seq:A":
            if len(choices) > 0:
                view["menu_index"] = (view["menu_index"] + len(choices) - 1) % len(choices)
            elif history_index > 0:
                history_index -= 1
                view["input"] = input_history[history_index]
                view["cursor"] = len(view["input"])
            end
        elif pressed == "seq:B":
            if len(choices) > 0:
                view["menu_index"] = (view["menu_index"] + 1) % len(choices)
            else:
                history_index = min(len(input_history), history_index + 1)
                view["input"] = ""
                if history_index < len(input_history):
                    view["input"] = input_history[history_index]
                end
                view["cursor"] = len(view["input"])
            end
        elif pressed == "tab":
            if len(choices) > 0:
                selected = choices[view["menu_index"]]
                view["input"] = selected["value"]
                if selected.get("arguments", False):
                    view["input"] += " "
                end
                view["cursor"] = len(view["input"])
            elif value == "":
                view["input"] = "/"
                view["cursor"] = 1
                view["menu_hidden"] = ""
            end
        end
    end
end

function start(plain=False):
    view["plain"] = plain
    if plain:
        return
    end
    call term.enter()
    view["active"] = True
    call os.run_argv_clean(tui.stty_tool(), ["-isig"])
    call term.emit(esc + "[?2004h")
    if len(entries) == 0:
        call add("welcome", i18n.t("Co dnes postavíme?\nNapiš úkol nebo / pro příkazy. Změny souborů uvidíš vpravo."))
    end
    call paint(True)
end

function stop():
    if view["active"]:
        call term.emit(esc + "[?2004l" + esc + "[0m")
        call term.leave()
        view["active"] = False
    end
end

function divider(width):
    return rich.fit("", width).replace(" ", "─")
end

function job_badges():
    parts = []
    counts = core.state.get("job_counts", {})
    for category in ["shell", "monitoring", "služby", "stahování"]:
        count = counts.get(category, 0)
        if count > 0:
            parts.append(String(count) + " " + i18n.t(category))
        end
    end
    if len(parts) == 0:
        return i18n.t("Žádné úlohy na pozadí")
    end
    return " · ".join(parts)
end

function language_changed():
    for item in commands:
        item["detail"] = i18n.t(item.get("detail", ""))
    end
    if view["title"] in ["Nové sezení", "New session"]:
        view["title"] = i18n.t("Nové sezení")
    end
    view["status"] = i18n.t("Ready")
end
