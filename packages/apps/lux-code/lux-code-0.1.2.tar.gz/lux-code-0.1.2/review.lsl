load time
load common as core
load workspace as files
load json

items = []
state = {"selected": 0, "offset": 0, "tab": "changes", "cwd": "", "captured": False, "baseline": {}, "known": {}, "observed": {}, "scope": "agent"}

function reset():
    items.clear()
    state["selected"] = 0
    state["offset"] = 0
    state["cwd"] = core.state["cwd"]
    state["scope"] = "agent"
    state["captured"] = False
    state["baseline"] = {}
    state["known"] = {}
    state["observed"] = {}
end

function paths():
    # --one-file-system + limit: snimek pred prikazem bezi synchronne; slozka site (sshfs) v pracovnim
    # adresari (napr. ~/disk) jinak zablokovala cele TUI, dokud spojeni neodpovedelo
    listing = core.run("timeout -k 1 3 rg --files --one-file-system -g '!node_modules' -g '!.build' -g '!vendor' -g '!dist' -g '!build' -g '!__pycache__' -g '!.venv' -g '!*.lock' -g '!package-lock.json' -g '!TOOLS.md' 2>/dev/null | head -n 160")
    return listing["stdout"].split("\n")
end

function before_tool(name):
    if state["cwd"] != core.state["cwd"]:
        call reset()
    end
    if name not in ["bash", "run_tests", "start_service", "background_shell", "monitor_command", "call_tool"]:
        return
    end
    budget = 524288
    baseline = {}
    known = {}
    for name in paths():
        if name != "":
            filename = core.path(name)
            known[filename] = True
            if not visible(filename):
                continue
            end
            try:
                size = core.cli(["stat", "-c", "%s", "--", filename])
                amount = Int(size["stdout"].strip())
                if filename not in baseline and amount <= 65536 and amount <= budget:
                    baseline[filename] = readfile(filename)
                    budget -= amount
                end
            else:
                continue
            end
        end
    end
    for change in files.changes:
        filename = change["path"]
        if filename in baseline and baseline[filename] == change["after"]:
            baseline[filename] = change["before"]
        end
    end
    state["baseline"] = baseline
    state["known"] = known
    state["captured"] = True
end

function record(filename, patch, label=""):
    if patch == "":
        return
    end
    added = 0
    removed = 0
    for line in patch.split("\n"):
        if line.startswith("+") and not line.startswith("+++"):
            added += 1
        elif line.startswith("-") and not line.startswith("---"):
            removed += 1
        end
    end
    name = filename
    prefix = core.state["cwd"] + "/"
    if name.startswith(prefix):
        name = name[len(prefix):len(name)]
    end
    items.append({"path": filename, "name": name, "added": added, "removed": removed, "diff": patch, "label": label})
end

function patch_for(filename, before, after):
    if before == after:
        return ""
    end
    root = core.state["home"] + "/artifacts/review-" + core.state["session"]
    call core.ensure(root)
    writefile(root + "/before", before)
    writefile(root + "/after", after)
    result = core.cli(["diff", "-u", "--label", "a/" + filename, "--label", "b/" + filename, root + "/before", root + "/after"])
    return result["stdout"]
end

function compare(filename, before, after):
    call record(filename, patch_for(filename, before, after))
end

function refresh():
    if state["cwd"] != core.state["cwd"]:
        call reset()
    end
    selected = ""
    if state["selected"] < len(items):
        selected = items[state["selected"]]["path"]
    end
    if state["scope"] == "agent":
        call agent_refresh()
        return
    end
    items.clear()
    handled = {}
    # Snapshoty zobrazí přesné změny agenta i mimo Git a u nových souborů.
    originals = {}
    for change in files.changes:
        filename = change["path"]
        if filename not in originals:
            originals[filename] = change["before"]
        end
    end
    for filename in originals:
        if not filename.startswith(core.state["cwd"] + "/") or not visible(filename):
            continue
        end
        try:
            after = ""
            if exists(filename):
                after = readfile(filename)
            end
            call compare(filename, originals[filename], after)
            handled[filename] = True
        else:
            continue
        end
    end
    git = core.cli(["git", "rev-parse", "--show-toplevel"])
    if git["ok"]:
        root = git["stdout"].strip()
        arguments = ["git", "diff", "--no-ext-diff", "--no-color"]
        head = core.cli(["git", "rev-parse", "--verify", "HEAD"])
        if head["ok"]:
            arguments.append("HEAD")
        end
        stats = core.cli(arguments + ["--numstat", "-z", "--"])
        records = stats["stdout"].split(chr(0))
        i = 0
        while i < len(records):
            pieces = records[i].split("\t")
            i += 1
            if len(pieces) < 3:
                continue
            end
            name = "\t".join(pieces[2:len(pieces)])
            if name == "" and i + 1 < len(records):
                name = records[i + 1]
                i += 2
            end
            filename = root + "/" + name
            if filename not in handled and name != "" and visible(filename):
                patch = core.cli(arguments + ["--", filename])
                call record(filename, patch["stdout"], "Git")
                handled[filename] = True
            end
        end
        untracked = core.cli(["git", "ls-files", "--others", "--exclude-standard", "-z"])
        count = 0
        for name in untracked["stdout"].split(chr(0)):
            filename = root + "/" + name
            if name != "" and filename not in handled and count < 30 and visible(filename):
                try:
                    size = core.cli(["stat", "-c", "%s", "--", filename])
                    if Int(size["stdout"].strip()) <= 65536:
                        call compare(filename, "", readfile(filename))
                    end
                else:
                    continue
                end
                count += 1
            end
        end
    elif state["captured"]:
        baseline = state["baseline"]
        candidates = {}
        for filename in baseline:
            candidates[filename] = True
        end
        for name in paths():
            if name != "":
                candidates[core.path(name)] = True
            end
        end
        for filename in candidates:
            if filename not in handled and visible(filename):
                if filename not in baseline and filename in state["known"]:
                    continue
                end
                try:
                    after = ""
                    if exists(filename):
                        size = core.cli(["stat", "-c", "%s", "--", filename])
                        if Int(size["stdout"].strip()) > 65536:
                            continue
                        end
                        after = readfile(filename)
                    end
                    call compare(filename, baseline.get(filename, ""), after)
                else:
                    continue
                end
            end
        end
    end
    state["selected"] = min(state["selected"], max(0, len(items) - 1))
    for i in rang(len(items)):
        if items[i]["path"] == selected:
            state["selected"] = i
        end
    end
end

function move_file(delta):
    if len(items) > 0:
        state["selected"] = (state["selected"] + delta + len(items)) % len(items)
        state["offset"] = 0
    end
end

function visible(filename):
    if filename == core.state["home"] or filename.startswith(core.state["home"] + "/"):
        return False
    end
    parts = filename.split("/")
    name = parts[len(parts) - 1].lower()
    if name.startswith(".env") or name in ["id_rsa", "id_ed25519", "credentials.json", "secrets.json"] or name.endswith(".pem") or name.endswith(".key"):
        return False
    end
    return True
end

function focus(arguments):
    try:
        args = json.decode(arguments)
        if "tool_name" in args:
            args = json.decode(args.get("arguments", "{}"))
        end
        path = args.get("path", "")
        if path != "":
            target = core.path(path)
            for i in rang(len(items)):
                if items[i]["path"] == target:
                    state["selected"] = i
                    state["offset"] = 0
                    state["tab"] = "changes"
                end
            end
        end
    else:
        return
    end
end

# Řádky unified diffu se skutečnými čísly původního/nového souboru.
function numbered(patch):
    result = []
    old = 0
    new = 0
    for raw in patch.split("\n"):
        if raw.startswith("---") or raw.startswith("+++") or raw == "":
            continue
        end
        if raw.startswith("@@"):
            parts = raw.split(" ")
            try:
                old = Int(parts[1][1:len(parts[1])].split(",")[0])
                new = Int(parts[2][1:len(parts[2])].split(",")[0])
            else:
                old = 0
                new = 0
            end
            result.append(raw)
        elif raw.startswith("+"):
            result.append(String(new) + " + " + raw[1:len(raw)])
            new += 1
        elif raw.startswith("-"):
            result.append(String(old) + " - " + raw[1:len(raw)])
            old += 1
        elif raw.startswith(" "):
            result.append(String(new) + "   " + raw[1:len(raw)])
            old += 1
            new += 1
        end
    end
    return result
end

function preview(card, change_start):
    args = json.decode(card["arguments"])
    if card["name"] == "call_tool":
        args = json.decode(args.get("arguments", "{}"))
    end
    target = args.get("path", "")
    if target == "":
        return
    end
    target = core.path(target)
    before = None
    after = ""
    for i in rang(change_start, len(files.changes)):
        change = files.changes[i]
        if change["path"] == target:
            if before == None:
                before = change["before"]
            end
            after = change["after"]
        end
    end
    if before != None and visible(target):
        card["preview"] = []
        for raw in numbered(patch_for(target, before, after)):
            if diff_kind(raw) in ["+", "-"]:
                style = "38;5;150"
                if diff_kind(raw) == "-":
                    style = "38;5;203"
                end
                card["preview"].append({"text": raw, "style": style})
                if len(card["preview"]) >= 4:
                    break
                end
            end
        end
    end
end

function diff_kind(raw):
    parts = raw.split(" ")
    if len(parts) > 1:
        return parts[1]
    end
    return ""
end

function observe(baseline, known):
    candidates = {}
    for filename in baseline:
        candidates[filename] = True
    end
    for name in paths():
        if name != "":
            candidates[core.path(name)] = True
        end
    end
    for filename in candidates:
        if not visible(filename) or filename not in baseline and filename in known:
            continue
        end
        try:
            after = ""
            if exists(filename):
                size = core.cli(["stat", "-c", "%s", "--", filename])
                if Int(size["stdout"].strip()) > 65536:
                    continue
                end
                after = readfile(filename)
            end
            before = baseline.get(filename, "")
            if before != after:
                previous = state["observed"].get(filename, None)
                if previous != None and previous["after"] == before:
                    before = previous["before"]
                end
                state["observed"][filename] = {"before": before, "after": after, "order": time.time()}
            end
        else:
            continue
        end
    end
end

function agent_refresh():
    if state["captured"]:
        call observe(state["baseline"], state["known"])
        state["captured"] = False
    end
    items.clear()
    snapshots = {}
    for path in state["observed"]:
        snapshots[path] = state["observed"][path]
    end
    for change in files.changes:
        path = change["path"]
        if not path.startswith(core.state["cwd"] + "/") or not visible(path):
            continue
        end
        previous = snapshots.get(path, None)
        if previous != None and previous.get("order", 0) > change.get("order", 0):
            continue
        end
        before = change["before"]
        if previous != None and previous["after"] == before:
            before = previous["before"]
        end
        snapshots[path] = {"before": before, "after": change["after"], "order": change.get("order", 0)}
    end
    for path in snapshots:
        item = snapshots[path]
        call record(path, patch_for(path, item["before"], item["after"]), "Sezení / pozorovaná akce")
    end
    state["selected"] = min(state["selected"], max(0, len(items) - 1))
end

function record_undo(change):
    path = change["path"]
    if path in state["observed"]:
        previous = state["observed"][path]
        state["observed"][path] = {"before": previous["before"], "after": change["before"], "order": time.time()}
    end
end
