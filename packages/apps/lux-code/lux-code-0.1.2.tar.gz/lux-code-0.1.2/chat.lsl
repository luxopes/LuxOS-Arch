load i18n
load references
load jobs
load activity
load permissions
load engine
load common as core
load screen as ui
load sessions
load tools
load workspace as files
load json
load settings as env
load model_worker
load models
load context_display
load review
load auth
load attachments as att

function command(value, messages):
    pieces = value.split(" ")
    name = pieces[0]
    rest = value[len(name):len(value)].strip()
    if name == "/help":
        call ui.add("help", i18n.t("/help — příkazy\n/lang [en|cs] — jazyk rozhraní\n/tools [filter] — katalog nástrojů\n/permissions [readonly|ask|full] — přístup k nástrojům\n/references [update] — referenční knihovna\n/context — skutečný limit kontextu\n/jobs — úlohy na pozadí\n/model [name] — interaktivní výběr modelu\n/reasoning [auto|none|low|medium|high|xhigh|max] — úroveň reasoningu\n/think — zobrazit / skrýt reasoning\n/rename název — přejmenovat sezení\n/new — nové sezení\n/sessions — interaktivní výběr sezení\n/resume [ID / hledání] — pokračovat v pojmenovaném sezení\n/save — uložit sezení\n/export path.md — export konverzace\n/paste [cesta|clear] — přiložit obrázek ze schránky nebo souboru\n/compact — shrnout kontext a archivovat původní\n/retry — pokračovat po chybě/přerušení\n/cd path — změnit pracovní adresář a načíst instrukce\n/diff [all] — změny sezení / celý workspace\n/undo — vrátit poslední editaci souboru\n/plan — zobrazit plán\n/clear — vyčistit obrazovku (historie zůstane)\n/quit — uložit a skončit\n\nEditor: šipky, Home/End, Ctrl+A/E/U, historie ↑↓, Alt+Enter nový řádek, vložení více řádků, Ctrl+V/Alt+V obrázek ze schránky (vložená/přetažená cesta k obrázku se přiloží, Backspace v prázdném řádku přílohu odebere), PgUp/PgDn. Ctrl+C/Esc přeruší API nebo běžící shell. Návrhy příkazů se ukazují při psaní /. F2 přepíná změny/plán; F3 rozbalí nástroje. Ctrl+←/→ vybírá soubor a Ctrl+↑/↓ posouvá diff."))
    elif name == "/lang":
        selected = rest.lower()
        if selected == "":
            selected = ui.select(i18n.t("Jazyk rozhraní"), i18n.choices(), "", i18n.state["language"])
        end
        if selected != None:
            call i18n.set(selected)
            call ui.language_changed()
            call ui.add("system", i18n.t("Rozhraní je nyní česky."))
        end
    elif name == "/jobs":
        call jobs.poll()
        call ui.add("jobs", json.encode(jobs.execute("list_services", {})))
    elif name == "/context":
        call ui.add("context", context_display.render(models.context_info(ui.view["model"]), ui.view.get("context_tokens", Int(ui.view["context"] / 4)), ui.view.get("last_request_tokens", 0)))
    elif name == "/references":
        if rest == "update":
            call references.ensure(True)
        end
        call ui.add("references", json.encode(references.catalog()))
    elif name == "/tools":
        lines = []
        for tool in tools.tools:
            fn = tool["function"]
            if rest == "" or rest in fn["name"]:
                lines.append(fn["name"] + " — " + fn["description"])
            end
        end
        call ui.add("tools", "\n".join(lines))
    elif name == "/permissions":
        selected = rest
        if selected == "":
            selected = ui.select(i18n.t("Oprávnění nástrojů"), permissions.choices(), "", permissions.state["mode"])
        end
        if selected != None:
            call permissions.set(selected)
            call ui.add("system", i18n.t("Oprávnění: ") + selected)
        end
    elif name == "/model":
        ui.view["status"] = i18n.t("Načítám katalog modelů…")
        call ui.paint(True)
        available = models.list()
        ui.model_items.clear()
        for item in available:
            ui.model_items.append(item)
        end
        selected = None
        for item in available:
            if rest != "" and item["value"] == rest:
                selected = rest
            end
        end
        if selected == None:
            selected = ui.select(i18n.t("Vybrat model"), available, rest, ui.view["model"])
        end
        if selected != None:
            ui.view["model"] = selected
            for item in available:
                if item["value"] == selected and len(item.get("efforts", [])) > 0:
                    if ui.view["reasoning"] != "auto" and ui.view["reasoning"] not in item["efforts"]:
                        ui.view["reasoning"] = "auto"
                    end
                end
            end
            call ui.add("system", "Model: " + selected)
        end
    elif name == "/reasoning":
        if rest != "":
            if rest not in ["auto", "none", "low", "medium", "high", "xhigh", "max"]:
                Error(CommandError: i18n.t("Použij auto, none, low, medium, high, xhigh nebo max."))
            end
            ui.view["reasoning"] = rest
        end
        call ui.add("system", "Reasoning: " + ui.view["reasoning"])
    elif name == "/think":
        ui.view["show_reasoning"] = not ui.view["show_reasoning"]
    elif name == "/sessions" or name == "/resume":
        choices = sessions.catalog()
        selected = None
        if rest != "":
            try:
                if exists(sessions.filename(rest)):
                    selected = rest
                end
            else:
                selected = None
            end
        end
        if selected == None:
            selected = ui.select(i18n.t("Pokračovat v sezení"), choices, rest)
        end
        if selected != None:
            if not sessions.save(messages):
                return
            end
            call sessions.load_session(selected, messages)
            messages[0]["content"] = engine.instructions()
            call ui.add("system", i18n.t("Pokračujete: ") + ui.view["title"])
        end
    elif name == "/rename":
        if rest == "":
            rest = ui.prompt(i18n.t("Název sezení"))
        end
        if rest != "" and rest != "/quit":
            ui.view["title"] = sessions.name(rest)
            core.state["title_source"] = "manual"
            call ui.add("system", i18n.t("Sezení: ") + ui.view["title"])
        end
    elif name == "/save":
        if sessions.save(messages):
            if sessions.has_content(messages, files.changes, ui.tasks):
                call ui.add("system", i18n.t("Uloženo ") + core.state["session"])
            else:
                call ui.add("system", i18n.t("Prázdné sezení se neukládá."))
            end
        end
    elif name == "/export":
        if rest == "":
            rest = "lux-code-session.md"
        end
        call sessions.export_markdown(rest)
        call ui.add("system", i18n.t("Exportováno ") + rest)
    elif name == "/new":
        if not sessions.save(messages):
            return
        end
        call core.init()
        ui.view["title"] = i18n.t("Nové sezení")
        call review.reset()
        messages.clear()
        for message in engine.new_messages():
            messages.append(message)
        end
        ui.entries.clear()
        ui.tasks.clear()
        files.changes.clear()
        activity.events.clear()
        ui.queue.clear()
        ui.view["input"] = ""
        ui.view["cursor"] = 0
        core.state["running_jobs"] = 0
        jobs.owned.clear()
        call ui.add("system", i18n.t("Nové sezení ") + core.state["session"])
    elif name == "/clear":
        ui.entries.clear()
    elif name == "/diff":
        review.state["scope"] = "agent"
        if rest == "all":
            review.state["scope"] = "workspace"
        end
        call review.refresh()
        choices = []
        for item in review.items:
            choices.append({"value": item["path"], "label": item["name"], "detail": "+" + String(item["added"]) + " −" + String(item["removed"]), "hint": item["path"]})
        end
        if len(choices) == 0:
            call ui.add("system", i18n.t("Žádné změny souborů."))
        else:
            selected = ui.select(i18n.t("Změněné soubory"), choices)
            if selected != None:
                for i in rang(len(review.items)):
                    if review.items[i]["path"] == selected:
                        review.state["selected"] = i
                        review.state["offset"] = 0
                        review.state["tab"] = "changes"
                        if ui.view["plain"] or ui.term.cols < 108:
                            call ui.add("diff", "```diff\n" + review.items[i]["diff"] + "\n```")
                        end
                    end
                end
            end
        end
    elif name == "/undo":
        card = ui.tool_start("undo_edit", "{}")
        result = tools.execute("undo_edit", "{}")
        call ui.tool_finish(card, result)
        call review.refresh()
    elif name == "/plan":
        review.state["tab"] = "plan"
        if ui.view["plain"] or ui.term.cols < 108:
            lines = []
            for item in ui.tasks:
                mark = "○ "
                if item.get("done", False):
                    mark = "✓ "
                end
                lines.append(mark + item["text"])
            end
            call ui.add("plan", "\n".join(lines))
        end
    elif name == "/cd":
        result = json.decode(tools.execute("change_directory", json.encode({"path": rest})))
        if "error" in result:
            call ui.add("error", result["error"])
        else:
            call review.reset()
            call review.refresh()
            call ui.add("system", i18n.t("Složka: ") + core.state["cwd"])
            messages[0]["content"] = engine.instructions()
        end
    elif name == "/paste":
        call paste_command(rest)
    elif name == "/compact":
        call engine.compact(messages)
    elif name == "/retry":
        call engine.respond(messages)
    else:
        call ui.add("error", i18n.t("Neznámý příkaz. /help zobrazí nápovědu."))
    end
end

function paste_command(rest):
    if rest == "clear":
        call att.clear()
        call ui.add("system", i18n.t("Přílohy odebrány."))
        return
    end
    if rest == "":
        result = att.clipboard()
        if "text" in result:
            Error(AttachmentError: i18n.t("Ve schránce není obrázek ani soubor s obrázkem."))
        end
    elif len(att.image_paths(rest)) > 0:
        call att.add_paths(rest)
    else:
        call att.add_file(rest)
    end
    call ui.add("system", att.chip() + i18n.t("\nObrázek se pošle s příští zprávou; /paste clear jej odebere."))
end

function submit(value, messages):
    # Text složený jen z cest k obrázkům (přetažení bez bracketed paste) se přiloží.
    if not value.startswith("/") and len(att.image_paths(value)) > 0:
        call att.add_paths(value)
        value = ""
    end
    if len(att.pending) > 0:
        if models.image_support(ui.view["model"]) == "no":
            if value != "":
                ui.view["input"] = value
                ui.view["cursor"] = len(value)
            end
            Error(AttachmentError: "Model " + ui.view["model"] + i18n.t(" nepřijímá obrázky. Přepni /model flash, nebo přílohu odeber (Backspace v prázdném řádku, /paste clear)."))
        end
        if value.strip() == "":
            value = i18n.t("Podívej se na přiložený obrázek.")
        end
    end
    call engine.chat(value, messages)
end

function main():
    if arg(1) == "--install-references":
        call core.init()
        call references.install()
        return
    end
    if arg(1) == "--worker":
        call model_worker.run(arg(2))
        return
    end
    call core.init()
    call i18n.init()
    call ui.language_changed()
    call engine.init()
    plain = env.get("LUX_CODE_PLAIN", "0") == "1"
    once = ""
    resume = ""
    i = 1
    loop:
        value = arg(i)
        if value == None or value == "":
            break
        end
        if value == "--plain":
            plain = True
        elif value == "--prompt":
            i += 1
            once = arg(i)
            plain = True
        elif value == "--resume":
            i += 1
            resume = arg(i)
        elif value == "--cwd":
            i += 1
            directory = core.path(arg(i))
            core.state["cwd"] = core.checked("cd " + core.quote(directory) + " && pwd -P").strip()
        elif value == "--help":
            print "Lux Code · LSL AI coding agent\nlux-code [--plain] [--cwd PATH] [--resume ID] [--prompt TEXT]\n" + i18n.t("Přihlášení: ") + auth.label()
            return
        end
        i += 1
    end
    for item in models.fallback():
        ui.model_items.append(item)
    end
    messages = engine.new_messages()
    if resume != "":
        call sessions.load_session(resume, messages)
        messages[0]["content"] = engine.instructions()
    end
    call review.refresh()
    try:
        call ui.start(plain)
        call references.ensure()
        if once != "":
            call engine.chat(once, messages)
        else:
            loop:
                try:
                    ui.session_items.clear()
                    for item in sessions.catalog():
                        ui.session_items.append(item)
                    end
                    call jobs.poll()
                    if len(activity.events) > 0 and len(ui.queue) == 0:
                        call engine.background(messages)
                        continue
                    end
                    value = ui.prompt("Ready", True)
                    if value == "__background_event__":
                        continue
                    end
                    if value == "/quit" or value == "exit" or value == "quit":
                        if sessions.save(messages) or plain:
                            break
                        end
                        continue
                    elif value.strip() == "" and len(att.pending) == 0:
                        continue
                    end
                    try:
                        if value.startswith("/"):
                            call command(value, messages)
                        else:
                            call submit(value, messages)
                        end
                    else:
                        failure = core.clean(String(last_error()))
                        call core.record_error("interactive.command", failure)
                        call ui.add("error", failure)
                    end
                    call sessions.save(messages)
                else:
                    failure = core.clean(String(last_error()))
                    call core.record_error("interactive.turn", failure)
                    call ui.add("error", failure + i18n.t("\nAplikace pokračuje. /retry zopakuje požadavek."))
                    ui.view["status"] = i18n.t("Chyba · připraveno pokračovat")
                end
            end
        end
        call sessions.save(messages)
        call ui.stop()
        if once != "" and core.state.get("error", False) or core.state.get("save_error", "") != "":
            exit(1)
        end
    else:
        failure = core.clean(String(last_error()))
        call core.record_error("main", failure)
        call ui.stop()
        printl "Lux Code: {failure}"
        exit(1)
    end
end

call main()
