load i18n
load json
load settings as env

# Vyber autentizace pro LuxAI:
#   account - sdileny ucet LuxOS (~/.config/luxai/account.json, cookie session),
#   apikey  - dosavadni API klic LUX_AI_API z env/.env.
# LUX_CODE_AUTH=auto|account|apikey (vychozi auto). Token se nikdy nevypisuje,
# neuklada do request souboru ani nepredava v argumentech procesu.

ACCOUNT_ORIGIN = "https://lux-ai.cz"
ACCOUNT_PATH = "/api/ide/chat/completions"
ACCOUNT_CLIENT = "lux-code"
ACCOUNT_MODELS = ["flash", "lite"]
DEFAULT_ENDPOINT = "https://api.lux-ai.cz/v1/chat/completions"

function account_file():
    config_home = env.get("XDG_CONFIG_HOME", "")
    if config_home == "":
        config_home = env.get("HOME", "/tmp") + "/.config"
    end
    return env.get("LUX_CODE_ACCOUNT_FILE", config_home + "/luxai/account.json")
end

function safe_text(value):
    # E-mail z ciziho souboru nesmi do terminalu poslat ridici znaky.
    result = ""
    for ch in String(value):
        code = ord(ch)
        if code >= 32 and code != 127:
            result += ch
        end
    end
    if len(result) > 120:
        return result[0:120]
    end
    return result
end

function account_origin(data):
    # Puvod z account.json se pouzije jen pro oficialni server nebo pro
    # lokalni loopback (testy); jinak se cookie nikam jinam neposle.
    address = data.get("origin", ACCOUNT_ORIGIN)
    if type(address) != "String":
        return ACCOUNT_ORIGIN
    end
    address = address.strip()
    while address.endswith("/"):
        address = address[0:len(address) - 1]
    end
    if address == ACCOUNT_ORIGIN or address.startswith("http://127.0.0.1:"):
        return address
    end
    return ACCOUNT_ORIGIN
end

function load_account():
    filename = account_file()
    if not exists(filename):
        return None
    end
    try:
        data = json.decode(readfile(filename))
    else:
        return None
    end
    if type(data) != "Dictionary":
        return None
    end
    token = data.get("sessionToken", "")
    if type(token) != "String" or token.strip() == "":
        return None
    end
    user = data.get("user", {})
    email = ""
    if type(user) == "Dictionary":
        email = safe_text(user.get("email", user.get("username", "")))
    end
    return {"token": token.strip(), "email": email, "origin": account_origin(data)}
end

# Webove vyhledavani pres server uctu LuxAI (klic vyhledavace zustava na serveru).
# Cookie se posila jen na puvod uctu (lux-ai.cz, v testech loopback); None = neprihlasen.
ACCOUNT_SEARCH_PATH = "/api/ide/search"

function search_request():
    account = load_account()
    if account == None:
        return None
    end
    return {"url": account["origin"] + ACCOUNT_SEARCH_PATH, "headers": {"Cookie": "lux_account_session=" + account["token"], "X-Lux-Client": ACCOUNT_CLIENT, "User-Agent": ACCOUNT_CLIENT}}
end

function custom_endpoint():
    # Vlastni endpoint (mock API, jiny provider) znamena vyslovne API klic.
    if not env.has("LUX_AI_ENDPOINT"):
        return False
    end
    return env.get("LUX_AI_ENDPOINT", DEFAULT_ENDPOINT) != DEFAULT_ENDPOINT
end

function mode():
    selected = env.get("LUX_CODE_AUTH", "auto").strip().lower()
    if selected == "apikey" or selected == "api":
        return "apikey"
    end
    if selected == "account":
        return "account"
    end
    if custom_endpoint():
        return "apikey"
    end
    if load_account() != None:
        return "account"
    end
    return "apikey"
end

function is_account():
    return mode() == "account"
end

function account_endpoint(account):
    return account["origin"] + ACCOUNT_PATH
end

function endpoint():
    if is_account():
        account = load_account()
        if account == None:
            return ACCOUNT_ORIGIN + ACCOUNT_PATH
        end
        return account_endpoint(account)
    end
    return env.get("LUX_AI_ENDPOINT", DEFAULT_ENDPOINT)
end

# Prihlasovaci udaje pro konkretni endpoint: {"token", "headers"}.
# Cookie se prida jen pro endpoint uctu, nikdy pro jiny server.
function credentials(target):
    if is_account():
        account = load_account()
        if account == None:
            Error(AIAuthError: login_message())
        end
        if target != account_endpoint(account):
            Error(AIAuthError: "LuxAI account session is only sent to " + account_endpoint(account))
        end
        return {"token": "", "headers": {"Cookie": "lux_account_session=" + account["token"], "X-Lux-Client": ACCOUNT_CLIENT, "User-Agent": ACCOUNT_CLIENT}}
    end
    return {"token": env.require("LUX_AI_API"), "headers": {}}
end

function label():
    if is_account():
        account = load_account()
        email = ""
        if account != None:
            email = account["email"]
        end
        if email == "":
            return i18n.t("účet LuxAI")
        end
        return i18n.t("účet LuxAI") + " " + email
    end
    if env.has("LUX_AI_API"):
        return i18n.t("API klíč")
    end
    return i18n.t("API klíč chybí")
end

function login_message():
    return i18n.t("Přihlášení k účtu LuxAI vypršelo nebo je neplatné. Spusťte `luxos-account login` a zkuste to znovu (/retry).")
end

# Prevede chybu serveru uctu na srozumitelnou zpravu; jinak vrati None.
function account_failure(failure):
    lowered = failure.lower()
    if "http 401:" in lowered or "http 403:" in lowered:
        return login_message()
    end
    if "flash_monthly_limit" in lowered:
        return i18n.t("Měsíční limit modelu Flash na účtu LuxAI je vyčerpán. Přepněte /model lite nebo počkejte na nový měsíc.")
    end
    if "monthly_limit" in lowered:
        return i18n.t("Měsíční limit modelu Lite na účtu LuxAI je vyčerpán.")
    end
    return None
end

function model(selected):
    if is_account() and selected not in ACCOUNT_MODELS:
        return "flash"
    end
    return selected
end
