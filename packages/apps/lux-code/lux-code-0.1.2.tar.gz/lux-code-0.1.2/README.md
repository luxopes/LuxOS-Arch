# Lux Code

AI agent pro práci s kódem a počítačem, napsaný v LSL. Používá stávající
LuxAI API klíč z `.env` vedle `chat.lsl`.

```sh
cd ~/Lux-Code
lsl chat.lsl
```

Pro jiný projekt:

```sh
lsl ~/Lux-Code/chat.lsl --cwd ~/Projects/muj-projekt
```

Agent načte pouze `AGENTS.md` přímo v aktivní pracovní složce (nebo `--cwd`).
Pokud chybí, pokračuje bez něj; domovskou složku ani rodiče neprohledává. Může sám
číst soubory, upravovat kód, spouštět kontroly a pokračovat podle výsledků.
Před každým požadavkem se systémové instrukce znovu sestaví. Při obnovení staršího
sezení se původní kontext archivuje do `artifacts/session-before-cwd-policy-*.json`;
model dostane původní uživatelská zadání bez historických odpovědí a souhrnů, které
mohly obsahovat cizí pravidla. Přepis v TUI zůstane zachovaný.
Smyčka nemá pevný limit deseti kol. U většího úkolu si vede plán.

## Instalace jako aplikace (.deb)

Hotový balíček pro 64bitový Debian/Ubuntu/Kali je v `dist/`:

```sh
sudo apt install ./dist/lux-code_0.1.1_amd64.deb
```

Po instalaci spusť `lux-code` v adresáři projektu nebo otevři **Lux Code**
z nabídky aplikací. `lux-code --cwd /cesta/k/projektu` vybere projekt explicitně.
Balíček obsahuje samostatnou binárku; LSL není pro běh potřeba.

API klíč se do balíčku nepřidává. Pro první konfiguraci můžeš použít
stávající `.env` z tohoto projektu (pokud cílový soubor už existuje, zachovej ho):

```sh
install -d -m 700 ~/.config/lux-code
test -e ~/.config/lux-code/.env || install -m 600 .env ~/.config/lux-code/.env
```

Bez stávajícího klíče použij jako vzor `/usr/share/doc/lux-code/env.example`.
Vlastní umístění konfiguračního souboru lze nastavit přes `LUX_CODE_CONFIG`;
proměnné prostředí mají přednost. Nastavení a historie zůstávají u uživatele,
aktualizace ani odstranění balíčku je nemaže. Volitelné nástroje pro prohlížeč,
desktop a Android jsou popsané v `/usr/share/doc/lux-code/README.Debian`.

Nový balíček sestavíš ze zdrojového adresáře:

```sh
lsl build_deb.lsl
# nebo vlastní verze:
lsl build_deb.lsl 0.1.2
```

V `dist/` vznikne `.deb` a jeho kontrolní součet `.deb.sha256`.

## TUI

Tmavé rozhraní s modrými akcenty a jednobarevným bodovým logem LuxAI na úvodní obrazovce.
Používá kompatibilní 256barevnou paletu a jednotné pozadí textu.
Odeslaný vstup se vymaže ihned, ještě před čekáním na model.
Logo je vložené přímo v LSL a přizpůsobuje velikost výšce terminálu.
Celoobrazovkové rozhraní s živým Markdownem: tučný text, inline kód,
řetězce v jednoduchých uvozovkách, kombinované tučné písmo s kódem/uvozovkami,
nadpisy, seznamy a bloky kódu. Markdown tabulky mají zarovnané sloupce,
zalamování buněk a v úzkém panelu přecházejí na seznam hodnot.
Nástroje mají stavovou tečku (zelený úspěch, červenou chybu, žlutý průběh),
tučný název s hlavním argumentem a odsazený stručný výsledek. U souborových
editací se ukáže až čtyřřádkový náhled s čísly řádků. Celé argumenty a výsledky zůstávají v historii;
**F3** je rozbalí nebo zase skryje. Starší sezení se při načtení převedou
na stejný kompaktní výpis.

- Psaní `/` nebo `/mo` rovnou nabídne odpovídající příkazy. ↑↓ vybírají,
  Tab doplní a Enter potvrdí; Esc nabídku schová.
- `/model` otevře filtrovatelný výběr z API katalogu; `/model p` napovídá
  modely při psaní. Při nedostupnosti katalogu zůstávají označené fallback aliasy.
- `/resume` a `/sessions` otevřou filtrovatelný výběr podle názvu, složky,
  data a modelu. `/resume ID` dál funguje přímo.
- Prázdná nová sezení se neukládají; starší prázdná sezení se v resume nenabízejí.
- Model na začátku sezení vytvoří krátký název přes `session_title`; do té doby
  se používá náhradní název podle prvního zadání. `/rename název`
  umožní vlastní jméno; název je vidět v záhlaví a zůstává zachovaný při resume.
- Vpravo se po editaci objeví soubory, skutečné počty `+`/`−` a diff s čísly řádků.
  Panel sleduje souborové nástroje i Git změny. Mimo Git zachytává také
  změny menších textových souborů ze shellu (snapshot do 64 KiB na soubor,
  celkem 512 KiB). Citlivé konfigurační soubory do automatického náhledu nezahrnuje.
- **Ctrl+←/→** vybírá soubor, **Ctrl+↑/↓** posouvá diff. **F2** přepíná
  mezi změnami a plánem. `/diff` otevře výběr souboru; v úzkém terminálu
  vypíše diff do konverzace.
- Enter odešle zadání, Alt+Enter vloží nový řádek. Vložení více řádků
  používá bracketed paste. Editor podporuje UTF-8 a šířku znaků terminálu.
- **Ctrl+V** nebo **Alt+V** (případně `/paste`) přiloží obrázek ze schránky
  (`xclip` na X11, `wl-paste` na Waylandu; PNG/JPEG/WebP/GIF, BMP/TIFF přes
  ImageMagick). Soubor zkopírovaný ve správci souborů se přiloží také; pokud je
  ve schránce jen text, Ctrl+V jej vloží. Vložená nebo přetažená cesta
  k obrázku či `file://` URI se přiloží místo textu. Nad vstupem se ukáže
  `📎 obrázek přiložen (Š×V, velikost)`; Backspace v prázdném řádku nebo
  `/paste clear` přílohu odebere. Enter na prázdném řádku odešle jen obrázek.
  Obrázky nad 2048 px nebo 1 MiB se s ImageMagick zmenší (originál zůstane).
  Model bez obrazových vstupů (podle katalogu brány) přílohu odmítne.
- Šipky vlevo/vpravo, Home/End a Ctrl+A/E/U upravují vstup. ↑↓ mimo
  nabídku procházejí historii; PgUp/PgDn procházejí konverzaci.
- Ctrl+C nebo Esc přeruší běžící API požadavek i shell; při prázdném
  vstupu Ctrl+C skončí. Rozhraní reaguje na změny velikosti terminálu.

```text
/tools [filter]                  katalog nástrojů
/model [name]                    interaktivní výběr modelu
/reasoning [auto|none|low|medium|high|xhigh|max]
/new                             nové sezení
/sessions                        interaktivní výběr sezení
/resume [ID / hledání]           výběr a pokračování v sezení
/rename název                    přejmenovat sezení
/save                            uložit nyní
/export cesta.md                 export konverzace
/compact                         shrnout kontext a archivovat původní
/retry                           pokračovat po chybě nebo přerušení
/cd cesta                        změnit pracovní adresář a načíst instrukce
/diff                            změny v Gitu
/undo                            vrátit poslední editaci souboru
/plan                            aktuální plán
/clear                           vyčistit obrazovku
/quit                            uložit a skončit
```

## Nástroje

Katalog má **113 nástrojů**; kompletní seznam je v [TOOLS.md](TOOLS.md).

| Oblast | Funkce |
| --- | --- |
| Soubory | Čtení s čísly řádků, přesné náhrady, zápis, append, vkládání/mazání řádků, unified diff, undo, JSON, hledání, strom, přesuny, kopie, hashe |
| Vývoj | Shell, testy, Git status/diff/log/blame/branches, explicitní staging, nové větve, informace o runtime |
| Služby | Background procesy ve vlastních skupinách, stav, logy, zastavení, obnova evidence sezení |
| Web | Vyhledávání na webu (přes účet LuxAI nebo vlastní Tavily), extrakce textu stránek, HTTP request/fetch |
| Firefox | DOM, snapshot, konzole, síť, JS eval, CSS, responsive, accessibility, screenshot, klikání, psaní, scroll |
| Desktop | Screenshot, okna, focus, myš, klávesy, psaní, clipboard, otevření URL |
| Android | ADB devices, shell, screenshot, UI XML, tap/swipe/text/key, aplikace, logcat, URL |
| Agent | Plán, dotaz uživateli, projektová paměť, obrázky, vyhledávání a volání nástrojů |

LuxAI API přijímá nejvýše 64 definic na požadavek. Základní nástroje jsou
předané přímo; specializované desktop/Android nástroje a browser aliasy
si model najde pomocí `tool_search` a použije přes `call_tool`:

```json
{"tool_name":"desktop_info","arguments":"{}"}
```

Příkazy shellu nemají přidaný timeout. Dlouho běžící služby mají vlastní
procesní skupinu, log a stavový soubor. Ctrl+C ukončí skupinu právě
přerušovaného příkazu. `stop_service` pracuje pouze s evidovanými procesy
a kontroluje jejich identitu, aby nezasáhl jiný proces po znovupoužití PID.

Editace zapisují atomicky a uchovávají snapshot pro `/undo`; existujícím
souborům zachovávají oprávnění. Přesná náhrada odmítne nejednoznačný
výskyt. Undo odmítne přepsat pozdější změnu souboru. Undo se týká změn
provedených souborovými nástroji, nikoli libovolných příkazů v shellu.
Unified diff může změnit více souborů; jedno undo obnoví jeden snapshot.

## Místní integrace

- Firefox používá existující `~/.local/bin/ff-rdp`, inspirovaný místním Pi
  rozšířením `web-debug.ts`. Výchozí port je **6010**; `browser_open`
  podle potřeby spustí izolovaný headless Firefox s dočasným profilem.
- `web_search` funguje bez dalšího nastavení přes účet LuxAI (`luxos-account login`):
  dotaz jde na `https://lux-ai.cz/api/ide/search` s cookie účtu, vyhledávač
  (Tavily, případně DuckDuckGo) i jeho klíč zůstávají na serveru. Limit je
  20 dotazů za minutu a 500 za den na účet. Bez přihlášení nástroj vrátí
  srozumitelnou chybu s návodem.
- Vlastní klíč Tavily (`TAVILY_API_KEY` v `~/.config/lux-code/.env` nebo
  existující `~/.pi/agent/tavily-token`) má přednost před účtem a používá se
  pro `web_search` i `web_extract`. Bez něj `web_extract` stáhne stránky přímo
  a převede HTML na text (nejvýše 5 URL, 20 000 znaků na stránku).
- Desktop ovládání používá `xdotool` a `xclip` na X11. Screenshot používá
  ImageMagick `import`; na Waylandu `grim`, pokud je dostupný.
- Android nástroje používají `adb` a potřebují autorizované připojené zařízení.
- Obrázky PNG/JPEG/WebP do 1 MiB se přikládají k dalšímu požadavku.
  Vybraný model musí podporovat obrazové vstupy. Větší obrázek je třeba
  nejprve zmenšit. Screenshoty i další artefakty mají cestu ve výsledku nástroje.

Agentní logika, katalog, UI, síťový worker, sezení a testy jsou v LSL.
Systémové operace používají instalované CLI nástroje; nejsou přepsané
implementace Firefoxu, Gitu, ADB ani shellu. Aplikace nepotřebuje Python
ani Node runtime. Projekt může své vlastní runtime používat při testování.

## Sezení a kontext

Sezení se ukládají do `~/.local/state/lux-code/sessions`. Stavový adresář
má práva 700 a soubory sezení 600. Ukládá se historie, plán, pracovní
adresář, model, reasoning, záznamy nástrojů, undo a evidence služeb.
Výsledky nástrojů se ukládají průběžně; ještě před jejich spuštěním existuje
v historii záznam nepotvrzeného volání pro případ pádu.

Dlouhé výstupy nástrojů dostanou zkrácený náhled a cestu k úplnému artefaktu.
Automatické shrnutí se řídí limitem kontextu konkrétního modelu z metadat,
rezervou na odpověď a odhadem vstupu kalibrovaným skutečným `prompt_tokens`,
pokud je API vrací. Pevný výchozí limit 180 000 znaků se nepoužívá.
Neznámý model nemá vymyšlený limit; `/context` ukáže dostupná metadata.
`LUX_CODE_CONTEXT_CHARS` zůstává volitelným ručním limitem. Gateway může mít
vlastní nižší limity velikosti požadavku či počtu zpráv. `/compact` spustí
shrnutí ručně; původní kontext se archivuje.
Base64 obrázků se nepočítá jako textový kontext. Před odpovědí se používá
orientační odhad 4096 tokenů na snímek; skutečnou spotřebu určuje provider
a poslední nahlášený vstup ukazuje `/context`. Po úspěšné odpovědi se
obrazové payloady vyřadí z živé historie, při chybě zůstanou pro opakování.
`web_debug` fotí standardně viewport; celou stránku vyžádá `full_page: true`.
Obrazové přílohy se do obnoveného sezení neukládají; původní cestu
lze znovu otevřít přes `view_image`. Projektovou paměť agent ukládá do
`.lux-code/memory.md` v pracovním projektu.

## Jazyk rozhraní

Výchozí jazyk TUI je angličtina. `/lang` otevře výběr; `/lang cs` zapne
češtinu a `/lang en` angličtinu. Volba se uloží pro další spuštění a platí
pro nabídky, nápovědu, stavové zprávy i `/context`. Jazyk odpovědí modelu
se dál řídí jazykem uživatele. Příkazy a názvy nástrojů se nemění.

## Přihlášení: účet LuxAI nebo API klíč

V LuxOS Lux Code přebírá sdílený účet LuxAI: existuje-li
`~/.config/luxai/account.json` se `sessionToken`, chat jde na
`POST https://lux-ai.cz/api/ide/chat/completions` s cookie
`lux_account_session` a hlavičkou `X-Lux-Client: lux-code` a spotřeba se
účtuje na účet (modely `flash` a `lite`). Bez souboru se použije
dosavadní API klíč `LUX_AI_API` z `.env`. Vlastní `LUX_AI_ENDPOINT` nebo
`LUX_CODE_AUTH=apikey` vynutí API klíč, `LUX_CODE_AUTH=account` účet.
Při HTTP 401/403 Lux Code vypíše výzvu ke spuštění `luxos-account login`;
soubor účtu jen čte, nikdy ho nemění. Token se nevypisuje, nezapisuje do
sezení, request souborů ani argumentů procesů. Hlavička TUI a `--help`
ukazují, které přihlášení se používá (e-mail účtu / API klíč).

## Konfigurace

Stávající `.env` zůstává zachovaný. Proměnné prostředí mají přednost.

| Proměnná | Výchozí hodnota / význam |
| --- | --- |
| `LUX_CODE_CONFIG` | Volitelná explicitní cesta k `.env`; build v `.build` najde i `.env` v kořeni aplikace |
| `LUX_AI_API` | API klíč (použije se, když není přihlášený účet LuxAI) |
| `LUX_CODE_AUTH` | `auto` (účet LuxAI, jinak API klíč), `account` nebo `apikey` |
| `LUX_CODE_ACCOUNT_FILE` | `~/.config/luxai/account.json` |
| `LUX_AI_MODEL` | `flash` |
| `LUX_AI_ENDPOINT` | `https://api.lux-ai.cz/v1/chat/completions` |
| `LUX_AI_REASONING` | `low`; `auto` parametr vynechá |
| `LUX_CODE_SHELL` | `/bin/bash` pro shellové příkazy a služby |
| `LUX_CODE_HOME` | `~/.local/state/lux-code` |
| `LUX_CODE_CONTEXT_CHARS` | nenastaveno; automaticky podle modelu |
| `LUX_CODE_BROWSER_PORT` | `6010` |
| `FF_RDP` | `~/.local/bin/ff-rdp` |
| `LUX_CODE_PLAIN` | `1` zapne řádkový režim |
| `LUX_AI_STREAM_RELIABILITY` | Pro LuxAI `live`, aby text přicházel průběžně; lze nastavit `transactional` |
| `LUX_AI_HTTP_TIMEOUT` | Volitelná změna timeoutu HTTP transportu knihovny; bez nastavení se použije jeho výchozí hodnota |

```sh
lsl chat.lsl --plain
lsl chat.lsl --prompt 'Prohlédni projekt a vysvětli vstupní bod.'
lsl chat.lsl --resume ID
```

Použitý `aikit.lsl` 1.2.0 je lokální kopie se zdrojovým reasoning API,
streamováním a function calling. API klíč se neukládá do argumentů workeru
ani jeho request souboru. Síťový worker je stejné LSL executable, aby jej
šlo přerušit i během čekání na první token.

## Ověření a sestavení

LSL 0.8.9+, Linux x86_64 a instalovaný balíček `shell`.

```sh
lsl test.lsl
lsl test_agent.lsl
lsl test_account.lsl
lsl test_ui.lsl
lsl test_context.lsl
lsl test_vision.lsl
lsl test_attachments.lsl
lsl test_language.lsl
lsl test_encoding.lsl
lsl test_background_encoding.lsl
lsl test_markdown.lsl
lsl test_permissions.lsl
lsl test_runtime.lsl
lsl test_browser.lsl
```

UI test ověřuje lokální instrukce, Markdown, názvy a index sezení,
napovídání, kompaktní výstupy a skutečné diffy včetně undo.
První test pracuje v dočasném projektu, druhý používá lokální testovací API
napsané v LSL, třetí ověřuje skutečný headless Firefox na místní testovací
stránce. Testy nemění uživatelské projekty ani běžné browser profily.

Volitelný build samostatného executable:

```sh
mkdir -p .build
lsl compile chat.lsl .build/lux-code
.build/lux-code
```

Katalog dokumentace lze znovu vygenerovat příkazem `lsl catalog.lsl`.

## Zotavení z chyb

Neplatné UTF-8 z nástrojů se pro model a terminál nahradí znakem `�`.
Uložený stav zachovává neplatné bajty v označeném JSON záznamu; snapshoty pro
undo se při obnovení dekódují beze změny původního souboru.
Chyba ukládání se zobrazí v TUI, konverzace zůstane v paměti a `/save` umožní
opakovat uložení. `/new` a `/resume` nepřepnou sezení, dokud se aktuální stav
nepodaří uložit. Interaktivní `/quit` při neúspěšném uložení také zůstane v TUI;
režim `--plain` při ukončení s neuloženým stavem vrací nenulový exit kód.
Diagnostika je v `$LUX_CODE_HOME/artifacts/errors.log`, standardně
`~/.local/state/lux-code/artifacts/errors.log`. Log neobsahuje celé požadavky.

## Připojení a oprávnění

Při výpadku spojení, přerušeném SSE streamu a dočasných HTTP chybách (408, 429,
500/502/503/504 a vybrané chyby proxy) agent čeká a opakuje nedokončený požadavek.
Interval roste od 2 do 30 sekund; počet pokusů nemá limit. Esc nebo Ctrl+C čekání
přeruší. Chyby přihlášení, neplatné požadavky a chyby formátu se automaticky
neopakují. `LUX_CODE_RECONNECT=0` automatické opakování vypne. Nedokončený text
se při opakování zahodí; nástroje se spouštějí až po dokončení celého streamu.
Výsledky již provedených nástrojů zůstávají v kontextu. Zadání se uloží před
síťovým požadavkem. V režimu `--plain` může být částečný text před oznámením
opakování již vypsaný na stdout.

`/permissions` otevře výběr, případně použij přímo:

- `/permissions readonly` — čtení souborů a webu; blokuje shell, úpravy souborů,
  libovolné HTTP požadavky a ovládání prohlížeče/PC/mobilu. Interní plán a název
  sezení zůstávají dostupné.
- `/permissions ask` — čtení bez dotazu; ostatní akce vyžadují jednorázové
  potvrzení. Esc a výchozí volba akci zamítnou. Kontrola platí i pro `call_tool`.
- `/permissions full` — dosavadní plný přístup bez jednotlivých potvrzení.

Volba se ukládá do `$LUX_CODE_HOME/permissions.json` a platí i po restartu.
Resume nastavení oprávnění nemění. Jde o kontrolu volání nástrojů aplikací,
ne o izolaci operačního systému; jednorázově schválený shell má běžná práva
uživatele. Síťové spojení s modelem a ukládání vlastního stavu fungují ve všech
režimech. Ruční `/rename` má před názvem od modelu přednost.

## Úlohy na pozadí a editor

`background_shell(command, name)` spustí kompilaci/test či jiný shell na pozadí.
`monitor_command(command, name)` spustí jednorázový watcher: příkaz má skončit,
když nastane sledovaná událost. Není nastaven pevný timeout. Oba nástroje se
řídí `/permissions`; stav a výstup jsou dostupné přes `/jobs`, `service_status`,
`service_logs` a `stop_service`. Po dokončení se zobrazí oznámení a model dostane
výsledek v další bezpečné hranici mezi koly. V interaktivním TUI se tím probudí
i po své závěrečné odpovědi. Během aktivního modelového kola se nástroje nevolají
souběžně s jiným modelem. Oznámení je vygenerované jednou a ukládá se se sezením.
Po vypnutí PC se nedokončená úloha označí jako přerušená, nikoli úspěšná;
původní proces se automaticky nespouští znovu.

Během generování, shellu i čekání na síť lze psát do editoru. Enter zařadí
zadání do fronty a vyčistí vstup; rozepsaný další text zůstane v editoru. Fronta
se zpracuje po aktuálním kole a má přednost před automatickými oznámeními.
Esc/Ctrl+C přeruší právě běžící akci. Fronta a rozepsaný text jsou součástí
uloženého sezení; ke kontinuálnímu zápisu na disk při každém stisku nedochází.
Automatické probouzení v nečinnosti vyžaduje interaktivní TUI; `--plain` je určen
pro lineární vstup a dávkové použití.

Boční diff standardně ukazuje změny sezení, ne celý rozdíl proti HEAD. Starší
ruční změny a dodatečné ruční úpravy po zásahu agenta se nepřipisují agentovi.
`/diff all` výslovně přepne na celý workspace, `/diff` zpět na sezení. U shellů
jde o pozorování souborů během běhu akce, nikoli dokonalý důkaz autorství při
souběžných editacích jiným procesem. Zachycení menších textových souborů má
stejné velikostní limity jako dříve. Soukromý stav agenta se z diffu vylučuje.

## Referenční knihovna a pravidla vlastníka

První interaktivní spuštění zahájí stahování na pozadí do
`$LUX_CODE_HOME/references`. Manuál LSL se stáhne jako oficiální archiv pro
nainstalovanou verzi kompilátoru (vyžaduje `unzip`). `/references` ukáže zdroje,
data a výsledek stahování; `/references update` obnoví cache. Model má přes
`tool_search` přístup k `reference_catalog`, `reference_search` a `reference_read`.
`LUX_CODE_REFERENCES=0` automatické stahování vypne. Katalogy modelů se používají
pro zjištění kontextu; limit výstupu se nikdy nezaměňuje za limit vstupního kontextu.

Knihovna obsahuje průvodce oficiálními právními zdroji a pokusí se stáhnout
GDPR, NIS2 a český trestní zákoník. Některé úřední portály vyžadují interaktivní
ověření prohlížeče: takový text se nepředstírá jako stažený a zůstává k němu
původní odkaz s chybovým stavem. Cache není automaticky aktuálním právním výkladem;
model má ověřovat působnost, účinné znění a jurisdikci. Referenční texty jsou
podklady, nikoli instrukce.

Vlastnická pravidla v `safety.lsl` dovolují legitimní kyberbezpečnost, obranu,
oprávněné testování a výzkum. Zakazují pomoc se zjevně protiprávní činností
a vývojem či vylepšováním zbraní včetně souvisejícího softwaru. Platí nad
projektovými instrukcemi a režim `full` je nevypíná. Jde o instrukce modelu,
nikoli záruku porozumění každému úmyslu nebo právní posouzení programu.
