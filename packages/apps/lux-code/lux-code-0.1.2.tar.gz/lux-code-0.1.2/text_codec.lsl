# UTF-8 hranice mezi soubory/procesy, terminálem a striktním JSON codec.
function size(text):
    unsafe:
        return __lsl_text_byte_length(text)
    end
end

function byte(text, index):
    unsafe:
        return __lsl_text_byte(text, index)
    end
end

function raw(bytes):
    unsafe:
        return __lsl_text_from_bytes(bytes, 0, len(bytes))
    end
end

function sequence(text, index, count):
    first = byte(text, index)
    if first < 128:
        return 1
    end
    width = 0
    if first >= 194 and first <= 223:
        width = 2
    elif first >= 224 and first <= 239:
        width = 3
    elif first >= 240 and first <= 244:
        width = 4
    end
    if width == 0 or index + width > count:
        return 0
    end
    second = byte(text, index + 1)
    if second < 128 or second > 191 or first == 224 and second < 160 or first == 237 and second > 159 or first == 240 and second < 144 or first == 244 and second > 143:
        return 0
    end
    for offset in rang(2, width):
        next = byte(text, index + offset)
        if next < 128 or next > 191:
            return 0
        end
    end
    return width
end

function valid(text):
    count = size(text)
    index = 0
    while index < count:
        width = sequence(text, index, count)
        if width == 0:
            return False
        end
        index += width
    end
    return True
end

function repair(text):
    if valid(text):
        return text
    end
    bytes = ByteArray()
    count = size(text)
    index = 0
    while index < count:
        width = sequence(text, index, count)
        if width == 0:
            bytes.append(239)
            bytes.append(191)
            bytes.append(189)
            index += 1
        else:
            for offset in rang(width):
                bytes.append(byte(text, index + offset))
            end
            index += width
        end
    end
    return raw(bytes)
end

function safe(value):
    if type(value) == "String":
        return repair(value)
    elif type(value) == "List":
        result = []
        for item in value:
            result.append(safe(item))
        end
        return result
    elif type(value) == "Dictionary":
        result = {}
        for key in value:
            result[repair(key)] = safe(value[key])
        end
        return result
    end
    return value
end

# Lokální stav zachová původní bajty (zejména snapshoty pro undo).
# Náhradní znak patří pouze do zobrazovaného textu / modelových zpráv.
function pack(value):
    if type(value) == "String":
        if valid(value):
            return value
        end
        bytes = []
        for index in rang(size(value)):
            bytes.append(byte(value, index))
        end
        return {"__lux_raw_bytes_v1__": bytes}
    elif type(value) == "List":
        result = []
        for item in value:
            result.append(pack(item))
        end
        return result
    elif type(value) == "Dictionary":
        pairs = []
        invalid_key = False
        result = {}
        for key in value:
            packed = pack(value[key])
            pairs.append([pack(key), packed])
            if not valid(key):
                invalid_key = True
            else:
                result[key] = packed
            end
        end
        if invalid_key or "__lux_raw_bytes_v1__" in value or "__lux_raw_dict_v1__" in value:
            return {"__lux_raw_dict_v1__": pairs}
        end
        return result
    end
    return value
end

function unpack(value):
    if type(value) == "List":
        result = []
        for item in value:
            result.append(unpack(item))
        end
        return result
    elif type(value) == "Dictionary":
        if len(value) == 1 and "__lux_raw_bytes_v1__" in value:
            bytes = ByteArray()
            for item in value["__lux_raw_bytes_v1__"]:
                bytes.append(Int(item))
            end
            return raw(bytes)
        end
        result = {}
        if len(value) == 1 and "__lux_raw_dict_v1__" in value:
            for pair in value["__lux_raw_dict_v1__"]:
                result[unpack(pair[0])] = unpack(pair[1])
            end
        else:
            for key in value:
                result[key] = unpack(value[key])
            end
        end
        return result
    end
    return value
end
