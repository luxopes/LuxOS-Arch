load i18n
load common as core
load json
load settings as env
load requests
load auth

cache = []
metadata = {"stamp": "", "models": {}}

function fallback():
    result = []
    for name in ["lite", "flash", "pro", "ultra"]:
        result.append({"value": name, "label": name, "detail": i18n.t("LuxAI · katalog ověřit přes /model"), "hint": i18n.t("Dostupnost určuje API"), "efforts": []})
    end
    return result
end

function parse(payload):
    result = []
    if "m" in payload:
        for model in payload["m"]:
            if type(model) == "List" and len(model) >= 3:
                inputs = "text"
                if len(model) > 3:
                    inputs = ", ".join(model[3])
                end
                maximum = 0
                if len(model) > 4:
                    maximum = model[4]
                end
                result.append({"value": model[0], "label": model[0], "detail": model[1], "hint": inputs + "  ·  reasoning: " + ", ".join(model[2]), "efforts": model[2], "upstream": model[1], "max_output": maximum})
                if len(model) > 3:
                    result[len(result) - 1]["inputs"] = model[3]
                end
            end
        end
    elif "data" in payload:
        for model in payload["data"]:
            result.append({"value": model["id"], "label": model["id"], "detail": model.get("name", model.get("owned_by", "")), "hint": model.get("description", ""), "efforts": [], "upstream": model["id"], "context_length": model.get("context_length", model.get("context_window", 0)), "max_output": model.get("max_completion_tokens", model.get("max_output_tokens", 0))})
        end
    end
    return result
end

function list():
    if len(cache) > 0:
        return cache
    end
    if auth.is_account():
        # Ucet LuxAI nabizi jen modely s mesicnim limitem uctu.
        return [{"value": "flash", "label": "flash", "detail": i18n.t("LuxAI účet · měsíční limit Flash"), "hint": i18n.t("Účtováno na účet LuxAI"), "efforts": []}, {"value": "lite", "label": "lite", "detail": i18n.t("LuxAI účet · měsíční limit Lite"), "hint": i18n.t("Účtováno na účet LuxAI"), "efforts": []}]
    end
    try:
        endpoint = env.get("LUX_AI_ENDPOINT", "https://api.lux-ai.cz/v1/chat/completions")
        url = endpoint.replace("/chat/completions", "/models")
        response = requests.get(url, {"Authorization": "Bearer " + env.require("LUX_AI_API")})
        call response.raise_for_status()
        parsed = parse(response.json())
        for item in parsed:
            cache.append(item)
        end
    else:
        return fallback()
    end
    if len(cache) == 0:
        return fallback()
    end
    return cache
end

function context_info(selected):
    root = core.state["home"] + "/references"
    if len(cache) == 0 and exists(root + "/gateway-models.json"):
        try:
            for item in parse(json.decode(readfile(root + "/gateway-models.json"))):
                cache.append(item)
            end
        else:
            call core.record_error("models.gateway", String(last_error()))
        end
    end
    upstream = selected
    context = 0
    output = 0
    for item in cache:
        if item["value"] == selected:
            upstream = item.get("upstream", selected)
            context = item.get("context_length", 0)
            output = item.get("max_output", 0)
        end
    end
    filename = root + "/model-catalog.json"
    if exists(filename):
        stamp = core.cli(["stat", "-c", "%Y:%s", "--", filename])["stdout"].strip()
        if stamp != metadata["stamp"]:
            try:
                entries = {}
                for model in json.decode(readfile(filename)).get("data", []):
                    entries[model["id"]] = {"context": model.get("context_length", 0), "output": model.get("top_provider", {}).get("max_completion_tokens", 0)}
                end
                metadata["models"] = entries
                metadata["stamp"] = stamp
            else:
                call core.record_error("models.catalog", String(last_error()))
            end
        end
        if upstream in metadata["models"]:
            item = metadata["models"][upstream]
            if context == 0:
                context = item["context"]
            end
            if output == 0:
                output = item["output"]
            end
        end
    end
    return {"model": selected, "upstream": upstream, "context_tokens": context, "max_output_tokens": output, "known": context > 0}
end

function image_support(selected):
    # "yes"/"no" podle katalogu brány; "unknown", když model v katalogu není
    # (pak obrázek pošleme a případnou chybu ohlásí API).
    call context_info(selected)
    for item in cache:
        if item["value"] == selected and "inputs" in item:
            if "image" in item["inputs"]:
                return "yes"
            end
            return "no"
        end
    end
    return "unknown"
end
