# Pouze standardní 256barevné SGR: funguje i v terminálech bez truecolor.
background = "48;5;234"
foreground = "38;5;252"
accent = "38;5;75"
panel = background
selected = "48;5;24"
code = background

function ansi(style):
    style = style.replace("48;5;235", panel).replace("48;5;236", background).replace("48;5;237", code).replace("48;5;238", selected)
    # Reset se provede SAMOSTATNĚ. Styl '0' ani prázdné SGR pole nesmí
    # po nastavení pozadí vrátit výchozí barvy terminálu.
    parts = []
    for part in style.split(";"):
        if part != "":
            parts.append(part)
        end
    end
    if style == "0":
        parts = []
    end
    suffix = ""
    if len(parts) > 0:
        suffix = ";" + ";".join(parts)
    end
    return chr(27) + "[0m" + chr(27) + "[" + background + ";" + foreground + suffix + "m"
end
