# Události patří sezení; editor ani síťový worker nemusí importovat engine.
events = []
