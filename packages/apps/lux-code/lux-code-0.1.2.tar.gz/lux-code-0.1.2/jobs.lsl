load i18n
load text_codec as codec
load review
load activity
load common as core
load json
load time
load settings as env
load screen as ui

owned = []

function start(command, label, background=False, notify=False, kind="shell"):
    id = core.checked("date +%s%N").strip()
    base = core.state["home"] + "/jobs/" + id
    # Stavový soubor vzniká až po ukončení celé shellové úlohy.
    script = "cd " + core.quote(core.state["cwd"]) + " || exit 1\n" + command + "\n"
    writefile(base + ".sh", script)
    wrapper = core.quote(env.get("LUX_CODE_SHELL", "/bin/bash")) + " " + core.quote(base + ".sh") + "; result=$?; printf '%s' \"$result\" > " + core.quote(base + ".status")
    # Složené závorky: core.run přidává "cd ... && ", bez nich by "&" poslal na pozadí
    # celý seznam "cd && nohup" v podshellu, který drží rouru stdout otevřenou
    # až do konce úlohy – start() pak blokoval (žádný živý stream, zamrzlé TUI)
    # a $! bylo PID podshellu místo PID úlohy.
    launched = core.checked("{ nohup setsid /bin/sh -c " + core.quote(wrapper) + " > " + core.quote(base + ".log") + " 2>&1 < /dev/null & echo $!; }").strip()
    job = {"id": id, "boot_id": readfile("/proc/sys/kernel/random/boot_id").strip(), "background": background, "notify": notify, "kind": kind, "notified": False, "pid": Int(launched), "name": label, "command": command, "cwd": core.state["cwd"], "base": base}
    if background:
        job["review_capture"] = review.state["captured"]
        job["review_before"] = review.state["baseline"]
        job["review_known"] = review.state["known"]
    end
    job["identity"] = core.cli(["ps", "-p", String(job["pid"]), "-o", "lstart="])["stdout"].strip()
    owned.append(job)
    call core.atomic(base + ".json", json.encode(codec.pack(job)))
    return job
end

function get(id):
    for job in owned:
        if job["id"] == id:
            return job
        end
    end
    Error(ToolError: "Job is not owned by this session: " + id)
end

function status(job):
    result = {"id": job["id"], "pid": job["pid"], "name": job["name"], "running": True, "status": None}
    if exists(job["base"] + ".status"):
        result["running"] = False
        result["status"] = Int(readfile(job["base"] + ".status").strip())
    else:
        if job.get("boot_id", "") != "" and job["boot_id"] != readfile("/proc/sys/kernel/random/boot_id").strip():
            result["running"] = False
            result["interrupted"] = True
            return result
        end
        probe = core.cli(["kill", "-0", String(job["pid"])])
        identity = core.cli(["ps", "-p", String(job["pid"]), "-o", "lstart="])["stdout"].strip()
        if not probe["ok"] or identity == "" or identity != job.get("identity", ""):
            result["running"] = False
            result["interrupted"] = True
        end
    end
    return result
end

function stop(job):
    if job.get("boot_id", "") != "" and job["boot_id"] != readfile("/proc/sys/kernel/random/boot_id").strip():
        return {"ok": False, "error": "Job belongs to a previous boot; no signal sent."}
    end
    identity = core.cli(["ps", "-p", String(job["pid"]), "-o", "lstart="])["stdout"].strip()
    if identity == "" or identity != job.get("identity", ""):
        return {"ok": False, "error": "Process exited or PID was reused; no signal sent."}
    end
    result = core.cli(["/usr/bin/kill", "-TERM", "--", "-" + String(job["pid"])])
    if result["ok"]:
        call core.atomic(job["base"] + ".status", "143")
    end
    return result
end

# Never expose private review snapshots or raw file bytes in model results.
function started(job):
    return {"ok": True, "id": job["id"], "pid": job["pid"], "name": job["name"], "command": job["command"], "cwd": job["cwd"], "background": True, "kind": job["kind"], "log_path": job["base"] + ".log", "completion_notification": job.get("notify", False)}
end

function execute(name, args):
    if name == "start_service":
        return started(start(args["command"], args.get("name", "service"), True, True, "service"))
    elif name == "background_shell" or name == "monitor_command":
        return started(start(args["command"], args.get("name", name), True, True, name))

    elif name == "list_services":
        result = []
        for job in owned:
            if job["name"] != "model request":
                result.append(status(job))
            end
        end
        return result
    elif name == "service_logs":
        job = get(args["id"])
        return core.cli(["tail", "-n", String(core.number(args, "lines", 100)), "--", job["base"] + ".log"])
    elif name == "stop_service":
        return stop(get(args["id"]))
    elif name == "service_status":
        return status(get(args["id"]))
    elif name == "bash" or name == "run_tests":
        job = start(args["command"], name)
        ui.view["status"] = "Running · " + args["command"][0:90]
        loop:
            current = status(job)
            if not current["running"]:
                log = core.cli(["cat", "--", job["base"] + ".log"])
                return {"ok": current["status"] == 0, "status": current["status"], "stdout": log["stdout"], "stderr": "", "job": job["id"]}
            end
            if ui.cancel():
                call stop(job)
                return {"ok": False, "cancelled": True, "job": job["id"], "stdout": core.checked("tail -c 20000 -- " + core.quote(job["base"] + ".log"))}
            end
            call time.sleep(0.08)
        end
    end
    Error(ToolError: "Unknown job tool")
end

function poll():
    now = time.monotonic()
    if now - core.state.get("last_job_poll", 0.0) < 0.5:
        return
    end
    core.state["last_job_poll"] = now
    running = 0
    counts = {"shell": 0, "monitoring": 0, "služby": 0, "stahování": 0}
    for job in owned:
        if not job.get("background", False):
            continue
        end
        current = status(job)
        if current["running"]:
            running += 1
            category = "shell"
            if job.get("kind", "") == "monitor_command":
                category = "monitoring"
            elif job.get("kind", "") == "service":
                category = "služby"
            elif job.get("kind", "") == "references":
                category = "stahování"
            end
            counts[category] += 1
        elif job.get("notify", False) and not job.get("notified", False):
            job["notified"] = True
            # Log je omezený výpis; plný zůstává dostupný přes service_logs.
            log = core.cli(["tail", "-c", "16000", "--", job["base"] + ".log"])
            notice = {"id": job["id"], "name": job["name"], "status": current["status"], "interrupted": current.get("interrupted", False), "cwd": job["cwd"], "stdout": core.clean(log["stdout"])}
            if job.get("review_capture", False):
                call review.observe(job.get("review_before", {}), job.get("review_known", {}))
                call review.refresh()
            end
            activity.events.append(notice)
            outcome = "exit " + String(current["status"])
            if current.get("interrupted", False):
                outcome = i18n.t("přerušeno · výsledek neznámý")
            end
            call ui.add("notification", i18n.t("Úloha dokončena: ") + job["name"] + " · " + outcome)
        end
    end
    core.state["running_jobs"] = running
    core.state["job_counts"] = counts
end
