load common as core
load json
load settings as env
load requests
load time
load screen as ui

images = []
browser_state = {"owned_pid": None}

function picture(filename):
    filename = core.path(filename)
    mime = "image/png"
    lower = filename.lower()
    if lower.endswith(".jpg") or lower.endswith(".jpeg"):
        mime = "image/jpeg"
    elif lower.endswith(".webp"):
        mime = "image/webp"
    end
    info = core.checked("stat -c %s -- " + core.quote(filename)).strip()
    if Int(info) > 1048576:
        Error(ToolError: "Image exceeds 1 MiB; resize before attaching.")
    end
    data = core.checked("base64 -w0 -- " + core.quote(filename))
    images.append({"type": "image_url", "image_url": {"url": "data:" + mime + ";base64," + data}})
    return {"ok": True, "path": filename, "attached": True}
end

function browser(args):
    action = args["action"]
    allowed = ["open", "launch", "status", "tabs", "text", "dom", "snapshot", "eval", "click", "type", "reload", "console", "network", "sources", "css", "computed", "cascade", "screenshot", "performance", "cookies", "storage", "a11y", "geometry", "responsive", "back", "forward", "scroll", "wait"]
    if action not in allowed:
        Error(ToolError: "Unknown web_debug action")
    end
    ff = env.get("FF_RDP", env.get("HOME", "") + "/.local/bin/ff-rdp")
    prefix = [ff, "--port", env.get("LUX_CODE_BROWSER_PORT", "6010")]
    command = prefix
    if action == "open":
        ready = core.cli(prefix + ["tabs", "--no-daemon"])
        if not ready["ok"]:
            launch = prefix + ["launch", "--temp-profile"]
            if args.get("headless", True):
                launch.append("--headless")
            end
            launched = core.cli(launch)
            if not launched["ok"]:
                return launched
            end
            try:
                browser_state["owned_pid"] = json.decode(launched["stdout"])["results"]["pid"]
            else:
                browser_state["owned_pid"] = None
            end
        end
        # Firefox po launch ještě nemusí mít připravený první debugovatelný tab.
        loop:
            ready = core.cli(prefix + ["tabs", "--no-daemon"])
            if ready["ok"]:
                tabs = json.decode(ready["stdout"])
                if tabs.get("total", 0) > 0:
                    break
                end
            end
            if ui.cancel():
                return {"ok": False, "cancelled": True}
            end
            pid = browser_state["owned_pid"]
            if pid != None:
                alive = core.cli(["kill", "-0", String(pid)])
                if not alive["ok"]:
                    return ready
                end
            end
            call time.sleep(0.2)
        end
        command += ["navigate", "--no-daemon", "--with-network", core.text(args, "url")]
    elif action == "launch":
        command += ["launch", "--temp-profile"]
        if args.get("headless", True):
            command.append("--headless")
        end
    elif action == "status":
        command += ["doctor", "--no-daemon"]
    elif action == "text":
        command += ["page-text", "--no-daemon"]
    elif action == "eval":
        command += ["eval", "--no-daemon", "--stringify", core.text(args, "expression")]
    elif action == "dom" or action == "click" or action == "geometry" or action == "computed":
        command += [action, "--no-daemon", core.text(args, "selector")]
    elif action == "css":
        command += ["styles", "--no-daemon", core.text(args, "selector"), "--properties", args.get("property", "color,display,font-size,background-color,width,height,margin,padding")]
    elif action == "cascade":
        command += ["cascade", "--no-daemon", core.text(args, "selector"), "--prop", core.text(args, "property")]
    elif action == "responsive":
        command += ["responsive", "--no-daemon", core.text(args, "selector"), "--widths", args.get("widths", "375,768,1440")]
    elif action == "type":
        command += ["type", "--no-daemon", core.text(args, "selector"), args["text"], "--clear"]
    elif action == "screenshot":
        filename = core.path(args.get("path", core.state["home"] + "/artifacts/browser-" + core.state["session"] + ".png"))
        command += ["screenshot", "--no-daemon", "--output", filename]
        if args.get("full_page", False):
            command.append("--full-page")
        end
        result = core.cli(command)
        if result["ok"]:
            result["image"] = picture(filename)
        end
        return result
    elif action == "performance":
        command += ["perf", "--no-daemon", "audit"]
    elif action == "storage":
        command += ["storage", "--no-daemon", args.get("area", "local")]
    elif action == "scroll":
        command += ["scroll", "--no-daemon", "by", "--dy", String(core.number(args, "dy", 600))]
    elif action == "wait":
        command += ["wait", "--no-daemon", "--selector", core.text(args, "selector")]
    else:
        command += [action, "--no-daemon"]
        if action == "snapshot":
            command += ["--depth", String(core.number(args, "depth", 5)), "--max-chars", "30000"]
        elif action == "network":
            command.append("--detail")
        end
    end
    if args.get("filter", "") != "":
        if action == "console":
            command += ["--pattern", args["filter"]]
        elif action == "network" or action == "sources":
            command += ["--filter", args["filter"]]
        end
    end
    response = core.cli(command)
    if action == "cookies" or action == "storage" or action == "network":
        try:
            response["stdout"] = json.encode(redact(json.decode(response["stdout"]), action == "cookies" or action == "storage"))
        else:
            return response
        end
    end
    return response
end

function desktop(name, args):
    if name == "desktop_info":
        return {"session": env.get("XDG_SESSION_TYPE", "unknown"), "display": env.get("DISPLAY", ""), "wayland": env.get("WAYLAND_DISPLAY", ""), "xdotool": core.run("command -v xdotool"), "screenshot": core.run("for x in import grim; do command -v $x || true; done")}
    elif name == "desktop_screenshot":
        filename = core.path(args.get("path", core.state["home"] + "/artifacts/desktop-" + core.state["session"] + ".png"))
        if env.get("XDG_SESSION_TYPE", "") == "wayland":
            result = core.cli(["grim", filename])
        else:
            result = core.cli(["import", "-window", "root", filename])
        end
        if result["ok"]:
            result["image"] = picture(filename)
        end
        return result
    elif name == "open_url":
        return core.cli(["xdg-open", core.text(args, "url")])
    elif name == "clipboard_read":
        return core.cli(["xclip", "-selection", "clipboard", "-o"])
    elif name == "clipboard_write":
        return core.run("printf '%s' " + core.quote(args["text"]) + " | xclip -selection clipboard")
    end
    if env.get("XDG_SESSION_TYPE", "") == "wayland":
        Error(ToolError: "xdotool controls X11 only. Use web_debug for browser actions on Wayland.")
    end
    command = ["xdotool"]
    if name == "desktop_windows":
        command += ["search", "--onlyvisible", "--name", "."]
    elif name == "desktop_active_window":
        command += ["getactivewindow", "getwindowname"]
    elif name == "desktop_focus":
        command += ["windowactivate", "--sync", args["window"]]
    elif name == "desktop_click":
        command += ["mousemove", "--sync", String(args["x"]), String(args["y"]), "click", String(core.number(args, "button", 1))]
    elif name == "desktop_move":
        command += ["mousemove", "--sync", String(args["x"]), String(args["y"])]
    elif name == "desktop_type":
        command += ["type", "--clearmodifiers", "--", args["text"]]
    elif name == "desktop_key":
        command += ["key", "--clearmodifiers", args["key"]]
    elif name == "desktop_scroll":
        button = "5"
        if core.number(args, "amount", 3) < 0:
            button = "4"
        end
        command += ["click", "--repeat", String(abs(core.number(args, "amount", 3))), button]
    elif name == "desktop_mouse_position":
        command += ["getmouselocation", "--shell"]
    else:
        Error(ToolError: "Unknown desktop tool")
    end
    return core.cli(command)
end

function mobile(name, args):
    command = ["adb"]
    if args.get("device", "") != "":
        command += ["-s", args["device"]]
    end
    if name == "mobile_devices":
        command += ["devices", "-l"]
    elif name == "mobile_shell":
        command += ["shell", args["command"]]
    elif name == "mobile_tap":
        command += ["shell", "input", "tap", String(args["x"]), String(args["y"])]
    elif name == "mobile_key":
        command += ["shell", "input", "keyevent", args["key"]]
    elif name == "mobile_text":
        command += ["shell", "input", "text", core.quote(args["text"].replace(" ", "%s"))]
    elif name == "mobile_swipe":
        command += ["shell", "input", "swipe", String(args["x1"]), String(args["y1"]), String(args["x2"]), String(args["y2"])]
    elif name == "mobile_apps":
        command += ["shell", "pm", "list", "packages"]
    elif name == "mobile_open_url":
        command += ["shell", "am", "start", "-a", "android.intent.action.VIEW", "-d", core.quote(args["url"])]
    elif name == "mobile_logs":
        command += ["logcat", "-d", "-t", String(core.number(args, "lines", 100))]
    elif name == "mobile_ui":
        return core.run(core.quote(command[0]) + " " + " ".join([core.quote(x) for x in command[1:len(command)]]) + " shell uiautomator dump /sdcard/lux-code-ui.xml && " + " ".join([core.quote(x) for x in command]) + " shell cat /sdcard/lux-code-ui.xml")
    elif name == "mobile_screenshot":
        filename = core.path(args.get("path", core.state["home"] + "/artifacts/mobile-" + core.state["session"] + ".png"))
        command += ["exec-out", "screencap", "-p"]
        result = core.run(" ".join([core.quote(x) for x in command]) + " > " + core.quote(filename))
        if result["ok"]:
            result["image"] = picture(filename)
        end
        return result
    end
    return core.cli(command)
end

function web(name, args):
    if name == "web_fetch" or name == "http_request":
        response = requests.request(args.get("method", "GET"), args["url"], args.get("body", None), args.get("headers", None))
        return {"ok": response.ok, "status": response.status, "text": response.text}
    end
    key = env.get("TAVILY_API_KEY", "")
    token_file = env.get("HOME", "") + "/.pi/agent/tavily-token"
    if key == "" and exists(token_file):
        key = readfile(token_file).strip()
    end
    if key == "":
        Error(ToolError: "Set TAVILY_API_KEY or configure ~/.pi/agent/tavily-token")
    end
    endpoint = "/search"
    body = {"query": args.get("query", ""), "max_results": core.number(args, "max_results", 5)}
    if name == "web_extract":
        endpoint = "/extract"
        body = {"urls": args["urls"]}
    end
    response = requests.post("https://api.tavily.com" + endpoint, body, {"Authorization": "Bearer " + key})
    call response.raise_for_status()
    return response.json()
end

# Stejně jako místní Pi rozšíření nevracíme hodnoty cookies ani známé secret klíče.
function redact(value, values=False):
    if type(value) == "List":
        result = []
        for item in value:
            result.append(redact(item, values))
        end
        return result
    elif type(value) == "Dictionary":
        result = {}
        named_secret = False
        label = String(value.get("name", "")).lower()
        for word in ["token", "secret", "password", "authorization", "api_key", "apikey", "cookie"]:
            if word in label:
                named_secret = True
            end
        end
        for key in value:
            sensitive = False
            lower = key.lower()
            for word in ["token", "secret", "password", "authorization", "api_key", "apikey", "set-cookie"]:
                if word in lower:
                    sensitive = True
                end
            end
            if lower == "value" and (values or named_secret):
                sensitive = True
            end
            if sensitive:
                result[key] = "<redacted>"
            else:
                result[key] = redact(value[key], values)
            end
        end
        return result
    end
    return value
end
