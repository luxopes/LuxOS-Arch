# Volani nastroju, ktera model vypsal jako text do obsahu odpovedi misto kanalu tool_calls
# (GLM <arg_key>/<arg_value>, Hermes/Qwen <tool_call>{json}</tool_call>, Qwen3-Coder <function=...>).
# Rozpoznane volani se prevede na bezne tool_calls: spusti se stejnou cestou jako nativni volani
# (posuzovac safety, potvrzeni uzivatele). Neuplne nebo nejasne volani se nikdy nespusti.
load common
load json

OPEN = "<tool_call>"
CLOSE = "</tool_call>"
CUT_NUDGE = "Your last response contained a {0} tool call written as text that was cut off by the answer length limit before it was complete. It was NOT executed. Call tools only through the API tool_calls channel. Keep each call small: write a large file in several steps (write_file with the first part, then add the following parts with edit_file, replacing a unique last line with that line plus the next part). Do not repeat text you already wrote."

# --- zobrazeni pri streamovani: text od <tool_call> do </tool_call> se nezobrazuje ---

function new_filter():
    return {"hidden": False, "held": ""}
end

function partial_suffix(text, tag):
    # delka nejdelsiho konce textu, ktery muze byt zacatkem znacky (napr. "<tool")
    size = min(len(tag) - 1, len(text))
    while size > 0:
        if text.endswith(tag[:size]):
            return size
        end
        size -= 1
    end
    return 0
end

function filter_text(state, text):
    # vraci cast streamovaneho textu, kterou lze hned ukazat; zbytek (volani) se zahodi
    buffer = state["held"] + common.text(text)
    state["held"] = ""
    shown = []
    while buffer:
        if state["hidden"]:
            stop = buffer.find(CLOSE)
            if stop < 0:
                keep = partial_suffix(buffer, CLOSE)
                state["held"] = buffer[len(buffer) - keep:]
                break
            end
            state["hidden"] = False
            buffer = buffer[stop + len(CLOSE):]
        else:
            start = buffer.find(OPEN)
            if start < 0:
                keep = partial_suffix(buffer, OPEN)
                shown.append(buffer[:len(buffer) - keep])
                state["held"] = buffer[len(buffer) - keep:]
                break
            end
            shown.append(buffer[:start])
            state["hidden"] = True
            buffer = buffer[start + len(OPEN):]
        end
    end
    return "".join(shown)
end

# --- rozbor ---

function property_types(definitions):
    # {nazev nastroje: {argument: typ ze schematu}}
    output = {}
    for definition in common.fallback(definitions, []):
        fn = definition["function"]
        types = {}
        properties = common.fallback(common.fallback(fn.get("parameters"), {}).get("properties"), {})
        for key in properties.keys():
            types[key] = common.fallback(properties[key].get("type"), "string")
        end
        output[fn["name"]] = types
    end
    return output
end

function typed_value(raw, kind):
    # GLM a Qwen3-Coder posilaji hodnoty jako text; necelkove typy (cislo, bool, objekt) jsou JSON
    if kind == "string":
        return raw
    end
    try:
        return json.decode(common.strip_text(raw))
    else:
        return raw
    end
end

function one_newline(text):
    # Qwen3-Coder obaluje hodnotu jednim radkem navic na zacatku a na konci
    if text.startswith("\n"):
        text = text[1:]
    end
    if text.endswith("\n"):
        text = text[:len(text) - 1]
    end
    return text
end

function glm_pairs(body, lenient=False):
    # [[klic, hodnota], ...] z <arg_key>K</arg_key><arg_value>V</arg_value>; None pri chybe tvaru
    pairs = []
    position = body.find("<arg_key>")
    while position >= 0:
        key_end = body.find("</arg_key>", position)
        if key_end < 0:
            if lenient:
                pairs.append([common.strip_text(body[position + 9:]), ""])
                return pairs
            end
            return None
        end
        key = common.strip_text(body[position + 9:key_end])
        value_start = body.find("<arg_value>", key_end)
        if value_start < 0 or common.strip_text(body[key_end + 10:value_start]):
            if lenient:
                pairs.append([key, ""])
                return pairs
            end
            return None
        end
        value_end = body.find("</arg_value>", value_start)
        if value_end < 0:
            if lenient:
                pairs.append([key, body[value_start + 11:]])
                return pairs
            end
            return None
        end
        pairs.append([key, body[value_start + 11:value_end]])
        position = body.find("<arg_key>", value_end)
        if position < 0 and common.strip_text(body[value_end + 12:]) and not lenient:
            return None
        end
    end
    return pairs
end

function parse_glm(body, types):
    first = body.find("<arg_key>")
    name = body
    if first >= 0:
        name = body[:first]
    end
    name = common.strip_text(name)
    if not name or name not in types:
        return None
    end
    arguments = {}
    if first >= 0:
        pairs = glm_pairs(body)
        if pairs == None:
            return None
        end
        for pair in pairs:
            arguments[pair[0]] = typed_value(pair[1], types[name].get(pair[0], "string"))
        end
    end
    return {"name": name, "arguments": arguments}
end

function parse_json_call(body, types):
    value = None
    try:
        value = json.decode(common.strip_text(body))
    else:
        return None
    end
    if type(value) != "Dictionary":
        return None
    end
    fn = value
    if type(value.get("function")) == "Dictionary":
        fn = value["function"]
    end
    name = fn.get("name")
    if type(name) != "String" or name not in types:
        return None
    end
    arguments = fn.get("arguments", fn.get("parameters", {}))
    if type(arguments) == "String":
        try:
            arguments = json.decode(arguments)
        else:
            return None
        end
    end
    if arguments == None:
        arguments = {}
    end
    if type(arguments) != "Dictionary":
        return None
    end
    return {"name": name, "arguments": arguments}
end

function parse_function_call(body, types):
    # <function=NAME><parameter=K>V</parameter>...</function>
    text = common.strip_text(body)
    head_end = text.find(">")
    if not text.startswith("<function=") or head_end < 0 or not text.endswith("</function>"):
        return None
    end
    name = common.strip_text(text[10:head_end])
    if name not in types:
        return None
    end
    inner = text[head_end + 1:len(text) - 11]
    arguments = {}
    position = inner.find("<parameter=")
    if position < 0 and common.strip_text(inner):
        return None
    end
    while position >= 0:
        if common.strip_text(inner[:position]) and not arguments:
            return None
        end
        key_end = inner.find(">", position)
        value_end = inner.find("</parameter>", position)
        if key_end < 0 or value_end < 0 or value_end < key_end:
            return None
        end
        key = common.strip_text(inner[position + 11:key_end])
        arguments[key] = typed_value(one_newline(inner[key_end + 1:value_end]), types[name].get(key, "string"))
        position = inner.find("<parameter=", value_end)
        if position < 0 and common.strip_text(inner[value_end + 12:]):
            return None
        end
    end
    return {"name": name, "arguments": arguments}
end

function parse_body(body, types):
    text = common.strip_text(body)
    if text.startswith("{"):
        return parse_json_call(text, types)
    elif text.startswith("<function="):
        return parse_function_call(text, types)
    end
    return parse_glm(body, types)
end

function extract(content, definitions, finished=True):
    # {"found", "calls" [{name, arguments}], "text" (obsah bez volani), "incomplete" (useknute, bez
    # </tool_call>), "invalid" (blok, ktery neni platnym volanim nabidnuteho nastroje)}.
    # Chybejici </tool_call> na konci radne ukoncene odpovedi (finished) staci, je-li volani cele platne.
    result = {"found": False, "calls": [], "text": content, "incomplete": False, "invalid": False}
    if type(content) != "String" or OPEN not in content:
        return result
    end
    result["found"] = True
    types = property_types(definitions)
    parts = []
    position = 0
    start = content.find(OPEN)
    while start >= 0:
        parts.append(content[position:start])
        stop = content.find(CLOSE, start)
        if stop < 0:
            last = None
            if finished:
                last = parse_body(content[start + len(OPEN):], types)
            end
            if last == None:
                result["incomplete"] = True
            else:
                result["calls"].append(last)
            end
            position = len(content)
            break
        end
        call_value = parse_body(content[start + len(OPEN):stop], types)
        if call_value == None:
            result["invalid"] = True
        else:
            result["calls"].append(call_value)
        end
        position = stop + len(CLOSE)
        start = content.find(OPEN, position)
    end
    parts.append(content[position:])
    result["text"] = common.strip_text("".join(parts))
    return result
end

function incomplete_name(content):
    # nazev nastroje z useknuteho volani (pro zpravu modelu), jinak ""
    start = content.find(OPEN)
    if start < 0:
        return ""
    end
    body = common.lstrip_text(content[start + len(OPEN):])
    if body.startswith("{"):
        marker = body.find("\"name\"")
        if marker >= 0:
            rest = body[marker + 6:]
            quote = rest.find("\"")
            close = rest.find("\"", quote + 1)
            if quote >= 0 and close > quote:
                return rest[quote + 1:close]
            end
        end
        return ""
    end
    if body.startswith("<function="):
        stop = body.find(">")
        if stop > 10:
            return common.strip_text(body[10:stop])
        end
        return ""
    end
    stop = body.find("<")
    if stop < 0:
        stop = min(len(body), 80)
    end
    return common.strip_text(body[:stop])
end

# --- zobrazeni ulozeneho textu (stare zpravy, nerozpoznane bloky) ---

function longest_backticks(text):
    longest = 0
    current = 0
    for char in text:
        if char == "`":
            current += 1
            longest = max(longest, current)
        else:
            current = 0
        end
    end
    return longest
end

function readable_block(body):
    # GLM blok jako "nazev, klic: hodnota"; jine tvary beze zmeny
    first = body.find("<arg_key>")
    if first < 0:
        return common.strip_text(body)
    end
    lines = [common.strip_text(body[:first])]
    pairs = glm_pairs(body, True)
    for pair in common.fallback(pairs, []):
        lines.append("")
        lines.append(pair[0] + ":")
        lines.append(pair[1])
    end
    return "\n".join(lines)
end

function display_markdown(text):
    # Bloky <tool_call> se ukazou jako kod (ne Markdown): obsah souboru tak neztrati odsazeni
    # a radky s "#" se nezmeni v nadpisy.
    if type(text) != "String" or OPEN not in text:
        return text
    end
    parts = []
    position = 0
    start = text.find(OPEN)
    while start >= 0:
        parts.append(text[position:start])
        stop = text.find(CLOSE, start)
        body = ""
        if stop < 0:
            body = text[start + len(OPEN):]
            position = len(text)
        else:
            body = text[start + len(OPEN):stop]
            position = stop + len(CLOSE)
        end
        shown = readable_block(body)
        fence = "```"
        while len(fence) <= longest_backticks(shown):
            fence += "`"
        end
        parts.append("\n\n" + fence + "\n" + shown + "\n" + fence + "\n\n")
        if stop < 0:
            break
        end
        start = text.find(OPEN, position)
    end
    parts.append(text[position:])
    return "".join(parts)
end
