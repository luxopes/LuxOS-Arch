# lsl: internal-abi
# Testovaci ovladac bohatych bloku v celem okne LuxAI (izolovany displej, falesny server, docasny
# HOME a XDG slozky dodava test). Nikdy vstup aplikace. Posila "rich: <nazev>", fotografuje
# bubliny odpovedi do PNG, zkousi interakce (kviz, seznam, formular, tabulka, graf), ulozeni stavu
# do konverzace a jeho obnoveni po znovuotevreni; meri pamet a cas CPU.
load gtk
load gtk_ext
load app_window
load app_model
load ui_dispatch
load common
load i18n
load json
load time
load platform
load glib
load cairo
load rich_ui
load rich_draw

function proc_status(name):
    for line in readfile("/proc/self/status").split("\n"):
        if line.startswith(name + ":"):
            return Int(line[len(name) + 1:].strip().split(" ")[0])
        end
    end
    return 0
end

function cpu_seconds():
    fields = readfile("/proc/self/stat").split(") ")[1].split(" ")
    return (Int(fields[11]) + Int(fields[12])) / 100.0
end

function library_loaded(name):
    return name in readfile("/proc/self/maps")
end

function pump_for(seconds):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        call ui_dispatch.pump()
        call time.sleep(0.005)
    end
end

function wait_idle(state, seconds=15):
    deadline = time.monotonic() + seconds
    while state["current_run"] != None and time.monotonic() < deadline:
        call ui_dispatch.pump()
        call time.sleep(0.005)
    end
    call pump_for(0.25)
end

function snapshot(widget, path, palette):
    width = gtk.widget_get_allocated_width(widget)
    height = gtk.widget_get_allocated_height(widget)
    if width < 2 or height < 2:
        return [width, height]
    end
    scale = Float(rich_ui.scale_factor(widget))
    surface = rich_draw.png_surface(width, height, scale)
    cr = cairo.create(surface)
    call rich_draw.source(cr, palette["page"])
    call cairo.paint(cr)
    call __lsl_qbe_call2(__lsl_symbol("gtk_widget_draw"), platform.pointer(widget), platform.pointer(cr))
    call cairo.destroy(cr)
    call cairo.surface_write_to_png(surface, path)
    call cairo.surface_destroy(surface)
    return [width, height]
end

function last_child(container):
    children = gtk_ext.children(container)
    if not children:
        return 0
    end
    return children[len(children) - 1]
end

function cards_of(kind):
    output = []
    for card in rich_ui.registry["cards"]:
        if card["kind"] == kind and card["alive"]:
            output.append(card)
        end
    end
    return output
end

function label_text(widget):
    return gtk.label_get_text(widget)
end

function send(state, text):
    call app_window.set_input(state, text)
    call gtk.button_clicked(state["send_button"])
    call pump_for(0.05)
    call wait_idle(state)
end

fixture = json.decode(readfile(arg(1)))
call gtk.init()
call i18n.initialize(fixture["app_root"], "/nonexistent", {"LANG": fixture.get("lang", "en")})
call ui_dispatch.initialize(3)
rich_ui.registry["enabled"] = True
state = app_window.new_window(0, fixture["app_root"], fixture.get("account"), False)
state["settings"]["workdir"] = fixture["cwd"]
state["settings"]["auto_title"] = False
state["settings"]["theme"] = fixture.get("theme", "light")
state["permissions"]["policy"]["network"] = fixture.get("network", "ask")
call app_window.apply_theme(state)
call gtk.window_resize(state["widget"], fixture.get("width", 1000), fixture.get("height", 900))
call pump_for(0.3)
palette = rich_draw.theme(state["dark"]).copy()
palette["page"] = [0.984, 0.984, 0.992]
if state["dark"]:
    palette["page"] = [0.11, 0.114, 0.16]
end
result = {"dark": state["dark"], "steps": [], "librsvg_at_start": library_loaded("librsvg"), "rss_start_kb": proc_status("VmRSS")}
shots = fixture.get("shots", "")
prefix = fixture.get("prefix", "light")
cpu_before = cpu_seconds()
for step in fixture["steps"]:
    started = time.monotonic()
    cpu_start = cpu_seconds()
    rss = proc_status("VmRSS")
    call send(state, "rich: " + step)
    item = {"step": step, "seconds": time.monotonic() - started, "cpu": cpu_seconds() - cpu_start, "rss_delta_kb": proc_status("VmRSS") - rss}
    bubble = last_child(state["column"])
    if shots and bubble:
        item["size"] = snapshot(bubble, common.join(shots, prefix + "-" + step + ".png"), palette)
    end
    result["steps"].append(item)
end
result["cpu_total"] = cpu_seconds() - cpu_before
result["rss_after_kb"] = proc_status("VmRSS")
result["librsvg_after"] = library_loaded("librsvg")
# necinnost: zadna animace ani prekreslovani bez podnetu
idle_cpu = cpu_seconds()
call pump_for(1.0)
result["idle_cpu"] = cpu_seconds() - idle_cpu
result["cards"] = []
for card in rich_ui.registry["cards"]:
    if card["alive"]:
        result["cards"].append({"kind": card["kind"], "draws": card.get("draws", 0), "draw_ms": card.get("draw_ms", 0.0)})
    end
end
if fixture.get("interact"):
    actions = {}
    quizzes = cards_of("quiz")
    if quizzes:
        quiz = quizzes[0]
        call gtk.button_clicked(quiz["rows"][0]["buttons"]["1"])
        call gtk.toggle_button_set_active(quiz["rows"][1]["checks"]["0"], True)
        call gtk.toggle_button_set_active(quiz["rows"][1]["checks"]["1"], True)
        call gtk.button_clicked(quiz["rows"][1]["check_button"])
        call gtk.button_clicked(quiz["rows"][0]["hint_button"])
        actions["quiz_score"] = label_text(quiz["score"])
        actions["quiz_result_0"] = label_text(quiz["rows"][0]["result"])
        actions["quiz_result_1"] = label_text(quiz["rows"][1]["result"])
        # druhy klik na uz zodpovezenou otazku nic nezmeni
        call gtk.button_clicked(quiz["rows"][0]["buttons"]["2"])
        actions["quiz_score_after_second_click"] = label_text(quiz["score"])
    end
    checklists = cards_of("checklist")
    if checklists:
        call gtk.toggle_button_set_active(checklists[0]["checks"][1][0], True)
        actions["checklist"] = label_text(checklists[0]["progress"])
    end
    forms = cards_of("form")
    if forms:
        form = forms[0]
        call gtk.range_set_value(form["controls"]["amount"]["widget"], 5000000)
        call gtk.combo_box_set_active(form["controls"]["years"]["widget"], 1)
        call gtk.switch_set_active(form["controls"]["insurance"]["widget"], True)
        outputs = []
        for entry in form["outputs"]:
            outputs.append(label_text(entry["label"]))
        end
        actions["form_outputs"] = outputs
        actions["form_amount"] = label_text(form["controls"]["amount"]["shown"])
        actions["form_message"] = rich_ui.form_message(form)
    end
    tables = cards_of("table")
    if tables:
        table = tables[0]
        call rich_ui.table_sort({"card": table, "column": 1}, 0)
        actions["table_sorted_asc"] = rich_ui.block_state(table).get("sort")
        call rich_ui.table_sort({"card": table, "column": 1}, 0)
        actions["table_sorted"] = rich_ui.block_state(table).get("sort")
        actions["table_csv_head"] = rich_ui.table_csv(table["spec"]).split("\r\n")[0]
    end
    charts = cards_of("chart")
    if charts and charts[0].get("hits"):
        chart = charts[0]
        hit = chart["hits"][len(chart["hits"]) - 1]
        actions["chart_hit"] = rich_draw.hit_test(chart["hits"], (hit[0] + hit[2]) / 2.0, (hit[1] + hit[3]) / 2.0)
        chart["hover"] = actions["chart_hit"]
        call gtk.widget_queue_draw(chart["area"])
        actions["chart_tip"] = hit[6]
    end
    call pump_for(0.3)
    if shots:
        for kind in ["quiz", "form", "checklist", "chart", "table"]:
            found = cards_of(kind)
            if found:
                call snapshot(found[0]["widget"], common.join(shots, prefix + "-interact-" + kind + ".png"), palette)
            end
        end
    end
    call rich_ui.flush_saves()
    call pump_for(0.2)
    conversation_id = state["conversation"]["id"]
    saved = json.decode(readfile(common.join(state["store_root"], conversation_id + ".json")))
    stored = {}
    for message in saved["messages"]:
        if type(message.get("_rich")) == "Dictionary":
            for key in message["_rich"].keys():
                stored[key] = message["_rich"][key]
            end
        end
    end
    actions["stored"] = stored
    if forms and fixture.get("send_form"):
        before = len(state["conversation"]["messages"])
        call gtk.button_clicked(forms[0]["send_button"])
        call pump_for(0.1)
        call wait_idle(state)
        actions["sent_message"] = state["conversation"]["messages"][before]["content"]
    end
    # znovuotevreni konverzace z disku: stav se obnovi
    rich_ui.registry["cards"] = []
    call gtk.button_clicked(state["new_button"])
    call pump_for(0.1)
    call app_model.open_conversation(state, conversation_id)
    call pump_for(0.3)
    restored = {}
    quizzes = cards_of("quiz")
    if quizzes:
        restored["quiz_score"] = label_text(quizzes[0]["score"])
        restored["quiz_buttons_locked"] = not __lsl_qbe_call1(__lsl_symbol("gtk_widget_get_sensitive"), platform.pointer(quizzes[0]["rows"][0]["buttons"]["0"])) & 255
    end
    checklists = cards_of("checklist")
    if checklists:
        restored["checklist"] = label_text(checklists[0]["progress"])
    end
    forms = cards_of("form")
    if forms:
        restored["form_amount"] = label_text(forms[0]["controls"]["amount"]["shown"])
        restored["form_insurance"] = gtk.switch_get_active(forms[0]["controls"]["insurance"]["widget"])
    end
    tables = cards_of("table")
    if tables:
        restored["table_sort"] = rich_ui.block_state(tables[0]).get("sort")
    end
    actions["restored"] = restored
    result["actions"] = actions
end
call gtk.window_close(state["widget"])
close_deadline = time.monotonic() + 10
while state["alive"] and time.monotonic() < close_deadline:
    call ui_dispatch.pump()
    call time.sleep(0.005)
end
result["closed"] = not state["alive"]
call gtk_ext.collect_callbacks(None, None)
call ui_dispatch.close()
for worker in ui_dispatch.queues["threads"]:
    call thread_join(worker)
end
print json.encode(result)
