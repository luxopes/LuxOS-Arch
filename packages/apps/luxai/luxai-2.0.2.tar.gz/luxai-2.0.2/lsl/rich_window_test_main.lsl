# lsl: internal-abi
# Testovaci ovladac bohatych bloku v celem okne LuxAI (izolovany displej, falesny server, docasny
# HOME a XDG slozky dodava test). Nikdy vstup aplikace. Posila "rich: <nazev>", fotografuje
# bubliny odpovedi do PNG, zkousi interakce (kviz, seznam, formular, tabulka, graf), ulozeni stavu
# do konverzace a jeho obnoveni po znovuotevreni; meri pamet a cas CPU.
load gtk
load gtk_ext
load app_window
load app_model
load ui_dispatch
load common
load i18n
load json
load time
load platform
load glib
load cairo
load rich_ui
load rich_draw
load rich_quiz
load child_process

function proc_status(name):
    for line in readfile("/proc/self/status").split("\n"):
        if line.startswith(name + ":"):
            return Int(line[len(name) + 1:].strip().split(" ")[0])
        end
    end
    return 0
end

function cpu_seconds():
    fields = readfile("/proc/self/stat").split(") ")[1].split(" ")
    return (Int(fields[11]) + Int(fields[12])) / 100.0
end

function library_loaded(name):
    return name in readfile("/proc/self/maps")
end

function pump_for(seconds):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        call ui_dispatch.pump()
        call time.sleep(0.005)
    end
end

function wait_idle(state, seconds=15):
    deadline = time.monotonic() + seconds
    while state["current_run"] != None and time.monotonic() < deadline:
        call ui_dispatch.pump()
        call time.sleep(0.005)
    end
    call pump_for(0.25)
end

function snapshot(widget, path, palette):
    width = gtk.widget_get_allocated_width(widget)
    height = gtk.widget_get_allocated_height(widget)
    if width < 2 or height < 2:
        return [width, height]
    end
    scale = Float(rich_ui.scale_factor(widget))
    surface = rich_draw.png_surface(width, height, scale)
    cr = cairo.create(surface)
    call rich_draw.source(cr, palette["page"])
    call cairo.paint(cr)
    call __lsl_qbe_call2(__lsl_symbol("gtk_widget_draw"), platform.pointer(widget), platform.pointer(cr))
    call cairo.destroy(cr)
    call cairo.surface_write_to_png(surface, path)
    call cairo.surface_destroy(surface)
    return [width, height]
end

function last_child(container):
    children = gtk_ext.children(container)
    if not children:
        return 0
    end
    return children[len(children) - 1]
end

function cards_of(kind):
    output = []
    for card in rich_ui.registry["cards"]:
        if card["kind"] == kind and card["alive"]:
            output.append(card)
        end
    end
    return output
end

function label_text(widget):
    return gtk.label_get_text(widget)
end

function send(state, text):
    call app_window.set_input(state, text)
    call gtk.button_clicked(state["send_button"])
    call pump_for(0.05)
    call wait_idle(state)
end

# ---------------------------------------------------------------- kviz po strankach: skutecne
# udalosti mysi a klavesnice pres xdotool na izolovanem Xvfb (DISPLAY dodava test, nikdy :0).
# run = {"state", "fixture", "shots", "prefix", "palette"}

function root_point(widget, toplevel):
    # stred widgetu v souradnicich obrazovky
    cell = platform.buffer(16)
    address = platform.address(cell)
    call __lsl_qbe_call3(__lsl_symbol("gdk_window_get_origin"), platform.pointer(gtk.widget_get_window(toplevel)), platform.pointer(address), platform.pointer(address) + 4)
    ox = __lsl_qbe_load32(platform.pointer(address))
    oy = __lsl_qbe_load32(platform.pointer(address) + 4)
    width = gtk.widget_get_allocated_width(widget)
    height = gtk.widget_get_allocated_height(widget)
    call __lsl_qbe_call6(__lsl_symbol("gtk_widget_translate_coordinates"), platform.pointer(widget), platform.pointer(toplevel), platform.pointer(width // 2), platform.pointer(height // 2), platform.pointer(address) + 8, platform.pointer(address) + 12)
    # GDK_SCALE=2: GTK pocita v logickych bodech, X (xdotool) ve skutecnych pixelech
    scale = rich_ui.scale_factor(toplevel)
    return [(ox + __lsl_qbe_load32(platform.pointer(address) + 8)) * scale, (oy + __lsl_qbe_load32(platform.pointer(address) + 12)) * scale]
end

function xdo(run, arguments):
    display = String(common.fallback(child_process.environment().get("DISPLAY"), ""))
    if display in ["", ":0", ":0.0"]:
        Error(RuntimeError: "refusing to send input without a private display")
    end
    finished = child_process.run(["xdotool"] + arguments, run["fixture"]["cwd"], None, 10)
    if finished["exit_code"] != 0:
        Error(RuntimeError: "xdotool failed: " + finished["output"] + finished["stderr"])
    end
    call pump_for(0.03)
end

function mouse_click(run, widget):
    point = root_point(widget, run["state"]["widget"])
    call xdo(run, ["mousemove", "--sync", String(point[0]), String(point[1])])
    call xdo(run, ["click", "1"])
    call pump_for(0.08)
end

function press(run, name):
    call xdo(run, ["key", name])
    call pump_for(0.08)
end

function is_sensitive(widget):
    return __lsl_qbe_call1(__lsl_symbol("gtk_widget_is_sensitive"), platform.pointer(widget)) & 255 != 0
end

function revealed(revealer):
    return __lsl_qbe_call1(__lsl_symbol("gtk_revealer_get_reveal_child"), platform.pointer(revealer)) & 255 != 0
end

function child_text(widget):
    return label_text(__lsl_qbe_call1(__lsl_symbol("gtk_bin_get_child"), platform.pointer(widget)))
end

function is_label(widget):
    return __lsl_qbe_call2(__lsl_symbol("g_type_check_instance_is_a"), platform.pointer(widget), __lsl_qbe_call0(__lsl_symbol("gtk_label_get_type"))) & 255 != 0
end

function settle(card):
    # konec animaci (posun karet, vysunuti vysledku)
    deadline = time.monotonic() + 2.0
    while time.monotonic() < deadline:
        running = False
        for name in ["stack", "outer"]:
            if card.get(name) and gtk_ext.stack_get_transition_running(card[name]):
                running = True
            end
        end
        if not running:
            break
        end
        call pump_for(0.02)
    end
    call pump_for(0.35)
end

function quiz_view(card):
    # co je na karte videt (pro test)
    view = {"mode": card.get("mode"), "score": rich_ui.quiz_score_text(card), "state": json.decode(json.encode(rich_ui.block_state(card)))}
    if card.get("mode") == "pages":
        view["outer"] = gtk_ext.stack_get_visible_child_name(card["outer"])
        view["page"] = gtk_ext.stack_get_visible_child_name(card["stack"])
        view["position"] = label_text(card["position"])
        view["back_enabled"] = is_sensitive(card["back"])
        view["next_visible"] = gtk.widget_get_visible(card["next"])
        view["next_label"] = child_text(card["next"])
        view["stack_height"] = gtk.widget_get_allocated_height(card["stack"])
        view["card_width"] = gtk.widget_get_allocated_width(card["widget"])
        view["focus_in_quiz"] = rich_ui.quiz_focus(card) != 0
        if view["outer"] == "summary":
            view["summary"] = []
            for child in gtk_ext.children(card["summary"]):
                if is_label(child):
                    view["summary"].append(label_text(child))
                end
            end
            view["summary_rows"] = []
            for item in card.get("summary_rows", []):
                view["summary_rows"].append(child_text(item))
            end
        end
    else:
        view["rows"] = len(card["rows"])
        if card.get("score"):
            view["score_label"] = label_text(card["score"])
        end
    end
    results = {}
    for qi in rang(len(card["rows"])):
        row = card["rows"][qi]
        if row != None and gtk.widget_get_visible(row["result"]) and label_text(row["result"]):
            shown = True
            if row.get("result_revealer"):
                shown = revealed(row["result_revealer"])
            end
            if shown:
                results[String(qi)] = label_text(row["result"])
            end
        end
    end
    view["results"] = results
    return view
end

function shoot(run, widget, name):
    if run["shots"]:
        call snapshot(widget, common.join(run["shots"], run["prefix"] + "-" + name + ".png"), run["palette"])
    end
end

function stored_quiz(run):
    call rich_ui.flush_saves()
    call pump_for(0.1)
    window = run["state"]
    conversation = json.decode(readfile(common.join(window["store_root"], window["conversation"]["id"] + ".json")))
    for message in conversation["messages"]:
        if type(message.get("_rich")) == "Dictionary":
            for key in message["_rich"].keys():
                if key.startswith("quiz:"):
                    return message["_rich"][key]
                end
            end
        end
    end
    return None
end

function reopen(run):
    window = run["state"]
    ident = window["conversation"]["id"]
    rich_ui.registry["cards"] = []
    call gtk.button_clicked(window["new_button"])
    call pump_for(0.1)
    call app_model.open_conversation(window, ident)
    call pump_for(0.4)
    return cards_of("quiz")[0]
end

function script_pages(run, card):
    log = {}
    log["start"] = quiz_view(card)
    # 1. otazka mysi (spravne B), vysledek s vysvetlenim se vysune
    call mouse_click(run, card["rows"][0]["buttons"]["1"])
    call settle(card)
    log["answered_mouse"] = quiz_view(card)
    # regrese: obnoveni uctu 1,5 s po odpovedi (account_changed) bralo fokus zpet do pole pro zpravu
    call pump_for(2.5)
    log["focus_after_refresh"] = rich_ui.quiz_focus(card) != 0
    call shoot(run, card["widget"], "quiz-card")
    # Dalsi mysi: posun animaci
    call mouse_click(run, card["next"])
    log["sliding"] = gtk_ext.stack_get_transition_running(card["stack"])
    call settle(card)
    log["after_next"] = quiz_view(card)
    # klavesnice: zpet, vpred, odpoved pismenem, Enter = dalsi
    call press(run, "Left")
    call settle(card)
    log["after_left"] = quiz_view(card)
    call press(run, "Right")
    call settle(card)
    call press(run, "a")
    call settle(card)
    log["answered_key"] = quiz_view(card)
    call press(run, "Return")
    call settle(card)
    log["at_multi"] = quiz_view(card)
    # vice spravnych: 1 a 3 zaskrtne, Enter zkontroluje, dalsi Enter posune
    call press(run, "1")
    call press(run, "3")
    checks = card["rows"][2]["checks"]
    log["multi_checked"] = [gtk.toggle_button_get_active(checks["0"]), gtk.toggle_button_get_active(checks["1"]), gtk.toggle_button_get_active(checks["2"])]
    call press(run, "Return")
    call settle(card)
    log["multi_answered"] = quiz_view(card)
    call shoot(run, card["widget"], "quiz-card-multi")
    call press(run, "Return")
    call settle(card)
    # napoveda mysi, spatna odpoved klavesou B, Enter
    call mouse_click(run, card["rows"][3]["hint_button"])
    call settle(card)
    log["hint"] = [gtk.widget_get_visible(card["rows"][3]["hint"]), revealed(card["rows"][3]["hint_revealer"])]
    call press(run, "b")
    call settle(card)
    log["wrong"] = quiz_view(card)
    call press(run, "Return")
    call settle(card)
    # posledni otazku preskoci (Page Down) -> souhrn
    call press(run, "Next")
    call settle(card)
    log["summary_skip"] = quiz_view(card)
    # klik na radek souhrnu = zpet na otazku 5, odpoved C, Enter -> souhrn
    call mouse_click(run, card["summary_rows"][4])
    call settle(card)
    log["jumped"] = quiz_view(card)
    call press(run, "c")
    call settle(card)
    call press(run, "Return")
    call settle(card)
    log["summary"] = quiz_view(card)
    call shoot(run, card["widget"], "quiz-summary")
    log["stored"] = stored_quiz(run)
    # znovuotevreni konverzace: stejna stranka a odpovedi
    card = reopen(run)
    call settle(card)
    log["restored"] = quiz_view(card)
    # Zkusit znovu (mysi)
    call mouse_click(run, card["again"])
    call settle(card)
    log["again"] = quiz_view(card)
    log["stored_again"] = stored_quiz(run)
    for i in rang(5):
        call press(run, "Next")
        call settle(card)
    end
    log["empty_summary"] = quiz_view(card)
    call mouse_click(run, card["shuffle_again"])
    call settle(card)
    log["shuffled"] = quiz_view(card)
    for i in rang(5):
        call press(run, "Next")
        call settle(card)
    end
    # Zobrazit vsechny otazky -> seznam; Po jedne -> zpet na karty
    call mouse_click(run, card["show_all"])
    call settle(card)
    log["list"] = quiz_view(card)
    log["mode_tool_list"] = child_text(card["mode_tool"])
    order = rich_quiz.order(card["spec"], rich_ui.block_state(card))
    # seznam je vyssi nez okno (cast mimo viditelnou oblast): tady primo signalem, ne mysi
    call gtk.button_clicked(card["rows"][order[0]]["buttons"][String(card["spec"]["questions"][order[0]]["correct"][0])])
    call pump_for(0.1)
    log["list_answer"] = quiz_view(card)
    call shoot(run, card["widget"], "quiz-list")
    call gtk.button_clicked(card["mode_tool"])
    call settle(card)
    log["pages_again"] = quiz_view(card)
    log["mode_tool_pages"] = child_text(card["mode_tool"])
    log["stored_final"] = stored_quiz(run)
    return log
end

function script_mocniny(run, card):
    # skutecny kviz uzivatele (8 otazek): vse klavesnici, pismeno spravne odpovedi + Enter
    log = {"start": quiz_view(card)}
    call mouse_click(run, card["position"])
    letters = "abcdefghij"
    pages = []
    for qi in rang(len(card["spec"]["questions"])):
        correct = card["spec"]["questions"][qi]["correct"][0]
        display = card["rows"][qi]["display"]
        position = 0
        for i in rang(len(display)):
            if display[i] == correct:
                position = i
            end
        end
        call press(run, letters[position])
        call settle(card)
        if qi == 0:
            call shoot(run, card["widget"], "quiz-mocniny-card")
        end
        view = quiz_view(card)
        pages.append([view["page"], view["position"], view["stack_height"], len(view["results"])])
        call press(run, "Return")
        call settle(card)
    end
    log["pages"] = pages
    log["summary"] = quiz_view(card)
    call shoot(run, card["widget"], "quiz-mocniny-summary")
    return log
end

function script_motion(run, card):
    # omezeni pohybu (gtk-enable-animations = False): stranka se prepne hned, bez animace
    log = {"start": quiz_view(card), "animations": gtk.object_get_bool(gtk.settings_get_default(), "gtk-enable-animations")}
    call mouse_click(run, card["next"])
    log["running_after_click"] = gtk_ext.stack_get_transition_running(card["stack"])
    log["after_next"] = quiz_view(card)
    return log
end

function script_narrow(run, card):
    log = {"start": quiz_view(card), "window_width": gtk.widget_get_allocated_width(run["state"]["widget"])}
    call shoot(run, card["widget"], "quiz-narrow-card")
    for i in rang(len(card["spec"]["questions"])):
        call gtk.button_clicked(card["next"])
    end
    call settle(card)
    log["summary"] = quiz_view(card)
    log["again_width"] = gtk.widget_get_allocated_width(card["again"])
    log["show_all_width"] = gtk.widget_get_allocated_width(card["show_all"])
    call shoot(run, card["widget"], "quiz-narrow-summary")
    return log
end

fixture = json.decode(readfile(arg(1)))
call gtk.init()
if fixture.get("animations") == False:
    call gtk.object_set_bool(gtk.settings_get_default(), "gtk-enable-animations", False)
end
call i18n.initialize(fixture["app_root"], "/nonexistent", {"LANG": fixture.get("lang", "en")})
call ui_dispatch.initialize(3)
rich_ui.registry["enabled"] = True
state = app_window.new_window(0, fixture["app_root"], fixture.get("account"), False)
state["settings"]["workdir"] = fixture["cwd"]
state["settings"]["auto_title"] = False
state["settings"]["theme"] = fixture.get("theme", "light")
state["permissions"]["policy"]["network"] = fixture.get("network", "ask")
call app_window.apply_theme(state)
call gtk.window_resize(state["widget"], fixture.get("width", 1000), fixture.get("height", 900))
call pump_for(0.3)
palette = rich_draw.theme(state["dark"]).copy()
palette["page"] = [0.984, 0.984, 0.992]
if state["dark"]:
    palette["page"] = [0.11, 0.114, 0.16]
end
result = {"dark": state["dark"], "steps": [], "librsvg_at_start": library_loaded("librsvg"), "rss_start_kb": proc_status("VmRSS")}
shots = fixture.get("shots", "")
prefix = fixture.get("prefix", "light")
cpu_before = cpu_seconds()
for step in fixture["steps"]:
    started = time.monotonic()
    cpu_start = cpu_seconds()
    rss = proc_status("VmRSS")
    call send(state, "rich: " + step)
    item = {"step": step, "seconds": time.monotonic() - started, "cpu": cpu_seconds() - cpu_start, "rss_delta_kb": proc_status("VmRSS") - rss}
    bubble = last_child(state["column"])
    if shots and bubble:
        item["size"] = snapshot(bubble, common.join(shots, prefix + "-" + step + ".png"), palette)
    end
    result["steps"].append(item)
end
result["cpu_total"] = cpu_seconds() - cpu_before
result["rss_after_kb"] = proc_status("VmRSS")
result["librsvg_after"] = library_loaded("librsvg")
# necinnost: zadna animace ani prekreslovani bez podnetu
idle_cpu = cpu_seconds()
call pump_for(1.0)
result["idle_cpu"] = cpu_seconds() - idle_cpu
result["cards"] = []
for card in rich_ui.registry["cards"]:
    if card["alive"]:
        result["cards"].append({"kind": card["kind"], "draws": card.get("draws", 0), "draw_ms": card.get("draw_ms", 0.0)})
    end
end
if fixture.get("quiz_script"):
    run = {"state": state, "fixture": fixture, "shots": shots, "prefix": prefix, "palette": palette}
    quiz_cards = cards_of("quiz")
    script = fixture["quiz_script"]
    if script == "pages":
        result["quiz"] = script_pages(run, quiz_cards[0])
    elif script == "mocniny":
        result["quiz"] = script_mocniny(run, quiz_cards[0])
    elif script == "motion":
        result["quiz"] = script_motion(run, quiz_cards[0])
    elif script == "narrow":
        result["quiz"] = script_narrow(run, quiz_cards[0])
    end
end
if fixture.get("interact"):
    actions = {}
    quizzes = cards_of("quiz")
    if quizzes:
        quiz = quizzes[0]
        call gtk.button_clicked(quiz["rows"][0]["buttons"]["1"])
        call gtk.toggle_button_set_active(quiz["rows"][1]["checks"]["0"], True)
        call gtk.toggle_button_set_active(quiz["rows"][1]["checks"]["1"], True)
        call gtk.button_clicked(quiz["rows"][1]["check_button"])
        call gtk.button_clicked(quiz["rows"][0]["hint_button"])
        actions["quiz_score"] = rich_ui.quiz_score_text(quiz)
        actions["quiz_mode"] = quiz["mode"]
        actions["quiz_result_0"] = label_text(quiz["rows"][0]["result"])
        actions["quiz_result_1"] = label_text(quiz["rows"][1]["result"])
        # druhy klik na uz zodpovezenou otazku nic nezmeni
        call gtk.button_clicked(quiz["rows"][0]["buttons"]["2"])
        actions["quiz_score_after_second_click"] = rich_ui.quiz_score_text(quiz)
    end
    checklists = cards_of("checklist")
    if checklists:
        call gtk.toggle_button_set_active(checklists[0]["checks"][1][0], True)
        actions["checklist"] = label_text(checklists[0]["progress"])
    end
    forms = cards_of("form")
    if forms:
        form = forms[0]
        call gtk.range_set_value(form["controls"]["amount"]["widget"], 5000000)
        call gtk.combo_box_set_active(form["controls"]["years"]["widget"], 1)
        call gtk.switch_set_active(form["controls"]["insurance"]["widget"], True)
        outputs = []
        for entry in form["outputs"]:
            outputs.append(label_text(entry["label"]))
        end
        actions["form_outputs"] = outputs
        actions["form_amount"] = label_text(form["controls"]["amount"]["shown"])
        actions["form_message"] = rich_ui.form_message(form)
    end
    tables = cards_of("table")
    if tables:
        table = tables[0]
        call rich_ui.table_sort({"card": table, "column": 1}, 0)
        actions["table_sorted_asc"] = rich_ui.block_state(table).get("sort")
        call rich_ui.table_sort({"card": table, "column": 1}, 0)
        actions["table_sorted"] = rich_ui.block_state(table).get("sort")
        actions["table_csv_head"] = rich_ui.table_csv(table["spec"]).split("\r\n")[0]
    end
    charts = cards_of("chart")
    if charts and charts[0].get("hits"):
        chart = charts[0]
        hit = chart["hits"][len(chart["hits"]) - 1]
        actions["chart_hit"] = rich_draw.hit_test(chart["hits"], (hit[0] + hit[2]) / 2.0, (hit[1] + hit[3]) / 2.0)
        chart["hover"] = actions["chart_hit"]
        call gtk.widget_queue_draw(chart["area"])
        actions["chart_tip"] = hit[6]
    end
    call pump_for(0.3)
    if shots:
        for kind in ["quiz", "form", "checklist", "chart", "table"]:
            found = cards_of(kind)
            if found:
                call snapshot(found[0]["widget"], common.join(shots, prefix + "-interact-" + kind + ".png"), palette)
            end
        end
    end
    call rich_ui.flush_saves()
    call pump_for(0.2)
    conversation_id = state["conversation"]["id"]
    saved = json.decode(readfile(common.join(state["store_root"], conversation_id + ".json")))
    stored = {}
    for message in saved["messages"]:
        if type(message.get("_rich")) == "Dictionary":
            for key in message["_rich"].keys():
                stored[key] = message["_rich"][key]
            end
        end
    end
    actions["stored"] = stored
    if forms and fixture.get("send_form"):
        before = len(state["conversation"]["messages"])
        call gtk.button_clicked(forms[0]["send_button"])
        call pump_for(0.1)
        call wait_idle(state)
        actions["sent_message"] = state["conversation"]["messages"][before]["content"]
    end
    # znovuotevreni konverzace z disku: stav se obnovi
    rich_ui.registry["cards"] = []
    call gtk.button_clicked(state["new_button"])
    call pump_for(0.1)
    call app_model.open_conversation(state, conversation_id)
    call pump_for(0.3)
    restored = {}
    quizzes = cards_of("quiz")
    if quizzes:
        restored["quiz_score"] = rich_ui.quiz_score_text(quizzes[0])
        restored["quiz_buttons_locked"] = not __lsl_qbe_call1(__lsl_symbol("gtk_widget_get_sensitive"), platform.pointer(quizzes[0]["rows"][0]["buttons"]["0"])) & 255
    end
    checklists = cards_of("checklist")
    if checklists:
        restored["checklist"] = label_text(checklists[0]["progress"])
    end
    forms = cards_of("form")
    if forms:
        restored["form_amount"] = label_text(forms[0]["controls"]["amount"]["shown"])
        restored["form_insurance"] = gtk.switch_get_active(forms[0]["controls"]["insurance"]["widget"])
    end
    tables = cards_of("table")
    if tables:
        restored["table_sort"] = rich_ui.block_state(tables[0]).get("sort")
    end
    actions["restored"] = restored
    result["actions"] = actions
end
call gtk.window_close(state["widget"])
close_deadline = time.monotonic() + 10
while state["alive"] and time.monotonic() < close_deadline:
    call ui_dispatch.pump()
    call time.sleep(0.005)
end
result["closed"] = not state["alive"]
call gtk_ext.collect_callbacks(None, None)
call ui_dispatch.close()
for worker in ui_dispatch.queues["threads"]:
    call thread_join(worker)
end
print json.encode(result)
