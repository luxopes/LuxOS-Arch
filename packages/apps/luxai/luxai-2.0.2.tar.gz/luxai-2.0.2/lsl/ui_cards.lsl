load gtk
load gtk_ext
load glib
load common
load platform
load json
load time
load ui_widgets
load ui_format
load ui_data
load tool_format
load catalog
load i18n
load images
load feedback
load safety_data
load maps
load calendar
load calendar_data
load weather
load weather_data

function new_card(id, name, arguments):
    root = ui_widgets.box(True, 6, ["tool-card"])
    call gtk_ext.widget_set_margin_end(root, 40)
    head = ui_widgets.box(False, 8)
    dot = ui_widgets.box(False, 0, ["dot", "running"])
    call gtk.widget_set_valign(dot, 1)
    call ui_widgets.pack(head, dot)
    texts = ui_widgets.box(True, 1)
    top = ui_widgets.box(False, 8)
    call ui_widgets.pack(top, ui_widgets.label(i18n.translate(tool_format.label(name)), None, ["tool-name"]))
    status_label = ui_widgets.label("", None, ["dim", "small"])
    call ui_widgets.pack(top, status_label)
    spinner = gtk_ext.spinner_new()
    call gtk_ext.widget_set_no_show_all(spinner, True)
    call ui_widgets.pack(top, spinner)
    elapsed = ui_widgets.label("", None, ["tool-elapsed"])
    call ui_widgets.pack(top, elapsed)
    call ui_widgets.pack(texts, top)
    subject = tool_format.subject(name, arguments)
    if subject:
        call ui_widgets.pack(texts, ui_widgets.label(subject, None, ["tool-subject"], True, True))
    end
    call ui_widgets.pack(head, texts, True)
    call ui_widgets.pack(root, head)
    confirm = ui_widgets.box(True, 6)
    preview = ui_widgets.box(True, 4)
    details = ui_widgets.box(True, 6)
    expander = gtk_ext.expander_new(i18n.translate("Details"))
    call gtk.container_add(expander, details)
    call ui_widgets.pack(root, confirm)
    call ui_widgets.pack(root, preview)
    call ui_widgets.pack(root, expander)
    card = {"widget": root, "id": id, "name": name, "args": arguments, "prepared": None, "state": "running", "done": False, "started": time.monotonic(), "status_label": status_label, "dot": dot, "spinner": spinner, "elapsed": elapsed, "confirm": confirm, "preview": preview, "details": details, "buttons": {}, "answered": True, "kind": "", "stage": 0}
    call add_pre(details, "Arguments", String(ui_format.pretty(arguments))[:6000])
    call gtk.widget_show_all(root)
    call set_status(card, "running")
    return card
end

function add_pre(container, title, text):
    call ui_widgets.pack(container, ui_widgets.label(i18n.translate(title), None, ["dim", "small"]))
    call ui_widgets.pack(container, ui_widgets.label(text, None, ["tool-pre"], True, True))
    call gtk.widget_show_all(container)
end

function elapsed_text(seconds):
    if seconds < 2:
        return ""
    end
    remainder = String(seconds % 60)
    if len(remainder) < 2:
        remainder = "0" + remainder
    end
    return String(seconds // 60) + ":" + remainder
end

function tick(card):
    if card["state"] == "running" and not card["done"]:
        call gtk.label_set_text(card["elapsed"], elapsed_text(Int(time.monotonic() - card["started"])))
    end
end

function set_status(card, status):
    previous = card["state"]
    card["state"] = status
    for name in ui_data.STATUS_TEXT.keys():
        call gtk.widget_remove_class(card["dot"], name)
    end
    call gtk.widget_add_class(card["dot"], status)
    call gtk.label_set_text(card["status_label"], i18n.translate(ui_data.STATUS_TEXT.get(status, status)))
    if status != "waiting":
        call gtk.widget_remove_class(card["widget"], "waiting")
    end
    if status == "running":
        if previous != "running":
            card["started"] = time.monotonic()
        end
        call gtk.widget_show(card["spinner"])
        call gtk_ext.spinner_start(card["spinner"])
        call tick(card)
    else:
        call gtk_ext.spinner_stop(card["spinner"])
        call gtk.widget_hide(card["spinner"])
        if status == "waiting":
            call gtk.label_set_text(card["elapsed"], "")
        end
    end
end

function set_prepared(card, preview):
    card["prepared"] = preview
end

function scrolled_pre(text, height):
    content = ui_widgets.label(text, None, ["tool-pre"], True, True)
    lines = 0
    for line in text.split("\n"):
        lines += 1 + len(line) // 90
    end
    if lines * 16 + 20 <= height:
        return content
    end
    scroll = ui_widgets.scrolled(content)
    call gtk.scrolled_window_set_min_content_height(scroll, height)
    return scroll
end

function preview_report(card):
    container = card["confirm"]
    payload = card["prepared"]
    if not payload:
        call ui_widgets.pack(container, ui_widgets.label(i18n.translate("The report could not be prepared."), None, ["warn-text"]))
        return
    end
    kind = i18n.translate(ui_data.FEEDBACK_KINDS.get(payload.get("kind"), String(payload.get("kind"))))
    call ui_widgets.pack(container, ui_widgets.label("", "<b>" + glib.markup_escape(i18n.translate("Type:")) + "</b> " + glib.markup_escape(kind)))
    call ui_widgets.pack(container, ui_widgets.label(i18n.translate("Report text:"), None, ["dim", "small"]))
    call ui_widgets.pack(container, scrolled_pre(common.fallback(payload.get("message"), ""), 260))
    if payload.get("contact"):
        call ui_widgets.pack(container, ui_widgets.label(ui_format.format_text("Contact e-mail for a reply: {0}", payload["contact"]), None, ["small"], True))
    end
    signed = "Sent anonymously (you are not signed in)."
    if payload.get("signed_in"):
        signed = "Sent with your LuxAI account."
    end
    call ui_widgets.pack(container, ui_widgets.label(i18n.translate(signed), None, ["dim", "small"]))
    if payload.get("system") != None:
        expander = gtk_ext.expander_new(i18n.translate("System information that will be attached (anonymised)"))
        call gtk.container_add(expander, scrolled_pre(ui_format.pretty(payload["system"]), 300))
        call ui_widgets.pack(container, expander)
    else:
        call ui_widgets.pack(container, ui_widgets.label(i18n.translate("No system information will be attached."), None, ["dim", "small"]))
    end
    if payload.get("screenshot_bytes"):
        size = Int(payload["screenshot_bytes"] * 3 / 4 / 1024 + 0.5)
        expander = gtk_ext.expander_new(ui_format.format_text("Screenshot that will be attached ({0} kB)", size))
        image = images.from_data_url(common.fallback(payload.get("screenshot"), ""), 480, 300)
        if image:
            call gtk.container_add(expander, gtk.image_new_from_pixbuf(image))
            call glib.object_unref(image)
        else:
            call gtk.container_add(expander, ui_widgets.label(i18n.translate("(preview not available)"), None, ["dim", "small"]))
        end
        call ui_widgets.pack(container, expander)
    else:
        call ui_widgets.pack(container, ui_widgets.label(i18n.translate("No screenshot will be attached."), None, ["dim", "small"]))
    end
    for note in common.fallback(payload.get("notes"), []):
        call ui_widgets.pack(container, ui_widgets.label("• " + note, None, ["small"], True))
    end
end

function preview_change(card):
    args = card["args"]
    name = card["name"]
    text = ""
    if name == "send_feedback":
        call preview_report(card)
        return
    elif name in calendar_data.WRITE_TOOLS:
        call preview_calendar(card)
        return
    elif name == "write_file" and type(args.get("content")) == "String":
        lines = args["content"].split("\n")
        text = common.fallback("\n".join(lines[:12]), i18n.translate("(empty file)"))
        if len(lines) > 12:
            text += "\n… (+" + String(len(lines) - 12) + ")"
        end
    elif name == "edit_file":
        old = []
        new = []
        for line in String(args.get("old_text", "")).split("\n")[:8]:
            old.append("- " + line)
        end
        for line in String(args.get("new_text", "")).split("\n")[:8]:
            new.append("+ " + line)
        end
        text = "\n".join(old) + "\n" + "\n".join(new)
    elif name in ["run_command", "type_text"]:
        command = String(common.fallback(args.get("command"), common.fallback(args.get("text"), "")))
        if len(command) > 140:
            text = command[:4000]
        end
    end
    if text:
        call ui_widgets.pack(card["confirm"], ui_widgets.label(text, None, ["tool-pre"], True, True))
    end
end

# Udalost kalendare v karte: nazev tucne, kdy (mistni cas), misto, pripominka, poznamky
function calendar_event_box(event, dim=False):
    root = ui_widgets.box(True, 2)
    if type(event) != "Dictionary":
        return root
    end
    names = []
    if dim:
        names = ["dim"]
    end
    title = common.fallback(String(common.fallback(event.get("title"), "")), "—")
    call ui_widgets.pack(root, ui_widgets.label("", "<b>" + glib.markup_escape(title) + "</b>", names, True, True))
    for line in calendar.detail_lines(event):
        call ui_widgets.pack(root, ui_widgets.label(line, None, names + ["small"], True, True))
    end
    if type(event.get("description")) == "String" and event["description"]:
        lines = event["description"].split("\n")
        text = "\n".join(lines[:6])
        if len(lines) > 6:
            text += "\n…"
        end
        call ui_widgets.pack(root, ui_widgets.label(text[:600], None, ["dim", "small"], True, True))
    end
    return root
end

function preview_calendar(card):
    preview = card["prepared"]
    container = card["confirm"]
    if type(preview) != "Dictionary":
        return
    end
    view = ui_widgets.box(True, 6)
    if preview.get("action") == "update":
        call ui_widgets.pack(view, ui_widgets.label(i18n.translate("Before:"), None, ["dim", "small"]))
        call ui_widgets.pack(view, calendar_event_box(preview.get("before"), True))
        call ui_widgets.pack(view, ui_widgets.label(i18n.translate("After:"), None, ["dim", "small"]))
    end
    call ui_widgets.pack(view, calendar_event_box(preview.get("event")))
    event = common.fallback(preview.get("event"), {})
    if preview.get("action") in ["update", "delete"] and event.get("recurring"):
        call ui_widgets.pack(view, ui_widgets.label(i18n.translate("Repeating event – the change applies to all its occurrences."), None, ["warn-text"], True))
    end
    card["calendar_view"] = view
    call ui_widgets.pack(container, view)
end

function calendar_result(card, result):
    view = ui_widgets.box(True, 6)
    name = card["name"]
    if name == "calendar_list_events":
        events = common.fallback(result.get("events"), [])
        if not events:
            call ui_widgets.pack(view, ui_widgets.label(i18n.translate("No events in this period."), None, ["dim", "small"]))
        else:
            call ui_widgets.pack(view, ui_widgets.label(ui_format.format_text("Events: {0}", result.get("count", len(events))), None, ["dim", "small"]))
        end
        for event in events[:8]:
            call ui_widgets.pack(view, calendar_event_box(event))
        end
        more = common.fallback(result.get("count"), len(events)) - min(8, len(events))
        if more > 0:
            call ui_widgets.pack(view, ui_widgets.label(ui_format.format_text("… and {0} more", more), None, ["dim", "small"]))
        end
    else:
        headline = {"calendar_create_event": "Added to the calendar.", "calendar_update_event": "Changed in the calendar.", "calendar_delete_event": "Deleted from the calendar."}[name]
        call ui_widgets.pack(view, ui_widgets.label(i18n.translate(headline), None, ["dim", "small"]))
        call ui_widgets.pack(view, calendar_event_box(result.get("event"), name == "calendar_delete_event"))
    end
    card["calendar_view"] = view
    call ui_widgets.pack(card["preview"], view)
end

function answer(card, value):
    if card["answered"] or card["done"]:
        return
    end
    if value == "always" and (card["kind"] != "ask" or card["name"] == "send_feedback"):
        return
    end
    if value != "deny" and card["kind"] == "danger" and card["stage"] != 2:
        return
    end
    card["answered"] = True
    call gtk_ext.clear(card["confirm"])
    card["buttons"] = {}
    if value != "deny":
        call set_status(card, "running")
    end
    call card["done_callback"](card["done_state"], value)
end

function clicked(state, button):
    call answer(state["card"], state["value"])
end

function answer_button(card, row, title, value, style=""):
    names = []
    if style:
        names.append(style)
    end
    result = ui_widgets.button(title, clicked, {"card": card, "value": value}, names)
    call gtk.box_pack_end(row, result, False, True, 0)
    card["buttons"][value] = result
end

function second_step(card, button):
    if card["answered"] or card["done"]:
        return
    end
    card["stage"] = 2
    call gtk_ext.clear(card["confirm"])
    card["buttons"] = {}
    call ui_widgets.pack(card["confirm"], ui_widgets.label(i18n.translate("Are you sure? This can cause damage that cannot be undone."), None, ["warn-text"], True))
    row = ui_widgets.box(False, 6)
    call answer_button(card, row, "Yes, run it", "once", "danger-btn")
    call answer_button(card, row, "Cancel", "deny")
    call ui_widgets.pack(card["confirm"], row)
    call gtk.widget_show_all(card["confirm"])
end

function ask(card, kind, reasons, done, done_state):
    card["kind"] = kind
    card["stage"] = 1
    card["answered"] = False
    card["done_callback"] = done
    card["done_state"] = done_state
    card["buttons"] = {}
    call set_status(card, "waiting")
    call gtk.widget_add_class(card["widget"], "waiting")
    call gtk_ext.clear(card["confirm"])
    call preview_change(card)
    box = card["confirm"]
    if kind == "danger":
        call gtk.widget_add_class(card["widget"], "danger")
        call ui_widgets.pack(box, ui_widgets.label("⚠ " + i18n.translate("Potentially dangerous action"), None, ["warn-text"]))
    elif card["name"] == "send_feedback":
        call ui_widgets.pack(box, ui_widgets.label(i18n.translate("Send this report to the author of LuxOS?"), None, ["confirm-text"]))
    elif kind == "confirm" and safety_data.FETCH_UNTRUSTED_REASON in reasons:
        call ui_widgets.pack(box, ui_widgets.label("⚠ " + i18n.translate("LuxAI wants to open this web address:"), None, ["warn-text"], True))
        # cela URL pod nadpisem (v hlavicce karty je zkracena), zalamovani po znacich
        address = ui_widgets.label(String(card["args"].get("url", "")), None, ["tool-pre"], True, True)
        call gtk_ext.label_set_line_wrap_mode(address, 1)
        call ui_widgets.pack(box, address)
    elif kind == "confirm" and safety_data.WEB_TAINT_REASON in reasons:
        call ui_widgets.pack(box, ui_widgets.label("⚠ " + i18n.translate("Web content is in this conversation: check this command carefully"), None, ["warn-text"], True))
    elif kind == "confirm" and (reasons == [safety_data.ADMIN_REASON] or safety_data.EXTERNAL_ROOT_REASON in reasons):
        call ui_widgets.pack(box, ui_widgets.label("⚠ " + i18n.translate("Runs as administrator (root)"), None, ["warn-text"]))
    elif kind == "confirm":
        call ui_widgets.pack(box, ui_widgets.label("⚠ " + i18n.translate("This may access private data"), None, ["warn-text"]))
    end
    for reason in reasons:
        call ui_widgets.pack(box, ui_widgets.label("• " + i18n.translate(reason[:1].upper() + reason[1:]), None, ["small"], True))
    end
    if kind == "ask":
        call ui_widgets.pack(box, ui_widgets.label(i18n.translate("Allow LuxAI to do this?"), None, ["confirm-text"]))
    end
    row = ui_widgets.box(False, 6)
    if kind == "danger":
        next_button = ui_widgets.button("Allow once…", second_step, card, ["danger-btn"])
        card["buttons"]["next"] = next_button
        call gtk.box_pack_end(row, next_button, False, True, 0)
        call answer_button(card, row, "Deny", "deny")
    elif card["name"] == "send_feedback":
        call answer_button(card, row, "Send report", "once", "allow")
        call answer_button(card, row, "Don't send", "deny")
    else:
        call answer_button(card, row, "Allow once", "once", "allow")
        if kind == "ask":
            call answer_button(card, row, "Always for this session", "always")
        end
        call answer_button(card, row, "Deny", "deny")
    end
    call ui_widgets.pack(card["confirm"], row)
    call gtk.widget_show_all(card["confirm"])
end

function save_outbox(state, button):
    call gtk_ext.clear(state["row"])
    message = ""
    try:
        call feedback.save_outbox(state["payload"])
        message = i18n.translate("Saved. The Feedback app will send the report when you are online.")
    else:
        message = ui_format.format_text("The report could not be saved: {0}", String(last_error()))
    end
    call ui_widgets.pack(state["row"], ui_widgets.label(message, None, ["small"], True), True)
    call gtk.widget_show_all(state["row"])
end

function set_result(card, result, status):
    seconds = 0
    if card["state"] == "running":
        seconds = Int(time.monotonic() - card["started"])
    end
    card["done"] = True
    card["answered"] = True
    call set_status(card, status)
    call gtk.label_set_text(card["elapsed"], elapsed_text(seconds))
    call gtk_ext.clear(card["confirm"])
    card["buttons"] = {}
    call gtk.widget_remove_class(card["widget"], "danger")
    if type(result) != "Dictionary":
        return
    end
    text = ""
    calendar_rows = card["name"] in calendar_data.TOOLS and result.get("ok") and status == "ok"
    if status == "denied":
        text = i18n.translate("You denied this action.")
    elif status == "cancelled" and "output" not in result:
        text = i18n.translate("Stopped before running.")
    elif result.get("error"):
        text = String(result["error"])
    end
    if "output" in result:
        if text:
            text += "\n"
        end
        text += common.fallback(result.get("output"), i18n.translate("(no output)"))
        if "exit_code" in result:
            text += "\n[exit " + String(result["exit_code"]) + "]"
        end
    elif card["name"] in ["web_fetch", "web_search"] and result.get("ok"):
        text = ui_format.result_summary(card["name"], result)
    elif card["name"] in weather_data.TOOLS and result.get("ok"):
        text = weather.summary(card["name"], result)
    elif calendar_rows:
        text = calendar.summary(card["name"], result)
    elif card["name"] in MAP_CARD_TOOLS:
        if result.get("ok"):
            text = maps.summary(card["name"], result)
        else:
            text = common.fallback(maps.error_text(result), text)
        end
    elif type(result.get("content")) == "String":
        text = result["content"]
    elif result.get("ok") and not text:
        text = ui_format.result_summary(card["name"], result)
        if not text:
            clean = {}
            for key in result.keys():
                if not key.startswith("_") and key != "ok":
                    clean[key] = result[key]
                end
            end
            text = ui_format.pretty(clean, 1)
        end
    end
    lines = platform.strip(text, common.WHITESPACE).split("\n")
    short = "\n".join(lines[:4])
    if len(lines) > 4:
        short += "\n…"
    end
    if calendar_rows:
        call calendar_result(card, result)
    elif short:
        call ui_widgets.pack(card["preview"], ui_widgets.label(short[:600], None, ["tool-pre"], True, True))
    end
    if card["name"] == "screenshot" and result.get("path"):
        image = gtk.pixbuf_new_from_file_at_scale(result["path"], 320, 200, True)
        if image:
            picture = gtk.image_new_from_pixbuf(image)
            call gtk.widget_set_halign(picture, 1)
            call ui_widgets.pack(card["preview"], picture)
            call glib.object_unref(image)
        end
    end
    if card["name"] == "send_feedback" and result.get("offline") and type(result.get("_payload")) == "Dictionary":
        row = ui_widgets.box(False, 8)
        call ui_widgets.pack(row, ui_widgets.label(i18n.translate("You can save the report; the Feedback app will send it automatically later."), None, ["small"], True), True)
        call ui_widgets.pack(row, ui_widgets.button("Save and send later", save_outbox, {"row": row, "payload": result["_payload"]}, ["allow"]))
        call ui_widgets.pack(card["preview"], row)
    end
    if type(result.get("_map")) == "Dictionary":
        call route_map(card, result["_map"])
    end
    if text:
        call add_pre(card["details"], "Result", String(text)[:8000])
    end
    call gtk.widget_show_all(card["preview"])
end

MAP_CARD_TOOLS = ["map_geocode", "map_reverse", "map_nearby", "map_route", "map_transit_route", "transit_timetable", "current_location", "map_open"]

function open_route(binding, button):
    call maps.open_in_maps(binding["open"])
end

function route_map(card, route):
    # karta trasy jako v LuxAI na telefonu: obrazek mapy, barvy linek, zdroj dat, Otevrit v Mapach
    root = ui_widgets.box(True, 4)
    image = route.get("image")
    if type(image) == "String" and exists(image):
        picture = gtk.pixbuf_new_from_file_at_scale(image, 480, 270, True)
        if picture:
            widget = gtk.image_new_from_pixbuf(picture)
            call gtk.widget_set_halign(widget, 1)
            call ui_widgets.pack(root, widget)
            call glib.object_unref(picture)
        end
    end
    preview = {}
    if type(route.get("preview")) == "Dictionary":
        preview = route["preview"]
    end
    legend = []
    seen = []
    for leg in common.fallback(preview.get("legs"), []):
        if type(leg) != "Dictionary":
            continue
        end
        label = String(common.fallback(leg.get("label"), common.fallback(leg.get("mode"), "")))
        color = String(common.fallback(leg.get("color"), ""))
        key = label + "\n" + color
        if label and key not in seen and platform.regex_test("^#[0-9A-Fa-f]{6}$", color):
            seen.append(key)
            legend.append("<span foreground=\"" + color + "\">●</span> " + glib.markup_escape(label))
        end
    end
    if len(legend) > 1:
        call ui_widgets.pack(root, ui_widgets.label("", "   ".join(legend), ["small"], True))
    end
    call ui_widgets.pack(root, ui_widgets.label(i18n.translate("Map data © OpenStreetMap contributors"), None, ["dim", "small"]))
    if type(route.get("open")) == "List":
        row = ui_widgets.box(False, 8)
        button = ui_widgets.button("Open in Maps", open_route, {"open": route["open"]}, ["flat-small"])
        card["buttons"]["open_map"] = button
        call ui_widgets.pack(row, button)
        call ui_widgets.pack(root, row)
    end
    card["route_map"] = root
    call ui_widgets.pack(card["preview"], root)
end
