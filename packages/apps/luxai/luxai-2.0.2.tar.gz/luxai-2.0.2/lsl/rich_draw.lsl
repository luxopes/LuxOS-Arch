# lsl: internal-abi
# lsl: link libcairo.so.2 libpango-1.0.so.0 libpangocairo-1.0.so.0 libglib-2.0.so.0 libgobject-2.0.so.0
# Kresleni bohatych bloku v cairo (spolecne pro okno, export PNG/SVG a testy): barvy svetleho
# a tmaveho vzhledu, text pres Pango, grafy (sloupcovy, vodorovny, cara, plocha, body, kolac, prstenec)
# a vyhledani bodu pod mysi pro popisky.
load cairo
load pango
load math
load common
load platform
load rich_expr

LIGHT = {"dark": False, "bg": [1.0, 1.0, 1.0], "fg": [0.114, 0.114, 0.169], "dim": [0.114, 0.114, 0.169, 0.58], "grid": [0.0, 0.0, 0.0, 0.08], "axis": [0.0, 0.0, 0.0, 0.28], "accent": [0.239, 0.482, 1.0], "tip": [0.13, 0.14, 0.2, 0.94], "tip_fg": [1.0, 1.0, 1.0], "node": [0.94, 0.95, 0.99], "node_border": [0.239, 0.482, 1.0, 0.55], "palette": ["#3d7bff", "#f28c28", "#1f9d55", "#e5484d", "#8e5cf7", "#0098b3", "#d6409f", "#8a8f00", "#6b7280", "#b45309", "#0e7490", "#be123c"]}
DARK = {"dark": True, "bg": [0.149, 0.157, 0.22], "fg": [0.925, 0.933, 0.969], "dim": [0.925, 0.933, 0.969, 0.6], "grid": [1.0, 1.0, 1.0, 0.09], "axis": [1.0, 1.0, 1.0, 0.3], "accent": [0.29, 0.49, 1.0], "tip": [0.96, 0.96, 0.99, 0.96], "tip_fg": [0.1, 0.1, 0.15], "node": [0.2, 0.21, 0.3], "node_border": [0.42, 0.6, 1.0, 0.7], "palette": ["#6b9bff", "#ffa552", "#3ccf8e", "#ff6b6f", "#a98bff", "#2fc6dd", "#f06cbb", "#c2c84a", "#9ca3af", "#f59e0b", "#22d3ee", "#fb7185"]}
FONT = "Sans"

function theme(dark):
    if dark:
        return DARK
    end
    return LIGHT
end

function rgb(color):
    # "#rrggbb"/"#rgb" -> [r, g, b]
    text = String(color).lstrip("#")
    if len(text) == 3:
        text = text[0] + text[0] + text[1] + text[1] + text[2] + text[2]
    end
    if len(text) != 6:
        return [0.5, 0.5, 0.5]
    end
    digits = "0123456789abcdef"
    values = []
    for index in [0, 2, 4]:
        high = digits.find(text[index].lower())
        low = digits.find(text[index + 1].lower())
        if high < 0 or low < 0:
            return [0.5, 0.5, 0.5]
        end
        values.append((high * 16 + low) / 255.0)
    end
    return values
end

function source(cr, color, alpha=1.0):
    if len(color) > 3:
        call cairo.set_source_rgba(cr, color[0], color[1], color[2], color[3] * alpha)
    else:
        call cairo.set_source_rgba(cr, color[0], color[1], color[2], alpha)
    end
end

function series_color(palette, spec_color, index):
    if spec_color:
        return rgb(spec_color)
    end
    return rgb(palette["palette"][index % len(palette["palette"])])
end

function layout(cr, text, size=9.0, bold=False, width=0, markup=False):
    item = pango.cairo_create_layout(cr)
    weight = ""
    if bold:
        weight = " Bold"
    end
    call pango.layout_set_font(item, FONT + weight + " " + String(size))
    if markup:
        call pango.layout_set_markup(item, text)
    else:
        call pango.layout_set_text(item, String(text))
    end
    if width > 0:
        call pango.layout_set_width(item, Int(width))
        call pango.layout_set_ellipsize(item, 3)
    end
    return item
end

function text_size(cr, text, size=9.0, bold=False):
    item = layout(cr, text, size, bold)
    result = pango.layout_get_pixel_size(item)
    call pango.layout_unref(item)
    return result
end

function draw_text(cr, text, x, y, color, size=9.0, bold=False, align=0, width=0, alpha=1.0):
    # align: 0 vlevo, 1 na stred, 2 vpravo od x; y = horni okraj textu; vraci [sirka, vyska]
    item = layout(cr, text, size, bold, width)
    extent = pango.layout_get_pixel_size(item)
    left = x
    if align == 1:
        left = x - extent[0] / 2.0
    elif align == 2:
        left = x - extent[0]
    end
    call source(cr, color, alpha)
    call cairo.move_to(cr, left, y)
    call pango.cairo_show_layout(cr, item)
    call pango.layout_unref(item)
    return extent
end

function rounded(cr, x, y, width, height, radius):
    radius = max(0.0, min(radius, width / 2.0, height / 2.0))
    call cairo.new_path(cr)
    if radius <= 0.5:
        call cairo.rectangle(cr, x, y, width, height)
        return
    end
    call cairo.rounded_rectangle(cr, x, y, width, height, radius)
end

# ---------------------------------------------------------------- osy

function nice_number(value, round_up):
    if value <= 0:
        return 1.0
    end
    exponent = math.floor(math.log10(value))
    fraction = value / power10(exponent)
    nice = 10.0
    if round_up:
        if fraction <= 1.0:
            nice = 1.0
        elif fraction <= 2.0:
            nice = 2.0
        elif fraction <= 2.5:
            nice = 2.5
        elif fraction <= 5.0:
            nice = 5.0
        end
    else:
        if fraction < 1.5:
            nice = 1.0
        elif fraction < 3.0:
            nice = 2.0
        elif fraction < 7.0:
            nice = 5.0
        end
    end
    return nice * power10(exponent)
end

function power10(exponent):
    if exponent >= 0:
        return 10.0 ^ exponent
    end
    return 1.0 / (10.0 ^ (-exponent))
end

function ticks(low, high, count=5):
    # "hezke" znacky osy: [min, max, krok, [hodnoty]]
    if high < low:
        swap = low
        low = high
        high = swap
    end
    if high == low:
        if high == 0:
            high = 1.0
        else:
            spread = abs(high) * 0.1
            low = low - spread
            high = high + spread
        end
    end
    spread = nice_number(high - low, False)
    step = nice_number(spread / max(1, count - 1), True)
    start = math.floor(low / step) * step
    stop = math.ceil(high / step) * step
    values = []
    value = start
    guard = 0
    while value <= stop + step * 0.5 and guard < 50:
        values.append(value)
        value = start + step * (len(values))
        guard += 1
    end
    return [start, stop, step, values]
end

function compact(value, step=0):
    # popisek osy: 1 200 -> 1.2k, 3 400 000 -> 3.4M; desetinna mista podle kroku
    number = Float(value)
    magnitude = abs(number)
    if magnitude >= 1.0e9:
        return trim(rich_expr.fixed(number / 1.0e9, 1)) + "G"
    elif magnitude >= 1.0e6:
        return trim(rich_expr.fixed(number / 1.0e6, 1)) + "M"
    elif magnitude >= 1.0e4:
        return trim(rich_expr.fixed(number / 1.0e3, 1)) + "k"
    end
    decimals = 0
    if step > 0:
        # nejmene desetinnych mist, se kterymi je krok cele cislo (2.5 -> 1, 0.25 -> 2)
        while decimals < 6 and abs(step * power10(decimals) - math.floor(step * power10(decimals) + 0.5)) > 1.0e-6:
            decimals += 1
        end
    end
    return trim(rich_expr.fixed(number, decimals))
end

function trim(text):
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    end
    if text == "-0":
        return "0"
    end
    return text
end

# ---------------------------------------------------------------- graf

function chart_series_values(spec):
    # [kategorie, serie s hodnotami] pro sloupcove/carove grafy s kategoriemi
    count = len(spec["categories"])
    for item in spec["series"]:
        count = max(count, len(item["values"]))
    end
    categories = spec["categories"].copy()
    while len(categories) < count:
        categories.append(String(len(categories) + 1))
    end
    return categories[:count]
end

function value_range(spec, categories):
    low = None
    high = None
    stacked = spec["stacked"] and spec["type"] in ["bar", "hbar", "area"]
    if spec["numeric_x"]:
        for item in spec["series"]:
            for point in item["points"]:
                if low == None or point[1] < low:
                    low = point[1]
                end
                if high == None or point[1] > high:
                    high = point[1]
                end
            end
        end
    elif stacked:
        for index in rang(len(categories)):
            positive = 0.0
            negative = 0.0
            for item in spec["series"]:
                if index < len(item["values"]) and item["values"][index] != None:
                    value = item["values"][index]
                    if value >= 0:
                        positive += value
                    else:
                        negative += value
                    end
                end
            end
            if low == None or negative < low:
                low = negative
            end
            if high == None or positive > high:
                high = positive
            end
        end
    else:
        for item in spec["series"]:
            for value in item["values"]:
                if value != None:
                    if low == None or value < low:
                        low = value
                    end
                    if high == None or value > high:
                        high = value
                    end
                end
            end
        end
    end
    if low == None:
        low = 0.0
        high = 1.0
    end
    if spec["type"] in ["bar", "hbar", "area"]:
        low = min(low, 0.0)
        high = max(high, 0.0)
    end
    if spec["y_min"] != None:
        low = spec["y_min"]
    end
    if spec["y_max"] != None:
        high = spec["y_max"]
    end
    return [Float(low), Float(high)]
end

function x_range(spec):
    low = None
    high = None
    for item in spec["series"]:
        for point in item["points"]:
            if low == None or point[0] < low:
                low = point[0]
            end
            if high == None or point[0] > high:
                high = point[0]
            end
        end
    end
    if low == None:
        return [0.0, 1.0]
    end
    return [Float(low), Float(high)]
end

function value_text(spec, value):
    return rich_expr.format_value(value, "", spec["unit"])
end

function legend_entries(spec, palette):
    entries = []
    if spec["type"] in ["pie", "donut"]:
        values = spec["series"][0]["values"]
        categories = chart_series_values(spec)
        for index in rang(len(values)):
            label = ""
            if index < len(categories):
                label = categories[index]
            end
            entries.append([label, series_color(palette, "", index)])
        end
        return entries
    end
    if len(spec["series"]) < 2 and not spec["series"][0]["name"]:
        return entries
    end
    index = 0
    for item in spec["series"]:
        name = item["name"]
        if not name:
            name = "Series " + String(index + 1)
        end
        entries.append([name, series_color(palette, item["color"], index)])
        index += 1
    end
    return entries
end

function draw_legend(cr, entries, x, y, width, palette):
    # vraci vysku legendy (radky se zalomi)
    if not entries:
        return 0
    end
    cursor = x
    line = y
    height = 16
    for entry in entries:
        size = text_size(cr, entry[0], 8.5)
        needed = 14 + size[0] + 14
        if cursor > x and cursor + needed > x + width:
            cursor = x
            line += height
        end
        call source(cr, entry[1])
        call rounded(cr, cursor, line + 3, 10, 10, 2.5)
        call cairo.fill(cr)
        call draw_text(cr, entry[0], cursor + 14, line, palette["fg"], 8.5, False, 0, 0, 0.85)
        cursor += needed
    end
    return line - y + height + 4
end

function draw_chart(cr, spec, width, height, palette, hover=None):
    # nakresli graf do obdelniku 0,0 - width,height; vraci seznam oblasti pro popisky
    hits = []
    top = 8.0
    if spec["title"]:
        size = draw_text(cr, spec["title"], width / 2.0, top, palette["fg"], 10.5, True, 1, width - 16)
        top += size[1] + 6
    end
    if spec["type"] in ["function", "plane"]:
        hits = draw_plot(cr, spec, 0.0, top, width, height - top, palette, hover)
        if hover != None:
            for item in hits:
                if item[4] == hover[0] and item[5] == hover[1]:
                    call draw_tooltip(cr, item, width, height, palette)
                end
            end
        end
        return hits
    end
    entries = legend_entries(spec, palette)
    if spec["type"] in ["pie", "donut"]:
        hits = draw_pie(cr, spec, 8.0, top, width - 16.0, height - top - 8.0, palette, entries, hover)
    else:
        top += draw_legend(cr, entries, 12.0, top, width - 24.0, palette)
        hits = draw_axes_chart(cr, spec, 0.0, top, width, height - top, palette, hover)
    end
    if hover != None:
        for item in hits:
            if item[4] == hover[0] and item[5] == hover[1]:
                call draw_tooltip(cr, item, width, height, palette)
            end
        end
    end
    return hits
end

function draw_tooltip(cr, item, width, height, palette):
    text = item[6]
    size = text_size(cr, text, 9.0)
    box_width = size[0] + 14
    box_height = size[1] + 8
    x = (item[0] + item[2]) / 2.0 - box_width / 2.0
    y = item[1] - box_height - 6
    if y < 2:
        y = item[3] + 6
    end
    x = max(2.0, min(width - box_width - 2.0, x))
    y = max(2.0, min(height - box_height - 2.0, y))
    call source(cr, palette["tip"])
    call rounded(cr, x, y, box_width, box_height, 5)
    call cairo.fill(cr)
    call draw_text(cr, text, x + 7, y + 4, palette["tip_fg"], 9.0)
end

function draw_axes_chart(cr, spec, x0, y0, width, height, palette, hover):
    hits = []
    kind = spec["type"]
    horizontal = kind == "hbar"
    categories = []
    if not spec["numeric_x"]:
        categories = chart_series_values(spec)
    end
    values = value_range(spec, categories)
    scale = ticks(values[0], values[1], 5)
    if spec["y_min"] != None:
        scale[0] = Float(spec["y_min"])
    end
    if spec["y_max"] != None:
        scale[1] = Float(spec["y_max"])
    end
    low = scale[0]
    high = scale[1]
    if high <= low:
        high = low + 1
    end
    tick_labels = []
    label_width = 0
    for value in scale[3]:
        if value >= low - 1.0e-9 and value <= high + 1.0e-9:
            label = compact(value, scale[2])
            if spec["unit"] and value == scale[3][len(scale[3]) - 1]:
                label += " " + spec["unit"]
            end
            tick_labels.append([value, label])
            label_width = max(label_width, text_size(cr, label, 8.0)[0])
        end
    end
    left = x0 + 10.0
    if spec["y_label"] and not horizontal:
        left += 16
    end
    bottom = y0 + height - 22.0
    if spec["x_label"]:
        bottom -= 16
    end
    right = x0 + width - 14.0
    top = y0 + 6.0
    category_width = 0
    if horizontal:
        for name in categories:
            category_width = max(category_width, min(140, text_size(cr, name, 8.5)[0]))
        end
        left += category_width + 8
    else:
        left += label_width + 6
    end
    plot_width = max(10.0, right - left)
    plot_height = max(10.0, bottom - top)
    # mrizka a popisky hodnot
    for entry in tick_labels:
        fraction = (entry[0] - low) / (high - low)
        call source(cr, palette["grid"])
        call cairo.set_line_width(cr, 1.0)
        if horizontal:
            gx = Int(left + fraction * plot_width) + 0.5
            call cairo.move_to(cr, gx, top)
            call cairo.line_to(cr, gx, bottom)
            call cairo.stroke(cr)
            call draw_text(cr, entry[1], gx, bottom + 4, palette["dim"], 8.0, False, 1)
        else:
            gy = Int(bottom - fraction * plot_height) + 0.5
            call cairo.move_to(cr, left, gy)
            call cairo.line_to(cr, right, gy)
            call cairo.stroke(cr)
            call draw_text(cr, entry[1], left - 6, gy - 7, palette["dim"], 8.0, False, 2)
        end
    end
    # osa (nula)
    call source(cr, palette["axis"])
    if horizontal:
        zero = left + (max(low, min(high, 0.0)) - low) / (high - low) * plot_width
        call cairo.move_to(cr, Int(zero) + 0.5, top)
        call cairo.line_to(cr, Int(zero) + 0.5, bottom)
    else:
        zero = bottom - (max(low, min(high, 0.0)) - low) / (high - low) * plot_height
        call cairo.move_to(cr, left, Int(zero) + 0.5)
        call cairo.line_to(cr, right, Int(zero) + 0.5)
    end
    call cairo.stroke(cr)
    if spec["x_label"]:
        call draw_text(cr, spec["x_label"], left + plot_width / 2.0, y0 + height - 16, palette["dim"], 8.5, False, 1)
    end
    if spec["y_label"] and not horizontal:
        call cairo.save(cr)
        call cairo.translate(cr, x0 + 4, top + plot_height / 2.0)
        call cairo.rotate(cr, -math.PI / 2.0)
        call draw_text(cr, spec["y_label"], 0, 0, palette["dim"], 8.5, False, 1)
        call cairo.restore(cr)
    end
    frame = {"left": left, "top": top, "width": plot_width, "height": plot_height, "low": low, "high": high, "bottom": bottom, "right": right}
    if spec["numeric_x"]:
        return draw_points_chart(cr, spec, frame, palette, hover)
    end
    count = max(1, len(categories))
    band = plot_width / count
    if horizontal:
        band = plot_height / count
    end
    # popisky kategorii (preskocit, kdyz se nevejdou)
    step = 1
    if not horizontal:
        widest = 0
        for name in categories:
            widest = max(widest, min(120, text_size(cr, name, 8.5)[0]))
        end
        while step < count and widest + 8 > band * step:
            step += 1
        end
    end
    for index in rang(len(categories)):
        if index % step != 0:
            continue
        end
        if horizontal:
            cy = top + band * index + band / 2.0
            call draw_text(cr, categories[index], left - 8, cy - 7, palette["dim"], 8.5, False, 2, 140)
        else:
            cx = left + band * index + band / 2.0
            call draw_text(cr, categories[index], cx, bottom + 4, palette["dim"], 8.5, False, 1, Int(band * step - 4))
        end
    end
    series_count = len(spec["series"])
    if kind in ["bar", "hbar"]:
        stacked = spec["stacked"]
        group = band * 0.72
        bar = group
        if not stacked:
            bar = group / series_count
        end
        positive = []
        negative = []
        for index in rang(count):
            positive.append(0.0)
            negative.append(0.0)
        end
        for s in rang(series_count):
            item = spec["series"][s]
            color = series_color(palette, item["color"], s)
            for index in rang(len(item["values"])):
                value = item["values"][index]
                if value == None or index >= count:
                    continue
                end
                base = 0.0
                if stacked:
                    if value >= 0:
                        base = positive[index]
                        positive[index] += value
                    else:
                        base = negative[index]
                        negative[index] += value
                    end
                end
                start = (max(low, min(high, base)) - low) / (high - low)
                stop = (max(low, min(high, base + value)) - low) / (high - low)
                offset = band * index + (band - group) / 2.0
                if not stacked:
                    offset += bar * s
                end
                rect = []
                if horizontal:
                    a = left + min(start, stop) * plot_width
                    b = left + max(start, stop) * plot_width
                    rect = [a, top + offset, max(1.0, b - a), max(1.0, bar - 1)]
                else:
                    a = bottom - max(start, stop) * plot_height
                    b = bottom - min(start, stop) * plot_height
                    rect = [left + offset, a, max(1.0, bar - 1), max(1.0, b - a)]
                end
                alpha = 1.0
                if hover != None and not (hover[0] == s and hover[1] == index):
                    alpha = 0.55
                end
                call source(cr, color, alpha)
                call rounded(cr, rect[0], rect[1], rect[2], rect[3], min(3.0, bar / 4.0))
                call cairo.fill(cr)
                hits.append([rect[0], rect[1], rect[0] + rect[2], rect[1] + rect[3], s, index, tip_text(spec, s, categories[index], value)])
            end
        end
        return hits
    end
    # cara / plocha s kategoriemi
    totals = []
    for index in rang(count):
        totals.append(0.0)
    end
    for s in rang(series_count):
        item = spec["series"][s]
        color = series_color(palette, item["color"], s)
        points = []
        bases = []
        for index in rang(min(count, len(item["values"]))):
            value = item["values"][index]
            if value == None:
                points.append(None)
                bases.append(None)
                continue
            end
            base = 0.0
            if kind == "area" and spec["stacked"]:
                base = totals[index]
                totals[index] += value
                value = totals[index]
            end
            px = left + band * index + band / 2.0
            py = bottom - (max(low, min(high, value)) - low) / (high - low) * plot_height
            by = bottom - (max(low, min(high, base)) - low) / (high - low) * plot_height
            points.append([px, py])
            bases.append([px, by])
            hits.append([px - 6, py - 6, px + 6, py + 6, s, index, tip_text(spec, s, categories[index], item["values"][index])])
        end
        call draw_series_line(cr, points, bases, color, kind == "area", hover != None and hover[0] == s)
    end
    return hits
end

function tip_text(spec, series_index, label, value):
    name = spec["series"][series_index]["name"]
    text = value_text(spec, value)
    if label:
        text = label + ": " + text
    end
    if name and len(spec["series"]) > 1:
        text = name + " · " + text
    end
    return text
end

function draw_series_line(cr, points, bases, color, area, highlighted):
    # usek po useku (None preruseni); plocha s pruhlednou vyplni k zakladne
    segments = []
    current = []
    current_base = []
    for index in rang(len(points)):
        if points[index] == None:
            if current:
                segments.append([current, current_base])
            end
            current = []
            current_base = []
        else:
            current.append(points[index])
            current_base.append(bases[index])
        end
    end
    if current:
        segments.append([current, current_base])
    end
    for segment in segments:
        line = segment[0]
        if area and len(line) > 1:
            call cairo.new_path(cr)
            call cairo.move_to(cr, line[0][0], line[0][1])
            for point in line[1:]:
                call cairo.line_to(cr, point[0], point[1])
            end
            base = segment[1]
            index = len(base) - 1
            while index >= 0:
                call cairo.line_to(cr, base[index][0], base[index][1])
                index -= 1
            end
            call cairo.close_path(cr)
            call source(cr, color, 0.22)
            call cairo.fill(cr)
        end
        call cairo.new_path(cr)
        call cairo.move_to(cr, line[0][0], line[0][1])
        for point in line[1:]:
            call cairo.line_to(cr, point[0], point[1])
        end
        call source(cr, color)
        width = 2.0
        if highlighted:
            width = 3.0
        end
        call cairo.set_line_width(cr, width)
        call cairo.set_line_join(cr, 1)
        call cairo.set_line_cap(cr, 1)
        call cairo.stroke(cr)
        if len(line) <= 40:
            for point in line:
                call cairo.new_path(cr)
                call cairo.arc(cr, point[0], point[1], 3.0, 0, 2 * math.PI)
                call source(cr, color)
                call cairo.fill(cr)
            end
        end
    end
end

function draw_points_chart(cr, spec, frame, palette, hover):
    hits = []
    span = x_range(spec)
    scale = ticks(span[0], span[1], 6)
    low = scale[0]
    high = scale[1]
    if high <= low:
        high = low + 1
    end
    # popisky osy x
    last_right = -1000.0
    for value in scale[3]:
        if value < low - 1.0e-9 or value > high + 1.0e-9:
            continue
        end
        gx = frame["left"] + (value - low) / (high - low) * frame["width"]
        label = compact(value, scale[2])
        size = text_size(cr, label, 8.0)
        if gx - size[0] / 2.0 > last_right + 6:
            call draw_text(cr, label, gx, frame["bottom"] + 4, palette["dim"], 8.0, False, 1)
            last_right = gx + size[0] / 2.0
        end
        call source(cr, palette["grid"])
        call cairo.set_line_width(cr, 1.0)
        call cairo.move_to(cr, Int(gx) + 0.5, frame["top"])
        call cairo.line_to(cr, Int(gx) + 0.5, frame["bottom"])
        call cairo.stroke(cr)
    end
    kind = spec["type"]
    for s in rang(len(spec["series"])):
        item = spec["series"][s]
        color = series_color(palette, item["color"], s)
        ordered = item["points"]
        if kind != "scatter":
            ordered = sort_points(item["points"])
        end
        points = []
        bases = []
        index = 0
        for point in ordered:
            px = frame["left"] + (point[0] - low) / (high - low) * frame["width"]
            py = frame["bottom"] - (max(frame["low"], min(frame["high"], point[1])) - frame["low"]) / (frame["high"] - frame["low"]) * frame["height"]
            by = frame["bottom"] - (max(frame["low"], min(frame["high"], 0.0)) - frame["low"]) / (frame["high"] - frame["low"]) * frame["height"]
            points.append([px, py])
            bases.append([px, by])
            hits.append([px - 6, py - 6, px + 6, py + 6, s, index, tip_text(spec, s, "(" + compact(point[0], scale[2]) + ", " + compact(point[1]) + ")", point[1]).replace(": " + value_text(spec, point[1]), "")])
            index += 1
        end
        if kind == "scatter":
            for point in points:
                call cairo.new_path(cr)
                call cairo.arc(cr, point[0], point[1], 4.0, 0, 2 * math.PI)
                call source(cr, color, 0.8)
                call cairo.fill(cr)
            end
        else:
            call draw_series_line(cr, points, bases, color, kind == "area", hover != None and hover[0] == s)
        end
    end
    return hits
end

function sort_points(points):
    # stabilni razeni podle x (vlozenim pro male, sluckou pro velke seznamy)
    if len(points) <= 1:
        return points.copy()
    end
    middle = len(points) // 2
    left = sort_points(points[:middle])
    right = sort_points(points[middle:])
    output = []
    i = 0
    j = 0
    while i < len(left) and j < len(right):
        if right[j][0] < left[i][0]:
            output.append(right[j])
            j += 1
        else:
            output.append(left[i])
            i += 1
        end
    end
    while i < len(left):
        output.append(left[i])
        i += 1
    end
    while j < len(right):
        output.append(right[j])
        j += 1
    end
    return output
end

function draw_pie(cr, spec, x, y, width, height, palette, entries, hover):
    hits = []
    values = spec["series"][0]["values"]
    total = 0.0
    for value in values:
        if value != None and value > 0:
            total += value
        end
    end
    legend_width = 0
    for entry in entries:
        legend_width = max(legend_width, text_size(cr, entry[0] + "  100 %", 8.5)[0] + 18)
    end
    legend_width = min(legend_width, width * 0.45)
    radius = max(10.0, min((width - legend_width - 16) / 2.0, height / 2.0) - 4)
    cx = x + radius + 4
    cy = y + height / 2.0
    if total <= 0:
        call draw_text(cr, "No data", cx, cy - 7, palette["dim"], 9.0, False, 1)
        return hits
    end
    angle = -math.PI / 2.0
    categories = chart_series_values(spec)
    for index in rang(len(values)):
        value = values[index]
        if value == None or value <= 0:
            continue
        end
        sweep = value / total * 2 * math.PI
        color = series_color(palette, "", index)
        offset = 0.0
        if hover != None and hover[1] == index:
            offset = 5.0
        end
        middle = angle + sweep / 2.0
        ox = math.cos(middle) * offset
        oy = math.sin(middle) * offset
        call cairo.new_path(cr)
        call cairo.move_to(cr, cx + ox, cy + oy)
        call cairo.arc(cr, cx + ox, cy + oy, radius, angle, angle + sweep)
        call cairo.close_path(cr)
        call source(cr, color)
        call cairo.fill_preserve(cr)
        call source(cr, palette["bg"])
        call cairo.set_line_width(cr, 1.5)
        call cairo.stroke(cr)
        label = ""
        if index < len(categories):
            label = categories[index]
        end
        percent = rich_expr.fixed(value / total * 100, 1)
        text = label + ": " + value_text(spec, value) + " (" + trim(percent) + " %)"
        # oblast pro popisek: ctverec kolem stredu vyseci
        reach = 0.62
        if spec["type"] == "donut":
            reach = 0.78
        end
        hx = cx + math.cos(middle) * radius * reach
        hy = cy + math.sin(middle) * radius * reach
        hits.append([hx - radius * 0.3, hy - radius * 0.3, hx + radius * 0.3, hy + radius * 0.3, 0, index, text, cx, cy, radius, angle, angle + sweep])
        if sweep > 0.35 and radius > 50:
            call draw_text(cr, trim(rich_expr.fixed(value / total * 100, 0)) + " %", hx, hy - 7, [1.0, 1.0, 1.0], 8.5, True, 1)
        end
        angle += sweep
    end
    if spec["type"] == "donut":
        call cairo.new_path(cr)
        call cairo.arc(cr, cx, cy, radius * 0.55, 0, 2 * math.PI)
        call source(cr, palette["bg"])
        call cairo.fill(cr)
        call draw_text(cr, value_text(spec, total), cx, cy - 8, palette["fg"], 10.0, True, 1)
    end
    # legenda vpravo
    lx = cx + radius + 18
    ly = cy - len(entries) * 9.0
    ly = max(y, ly)
    for index in rang(len(entries)):
        entry = entries[index]
        if ly > y + height - 12:
            break
        end
        value = None
        if index < len(values):
            value = values[index]
        end
        call source(cr, entry[1])
        call rounded(cr, lx, ly + 3, 10, 10, 2.5)
        call cairo.fill(cr)
        percent = ""
        if value != None and value > 0:
            percent = "  " + trim(rich_expr.fixed(value / total * 100, 1)) + " %"
        end
        call draw_text(cr, entry[0] + percent, lx + 15, ly, palette["fg"], 8.5, False, 0, Int(max(20, x + width - lx - 15)), 0.85)
        ly += 18
    end
    return hits
end

function hit_test(hits, px, py):
    # [serie, bod] pod mysi nebo None (kolac: podle uhlu)
    best = None
    best_distance = 1.0e18
    for item in hits:
        if len(item) > 7:
            dx = px - item[7]
            dy = py - item[8]
            if dx * dx + dy * dy <= item[9] * item[9]:
                angle = atan2(dy, dx)
                while angle < item[10]:
                    angle += 2 * math.PI
                end
                while angle >= item[10] + 2 * math.PI:
                    angle -= 2 * math.PI
                end
                if angle < item[11]:
                    return [item[4], item[5]]
                end
            end
            continue
        end
        if px >= item[0] and px <= item[2] and py >= item[1] and py <= item[3]:
            cx = (item[0] + item[2]) / 2.0
            cy = (item[1] + item[3]) / 2.0
            distance = (px - cx) * (px - cx) + (py - cy) * (py - cy)
            if distance < best_distance:
                best = [item[4], item[5]]
                best_distance = distance
            end
        end
    end
    return best
end

function atan(value):
    # arkustangens (redukce argumentu + Taylor), presnost ~1e-12
    if value != value:
        return value
    end
    negative = value < 0
    x = abs(Float(value))
    invert = x > 1.0
    if invert:
        x = 1.0 / x
    end
    # redukce: atan(x) = 2 atan(x / (1 + sqrt(1 + x^2)))
    halvings = 0
    while x > 0.2:
        x = x / (1.0 + sqrt(1.0 + x * x))
        halvings += 1
    end
    term = x
    total = x
    square = x * x
    n = 1
    while n < 40:
        term = -term * square
        total += term / (2 * n + 1)
        n += 1
    end
    total = total * (2 ^ halvings)
    if invert:
        total = math.PI / 2.0 - total
    end
    if negative:
        return -total
    end
    return total
end

function atan2(y, x):
    if x > 0:
        return atan(y / x)
    elif x < 0:
        if y >= 0:
            return atan(y / x) + math.PI
        end
        return atan(y / x) - math.PI
    end
    if y > 0:
        return math.PI / 2.0
    elif y < 0:
        return -math.PI / 2.0
    end
    return 0.0
end

function plot_frame(spec, x0, y0, width, height):
    # [left, top, plot_w, plot_h, x_min, x_max, y_min, y_max]: pri stejnem meritku os se rozsah
    # rozsiri (nikdy neorizne), aby 1 jednotka na x = 1 jednotka na y
    left = x0 + 34.0
    right = x0 + width - 14.0
    top = y0 + 8.0
    bottom = y0 + height - 26.0
    plot_w = max(10.0, right - left)
    plot_h = max(10.0, bottom - top)
    xa = spec["x_range"][0]
    xb = spec["x_range"][1]
    ya = spec["y_range"][0]
    yb = spec["y_range"][1]
    if spec["equal"]:
        scale = min(plot_w / (xb - xa), plot_h / (yb - ya))
        extra_x = plot_w / scale - (xb - xa)
        extra_y = plot_h / scale - (yb - ya)
        xa -= extra_x / 2.0
        xb += extra_x / 2.0
        ya -= extra_y / 2.0
        yb += extra_y / 2.0
    end
    return [left, top, plot_w, plot_h, xa, xb, ya, yb]
end

function to_pixel(frame, x, y):
    return [frame[0] + (x - frame[4]) / (frame[5] - frame[4]) * frame[2], frame[1] + (frame[7] - y) / (frame[7] - frame[6]) * frame[3]]
end

function point_text(x, y):
    return "(" + trim(rich_expr.fixed(x, 4)) + ", " + trim(rich_expr.fixed(y, 4)) + ")"
end

function draw_arrow(cr, start, stop, color, width_line):
    call cairo.new_path(cr)
    call cairo.move_to(cr, start[0], start[1])
    dx = stop[0] - start[0]
    dy = stop[1] - start[1]
    length = sqrt(dx * dx + dy * dy)
    head = min(11.0, length * 0.45)
    if length < 0.5:
        return
    end
    ux = dx / length
    uy = dy / length
    call cairo.line_to(cr, stop[0] - ux * head * 0.8, stop[1] - uy * head * 0.8)
    call source(cr, color)
    call cairo.set_line_width(cr, width_line)
    call cairo.stroke(cr)
    call cairo.new_path(cr)
    call cairo.move_to(cr, stop[0], stop[1])
    call cairo.line_to(cr, stop[0] - ux * head - uy * head * 0.42, stop[1] - uy * head + ux * head * 0.42)
    call cairo.line_to(cr, stop[0] - ux * head + uy * head * 0.42, stop[1] - uy * head - ux * head * 0.42)
    call cairo.close_path(cr)
    call cairo.fill(cr)
end

function draw_plot(cr, spec, x0, y0, width, height, palette, hover):
    hits = []
    entries = []
    index = 0
    for item in spec["functions"]:
        entries.append([item["label"], series_color(palette, item["color"], index)])
        index += 1
    end
    legend = 0
    if entries:
        legend = draw_legend(cr, entries, 12.0, y0, width - 24.0, palette)
    end
    frame = plot_frame(spec, x0, y0 + legend, width, height - legend)
    left = frame[0]
    top = frame[1]
    right = left + frame[2]
    bottom = top + frame[3]
    xt = ticks(frame[4], frame[5], max(3, Int(frame[2] / 70)))
    yt = ticks(frame[6], frame[7], max(3, Int(frame[3] / 50)))
    call cairo.save(cr)
    call cairo.rectangle(cr, left, top, frame[2], frame[3])
    call cairo.clip(cr)
    if spec["grid"]:
        call source(cr, palette["grid"])
        call cairo.set_line_width(cr, 1.0)
        for value in xt[3]:
            gx = Int(to_pixel(frame, value, 0)[0]) + 0.5
            call cairo.move_to(cr, gx, top)
            call cairo.line_to(cr, gx, bottom)
        end
        for value in yt[3]:
            gy = Int(to_pixel(frame, 0, value)[1]) + 0.5
            call cairo.move_to(cr, left, gy)
            call cairo.line_to(cr, right, gy)
        end
        call cairo.stroke(cr)
    end
    call cairo.restore(cr)
    # osy pruchodem pocatku (mimo rozsah: u okraje)
    origin = to_pixel(frame, max(frame[4], min(frame[5], 0.0)), max(frame[6], min(frame[7], 0.0)))
    ax = Int(origin[0]) + 0.5
    ay = Int(origin[1]) + 0.5
    call draw_arrow(cr, [left, ay], [right + 8, ay], palette["axis"], 1.3)
    call draw_arrow(cr, [ax, bottom], [ax, top - 6], palette["axis"], 1.3)
    call draw_text(cr, spec["x_label"], right + 6, ay + 3, palette["dim"], 8.5, False, 2)
    call draw_text(cr, spec["y_label"], ax + 6, top - 6, palette["dim"], 8.5, False, 0)
    for value in xt[3]:
        if abs(value) < xt[2] * 1.0e-6:
            continue
        end
        px = to_pixel(frame, value, 0)[0]
        if px < left + 4 or px > right - 4:
            continue
        end
        call source(cr, palette["axis"])
        call cairo.move_to(cr, Int(px) + 0.5, ay - 3)
        call cairo.line_to(cr, Int(px) + 0.5, ay + 3)
        call cairo.stroke(cr)
        call draw_text(cr, compact(value, xt[2]), px, min(ay + 4, bottom + 4), palette["dim"], 8.0, False, 1)
    end
    for value in yt[3]:
        if abs(value) < yt[2] * 1.0e-6:
            continue
        end
        py = to_pixel(frame, 0, value)[1]
        if py < top + 4 or py > bottom - 4:
            continue
        end
        call source(cr, palette["axis"])
        call cairo.move_to(cr, ax - 3, Int(py) + 0.5)
        call cairo.line_to(cr, ax + 3, Int(py) + 0.5)
        call cairo.stroke(cr)
        call draw_text(cr, compact(value, yt[2]), max(ax - 5, left + 22), py - 7, palette["dim"], 8.0, False, 2)
    end
    call draw_text(cr, "0", ax - 4, ay + 2, palette["dim"], 8.0, False, 2)
    call cairo.save(cr)
    call cairo.rectangle(cr, left, top, frame[2], frame[3])
    call cairo.clip(cr)
    index = 0
    for item in spec["polygons"]:
        color = series_color(palette, item["color"], index + 3)
        call cairo.new_path(cr)
        first = True
        for vertex in item["points"]:
            p = to_pixel(frame, vertex[0], vertex[1])
            if first:
                call cairo.move_to(cr, p[0], p[1])
                first = False
            else:
                call cairo.line_to(cr, p[0], p[1])
            end
        end
        call cairo.close_path(cr)
        call source(cr, color, 0.16)
        call cairo.fill_preserve(cr)
        call source(cr, color)
        call cairo.set_line_width(cr, 1.8)
        call cairo.stroke(cr)
        index += 1
    end
    for item in spec["circles"]:
        color = series_color(palette, item["color"], index + 3)
        center = to_pixel(frame, item["center"][0], item["center"][1])
        rx = item["r"] / (frame[5] - frame[4]) * frame[2]
        ry = item["r"] / (frame[7] - frame[6]) * frame[3]
        call cairo.save(cr)
        call cairo.translate(cr, center[0], center[1])
        call cairo.scale(cr, rx, ry)
        call cairo.new_path(cr)
        call cairo.arc(cr, 0, 0, 1.0, 0, 2 * math.PI)
        call cairo.restore(cr)
        call source(cr, color)
        call cairo.set_line_width(cr, 2.0)
        call cairo.stroke(cr)
        index += 1
    end
    index = 0
    for item in spec["functions"]:
        color = series_color(palette, item["color"], index)
        for segment in item["segments"]:
            call cairo.new_path(cr)
            previous = None
            for point in segment:
                p = to_pixel(frame, point[0], point[1])
                # skok pres celou vysku (asymptota tan, 1/x): neprotahovat caru
                if previous == None or abs(p[1] - previous[1]) > frame[3] * 1.5:
                    call cairo.move_to(cr, p[0], max(-1.0e5, min(1.0e5, p[1])))
                else:
                    call cairo.line_to(cr, p[0], max(-1.0e5, min(1.0e5, p[1])))
                end
                previous = p
            end
            call source(cr, color)
            call cairo.set_line_width(cr, 2.2)
            if item["dashed"]:
                call cairo.set_dash(cr, [6.0, 4.0], 0.0)
            end
            call cairo.set_line_join(cr, 1)
            call cairo.stroke(cr)
            call cairo.set_dash(cr, [], 0.0)
        end
        index += 1
    end
    for item in spec["segments"]:
        a = to_pixel(frame, item["from"][0], item["from"][1])
        b = to_pixel(frame, item["to"][0], item["to"][1])
        call cairo.new_path(cr)
        call cairo.move_to(cr, a[0], a[1])
        call cairo.line_to(cr, b[0], b[1])
        call source(cr, series_color(palette, item["color"], 5))
        call cairo.set_line_width(cr, 2.0)
        if item["dashed"]:
            call cairo.set_dash(cr, [6.0, 4.0], 0.0)
        end
        call cairo.stroke(cr)
        call cairo.set_dash(cr, [], 0.0)
    end
    call cairo.restore(cr)
    vi = 0
    for item in spec["vectors"]:
        color = series_color(palette, item["color"], 3 + vi)
        a = to_pixel(frame, item["from"][0], item["from"][1])
        b = to_pixel(frame, item["to"][0], item["to"][1])
        call draw_arrow(cr, a, b, color, 2.6)
        tip = item["label"]
        if tip:
            call draw_text(cr, tip, (a[0] + b[0]) / 2.0 + 6, (a[1] + b[1]) / 2.0 - 16, color, 9.5, True)
        end
        dx = item["to"][0] - item["from"][0]
        dy = item["to"][1] - item["from"][1]
        text = point_text(item["from"][0], item["from"][1]) + " → " + point_text(item["to"][0], item["to"][1]) + ", |v| = " + trim(rich_expr.fixed(sqrt(dx * dx + dy * dy), 4))
        if tip:
            text = tip + ": " + text
        end
        hits.append([b[0] - 7, b[1] - 7, b[0] + 7, b[1] + 7, 1, vi, text])
        vi += 1
    end
    pi = 0
    for item in spec["points"]:
        p = to_pixel(frame, item["at"][0], item["at"][1])
        color = series_color(palette, item["color"], 3)
        call cairo.new_path(cr)
        call cairo.arc(cr, p[0], p[1], 4.5, 0, 2 * math.PI)
        call source(cr, palette["bg"])
        call cairo.fill_preserve(cr)
        call source(cr, color)
        call cairo.set_line_width(cr, 2.2)
        call cairo.stroke(cr)
        label = item["label"]
        if not label:
            label = point_text(item["at"][0], item["at"][1])
        end
        call draw_text(cr, label, p[0] + 7, p[1] - 18, palette["fg"], 8.5)
        hits.append([p[0] - 7, p[1] - 7, p[0] + 7, p[1] + 7, 0, pi, label + "  " + point_text(item["at"][0], item["at"][1])])
        pi += 1
    end
    # popisky pod mysi i na krivkach (kazdy 20. vzorek)
    index = 0
    for item in spec["functions"]:
        sample = 0
        for segment in item["segments"]:
            for point in segment:
                if sample % 20 == 0:
                    p = to_pixel(frame, point[0], point[1])
                    if p[1] >= top and p[1] <= bottom:
                        hits.append([p[0] - 5, p[1] - 5, p[0] + 5, p[1] + 5, 10 + index, sample, item["label"] + ": " + point_text(point[0], point[1])])
                    end
                end
                sample += 1
            end
        end
        index += 1
    end
    return hits
end

function chart_height(spec, width):
    if spec["type"] in ["function", "plane"]:
        if spec["equal"]:
            span = (spec["y_range"][1] - spec["y_range"][0]) / (spec["x_range"][1] - spec["x_range"][0])
            return min(560, max(240, Int((width - 48) * span + 70)))
        end
        return min(420, max(260, Int(width * 0.6)))
    end
    if spec["type"] in ["pie", "donut"]:
        return min(320, max(200, Int(width * 0.5)))
    end
    if spec["type"] == "hbar":
        rows = len(chart_series_values(spec))
        return min(640, max(180, 60 + rows * max(18, 8 * len(spec["series"]) + 8)))
    end
    return min(380, max(220, Int(width * 0.55)))
end

# ---------------------------------------------------------------- obrazky (export, testy)

function png_surface(width, height, scale=2.0):
    surface = cairo.image_surface_create(cairo.FORMAT_ARGB32, Int(width * scale + 0.5), Int(height * scale + 0.5))
    call __lsl_qbe_call3(__lsl_symbol("cairo_surface_set_device_scale"), platform.pointer(surface), Float(scale), Float(scale))
    return surface
end

function svg_surface(path, width, height):
    return __lsl_qbe_call3(__lsl_symbol("cairo_svg_surface_create"), platform.cstr(path), Float(width), Float(height))
end

function finish_surface(surface):
    call __lsl_qbe_call1(__lsl_symbol("cairo_surface_finish"), platform.pointer(surface))
    status = cairo.surface_status(surface)
    call cairo.surface_destroy(surface)
    return status == 0
end

function fill_background(cr, width, height, palette):
    call source(cr, palette["bg"])
    call cairo.rectangle(cr, 0, 0, width, height)
    call cairo.fill(cr)
end
