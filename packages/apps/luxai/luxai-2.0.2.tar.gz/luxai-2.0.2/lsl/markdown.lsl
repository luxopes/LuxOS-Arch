load common
load platform
load catalog
load highlight
load mathtex

function match(pattern, text):
    values = platform.regex_findall(pattern, text)
    if values and values[0]["start"] == 0:
        return values[0]["groups"]
    end
    return None
end

function split_row(line):
    text = line.strip(common.WHITESPACE)
    if text.startswith("|"):
        text = text[1:]
    end
    if text.endswith("|") and not text.endswith("\\|"):
        text = text[:len(text) - 1]
    end
    cells = []
    position = 0
    for separator in platform.regex_findall("(?<!\\\\)\\|", text):
        cells.append(text[position:separator["start"]].strip(common.WHITESPACE).replace("\\|", "|"))
        position = separator["end"]
    end
    cells.append(text[position:].strip(common.WHITESPACE).replace("\\|", "|"))
    return cells
end

function flush_para(blocks, paragraph):
    if paragraph:
        blocks.append({"type": "para", "text": "\n".join(paragraph)})
        call paragraph.clear()
    end
end

function parse_blocks(text):
    lines = common.text(text).replace("\r\n", "\n").replace("\t", "    ").split("\n")
    blocks = []
    paragraph = []
    index = 0
    while index < len(lines):
        line = lines[index]
        groups = match(catalog.MD_FENCE, line)
        if groups:
            call flush_para(blocks, paragraph)
            fence = groups[1]
            language = groups[2]
            body = []
            closed = False
            index += 1
            while index < len(lines):
                candidate = lines[index].strip(common.WHITESPACE)
                if candidate.startswith(fence) and not candidate.strip(fence[0]):
                    closed = True
                    index += 1
                    break
                end
                body.append(lines[index])
                index += 1
            end
            blocks.append({"type": "code", "lang": language, "text": "\n".join(body), "closed": closed})
            continue
        end
        if not line.strip(common.WHITESPACE):
            call flush_para(blocks, paragraph)
            index += 1
            continue
        end
        opener = ""
        closer = ""
        if line.strip(common.WHITESPACE).startswith("$$"):
            opener = "$$"
            closer = "$$"
        elif line.strip(common.WHITESPACE).startswith("\\["):
            opener = "\\["
            closer = "\\]"
        end
        if opener:
            rest = line.strip(common.WHITESPACE)[len(opener):]
            body = []
            closed = False
            after = ""
            loop:
                if closer in rest:
                    split = rest.find(closer)
                    body.append(rest[:split])
                    closed = True
                    after = rest[split + len(closer):].strip(common.WHITESPACE)
                    index += 1
                    break
                end
                body.append(rest)
                index += 1
                if index >= len(lines):
                    break
                end
                rest = lines[index]
            end
            call flush_para(blocks, paragraph)
            tex = common.strip_text("\n".join(body))
            if tex:
                blocks.append({"type": "math", "text": tex, "closed": closed})
            end
            if after:
                paragraph.append(after)
            end
            continue
        end
        groups = match(catalog.MD_HEADING, line)
        if groups:
            call flush_para(blocks, paragraph)
            blocks.append({"type": "heading", "level": len(groups[1]), "text": groups[2]})
            index += 1
            continue
        end
        if platform.regex_test(catalog.MD_HR, line) and not paragraph:
            blocks.append({"type": "hr"})
            index += 1
            continue
        end
        if "|" in line and index + 1 < len(lines) and platform.regex_test(catalog.MD_TABLE_SEP, lines[index + 1]) and "-" in lines[index + 1]:
            call flush_para(blocks, paragraph)
            header = split_row(line)
            rows = []
            index += 2
            while index < len(lines) and "|" in lines[index] and lines[index].strip(common.WHITESPACE):
                rows.append(split_row(lines[index]))
                index += 1
            end
            blocks.append({"type": "table", "header": header, "rows": rows})
            continue
        end
        if line.lstrip(common.WHITESPACE).startswith(">"):
            call flush_para(blocks, paragraph)
            quote = []
            while index < len(lines) and lines[index].lstrip(common.WHITESPACE).startswith(">"):
                quote.append(platform.regex_replace("^\\s*>\\s?", "", lines[index]))
                index += 1
            end
            blocks.append({"type": "quote", "text": "\n".join(quote)})
            continue
        end
        groups = match(catalog.MD_LIST_ITEM, line)
        if groups:
            call flush_para(blocks, paragraph)
            items = []
            ordered = platform.digit_value(String(groups[2])[0]) >= 0
            while index < len(lines):
                groups = match(catalog.MD_LIST_ITEM, lines[index])
                if groups:
                    marker = groups[2]
                    body = groups[3]
                    is_ordered = platform.digit_value(String(marker)[0]) >= 0
                    number = None
                    if is_ordered:
                        # jako Python int(re.sub(r"\\D", "", marker)) i pro jine nez ASCII cislice
                        number = 0
                        for char in String(marker):
                            if platform.digit_value(char) >= 0:
                                number = number * 10 + platform.digit_value(char)
                            end
                        end
                    end
                    item = {"level": min(len(groups[1]) // 2, 4), "ordered": is_ordered, "number": number, "text": body, "checked": None}
                    task = match(catalog.MD_TASK, body)
                    if task:
                        item["checked"] = task[1] != " "
                        item["text"] = task[2]
                    end
                    items.append(item)
                    index += 1
                elif lines[index].strip(common.WHITESPACE) and lines[index].startswith("  ") and items:
                    items[len(items) - 1]["text"] += " " + lines[index].strip(common.WHITESPACE)
                    index += 1
                else:
                    break
                end
            end
            blocks.append({"type": "list", "ordered": ordered, "items": items})
            continue
        end
        # odsazeny pokracovaci radek (napr. kod bez ```) si odsazeni ponecha, jinak by se ztratila struktura
        text = line.strip(common.WHITESPACE)
        if paragraph and line.startswith(" "):
            text = common.rstrip_text(line, common.WHITESPACE)
        end
        if line.endswith("  "):
            text += "\n"
        end
        paragraph.append(text)
        index += 1
    end
    call flush_para(blocks, paragraph)
    return blocks
end

function plain_markup(text):
    if mathtex.has_bare_latex(text):
        return mathtex.bare_markup(text)
    end
    return highlight.esc(text)
end

function link(url, label, color):
    if not platform.regex_test("(?i)^(https?|mailto|file):", url):
        return label
    end
    href = highlight.esc(url).replace("\"", "&quot;").replace("'", "&#x27;")
    if color:
        label = "<span foreground=\"" + color + "\">" + label + "</span>"
    end
    return "<a href=\"" + href + "\">" + label + "</a>"
end

function inline(text, code_color=None, link_color=None):
    output = []
    position = 0
    text = common.text(text)
    for found in platform.regex_findall(catalog.MD_INLINE, text, 4):
        output.append(plain_markup(text[position:found["start"]]))
        position = found["end"]
        groups = {}
        for name in catalog.MD_INLINE_GROUPS.keys():
            groups[name] = found["groups"][catalog.MD_INLINE_GROUPS[name]]
        end
        math = ""
        for name in ["mdd_body", "mbr_body", "mpar_body", "md_body"]:
            if groups[name]:
                math = groups[name]
                break
            end
        end
        if math:
            output.append(mathtex.to_markup(math))
        elif groups["code"]:
            body = groups["code_body"]
            if body.startswith(" ") and body.endswith(" ") and body.strip(common.WHITESPACE):
                body = body[1:len(body) - 1]
            end
            attributes = " font_family=\"monospace\""
            if code_color:
                attributes += " background=\"" + code_color + "\""
            end
            output.append("<span" + attributes + ">" + highlight.esc(body) + "</span>")
        elif groups["link_text"]:
            output.append(link(groups["link_url"], inline(groups["link_text"], code_color, link_color), link_color))
        elif groups["auto"]:
            output.append(link(groups["auto_url"], highlight.esc(groups["auto_url"]), link_color))
        elif groups["b3"]:
            output.append("<b><i>" + inline(groups["b3_body"], code_color, link_color) + "</i></b>")
        elif groups["b2"]:
            output.append("<b>" + inline(groups["b2_body"], code_color, link_color) + "</b>")
        elif groups["st"]:
            output.append("<s>" + inline(groups["st_body"], code_color, link_color) + "</s>")
        elif groups["i1_body"]:
            output.append("<i>" + inline(groups["i1_body"], code_color, link_color) + "</i>")
        elif groups["i2_body"]:
            output.append("<i>" + inline(groups["i2_body"], code_color, link_color) + "</i>")
        end
    end
    output.append(plain_markup(text[position:]))
    return "".join(output)
end

function math_markup(block):
    return "<span size=\"large\">" + mathtex.to_markup(block["text"], True) + "</span>"
end

function heading_markup(block, code_color=None, link_color=None):
    size = "medium"
    if block["level"] == 1:
        size = "x-large"
    elif block["level"] == 2:
        size = "large"
    end
    return "<span size=\"" + size + "\" weight=\"bold\">" + inline(block["text"], code_color, link_color) + "</span>"
end

function list_item_prefix(item, index):
    if item.get("checked") != None:
        if item["checked"]:
            return "☑"
        end
        return "☐"
    end
    if item["ordered"]:
        number = item.get("number")
        if number == None:
            number = index + 1
        end
        return String(number) + "."
    end
    return ["•", "◦", "▪", "•", "◦"][item["level"] % 5]
end

function table_text(block, width_limit=40):
    rows = [block["header"]] + block["rows"]
    columns = 0
    for row in rows:
        columns = max(columns, len(row))
    end
    widths = []
    for column in rang(columns):
        width = 0
        for row in rows:
            if column < len(row):
                width = max(width, len(row[column]))
            end
        end
        widths.append(min(width_limit, width))
    end
    lines = []
    for index in rang(len(rows)):
        values = []
        for column in rang(columns):
            value = ""
            if column < len(rows[index]):
                value = rows[index][column][:width_limit]
            end
            values.append(value + " " * max(0, widths[column] - len(value)))
        end
        lines.append(" | ".join(values).rstrip(common.WHITESPACE))
        if index == 0:
            separators = []
            for width in widths:
                separators.append("-" * width)
            end
            lines.append("-+-".join(separators))
        end
    end
    return "\n".join(lines)
end

function to_plain(text):
    markup = platform.regex_replace("<[^>]+>", "", inline(text))
    return markup.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
end
