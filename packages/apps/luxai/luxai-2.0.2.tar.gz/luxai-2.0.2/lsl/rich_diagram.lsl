# lsl: internal-abi
# ```mermaid / ```diagram: vlastni parser podmnoziny Mermaid a nativni rozvrzeni a kresleni v cairo
# (bez site, bez JavaScriptu). Podporovano: flowchart/graph (TD, TB, BT, LR, RL; tvary uzlu
# [] () (()) {} {{}} [()] [[]] ([]) >] [//]; hrany --> --- -.-> ==> --o --x s popisky |text| i -- text -->;
# retezy A --> B --> C a A & B --> C), sequenceDiagram (participant/actor, zpravy ->> -->> -> --> -x -),
# poznamky, loop/alt/else/opt/par bloky, autonumber), stateDiagram(-v2) ([*], popisky prechodu,
# state "..." as X), timeline (title, section, obdobi : udalost) a pie.
# Ignoruje se: classDef/class/style/linkStyle/click (zadne odkazy ani skripty), subgraph (obsah zustane).
#
# Rozvrzeni vrstvenim (Sugiyama): odstraneni cyklu, nejdelsi cesta, pomocne uzly pro dlouhe hrany,
# poradi ve vrstvach barycentry, souradnice s minimalnimi rozestupy.
load cairo
load pango
load math
load common
load platform
load rich_draw
load rich_blocks

MAX_NODES = 120
MAX_EDGES = 240
MAX_MESSAGES = 200
NODE_TEXT_WIDTH = 170
SHAPES = [["((", "))", "circle"], ["([", "])", "stadium"], ["[[", "]]", "subroutine"], ["[(", ")]", "cylinder"], ["{{", "}}", "hexagon"], ["[/", "/]", "parallelogram"], ["[\\", "\\]", "parallelogram"], ["[/", "\\]", "trapezoid"], ["[", "]", "rect"], ["(", ")", "round"], ["{", "}", "diamond"], [">", "]", "flag"]]
EDGE_PATTERN = "^(<)?\\s*(-{2,}|={2,}|-?\\.{1,}-?)(>|x|o)?(?:\\s*\\|([^|]*)\\|)?"
TEXT_EDGE_PATTERN = "^(<)?(--|==|-\\.)\\s*([^|>]+?)\\s*(-{2,}>|={2,}>|\\.-{1,}>|-{2,}|={2,})"
SEQUENCE_ARROWS = ["-->>", "->>", "-->", "->", "--x", "-x", "--)", "-)"]

function fail(message):
    Error(DiagramError: message)
end

function clean_label(text):
    # <br> -> novy radek, ostatni HTML znacky pryc, uvozovky kolem textu pryc
    value = String(text).strip()
    if len(value) >= 2 and value.startswith("\"") and value.endswith("\""):
        value = value[1:len(value) - 1]
    end
    value = platform.regex_replace("(?i)<br\\s*/?>", "\n", value)
    value = platform.regex_replace("<[^>]*>", "", value)
    value = value.replace("&quot;", "\"").replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("#quot;", "\"")
    value = value.replace("**", "").replace("`", "")
    return value[:300]
end

function strip_comment(line):
    position = line.find("%%")
    if position >= 0:
        return line[:position]
    end
    return line
end

function source_lines(source):
    lines = []
    for raw in String(source).replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = strip_comment(raw).strip()
        if line:
            lines.append(line)
        end
    end
    return lines
end

function parse(source):
    lines = source_lines(source)
    if not lines:
        call fail("diagram is empty")
    end
    # inicializacni direktivy %%{init}%% uz odstranil strip_comment; frontmatter --- ... ---
    if lines[0] == "---":
        index = 1
        while index < len(lines) and lines[index] != "---":
            index += 1
        end
        lines = lines[index + 1:]
        if not lines:
            call fail("diagram is empty")
        end
    end
    head = lines[0].lower()
    word = head.split(" ")[0]
    if word in ["flowchart", "graph"]:
        return parse_flowchart(lines)
    elif word == "sequencediagram":
        return parse_sequence(lines)
    elif word in ["statediagram", "statediagram-v2"]:
        return parse_state(lines)
    elif word == "timeline":
        return parse_timeline(lines)
    elif word == "pie":
        return parse_pie(lines)
    end
    call fail("unsupported diagram type (supported: flowchart, sequenceDiagram, stateDiagram, timeline, pie)")
end

# ---------------------------------------------------------------- flowchart

function new_graph(kind, direction):
    return {"kind": kind, "direction": direction, "nodes": {}, "order": [], "edges": [], "title": ""}
end

function add_node(graph, ident, label=None, shape=None):
    if ident not in graph["nodes"]:
        if len(graph["order"]) >= MAX_NODES:
            call fail("diagram has too many nodes (max " + String(MAX_NODES) + ")")
        end
        graph["nodes"][ident] = {"id": ident, "label": ident, "shape": "rect"}
        graph["order"].append(ident)
    end
    node = graph["nodes"][ident]
    if label != None:
        node["label"] = label
    end
    if shape != None:
        node["shape"] = shape
    end
    return node
end

function add_edge(graph, source, target, label="", style="solid", arrow=True, back=False):
    if len(graph["edges"]) >= MAX_EDGES:
        call fail("diagram has too many edges (max " + String(MAX_EDGES) + ")")
    end
    graph["edges"].append({"from": source, "to": target, "label": label, "style": style, "arrow": arrow, "back_arrow": back})
end

function direction_of(text):
    value = text.upper()
    if value in ["TD", "TB"]:
        return "TB"
    elif value in ["BT", "LR", "RL"]:
        return value
    end
    return "TB"
end

function read_node(line, position):
    # [id, popisek nebo None, tvar nebo None, nova pozice] nebo None
    rest = line[position:]
    found = platform.regex_findall("^([A-Za-z0-9_\\x{80}-\\x{10FFFF}]+)", rest)
    if not found:
        return None
    end
    ident = found[0]["groups"][1]
    position += len(ident)
    for shape in SHAPES:
        opener = shape[0]
        if line[position:position + len(opener)] == opener:
            start = position + len(opener)
            closer = shape[1]
            stop = -1
            if line[start:start + 1] == "\"":
                quote = line.find("\"", start + 1)
                if quote >= 0:
                    stop = line.find(closer, quote + 1)
                end
            else:
                stop = line.find(closer, start)
            end
            if stop < 0:
                call fail("unclosed node shape for " + ident)
            end
            return [ident, clean_label(line[start:stop]), shape[2], stop + len(closer)]
        end
    end
    return [ident, None, None, position]
end

function skip_spaces(line, position):
    while position < len(line) and line[position] in " \t":
        position += 1
    end
    return position
end

function read_group(graph, line, position):
    # A & B & C -> [[id...], pozice]
    names = []
    loop:
        position = skip_spaces(line, position)
        node = read_node(line, position)
        if node == None:
            break
        end
        call add_node(graph, node[0], node[1], node[2])
        names.append(node[0])
        position = skip_spaces(line, node[3])
        if line[position:position + 1] == "&":
            position += 1
            continue
        end
        break
    end
    return [names, position]
end

function read_edge(line, position):
    rest = line[position:]
    found = platform.regex_findall(TEXT_EDGE_PATTERN, rest)
    if found:
        groups = found[0]["groups"]
        tail = groups[4]
        style = "solid"
        if groups[2] == "==" or tail.startswith("="):
            style = "thick"
        elif groups[2] == "-." or "." in tail:
            style = "dotted"
        end
        return {"label": clean_label(groups[3]), "style": style, "arrow": tail.endswith(">"), "back": groups[1] == "<", "end": position + found[0]["end"]}
    end
    found = platform.regex_findall(EDGE_PATTERN, rest)
    if not found:
        return None
    end
    groups = found[0]["groups"]
    body = groups[2]
    style = "solid"
    if body.startswith("="):
        style = "thick"
    elif "." in body:
        style = "dotted"
    end
    head = groups[3]
    label = ""
    if groups[4]:
        label = clean_label(groups[4])
    end
    return {"label": label, "style": style, "arrow": head == ">", "head": head, "back": groups[1] == "<", "end": position + found[0]["end"]}
end

function parse_statement(graph, line):
    position = 0
    group = read_group(graph, line, position)
    if not group[0]:
        return
    end
    previous = group[0]
    position = group[1]
    while position < len(line):
        edge = read_edge(line, position)
        if edge == None:
            break
        end
        group = read_group(graph, line, edge["end"])
        if not group[0]:
            call fail("edge without a target: " + line[:80])
        end
        for source in previous:
            for target in group[0]:
                call add_edge(graph, source, target, edge["label"], edge["style"], edge["arrow"], edge["back"])
            end
        end
        previous = group[0]
        position = group[1]
    end
end

function parse_flowchart(lines):
    parts = lines[0].split(" ")
    direction = "TB"
    if len(parts) > 1:
        direction = direction_of(parts[1].strip())
    end
    graph = new_graph("flow", direction)
    for raw in lines[1:]:
        for line in raw.split(";"):
            line = line.strip()
            lowered = line.lower()
            if not line or lowered == "end":
                continue
            end
            first = lowered.split(" ")[0]
            if first in ["classdef", "class", "style", "linkstyle", "click", "accdescr", "acctitle"]:
                continue
            end
            if first == "subgraph":
                continue
            end
            if first == "direction":
                continue
            end
            if first == "title" and not graph["title"]:
                graph["title"] = clean_label(line[6:])
                continue
            end
            # odkazy ":::trida" na uzlech
            line = platform.regex_replace(":::[A-Za-z0-9_-]+", "", line)
            call parse_statement(graph, line)
        end
    end
    if not graph["order"]:
        call fail("flowchart has no nodes")
    end
    return graph
end

# ---------------------------------------------------------------- state

function state_node(graph, name, as_target):
    if name == "[*]":
        if as_target:
            call add_node(graph, "__end", "", "end")
            return "__end"
        end
        call add_node(graph, "__start", "", "start")
        return "__start"
    end
    if name not in graph["nodes"]:
        call add_node(graph, name, name, "round")
    end
    return name
end

function parse_state(lines):
    graph = new_graph("flow", "TB")
    for line in lines[1:]:
        lowered = line.lower()
        if line in ["}", "{"] or lowered.startswith("note") or lowered == "end note" or lowered.startswith("classdef") or lowered.startswith("class "):
            continue
        end
        if lowered.startswith("direction "):
            graph["direction"] = direction_of(line[10:].strip())
            continue
        end
        found = platform.regex_findall("^state\\s+\"([^\"]*)\"\\s+as\\s+([A-Za-z0-9_]+)", line)
        if found:
            node = add_node(graph, found[0]["groups"][2], clean_label(found[0]["groups"][1]), "round")
            continue
        end
        found = platform.regex_findall("^state\\s+([A-Za-z0-9_]+)\\s*(<<(choice|fork|join)>>)?", line)
        if found:
            shape = "round"
            if found[0]["groups"][3] == "choice":
                shape = "diamond"
            elif found[0]["groups"][3] in ["fork", "join"]:
                shape = "bar"
            end
            node = add_node(graph, found[0]["groups"][1], None, shape)
            if shape != "round":
                node["label"] = ""
            end
            continue
        end
        found = platform.regex_findall("^(\\[\\*\\]|[A-Za-z0-9_]+)\\s*(-->|--)\\s*(\\[\\*\\]|[A-Za-z0-9_]+)\\s*(?::\\s*(.*))?$", line)
        if found:
            groups = found[0]["groups"]
            source = state_node(graph, groups[1], False)
            target = state_node(graph, groups[3], True)
            label = ""
            if groups[4]:
                label = clean_label(groups[4])
            end
            call add_edge(graph, source, target, label, "solid", True)
            continue
        end
        found = platform.regex_findall("^([A-Za-z0-9_]+)\\s*:\\s*(.+)$", line)
        if found:
            call add_node(graph, found[0]["groups"][1], clean_label(found[0]["groups"][2]), "round")
            continue
        end
    end
    if not graph["order"]:
        call fail("state diagram has no states")
    end
    return graph
end

# ---------------------------------------------------------------- sequence

function parse_sequence(lines):
    result = {"kind": "sequence", "participants": [], "labels": {}, "actors": [], "rows": [], "title": "", "autonumber": False}
    depth = 0
    for line in lines[1:]:
        lowered = line.lower()
        first = lowered.split(" ")[0]
        if first in ["participant", "actor"]:
            found = platform.regex_findall("^(?:participant|actor)\\s+(.+?)(?:\\s+as\\s+(.+))?$", line)
            if found:
                name = found[0]["groups"][1].strip()
                label = name
                if found[0]["groups"][2]:
                    label = found[0]["groups"][2]
                end
                call sequence_participant(result, name)
                result["labels"][name] = clean_label(label)
                if first == "actor" and name not in result["actors"]:
                    result["actors"].append(name)
                end
            end
            continue
        end
        if first == "autonumber":
            result["autonumber"] = True
            continue
        end
        if first == "title":
            result["title"] = clean_label(line[5:].lstrip(":"))
            continue
        end
        if first in ["activate", "deactivate", "create", "destroy", "box", "links", "link", "properties"]:
            continue
        end
        if first in ["loop", "alt", "opt", "par", "critical", "break", "rect"]:
            depth += 1
            result["rows"].append({"type": "open", "kind": first, "label": clean_label(line[len(first):]), "depth": depth})
            continue
        end
        if first in ["else", "and", "option"]:
            result["rows"].append({"type": "divider", "label": clean_label(line[len(first):]), "depth": depth})
            continue
        end
        if lowered == "end":
            if depth > 0:
                result["rows"].append({"type": "close", "depth": depth})
                depth -= 1
            end
            continue
        end
        if first == "note":
            found = platform.regex_findall("(?i)^note\\s+(left of|right of|over)\\s+([^:]+):\\s*(.*)$", line)
            if found:
                names = []
                for name in found[0]["groups"][2].split(","):
                    name = name.strip()
                    if name:
                        call sequence_participant(result, name)
                        names.append(name)
                    end
                end
                result["rows"].append({"type": "note", "where": found[0]["groups"][1].lower(), "names": names, "label": clean_label(found[0]["groups"][3])})
            end
            continue
        end
        message = sequence_message(line)
        if message != None:
            call sequence_participant(result, message["from"])
            call sequence_participant(result, message["to"])
            result["rows"].append(message)
            if len(result["rows"]) > MAX_MESSAGES:
                call fail("sequence diagram is too long (max " + String(MAX_MESSAGES) + " rows)")
            end
        end
    end
    while depth > 0:
        result["rows"].append({"type": "close", "depth": depth})
        depth -= 1
    end
    if not result["participants"]:
        call fail("sequence diagram has no participants")
    end
    return result
end

function sequence_participant(result, name):
    if name not in result["participants"]:
        if len(result["participants"]) >= 20:
            call fail("sequence diagram has too many participants (max 20)")
        end
        result["participants"].append(name)
        result["labels"][name] = clean_label(name)
    end
end

function sequence_message(line):
    colon = line.find(":")
    head = line
    label = ""
    if colon >= 0:
        head = line[:colon]
        label = clean_label(line[colon + 1:])
    end
    for arrow in SEQUENCE_ARROWS:
        position = head.find(arrow)
        if position > 0:
            source = head[:position].strip()
            target = head[position + len(arrow):].strip().lstrip("+-").strip()
            if source and target:
                return {"type": "message", "from": source, "to": target, "label": label, "dashed": arrow.startswith("--"), "head": arrow[len(arrow) - 1:], "open": arrow in ["->", "-->"]}
            end
        end
    end
    return None
end

# ---------------------------------------------------------------- timeline, pie

function parse_timeline(lines):
    result = {"kind": "timeline", "title": "", "periods": []}
    section = ""
    for line in lines[1:]:
        lowered = line.lower()
        if lowered.startswith("title"):
            result["title"] = clean_label(line[5:])
            continue
        end
        if lowered.startswith("section"):
            section = clean_label(line[7:])
            continue
        end
        parts = line.split(":")
        if line.startswith(":") and result["periods"]:
            for part in parts[1:]:
                if part.strip():
                    result["periods"][len(result["periods"]) - 1]["events"].append(clean_label(part))
                end
            end
            continue
        end
        events = []
        for part in parts[1:]:
            if part.strip():
                events.append(clean_label(part))
            end
        end
        result["periods"].append({"period": clean_label(parts[0]), "events": events, "section": section})
        if len(result["periods"]) > 60:
            call fail("timeline has too many periods (max 60)")
        end
    end
    if not result["periods"]:
        call fail("timeline has no periods")
    end
    return result
end

function parse_pie(lines):
    title = ""
    found = platform.regex_findall("(?i)^pie(?:\\s+showData)?(?:\\s+title\\s+(.*))?$", lines[0])
    if found and found[0]["groups"][1]:
        title = clean_label(found[0]["groups"][1])
    end
    labels = []
    values = []
    for line in lines[1:]:
        if line.lower().startswith("title"):
            title = clean_label(line[5:])
            continue
        end
        found = platform.regex_findall("^\"([^\"]*)\"\\s*:\\s*([-+]?[0-9]*\\.?[0-9]+)", line)
        if found:
            labels.append(clean_label(found[0]["groups"][1]))
            values.append(Float(found[0]["groups"][2]))
        end
    end
    if not values:
        call fail("pie has no values")
    end
    spec = {"type": "pie", "title": title, "categories": labels, "series": [{"name": "", "values": values, "points": [], "color": ""}], "numeric_x": False, "x_label": "", "y_label": "", "y_min": None, "y_max": None, "unit": "", "stacked": False}
    for value in values:
        if value < 0:
            call fail("pie values must not be negative")
        end
    end
    return {"kind": "pie", "chart": spec}
end

# ---------------------------------------------------------------- rozvrzeni flowchart

function measure_context():
    surface = cairo.image_surface_create(cairo.FORMAT_ARGB32, 4, 4)
    cr = cairo.create(surface)
    return [surface, cr]
end

function release_context(context):
    call cairo.destroy(context[1])
    call cairo.surface_destroy(context[0])
end

function wrapped_layout(cr, text, size=9.5, width=170, bold=False):
    item = rich_draw.layout(cr, text, size, bold)
    call pango.layout_set_width(item, Int(width))
    call pango.layout_set_wrap(item, 2)
    call pango.layout_set_alignment(item, 1)
    return item
end

function label_size(cr, text, size=9.5, width=170):
    if not text:
        return [0, 0]
    end
    item = wrapped_layout(cr, text, size, width)
    extent = pango.layout_get_pixel_size(item)
    call pango.layout_unref(item)
    # sirka zalomeneho textu: skutecna sirka radku
    return [min(extent[0], width), extent[1]]
end

function node_size(cr, node):
    shape = node["shape"]
    if shape in ["start", "end"]:
        return [18.0, 18.0]
    end
    if shape == "bar":
        return [70.0, 8.0]
    end
    text = label_size(cr, node["label"])
    width = text[0] + 24.0
    height = text[1] + 16.0
    if shape == "circle":
        side = max(width, height) + 6
        return [side, side]
    elif shape == "diamond":
        return [width * 1.5 + 8, height * 1.6 + 6]
    elif shape == "hexagon":
        return [width + 24, height]
    elif shape in ["parallelogram", "trapezoid", "flag"]:
        return [width + 20, height]
    elif shape == "cylinder":
        return [width, height + 12]
    end
    return [max(width, 48.0), max(height, 34.0)]
end

function separation(vertices, first, second, gap):
    return vertices[first]["along"] / 2.0 + gap + vertices[second]["along"] / 2.0
end

function sort_by_value(items):
    # stabilni razeni dvojic [hodnota, klic] podle klice (sluckou)
    if len(items) <= 1:
        return items.copy()
    end
    middle = len(items) // 2
    left = sort_by_value(items[:middle])
    right = sort_by_value(items[middle:])
    output = []
    i = 0
    j = 0
    while i < len(left) and j < len(right):
        if right[j][1] < left[i][1]:
            output.append(right[j])
            j += 1
        else:
            output.append(left[i])
            i += 1
        end
    end
    output.extend(left[i:])
    output.extend(right[j:])
    return output
end

function layout_flow(graph, cr):
    nodes = graph["order"]
    index_of = {}
    for i in rang(len(nodes)):
        index_of[nodes[i]] = i
    end
    count = len(nodes)
    # hrany jako indexy; smycky (A --> A) se kresli zvlast
    edges = []
    for edge in graph["edges"]:
        edges.append([index_of[edge["from"]], index_of[edge["to"]], edge])
    end
    # 1. odstraneni cyklu: zpetne hrany DFS se otoci
    outgoing = []
    for i in rang(count):
        outgoing.append([])
    end
    for e in rang(len(edges)):
        if edges[e][0] != edges[e][1]:
            outgoing[edges[e][0]].append(e)
        end
    end
    state = []
    for i in rang(count):
        state.append(0)
    end
    reversed_edges = []
    for start in rang(count):
        if state[start] != 0:
            continue
        end
        stack = [[start, 0]]
        state[start] = 1
        while stack:
            top = stack[len(stack) - 1]
            node = top[0]
            if top[1] < len(outgoing[node]):
                e = outgoing[node][top[1]]
                top[1] += 1
                target = edges[e][1]
                if state[target] == 1:
                    reversed_edges.append(e)
                elif state[target] == 0:
                    state[target] = 1
                    stack.append([target, 0])
                end
            else:
                state[node] = 2
                call stack.pop()
            end
        end
    end
    dag = []
    for e in rang(len(edges)):
        a = edges[e][0]
        b = edges[e][1]
        if a == b:
            continue
        end
        if e in reversed_edges:
            dag.append([b, a, e])
        else:
            dag.append([a, b, e])
        end
    end
    # 2. vrstvy: nejdelsi cesta (Kahn)
    incoming_count = []
    successors = []
    for i in rang(count):
        incoming_count.append(0)
        successors.append([])
    end
    for item in dag:
        incoming_count[item[1]] += 1
        successors[item[0]].append(item[1])
    end
    layer = []
    for i in rang(count):
        layer.append(0)
    end
    queue = []
    for i in rang(count):
        if incoming_count[i] == 0:
            queue.append(i)
        end
    end
    head = 0
    while head < len(queue):
        node = queue[head]
        head += 1
        for target in successors[node]:
            layer[target] = max(layer[target], layer[node] + 1)
            incoming_count[target] -= 1
            if incoming_count[target] == 0:
                queue.append(target)
            end
        end
    end
    # 3. pomocne uzly pro hrany pres vice vrstev
    vertices = []
    for i in rang(count):
        size = node_size(cr, graph["nodes"][nodes[i]])
        vertices.append({"id": nodes[i], "layer": layer[i], "w": size[0], "h": size[1], "dummy": False, "pos": 0.0, "rank": 0.0})
    end
    chains = []
    links = []
    for item in dag:
        a = item[0]
        b = item[1]
        chain = [a]
        current = a
        for level in rang(layer[a] + 1, layer[b]):
            vertices.append({"id": "", "layer": level, "w": 12.0, "h": 12.0, "dummy": True, "pos": 0.0, "rank": 0.0})
            dummy = len(vertices) - 1
            links.append([current, dummy])
            chain.append(dummy)
            current = dummy
        end
        links.append([current, b])
        chain.append(b)
        chains.append([item[2], chain])
    end
    depth = 0
    for vertex in vertices:
        depth = max(depth, vertex["layer"])
    end
    layers = []
    for level in rang(depth + 1):
        layers.append([])
    end
    for v in rang(len(vertices)):
        layers[vertices[v]["layer"]].append(v)
    end
    upper = []
    lower = []
    for v in rang(len(vertices)):
        upper.append([])
        lower.append([])
    end
    for link in links:
        lower[link[0]].append(link[1])
        upper[link[1]].append(link[0])
    end
    # 4. poradi ve vrstvach: barycentry (dolu a nahoru)
    position = []
    for v in rang(len(vertices)):
        position.append(0.0)
    end
    for level in layers:
        for i in rang(len(level)):
            position[level[i]] = Float(i)
        end
    end
    for sweep in rang(6):
        downward = sweep % 2 == 0
        order = rang(1, len(layers))
        if not downward:
            order = []
            level_index = len(layers) - 2
            while level_index >= 0:
                order.append(level_index)
                level_index -= 1
            end
        end
        for level_index in order:
            items = []
            for v in layers[level_index]:
                neighbours = upper[v]
                if not downward:
                    neighbours = lower[v]
                end
                if neighbours:
                    total = 0.0
                    for n in neighbours:
                        total += position[n]
                    end
                    items.append([v, total / len(neighbours)])
                else:
                    items.append([v, position[v]])
                end
            end
            ordered = sort_by_value(items)
            level = []
            for i in rang(len(ordered)):
                level.append(ordered[i][0])
                position[ordered[i][0]] = Float(i)
            end
            layers[level_index] = level
        end
    end
    # 5. souradnice: hlavni osa = vrstvy, vedlejsi osa = poradi
    horizontal = graph["direction"] in ["LR", "RL"]
    gap = 26.0
    rank_gap = 46.0
    for v in rang(len(vertices)):
        if horizontal:
            vertices[v]["along"] = vertices[v]["h"]
            vertices[v]["across"] = vertices[v]["w"]
        else:
            vertices[v]["along"] = vertices[v]["w"]
            vertices[v]["across"] = vertices[v]["h"]
        end
    end
    # vychozi rozmisteni zleva doprava
    for level in layers:
        cursor = 0.0
        for v in level:
            vertices[v]["pos"] = cursor + vertices[v]["along"] / 2.0
            cursor += vertices[v]["along"] + gap
        end
    end
    # pritazeni k sousedum se zachovanim poradi a rozestupu
    for sweep in rang(8):
        downward = sweep % 2 == 0
        for level in layers:
            if not level:
                continue
            end
            desired = []
            for v in level:
                neighbours = upper[v]
                if not downward:
                    neighbours = lower[v]
                end
                if neighbours:
                    total = 0.0
                    for n in neighbours:
                        total += vertices[n]["pos"]
                    end
                    desired.append(total / len(neighbours))
                else:
                    desired.append(vertices[v]["pos"])
                end
            end
            # zleva nejmensi pozice >= pozadovane, zprava nejvetsi <= pozadovane, vysledek prumer
            # a nakonec znovu dodrzet rozestupy (vyvazene, bez driftu jednim smerem)
            count_level = len(level)
            left_pass = []
            for i in rang(count_level):
                value = desired[i]
                if i > 0:
                    value = max(value, left_pass[i - 1] + separation(vertices, level[i - 1], level[i], gap))
                end
                left_pass.append(value)
            end
            right_pass = []
            for i in rang(count_level):
                right_pass.append(0.0)
            end
            i = count_level - 1
            while i >= 0:
                value = desired[i]
                if i < count_level - 1:
                    value = min(value, right_pass[i + 1] - separation(vertices, level[i], level[i + 1], gap))
                end
                right_pass[i] = value
                i -= 1
            end
            placed = []
            for i in rang(count_level):
                value = (left_pass[i] + right_pass[i]) / 2.0
                if i > 0:
                    value = max(value, placed[i - 1] + separation(vertices, level[i - 1], level[i], gap))
                end
                placed.append(value)
            end
            for i in rang(len(level)):
                vertices[level[i]]["pos"] = placed[i]
            end
        end
    end
    # normalizace na 0
    minimum = 1.0e18
    for v in rang(len(vertices)):
        minimum = min(minimum, vertices[v]["pos"] - vertices[v]["along"] / 2.0)
    end
    for v in rang(len(vertices)):
        vertices[v]["pos"] -= minimum
    end
    cursor = 0.0
    for level in layers:
        thickness = 0.0
        for v in level:
            thickness = max(thickness, vertices[v]["across"])
        end
        for v in level:
            vertices[v]["rank"] = cursor + thickness / 2.0
        end
        cursor += thickness + rank_gap
    end
    total_rank = max(0.0, cursor - rank_gap)
    total_along = 0.0
    for v in rang(len(vertices)):
        total_along = max(total_along, vertices[v]["pos"] + vertices[v]["along"] / 2.0)
    end
    # mapovani na x, y podle smeru
    for v in rang(len(vertices)):
        vertex = vertices[v]
        if horizontal:
            vertex["x"] = vertex["rank"]
            vertex["y"] = vertex["pos"]
            if graph["direction"] == "RL":
                vertex["x"] = total_rank - vertex["rank"]
            end
        else:
            vertex["x"] = vertex["pos"]
            vertex["y"] = vertex["rank"]
            if graph["direction"] == "BT":
                vertex["y"] = total_rank - vertex["rank"]
            end
        end
    end
    width = total_along
    height = total_rank
    if horizontal:
        width = total_rank
        height = total_along
    end
    routes = []
    for item in chains:
        edge_index = item[0]
        chain = item[1]
        points = []
        for v in chain:
            points.append([vertices[v]["x"], vertices[v]["y"]])
        end
        if edge_index in reversed_edges:
            points.reverse()
        end
        routes.append({"edge": edges[edge_index][2], "points": points, "from": edges[edge_index][0], "to": edges[edge_index][1]})
    end
    loops = []
    for e in rang(len(edges)):
        if edges[e][0] == edges[e][1]:
            loops.append({"edge": edges[e][2], "node": edges[e][0]})
        end
    end
    boxes = []
    for i in rang(count):
        boxes.append(vertices[i])
    end
    return {"width": width + 2, "height": height + 2, "boxes": boxes, "routes": routes, "loops": loops, "horizontal": horizontal}
end

# ---------------------------------------------------------------- kresleni flowchart

function draw_shape(cr, shape, x, y, w, h, palette):
    left = x - w / 2.0
    top = y - h / 2.0
    call cairo.new_path(cr)
    if shape == "start":
        call cairo.arc(cr, x, y, w / 2.0, 0, 2 * math.PI)
        call rich_draw.source(cr, palette["fg"], 0.85)
        call cairo.fill(cr)
        return
    elif shape == "end":
        call cairo.arc(cr, x, y, w / 2.0, 0, 2 * math.PI)
        call rich_draw.source(cr, palette["fg"], 0.85)
        call cairo.set_line_width(cr, 1.6)
        call cairo.stroke(cr)
        call cairo.arc(cr, x, y, w / 2.0 - 4, 0, 2 * math.PI)
        call cairo.fill(cr)
        return
    elif shape == "bar":
        call rich_draw.rounded(cr, left, top, w, h, 2)
        call rich_draw.source(cr, palette["fg"], 0.85)
        call cairo.fill(cr)
        return
    elif shape == "circle":
        call cairo.arc(cr, x, y, w / 2.0, 0, 2 * math.PI)
    elif shape == "diamond":
        call cairo.move_to(cr, x, top)
        call cairo.line_to(cr, left + w, y)
        call cairo.line_to(cr, x, top + h)
        call cairo.line_to(cr, left, y)
        call cairo.close_path(cr)
    elif shape == "hexagon":
        inset = min(14.0, w / 4.0)
        call cairo.move_to(cr, left + inset, top)
        call cairo.line_to(cr, left + w - inset, top)
        call cairo.line_to(cr, left + w, y)
        call cairo.line_to(cr, left + w - inset, top + h)
        call cairo.line_to(cr, left + inset, top + h)
        call cairo.line_to(cr, left, y)
        call cairo.close_path(cr)
    elif shape == "parallelogram" or shape == "trapezoid":
        inset = 10.0
        call cairo.move_to(cr, left + inset, top)
        call cairo.line_to(cr, left + w, top)
        call cairo.line_to(cr, left + w - inset, top + h)
        call cairo.line_to(cr, left, top + h)
        call cairo.close_path(cr)
    elif shape == "flag":
        call cairo.move_to(cr, left, top)
        call cairo.line_to(cr, left + w, top)
        call cairo.line_to(cr, left + w, top + h)
        call cairo.line_to(cr, left, top + h)
        call cairo.line_to(cr, left + 10, y)
        call cairo.close_path(cr)
    elif shape == "stadium" or shape == "round":
        radius = h / 2.0
        if shape == "round":
            radius = min(12.0, h / 2.0)
        end
        call rich_draw.rounded(cr, left, top, w, h, radius)
    elif shape == "cylinder":
        ry = 6.0
        call cairo.move_to(cr, left, top + ry)
        call cairo.curve_to(cr, left, top - ry / 3.0, left + w, top - ry / 3.0, left + w, top + ry)
        call cairo.line_to(cr, left + w, top + h - ry)
        call cairo.curve_to(cr, left + w, top + h + ry / 3.0, left, top + h + ry / 3.0, left, top + h - ry)
        call cairo.close_path(cr)
    else:
        call rich_draw.rounded(cr, left, top, w, h, 4)
    end
    call rich_draw.source(cr, palette["node"])
    call cairo.fill_preserve(cr)
    call rich_draw.source(cr, palette["node_border"])
    call cairo.set_line_width(cr, 1.3)
    call cairo.stroke(cr)
    if shape == "cylinder":
        call cairo.new_path(cr)
        call cairo.move_to(cr, left, top + 6.0)
        call cairo.curve_to(cr, left, top + 6.0 * 2.3, left + w, top + 6.0 * 2.3, left + w, top + 6.0)
        call cairo.stroke(cr)
    elif shape == "subroutine":
        call cairo.new_path(cr)
        call cairo.move_to(cr, left + 7, top)
        call cairo.line_to(cr, left + 7, top + h)
        call cairo.move_to(cr, left + w - 7, top)
        call cairo.line_to(cr, left + w - 7, top + h)
        call cairo.stroke(cr)
    end
end

function clip_to_box(point, toward, box):
    # bod na okraji obdelniku uzlu ve smeru k toward (hrany konci na okraji)
    dx = toward[0] - point[0]
    dy = toward[1] - point[1]
    if dx == 0 and dy == 0:
        return point
    end
    half_w = box["w"] / 2.0 + 2
    half_h = box["h"] / 2.0 + 2
    scale = 1.0e18
    if dx != 0:
        scale = min(scale, half_w / abs(dx))
    end
    if dy != 0:
        scale = min(scale, half_h / abs(dy))
    end
    scale = min(scale, 1.0)
    return [point[0] + dx * scale, point[1] + dy * scale]
end

function arrow_head(cr, tip, from_point, color, size=8.0):
    dx = tip[0] - from_point[0]
    dy = tip[1] - from_point[1]
    length = sqrt(dx * dx + dy * dy)
    if length < 0.01:
        return
    end
    ux = dx / length
    uy = dy / length
    call cairo.new_path(cr)
    call cairo.move_to(cr, tip[0], tip[1])
    call cairo.line_to(cr, tip[0] - ux * size - uy * size * 0.45, tip[1] - uy * size + ux * size * 0.45)
    call cairo.line_to(cr, tip[0] - ux * size + uy * size * 0.45, tip[1] - uy * size - ux * size * 0.45)
    call cairo.close_path(cr)
    call rich_draw.source(cr, color)
    call cairo.fill(cr)
end

function edge_style(cr, style):
    if style == "dotted":
        call cairo.set_dash(cr, [3.0, 4.0], 0.0)
        call cairo.set_line_width(cr, 1.4)
    elif style == "thick":
        call cairo.set_dash(cr, [], 0.0)
        call cairo.set_line_width(cr, 2.8)
    else:
        call cairo.set_dash(cr, [], 0.0)
        call cairo.set_line_width(cr, 1.4)
    end
end

function draw_label_box(cr, text, x, y, palette, size=8.5):
    if not text:
        return
    end
    item = wrapped_layout(cr, text, size, 140)
    extent = pango.layout_get_pixel_size(item)
    w = min(extent[0], 140) + 8
    h = extent[1] + 4
    call rich_draw.source(cr, palette["bg"], 0.92)
    call rich_draw.rounded(cr, x - w / 2.0, y - h / 2.0, w, h, 4)
    call cairo.fill(cr)
    call rich_draw.source(cr, palette["dim"])
    call cairo.move_to(cr, x - 70, y - h / 2.0 + 2)
    call pango.cairo_show_layout(cr, item)
    call pango.layout_unref(item)
end

function draw_flow(cr, graph, layout, palette, offset_x, offset_y):
    boxes = layout["boxes"]
    line_color = palette["dim"]
    call cairo.save(cr)
    call cairo.translate(cr, offset_x, offset_y)
    labels = []
    for route in layout["routes"]:
        points = route["points"]
        edge = route["edge"]
        # body jsou vzdy od puvodniho zdroje k cili (otocene hrany cyklu se vratily zpet)
        source_box = boxes[route["from"]]
        target_box = boxes[route["to"]]
        start = clip_to_box(points[0], points[1], source_box)
        stop = clip_to_box(points[len(points) - 1], points[len(points) - 2], target_box)
        path = [start] + points[1:len(points) - 1] + [stop]
        call cairo.new_path(cr)
        call cairo.move_to(cr, path[0][0], path[0][1])
        if len(path) == 2:
            call cairo.line_to(cr, path[1][0], path[1][1])
        else:
            # hladka krivka pres pomocne body (stredy useku jako kotvy)
            for i in rang(1, len(path) - 1):
                middle = [(path[i][0] + path[i + 1][0]) / 2.0, (path[i][1] + path[i + 1][1]) / 2.0]
                if i == len(path) - 2:
                    middle = path[i + 1]
                end
                call cairo.curve_to(cr, path[i][0], path[i][1], path[i][0], path[i][1], middle[0], middle[1])
            end
        end
        call rich_draw.source(cr, line_color)
        call edge_style(cr, edge["style"])
        call cairo.stroke(cr)
        call cairo.set_dash(cr, [], 0.0)
        if edge["arrow"]:
            call arrow_head(cr, path[len(path) - 1], path[len(path) - 2], line_color)
        end
        if edge.get("back_arrow"):
            call arrow_head(cr, path[0], path[1], line_color)
        end
        if edge["label"]:
            middle_index = len(path) // 2
            lx = (path[middle_index - 1][0] + path[middle_index][0]) / 2.0
            ly = (path[middle_index - 1][1] + path[middle_index][1]) / 2.0
            labels.append([edge["label"], lx, ly])
        end
    end
    for item in layout["loops"]:
        box = boxes[item["node"]]
        x = box["x"] + box["w"] / 2.0
        y = box["y"]
        call cairo.new_path(cr)
        call cairo.move_to(cr, x, y - 6)
        call cairo.curve_to(cr, x + 28, y - 24, x + 28, y + 24, x, y + 6)
        call rich_draw.source(cr, line_color)
        call edge_style(cr, item["edge"]["style"])
        call cairo.stroke(cr)
        call arrow_head(cr, [x, y + 6], [x + 10, y + 14], line_color)
        if item["edge"]["label"]:
            labels.append([item["edge"]["label"], x + 30, y])
        end
    end
    for box in boxes:
        node = graph["nodes"][box["id"]]
        call draw_shape(cr, node["shape"], box["x"], box["y"], box["w"], box["h"], palette)
        if node["label"] and node["shape"] not in ["start", "end", "bar"]:
            item = wrapped_layout(cr, node["label"])
            extent = pango.layout_get_pixel_size(item)
            call rich_draw.source(cr, palette["fg"])
            call cairo.move_to(cr, box["x"] - NODE_TEXT_WIDTH / 2.0, box["y"] - extent[1] / 2.0)
            call pango.cairo_show_layout(cr, item)
            call pango.layout_unref(item)
        end
    end
    for label in labels:
        call draw_label_box(cr, label[0], label[1], label[2], palette)
    end
    call cairo.restore(cr)
end

# ---------------------------------------------------------------- sekvencni diagram

function layout_sequence(diagram, cr):
    names = diagram["participants"]
    widths = []
    for name in names:
        size = label_size(cr, diagram["labels"][name], 9.5, 150)
        widths.append(max(80.0, size[0] + 24))
    end
    gaps = []
    for i in rang(len(names)):
        gaps.append(0.0)
    end
    number = 0
    for row in diagram["rows"]:
        if row["type"] == "message":
            a = names.index(row["from"])
            b = names.index(row["to"])
            label = row["label"]
            if diagram["autonumber"]:
                number += 1
                label = String(number) + ". " + label
            end
            row["text"] = label
            size = label_size(cr, label, 8.5, 260)
            if a != b:
                low = min(a, b)
                span = abs(a - b)
                need = (size[0] + 30) / span
                for i in rang(low, low + span):
                    gaps[i] = max(gaps[i], need)
                end
            else:
                gaps[a] = max(gaps[a], size[0] + 50)
            end
        end
    end
    centers = []
    cursor = 10.0
    for i in rang(len(names)):
        if i > 0:
            cursor += max(widths[i - 1] / 2.0 + widths[i] / 2.0 + 30, gaps[i - 1])
        else:
            cursor += widths[0] / 2.0
        end
        centers.append(cursor)
    end
    width = cursor + widths[len(widths) - 1] / 2.0 + 10
    if gaps[len(gaps) - 1] > 0:
        width = max(width, centers[len(centers) - 1] + gaps[len(gaps) - 1])
    end
    head_height = 0.0
    for name in names:
        head_height = max(head_height, label_size(cr, diagram["labels"][name], 9.5, 150)[1] + 16)
    end
    y = head_height + 22
    rows = []
    for row in diagram["rows"]:
        if row["type"] == "message":
            text_height = label_size(cr, row["text"], 8.5, 260)[1]
            height = max(30.0, text_height + 18)
            if row["from"] == row["to"]:
                height += 16
            end
            rows.append([row, y, height])
            y += height
        elif row["type"] == "note":
            text_height = label_size(cr, row["label"], 8.5, 180)[1]
            rows.append([row, y, text_height + 18])
            y += text_height + 22
        elif row["type"] == "open":
            rows.append([row, y, 22.0])
            y += 24
        elif row["type"] == "divider":
            rows.append([row, y, 20.0])
            y += 22
        else:
            rows.append([row, y, 8.0])
            y += 10
        end
    end
    height = y + head_height + 12
    return {"width": width, "height": height, "centers": centers, "widths": widths, "head": head_height, "rows": rows}
end

function draw_participant(cr, diagram, name, x, y, w, h, palette):
    if name in diagram["actors"]:
        # panacek
        call rich_draw.source(cr, palette["node_border"])
        call cairo.set_line_width(cr, 1.5)
        call cairo.new_path(cr)
        call cairo.arc(cr, x, y + 7, 5, 0, 2 * math.PI)
        call cairo.stroke(cr)
        call cairo.move_to(cr, x, y + 12)
        call cairo.line_to(cr, x, y + 22)
        call cairo.move_to(cr, x - 8, y + 15)
        call cairo.line_to(cr, x + 8, y + 15)
        call cairo.move_to(cr, x, y + 22)
        call cairo.line_to(cr, x - 6, y + 30)
        call cairo.move_to(cr, x, y + 22)
        call cairo.line_to(cr, x + 6, y + 30)
        call cairo.stroke(cr)
        call rich_draw.draw_text(cr, diagram["labels"][name], x, y + 31, palette["fg"], 8.5, False, 1)
        return
    end
    call draw_shape(cr, "rect", x, y + h / 2.0, w, h, palette)
    item = wrapped_layout(cr, diagram["labels"][name], 9.5, 150)
    extent = pango.layout_get_pixel_size(item)
    call rich_draw.source(cr, palette["fg"])
    call cairo.move_to(cr, x - 75, y + h / 2.0 - extent[1] / 2.0)
    call pango.cairo_show_layout(cr, item)
    call pango.layout_unref(item)
end

function draw_sequence(cr, diagram, layout, palette, offset_x, offset_y):
    call cairo.save(cr)
    call cairo.translate(cr, offset_x, offset_y)
    names = diagram["participants"]
    centers = layout["centers"]
    head = layout["head"]
    bottom = layout["height"] - head - 6
    # zivotni cary
    for i in rang(len(names)):
        call rich_draw.source(cr, palette["axis"])
        call cairo.set_line_width(cr, 1.0)
        call cairo.set_dash(cr, [4.0, 4.0], 0.0)
        call cairo.move_to(cr, centers[i], head + 4)
        call cairo.line_to(cr, centers[i], bottom)
        call cairo.stroke(cr)
        call cairo.set_dash(cr, [], 0.0)
    end
    # bloky loop/alt (od otevreni po zavreni)
    opened = []
    for item in layout["rows"]:
        row = item[0]
        y = item[1]
        if row["type"] == "open":
            opened.append([row, y])
        elif row["type"] == "close" and opened:
            start = opened.pop()
            inset = 6.0 * (len(opened))
            left = 4.0 + inset
            right = layout["width"] - 4.0 - inset
            call rich_draw.source(cr, palette["accent"], 0.07)
            call rich_draw.rounded(cr, left, start[1], right - left, y - start[1], 5)
            call cairo.fill_preserve(cr)
            call rich_draw.source(cr, palette["node_border"])
            call cairo.set_line_width(cr, 1.0)
            call cairo.stroke(cr)
            tag = start[0]["kind"]
            size = rich_draw.draw_text(cr, tag, left + 6, start[1] + 3, palette["accent"], 8.0, True)
            if start[0]["label"]:
                call rich_draw.draw_text(cr, "[" + start[0]["label"] + "]", left + 14 + size[0], start[1] + 3, palette["dim"], 8.0)
            end
        end
    end
    for item in layout["rows"]:
        row = item[0]
        y = item[1]
        if row["type"] == "divider":
            call rich_draw.source(cr, palette["node_border"])
            call cairo.set_dash(cr, [3.0, 3.0], 0.0)
            call cairo.move_to(cr, 8, y + 4)
            call cairo.line_to(cr, layout["width"] - 8, y + 4)
            call cairo.stroke(cr)
            call cairo.set_dash(cr, [], 0.0)
            if row["label"]:
                call rich_draw.draw_text(cr, "[" + row["label"] + "]", 14, y + 6, palette["dim"], 8.0)
            end
        elif row["type"] == "message":
            a = names.index(row["from"])
            b = names.index(row["to"])
            line_y = y + item[2] - 8
            call rich_draw.source(cr, palette["fg"], 0.75)
            call cairo.set_line_width(cr, 1.3)
            if row["dashed"]:
                call cairo.set_dash(cr, [4.0, 3.0], 0.0)
            end
            if a == b:
                x = centers[a]
                call cairo.move_to(cr, x, line_y - 16)
                call cairo.line_to(cr, x + 30, line_y - 16)
                call cairo.line_to(cr, x + 30, line_y)
                call cairo.line_to(cr, x + 2, line_y)
                call cairo.stroke(cr)
                call cairo.set_dash(cr, [], 0.0)
                call arrow_head(cr, [x + 1, line_y], [x + 30, line_y], palette["fg"], 7.0)
                call draw_message_text(cr, row["text"], x + 36, line_y - 16 - 2, palette, 0)
            else:
                x1 = centers[a]
                x2 = centers[b]
                call cairo.move_to(cr, x1, line_y)
                call cairo.line_to(cr, x2, line_y)
                call cairo.stroke(cr)
                call cairo.set_dash(cr, [], 0.0)
                if row["head"] == "x":
                    sx = x2 - 8
                    if x2 < x1:
                        sx = x2 + 8
                    end
                    call cairo.move_to(cr, sx - 4, line_y - 4)
                    call cairo.line_to(cr, sx + 4, line_y + 4)
                    call cairo.move_to(cr, sx - 4, line_y + 4)
                    call cairo.line_to(cr, sx + 4, line_y - 4)
                    call cairo.stroke(cr)
                elif row["open"]:
                    direction = 1
                    if x2 < x1:
                        direction = -1
                    end
                    call cairo.move_to(cr, x2 - direction * 8, line_y - 4)
                    call cairo.line_to(cr, x2, line_y)
                    call cairo.line_to(cr, x2 - direction * 8, line_y + 4)
                    call cairo.stroke(cr)
                else:
                    call arrow_head(cr, [x2, line_y], [x1, line_y], palette["fg"], 8.0)
                end
                call draw_message_text(cr, row["text"], (x1 + x2) / 2.0, line_y - 4, palette, 1)
            end
        elif row["type"] == "note":
            indexes = []
            for name in row["names"]:
                indexes.append(names.index(name))
            end
            size = label_size(cr, row["label"], 8.5, 180)
            w = size[0] + 14
            h = size[1] + 10
            x = centers[indexes[0]]
            if row["where"] == "right of":
                x = x + 12 + w / 2.0
            elif row["where"] == "left of":
                x = x - 12 - w / 2.0
            elif len(indexes) > 1:
                x = (centers[min(indexes)] + centers[max(indexes)]) / 2.0
                w = max(w, centers[max(indexes)] - centers[min(indexes)] + 40)
            end
            call cairo.new_path(cr)
            call rich_draw.rounded(cr, x - w / 2.0, y + 2, w, h, 3)
            call cairo.set_source_rgba(cr, 1.0, 0.86, 0.35, 0.35)
            call cairo.fill_preserve(cr)
            call cairo.set_source_rgba(cr, 0.85, 0.65, 0.1, 0.8)
            call cairo.set_line_width(cr, 1.0)
            call cairo.stroke(cr)
            item = wrapped_layout(cr, row["label"], 8.5, 180)
            call rich_draw.source(cr, palette["fg"])
            call cairo.move_to(cr, x - 90, y + 7)
            call pango.cairo_show_layout(cr, item)
            call pango.layout_unref(item)
        end
    end
    for i in rang(len(names)):
        call draw_participant(cr, diagram, names[i], centers[i], 2, layout["widths"][i], head - 4, palette)
        call draw_participant(cr, diagram, names[i], centers[i], bottom, layout["widths"][i], head - 4, palette)
    end
    call cairo.restore(cr)
end

function draw_message_text(cr, text, x, baseline, palette, align):
    if not text:
        return
    end
    item = wrapped_layout(cr, text, 8.5, 260)
    extent = pango.layout_get_pixel_size(item)
    left = x - 130
    if align == 0:
        call pango.layout_set_alignment(item, 0)
        left = x
    end
    call rich_draw.source(cr, palette["fg"], 0.9)
    call cairo.move_to(cr, left, baseline - extent[1])
    call pango.cairo_show_layout(cr, item)
    call pango.layout_unref(item)
end

# ---------------------------------------------------------------- casova osa

function layout_timeline(diagram, cr, available):
    periods = diagram["periods"]
    column = 150.0
    per_row = max(1, Int((available - 20) / column))
    per_row = min(per_row, len(periods))
    rows = []
    index = 0
    while index < len(periods):
        rows.append(periods[index:index + per_row])
        index += per_row
    end
    heights = []
    for row in rows:
        tallest = 0.0
        for period in row:
            total = 0.0
            for event in period["events"]:
                total += label_size(cr, event, 8.5, column - 24)[1] + 12
            end
            tallest = max(tallest, total)
        end
        heights.append(tallest + 64)
    end
    title_height = 0.0
    if diagram["title"]:
        title_height = 26.0
    end
    height = title_height + 8
    for value in heights:
        height += value
    end
    return {"width": max(column * per_row + 20, 200.0), "height": height, "rows": rows, "heights": heights, "column": column, "title_height": title_height}
end

function draw_timeline(cr, diagram, layout, palette, offset_x, offset_y):
    call cairo.save(cr)
    call cairo.translate(cr, offset_x, offset_y)
    y = 4.0
    if diagram["title"]:
        call rich_draw.draw_text(cr, diagram["title"], layout["width"] / 2.0, y, palette["fg"], 10.5, True, 1)
        y += layout["title_height"]
    end
    column = layout["column"]
    color_index = 0
    sections = {}
    for r in rang(len(layout["rows"])):
        row = layout["rows"][r]
        axis_y = y + 30
        call rich_draw.source(cr, palette["axis"])
        call cairo.set_line_width(cr, 2.0)
        call cairo.move_to(cr, 10, axis_y)
        call cairo.line_to(cr, 10 + column * len(row), axis_y)
        call cairo.stroke(cr)
        for i in rang(len(row)):
            period = row[i]
            key = period["section"]
            if key not in sections:
                sections[key] = len(sections)
            end
            color = rich_draw.series_color(palette, "", sections[key])
            cx = 10 + column * i + column / 2.0
            call rich_draw.draw_text(cr, period["period"], cx, y, palette["fg"], 9.5, True, 1, Int(column - 8))
            call cairo.new_path(cr)
            call cairo.arc(cr, cx, axis_y, 6, 0, 2 * math.PI)
            call rich_draw.source(cr, color)
            call cairo.fill(cr)
            ey = axis_y + 16
            for event in period["events"]:
                size = label_size(cr, event, 8.5, column - 24)
                call rich_draw.source(cr, color, 0.14)
                call rich_draw.rounded(cr, cx - (column - 12) / 2.0, ey, column - 12, size[1] + 8, 5)
                call cairo.fill(cr)
                item = wrapped_layout(cr, event, 8.5, column - 24)
                call rich_draw.source(cr, palette["fg"])
                call cairo.move_to(cr, cx - (column - 24) / 2.0, ey + 4)
                call pango.cairo_show_layout(cr, item)
                call pango.layout_unref(item)
                ey += size[1] + 12
            end
        end
        y += layout["heights"][r]
    end
    call cairo.restore(cr)
end

# ---------------------------------------------------------------- spolecne

function measure(diagram, available=560.0):
    # {"width", "height", ...} prirozena velikost diagramu v bodech
    context = measure_context()
    result = None
    try:
        result = layout_of(diagram, context[1], available)
    else:
        call release_context(context)
        Error(DiagramError: String(last_error()))
    end
    call release_context(context)
    return result
end

function layout_of(diagram, cr, available):
    kind = diagram["kind"]
    if kind == "flow":
        result = layout_flow(diagram, cr)
        if diagram["title"]:
            result["title_height"] = 24.0
            result["height"] += 24
        end
        return result
    elif kind == "sequence":
        result = layout_sequence(diagram, cr)
        if diagram["title"]:
            result["title_height"] = 24.0
            result["height"] += 24
        end
        return result
    elif kind == "timeline":
        return layout_timeline(diagram, cr, available)
    elif kind == "pie":
        return {"width": available, "height": rich_draw.chart_height(diagram["chart"], available)}
    end
    call fail("unknown diagram")
end

function draw(cr, diagram, layout, width, height, palette):
    # nakresli diagram vystredeny a zmenseny do width x height
    kind = diagram["kind"]
    if kind == "pie":
        call rich_draw.draw_chart(cr, diagram["chart"], width, height, palette, None)
        return
    end
    padding = 12.0
    natural_w = layout["width"] + padding * 2
    natural_h = layout["height"] + padding * 2
    scale = min(1.0, width / natural_w, height / natural_h)
    call cairo.save(cr)
    call cairo.translate(cr, (width - natural_w * scale) / 2.0, 0)
    call cairo.scale(cr, scale, scale)
    top = padding
    if kind in ["flow", "sequence"] and diagram["title"]:
        call rich_draw.draw_text(cr, diagram["title"], natural_w / 2.0, 4, palette["fg"], 10.5, True, 1)
        top += layout["title_height"]
    end
    if kind == "flow":
        call draw_flow(cr, diagram, layout, palette, padding, top)
    elif kind == "sequence":
        call draw_sequence(cr, diagram, layout, palette, padding, top)
    elif kind == "timeline":
        call draw_timeline(cr, diagram, layout, palette, padding, padding)
    end
    call cairo.restore(cr)
end

function display_size(layout, available, kind):
    # velikost widgetu: prirozena, zmensena na sirku bubliny (min. 55 %), jinak posuvnik
    if kind == "pie":
        return [Int(available), Int(layout["height"])]
    end
    natural_w = layout["width"] + 24
    natural_h = layout["height"] + 24
    scale = min(1.0, available / natural_w)
    if scale < 0.55:
        scale = 0.55
    end
    return [Int(natural_w * scale + 0.5), Int(natural_h * scale + 0.5)]
end
