# Shared values and filesystem primitives. No Python runtime or shell evaluation.
load glib
load json
load process
load time
load platform
load json_store

function strip_text(text, characters=" \t\n\r"):
    return platform.strip(text, characters)
end

function lstrip_text(text, characters=" \t\n\r"):
    return platform.strip(text, characters, True, False)
end

function rstrip_text(text, characters=" \t\n\r"):
    return platform.strip(text, characters, False, True)
end

function fallback(value, alternative):
    if value:
        return value
    end
    return alternative
end

function copy(value):
    return json.decode(json.encode(value))
end

function python_json(value):
    # Match json.dumps(..., ensure_ascii=False)'s separators for history budgets.
    encoded = json.encode(value)
    output = []
    quoted = False
    escaped = False
    for char in encoded:
        output.append(char)
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == "\"":
                quoted = False
            end
        elif char == "\"":
            quoted = True
        elif char in ",:":
            output.append(" ")
        end
    end
    return "".join(output)
end

function py_repr(value):
    # repr() textu jako v Pythonu ({0!r}): apostrofy, nebo uvozovky kdyz text apostrof obsahuje
    text = String(value)
    quote = "'"
    if "'" in text and "\"" not in text:
        quote = "\""
    end
    output = [quote]
    for char in text:
        code = ord(char)
        if char == "\\":
            output.append("\\\\")
        elif char == quote:
            output.append("\\" + char)
        elif char == "\n":
            output.append("\\n")
        elif char == "\r":
            output.append("\\r")
        elif char == "\t":
            output.append("\\t")
        elif code < 32 or code == 127:
            output.append("\\x" + hex4(code)[2:])
        else:
            output.append(char)
        end
    end
    output.append(quote)
    return "".join(output)
end

function python_json_ascii(value):
    # json.dumps(value) s vychozim ensure_ascii=True: znaky mimo ASCII jako \uXXXX (nad BMP dvojice)
    output = []
    for char in python_json(value):
        code = ord(char)
        if code < 128:
            output.append(char)
        elif code < 65536:
            output.append("\\u" + hex4(code))
        else:
            rest = code - 65536
            output.append("\\u" + hex4(55296 + (rest >> 10)) + "\\u" + hex4(56320 + (rest & 1023)))
        end
    end
    return "".join(output)
end

function hex4(value):
    digits = "0123456789abcdef"
    return digits[(value >> 12) & 15] + digits[(value >> 8) & 15] + digits[(value >> 4) & 15] + digits[value & 15]
end

function environment(name, fallback=""):
    value = glib.getenv(name)
    if value:
        return value
    end
    return fallback
end

function dirname(path):
    parts = String(path).rstrip("/").split("/")
    if len(parts) <= 1:
        return "."
    end
    result = "/".join(parts[:len(parts) - 1])
    return fallback(result, "/")
end

# Kratka cesta pro stavovy radek: domovska slozka -> "~", dlouhy stred -> "…"
# (zacatek a posledni slozky zustanou), napr. "~/Projects/…/src/app".
function short_path(path, home="", limit=48):
    text = String(path)
    base = String(home).rstrip("/")
    if base and (text == base or text.startswith(base + "/")):
        text = "~" + text[len(base):]
    end
    if len(text) <= limit:
        return text
    end
    parts = text.split("/")
    if len(parts) <= 3:
        return text
    end
    head = parts[0] + "/" + parts[1]
    tail = parts[len(parts) - 1]
    k = len(parts) - 2
    while k > 1 and len(head) + 3 + len(parts[k]) + 1 + len(tail) <= limit:
        tail = parts[k] + "/" + tail
        k = k - 1
    end
    if k <= 1:
        return text
    end
    return head + "/…/" + tail
end

function join(left, right):
    if right.startswith("/"):
        return right
    end
    return left.rstrip("/") + "/" + right
end

function normalize(path):
    absolute = path.startswith("/")
    parts = []
    for part in path.split("/"):
        if part == "" or part == ".":
            continue
        end
        if part == ".." and len(parts) > 0 and parts[len(parts) - 1] != "..":
            call parts.pop()
        elif part != ".." or not absolute:
            parts.append(part)
        end
    end
    prefix = ""
    if absolute:
        prefix = "/"
    end
    result = prefix + "/".join(parts)
    return fallback(result, ".")
end

function expand(path, workdir="", home=""):
    home = fallback(home, glib.home_dir())
    path = String(path)
    if path == "~":
        path = home
    elif path.startswith("~/"):
        path = home + path[1:]
    end
    if not path.startswith("/"):
        path = join(fallback(workdir, platform.current_dir()), path)
    end
    return normalize(path)
end

function mkdir_private(path):
    call process.check("/usr/bin/mkdir", ["-p", "-m", "700", "--", path])
end

function remove_file(path):
    call process.check("/usr/bin/rm", ["-f", "--", path])
end

function temp_private(folder, prefix=".tmp-"):
    call mkdir_private(folder)
    return process.check("/usr/bin/mktemp", ["--", join(folder, prefix + "XXXXXXXXXXXX")]).strip(WHITESPACE)
end

function atomic_text(path, text):
    temporary = temp_private(dirname(path))
    try:
        call writefile(temporary, text)
        call process.check("/usr/bin/mv", ["-fT", "--", temporary, path])
    else:
        failure = String(last_error())
        if exists(temporary):
            call remove_file(temporary)
        end
        Error(FileError: failure)
    end
end

function atomic_bytes(path, bytes):
    temporary = temp_private(dirname(path))
    try:
        call writebytes(temporary, bytes)
        call process.check("/usr/bin/mv", ["-fT", "--", temporary, path])
    else:
        failure = String(last_error())
        if exists(temporary):
            call remove_file(temporary)
        end
        Error(FileError: failure)
    end
end

function atomic_json(path, value):
    call atomic_text(path, json_store.encode(value) + "\n")
end

function read_json(path, fallback=None):
    try:
        return json_store.decode(readfile(path))
    else:
        return fallback
    end
end

function read_json_text(text):
    return json.decode(text)
end

function identifier(text, limit=80, alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-"):
    if type(text) != "String" or len(text) < 1 or len(text) > limit:
        return False
    end
    for c in text:
        if c not in alphabet:
            return False
        end
    end
    return True
end

function random_hex(length=16):
    result = process.check("/usr/bin/od", ["-An", "-N", String((length + 1) // 2), "-tx1", "/dev/urandom"])
    return "".join(result.split())[:length]
end

function words(text):
    return " ".join(split_words(String(text)))
end

WHITESPACE = " \t\n\r"
for whitespace_code in [11,12,28,29,30,31,133,160,5760,8192,8193,8194,8195,8196,8197,8198,8199,8200,8201,8202,8232,8233,8239,8287,12288]:
    WHITESPACE += chr(whitespace_code)
end

function split_words(text):
    output = []
    current = ""
    for char in text:
        if char in WHITESPACE:
            if current:
                output.append(current)
                current = ""
            end
        else:
            current += char
        end
    end
    if current:
        output.append(current)
    end
    return output
end

function splitlines(value):
    # String(): rez netypovaneho parametru je v LSL 0.10.6 pomaly
    text = String(value)
    if text == "":
        return []
    end
    separators = "\r\n|[\n\r" + chr(11) + chr(12) + chr(28) + chr(29) + chr(30) + chr(133) + chr(8232) + chr(8233) + "]"
    output = []
    position = 0
    for match in platform.regex_findall(separators, text):
        output.append(text[position:match["start"]])
        position = match["end"]
    end
    if position < len(text):
        output.append(text[position:])
    end
    return output
end

function rfind(text, needle):
    index = len(text) - len(needle)
    while index >= 0:
        if text[index:index + len(needle)] == needle:
            return index
        end
        index -= 1
    end
    return -1
end

function without(value, key):
    result = {}
    for k in value.keys():
        if k != key:
            result[k] = value[k]
        end
    end
    return result
end

function text(value):
    if value == None:
        return ""
    end
    return String(value)
end

function base64_encode(bytes):
    return platform.base64_encode(bytes)
end

function base64_decode(text):
    return platform.base64_decode(text)
end

function base64_decode_lenient(text):
    # jako Python base64.b64decode bez validate: znaky mimo abecedu (zalomeni radku) se zahodi
    return platform.base64_decode(platform.regex_replace("[^A-Za-z0-9+/=]", "", String(text)))
end
