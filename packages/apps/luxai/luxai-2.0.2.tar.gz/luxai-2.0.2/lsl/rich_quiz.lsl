# lsl: internal-abi
# Stav kvizu bez GTK (testuje rich_test_main): rezim zobrazeni ("pages" = jedna otazka na karte,
# "list" = vsechny pod sebou), odpovedi, napovedy, aktualni stranka, poradi otazek po
# "Zamichat a zkusit znovu" a klavesove zkratky. Stav je slovnik ulozeny u zpravy (_rich);
# normalize() ho pred pouzitim zkontroluje, takze stary format {"answers", "hints"} z 2.0.2-4/-5
# (bez "page", "mode", "order") i rucne poskozeny soubor konverzace zustanou pouzitelne.

load rich_blocks

MODES = ["pages", "list"]

function count(spec):
    return len(spec["questions"])
end

function mode(spec, state):
    # volba uzivatele (Zobrazit vsechny otazky / Po jedne) ma prednost pred blokem;
    # jedna otazka je vzdy obycejny seznam (karty by jen pridaly tlacitka navic)
    if count(spec) < 2:
        return "list"
    end
    chosen = state.get("mode")
    if chosen in MODES:
        return chosen
    end
    if spec.get("mode") in MODES:
        return spec["mode"]
    end
    return "pages"
end

function whole(value):
    # cele cislo z JSON (Int nebo Float bez desetinne casti), jinak None
    if type(value) == "Bool":
        return None
    end
    if type(value) == "Int":
        return value
    end
    if type(value) == "Float" and Float(Int(value)) == value:
        return Int(value)
    end
    return None
end

function question_key(text, total):
    # "3" -> 3, kdyz je to platne cislo otazky ("03" ne); jinak -1
    if type(text) != "String" or not text or len(text) > 3:
        return -1
    end
    for char in text:
        if char not in "0123456789":
            return -1
        end
    end
    number = Int(text)
    if String(number) != text or number >= total:
        return -1
    end
    return number
end

function valid_answer(question, answer):
    if type(answer) != "List" or not answer:
        return False
    end
    seen = []
    for item in answer:
        number = whole(item)
        if number == None or number < 0 or number >= len(question["options"]) or number in seen:
            return False
        end
        seen.append(number)
    end
    if not question["multiple"] and len(seen) != 1:
        return False
    end
    return True
end

function identity(total):
    output = []
    for index in rang(total):
        output.append(index)
    end
    return output
end

function valid_order(value, total):
    if type(value) != "List" or len(value) != total:
        return False
    end
    seen = {}
    for item in value:
        number = whole(item)
        if number == None or number < 0 or number >= total or String(number) in seen:
            return False
        end
        seen[String(number)] = True
    end
    return True
end

function order(spec, state):
    # poradi otazek na strankach (indexy do spec["questions"])
    total = count(spec)
    if valid_order(state.get("order"), total):
        output = []
        for item in state["order"]:
            output.append(whole(item))
        end
        return output
    end
    return identity(total)
end

function normalize(spec, state):
    # opravi stav na miste a vrati ho; neplatne casti zahodi, nic nevymysli
    total = count(spec)
    answers = {}
    if type(state.get("answers")) == "Dictionary":
        for key in state["answers"].keys():
            qi = question_key(key, total)
            if qi >= 0 and valid_answer(spec["questions"][qi], state["answers"][key]):
                clean = []
                for item in state["answers"][key]:
                    clean.append(whole(item))
                end
                clean.sort()
                answers[String(qi)] = clean
            end
        end
    end
    state["answers"] = answers
    hints = []
    if type(state.get("hints")) == "List":
        for item in state["hints"]:
            if question_key(item, total) >= 0 and item not in hints:
                hints.append(item)
            end
        end
    end
    state["hints"] = hints
    if "order" in state and not valid_order(state["order"], total):
        call state.pop("order")
    end
    if "mode" in state and state["mode"] not in MODES:
        call state.pop("mode")
    end
    page = whole(state.get("page"))
    if page == None or page < 0 or page > total:
        # stary stav bez stranky: prvni nezodpovezena otazka, po dokonceni souhrn
        page = first_open(spec, state)
    end
    state["page"] = page
    return state
end

function first_open(spec, state):
    sequence = order(spec, state)
    for position in rang(len(sequence)):
        if String(sequence[position]) not in state.get("answers", {}):
            return position
        end
    end
    return len(sequence)
end

function question_at(spec, state, page):
    # index otazky na strance, -1 = souhrn
    sequence = order(spec, state)
    if page < 0 or page >= len(sequence):
        return -1
    end
    return sequence[page]
end

function answered(state, qi):
    return String(qi) in state["answers"]
end

function is_right(spec, state, qi):
    answer = state["answers"].get(String(qi))
    return type(answer) == "List" and sorted(answer) == sorted(spec["questions"][qi]["correct"])
end

function status(spec, state, qi):
    if not answered(state, qi):
        return "open"
    end
    if is_right(spec, state, qi):
        return "right"
    end
    return "wrong"
end

function score(spec, state):
    total = count(spec)
    right = 0
    done = 0
    for qi in rang(total):
        if answered(state, qi):
            done += 1
            if is_right(spec, state, qi):
                right += 1
            end
        end
    end
    return {"right": right, "answered": done, "total": total}
end

function answer(spec, state, qi, options):
    # zaznamena odpoved; False = uz zodpovezeno nebo neplatna volba (druhy klik nic nezmeni)
    if qi < 0 or qi >= count(spec) or answered(state, qi):
        return False
    end
    if not valid_answer(spec["questions"][qi], options):
        return False
    end
    clean = []
    for item in options:
        clean.append(whole(item))
    end
    clean.sort()
    state["answers"][String(qi)] = clean
    return True
end

function hint(spec, state, qi):
    if qi < 0 or qi >= count(spec) or not spec["questions"][qi]["hint"]:
        return False
    end
    if String(qi) not in state["hints"]:
        state["hints"].append(String(qi))
    end
    return True
end

function go(spec, state, page):
    # presun na stranku (0 .. pocet otazek - 1, pocet = souhrn); vraci novou stranku
    state["page"] = max(0, min(count(spec), page))
    return state["page"]
end

function step(spec, state, delta):
    return go(spec, state, state["page"] + delta)
end

function permutation(total, seed_text):
    # stabilni michani (stejny text = stejne poradi): Fisher-Yates s LCG ze FNV-1a textu
    # (stejne jako michani moznosti od 2.0.2-4, aby ulozene odpovedi sedely)
    output = identity(total)
    seed = 0
    for char in rich_blocks.hash_text(seed_text):
        seed = (seed * 16 + "0123456789abcdef".find(char)) & 2147483647
    end
    i = total - 1
    while i > 0:
        seed = (seed * 1103515245 + 12345) & 2147483647
        j = seed % (i + 1)
        swap = output[i]
        output[i] = output[j]
        output[j] = swap
        i -= 1
    end
    return output
end

function reset(spec, state, shuffle, seed_text=""):
    # Zkusit znovu: smaze odpovedi a napovedy, zacne prvni strankou; se zamichanim jine poradi
    # otazek nez dosud (u 2+ otazek), stabilni podle kola, aby se dalo otestovat
    state["answers"] = {}
    state["hints"] = []
    state["page"] = 0
    total = count(spec)
    if not shuffle or total < 2:
        if "order" in state:
            call state.pop("order")
        end
        return state
    end
    previous = order(spec, state)
    rounds = whole(state.get("round"))
    if rounds == None or rounds < 0:
        rounds = 0
    end
    attempt = 0
    candidate = previous
    while attempt < 20 and candidate == previous:
        rounds += 1
        candidate = permutation(total, seed_text + ":" + String(rounds))
        attempt += 1
    end
    if candidate == previous:
        # (prakticky nenastane) posun o jednu
        candidate = previous[1:] + previous[:1]
    end
    state["round"] = rounds
    state["order"] = candidate
    return state
end

function key_action(keyval, modifiers=0):
    # klavesa na karte kvizu -> {"action": "back"|"next"|"enter"|"choose", "position": n} nebo None
    # (Ctrl/Alt/Super se nechavaji oknu: Ctrl+C, Ctrl+N ...)
    if (modifiers & (4 | 8 | 67108864)) != 0:
        return None
    end
    if keyval in [65361, 65365, 65430, 65434]:
        # Left, Page_Up, KP_Left, KP_Page_Up
        return {"action": "back"}
    end
    if keyval in [65363, 65366, 65432, 65435]:
        # Right, Page_Down, KP_Right, KP_Page_Down
        return {"action": "next"}
    end
    if keyval in [65293, 65421]:
        return {"action": "enter"}
    end
    if 49 <= keyval and keyval <= 57:
        return {"action": "choose", "position": keyval - 49}
    end
    if 65457 <= keyval and keyval <= 65465:
        return {"action": "choose", "position": keyval - 65457}
    end
    if 97 <= keyval and keyval <= 106:
        return {"action": "choose", "position": keyval - 97}
    end
    if 65 <= keyval and keyval <= 74:
        return {"action": "choose", "position": keyval - 65}
    end
    return None
end

function enter_action(spec, state, selected_count):
    # Enter: zodpovezena otazka -> dalsi; vice spravnych s vyberem -> Zkontrolovat; jinak nic
    qi = question_at(spec, state, state["page"])
    if qi < 0:
        return ""
    end
    if answered(state, qi):
        return "next"
    end
    if spec["questions"][qi]["multiple"] and selected_count > 0:
        return "check"
    end
    return ""
end
