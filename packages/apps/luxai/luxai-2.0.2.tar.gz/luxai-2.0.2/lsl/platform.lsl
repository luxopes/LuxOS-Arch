# lsl: internal-abi
# lsl: link libglib-2.0.so.0 libgio-2.0.so.0 libc.so.6
# Audited native boundary: GLib regex/Unicode and POSIX file/process operations.
# The application entry point explicitly opts into the internal ABI.
load glib

regex_cache = {"compiled": {}, "order": []}
regex_lock = IntArray()
regex_lock.append(0)
callback_lock = IntArray()
callback_lock.append(0)

function cstr(text):
    return __lsl_address(text) + 16
end

function current_dir():
    return glib.take_c(__lsl_qbe_call0(__lsl_symbol("g_get_current_dir")))
end

function check_path(path):
    if type(path) != "String" or "\0" in path:
        Error(FileError: "embedded null byte or invalid path")
    end
end

function pointer(value):
    return __lsl_unbox_int(value)
end

function buffer(size):
    return __lsl_byte_zeros(__lsl_unbox_int(size))
end

function address(bytes):
    return __lsl_qbe_load64(__lsl_address(bytes) + 24)
end

function utf8_index(text, offset):
    return __lsl_qbe_call2(__lsl_symbol("g_utf8_pointer_to_offset"), cstr(text), cstr(text) + pointer(offset))
end

function regex(pattern, flags=0):
    key = String(flags) + ":" + pattern
    result = 0
    lock regex_lock:
        if key in regex_cache["compiled"]:
            cached = regex_cache["compiled"][key]
            result = __lsl_qbe_call1(__lsl_symbol("g_regex_ref"), pointer(cached))
        else:
            errors = __lsl_byte_zeros(8)
            compiled = __lsl_qbe_call4(__lsl_symbol("g_regex_new"), cstr(pattern), pointer(flags), 0, address(errors))
            if compiled == 0:
                failure = __lsl_qbe_load64(address(errors))
                if failure != 0:
                    call __lsl_qbe_call1(__lsl_symbol("g_error_free"), failure)
                end
                Error(RegexError: "Invalid regular expression")
            end
            if len(regex_cache["order"]) >= 128:
                oldest = regex_cache["order"].pop(0)
                call __lsl_qbe_call1(__lsl_symbol("g_regex_unref"), pointer(regex_cache["compiled"][oldest]))
                regex_cache["compiled"] = without_cache_key(regex_cache["compiled"], oldest)
            end
            regex_cache["compiled"][key] = compiled
            regex_cache["order"].append(key)
            result = __lsl_qbe_call1(__lsl_symbol("g_regex_ref"), compiled)
        end
    end
    return result
end

function without_cache_key(values, key):
    output = {}
    for name in values.keys():
        if name != key:
            output[name] = values[name]
        end
    end
    return output
end

function regex_unref(compiled):
    call __lsl_qbe_call1(__lsl_symbol("g_regex_unref"), pointer(compiled))
end

function regex_test(pattern, text, flags=0):
    compiled = regex(pattern, flags)
    result = __lsl_qbe_call7(__lsl_symbol("g_regex_match_full"), pointer(compiled), cstr(text), __lsl_text_byte_length(text), 0, 0, 0, 0)
    call regex_unref(compiled)
    return result != 0
end

function regex_findall(pattern, input_text, flags=0):
    text = String(input_text)
    compiled = regex(pattern, flags)
    info_slot = __lsl_byte_zeros(8)
    count = __lsl_qbe_call1(__lsl_symbol("g_regex_get_capture_count"), pointer(compiled))
    matched = __lsl_qbe_call7(__lsl_symbol("g_regex_match_full"), pointer(compiled), cstr(text), __lsl_text_byte_length(text), 0, 0, address(info_slot), 0)
    info = __lsl_qbe_load64(address(info_slot))
    output = []
    while matched != 0:
        groups = []
        for index in rang(count + 1):
            group_offsets = __lsl_byte_zeros(8)
            call __lsl_qbe_call4(__lsl_symbol("g_match_info_fetch_pos"), info, pointer(index), address(group_offsets), address(group_offsets) + 4)
            group_begin = __lsl_qbe_load32(address(group_offsets))
            group_end = __lsl_qbe_load32(address(group_offsets) + 4)
            if group_begin >= 2147483648:
                groups.append("")
            else:
                groups.append(text[utf8_index(text, group_begin):utf8_index(text, group_end)])
            end
        end
        offsets = __lsl_byte_zeros(8)
        call __lsl_qbe_call4(__lsl_symbol("g_match_info_fetch_pos"), info, 0, address(offsets), address(offsets) + 4)
        begin = __lsl_qbe_load32(address(offsets))
        finish = __lsl_qbe_load32(address(offsets) + 4)
        output.append({"groups": groups, "start": utf8_index(text, begin), "end": utf8_index(text, finish)})
        matched = __lsl_qbe_call2(__lsl_symbol("g_match_info_next"), info, 0)
    end
    if info != 0:
        call __lsl_qbe_call1(__lsl_symbol("g_match_info_free"), info)
    end
    call regex_unref(compiled)
    return output
end

function regex_replace(pattern, replacement, input_text, flags=0):
    text = String(input_text)
    output = []
    position = 0
    for match in regex_findall(pattern, text, flags):
        output.append(text[Int(position):Int(match["start"])])
        expanded = []
        index = 0
        while index < len(replacement):
            char = replacement[index]
            if char == "\\" and index + 1 < len(replacement):
                index += 1
                char = replacement[index]
                if char in "0123456789":
                    group_index = Int(char)
                    if group_index >= len(match["groups"]):
                        Error(RegexError: "Invalid group reference")
                    end
                    expanded.append(match["groups"][group_index])
                elif char == "n":
                    expanded.append("\n")
                elif char == "t":
                    expanded.append("\t")
                else:
                    expanded.append(char)
                end
            else:
                expanded.append(char)
            end
            index += 1
        end
        output.append("".join(expanded))
        position = match["end"]
    end
    output.append(text[Int(position):])
    return "".join(output)
end

function casefold(text):
    raw = __lsl_qbe_call2(__lsl_symbol("g_utf8_casefold"), cstr(text), -1)
    return glib.take_c(raw)
end

function regex_escape(text):
    escaped = __lsl_qbe_call2(__lsl_symbol("g_regex_escape_string"), cstr(text), __lsl_text_byte_length(text))
    return glib.take_c(escaped)
end

function byte_length(text):
    return __lsl_text_byte_length(text)
end

# Avoid the current runtime's quadratic strip implementation for large pages.
# Scan UTF-8 boundaries in bytes, then copy once; embedded NUL stays intact.
function strip(input_text, characters, left=True, right=True):
    # Linearni strip/lstrip/rstrip; vestavene String.strip() je v LSL 0.10.6 kvadraticke (LSL-ISSUES).
    text = String(input_text)
    begin = cstr(text)
    finish = begin + byte_length(text)
    while left and begin < finish:
        codepoint = __lsl_qbe_call1(__lsl_symbol("g_utf8_get_char"), pointer(begin))
        if chr(codepoint) not in characters:
            break
        end
        begin += 1
        while begin < finish and (__lsl_qbe_load8(pointer(begin)) & 192) == 128:
            begin += 1
        end
    end
    while right and finish > begin:
        previous = __lsl_qbe_call2(__lsl_symbol("g_utf8_find_prev_char"), pointer(begin), pointer(finish))
        codepoint = __lsl_qbe_call1(__lsl_symbol("g_utf8_get_char"), previous)
        if chr(codepoint) not in characters:
            break
        end
        finish = previous
    end
    result = buffer(finish - begin)
    if finish > begin:
        call __lsl_qbe_call3(__lsl_symbol("memcpy"), address(result), pointer(begin), pointer(finish - begin))
    end
    return utf8_decode(result)
end

function system_facts():
    uts = __lsl_byte_zeros(390)
    status = __lsl_qbe_call1(__lsl_symbol("uname"), address(uts))
    kernel = ""
    if status == 0:
        kernel = glib.from_c(address(uts) + 130)
    end
    disk = __lsl_byte_zeros(112)
    root = "/"
    free = 0.0
    status = __lsl_qbe_call2(__lsl_symbol("statvfs"), cstr(root), address(disk))
    if status == 0:
        bytes = __lsl_qbe_load64(address(disk) + 32) * __lsl_qbe_load64(address(disk) + 8)
        free = Float(bytes) / 1000000000.0
    end
    cores = __lsl_qbe_call1(__lsl_symbol("sysconf"), 84)
    return {"kernel": kernel, "cpuCores": max(0, cores), "diskFreeGB": Int(free * 10 + 0.5) / 10.0}
end

function write_exclusive(path, text):
    call check_path(path)
    # open vraci int: znamenkove rozsireni, jinak -1 vypada jako 4294967295 (LSL-ISSUES)
    handle = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("open"), cstr(path), 524481, 384))
    if handle < 0:
        Error(FileError: "Cannot create private file")
    end
    length = __lsl_text_byte_length(text)
    offset = 0
    while offset < length:
        count = __lsl_qbe_call3(__lsl_symbol("write"), handle, cstr(text) + pointer(offset), pointer(length) - pointer(offset))
        if count <= 0:
            call __lsl_qbe_call1(__lsl_symbol("close"), handle)
            Error(FileError: "Cannot write private file")
        end
        offset += count
    end
    call __lsl_qbe_call1(__lsl_symbol("close"), handle)
end

function unicode_normalize(text, mode=3):
    raw = __lsl_qbe_call3(__lsl_symbol("g_utf8_normalize"), cstr(text), -1, pointer(mode))
    return glib.take_c(raw)
end

function valid_utf8(bytes, allow_partial=False):
    ending = __lsl_byte_zeros(8)
    valid = __lsl_qbe_call3(__lsl_symbol("g_utf8_validate"), address(bytes), len(bytes), address(ending))
    if valid != 0:
        return True
    end
    offset = __lsl_qbe_load64(address(ending)) - address(bytes)
    return allow_partial and offset >= len(bytes) - 4
end

function utf8_repair(bytes):
    output = __lsl_qbe_call2(__lsl_symbol("g_utf8_make_valid"), address(bytes), len(bytes))
    return glib.take_c(output)
end

function utf8_decode(bytes):
    # Python-compatible errors=replace, including embedded NUL and incomplete
    # multibyte prefixes. The common valid-text case stays in native GLib.
    if valid_utf8(bytes):
        return utf8_repair(bytes)
    end
    output = []
    i = 0
    while i < len(bytes):
        first = bytes[i]
        if first < 128:
            output.append(chr(first))
            i += 1
            continue
        end
        count = 0
        code = 0
        if first >= 194 and first <= 223:
            count = 2
            code = first & 31
        elif first >= 224 and first <= 239:
            count = 3
            code = first & 15
        elif first >= 240 and first <= 244:
            count = 4
            code = first & 7
        end
        if count == 0:
            output.append("�")
            i += 1
            continue
        end
        consumed = 1
        while consumed < count and i + consumed < len(bytes):
            byte = bytes[i + consumed]
            if byte < 128 or byte > 191:
                break
            end
            if consumed == 1 and ((first == 224 and byte < 160) or (first == 237 and byte > 159) or (first == 240 and byte < 144) or (first == 244 and byte > 143)):
                break
            end
            code = code * 64 + (byte & 63)
            consumed += 1
        end
        if consumed == count:
            output.append(chr(code))
        else:
            output.append("�")
        end
        i += consumed
    end
    return "".join(output)
end

function utf8_bytes(text):
    length = byte_length(text)
    bytes = buffer(length)
    if length > 0:
        call __lsl_qbe_call3(__lsl_symbol("memcpy"), address(bytes), cstr(text), pointer(length))
    end
    return bytes
end

function decode_charset(bytes, encoding):
    normalized_encoding = encoding.lower().replace("-", "").replace("_", "")
    if normalized_encoding in ["utf8", "utf8sig"]:
        text = String(utf8_decode(bytes))
        if normalized_encoding == "utf8sig" and text.startswith("﻿"):
            return text[1:]
        end
        return text
    end
    if "\0" in encoding:
        return utf8_decode(bytes)
    end
    aliases = {"utf16le": "UTF-16LE", "utf16be": "UTF-16BE", "utf32le": "UTF-32LE", "utf32be": "UTF-32BE", "latin1": "ISO-8859-1"}
    name = encoding.lower().replace("-", "").replace("_", "")
    native_encoding = aliases.get(name, encoding)
    converter = __lsl_qbe_call2(__lsl_symbol("g_iconv_open"), cstr("UTF-8"), cstr(native_encoding))
    if converter == -1:
        return utf8_decode(bytes)
    end
    capacity = len(bytes) * 4 + 16
    output = buffer(capacity)
    input_slot = buffer(8)
    input_left = buffer(8)
    output_slot = buffer(8)
    output_left = buffer(8)
    call __lsl_qbe_store64(address(input_slot), address(bytes))
    call __lsl_qbe_store64(address(input_left), pointer(len(bytes)))
    call __lsl_qbe_store64(address(output_slot), address(output))
    call __lsl_qbe_store64(address(output_left), pointer(capacity))
    unit = 1
    if name.startswith("utf16") or name.startswith("ucs2"):
        unit = 2
    elif name.startswith("utf32") or name.startswith("ucs4"):
        unit = 4
    end
    while __lsl_qbe_load64(address(input_left)) > 0:
        status = __lsl_qbe_call5(__lsl_symbol("g_iconv"), converter, address(input_slot), address(input_left), address(output_slot), address(output_left))
        if status != -1:
            break
        end
        problem = errno_value()
        remaining = __lsl_qbe_load64(address(input_left))
        if problem not in [22, 84] or __lsl_qbe_load64(address(output_left)) < 3:
            break
        end
        count = min(unit, remaining)
        if problem == 22:
            count = remaining
        end
        destination = __lsl_qbe_load64(address(output_slot))
        replacement = "�"
        call __lsl_qbe_call3(__lsl_symbol("memcpy"), destination, cstr(replacement), 3)
        call __lsl_qbe_store64(address(output_slot), destination + 3)
        call __lsl_qbe_store64(address(output_left), __lsl_qbe_load64(address(output_left)) - 3)
        call __lsl_qbe_store64(address(input_slot), __lsl_qbe_load64(address(input_slot)) + pointer(count))
        call __lsl_qbe_store64(address(input_left), remaining - pointer(count))
    end
    call __lsl_qbe_call1(__lsl_symbol("g_iconv_close"), converter)
    count = capacity - __lsl_qbe_load64(address(output_left))
    return utf8_decode(output[:Int(count)])
end

function base64_encode(bytes):
    encoded = __lsl_qbe_call2(__lsl_symbol("g_base64_encode"), address(bytes), len(bytes))
    return glib.take_c(encoded)
end

function base64_decode(text):
    if len(text) % 4 != 0 or not regex_test("^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$", text):
        Error(ValueError: "Invalid base64 data")
    end
    size = __lsl_byte_zeros(8)
    decoded = __lsl_qbe_call2(__lsl_symbol("g_base64_decode"), cstr(text), address(size))
    length = __lsl_qbe_load64(address(size))
    output = __lsl_byte_zeros(length)
    if length > 0:
        call __lsl_qbe_call3(__lsl_symbol("memcpy"), address(output), decoded, length)
    end
    if decoded != 0:
        call __lsl_qbe_call1(__lsl_symbol("g_free"), decoded)
    end
    return output
end

function realpath(path):
    call check_path(path)
    # Explicit output buffer also works with glibc's compatibility realpath ABI.
    bytes = __lsl_byte_zeros(4096)
    raw = __lsl_qbe_call2(__lsl_symbol("realpath"), cstr(path), address(bytes))
    if raw == 0:
        return ""
    end
    return glib.from_c(raw)
end

function readlink(path):
    call check_path(path)
    bytes = __lsl_byte_zeros(4097)
    # ssize_t -1 bez znamenkoveho rozsireni vypada jako obri kladne cislo (LSL-ISSUES)
    count = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("readlink"), cstr(path), address(bytes), 4096))
    if count < 0:
        return None
    end
    return utf8_repair(bytes[:count])
end

function file_info(path, follow=True):
    call check_path(path)
    data = __lsl_byte_zeros(144)
    status = 0
    if follow:
        status = __lsl_qbe_call2(__lsl_symbol("stat"), cstr(path), address(data))
    else:
        status = __lsl_qbe_call2(__lsl_symbol("lstat"), cstr(path), address(data))
    end
    if status != 0:
        return None
    end
    mode = __lsl_qbe_load32(address(data) + 24)
    return {"mode": mode, "size": __lsl_qbe_load64(address(data) + 48), "mtime": __lsl_qbe_load64(address(data) + 88), "mtime_ns": __lsl_qbe_load64(address(data) + 96), "directory": (mode & 61440) == 16384, "file": (mode & 61440) == 32768, "symlink": (mode & 61440) == 40960}
end

function combining_class(char):
    return __lsl_qbe_call1(__lsl_symbol("g_unichar_combining_class"), ord(char))
end

function file_size(path):
    call check_path(path)
    value = __lsl_byte_zeros(144)
    status = __lsl_qbe_call2(__lsl_symbol("stat"), cstr(path), address(value))
    if status != 0:
        Error(FileError: "Cannot stat file")
    end
    return __lsl_qbe_load64(address(value) + 48)
end

function read_prefix(path, limit):
    call check_path(path)
    # open vraci int: znamenkove rozsireni, jinak -1 vypada jako 4294967295 (LSL-ISSUES)
    handle = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("open"), cstr(path), 524288, 0))
    if handle < 0:
        Error(FileError: "Cannot open file: " + strerror(errno_value()))
    end
    bytes = __lsl_byte_zeros(pointer(limit))
    offset = 0
    while offset < limit:
        count = __lsl_qbe_call3(__lsl_symbol("read"), handle, address(bytes) + pointer(offset), pointer(limit) - pointer(offset))
        if count < 0:
            problem = errno_value()
            call __lsl_qbe_call1(__lsl_symbol("close"), handle)
            Error(FileError: "Cannot read file: " + strerror(problem))
        end
        if count == 0:
            break
        end
        offset += count
    end
    call __lsl_qbe_call1(__lsl_symbol("close"), handle)
    return bytes[:offset]
end

function append_private(path, text):
    call check_path(path)
    # open vraci int: znamenkove rozsireni, jinak -1 vypada jako 4294967295 (LSL-ISSUES)
    handle = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("open"), cstr(path), 525377, 384))
    if handle < 0:
        Error(FileError: "Cannot open private log")
    end
    offset = 0
    length = __lsl_text_byte_length(text)
    while offset < length:
        count = __lsl_qbe_call3(__lsl_symbol("write"), handle, cstr(text) + pointer(offset), pointer(length) - pointer(offset))
        if count <= 0:
            call __lsl_qbe_call1(__lsl_symbol("close"), handle)
            Error(FileError: "Cannot write private log")
        end
        offset += count
    end
    call __lsl_qbe_call1(__lsl_symbol("close"), handle)
end

function chmod(path, mode):
    call check_path(path)
    return __lsl_qbe_call2(__lsl_symbol("chmod"), cstr(path), pointer(mode))
end

function rename(source, destination):
    call check_path(source)
    call check_path(destination)
    return __lsl_qbe_call2(__lsl_symbol("rename"), cstr(source), cstr(destination))
end

function getpid():
    return __lsl_qbe_call0(__lsl_symbol("getpid"))
end

function getuid():
    return __lsl_qbe_call0(__lsl_symbol("getuid"))
end

function geteuid():
    return __lsl_qbe_call0(__lsl_symbol("geteuid"))
end

function user_info(uid):
    # Used only in the single-threaded helper before starting a command.
    record = __lsl_qbe_call1(__lsl_symbol("getpwuid"), pointer(uid))
    if record == 0:
        return None
    end
    return {"name": glib.from_c(__lsl_qbe_load64(record)), "uid": __lsl_qbe_load32(record + 16), "home": glib.from_c(__lsl_qbe_load64(record + 32))}
end

function stderr(text):
    offset = 0
    length = byte_length(text)
    while offset < length:
        count = __lsl_qbe_call3(__lsl_symbol("write"), 2, cstr(text) + pointer(offset), pointer(length - offset))
        if count <= 0:
            break
        end
        offset += count
    end
end

function digit_value(char):
    # hodnota desitkove cislice (i jine nez ASCII, jako Python int()/isdigit pro \d), jinak -1
    return __lsl_qbe_s32(__lsl_qbe_call1(__lsl_symbol("g_unichar_digit_value"), pointer(ord(char))))
end

function strerror(code):
    # text chyby OS jako Python OSError.strerror (lokalizovany podle LC_MESSAGES)
    return glib.from_c(__lsl_qbe_call1(__lsl_symbol("g_strerror"), pointer(code)))
end

function errno_value():
    slot = __lsl_qbe_call0(__lsl_symbol("__errno_location"))
    return __lsl_qbe_load32(slot)
end

function unlink(path):
    call check_path(path)
    result = __lsl_qbe_s32(__lsl_qbe_call1(__lsl_symbol("unlink"), cstr(path)))
    if result < 0 and errno_value() != 2:
        Error(FileError: "Cannot remove file")
    end
end

function atomic_write(path, text, mode=384):
    call check_path(path)
    # Native mkstemp, fsync and atomic rename. No external executable or shell.
    slash = 0
    for index in rang(len(path)):
        if path[index] == "/":
            slash = index + 1
        end
    end
    template = path[:slash] + ".luxai-root-XXXXXXXXXXXX"
    writable = __lsl_qbe_call1(__lsl_symbol("g_strdup"), cstr(template))
    fd = __lsl_qbe_s32(__lsl_qbe_call1(__lsl_symbol("mkstemp"), writable))
    temporary = glib.from_c(writable)
    call __lsl_qbe_call1(__lsl_symbol("g_free"), writable)
    if fd < 0:
        Error(FileError: "Cannot create temporary file")
    end
    failed = False
    offset = 0
    length = byte_length(text)
    while offset < length:
        count = __lsl_qbe_call3(__lsl_symbol("write"), pointer(fd), cstr(text) + pointer(offset), pointer(length - offset))
        if count <= 0:
            failed = True
            break
        end
        offset += count
    end
    if __lsl_qbe_call1(__lsl_symbol("fsync"), pointer(fd)) != 0:
        failed = True
    end
    if __lsl_qbe_call2(__lsl_symbol("fchmod"), pointer(fd), pointer(mode)) != 0:
        failed = True
    end
    call __lsl_qbe_call1(__lsl_symbol("close"), pointer(fd))
    if not failed and rename(temporary, path) == 0:
        return
    end
    call unlink(temporary)
    Error(FileError: "Cannot write file atomically")
end

function audit_root(user, helper, workdir, command):
    call __lsl_qbe_call3(__lsl_symbol("openlog"), cstr("luxai-root"), 0, 80)
    message = "user=" + user + " helper=" + helper + " cwd=" + workdir + " command=" + command
    call __lsl_qbe_call3(__lsl_symbol("syslog"), 5, cstr("%s"), cstr(message))
    call __lsl_qbe_call0(__lsl_symbol("closelog"))
end

function mkdir_parents(path):
    call check_path(path)
    if __lsl_qbe_call2(__lsl_symbol("g_mkdir_with_parents"), cstr(path), 511) != 0:
        Error(FileError: "Cannot create folder: " + path)
    end
end

function remove_directory(path):
    call check_path(path)
    if __lsl_qbe_call1(__lsl_symbol("rmdir"), cstr(path)) != 0:
        Error(FileError: "Cannot remove folder: " + path)
    end
end

function format_time(timestamp, format):
    date = __lsl_qbe_call1(__lsl_symbol("g_date_time_new_from_unix_local"), pointer(timestamp))
    if date == 0:
        return ""
    end
    text = glib.take_c(__lsl_qbe_call2(__lsl_symbol("g_date_time_format"), date, cstr(format)))
    call __lsl_qbe_call1(__lsl_symbol("g_date_time_unref"), date)
    return text
end

function release_callback(record_address):
    # GLib retains callbacks for sources that may outlive their creating call.
    # HTTP callbacks cease to exist once curl_easy_perform returns.
    lock callback_lock:
        index = 0
        for record in glib.handlers:
            if __lsl_address(record) == pointer(record_address):
                # Equal callback records can belong to different live GTK
                # objects. Remove the exact address, never the first equal
                # list value (which would leave a dangling native callback).
                call glib.handlers.pop(index)
                break
            end
            index += 1
        end
    end
end

function kill_group(pid, signal):
    return __lsl_qbe_call2(__lsl_symbol("kill"), -pointer(pid), pointer(signal))
end
