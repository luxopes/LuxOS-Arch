# lsl: internal-abi
# lsl: link libglib-2.0.so.0 libgobject-2.0.so.0
# ```svg v odpovedich: sanitace na bezpecnou podmnozinu SVG a vykresleni pres librsvg.
#
# Sanitace je whitelist: vlastni XML tokenizer, novy dokument se sklada jen z povolenych prvku
# a atributu. Pryc je <script>, <style>, <foreignObject>, <image>, <iframe>, odkazy mimo dokument
# (href jen "#id", url() jen url(#id)), obsluhy udalosti (on*), DOCTYPE/entity (zadne rozsirovani
# entit), zpracovaci instrukce. Limity: velikost, pocet prvku, hloubka, pocet <use>.
# librsvg se nacita az pri prvnim vykresleni (dlopen), takze aplikace bez SVG blokem ji nenacita.
load common
load platform

MAX_INPUT = 262144
MAX_ELEMENTS = 3000
MAX_DEPTH = 40
MAX_USES = 200
MAX_ATTRIBUTE = 20000
ELEMENTS = ["svg", "g", "defs", "symbol", "use", "path", "rect", "circle", "ellipse", "line", "polyline", "polygon", "text", "tspan", "textPath", "title", "desc", "linearGradient", "radialGradient", "stop", "clipPath", "mask", "pattern", "marker", "switch"]
UNWRAP = ["a"]
TEXT_ELEMENTS = ["text", "tspan", "textPath", "title", "desc"]
ATTRIBUTES = ["id", "x", "y", "x1", "y1", "x2", "y2", "cx", "cy", "r", "rx", "ry", "fx", "fy", "fr", "width", "height", "d", "points", "viewBox", "preserveAspectRatio", "transform", "fill", "fill-opacity", "fill-rule", "stroke", "stroke-width", "stroke-opacity", "stroke-linecap", "stroke-linejoin", "stroke-dasharray", "stroke-dashoffset", "stroke-miterlimit", "opacity", "font-family", "font-size", "font-weight", "font-style", "font-variant", "text-anchor", "dominant-baseline", "alignment-baseline", "baseline-shift", "letter-spacing", "word-spacing", "text-decoration", "dx", "dy", "rotate", "textLength", "lengthAdjust", "offset", "stop-color", "stop-opacity", "gradientUnits", "gradientTransform", "spreadMethod", "clip-path", "clip-rule", "mask", "maskUnits", "maskContentUnits", "clipPathUnits", "patternUnits", "patternContentUnits", "patternTransform", "marker-start", "marker-mid", "marker-end", "markerWidth", "markerHeight", "markerUnits", "refX", "refY", "orient", "visibility", "display", "color", "version", "style", "href", "pathLength", "startOffset", "method", "spacing", "side", "vector-effect", "paint-order", "shape-rendering", "text-rendering", "overflow", "xml:space"]
STYLE_PROPERTIES = ["fill", "fill-opacity", "fill-rule", "stroke", "stroke-width", "stroke-opacity", "stroke-linecap", "stroke-linejoin", "stroke-dasharray", "stroke-dashoffset", "stroke-miterlimit", "opacity", "font-family", "font-size", "font-weight", "font-style", "font-variant", "text-anchor", "dominant-baseline", "alignment-baseline", "baseline-shift", "letter-spacing", "word-spacing", "text-decoration", "stop-color", "stop-opacity", "clip-path", "clip-rule", "mask", "marker-start", "marker-mid", "marker-end", "visibility", "display", "color", "vector-effect", "paint-order", "shape-rendering", "text-rendering", "overflow"]
ENTITIES = {"lt": "<", "gt": ">", "amp": "&", "quot": "\"", "apos": "'"}
rsvg = {"loaded": False, "library": 0, "new": 0, "pixbuf": 0}

function fail(message):
    Error(SvgError: message)
end

function decode_entities(text):
    # jen 5 zakladnich entit a ciselne odkazy; ostatni (&foo;) zustanou jako text "&foo;"
    if "&" not in text:
        return text
    end
    output = []
    index = 0
    count = len(text)
    while index < count:
        char = text[index]
        if char != "&":
            output.append(char)
            index += 1
            continue
        end
        end_index = text.find(";", index)
        if end_index < 0 or end_index - index > 12:
            output.append("&")
            index += 1
            continue
        end
        name = text[index + 1:end_index]
        if name in ENTITIES:
            output.append(ENTITIES[name])
        elif name.startswith("#x") or name.startswith("#X"):
            code = parse_hex(name[2:])
            if code > 0 and code < 1114112 and code != 0 and not (code >= 55296 and code <= 57343):
                output.append(chr(code))
            end
        elif name.startswith("#"):
            code = -1
            if name[1:] and platform.regex_test("^[0-9]{1,7}$", name[1:]):
                code = Int(name[1:])
            end
            if code > 0 and code < 1114112 and not (code >= 55296 and code <= 57343):
                output.append(chr(code))
            end
        else:
            output.append("&" + name + ";")
        end
        index = end_index + 1
    end
    return "".join(output)
end

function parse_hex(text):
    if not text or len(text) > 6:
        return -1
    end
    value = 0
    for char in text.lower():
        digit = "0123456789abcdef".find(char)
        if digit < 0:
            return -1
        end
        value = value * 16 + digit
    end
    return value
end

function escape(text, attribute=False):
    result = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    if attribute:
        result = result.replace("\"", "&quot;")
    end
    return result
end

function safe_value(name, value):
    # hodnota atributu nebo vlastnosti stylu; None = zahodit
    lowered = value.lower()
    if len(value) > MAX_ATTRIBUTE:
        return None
    end
    for bad in ["javascript:", "vbscript:", "data:", "expression(", "@import", "\\", "<", "behavior:"]:
        if bad in lowered:
            return None
        end
    end
    if "url(" in lowered:
        # jen odkazy uvnitr dokumentu: url(#id) nebo url('#id')
        for found in platform.regex_findall("(?i)url\\s*\\(([^)]*)\\)", value):
            target = found["groups"][1].strip().strip("'\"").strip()
            if not platform.regex_test("^#[A-Za-z_][A-Za-z0-9_.:-]*$", target):
                return None
            end
        end
        if platform.regex_test("(?i)url\\s*\\((?![^)]*\\))", value):
            return None
        end
    end
    if name == "href":
        if not platform.regex_test("^#[A-Za-z_][A-Za-z0-9_.:-]*$", value.strip()):
            return None
        end
        return value.strip()
    end
    return value
end

function clean_style(value):
    kept = []
    for part in value.split(";"):
        separator = part.find(":")
        if separator <= 0:
            continue
        end
        name = part[:separator].strip().lower()
        content = part[separator + 1:].strip()
        if name in STYLE_PROPERTIES and content:
            checked = safe_value(name, content)
            if checked != None and "{" not in checked and "}" not in checked:
                kept.append(name + ":" + checked)
            end
        end
    end
    return ";".join(kept)
end

function parse_attributes(text):
    # [[jmeno, hodnota], ...]; spatna syntaxe -> chyba
    result = []
    index = 0
    count = len(text)
    while index < count:
        while index < count and text[index] in " \t\r\n":
            index += 1
        end
        if index >= count:
            break
        end
        start = index
        while index < count and text[index] not in " \t\r\n=/>":
            index += 1
        end
        name = text[start:index]
        if not name:
            if text[index] == "/":
                index += 1
                continue
            end
            call fail("invalid attribute")
        end
        while index < count and text[index] in " \t\r\n":
            index += 1
        end
        value = ""
        if index < count and text[index] == "=":
            index += 1
            while index < count and text[index] in " \t\r\n":
                index += 1
            end
            if index < count and text[index] in "\"'":
                quote = text[index]
                close = text.find(quote, index + 1)
                if close < 0:
                    call fail("unterminated attribute value")
                end
                value = text[index + 1:close]
                index = close + 1
            else:
                start = index
                while index < count and text[index] not in " \t\r\n>":
                    index += 1
                end
                value = text[start:index]
            end
        end
        result.append([name, decode_entities(value)])
        if len(result) > 200:
            call fail("too many attributes")
        end
    end
    return result
end

function tag_end(source, index):
    # konec znacky '>' mimo uvozovky
    quote = ""
    count = len(source)
    while index < count:
        char = source[index]
        if quote:
            if char == quote:
                quote = ""
            end
        elif char == "\"" or char == "'":
            quote = char
        elif char == ">":
            return index
        end
        index += 1
    end
    return -1
end

function at(source, index, prefix):
    return source[index:index + len(prefix)] == prefix
end

function local_name(name):
    if name.startswith("svg:"):
        return name[4:]
    end
    return name
end

function number_attribute(value):
    found = platform.regex_findall("^\\s*([0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?)\\s*(px)?\\s*$", String(value))
    if found:
        try:
            return Float(found[0]["groups"][1])
        else:
            return None
        end
    end
    return None
end

function sanitize(source):
    # {"svg": text, "width": Float, "height": Float, "removed": [duvody]} nebo Error(SvgError)
    source = String(source)
    if len(source) > MAX_INPUT:
        call fail("SVG is too large (max 256 KB)")
    end
    output = []
    stack = []
    skip_depth = 0
    elements = 0
    uses = 0
    removed = []
    root = None
    root_closed = False
    index = 0
    count = len(source)
    while index < count:
        char = source[index]
        if char != "<":
            next_index = source.find("<", index)
            if next_index < 0:
                next_index = count
            end
            content = source[index:next_index]
            if skip_depth == 0 and stack and stack[len(stack) - 1] in TEXT_ELEMENTS:
                output.append(escape(decode_entities(content)))
            elif skip_depth == 0 and stack and content.strip() == "":
                output.append(content)
            end
            index = next_index
            continue
        end
        if at(source, index, "<!--"):
            close = source.find("-->", index + 4)
            if close < 0:
                call fail("unterminated comment")
            end
            index = close + 3
            continue
        end
        if at(source, index, "<![CDATA["):
            close = source.find("]]>", index + 9)
            if close < 0:
                call fail("unterminated CDATA")
            end
            if skip_depth == 0 and stack and stack[len(stack) - 1] in TEXT_ELEMENTS:
                output.append(escape(source[index + 9:close]))
            end
            index = close + 3
            continue
        end
        if at(source, index, "<?"):
            close = source.find("?>", index + 2)
            if close < 0:
                call fail("unterminated processing instruction")
            end
            index = close + 2
            continue
        end
        if at(source, index, "<!"):
            # DOCTYPE vcetne vnitrni podmnoziny [ ... ] (definice entit se zahodi)
            if "doctype" not in removed:
                removed.append("doctype")
            end
            bracket = source.find("[", index)
            close = source.find(">", index)
            if bracket >= 0 and (close < 0 or bracket < close):
                end_subset = source.find("]", bracket)
                if end_subset < 0:
                    call fail("unterminated DOCTYPE")
                end
                close = source.find(">", end_subset)
            end
            if close < 0:
                call fail("unterminated DOCTYPE")
            end
            index = close + 1
            continue
        end
        close = tag_end(source, index + 1)
        if close < 0:
            call fail("unterminated tag")
        end
        body = source[index + 1:close]
        index = close + 1
        if body.startswith("/"):
            name = local_name(body[1:].strip())
            if skip_depth > 0:
                skip_depth -= 1
                continue
            end
            if not stack:
                call fail("unexpected closing tag")
            end
            opened = stack.pop()
            if opened != name and not (opened == "#unwrap" and name in UNWRAP):
                call fail("mismatched closing tag " + name)
            end
            if opened != "#unwrap":
                output.append("</" + opened + ">")
            end
            if not stack and root != None:
                root_closed = True
            end
            continue
        end
        self_closing = body.endswith("/")
        if self_closing:
            body = body[:len(body) - 1]
        end
        split = 0
        while split < len(body) and body[split] not in " \t\r\n":
            split += 1
        end
        name = local_name(body[:split])
        if not platform.regex_test("^[A-Za-z_][A-Za-z0-9_.:-]*$", name):
            call fail("invalid tag")
        end
        attributes = parse_attributes(body[split:])
        if skip_depth > 0:
            if not self_closing:
                skip_depth += 1
            end
            continue
        end
        if root_closed:
            call fail("content after the root element")
        end
        if root == None and name != "svg":
            call fail("the root element must be <svg>")
        end
        elements += 1
        if elements > MAX_ELEMENTS:
            call fail("SVG has too many elements (max " + String(MAX_ELEMENTS) + ")")
        end
        if len(stack) >= MAX_DEPTH:
            call fail("SVG is nested too deeply")
        end
        if name in UNWRAP:
            if not self_closing:
                stack.append("#unwrap")
            end
            if "link" not in removed:
                removed.append("link")
            end
            continue
        end
        if name not in ELEMENTS:
            if name not in removed:
                removed.append(name)
            end
            if not self_closing:
                skip_depth = 1
            end
            continue
        end
        if name == "use":
            uses += 1
            if uses > MAX_USES:
                call fail("SVG has too many <use> elements")
            end
        end
        kept = []
        has_namespace = False
        for pair in attributes:
            attribute = pair[0]
            value = pair[1]
            if attribute == "xlink:href":
                attribute = "href"
            end
            if attribute == "xmlns":
                has_namespace = True
                continue
            end
            if attribute not in ATTRIBUTES:
                lowered = attribute.lower()
                if lowered.startswith("on") and "event" not in removed:
                    removed.append("event")
                end
                continue
            end
            if attribute == "style":
                value = clean_style(value)
                if not value:
                    continue
                end
            else:
                value = safe_value(attribute, value)
                if value == None:
                    if "reference" not in removed:
                        removed.append("reference")
                    end
                    continue
                end
            end
            kept.append([attribute, value])
        end
        if root == None:
            root = {}
            for pair in kept:
                root[pair[0]] = pair[1]
            end
        end
        text = "<" + name
        is_root = len(stack) == 0
        if is_root:
            # sirku a vysku doplni render() podle mista v okne; bez viewBox se doplni z puvodni velikosti
            text += " xmlns=\"http://www.w3.org/2000/svg\""
            if not root.get("viewBox"):
                size = intrinsic_size(root)
                text += " viewBox=\"0 0 " + trim_number(size[0]) + " " + trim_number(size[1]) + "\""
            end
        end
        for pair in kept:
            if is_root and pair[0] in ["width", "height"]:
                continue
            end
            text += " " + pair[0] + "=\"" + escape(pair[1], True) + "\""
        end
        if self_closing:
            output.append(text + "/>")
            if not stack:
                root_closed = True
            end
        else:
            output.append(text + ">")
            stack.append(name)
        end
    end
    if root == None:
        call fail("no <svg> element")
    end
    if stack or skip_depth > 0:
        call fail("SVG is not complete")
    end
    size = intrinsic_size(root)
    explicit = number_attribute(root.get("width", "")) != None or number_attribute(root.get("height", "")) != None
    return {"svg": "".join(output), "width": size[0], "height": size[1], "explicit": explicit, "removed": removed}
end

function intrinsic_size(root):
    width = number_attribute(root.get("width", ""))
    height = number_attribute(root.get("height", ""))
    box = None
    if root.get("viewBox"):
        parts = platform.regex_findall("[-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?", root["viewBox"])
        if len(parts) == 4:
            try:
                box = [Float(parts[2]["groups"][0]), Float(parts[3]["groups"][0])]
            else:
                box = None
            end
            if box != None and (box[0] <= 0 or box[1] <= 0):
                box = None
            end
        end
    end
    if width == None and height == None:
        if box != None:
            return [box[0], box[1]]
        end
        return [300.0, 150.0]
    end
    if width == None:
        if box != None:
            width = height * box[0] / box[1]
        else:
            width = height
        end
    end
    if height == None:
        if box != None:
            height = width * box[1] / box[0]
        else:
            height = width
        end
    end
    return [max(1.0, width), max(1.0, height)]
end

function trim_number(value):
    text = String(value)
    if text.endswith(".0"):
        return text[:len(text) - 2]
    end
    return text
end

function sized(svg, width, height):
    # korenovy prvek dostane velikost v pixelech (librsvg pak kresli presne do teto velikosti)
    return "<svg width=\"" + String(Int(width)) + "\" height=\"" + String(Int(height)) + "\"" + svg[4:]
end

function display_size(info, limit_width=640.0, limit_height=560.0):
    # velikost v bodech na obrazovce: zachovat pomer stran, vejit se do bubliny
    width = info["width"]
    height = info["height"]
    scale = min(1.0, limit_width / width, limit_height / height)
    if not info.get("explicit"):
        # jen viewBox: vyplnit sirku bubliny (max. 480 px) jako na webu
        scale = min(min(limit_width, 480.0) / width, limit_height / height)
    elif width < 48 and height < 48:
        scale = min(limit_width / width, limit_height / height, 4.0)
    end
    return [max(1, Int(width * scale + 0.5)), max(1, Int(height * scale + 0.5))]
end

# ---------------------------------------------------------------- librsvg (lazy)

function load_library():
    if rsvg["loaded"]:
        return rsvg["library"] != 0
    end
    rsvg["loaded"] = True
    library = __lsl_qbe_call2(__lsl_symbol("dlopen"), platform.cstr("librsvg-2.so.2"), 1)
    if library == 0:
        return False
    end
    rsvg["new"] = __lsl_qbe_call2(__lsl_symbol("dlsym"), platform.pointer(library), platform.cstr("rsvg_handle_new_from_data"))
    rsvg["pixbuf"] = __lsl_qbe_call2(__lsl_symbol("dlsym"), platform.pointer(library), platform.cstr("rsvg_handle_get_pixbuf"))
    if rsvg["new"] == 0 or rsvg["pixbuf"] == 0:
        return False
    end
    rsvg["library"] = library
    return True
end

function pixbuf(svg, width, height):
    # GdkPixbuf presne width x height (librsvg rsvg_handle_get_pixbuf), nebo 0; volajici uvolni
    # g_object_unref. (rsvg_handle_render_document s kontextem cairo z LSL v tomto prostredi pada,
    # proto se kresli pres pixbuf.)
    if not load_library() or width < 1 or height < 1 or width > 8192 or height > 8192:
        return 0
    end
    text = sized(svg, width, height)
    errors = platform.buffer(8)
    error_address = platform.address(errors)
    handle = __lsl_qbe_call3(platform.pointer(rsvg["new"]), platform.cstr(text), platform.pointer(platform.byte_length(text)), platform.pointer(error_address))
    problem = __lsl_qbe_load64(platform.pointer(error_address))
    if problem != 0:
        call __lsl_qbe_call1(__lsl_symbol("g_error_free"), platform.pointer(problem))
    end
    if handle == 0:
        return 0
    end
    image = __lsl_qbe_call1(platform.pointer(rsvg["pixbuf"]), platform.pointer(handle))
    call __lsl_qbe_call1(__lsl_symbol("g_object_unref"), platform.pointer(handle))
    return image
end
