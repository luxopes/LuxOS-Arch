# Agent orchestration, independent of GTK and concrete tool/policy implementations.
# A policy judge is mandatory before ANY tool executes. No permissive fallback.
load api
load common
load catalog
load protocol
load prompts
load rootmode
load tool_format
load text_calls
load json
load settings
load safety_data
load time

function new_run(conversation, client, ui=None, tools=None, permissions=None, preferences=None, vision=False, screen=""):
    signal = IntArray()
    signal.append(0)
    return {"conversation": conversation, "client": client, "ui": common.fallback(ui, {}), "tools": tools, "permissions": permissions, "preferences": common.fallback(preferences, {}), "vision": vision, "screen": screen, "cancel_signal": signal, "events": [], "max_steps": 40}
end

function is_cancelled(state):
    signal = IntArray(state["cancel_signal"])
    return atomic_add(signal, 0, 0) != 0
end

function cancel(state):
    signal = IntArray(state["cancel_signal"])
    call atomic_xchg(signal, 0, 1)
    if state["client"] != None:
        call api.abort(state["client"])
    end
    if state["tools"] != None and state["tools"].get("cancel") != None:
        call state["tools"]["cancel"](state["tools"])
    end
end

function emit(state, name, arguments=None):
    arguments = common.fallback(arguments, [])
    state["events"].append([name] + arguments)
    if state["ui"].get("emit") != None:
        call state["ui"]["emit"](state["ui"], name, arguments)
    end
end

function stream_delta(state, text, reasoning):
    if state.get("text_filter") != None and text:
        # volani nastroje vypsane jako text (<tool_call>...) se pri streamovani neukazuje
        text = text_calls.filter_text(state["text_filter"], text)
        if not text and not reasoning:
            return
        end
    end
    call emit(state, "stream_delta", [text, reasoning])
end

function policy(state):
    if state["permissions"] != None:
        return common.fallback(state["permissions"].get("policy"), {})
    end
    return {}
end

function definitions(state):
    if state["tools"] == None:
        return None
    end
    offered = state["tools"].get("definitions", [])
    output = []
    rules = policy(state)
    hidden = state["tools"].get("hidden", [])
    for definition in offered:
        name = definition["function"]["name"]
        category = catalog.TOOL_CATEGORY.get(name)
        if name in hidden or (category != None and rules.get(category) == "never"):
            continue
        end
        output.append(definition)
    end
    return common.fallback(output, None)
end

function declared_names(defs):
    names = []
    for definition in common.fallback(defs, []):
        names.append(definition["function"]["name"])
    end
    return names
end

function web_tainted(messages):
    # stejne jako safety.web_tainted a Python agent.web_tainted (jen odpovedi na web_search/web_fetch asistenta)
    web_ids = []
    for message in common.fallback(messages, []):
        if type(message) != "Dictionary":
            continue
        end
        if message.get("role") == "assistant":
            for tool_call in common.fallback(message.get("tool_calls"), []):
                if type(tool_call) == "Dictionary" and type(tool_call.get("function")) == "Dictionary" and tool_call["function"].get("name") in safety_data.WEB_TOOLS:
                    web_ids.append(tool_call.get("id"))
                end
            end
        elif message.get("role") == "tool" and message.get("tool_call_id") in web_ids:
            return True
        end
    end
    return False
end

function body(state):
    conversation = state["conversation"]
    mode = conversation["mode"]
    defs = definitions(state)
    names = declared_names(defs)
    declared = common.fallback(names, None)
    workdir = ""
    if mode == "agent" and state["tools"] != None:
        workdir = state["tools"].get("workdir", "")
    end
    system = prompts.system_prompt(mode, workdir, state["vision"], state["screen"], state["preferences"], policy(state), conversation["model"], "docs_search" in names, "web_search" in names or "web_fetch" in names, mode == "agent" and web_tainted(conversation["messages"]), "map_geocode" in names, "calendar_list_events" in names, Bool(state["preferences"].get("rich_blocks")), "weather_forecast" in names)
    if type(state.get("system_note")) == "String" and state["system_note"]:
        system = system + "\n\n" + state["system_note"]
    end
    messages = [{"role": "system", "content": system}] + protocol.api_messages(conversation["messages"], mode, state["vision"], declared)
    messages = protocol.trim_history(messages)
    if mode == "agent" or declared:
        messages = protocol.repair_tool_sequence(messages, declared)[0]
    end
    max_tokens = common.fallback(state["preferences"].get("max_tokens"), 4096)
    if mode == "agent":
        # misto na volani nastroju s celym souborem (useknute volani se nespusti), jako Python AGENT_MAX_TOKENS
        max_tokens = max(8192, max_tokens)
    end
    request = {"model": conversation["model"], "messages": messages, "max_tokens": Int(max_tokens)}
    temperature = state["preferences"].get("temperature")
    if type(temperature) in ["Int", "Float"]:
        request["temperature"] = Int(min(1.5, max(0.0, Float(temperature))) * 100 + 0.5) / 100.0
    end
    if defs:
        request["tools"] = defs
        request["tool_choice"] = "auto"
    end
    return protocol.shrink_body(request)
end

function request(state):
    # pri HTTP 413 (prilis velke telo) jednou znovu bez obrazku a s kratsi historii (jako Python)
    smaller = False
    for attempt in rang(5):
        try:
            payload = body(state)
            if smaller:
                payload = protocol.shrink_body(payload, protocol.MAX_BODY_BYTES // 2, True)
            end
            state["text_filter"] = None
            if payload.get("tools"):
                state["text_filter"] = text_calls.new_filter()
            end
            if state.get("request") != None:
                return state["request"](state, payload)
            end
            return api.chat_stream(state["client"], payload, stream_delta, is_cancelled, 300, state)
        else:
            problem = api.caught_error(String(last_error()))
            if problem["code"] == "too_large" and not smaller and not is_cancelled(state):
                smaller = True
                continue
            end
            if problem["code"] != "chat_busy" or attempt >= 4 or is_cancelled(state):
                call api.raise_error(problem)
            end
            for tick in rang(40):
                if is_cancelled(state):
                    call api.raise_error(api.error("cancelled"))
                end
                call time.sleep(0.05)
            end
        end
    end
    call api.raise_error(api.error("chat_busy", 429))
end

function drop_transient(state):
    output = []
    for message in state["conversation"]["messages"]:
        if not message.get("_transient"):
            output.append(message)
        end
    end
    state["conversation"]["messages"] = output
end

function unique_call_ids(state, message):
    known = []
    for previous in state["conversation"]["messages"]:
        if previous.get("role") == "tool":
            known.append(previous.get("tool_call_id"))
        end
        for tool_call in common.fallback(previous.get("tool_calls"), []):
            known.append(tool_call.get("id"))
        end
    end
    for tool_call in common.fallback(message.get("tool_calls"), []):
        id = tool_call.get("id")
        if type(id) != "String" or not id or len(id) > 200 or id in known:
            tool_call["id"] = "call_" + common.random_hex()
        end
        known.append(tool_call["id"])
    end
end

function tool_message(state, id, result):
    message = {"role": "tool", "tool_call_id": id, "content": tool_format.encode_result(result)}
    if type(result.get("_links")) == "List":
        message["_links"] = result["_links"]
    end
    if type(result.get("_map")) == "Dictionary":
        # nahled trasy pro kartu (uklada se u zpravy, modelu se neposila)
        message["_map"] = result["_map"]
    end
    state["conversation"]["messages"].append(message)
end

function tool_end(state, id, name, result, status):
    call tool_message(state, id, result)
    call emit(state, "tool_result", [id, name, result, status])
end

function run_call(state, tool_call):
    id = tool_call.get("id", "")
    fn = common.fallback(tool_call.get("function"), {})
    name = fn.get("name", "")
    arguments = None
    try:
        arguments = common.read_json_text(common.fallback(fn.get("arguments"), "{}"))
    else:
        arguments = None
    end
    if name == "run_command" and type(arguments) == "Dictionary":
        arguments = rootmode.normalize_run_command(arguments)
    end
    display_args = {}
    if type(arguments) == "Dictionary":
        display_args = arguments
    end
    call emit(state, "tool_start", [id, name, display_args])
    if is_cancelled(state):
        call tool_end(state, id, name, {"ok": False, "cancelled": True, "error": "Stopped by the user before running"}, "cancelled")
        return None
    end
    if type(arguments) != "Dictionary":
        call tool_end(state, id, name, {"ok": False, "error": "Tool arguments are not a valid JSON object"}, "error")
        return None
    end
    declared = name in declared_names(definitions(state))
    if not declared and state["conversation"]["mode"] != "agent":
        message = "Tool " + name + " is not available in Chat mode. Only docs_search, docs_read, web_search and web_fetch are; suggest Agent mode for work on the computer."
        call tool_end(state, id, name, {"ok": False, "error": message}, "error")
        return None
    end
    permissions = state["permissions"]
    if permissions == None or permissions.get("judge") == None:
        call tool_end(state, id, name, {"ok": False, "blocked": True, "error": "No permission policy is connected; this tool was not executed."}, "blocked")
        return None
    end
    assessment = permissions["judge"](permissions, name, arguments, state)
    action = assessment["action"]
    reasons = assessment.get("reasons", [])
    if action == "block" or action not in ["allow", "ask", "confirm", "danger"]:
        call tool_end(state, id, name, {"ok": False, "blocked": True, "error": "Refused by LuxAI safety rules: " + "; ".join(reasons) + ". Do not try to bypass this."}, "blocked")
        return None
    end
    if not declared:
        # Agent: nastroj vypnuty v nastaveni odmitne uz posuzovac (jako Python); jiny nenabidnuty se nespusti
        call tool_end(state, id, name, {"ok": False, "error": "Tool " + name + " is not available in this request."}, "error")
        return None
    end
    if name in safety_data.ALWAYS_CONFIRM_TOOLS and action not in ["confirm", "danger"]:
        action = "confirm"
    end
    prepared = None
    tools = state["tools"]
    if tools.get("prepare") != None:
        prepared = tools["prepare"](tools, name, arguments, policy(state).get("screen") != "never")
        if is_cancelled(state):
            call tool_end(state, id, name, {"ok": False, "cancelled": True, "error": "Stopped by the user before running"}, "cancelled")
            return None
        end
        if prepared != None and not prepared.get("ok"):
            call tool_end(state, id, name, {"ok": False, "error": common.fallback(prepared.get("error"), "Invalid arguments")}, "error")
            return None
        end
        if prepared != None:
            call emit(state, "tool_prepared", [id, name, prepared["preview"]])
        end
    end
    if action in ["ask", "confirm", "danger"]:
        answer = "deny"
        if state["ui"].get("confirm") != None:
            answer = state["ui"]["confirm"](state["ui"], id, name, arguments, action, reasons)
        end
        if is_cancelled(state):
            answer = "deny"
        end
        if action != "ask" and answer == "always":
            answer = "once"
        end
        accepted = answer in ["once", "always"]
        if permissions.get("remember") != None:
            accepted = permissions["remember"](permissions, name, answer)
        end
        if not accepted:
            status = "denied"
            if is_cancelled(state):
                status = "cancelled"
            end
            denial = "The user denied this action. Do not try to achieve it through another tool."
            if status == "denied" and type(state["ui"].get("deny_error")) == "String":
                # headless remote session: no confirmation was possible, the reason is explained
                denial = state["ui"]["deny_error"]
            end
            call tool_end(state, id, name, {"ok": False, "permission_denied": True, "error": denial}, status)
            return None
        end
    end
    call emit(state, "tool_running", [id, name])
    tools["root_mode"] = rootmode.effective_mode(policy(state), state["conversation"]["model"])
    tools["model"] = state["conversation"]["model"]
    result = tools["execute"](tools, name, arguments, prepared)
    image = result.get("_image")
    status = "error"
    if result.get("cancelled"):
        status = "cancelled"
    elif result.get("ok"):
        status = "ok"
    end
    call tool_end(state, id, name, result, status)
    return image
end

function textual_calls(state, message, finish):
    # Volani vypsana modelem jako text (GLM/Hermes/Qwen) -> bezne tool_calls (stejna cesta jako nativni:
    # posuzovac, potvrzeni). Vraci "calls" (prevedeno), "cut" (useknute, nic se nespusti) nebo "".
    content = message.get("content")
    if message.get("tool_calls") or type(content) != "String" or text_calls.OPEN not in content:
        return ""
    end
    defs = definitions(state)
    if not defs:
        return ""
    end
    textual = text_calls.extract(content, defs, finish != "length")
    if textual["incomplete"]:
        return "cut"
    end
    if not textual["calls"] or textual["invalid"]:
        return ""
    end
    calls = []
    for item in textual["calls"]:
        calls.append({"id": "call_" + common.random_hex(), "type": "function", "function": {"name": item["name"], "arguments": json.encode(item["arguments"])}})
    end
    message["tool_calls"] = calls
    message["content"] = common.fallback(textual["text"], None)
    call unique_call_ids(state, message)
    return "calls"
end

function run_loop(state):
    nudged = False
    format_retries = 0
    cut_retries = 0
    for step in rang(state["max_steps"]):
        if is_cancelled(state):
            return "cancelled"
        end
        call emit(state, "stream_start")
        response = request(state)
        message = response[0]
        finish = response[1]
        if response[2]:
            call emit(state, "usage", [response[2]])
        end
        call drop_transient(state)
        if is_cancelled(state) or finish == "cancelled":
            if message.get("content"):
                state["conversation"]["messages"].append({"role": "assistant", "content": message["content"]})
            end
            call emit(state, "stream_end", [{"role": "assistant", "content": message.get("content")}])
            return "cancelled"
        end
        if state["conversation"]["mode"] != "agent" and state["tools"] == None:
            message = common.without(message, "tool_calls")
        end
        if message.get("tool_calls"):
            call unique_call_ids(state, message)
        elif "tool_calls" in message:
            message = common.without(message, "tool_calls")
        end
        if not message.get("content") and not message.get("tool_calls"):
            call emit(state, "stream_end", [message])
            if finish == "length":
                return "length"
            end
            return "done"
        end
        if textual_calls(state, message, finish) == "cut":
            # Volani useknute limitem delky odpovedi (napr. velky soubor): nespustit, model ho rozdeli
            call emit(state, "stream_end", [{"role": "assistant", "content": None}])
            if cut_retries >= 1:
                call api.raise_error(api.error("model", 200, "The model's tool call was cut off at the answer length limit twice. Nothing was executed from it. Please ask for smaller steps."))
            end
            cut_retries += 1
            transient = common.copy(message)
            transient["_transient"] = True
            state["conversation"]["messages"].append(transient)
            nudge = text_calls.CUT_NUDGE.replace("{0}", common.fallback(text_calls.incomplete_name(message["content"]), "tool"))
            state["conversation"]["messages"].append({"role": "user", "content": nudge, "_transient": True})
            continue
        end
        if state["conversation"]["mode"] == "agent" and not message.get("tool_calls") and finish != "length" and prompts.printed_tool_call(message.get("content"), definitions(state)):
            call emit(state, "stream_end", [{"role": "assistant", "content": None}])
            if format_retries >= 1:
                call api.raise_error(api.error("model", 200, "The model returned tool-call JSON as text twice. No action was executed from that text. Please retry the request."))
            end
            format_retries += 1
            transient = common.copy(message)
            transient["_transient"] = True
            state["conversation"]["messages"].append(transient)
            state["conversation"]["messages"].append({"role": "user", "content": catalog.TOOL_FORMAT_NUDGE, "_transient": True})
            continue
        end
        state["conversation"]["messages"].append(message)
        call emit(state, "stream_end", [message])
        calls = common.fallback(message.get("tool_calls"), [])
        if not calls:
            if finish == "length":
                return "length"
            end
            if state["conversation"]["mode"] == "agent" and state["tools"] != None and not nudged and prompts.announces_action(message.get("content")):
                nudged = True
                state["conversation"]["messages"].append({"role": "user", "content": catalog.NUDGE_TEXT, "_transient": True})
                continue
            end
            return "done"
        end
        images = []
        for tool_call in calls:
            image = run_call(state, tool_call)
            if image:
                images.append(image)
            end
        end
        if images:
            content = [{"type": "text", "text": catalog.SCREENSHOT_TEXT}]
            for image in images:
                content.append({"type": "image_url", "image_url": {"url": image}})
            end
            state["conversation"]["messages"].append({"role": "user", "content": content, "_screenshot": True})
        end
        if is_cancelled(state):
            return "cancelled"
        end
    end
    return "limit"
end

function run(state):
    reason = "done"
    try:
        reason = run_loop(state)
    else:
        if is_cancelled(state):
            reason = "cancelled"
        else:
            call emit(state, "error", [api.caught_error(String(last_error()))])
            reason = "error"
        end
    end
    call drop_transient(state)
    repaired = protocol.repair_tool_sequence(state["conversation"]["messages"], None, {"ok": False, "cancelled": True, "error": "Stopped by the user before running"})
    if repaired[1]:
        # jako Python: historie se prepise jen kdyz oprava neco zmenila
        state["conversation"]["messages"] = repaired[0]
    end
    call emit(state, "finished", [reason])
    return reason
end
