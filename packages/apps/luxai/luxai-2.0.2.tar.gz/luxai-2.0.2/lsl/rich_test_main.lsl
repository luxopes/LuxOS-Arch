# lsl: internal-abi
# Testovaci vstup bohatych bloku (rich_*), nikdy vstup aplikace. Cte JSON seznam pozadavku
# {"op": ..., ...} ze souboru (argv[1]) a vypise JSON seznam {"ok", "value"} / {"ok": False, "error"}.
load json
load common
load rich_expr
load rich_blocks
load rich_svg
load rich_draw
load rich_diagram
load rich_math
load cairo
load rich_ui
load rich_quiz
load web
load prompts
load markdown
load mathtex
load gtk
load glib

function run_request(request):
    op = request["op"]
    if op == "expr":
        return rich_expr.compute(request["text"], request.get("values", {}))
    elif op == "expr_parse":
        return rich_expr.parse(request["text"])
    elif op == "format":
        return rich_expr.format_value(request["value"], request.get("pattern", ""), request.get("unit", ""))
    elif op == "kind":
        return rich_blocks.kind_of(request["lang"])
    elif op == "parse":
        return rich_blocks.parse(request["kind"], request["text"])
    elif op == "sanitize":
        return rich_svg.sanitize(request["text"], request.get("theme"))
    elif op == "render":
        return render(request)
    elif op == "diagram":
        return rich_diagram.parse(request["text"])
    elif op == "image_kind":
        return rich_ui.image_kind(common.base64_decode(request["data"]))
    elif op == "download":
        fetcher = web.new_fetcher(None, None, 30)
        fetcher["fake"] = request
        fetcher["resolver"] = fake_resolve
        fetcher["sender"] = fake_send
        path = rich_ui.download_image(request["url"], fetcher)
        return {"path": path, "requests": fetcher.get("sent", 0)}
    elif op == "csv":
        return rich_ui.table_csv(rich_blocks.parse("table", request["text"])["spec"])
    elif op == "sort_rows":
        return rich_ui.sorted_table_rows(request["rows"], request["column"], request.get("descending", False))
    elif op == "polyline":
        return rich_ui.encode_polyline(request["points"], request.get("precision", 6))
    elif op == "math_size":
        box = rich_math.measure(request["text"], 17.0, True)
        return [box["w"], box["a"], box["d"]]
    elif op == "diagram_layout":
        diagram = rich_diagram.parse(request["text"])
        layout = rich_diagram.measure(diagram, 600.0)
        return {"kind": diagram["kind"], "width": layout["width"], "height": layout["height"]}
    elif op == "hits":
        parsed = rich_blocks.parse("chart", request["text"])
        surface = rich_draw.png_surface(560, 300, 1.0)
        cr = cairo.create(surface)
        hits = rich_draw.draw_chart(cr, parsed["spec"], 560, 300, rich_draw.theme(False), None)
        call cairo.destroy(cr)
        call cairo.surface_destroy(surface)
        found = []
        for hit in hits:
            found.append([hit[4], hit[5], hit[6], rich_draw.hit_test(hits, (hit[0] + hit[2]) / 2.0, (hit[1] + hit[3]) / 2.0), (hit[0] + hit[2]) / 2.0, (hit[1] + hit[3]) / 2.0])
        end
        return found
    elif op == "ticks":
        return rich_draw.ticks(request["low"], request["high"], request.get("count", 5))
    elif op == "atan2":
        return rich_draw.atan2(request["y"], request["x"])
    elif op == "prompt":
        return prompts.system_prompt(request.get("mode", "chat"), "/tmp", False, "", {}, {}, request.get("model", "flash"), False, False, False, False, False, request.get("rich", False))
    elif op == "inline":
        return markdown.inline(request["text"])
    elif op == "blocks":
        return markdown.parse_blocks(request["text"])
    elif op == "quiz":
        return quiz_steps(request)
    elif op == "hash":
        return rich_blocks.hash_text(request["text"])
    end
    Error(ValueError: "unknown op " + op)
end

function quiz_steps(request):
    # stavovy automat kvizu (rich_quiz) bez GTK: kroky nad jednim stavem, po kazdem kopie stavu
    parsed = rich_blocks.parse("quiz", request["text"])
    if not parsed["ok"]:
        Error(ValueError: parsed["error"])
    end
    spec = parsed["spec"]
    state = request.get("state", {})
    output = []
    for item in request.get("steps", []):
        action = item["do"]
        value = None
        if action == "normalize":
            call rich_quiz.normalize(spec, state)
        elif action == "answer":
            value = rich_quiz.answer(spec, state, item["q"], item["options"])
        elif action == "hint":
            value = rich_quiz.hint(spec, state, item["q"])
        elif action == "go":
            value = rich_quiz.go(spec, state, item["page"])
        elif action == "step":
            value = rich_quiz.step(spec, state, item["delta"])
        elif action == "reset":
            call rich_quiz.reset(spec, state, item.get("shuffle", False), request["text"])
        elif action == "key":
            value = rich_quiz.key_action(item["key"], item.get("modifiers", 0))
        elif action == "enter":
            value = rich_quiz.enter_action(spec, state, item.get("selected", 0))
        elif action == "mode":
            value = rich_quiz.mode(spec, state)
        elif action == "set_mode":
            state["mode"] = item["mode"]
            value = rich_quiz.mode(spec, state)
        elif action == "score":
            value = rich_quiz.score(spec, state)
        elif action == "status":
            value = []
            for qi in rang(rich_quiz.count(spec)):
                value.append(rich_quiz.status(spec, state, qi))
            end
        elif action == "order":
            value = rich_quiz.order(spec, state)
        elif action == "question_at":
            value = rich_quiz.question_at(spec, state, item["page"])
        elif action == "spec_mode":
            value = spec["mode"]
        else:
            Error(ValueError: "unknown quiz step " + action)
        end
        output.append({"value": value, "state": json.decode(json.encode(state))})
    end
    return output
end

function fake_resolve(fetcher, host, port):
    return fetcher["fake"].get("addresses", ["93.184.216.34"])
end

function fake_send(fetcher, method, url, headers, body, max_bytes, resolve):
    # odpoved jako transport.request: obsah z pozadavku testu (base64), bez site
    fetcher["sent"] = fetcher.get("sent", 0) + 1
    data = common.base64_decode(fetcher["fake"].get("body", ""))
    truncated = len(data) > max_bytes or fetcher["fake"].get("truncated", False)
    return {"status": fetcher["fake"].get("status", 200), "headers": {"content-type": fetcher["fake"].get("type", "image/png")}, "data": data, "truncated": truncated, "code": 0}
end

function render(request):
    # blok -> PNG (request["path"]); vraci popis vykresleni
    kind = request["kind"]
    width = request.get("width", 560)
    palette = rich_draw.theme(request.get("dark", False))
    parsed = rich_blocks.parse(kind, request["text"])
    if not parsed["ok"]:
        return parsed
    end
    spec = parsed["spec"]
    height = 200
    info = None
    diagram = None
    box = None
    layout = None
    if kind == "chart":
        height = rich_draw.chart_height(spec, width)
    elif kind == "diagram":
        diagram = rich_diagram.parse(spec["source"])
        layout = rich_diagram.measure(diagram, width)
        size = rich_diagram.display_size(layout, width, diagram["kind"])
        width = size[0]
        height = size[1]
    elif kind == "math":
        box = rich_math.measure(spec["source"], request.get("size", 17.0), True)
        width = min(width, Int(box["w"] + 8.5))
        height = Int(box["a"] + box["d"] + 8.5)
    elif kind == "svg":
        theme = None
        if request.get("themed", True):
            theme = {"font": request.get("font", "sans-serif"), "color": "#1d1d2b"}
            if request.get("dark", False):
                theme["color"] = "#eceef7"
            end
        end
        info = rich_svg.sanitize(spec["source"], theme)
        size = rich_svg.display_size(info, width, 560.0)
        width = size[0]
        height = size[1]
    end
    surface = rich_draw.png_surface(width, height, request.get("scale", 1.0))
    cr = cairo.create(surface)
    call rich_draw.fill_background(cr, width, height, palette)
    result = {"width": width, "height": height}
    if kind == "chart":
        hits = rich_draw.draw_chart(cr, spec, width, height, palette, request.get("hover"))
        result["hits"] = len(hits)
    elif kind == "math":
        call rich_math.draw(cr, box, width, height, palette)
    elif kind == "diagram":
        call rich_draw.fill_background(cr, width, height, palette)
        call rich_diagram.draw(cr, diagram, layout, width, height, palette)
        result["diagram"] = diagram["kind"]
    elif kind == "svg":
        image = rich_svg.pixbuf(info["svg"], width * request.get("scale", 1.0), height * request.get("scale", 1.0))
        result["rendered"] = image != 0
        if image != 0:
            call cairo.save(cr)
            call cairo.scale(cr, 1.0 / request.get("scale", 1.0), 1.0 / request.get("scale", 1.0))
            call gtk.cairo_set_source_pixbuf(cr, image, 0, 0)
            call cairo.paint(cr)
            call cairo.restore(cr)
            call glib.object_unref(image)
        end
    end
    call cairo.destroy(cr)
    call cairo.surface_write_to_png(surface, request["path"])
    call cairo.surface_destroy(surface)
    return result
end

requests = json.decode(readfile(arg(1)))
output = []
for request in requests:
    try:
        output.append({"ok": True, "value": run_request(request)})
    else:
        output.append({"ok": False, "error": String(last_error())})
    end
end
print json.encode(output)
