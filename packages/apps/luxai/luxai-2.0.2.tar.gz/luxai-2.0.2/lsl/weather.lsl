# Native LuxAI adapter for `luxos-weather --json`. Shared cache and preferences,
# no GTK in data requests, no automatic IP/location lookup and no shell commands.
load common
load platform
load child_process
load glib
load json
load i18n
load weather_data

function invalid(message):
    Error(ValueError: message)
end

function command(name, args):
    if type(args) != "Dictionary":
        call invalid("arguments must be an object")
    end
    schema = None
    for definition in weather_data.TOOL_DEFS:
        if definition["function"]["name"] == name:
            schema = definition["function"]["parameters"]
        end
    end
    if schema == None:
        call invalid("unknown weather tool")
    end
    for key in schema["required"]:
        if key not in args:
            call invalid("missing " + key)
        end
    end
    for key in args.keys():
        if key not in schema["properties"]:
            call invalid("unexpected argument " + key)
        end
        rule = schema["properties"][key]
        value = args[key]
        if rule["type"] == "string":
            if type(value) != "String" or "\0" in value or len(value) > 200:
                call invalid(key + " must be a string of at most 200 characters")
            end
        elif rule["type"] == "integer":
            if type(value) != "Int":
                call invalid(key + " must be an integer")
            end
        elif type(value) not in ["Int", "Float"]:
            call invalid(key + " must be a number")
        end
        if "minimum" in rule and (value < rule["minimum"] or value > rule["maximum"]):
            call invalid(key + " is outside its valid range")
        end
        if "enum" in rule and value not in rule["enum"]:
            call invalid("invalid " + key)
        end
    end
    if name == "weather_locations":
        return ["locations"]
    elif name == "weather_search":
        query = common.strip_text(args["query"])
        if len(query) < 2:
            call invalid("query must contain at least two characters")
        end
        return ["search", "--limit", String(args.get("limit", 5)), "--", query]
    end
    if ("latitude" in args) != ("longitude" in args):
        call invalid("give both latitude and longitude")
    end
    argv = ["forecast"]
    for key in ["latitude", "longitude", "name", "units", "days", "hours"]:
        if key in args:
            argv.append("--" + key + "=" + String(args[key]))
        end
    end
    return argv
end

function execute(name, args, env=None, signal=None):
    argv = []
    try:
        argv = command(name, args)
    else:
        return {"ok": False, "error": "Invalid arguments: " + String(last_error())}
    end
    if env == None:
        env = child_process.environment()
    end
    executable = None
    for folder in String(env.get("PATH", "/usr/local/bin:/usr/bin:/bin")).split(":"):
        candidate = common.join(common.fallback(folder, "."), "luxos-weather-query")
        info = platform.file_info(candidate)
        if info != None and info["file"] and (info["mode"] & 73) != 0:
            executable = candidate
            break
        end
    end
    if executable == None:
        return {"ok": False, "weather_missing": True, "error": "LuxOS Weather needs to be installed or updated (lux install luxos-weather)."}
    end
    try:
        result = child_process.run([executable] + argv, glib.home_dir(), env, 20, signal, None, False, False, False, False)
        if result["cancelled"]:
            return {"ok": False, "cancelled": True, "error": "Stopped by the user"}
        end
        if result["timed_out"]:
            return {"ok": False, "error": "LuxOS Weather did not answer in time"}
        end
        value = json.decode(result["output"])
        if type(value) != "Dictionary" or type(value.get("ok")) != "Bool":
            return {"ok": False, "error": "LuxOS Weather returned an invalid answer"}
        end
        return value
    else:
        return {"ok": False, "error": "LuxOS Weather could not provide data: " + String(last_error())[:300]}
    end
end

function summary(name, result):
    if name in ["weather_search", "weather_locations"]:
        key = "places"
        if name == "weather_locations":
            key = "locations"
        end
        lines = []
        for place in result.get(key, []):
            text = String(place.get("name", ""))
            if place.get("country"):
                text += ", " + String(place["country"])
            end
            lines.append(text)
        end
        return "\n".join(lines)
    end
    current = result.get("data", {}).get("current", {})
    if not current:
        return ""
    end
    text = String(result.get("location", {}).get("name", "")) + " · " + String(current.get("temp", "")) + " " + String(result.get("units", {}).get("temp", ""))
    text += "\n" + i18n.translate(String(current.get("condition", ""))) + " · " + String(current.get("time", ""))
    if result.get("stale"):
        text += "\n" + i18n.translate("Last known weather (offline)")
    end
    return text
end
