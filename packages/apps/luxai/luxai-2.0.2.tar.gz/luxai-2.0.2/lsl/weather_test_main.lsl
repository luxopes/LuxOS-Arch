# lsl: internal-abi
# Isolated driver: tests_lsl/test_weather.py supplies temporary HOME, APIs and PATH.
load common
load child_process
load tools
load safety
load agent_core
load prompts
load weather
load json
load i18n

fixture = json.decode(readfile(arg(1)))
call i18n.initialize(fixture.get("app_root", "/nonexistent"), "/nonexistent", {"LANG": "en"})
environment = child_process.environment()
for key in fixture.get("env", {}).keys():
    environment[key] = fixture["env"][key]
end
results = []
for item in fixture["ops"]:
    backend = tools.new_tools(fixture["cwd"], None, 120, False, environment, None, None, item.get("chat", False))
    if item["op"] == "execute":
        if item.get("cancelled"):
            call tools.cancel(backend)
        end
        results.append(tools.execute(backend, item["name"], item.get("args", {})))
    elif item["op"] == "decide":
        permissions = safety.new_permissions(False, item.get("policy", {}))
        results.append(safety.decide(permissions, item["name"], item.get("args", {}), fixture["cwd"], None, False, item.get("mode", "agent")))
    elif item["op"] == "definitions":
        state = {"tools": backend, "permissions": safety.new_permissions(False, item.get("policy", {}))}
        results.append(agent_core.declared_names(agent_core.definitions(state)))
    elif item["op"] == "prompt":
        results.append(prompts.system_prompt(item.get("mode", "chat"), fixture["cwd"], False, "", {}, {}, "flash", False, False, False, False, False, False, item.get("weather", True)))
    elif item["op"] == "summary":
        results.append(weather.summary(item["name"], item["result"]))
    end
end
print json.encode(results)
