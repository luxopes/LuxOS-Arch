VERSION = "2.0.2"
APP_ID = "cz.luxai.LuxAI"
