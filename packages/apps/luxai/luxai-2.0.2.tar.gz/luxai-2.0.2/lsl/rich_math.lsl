# lsl: internal-abi
# Nativni sazba matematiky ($$...$$, \[...\], ```math) v cairo + Pango: vlastni krabickovy model
# podle TeXu (sirka, vyska nad a pod uctarim). Zlomky, odmocniny, horni a dolni indexy, velke
# operatory s mezemi (\sum, \int, \lim ...), \left \right s natazenymi zavorkami, matice
# (matrix, pmatrix, bmatrix, Bmatrix, vmatrix, Vmatrix, cases, aligned, array), \binom, akcenty,
# \text, \operatorname, \mathbb/\mathbf/\mathrm, recka pismena a symboly (tabulky z catalog).
# Radkove vzorce \( \) a $...$ zustavaji v Pango markupu (mathtex), ten je i zalohou pri chybe.
load cairo
load pango
load math
load common
load platform
load catalog
load rich_draw

FONT = "Serif"
MAX_SOURCE = 4000
MAX_NODES = 3000
BINARY = ["+", "−", "-", "±", "∓", "×", "÷", "·", "∗", "⋆", "∘", "∙", "⊕", "⊖", "⊗", "⊘", "∪", "∩", "∧", "∨", "⊎", "⊓", "⊔", "∖"]
RELATIONS = ["=", "<", ">", "≤", "≥", "≠", "≈", "≡", "∼", "≃", "≅", "∝", "≪", "≫", "→", "←", "↔", "⇒", "⇐", "⇔", "⟹", "⟸", "⟺", "↦", "∈", "∉", "∋", "⊂", "⊃", "⊆", "⊇", "⊊", "⊋", "⊥", "∥", "∣", ":", "≔", "≺", "≻", "⪯", "⪰", "≲", "≳", "⊢", "⊨", "↑", "↓", "⟶", "⟵", "⟷", "⇝", "≐", "≜", "∦"]
PUNCT = [",", ";"]
OPENERS = ["(", "[", "{", "⟨", "⌊", "⌈", "|", "‖"]
CLOSERS = [")", "]", "}", "⟩", "⌋", "⌉"]
DELIMITERS = {"(": "(", ")": ")", "[": "[", "]": "]", "\\{": "{", "\\}": "}", "|": "|", "\\|": "‖", ".": "", "/": "/", "<": "⟨", ">": "⟩", "\\langle": "⟨", "\\rangle": "⟩", "\\lfloor": "⌊", "\\rfloor": "⌋", "\\lceil": "⌈", "\\rceil": "⌉", "\\vert": "|", "\\Vert": "‖", "\\lvert": "|", "\\rvert": "|", "\\lVert": "‖", "\\rVert": "‖", "\\lbrace": "{", "\\rbrace": "}", "\\lbrack": "[", "\\rbrack": "]"}
LIMIT_OPS = ["sum", "prod", "coprod", "bigcup", "bigcap", "bigoplus", "bigotimes", "bigodot", "biguplus", "bigsqcup", "bigvee", "bigwedge", "lim", "max", "min", "sup", "inf", "liminf", "limsup", "argmax", "argmin", "det", "gcd", "Pr"]
MATRIX_DELIMS = {"matrix": ["", ""], "pmatrix": ["(", ")"], "bmatrix": ["[", "]"], "Bmatrix": ["{", "}"], "vmatrix": ["|", "|"], "Vmatrix": ["‖", "‖"], "smallmatrix": ["", ""], "cases": ["{", ""], "dcases": ["{", ""], "rcases": ["", "}"], "array": ["", ""], "aligned": ["", ""], "align": ["", ""], "align*": ["", ""], "gathered": ["", ""], "gather": ["", ""], "gather*": ["", ""], "split": ["", ""], "eqnarray": ["", ""], "alignat": ["", ""], "alignedat": ["", ""], "equation": ["", ""], "equation*": ["", ""], "multline": ["", ""]}

function fail(message):
    Error(MathError: message)
end

# ---------------------------------------------------------------- krabicky

function new_box(width=0.0, ascent=0.0, descent=0.0):
    return {"w": Float(width), "a": Float(ascent), "d": Float(descent), "items": []}
end

function place(target, child, dx, dy):
    # vlozi krabicku child s uctarim na (dx, dy) vuci uctari target (dy kladne = dolu)
    target["items"].append(["b", Float(dx), Float(dy), child])
    target["a"] = max(target["a"], child["a"] - dy)
    target["d"] = max(target["d"], child["d"] + dy)
    target["w"] = max(target["w"], dx + child["w"])
end

metrics_cache = {}

function measure_text(context, text, size, style):
    # mereni textu je nejdrazsi cast sazby: vysledky pro stejny text, velikost a rez se pamatuji
    key = style + "|" + String(size) + "|" + text
    if key in metrics_cache:
        return metrics_cache[key]
    end
    if len(metrics_cache) > 4000:
        call metrics_cache.clear()
    end
    item = text_layout(context["cr"], text, size, style)
    logical = pango.layout_get_pixel_size(item)
    baseline = pango.layout_get_baseline(item)
    ink = ink_extents(item)
    call pango.layout_unref(item)
    ascent = max(size * 0.7, Float(baseline - ink[1]))
    descent = max(size * 0.22, Float(ink[1] + ink[3] - baseline))
    if text.strip() == "":
        ascent = size * 0.7
        descent = size * 0.22
    end
    result = [Float(logical[0]), ascent, descent, Float(baseline)]
    metrics_cache[key] = result
    return result
end

function ink_extents(item):
    rectangles = platform.buffer(32)
    data = platform.address(rectangles)
    call __lsl_qbe_call3(__lsl_symbol("pango_layout_get_pixel_extents"), platform.pointer(item), platform.pointer(data), platform.pointer(data) + 16)
    values = []
    for index in rang(4):
        values.append(__lsl_qbe_s32(__lsl_qbe_load32(platform.pointer(data) + index * 4)))
    end
    return values
end

function text_layout(cr, text, size, style):
    item = pango.cairo_create_layout(cr)
    description = FONT
    if style == "i":
        description += " Italic"
    elif style == "b":
        description += " Bold"
    elif style == "bi":
        description += " Bold Italic"
    elif style == "s":
        description = "Sans"
    end
    call pango.layout_set_font(item, description + " " + String(Int(size * 10) / 10.0) + "px")
    call pango.layout_set_text(item, text)
    return item
end

function text_box(context, text, size, style="r", color=""):
    context["nodes"] += 1
    if context["nodes"] > MAX_NODES:
        call fail("formula is too complex")
    end
    metrics = measure_text(context, text, size, style)
    result = new_box(metrics[0], metrics[1], metrics[2])
    result["items"].append(["t", 0.0, -metrics[3], text, size, style, color])
    if style == "i":
        # sklon kurzivy: maly presah vpravo
        result["w"] += size * 0.03
    end
    return result
end

function rule(width, thickness):
    result = new_box(width, 0.0, 0.0)
    result["items"].append(["r", 0.0, -thickness / 2.0, width, thickness])
    result["a"] = thickness / 2.0
    result["d"] = thickness / 2.0
    return result
end

function space(width):
    return new_box(width, 0.0, 0.0)
end

# ---------------------------------------------------------------- parser -> atomy

function parser(source, context):
    return {"s": source, "i": 0, "context": context}
end

function peek(state):
    if state["i"] < len(state["s"]):
        return state["s"][state["i"]]
    end
    return ""
end

function skip_spaces(state):
    while state["i"] < len(state["s"]) and state["s"][state["i"]] in " \t\n\r":
        state["i"] += 1
    end
end

function read_command(state):
    # po "\": jmeno ze pismen, nebo jeden znak
    state["i"] += 1
    start = state["i"]
    while state["i"] < len(state["s"]) and state["s"][state["i"]] in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ":
        state["i"] += 1
    end
    if state["i"] == start and state["i"] < len(state["s"]):
        state["i"] += 1
    end
    name = state["s"][start:state["i"]]
    if state["i"] < len(state["s"]) and state["s"][state["i"]] == "*" and name in ["operatorname", "align", "gather", "equation"]:
        state["i"] += 1
        name += "*"
    end
    return name
end

function raw_group(state):
    # obsah {...} jako text (pro \text, \begin)
    call skip_spaces(state)
    if peek(state) != "{":
        char = peek(state)
        state["i"] += 1
        return char
    end
    depth = 0
    start = state["i"]
    while state["i"] < len(state["s"]):
        char = state["s"][state["i"]]
        if char == "\\":
            state["i"] += 2
            continue
        end
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                state["i"] += 1
                return state["s"][start + 1:state["i"] - 1]
            end
        end
        state["i"] += 1
    end
    call fail("unbalanced braces")
end

function argument(state, size, style):
    # jeden argument: {skupina}, \prikaz nebo jeden znak -> krabicka
    call skip_spaces(state)
    char = peek(state)
    if char == "":
        call fail("missing argument")
    end
    if char == "{":
        state["i"] += 1
        atoms = parse_list(state, size, style, "}")
        if peek(state) != "}":
            call fail("unbalanced braces")
        end
        state["i"] += 1
        return hlist(atoms, size, state["context"])
    end
    atoms = parse_atom(state, size, style, [])
    return hlist(atoms, size, state["context"])
end

function optional_argument(state, size, style):
    call skip_spaces(state)
    if peek(state) != "[":
        return None
    end
    state["i"] += 1
    atoms = parse_list(state, size, style, "]")
    if peek(state) != "]":
        call fail("unclosed [")
    end
    state["i"] += 1
    return hlist(atoms, size, state["context"])
end

function atom(cls, box, limits=False):
    return {"cls": cls, "box": box, "limits": limits}
end

function char_class(char):
    if char in BINARY:
        return "bin"
    elif char in RELATIONS:
        return "rel"
    elif char in PUNCT:
        return "punct"
    elif char in OPENERS:
        return "open"
    elif char in CLOSERS:
        return "close"
    end
    return "ord"
end

function parse_list(state, size, style, stop):
    atoms = []
    loop:
        call skip_spaces(state)
        char = peek(state)
        if char == "" or (stop and char == stop):
            break
        end
        if char == "}" and stop != "}":
            call fail("unbalanced braces")
        end
        if stop == "&row" and (char == "&" or state["s"][state["i"]:state["i"] + 2] == "\\\\"):
            break
        end
        if stop == "&row" and state["s"][state["i"]:state["i"] + 4] == "\\end":
            break
        end
        if stop == "\\right" and state["s"][state["i"]:state["i"] + 6] == "\\right":
            break
        end
        if stop == "" and state["s"][state["i"]:state["i"] + 2] == "\\\\":
            break
        end
        if char == "^" or char == "_":
            call attach_scripts(state, atoms, size, style)
            continue
        end
        found = parse_atom(state, size, style, atoms)
        for item in found:
            atoms.append(item)
        end
    end
    return atoms
end

function script_size(size):
    return max(7.0, size * 0.71)
end

function attach_scripts(state, atoms, size, style):
    superscript = None
    subscript = None
    small = script_size(size)
    loop:
        call skip_spaces(state)
        char = peek(state)
        if char == "^" and superscript == None:
            state["i"] += 1
            superscript = argument(state, small, style)
        elif char == "_" and subscript == None:
            state["i"] += 1
            subscript = argument(state, small, style)
        elif char == "'" and superscript == None:
            state["i"] += 1
            superscript = text_box(state["context"], "′", small, "r")
        else:
            break
        end
    end
    base = None
    if atoms:
        base = atoms.pop()
    else:
        base = atom("ord", space(0))
    end
    atoms.append(atom(base["cls"], scripted(base, superscript, subscript, size, state["context"]), False))
end

function scripted(base, superscript, subscript, size, context):
    body = base["box"]
    result = new_box()
    if base["limits"] and context["display"]:
        # meze nad a pod velkym operatorem (\sum, \lim v zobrazenem vzorci)
        width = body["w"]
        if superscript != None:
            width = max(width, superscript["w"])
        end
        if subscript != None:
            width = max(width, subscript["w"])
        end
        call place(result, body, (width - body["w"]) / 2.0, 0)
        if superscript != None:
            call place(result, superscript, (width - superscript["w"]) / 2.0, -(body["a"] + size * 0.12 + superscript["d"]))
        end
        if subscript != None:
            call place(result, subscript, (width - subscript["w"]) / 2.0, body["d"] + size * 0.12 + subscript["a"])
        end
        result["w"] = width
        return result
    end
    call place(result, body, 0, 0)
    x = body["w"] + size * 0.04
    up = max(size * 0.38, body["a"] - size * 0.25)
    down = max(size * 0.2, body["d"] + size * 0.05)
    if superscript != None and subscript != None:
        # oba indexy: dostatecna mezera mezi nimi
        gap = (up - superscript["d"]) - (subscript["a"] - down)
        if gap < size * 0.16:
            down += size * 0.16 - gap
        end
    end
    if superscript != None:
        call place(result, superscript, x, -up)
    end
    if subscript != None:
        subscript_x = x
        if base["cls"] == "op" and not base["limits"]:
            # integral: dolni mez trochu vlevo (sklon znaku)
            subscript_x = x - size * 0.18
        end
        call place(result, subscript, subscript_x, down)
    end
    result["w"] += size * 0.05
    return result
end

function symbol_atom(context, char, size, style):
    cls = char_class(char)
    font = "r"
    if style == "b":
        font = "b"
    end
    if char == "-":
        char = "−"
    end
    return atom(cls, text_box(context, char, size, font))
end

function parse_atom(state, size, style, previous):
    context = state["context"]
    char = peek(state)
    if char == "{":
        state["i"] += 1
        inner = parse_list(state, size, style, "}")
        if peek(state) != "}":
            call fail("unbalanced braces")
        end
        state["i"] += 1
        return [atom("ord", hlist(inner, size, context))]
    end
    if char == "\\":
        return command(state, size, style, previous)
    end
    if char == "&":
        state["i"] += 1
        return []
    end
    state["i"] += 1
    if char in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ":
        font = "i"
        if style == "b":
            font = "bi"
        elif style == "r":
            font = "r"
        end
        return [atom("ord", text_box(context, char, size, font))]
    end
    if char in "0123456789.":
        # cisla vcetne desetinne tecky jako jeden kus
        start = state["i"] - 1
        while state["i"] < len(state["s"]) and state["s"][state["i"]] in "0123456789.":
            state["i"] += 1
        end
        font = "r"
        if style == "b":
            font = "b"
        end
        return [atom("ord", text_box(context, state["s"][start:state["i"]], size, font))]
    end
    if char == "~":
        return [atom("ord", space(size * 0.33))]
    end
    return [symbol_atom(context, char, size, style)]
end

function command(state, size, style, previous):
    context = state["context"]
    name = read_command(state)
    if name == "\\":
        return []
    end
    if name in catalog.MATH_SPACES:
        widths = {",": 0.17, ":": 0.22, ";": 0.28, " ": 0.33, "quad": 1.0, "qquad": 2.0, "!": -0.17, "enspace": 0.5, "thinspace": 0.17, "medspace": 0.22, "thickspace": 0.28}
        return [atom("space", space(size * widths.get(name, 0.25)))]
    end
    if name in ["{", "}", "%", "$", "&", "#", "_", "|"]:
        text = name
        if name == "|":
            text = "‖"
        end
        return [atom(char_class(text), text_box(context, text, size, "r"))]
    end
    if name in catalog.MATH_GREEK:
        letter = catalog.MATH_GREEK[name]
        font = "i"
        if name[0] in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" or style == "r":
            font = "r"
        end
        if style == "b":
            font = "b"
        end
        return [atom("ord", text_box(context, letter, size, font))]
    end
    if name in catalog.MATH_BIG_OPS:
        glyph = catalog.MATH_BIG_OPS[name]
        big = size
        if context["display"]:
            big = size * 1.55
        else:
            big = size * 1.2
        end
        box = text_box(context, glyph, big, "r")
        # svisle vystredit na matematickou osu
        axis = size * 0.25
        middle = (box["a"] - box["d"]) / 2.0
        shifted = new_box()
        call place(shifted, box, 0, middle - axis)
        return [atom("op", shifted, name in LIMIT_OPS)]
    end
    if name in catalog.MATH_FUNCTIONS:
        text = name
        if name in ["mod", "bmod"]:
            return [atom("bin", text_box(context, "mod", size, "r"))]
        end
        return [atom("op", text_box(context, text, size, "r"), name in LIMIT_OPS)]
    end
    if name == "operatorname" or name == "operatorname*":
        text = raw_group(state)
        return [atom("op", text_box(context, strip_text(text), size, "r"), name.endswith("*"))]
    end
    if name in catalog.MATH_SYMBOLS:
        char = catalog.MATH_SYMBOLS[name]
        return [atom(char_class(char), text_box(context, char, size, "r"))]
    end
    if name in ["frac", "dfrac", "tfrac", "cfrac"]:
        inner = size
        if not context["display"] and name != "dfrac":
            inner = script_size(size)
        elif name == "tfrac":
            inner = script_size(size)
        end
        if context["depth"] >= 1 and name not in ["dfrac", "cfrac"]:
            inner = script_size(size)
        end
        context["depth"] += 1
        numerator = argument(state, inner, style)
        denominator = argument(state, inner, style)
        context["depth"] -= 1
        return [atom("inner", fraction(numerator, denominator, size, True))]
    end
    if name in ["binom", "dbinom", "tbinom"]:
        inner = size
        if not context["display"] or name == "tbinom":
            inner = script_size(size)
        end
        top = argument(state, inner, style)
        bottom = argument(state, inner, style)
        stack = fraction(top, bottom, size, False)
        return [atom("inner", fenced(context, "(", stack, ")", size))]
    end
    if name == "sqrt":
        degree = optional_argument(state, script_size(script_size(size)), style)
        body = argument(state, size, style)
        return [atom("ord", radical(body, degree, size))]
    end
    if name in catalog.MATH_TEXT_CMDS:
        text = strip_text(raw_group(state))
        font = "r"
        if name in ["text", "textrm", "textnormal", "mbox", "hbox", "textup"]:
            font = "s"
        end
        if name in ["mathrm", "mathup", "mathsf", "mathtt"]:
            # \mathrm{d}x: muze obsahovat dalsi prikazy - jednoduse jako text
            font = "r"
        end
        return [atom("ord", text_box(context, text, size, font))]
    end
    if name in catalog.MATH_BOLD_CMDS:
        return [atom("ord", argument(state, size, "b"))]
    end
    if name in catalog.MATH_ITALIC_CMDS:
        return [atom("ord", argument(state, size, "i"))]
    end
    if name in ["mathbb", "mathcal", "mathscr", "mathfrak"]:
        text = strip_text(raw_group(state))
        output = []
        letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        script_letters = "𝒜ℬ𝒞𝒟ℰℱ𝒢ℋℐ𝒥𝒦ℒℳ𝒩𝒪𝒫𝒬ℛ𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵"
        for char in text:
            if name == "mathbb":
                output.append(catalog.MATH_BLACKBOARD.get(char, char))
            elif name != "mathfrak" and char in letters:
                output.append(script_letters[letters.find(char)])
            else:
                output.append(char)
            end
        end
        return [atom("ord", text_box(context, "".join(output), size, "r"))]
    end
    if name in catalog.MATH_ACCENTS:
        body = argument(state, size, style)
        return [atom("ord", accent(context, name, body, size))]
    end
    if name in ["overbrace", "underbrace"]:
        body = argument(state, size, style)
        result = new_box()
        call place(result, body, 0, 0)
        brace = rule(body["w"], max(1.0, size * 0.05))
        if name == "overbrace":
            call place(result, brace, 0, -(body["a"] + size * 0.15))
        else:
            call place(result, brace, 0, body["d"] + size * 0.15)
        end
        return [atom("ord", result, True)]
    end
    if name == "boxed":
        body = argument(state, size, style)
        result = new_box(body["w"] + size * 0.5, body["a"] + size * 0.25, body["d"] + size * 0.25)
        result["items"].append(["frame", 0.0, -(body["a"] + size * 0.25), result["w"], result["a"] + result["d"], max(1.0, size * 0.05)])
        call place(result, body, size * 0.25, 0)
        return [atom("ord", result)]
    end
    if name == "not":
        body = argument(state, size, style)
        negatives = {"=": "≠", "<": "≮", ">": "≯", "≤": "≰", "≥": "≱", "∈": "∉", "⊂": "⊄", "⊆": "⊈", "∼": "≁", "≡": "≢", "≈": "≉", "∃": "∄"}
        result = new_box()
        call place(result, body, 0, 0)
        slash = text_box(context, "/", size, "r")
        call place(result, slash, (body["w"] - slash["w"]) / 2.0, 0)
        return [atom("rel", result)]
    end
    if name == "left":
        return [left_right(state, size, style)]
    end
    if name in ["right", "middle"]:
        call fail("\\" + name + " without \\left")
    end
    if name in ["bigl", "bigr", "Bigl", "Bigr", "big", "Big", "bigg", "Bigg", "biggl", "biggr", "Biggl", "Biggr", "bigm", "Bigm"]:
        delimiter = read_delimiter(state)
        factor = {"big": 1.2, "Big": 1.6, "bigg": 2.0, "Bigg": 2.5}
        key = name.rstrip("lrm")
        height = size * factor.get(key, 1.2)
        cls = "open"
        if name.endswith("r"):
            cls = "close"
        end
        return [atom(cls, delimiter_box(context, delimiter, height * 0.5 + size * 0.25, height * 0.5 - size * 0.25, size))]
    end
    if name == "begin":
        environment = raw_group(state)
        return [atom("inner", environment_box(state, environment, size, style))]
    end
    if name == "end":
        call fail("\\end without \\begin")
    end
    if name in ["color", "textcolor"]:
        call raw_group(state)
        if name == "textcolor":
            return [atom("ord", argument(state, size, style))]
        end
        return []
    end
    if name in ["label", "tag", "phantom", "hphantom", "vphantom", "nonumber", "notag"]:
        if name not in ["nonumber", "notag"]:
            call raw_group(state)
        end
        return []
    end
    if name in ["displaystyle", "textstyle", "limits", "nolimits", "rm", "it", "bf", "cal", "scriptstyle", "left.", "mathstrut", "strut"]:
        return []
    end
    if name == "cancel":
        return [atom("ord", argument(state, size, style))]
    end
    if name == "stackrel" or name == "overset" or name == "underset":
        top = argument(state, script_size(size), style)
        body = argument(state, size, style)
        result = new_box()
        width = max(top["w"], body["w"])
        call place(result, body, (width - body["w"]) / 2.0, 0)
        if name == "underset":
            call place(result, top, (width - top["w"]) / 2.0, body["d"] + size * 0.1 + top["a"])
        else:
            call place(result, top, (width - top["w"]) / 2.0, -(body["a"] + size * 0.1 + top["d"]))
        end
        result["w"] = width
        return [atom("rel", result)]
    end
    # neznamy prikaz: zobrazit jako text (bez chyby, at je videt, co model napsal)
    return [atom("ord", text_box(context, "\\" + name, size, "s", "dim"))]
end

function strip_text(text):
    return platform.regex_replace("\\\\([{}%$&#_ ])", "\\1", text).replace("~", " ").replace("\\,", " ")
end

function read_delimiter(state):
    call skip_spaces(state)
    char = peek(state)
    if char == "\\":
        start = state["i"]
        name = read_command(state)
        key = "\\" + name
        if key in DELIMITERS:
            return DELIMITERS[key]
        end
        call fail("unknown delimiter \\" + name)
    end
    state["i"] += 1
    if char in DELIMITERS:
        return DELIMITERS[char]
    end
    call fail("unknown delimiter " + char)
end

function left_right(state, size, style):
    context = state["context"]
    opening = read_delimiter(state)
    atoms = parse_list(state, size, style, "\\right")
    if state["s"][state["i"]:state["i"] + 6] != "\\right":
        call fail("\\left without \\right")
    end
    state["i"] += 6
    closing = read_delimiter(state)
    body = hlist(atoms, size, context)
    return atom("inner", fenced(context, opening, body, closing, size))
end

function fenced(context, opening, body, closing, size):
    axis = size * 0.25
    extent = max(body["a"] - axis, body["d"] + axis, size * 0.45) + size * 0.08
    result = new_box()
    x = 0.0
    if opening:
        left = delimiter_box(context, opening, axis + extent, extent - axis, size)
        call place(result, left, 0, 0)
        x = left["w"]
    end
    call place(result, body, x, 0)
    x += body["w"]
    if closing:
        right = delimiter_box(context, closing, axis + extent, extent - axis, size)
        call place(result, right, x, 0)
        x += right["w"]
    end
    result["w"] = x
    return result
end

function delimiter_box(context, char, ascent, descent, size):
    # zavorka presne vysoka ascent + descent; male velikosti jako znak pisma
    height = ascent + descent
    if height <= size * 1.25 and char not in ["⟨", "⟩"]:
        box = text_box(context, char, size, "r")
        return box
    end
    width = size * 0.42
    if char in ["|", "‖"]:
        width = size * 0.3
        if char == "‖":
            width = size * 0.45
        end
    elif char in ["{", "}"]:
        width = size * 0.5
    elif char in ["[", "]", "⌊", "⌋", "⌈", "⌉"]:
        width = size * 0.36
    end
    result = new_box(width, ascent, descent)
    result["items"].append(["delim", 0.0, -ascent, width, height, char, max(1.0, size * 0.065)])
    return result
end

function fraction(numerator, denominator, size, line=True):
    thickness = max(1.0, size * 0.06)
    axis = size * 0.25
    gap = size * 0.14
    width = max(numerator["w"], denominator["w"]) + size * 0.3
    result = new_box(width, 0, 0)
    call place(result, numerator, (width - numerator["w"]) / 2.0, -(axis + thickness / 2.0 + gap + numerator["d"]))
    call place(result, denominator, (width - denominator["w"]) / 2.0, -axis + thickness / 2.0 + gap + denominator["a"])
    if line:
        result["items"].append(["r", size * 0.08, -axis - thickness / 2.0, width - size * 0.16, thickness])
    end
    result["w"] = width
    return result
end

function radical(body, degree, size):
    thickness = max(1.0, size * 0.06)
    gap = size * 0.12
    sign_width = size * 0.6
    top = body["a"] + gap + thickness
    bottom = max(body["d"], size * 0.1)
    result = new_box()
    offset = 0.0
    if degree != None:
        offset = max(0.0, degree["w"] - sign_width * 0.45)
        call place(result, degree, 0, -(top * 0.45 + degree["d"]))
    end
    call place(result, body, offset + sign_width + size * 0.05, 0)
    result["items"].append(["radical", offset, -top, sign_width, top + bottom, body["w"] + size * 0.12, thickness])
    result["a"] = max(result["a"], top + thickness)
    result["d"] = max(result["d"], bottom)
    result["w"] = offset + sign_width + body["w"] + size * 0.17
    return result
end

function accent(context, name, body, size):
    result = new_box()
    call place(result, body, 0, 0)
    if name in ["overline", "bar", "underline"]:
        thickness = max(1.0, size * 0.05)
        if name == "underline":
            result["items"].append(["r", 0.0, body["d"] + size * 0.08, body["w"], thickness])
            result["d"] = body["d"] + size * 0.08 + thickness
        else:
            inset = 0.0
            if name == "bar":
                inset = body["w"] * 0.1
            end
            result["items"].append(["r", inset, -(body["a"] + size * 0.08 + thickness), body["w"] - inset * 2, thickness])
            result["a"] = body["a"] + size * 0.08 + thickness
        end
        return result
    end
    marks = {"hat": "ˆ", "widehat": "ˆ", "vec": "→", "dot": "˙", "ddot": "¨", "tilde": "˜", "widetilde": "˜", "check": "ˇ", "breve": "˘", "acute": "´", "grave": "`", "mathring": "˚"}
    mark = marks.get(name, "ˆ")
    small = size * 0.8
    if name == "vec":
        small = size * 0.6
    end
    glyph = text_box(context, mark, small, "r")
    lift = body["a"] - glyph["a"] * 0.35 + size * 0.02
    if name in ["hat", "widehat", "tilde", "widetilde", "check", "breve", "acute", "grave"]:
        lift = body["a"] - small * 0.45
    end
    call place(result, glyph, (body["w"] - glyph["w"]) / 2.0 + size * 0.05, -lift)
    result["w"] = max(body["w"], glyph["w"])
    return result
end

function environment_box(state, environment, size, style):
    context = state["context"]
    if environment not in MATRIX_DELIMS:
        call fail("unsupported environment " + environment)
    end
    if environment in ["array", "alignat", "alignedat"]:
        call raw_group(state)
    end
    inner = size
    if environment == "smallmatrix":
        inner = script_size(size)
    end
    rows = []
    row = []
    loop:
        atoms = parse_list(state, inner, style, "&row")
        row.append(hlist(atoms, inner, context))
        if len(rows) * 50 + len(row) > 2000:
            call fail("matrix is too large")
        end
        rest = state["s"][state["i"]:]
        if rest.startswith("&"):
            state["i"] += 1
            continue
        end
        if rest.startswith("\\\\"):
            state["i"] += 2
            call optional_argument(state, inner, style)
            rows.append(row)
            row = []
            continue
        end
        if rest.startswith("\\end"):
            state["i"] += 4
            name = raw_group(state)
            if name != environment:
                call fail("\\begin{" + environment + "} ended by \\end{" + name + "}")
            end
            rows.append(row)
            break
        end
        call fail("\\begin{" + environment + "} without \\end")
    end
    # prazdny posledni radek po \\ na konci
    if len(rows) > 1 and len(rows[len(rows) - 1]) == 1 and rows[len(rows) - 1][0]["w"] == 0:
        call rows.pop()
    end
    columns = 0
    for item in rows:
        columns = max(columns, len(item))
    end
    widths = []
    for c in rang(columns):
        widths.append(0.0)
    end
    for item in rows:
        for c in rang(len(item)):
            widths[c] = max(widths[c], item[c]["w"])
        end
    end
    aligned = environment in ["aligned", "align", "align*", "split", "eqnarray", "alignat", "alignedat"]
    left_aligned = environment in ["cases", "dcases", "rcases"]
    column_gap = size * 0.9
    if aligned:
        column_gap = 0.0
    elif left_aligned:
        column_gap = size * 1.1
    end
    row_gap = size * 0.35
    if environment in ["cases", "dcases"]:
        row_gap = size * 0.45
    end
    grid = new_box()
    y = 0.0
    first = True
    for item in rows:
        ascent = size * 0.7
        descent = size * 0.22
        for cell in item:
            ascent = max(ascent, cell["a"])
            descent = max(descent, cell["d"])
        end
        if not first:
            y += ascent
        end
        x = 0.0
        for c in rang(len(item)):
            cell = item[c]
            dx = (widths[c] - cell["w"]) / 2.0
            if left_aligned:
                dx = 0.0
            elif aligned:
                if c % 2 == 0:
                    dx = widths[c] - cell["w"]
                else:
                    dx = 0.0
                end
            end
            call place(grid, cell, x + dx, y)
            x += widths[c] + column_gap
        end
        y += descent + row_gap
        first = False
    end
    total_width = 0.0
    for c in rang(columns):
        total_width += widths[c]
    end
    total_width += column_gap * max(0, columns - 1)
    grid["w"] = total_width
    # svisle vystredit na matematickou osu
    axis = size * 0.25
    middle = (grid["a"] - grid["d"]) / 2.0
    centered = new_box()
    call place(centered, grid, size * 0.15, middle - axis)
    centered["w"] = grid["w"] + size * 0.3
    delimiters = MATRIX_DELIMS[environment]
    if delimiters[0] or delimiters[1]:
        return fenced(context, delimiters[0], centered, delimiters[1], size)
    end
    return centered
end

# ---------------------------------------------------------------- vodorovne skladani

function gap_between(left, right, size, context):
    # zjednodusena tabulka mezer TeXu (v em)
    if left == "space" or right == "space":
        return 0.0
    end
    if left in ["", "open"] or right in ["close", "punct"]:
        if left == "punct":
            return size * 0.17
        end
        return 0.0
    end
    if left == "punct":
        return size * 0.17
    end
    if left == "rel" or right == "rel":
        if left == "rel" and right == "rel":
            return 0.0
        end
        return size * 0.28
    end
    if left == "bin" or right == "bin":
        return size * 0.22
    end
    if left == "op" and right in ["ord", "inner", "op"]:
        return size * 0.17
    end
    if right == "op" and left in ["ord", "close", "inner"]:
        return size * 0.17
    end
    if left == "inner" or right == "inner":
        return size * 0.1
    end
    return 0.0
end

function hlist(atoms, size, context):
    result = new_box(0, size * 0.0, 0)
    x = 0.0
    previous = ""
    count = len(atoms)
    for index in rang(count):
        item = atoms[index]
        cls = item["cls"]
        # binarni operator na zacatku nebo po relaci/oteviraci zavorce je unarni (ord)
        if cls == "bin" and previous in ["", "bin", "rel", "open", "punct", "op"]:
            cls = "ord"
        end
        if cls == "bin" and index == count - 1:
            cls = "ord"
        end
        if size >= 11:
            x += gap_between(previous, cls, size, context)
        end
        call place(result, item["box"], x, 0)
        x += item["box"]["w"]
        if cls != "space":
            previous = cls
        end
    end
    result["w"] = max(0.0, x)
    return result
end

function layout(cr, source, size=17.0, display=True):
    # krabicka celeho vzorce; vice radku (\\ na nejvyssi urovni) pod sebou na stred
    source = String(source)
    if len(source) > MAX_SOURCE:
        call fail("formula is too long")
    end
    context = {"cr": cr, "display": display, "depth": 0, "nodes": 0}
    state = parser(source, context)
    lines = []
    loop:
        atoms = parse_list(state, size, "", "")
        lines.append(hlist(atoms, size, context))
        if state["s"][state["i"]:state["i"] + 2] == "\\\\":
            state["i"] += 2
            continue
        end
        if state["i"] < len(state["s"]):
            call fail("unexpected " + state["s"][state["i"]])
        end
        break
    end
    if len(lines) == 1:
        return lines[0]
    end
    width = 0.0
    for line in lines:
        width = max(width, line["w"])
    end
    result = new_box(width, 0, 0)
    y = 0.0
    first = True
    for line in lines:
        if not first:
            y += line["a"] + size * 0.4
        end
        call place(result, line, (width - line["w"]) / 2.0, y)
        y += line["d"]
        first = False
    end
    return result
end

# ---------------------------------------------------------------- kresleni

function draw_box(cr, box, x, y, palette):
    for item in box["items"]:
        kind = item[0]
        if kind == "b":
            call draw_box(cr, item[3], x + item[1], y + item[2], palette)
        elif kind == "t":
            color = palette["fg"]
            if item[6] == "dim":
                color = palette["dim"]
            end
            layout_item = text_layout(cr, item[3], item[4], item[5])
            call rich_draw.source(cr, color)
            call cairo.move_to(cr, x + item[1], y + item[2])
            call pango.cairo_show_layout(cr, layout_item)
            call pango.layout_unref(layout_item)
        elif kind == "r":
            call rich_draw.source(cr, palette["fg"])
            call cairo.rectangle(cr, x + item[1], y + item[2], item[3], item[4])
            call cairo.fill(cr)
        elif kind == "frame":
            call rich_draw.source(cr, palette["fg"])
            call cairo.set_line_width(cr, item[5])
            call cairo.rectangle(cr, x + item[1], y + item[2], item[3], item[4])
            call cairo.stroke(cr)
        elif kind == "radical":
            call draw_radical(cr, x + item[1], y + item[2], item[3], item[4], item[5], item[6], palette)
        elif kind == "delim":
            call draw_delimiter(cr, x + item[1], y + item[2], item[3], item[4], item[5], item[6], palette)
        end
    end
end

function draw_radical(cr, left, top, sign_width, height, body_width, thickness, palette):
    call rich_draw.source(cr, palette["fg"])
    call cairo.set_line_width(cr, thickness)
    call cairo.set_line_join(cr, 1)
    call cairo.new_path(cr)
    bottom = top + height
    call cairo.move_to(cr, left + sign_width * 0.05, bottom - height * 0.42)
    call cairo.line_to(cr, left + sign_width * 0.25, bottom - height * 0.5)
    call cairo.line_to(cr, left + sign_width * 0.5, bottom)
    call cairo.line_to(cr, left + sign_width * 0.95, top + thickness / 2.0)
    call cairo.line_to(cr, left + sign_width + body_width, top + thickness / 2.0)
    call cairo.stroke(cr)
end

function draw_delimiter(cr, left, top, width, height, char, thickness, palette):
    call rich_draw.source(cr, palette["fg"])
    call cairo.set_line_width(cr, thickness * 1.15)
    call cairo.set_line_cap(cr, 1)
    call cairo.new_path(cr)
    bottom = top + height
    middle = top + height / 2.0
    inner = left + width * 0.3
    outer = left + width * 0.75
    if char == "(":
        call cairo.move_to(cr, outer, top)
        call cairo.curve_to(cr, inner - width * 0.15, top + height * 0.25, inner - width * 0.15, bottom - height * 0.25, outer, bottom)
    elif char == ")":
        call cairo.move_to(cr, inner, top)
        call cairo.curve_to(cr, outer + width * 0.15, top + height * 0.25, outer + width * 0.15, bottom - height * 0.25, inner, bottom)
    elif char in ["[", "⌊", "⌈"]:
        if char != "⌊":
            call cairo.move_to(cr, outer, top)
            call cairo.line_to(cr, inner, top)
        else:
            call cairo.move_to(cr, inner, top)
        end
        call cairo.line_to(cr, inner, bottom)
        if char != "⌈":
            call cairo.line_to(cr, outer, bottom)
        end
    elif char in ["]", "⌋", "⌉"]:
        if char != "⌋":
            call cairo.move_to(cr, inner, top)
            call cairo.line_to(cr, outer, top)
        else:
            call cairo.move_to(cr, outer, top)
        end
        call cairo.line_to(cr, outer, bottom)
        if char != "⌉":
            call cairo.line_to(cr, inner, bottom)
        end
    elif char == "{":
        tip = left + width * 0.15
        stem = left + width * 0.5
        call cairo.move_to(cr, left + width * 0.85, top)
        call cairo.curve_to(cr, stem, top, stem, top, stem, top + height * 0.15)
        call cairo.line_to(cr, stem, middle - height * 0.1)
        call cairo.curve_to(cr, stem, middle, stem, middle, tip, middle)
        call cairo.curve_to(cr, stem, middle, stem, middle, stem, middle + height * 0.1)
        call cairo.line_to(cr, stem, bottom - height * 0.15)
        call cairo.curve_to(cr, stem, bottom, stem, bottom, left + width * 0.85, bottom)
    elif char == "}":
        tip = left + width * 0.85
        stem = left + width * 0.5
        call cairo.move_to(cr, left + width * 0.15, top)
        call cairo.curve_to(cr, stem, top, stem, top, stem, top + height * 0.15)
        call cairo.line_to(cr, stem, middle - height * 0.1)
        call cairo.curve_to(cr, stem, middle, stem, middle, tip, middle)
        call cairo.curve_to(cr, stem, middle, stem, middle, stem, middle + height * 0.1)
        call cairo.line_to(cr, stem, bottom - height * 0.15)
        call cairo.curve_to(cr, stem, bottom, stem, bottom, left + width * 0.15, bottom)
    elif char == "|":
        call cairo.move_to(cr, left + width / 2.0, top)
        call cairo.line_to(cr, left + width / 2.0, bottom)
    elif char == "‖":
        call cairo.move_to(cr, left + width * 0.35, top)
        call cairo.line_to(cr, left + width * 0.35, bottom)
        call cairo.move_to(cr, left + width * 0.65, top)
        call cairo.line_to(cr, left + width * 0.65, bottom)
    elif char == "⟨":
        call cairo.move_to(cr, outer, top)
        call cairo.line_to(cr, inner, middle)
        call cairo.line_to(cr, outer, bottom)
    elif char == "⟩":
        call cairo.move_to(cr, inner, top)
        call cairo.line_to(cr, outer, middle)
        call cairo.line_to(cr, inner, bottom)
    elif char == "/":
        call cairo.move_to(cr, outer, top)
        call cairo.line_to(cr, inner, bottom)
    end
    call cairo.stroke(cr)
end

function measure(source, size=17.0, display=True):
    # [box, sirka, vyska] bez okna (vlastni kontext pro mereni pisma)
    surface = cairo.image_surface_create(cairo.FORMAT_ARGB32, 4, 4)
    cr = cairo.create(surface)
    box = None
    problem = None
    try:
        box = layout(cr, source, size, display)
    else:
        problem = String(last_error())
    end
    call cairo.destroy(cr)
    call cairo.surface_destroy(surface)
    if problem != None:
        if problem.startswith("MathError: "):
            problem = problem[11:]
        end
        Error(MathError: problem)
    end
    return box
end

function draw(cr, box, width, height, palette):
    # vzorec vystredeny v obdelniku (zmenseny, kdyz se nevejde)
    natural_w = box["w"] + 8
    natural_h = box["a"] + box["d"] + 8
    scale = min(1.0, width / natural_w)
    call cairo.save(cr)
    call cairo.translate(cr, (width - natural_w * scale) / 2.0, (height - natural_h * scale) / 2.0)
    call cairo.scale(cr, scale, scale)
    call draw_box(cr, box, 4, 4 + box["a"], palette)
    call cairo.restore(cr)
end
