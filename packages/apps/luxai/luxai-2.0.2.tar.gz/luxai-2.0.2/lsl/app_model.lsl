# Application state and asynchronous lifecycle. GUI callbacks run on the main
# thread; API/agent/title work is queued through ui_dispatch.
load common
load platform
load glib
load time
load json
load settings
load store
load api
load attachments
load images
load titles
load safety
load tools
load agent_core
load catalog
load protocol
load ui_dispatch

function emit(state, name, arguments=None):
    if state.get("on_event") != None and state["alive"]:
        call state["on_event"](state, name, common.fallback(arguments, []))
    end
end

function new_model(on_event=None, account=None, load_saved_account=True):
    preferences = settings.Settings()
    repository = store.Store()
    if load_saved_account:
        account = api.load_account()
    end
    client = None
    user = None
    signed = "signed_out"
    if account:
        client = api.new_client(account)
        user = account.get("user")
        signed = "ok"
    end
    return {"settings": preferences.data, "settings_path": preferences.path, "store_root": repository.root, "account": account, "client": client, "user": user, "signed_state": signed, "mode": preferences.data["mode"], "model": preferences.data["model"], "conversation": store.Conversation(None, "", preferences.data["mode"], preferences.data["model"]), "permissions": safety.new_permissions(False, preferences.data["agent"]), "current_run": None, "run_id": 0, "confirmations": [], "attachments": [], "title_jobs": {}, "title_tries": {}, "deleted": [], "on_event": on_event, "alive": True, "closing": False, "account_generation": 0, "account_jobs": [], "pending_ask": None}
end

function save_settings(state):
    state["settings"]["agent"] = settings.normalize_policy(state["settings"]["agent"])
    try:
        call common.atomic_json(state["settings_path"], state["settings"])
        return True
    else:
        call emit(state, "save_error", [String(last_error())])
        return False
    end
end

function workdir(state):
    path = state["settings"]["workdir"]
    if path:
        info = platform.file_info(path)
        if info != None and info["directory"]:
            return path
        end
    end
    return glib.home_dir()
end

function load_conversation(state, id):
    repository = store.Store(state["store_root"])
    return repository.load(id)
end

function list_conversations(state):
    repository = store.Store(state["store_root"])
    items = repository.list()
    conversation = state["conversation"]
    if not state["settings"]["keep_history"]:
        items = []
        if not store.conversation_empty(conversation):
            items.append({"id": conversation["id"], "title": store.display_title(conversation), "mode": conversation["mode"], "model": conversation["model"], "updated": conversation["updated"]})
        end
    end
    for item in items:
        if item["id"] == conversation["id"] and not store.conversation_empty(conversation):
            item["title"] = common.fallback(store.display_title(conversation), item["title"])
        end
    end
    return items
end

function save_conversation(state, conversation=None, touch=True):
    conversation = common.fallback(conversation, state["conversation"])
    if not state["settings"]["keep_history"] or conversation["id"] in state["deleted"]:
        return False
    end
    # The worker owns the mutable message sequence until finished. Switching
    # views cancels that worker; its finished event persists the final history.
    if state["current_run"] != None and state["current_run"]["conversation"]["id"] == conversation["id"]:
        return False
    end
    try:
        repository = store.Store(state["store_root"])
        return repository.save(conversation, touch)
    else:
        call emit(state, "save_error", [String(last_error())])
        return False
    end
end

function fallback_title(conversation):
    topic = titles.topic(conversation["messages"])
    if topic != None and conversation["title_source"] == "fallback":
        conversation["title"] = common.fallback(titles.fallback_title(topic[2]), conversation["title"])
    end
    return topic
end

function preferences(state):
    values = state["settings"]
    temperature = None
    if values["temperature_custom"]:
        temperature = Float(values["temperature"])
    end
    return {"style": values["style"], "language": values["language"], "instructions": values["instructions"], "max_tokens": catalog.ANSWER_LENGTHS.get(values["answer_length"], 4096), "temperature": temperature}
end

function confirmation_done(request, answer):
    signal = IntArray(request["signal"])
    if atomic_add(signal, 0, 0) == 0:
        request["answer"] = answer
        call atomic_xchg(signal, 0, 1)
    end
end

function show_confirmation(ui, arguments):
    state = ui["owner"]
    request = arguments
    if state["closing"] or not state["alive"] or state["run_id"] != ui["run_id"] or state["conversation"]["id"] != ui["run"]["conversation"]["id"] or agent_core.is_cancelled(ui["run"]):
        call confirmation_done(request, "deny")
        return
    end
    state["confirmations"].append(request)
    call emit(state, "tool_confirm", [request])
end

function confirm(ui, id, name, arguments, kind, reasons):
    signal = IntArray()
    signal.append(0)
    request = {"id": id, "name": name, "args": arguments, "kind": kind, "reasons": reasons, "signal": signal, "answer": "deny", "done": confirmation_done}
    call ui_dispatch.post(show_confirmation, ui, request)
    while atomic_add(signal, 0, 0) == 0:
        if agent_core.is_cancelled(ui["run"]):
            return "deny"
        end
        call time.sleep(0.02)
    end
    return request["answer"]
end

function handle_event(ui, event):
    state = ui["owner"]
    name = event[0]
    arguments = event[1]
    if not state["alive"] or state["run_id"] != ui["run_id"]:
        return
    end
    if name == "finished":
        conversation = ui["run"]["conversation"]
        state["current_run"] = None
        state["confirmations"] = []
        call save_conversation(state, conversation, False)
        call maybe_title(state, conversation)
        call emit(state, "finished", [arguments[0], conversation["id"]])
        call emit(state, "history_changed")
        if state["closing"]:
            call finish_close(state)
        end
        return
    end
    if state["closing"] or state["conversation"]["id"] != ui["run"]["conversation"]["id"]:
        return
    end
    if name == "usage" and type(state["user"]) == "Dictionary":
        try:
            total = Int(common.fallback(arguments[0].get("total_tokens"), 0))
            if type(state["user"].get("usage")) != "Dictionary":
                state["user"]["usage"] = {}
            end
            key = "liteTokens"
            if ui["run"]["conversation"]["model"] == "flash":
                key = "fastTokens"
            end
            usage = state["user"]["usage"]
            usage[key] = Int(common.fallback(usage.get(key), 0)) + total
        else:
            total = 0
        end
    elif name == "error" and api.is_auth(arguments[0]):
        state["signed_state"] = "expired"
    end
    call emit(state, name, arguments)
end

function worker_emit(ui, name, arguments):
    call ui_dispatch.post(handle_event, ui, [name, arguments])
end

function run_worker(run, arguments):
    return agent_core.run(run)
end

function send(state, text, gui=None, screen=""):
    if state["current_run"] != None or state["signed_state"] != "ok" or state["client"] == None or state["closing"]:
        return False
    end
    text = platform.strip(text, common.WHITESPACE)
    if not text and not state["attachments"]:
        return False
    end
    conversation = state["conversation"]
    conversation["mode"] = state["mode"]
    conversation["model"] = state["model"]
    message = attachments.user_message(text, state["attachments"])
    conversation["messages"].append(message)
    call fallback_title(conversation)
    call save_conversation(state)
    state["attachments"] = []
    call emit(state, "user_message", [message])
    call emit(state, "attachments_changed")
    vision = Bool(state["settings"]["vision"].get(state["model"]))
    backend = tools.new_tools(workdir(state), gui, state["settings"]["timeout"], vision, None, state["permissions"]["policy"]["blocked_folders"], state["client"], state["mode"] == "chat")
    if state.get("tool_adapter") != None:
        backend = state["tool_adapter"](state, backend)
    end
    state["run_id"] += 1
    state["confirmations"] = []
    ui = {"owner": state, "run_id": state["run_id"], "emit": worker_emit, "confirm": confirm}
    # Each run has its own abort signal; refreshing account data uses a
    # separate client and cannot accidentally revive an aborted request.
    client = api.new_client(state["account"], state["client"]["origin"])
    run = agent_core.new_run(conversation, client, ui, backend, state["permissions"], preferences(state), vision, screen)
    ui["run"] = run
    # dotaz z jineho programu (app_window.ask): rezim spravce "bez ptani" pro nej neplati (safety.judge)
    run["external"] = Bool(state.get("external_ask"))
    if state.get("request_adapter") != None:
        run["request"] = state["request_adapter"]
    end
    state["current_run"] = run
    call emit(state, "running_changed", [True])
    call emit(state, "history_changed")
    state["run_job"] = ui_dispatch.background(run_worker, run)
    return True
end

function stop(state):
    if state["current_run"] != None:
        call agent_core.cancel(state["current_run"])
        for request in state["confirmations"]:
            call confirmation_done(request, "deny")
        end
        call emit(state, "stopping")
    end
end

function new_conversation(state):
    call stop(state)
    call save_conversation(state)
    state["conversation"] = store.Conversation(None, "", state["mode"], state["model"])
    call safety.reset(state["permissions"])
    call emit(state, "conversation_changed")
    call emit(state, "attachments_changed")
end

function open_conversation(state, id):
    call stop(state)
    call save_conversation(state)
    try:
        conversation = load_conversation(state, id)
    else:
        return False
    end
    state["conversation"] = conversation
    state["mode"] = conversation["mode"]
    if conversation["model"] in ["flash", "lite"]:
        state["model"] = conversation["model"]
    end
    state["settings"]["mode"] = state["mode"]
    state["settings"]["model"] = state["model"]
    call save_settings(state)
    call emit(state, "conversation_changed")
    return True
end

function rename(state, id, title):
    title = String(common.words(title))[:120]
    if not title:
        return False
    end
    conversation = state["conversation"]
    if id != conversation["id"]:
        try:
            conversation = load_conversation(state, id)
        else:
            return False
        end
    end
    conversation["title"] = title
    conversation["title_source"] = "manual"
    if id in state["title_jobs"]:
        call api.abort(state["title_jobs"][id]["client"])
        state["title_jobs"] = common.without(state["title_jobs"], id)
    end
    call save_conversation(state, conversation, False)
    call emit(state, "history_changed")
    return True
end

function delete(state, id):
    if id == state["conversation"]["id"]:
        call stop(state)
        state["conversation"] = store.Conversation(None, "", state["mode"], state["model"])
        call emit(state, "conversation_changed")
    end
    state["deleted"].append(id)
    if id in state["title_jobs"]:
        call api.abort(state["title_jobs"][id]["client"])
        state["title_jobs"] = common.without(state["title_jobs"], id)
    end
    repository = store.Store(state["store_root"])
    call repository.delete(id)
    call emit(state, "history_changed")
end

function clear_history(state):
    call stop(state)
    call cancel_titles(state)
    for item in list_conversations(state):
        state["deleted"].append(item["id"])
    end
    if state["current_run"] != None:
        state["deleted"].append(state["current_run"]["conversation"]["id"])
    end
    repository = store.Store(state["store_root"])
    call repository.clear()
    state["conversation"] = store.Conversation(None, "", state["mode"], state["model"])
    call safety.reset(state["permissions"])
    call emit(state, "conversation_changed")
    call emit(state, "history_changed")
end

function title_worker(job, arguments):
    title = job["fallback"]
    source = "fallback"
    try:
        title = titles.generate_title(job["client"], job["text"], job["answer"])
        source = "model"
    else:
        title = job["fallback"]
    end
    if not api.is_cancelled(job["client"]):
        call ui_dispatch.post(title_done, job, [title, source])
    end
end

function title_done(job, result):
    state = job["owner"]
    id = job["id"]
    if not state["alive"] or state["closing"] or id not in state["title_jobs"] or state["title_jobs"][id] != job:
        return
    end
    state["title_jobs"] = common.without(state["title_jobs"], id)
    if not result[0] or id in state["deleted"]:
        return
    end
    conversation = state["conversation"]
    if conversation["id"] != id:
        if not state["settings"]["keep_history"]:
            return
        end
        try:
            conversation = load_conversation(state, id)
        else:
            return
        end
    end
    if conversation["title_source"] != "fallback":
        return
    end
    conversation["title"] = result[0]
    conversation["title_source"] = result[1]
    call save_conversation(state, conversation, False)
    call emit(state, "history_changed")
end

function maybe_title(state, conversation=None):
    conversation = common.fallback(conversation, state["conversation"])
    id = conversation["id"]
    if state["closing"] or id in state["deleted"] or conversation["title_source"] != "fallback" or id in state["title_jobs"]:
        return
    end
    topic = fallback_title(conversation)
    if topic == None:
        return
    end
    call save_conversation(state, conversation, False)
    if state["title_tries"].get(id, 0) >= titles.MAX_ATTEMPTS or not state["settings"]["auto_title"] or not state["account"]:
        return
    end
    state["title_tries"][id] = state["title_tries"].get(id, 0) + 1
    client = api.new_client(state["account"], state["client"]["origin"])
    job = {"id": id, "owner": state, "client": client, "text": topic[1], "fallback": titles.fallback_title(topic[2]), "answer": titles.answer_after(conversation["messages"], topic[0])}
    state["title_jobs"][id] = job
    job["work"] = ui_dispatch.background(title_worker, job)
end

function cancel_titles(state):
    for job in state["title_jobs"].values():
        call api.abort(job["client"])
    end
    state["title_jobs"] = {}
end

function account_worker(job, arguments):
    try:
        value = api.me(job["client"])
        call ui_dispatch.post(account_done, job, {"value": value})
    else:
        call ui_dispatch.post(account_done, job, {"error": api.caught_error(String(last_error()))})
    end
end

function account_done(job, result):
    state = job["owner"]
    if not state["alive"] or state["closing"] or state["account_generation"] != job["generation"]:
        return
    end
    if "value" in result:
        state["user"] = result["value"].get("user")
        state["signed_state"] = "ok"
        call emit(state, "account_changed")
    elif api.is_auth(result["error"]):
        state["signed_state"] = "expired"
        call emit(state, "account_changed")
    else:
        call emit(state, "account_offline")
    end
end

function refresh_account(state):
    if state["client"] == None or state["closing"]:
        return
    end
    remaining = []
    for job in state["account_jobs"]:
        if ui_dispatch.completed(job["work"]) == 0:
            remaining.append(job)
        end
    end
    state["account_jobs"] = remaining
    if remaining:
        return
    end
    job = {"owner": state, "generation": state["account_generation"], "client": api.new_client(state["account"], state["client"]["origin"])}
    job["work"] = ui_dispatch.background(account_worker, job)
    state["account_jobs"].append(job)
end

function reload_account(state):
    state["account_generation"] += 1
    state["account"] = api.load_account()
    state["client"] = None
    if state["account"]:
        state["client"] = api.new_client(state["account"])
        state["user"] = state["account"].get("user")
        state["signed_state"] = "ok"
    else:
        state["user"] = None
        if state["signed_state"] != "expired":
            state["signed_state"] = "signed_out"
        end
    end
    call emit(state, "account_changed")
    call refresh_account(state)
end

function setting_changed(state, key):
    data = state["settings"]
    if key == "agent":
        call safety.set_policy(state["permissions"], data["agent"])
    elif key == "model" and state["current_run"] == None:
        state["model"] = data["model"]
        state["conversation"]["model"] = data["model"]
    elif key == "mode" and state["current_run"] == None and store.conversation_empty(state["conversation"]):
        state["mode"] = data["mode"]
        state["conversation"]["mode"] = data["mode"]
    elif key == "keep_history" and data["keep_history"]:
        call save_conversation(state)
    end
    call emit(state, "settings_changed", [key])
end

function finish_close(state):
    call save_conversation(state)
    call save_settings(state)
    call emit(state, "closed")
    state["alive"] = False
end

function close(state):
    state["closing"] = True
    call stop(state)
    call cancel_titles(state)
    for job in state["account_jobs"]:
        call api.abort(job["client"])
    end
    if state["current_run"] == None:
        call finish_close(state)
    end
end
