# lsl: internal-abi
# Native LuxAI desktop entry point. Build separately; never installs itself.
load gtk
load gtk_ext
load glib
load platform
load common
load app_window
load app_model
load ui_dispatch
load i18n
load time
load version
load remote_session

function application_root():
    executable = platform.readlink("/proc/self/exe")
    directory = common.dirname(executable)
    for candidate in [common.join(directory, "../share/luxai"), common.join(directory, ".."), "/usr/share/luxai"]:
        candidate = common.normalize(candidate)
        if exists(common.join(candidate, "data/luxai.png")):
            return candidate
        end
    end
    return "/usr/share/luxai"
end

function activated(context, application):
    # gtk_init (startup GtkApplication) nastavi tridu WM_CLASS z prgname ("Luxai"); jako Python "LuxAI"
    call __lsl_qbe_call1(__lsl_symbol("gdk_set_program_class"), platform.cstr("LuxAI"))
    if context["window"] == None or not context["window"]["alive"]:
        context["window"] = app_window.new_window(application, context["app_root"])
        call app_model.refresh_account(context["window"])
    end
    if context["window"]["widget"]:
        call gtk.window_present(context["window"]["widget"])
    end
end

function command_line(context, command, application):
    count = platform.buffer(4)
    raw = __lsl_qbe_call2(__lsl_symbol("g_application_command_line_get_arguments"), platform.pointer(command), platform.address(count))
    arguments = gtk_ext.string_vector(raw)
    mode = "agent"
    words = []
    for argument in arguments[1:]:
        if argument in ["--agent", "--chat"]:
            mode = argument[2:]
        elif not argument.startswith("--"):
            words.append(argument)
        end
    end
    call __lsl_qbe_call1(__lsl_symbol("g_application_activate"), platform.pointer(application))
    text = String(" ".join(words)).strip(common.WHITESPACE)
    if text and context["window"] != None:
        call app_window.ask(context["window"], text, mode)
    end
    return 0
end

function remote_requested():
    for index in rang(arg_count()):
        if index > 0 and arg(index) == "--remote-session":
            return True
        end
    end
    return False
end

function detach_terminal():
    # polkit (128+) povazuje dva procesy se stejnym rodicem, skupinou cgroup a ridicim terminalem za
    # jeden subjekt (jako sudo pro terminal). Spustena z terminalu by LuxAI s takovym sourozencem
    # sdilela zapamatovane heslo rezimu spravce, proto se ridiciho terminalu vzda (TIOCNOTTY).
    # Vedouci relace ne: jeho TIOCNOTTY posle SIGHUP popredi terminalu (i sobe).
    if __lsl_qbe_s32(__lsl_qbe_call1(__lsl_symbol("getsid"), 0)) == platform.getpid():
        return
    end
    # O_RDWR | O_NOCTTY | O_CLOEXEC
    handle = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("open"), platform.cstr("/dev/tty"), 524546, 0))
    if handle < 0:
        return
    end
    call __lsl_qbe_call3(__lsl_symbol("ioctl"), handle, 21538, 0)
    call __lsl_qbe_call1(__lsl_symbol("close"), handle)
end

call detach_terminal()
if remote_requested():
    # Headless mode for the LuxOS Companion bridge: no GtkApplication, so the request is
    # never forwarded to (or handled by) a running desktop instance over D-Bus.
    call __lsl_qbe_call1(__lsl_symbol("g_set_prgname"), platform.cstr("luxai"))
    call i18n.initialize(application_root())
    remote_status = remote_session.run()
    call __lsl_qbe_call1(__lsl_symbol("exit"), platform.pointer(remote_status))
end
call __lsl_qbe_call1(__lsl_symbol("g_set_prgname"), platform.cstr("luxai"))
call __lsl_qbe_call1(__lsl_symbol("g_set_application_name"), platform.cstr("LuxAI"))
call __lsl_qbe_call1(__lsl_symbol("gdk_set_program_class"), platform.cstr("LuxAI"))
root = application_root()
call i18n.initialize(root)
call ui_dispatch.initialize(3)
application = __lsl_qbe_call2(__lsl_symbol("gtk_application_new"), platform.cstr(version.APP_ID), 8)
context = {"application": application, "app_root": root, "window": None}
call gtk_ext.connect(application, "activate", activated, context)
call gtk_ext.connect(application, "command-line", command_line, context, 1)
startup_arguments = []
for index in rang(arg_count()):
    startup_arguments.append(arg(index))
end
native_arguments = glib.cstr_array(startup_arguments)
status = __lsl_qbe_call3(__lsl_symbol("g_application_run"), application, platform.pointer(len(startup_arguments)), platform.address(native_arguments))
if context["window"] != None and context["window"]["alive"]:
    call app_model.close(context["window"])
    deadline = time.monotonic() + 5
    while context["window"]["alive"] and time.monotonic() < deadline:
        call ui_dispatch.pump()
        call time.sleep(0.005)
    end
end
call ui_dispatch.drain()
call glib.object_unref(application)
call gtk_ext.collect_callbacks(None, None)
call ui_dispatch.close()
for worker in ui_dispatch.queues["threads"]:
    call thread_join(worker)
end
call __lsl_qbe_call1(__lsl_symbol("exit"), platform.pointer(status))
