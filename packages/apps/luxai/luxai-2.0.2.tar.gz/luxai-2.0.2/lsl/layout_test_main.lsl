# lsl: internal-abi
# Testovaci ovladac rozlozeni okna (jen izolovany displej): dlouha zalomena odpoved, kratka
# zprava uzivatele a rust posledni odpovedi pri streamovani. Vypise alokace radku konverzace
# a volitelne ulozi snimek okna (X11/xvfb). Nikdy neni vstupnim bodem aplikace.
load gtk
load gtk_ext
load glib
load app_window
load app_model
load ui_dispatch
load ui_widgets
load common
load i18n
load json
load time
load platform

function pump_for(seconds):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        call ui_dispatch.pump()
        call time.sleep(0.005)
    end
end

function bottom_in(widget, ancestor):
    # dolni okraj widgetu v souradnicich predka
    slot = platform.buffer(8)
    allocation = gtk.widget_get_allocation(widget)
    ok = __lsl_qbe_call6(__lsl_symbol("gtk_widget_translate_coordinates"), platform.pointer(widget), platform.pointer(ancestor), 0, platform.pointer(allocation[3]), platform.address(slot), platform.address(slot) + 4)
    if ok == 0:
        return None
    end
    return __lsl_qbe_s32(__lsl_qbe_load32(platform.address(slot) + 4))
end

function deficits(widget, output, row=None):
    if row == None:
        row = widget
    end
    # GtkExpander ma sbalene detaily uvnitr mapovaneho revealeru s alokaci 1x1.
    # Text uvnitr se nekresli a neni soucasti vysky viditelne karty.
    is_expander = __lsl_qbe_call2(__lsl_symbol("g_type_check_instance_is_a"), platform.pointer(widget), __lsl_qbe_call0(__lsl_symbol("gtk_expander_get_type"))) != 0
    if is_expander and __lsl_qbe_call1(__lsl_symbol("gtk_expander_get_expanded"), platform.pointer(widget)) == 0:
        return output
    end
    # zalomene popisky, ktere dostaly mene mista, nez potrebuji pro svou sirku (text pak pretece)
    is_label = __lsl_qbe_call2(__lsl_symbol("g_type_check_instance_is_a"), platform.pointer(widget), __lsl_qbe_call0(__lsl_symbol("gtk_label_get_type"))) != 0
    if is_label and __lsl_qbe_call1(__lsl_symbol("gtk_widget_get_mapped"), platform.pointer(widget)) != 0:
        allocation = gtk.widget_get_allocation(widget)
        slot = platform.buffer(8)
        # Samotne preferred-height muze byt prave chybne ulozene v GTK cache.
        # Pango layout je ten, ktery se opravdu kresli (vcetne zalomeni).
        layout = __lsl_qbe_call1(__lsl_symbol("gtk_label_get_layout"), platform.pointer(widget))
        call __lsl_qbe_call3(__lsl_symbol("pango_layout_get_pixel_size"), layout, platform.address(slot), platform.address(slot) + 4)
        need = __lsl_qbe_s32(__lsl_qbe_load32(platform.address(slot) + 4))
        if bottom_in(widget, row) > gtk.widget_get_allocated_height(row) + 1:
            output.append([String(gtk.label_get_text(widget))[:30], "outside row", bottom_in(widget, row), gtk.widget_get_allocated_height(row)])
        end
        if need > allocation[3] + 1:
            output.append([String(gtk.label_get_text(widget))[:30], allocation[3], need])
        end
    end
    is_container = __lsl_qbe_call2(__lsl_symbol("g_type_check_instance_is_a"), platform.pointer(widget), __lsl_qbe_call0(__lsl_symbol("gtk_container_get_type"))) != 0
    if is_container:
        for child in gtk_ext.children(widget):
            call deficits(child, output, row)
        end
    end
    return output
end

function rows(state):
    output = []
    for child in gtk_ext.children(state["column"]):
        output.append(gtk.widget_get_allocation(child))
    end
    return output
end

function row_deficits(state):
    output = []
    for child in gtk_ext.children(state["column"]):
        call deficits(child, output)
    end
    return output
end

function measure(state):
    rows_now = rows(state)
    children = gtk_ext.children(state["column"])
    last = children[len(children) - 1]
    scroll = state["scroll"]
    adjustment = state["adjustment"]
    column_alloc = gtk.widget_get_allocation(state["column"])
    missing = row_deficits(state)
    return {"deficits": missing, "rows": rows_now, "last_bottom_in_scroll": bottom_in(last, scroll), "scroll_height": gtk.widget_get_allocated_height(scroll), "column": column_alloc, "upper": gtk_ext.adjustment_get_upper(adjustment), "value": gtk_ext.adjustment_get_value(adjustment), "page": gtk_ext.adjustment_get_page_size(adjustment)}
end

function snapshot(state, path):
    if not path:
        return False
    end
    window = gtk.widget_get_window(state["widget"])
    width = gtk.widget_get_allocated_width(state["widget"])
    height = gtk.widget_get_allocated_height(state["widget"])
    pixbuf = __lsl_qbe_call5(__lsl_symbol("gdk_pixbuf_get_from_window"), platform.pointer(window), 0, 0, platform.pointer(width), platform.pointer(height))
    if pixbuf == 0:
        return False
    end
    call __lsl_qbe_call5(__lsl_symbol("gdk_pixbuf_save"), platform.pointer(pixbuf), platform.cstr(path), platform.cstr("png"), 0, 0)
    call glib.object_unref(pixbuf)
    return True
end

fixture = json.decode(readfile(arg(1)))
call gtk.init()
call i18n.initialize(fixture["app_root"], "/nonexistent", {"LANG": "en"})
call ui_dispatch.initialize(3)
state = app_window.new_window(0, fixture["app_root"], fixture.get("account"), False)
call gtk.window_resize(state["widget"], fixture.get("start_width", fixture.get("width", 850)), fixture.get("height", 700))
state["conversation"]["messages"] = fixture["messages"]
state["conversation"]["mode"] = "agent"
call app_window.render_conversation(state)
call pump_for(1.0)
if fixture.get("start_width"):
    # okno se zmensi az po vykresleni konverzace (zmena velikosti / posun postranniho panelu)
    call gtk.window_resize(state["widget"], fixture.get("width", 850), fixture.get("height", 700))
    call pump_for(1.0)
end
call app_window.scroll_end(state)
call pump_for(0.6)
result = {"static": measure(state), "shot_static": snapshot(state, fixture.get("shot_static"))}
# streamovani: nova odpoved roste po kouscich (jako stream_delta)
call app_window.handle_event(state, "stream_start", [])
for piece in fixture.get("stream", []):
    call app_window.handle_event(state, "stream_delta", [piece, ""])
    call pump_for(0.12)
end
call pump_for(0.6)
result["stream"] = measure(state)
result["shot_stream"] = snapshot(state, fixture.get("shot_stream"))
if fixture.get("tool"):
    tool = fixture["tool"]
    if fixture.get("last_piece"):
        call app_window.handle_event(state, "stream_delta", [fixture["last_piece"], ""])
    end
    message = {"role": "assistant", "content": state["bubble"]["text"]}
    # Konec textu a karta mohou prijit v jednom pruchodu hlavni smyckou.
    call app_window.handle_event(state, "stream_end", [message])
    call app_window.handle_event(state, "tool_start", ["layout-tool", "run_command", {"command": tool["command"]}])
    call app_window.handle_event(state, "tool_result", ["layout-tool", "run_command", {"ok": True, "output": tool["output"], "exit_code": 0}, "ok"])
    call pump_for(0.6)
    result["tool"] = measure(state)
    result["shot_tool"] = snapshot(state, fixture.get("shot_tool"))
    result["resized"] = []
    for width in fixture.get("resize_after_tool", []):
        call gtk.window_resize(state["widget"], width, fixture.get("height", 700))
        call pump_for(0.6)
        call app_window.scroll_end(state)
        call pump_for(0.2)
        result["resized"].append(measure(state))
    end
end
call gtk.widget_destroy(state["widget"])
call pump_for(0.2)
call ui_dispatch.close()
for worker in ui_dispatch.queues["threads"]:
    call thread_join(worker)
end
print json.encode(result)
