# Bohate bloky v odpovedich LuxAI: rozpoznani jazyka ohraniceneho bloku (```chart, ```quiz ...),
# nacteni a kontrola JSON/textu s limity. Vysledkem je normalizovany popis pro nativni
# vykresleni (rich_ui), nebo chyba, se kterou se blok zobrazi jako obycejny kod s poznamkou.
# Specifikace formatu: docs/rich-blocks.md.
load json
load common
load platform
load rich_expr

KINDS = {"svg": "svg", "chart": "chart", "quiz": "quiz", "form": "form", "controls": "form", "table": "table", "csv": "table", "mermaid": "diagram", "diagram": "diagram", "flowchart": "diagram", "math": "math", "map": "map", "gallery": "gallery", "timeline": "timeline", "checklist": "checklist"}
MAX_SOURCE = {"svg": 262144, "table": 262144, "diagram": 20000, "math": 4000}
MAX_JSON = 65536
MAX_TEXT = 300
MAX_LONG_TEXT = 2000
CHART_TYPES = {"function": "function", "functions": "function", "plot": "function", "plane": "plane", "geometry": "plane", "vectors": "plane", "bar": "bar", "column": "bar", "hbar": "hbar", "line": "line", "area": "area", "scatter": "scatter", "pie": "pie", "donut": "donut", "doughnut": "donut"}
CONTROL_TYPES = {"slider": "slider", "range": "slider", "number": "number", "toggle": "toggle", "switch": "toggle", "checkbox": "checkbox", "select": "select", "dropdown": "select", "radio": "select", "text": "text", "button": "button"}

RICH_PROMPT = json.decode("\"The LuxAI desktop app renders these fenced blocks natively (text by default; use a block only when a visual or interactive element clearly helps, at most a few per answer, never inside other code blocks). Write ```name alone on the first line, the content (valid JSON or text) on the following lines, then ``` on its own line. Block contents:\\nchart: {\\\"type\\\":\\\"bar|line|area|scatter|pie|donut\\\",\\\"title\\\":\\\"..\\\",\\\"x\\\":{\\\"categories\\\":[\\\"A\\\",\\\"B\\\"],\\\"label\\\":\\\"..\\\"},\\\"y\\\":{\\\"label\\\":\\\"..\\\",\\\"unit\\\":\\\"..\\\"},\\\"series\\\":[{\\\"name\\\":\\\"..\\\",\\\"data\\\":[1,2]}]} (line/scatter may use [[x,y],..]; \\\"stacked\\\":true)\\nchart: {\\\"type\\\":\\\"function\\\",\\\"x\\\":[-3,3],\\\"functions\\\":[{\\\"expr\\\":\\\"2*x\\\",\\\"label\\\":\\\"y = 2x\\\"}],\\\"points\\\":[[1,2,\\\"(1, 2)\\\"]]} for exact graphs of functions (expr in x, same formulas as form); {\\\"type\\\":\\\"plane\\\",\\\"vectors\\\":[{\\\"from\\\":[0,0],\\\"to\\\":[3,4],\\\"label\\\":\\\"v\\\"}],\\\"points\\\":[..],\\\"segments\\\":[{\\\"from\\\":[..],\\\"to\\\":[..]}],\\\"circles\\\":[{\\\"center\\\":[0,0],\\\"r\\\":2}],\\\"polygons\\\":[[[0,0],[2,0],[0,2]]]} for vectors and geometry (equal axes, exact coordinates). Use these for graphs, vectors and geometry, never hand-drawn SVG\\nquiz: {\\\"title\\\":\\\"..\\\",\\\"questions\\\":[{\\\"q\\\":\\\"..\\\",\\\"options\\\":[\\\"..\\\",\\\"..\\\"],\\\"correct\\\":0,\\\"explanation\\\":\\\"..\\\",\\\"hint\\\":\\\"..\\\"}]} (correct: index, or list for several answers)\\nform: {\\\"title\\\":\\\"..\\\",\\\"controls\\\":[{\\\"id\\\":\\\"loan\\\",\\\"type\\\":\\\"slider|number|toggle|checkbox|select|text\\\",\\\"label\\\":\\\"..\\\",\\\"min\\\":0,\\\"max\\\":100,\\\"step\\\":1,\\\"value\\\":50,\\\"unit\\\":\\\"..\\\"}],\\\"outputs\\\":[{\\\"label\\\":\\\"..\\\",\\\"expr\\\":\\\"loan*rate/12\\\",\\\"format\\\":\\\"0.00\\\",\\\"unit\\\":\\\"..\\\"}],\\\"submit\\\":\\\"Send to LuxAI\\\"} (expr: numbers, control ids, + - * / % ^, < > ==, a ? b : c, min max round floor ceil sqrt pow exp ln log abs clamp; select options [{\\\"label\\\":\\\"..\\\",\\\"value\\\":1}])\\ntable: CSV with a header row (sortable, exportable); normal Markdown tables are fine too\\nmermaid: flowchart TD|LR, sequenceDiagram, stateDiagram-v2, timeline or pie\\nsvg: only for illustrations that are not graphs: one small <svg viewBox=\\\"0 0 W H\\\">; compute coordinates carefully (y grows down), keep a margin of about 10 % so labels and arrowheads stay inside the viewBox, put the axes origin, grid and vectors on the same coordinates, set fill/stroke colors explicitly (no scripts, links, images; simple <style> class rules are fine)\\nmap: {\\\"title\\\":\\\"..\\\",\\\"markers\\\":[{\\\"lat\\\":50.087,\\\"lon\\\":14.421,\\\"label\\\":\\\"..\\\"}],\\\"route\\\":[[lat,lon],..]}\\ngallery: {\\\"images\\\":[{\\\"url\\\":\\\"https://..\\\",\\\"caption\\\":\\\"..\\\"}]} (only image URLs you are sure exist; the user must allow loading)\\ntimeline: {\\\"items\\\":[{\\\"date\\\":\\\"..\\\",\\\"title\\\":\\\"..\\\",\\\"text\\\":\\\"..\\\"}]}\\nchecklist: one task per line: - [ ] task\\nQuiz answers, ticks and form values are saved in the conversation; \\\"submit\\\" lets the user send the form values back to you.\"")
RICH_MATH_PROMPT = json.decode("\"The app typesets LaTeX: $...$ inline and $$...$$ (or \\\\[...\\\\]) on its own line for display math, with fractions, roots, sums, integrals and limits with bounds, sub- and superscripts, Greek letters, \\\\text, \\\\mathbb, \\\\left( \\\\right), matrices (pmatrix, bmatrix, vmatrix) and cases/aligned. Write each LaTeX command with a single backslash (\\\\\\\\frac, not \\\\\\\\\\\\\\\\frac). Never put math inside code blocks unless the user wants LaTeX source.\"")

function kind_of(language):
    # druh bohateho bloku podle jazyka za ```, jinak ""
    name = String(common.fallback(language, "")).strip().lower()
    return KINDS.get(name, "")
end

function fail(message):
    Error(RichError: message)
end

function hash_text(text):
    # FNV-1a 32 bit nad UTF-8 bajty, hex (klic pro ulozeny stav interaktivniho bloku)
    value = 2166136261
    data = platform.utf8_bytes(String(text))
    for byte in data:
        value = ((value ~ byte) * 16777619) & 4294967295
    end
    digits = "0123456789abcdef"
    output = ""
    for index in rang(8):
        output = digits[value & 15] + output
        value = value >> 4
    end
    return output
end

function relax_json(text):
    # tolerance k castym chybam modelu: koncove carky pred } a ] a komentare // mimo retezce
    output = []
    quoted = False
    escaped = False
    index = 0
    count = len(text)
    while index < count:
        char = text[index]
        if quoted:
            output.append(char)
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == "\"":
                quoted = False
            end
            index += 1
            continue
        end
        if char == "\"":
            quoted = True
            output.append(char)
            index += 1
            continue
        end
        if char == "/" and index + 1 < count and text[index + 1] == "/":
            while index < count and text[index] != "\n":
                index += 1
            end
            continue
        end
        if char == ",":
            probe = index + 1
            while probe < count and text[probe] in " \t\r\n":
                probe += 1
            end
            if probe < count and text[probe] in "]}":
                index += 1
                continue
            end
        end
        output.append(char)
        index += 1
    end
    return "".join(output)
end

function smart_quotes(text):
    # typograficke uvozovky misto JSON uvozovek (jen u struktury: za { [ , : nebo pred : , } ])
    text = platform.regex_replace("([{\\[,:]\\s*)[“”„«»]", "\\1\"", text)
    return platform.regex_replace("[“”„«»](\\s*[:,}\\]])", "\"\\1", text)
end

function balanced_prefix(text):
    # prvni uplna hodnota {...}/[...] (za ni muze byt text, kdyz model zapomnel uzavrit blok)
    depth = 0
    quoted = False
    escaped = False
    for index in rang(len(text)):
        char = text[index]
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == "\"":
                quoted = False
            end
            continue
        end
        if char == "\"":
            quoted = True
        elif char in "{[":
            depth += 1
        elif char in "}]":
            depth -= 1
            if depth == 0:
                return text[:index + 1]
            end
        end
    end
    return text
end

function repairs(source):
    first = relax_json(source)
    second = relax_json(smart_quotes(source))
    third = relax_json(balanced_prefix(smart_quotes(source)))
    return [first, second, third]
end

function decode(text):
    source = String(text).strip()
    if len(source) > MAX_JSON:
        call fail("block is too large (max " + String(MAX_JSON // 1024) + " KB)")
    end
    if not source:
        call fail("block is empty")
    end
    value = None
    try:
        value = json.decode(source)
    else:
        problem = ""
        for candidate in repairs(source):
            try:
                value = json.decode(candidate)
                return value
            else:
                if not problem:
                    problem = String(last_error())
                end
            end
        end
        if problem.startswith("JsonError: "):
            problem = problem[11:]
        end
        call fail("invalid JSON: " + problem[:160])
    end
    return value
end

function text(value, limit=300):
    if value == None:
        return ""
    end
    kind = type(value)
    if kind == "Int" or kind == "Float":
        if kind == "Float" and Float(Int(value)) == value and abs(value) < 1.0e15:
            return String(Int(value))
        end
        return String(value)
    end
    if kind == "Bool":
        if value:
            return "true"
        end
        return "false"
    end
    if kind != "String":
        return ""
    end
    return value.replace("\0", "")[:limit]
end

function is_number(value):
    kind = type(value)
    if kind == "Int":
        return True
    end
    if kind == "Float":
        return value == value and value != 1.0 / 0.0 and value != -1.0 / 0.0
    end
    return False
end

function number_or(value, default):
    if is_number(value):
        return value
    end
    if type(value) == "String":
        try:
            parsed = Float(value.strip().replace(",", "."))
            if is_number(parsed):
                return parsed
            end
        else:
            return default
        end
    end
    return default
end

function boolean(value, default=False):
    if type(value) == "Bool":
        return value
    end
    if value == None:
        return default
    end
    if is_number(value):
        return value != 0
    end
    if type(value) == "String":
        return value.strip().lower() in ["true", "yes", "1", "on"]
    end
    return default
end

function first_key(data, names, default=None):
    for name in names:
        if name in data and data[name] != None:
            return data[name]
        end
    end
    return default
end

function list_of(value, limit, what):
    if value == None:
        return []
    end
    if type(value) != "List":
        call fail(what + " must be a list")
    end
    if len(value) > limit:
        call fail("too many " + what + " (max " + String(limit) + ")")
    end
    return value
end

function color(value):
    # jen #rgb / #rrggbb (zadne url(), nazvy barev resi paleta)
    if type(value) == "String" and platform.regex_test("^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$", value.strip()):
        return value.strip()
    end
    return ""
end

function identifier(value):
    return type(value) == "String" and platform.regex_test("^[A-Za-z_][A-Za-z0-9_]{0,39}$", value)
end

# ---------------------------------------------------------------- chart

function chart(data):
    if type(data) == "List":
        data = {"type": "bar", "data": data}
    end
    if type(data) != "Dictionary":
        call fail("chart must be a JSON object")
    end
    kind = CHART_TYPES.get(text(first_key(data, ["type", "kind"], "bar")).lower())
    if kind == None:
        call fail("unknown chart type (use bar, line, area, scatter, pie, donut, function or plane)")
    end
    if kind in ["function", "plane"]:
        return plot(data, kind)
    end
    if boolean(data.get("horizontal")) and kind == "bar":
        kind = "hbar"
    end
    axis_x = data.get("x")
    axis_y = data.get("y")
    if type(axis_x) != "Dictionary":
        axis_x = {}
    end
    if type(axis_y) != "Dictionary":
        axis_y = {}
    end
    categories = []
    for item in list_of(first_key(axis_x, ["categories", "labels"], first_key(data, ["categories", "labels"])), 1000, "categories"):
        categories.append(text(item, 80))
    end
    series_source = data.get("series")
    if series_source == None and type(data.get("data")) == "List":
        rows = data["data"]
        if rows and type(rows[0]) == "Dictionary":
            # [{"label": "A", "value": 3}, ...]
            values = []
            labels = []
            for row in list_of(rows, 1000, "data points"):
                if type(row) != "Dictionary":
                    call fail("data points must be objects")
                end
                labels.append(text(first_key(row, ["label", "name", "x", "category"], ""), 80))
                values.append(first_key(row, ["value", "y", "count"]))
            end
            if not categories:
                categories = labels
            end
            series_source = [{"name": text(data.get("name", "")), "data": values}]
        else:
            series_source = [{"name": text(data.get("name", "")), "data": rows}]
        end
    end
    if series_source == None and type(data.get("slices")) == "List":
        values = []
        labels = []
        for row in list_of(data["slices"], 200, "slices"):
            if type(row) == "Dictionary":
                labels.append(text(first_key(row, ["label", "name"], ""), 80))
                values.append(row.get("value"))
            end
        end
        categories = labels
        series_source = [{"name": "", "data": values}]
    end
    series = []
    total = 0
    numeric_x = False
    for item in list_of(series_source, 12, "series"):
        if type(item) == "List":
            item = {"data": item}
        end
        if type(item) != "Dictionary":
            call fail("each series must be an object with data")
        end
        values = []
        points = []
        for value in list_of(first_key(item, ["data", "values"], []), 5000, "data points"):
            total += 1
            if type(value) == "List" and len(value) >= 2:
                x = number_or(value[0], None)
                y = number_or(value[1], None)
                if x != None and y != None:
                    points.append([x, y])
                end
            elif type(value) == "Dictionary" and "x" in value and "y" in value:
                x = number_or(value["x"], None)
                y = number_or(value["y"], None)
                if x != None and y != None:
                    points.append([x, y])
                end
            else:
                values.append(number_or(value, None))
            end
        end
        if points:
            numeric_x = True
        end
        series.append({"name": text(first_key(item, ["name", "label"], ""), 80), "values": values, "points": points, "color": color(item.get("color"))})
    end
    if total > 5000:
        call fail("too many data points (max 5000)")
    end
    if not series:
        call fail("chart has no series")
    end
    count = 0
    for item in series:
        count += len(item["points"])
        for value in item["values"]:
            if value != None:
                count += 1
            end
        end
    end
    if count == 0:
        call fail("chart has no numeric values")
    end
    if numeric_x and kind in ["bar", "hbar", "pie", "donut"]:
        call fail(kind + " chart needs values with categories, not [x, y] pairs")
    end
    if kind in ["pie", "donut"]:
        for value in series[0]["values"]:
            if value != None and value < 0:
                call fail("pie values must not be negative")
            end
        end
    end
    result = {"type": kind, "title": text(data.get("title")), "categories": categories, "series": series, "numeric_x": numeric_x}
    result["x_label"] = text(first_key(axis_x, ["label", "title"], data.get("x_label")))
    result["y_label"] = text(first_key(axis_y, ["label", "title"], data.get("y_label")))
    result["y_min"] = number_or(axis_y.get("min"), None)
    result["y_max"] = number_or(axis_y.get("max"), None)
    if result["y_min"] != None and result["y_max"] != None and result["y_min"] >= result["y_max"]:
        result["y_min"] = None
        result["y_max"] = None
    end
    result["unit"] = text(first_key(axis_y, ["unit"], data.get("unit")), 16)
    result["stacked"] = boolean(data.get("stacked"))
    return result
end

# ---------------------------------------------------------------- souradnicova rovina (function, plane)
# Presne grafy funkci a geometrie: funkce se vycisli bezpecnym vyhodnocovacem (promenna x),
# body, vektory, usecky, kruznice a mnohouhelniky jsou v souradnicich roviny (ne v pixelech),
# takze bod (1, 2) lezi presne na primce y = 2x. "plane" ma vychozi stejne meritko os.

PLOT_SAMPLES = 400

function pair(value, what):
    if type(value) == "List" and len(value) >= 2:
        x = number_or(value[0], None)
        y = number_or(value[1], None)
        if x != None and y != None:
            return [Float(x), Float(y)]
        end
    elif type(value) == "Dictionary":
        x = number_or(value.get("x"), None)
        y = number_or(value.get("y"), None)
        if x != None and y != None:
            return [Float(x), Float(y)]
        end
    end
    call fail(what + " needs [x, y] numbers")
end

function axis_range(value):
    # [a, b], {"min", "max", "label"} nebo None -> [min, max, popisek]
    if type(value) == "List" and len(value) >= 2:
        low = number_or(value[0], None)
        high = number_or(value[1], None)
        if low != None and high != None and high > low:
            return [Float(low), Float(high), ""]
        end
        call fail("axis range must be [min, max] with min < max")
    elif type(value) == "Dictionary":
        low = number_or(value.get("min"), None)
        high = number_or(value.get("max"), None)
        if low != None and high != None and high <= low:
            call fail("axis range must have min < max")
        end
        result = [None, None, text(value.get("label"), 40)]
        if low != None:
            result[0] = Float(low)
        end
        if high != None:
            result[1] = Float(high)
        end
        return result
    end
    return [None, None, ""]
end

function sample_function(tree, low, high, count):
    # useky krivky [[x, y] ...]; chyba nebo nekonecno = mezera
    segments = []
    current = []
    for i in rang(count + 1):
        x = low + (high - low) * i / count
        y = None
        try:
            value = rich_expr.evaluate(tree, {"x": x})
            if is_number(value):
                y = Float(value)
            elif type(value) == "Bool":
                y = None
            end
        else:
            y = None
        end
        if y == None or abs(y) > 1.0e12:
            if len(current) > 1:
                segments.append(current)
            end
            current = []
        else:
            current.append([x, y])
        end
    end
    if len(current) > 1:
        segments.append(current)
    end
    return segments
end

function plot(data, kind):
    axis_x = axis_range(first_key(data, ["x", "x_range", "domain"]))
    axis_y = axis_range(first_key(data, ["y", "y_range", "range"]))
    if type(data.get("x")) == "Dictionary" and not axis_x[2]:
        axis_x[2] = text(data["x"].get("label"), 40)
    end
    result = {"type": kind, "title": text(data.get("title")), "functions": [], "points": [], "vectors": [], "segments": [], "circles": [], "polygons": []}
    result["grid"] = boolean(data.get("grid"), True)
    result["equal"] = boolean(first_key(data, ["equal", "equal_aspect", "aspect_equal"]), kind == "plane")
    result["x_label"] = common.fallback(axis_x[2], "x")
    result["y_label"] = common.fallback(axis_y[2], "y")
    if not axis_x[2] and type(data.get("x_label")) == "String":
        result["x_label"] = text(data["x_label"], 40)
    end
    if not axis_y[2] and type(data.get("y_label")) == "String":
        result["y_label"] = text(data["y_label"], 40)
    end
    xs = []
    ys = []
    for item in list_of(data.get("points"), 200, "points"):
        label = ""
        color_value = ""
        if type(item) == "List" and len(item) > 2:
            label = text(item[2], 80)
        elif type(item) == "Dictionary":
            label = text(item.get("label"), 80)
            color_value = color(item.get("color"))
        end
        point = pair(item, "point")
        result["points"].append({"at": point, "label": label, "color": color_value})
        xs.append(point[0])
        ys.append(point[1])
    end
    for item in list_of(first_key(data, ["vectors", "arrows"]), 50, "vectors"):
        start = [0.0, 0.0]
        stop = None
        label = ""
        color_value = ""
        if type(item) == "Dictionary" and ("to" in item or "from" in item):
            if item.get("from") != None:
                start = pair(item["from"], "vector")
            end
            stop = pair(item.get("to"), "vector")
            label = text(item.get("label"), 80)
            color_value = color(item.get("color"))
        else:
            stop = pair(item, "vector")
            if type(item) == "Dictionary":
                label = text(item.get("label"), 80)
                color_value = color(item.get("color"))
            elif type(item) == "List" and len(item) > 2:
                label = text(item[2], 80)
            end
        end
        result["vectors"].append({"from": start, "to": stop, "label": label, "color": color_value})
        xs.extend([start[0], stop[0]])
        ys.extend([start[1], stop[1]])
    end
    for item in list_of(first_key(data, ["segments", "lines"]), 100, "segments"):
        if type(item) != "Dictionary":
            call fail("segments need {\"from\": [x, y], \"to\": [x, y]}")
        end
        a = pair(item.get("from"), "segment")
        b = pair(item.get("to"), "segment")
        result["segments"].append({"from": a, "to": b, "label": text(item.get("label"), 80), "color": color(item.get("color")), "dashed": boolean(item.get("dashed"))})
        xs.extend([a[0], b[0]])
        ys.extend([a[1], b[1]])
    end
    for item in list_of(data.get("circles"), 50, "circles"):
        if type(item) != "Dictionary":
            call fail("circles need {\"center\": [x, y], \"r\": radius}")
        end
        center = pair(item.get("center"), "circle")
        radius = number_or(first_key(item, ["r", "radius"]), None)
        if radius == None or radius <= 0:
            call fail("circle radius must be a positive number")
        end
        result["circles"].append({"center": center, "r": Float(radius), "label": text(item.get("label"), 80), "color": color(item.get("color"))})
        xs.extend([center[0] - radius, center[0] + radius])
        ys.extend([center[1] - radius, center[1] + radius])
    end
    for item in list_of(data.get("polygons"), 20, "polygons"):
        source = item
        label = ""
        color_value = ""
        if type(item) == "Dictionary":
            source = item.get("points")
            label = text(item.get("label"), 80)
            color_value = color(item.get("color"))
        end
        vertices = []
        for vertex in list_of(source, 100, "polygon points"):
            point = pair(vertex, "polygon point")
            vertices.append(point)
            xs.append(point[0])
            ys.append(point[1])
        end
        if len(vertices) < 2:
            call fail("polygon needs at least 2 points")
        end
        result["polygons"].append({"points": vertices, "label": label, "color": color_value})
    end
    sources = list_of(first_key(data, ["functions", "function", "expr"]), 8, "functions")
    if type(first_key(data, ["functions", "function", "expr"])) == "String":
        sources = [first_key(data, ["functions", "function", "expr"])]
    end
    # rozsah x: zadany, jinak z objektu, jinak -10..10
    low = axis_x[0]
    high = axis_x[1]
    if low == None or high == None:
        if xs:
            span = max(xs + [0.0]) - min(xs + [0.0])
            margin = max(span * 0.12, 0.5)
            if low == None:
                low = min(xs + [0.0]) - margin
            end
            if high == None:
                high = max(xs + [0.0]) + margin
            end
        else:
            if low == None:
                low = -10.0
            end
            if high == None:
                high = 10.0
            end
        end
    end
    if high <= low:
        high = low + 1.0
    end
    for item in sources:
        formula = ""
        label = ""
        color_value = ""
        dashed = False
        if type(item) == "String":
            formula = item
        elif type(item) == "Dictionary":
            formula = text(first_key(item, ["expr", "f", "y", "formula"], ""), rich_expr.MAX_LENGTH + 1)
            label = text(first_key(item, ["label", "name"], ""), 80)
            color_value = color(item.get("color"))
            dashed = boolean(item.get("dashed"))
        else:
            call fail("functions must be formulas like \"2*x\" or {\"expr\": \"2*x\"}")
        end
        formula = platform.regex_replace("^\\s*(?:y|f\\s*\\(\\s*x\\s*\\))\\s*=\\s*", "", formula)
        tree = None
        try:
            tree = rich_expr.parse(formula)
        else:
            problem = String(last_error())
            if problem.startswith("ExprError: "):
                problem = problem[11:]
            end
            call fail("function " + formula[:40] + ": " + problem)
        end
        for name in rich_expr.variables(tree):
            if name != "x":
                call fail("function " + formula[:40] + ": only the variable x is allowed (unknown name " + name + ")")
            end
        end
        if not label:
            label = "y = " + formula
        end
        segments = sample_function(tree, low, high, PLOT_SAMPLES)
        result["functions"].append({"expr": formula, "label": label, "color": color_value, "dashed": dashed, "segments": segments})
        for segment in segments:
            for point in segment:
                ys.append(point[1])
            end
        end
    end
    if not result["functions"] and not xs:
        call fail("plot has nothing to draw (functions, points, vectors, segments, circles or polygons)")
    end
    bottom = axis_y[0]
    top = axis_y[1]
    if bottom == None or top == None:
        # robustni rozsah y: krajni hodnoty krivek u asymptot (tan, 1/x) nerozbiji meritko
        values = ys + [0.0]
        values.sort()
        a = values[len(values) // 50]
        b = values[len(values) - 1 - len(values) // 50]
        for point in result["points"]:
            a = min(a, point["at"][1])
            b = max(b, point["at"][1])
        end
        span = max(b - a, 1.0e-9)
        margin = max(span * 0.1, 0.5)
        if bottom == None:
            bottom = a - margin
        end
        if top == None:
            top = b + margin
        end
    end
    if top <= bottom:
        top = bottom + 1.0
    end
    result["x_range"] = [low, high]
    result["y_range"] = [bottom, top]
    return result
end

# ---------------------------------------------------------------- quiz

function option_index(options, value):
    if type(value) == "Int" or (type(value) == "Float" and Float(Int(value)) == value):
        index = Int(value)
        if 0 <= index and index < len(options):
            return index
        end
        return -1
    end
    if type(value) == "String":
        wanted = value.strip()
        for index in rang(len(options)):
            if options[index] == wanted:
                return index
            end
        end
        # "B" jako pismeno moznosti
        letters = "ABCDEFGHIJ"
        if len(wanted) == 1 and wanted.upper() in letters and letters.find(wanted.upper()) < len(options):
            return letters.find(wanted.upper())
        end
    end
    return -1
end

function question(data, number):
    if type(data) != "Dictionary":
        call fail("question " + String(number) + " must be an object")
    end
    prompt = text(first_key(data, ["q", "question", "text", "title"], ""), MAX_LONG_TEXT)
    if not prompt:
        call fail("question " + String(number) + " has no text")
    end
    options = []
    for item in list_of(first_key(data, ["options", "choices", "answers"], []), 10, "options"):
        if type(item) == "Dictionary":
            options.append(text(first_key(item, ["text", "label"], ""), 500))
        else:
            options.append(text(item, 500))
        end
    end
    if len(options) < 2:
        call fail("question " + String(number) + " needs at least 2 options")
    end
    raw = first_key(data, ["correct", "answer", "answers_correct"])
    values = raw
    if type(raw) != "List":
        values = [raw]
    end
    correct = []
    for value in values:
        index = option_index(options, value)
        if index < 0:
            call fail("question " + String(number) + " has an invalid correct answer")
        end
        if index not in correct:
            correct.append(index)
        end
    end
    if not correct:
        call fail("question " + String(number) + " has no correct answer")
    end
    correct.sort()
    multiple = boolean(data.get("multiple"), len(correct) > 1) or len(correct) > 1
    return {"q": prompt, "options": options, "correct": correct, "multiple": multiple, "explanation": text(first_key(data, ["explanation", "explain", "why"], ""), MAX_LONG_TEXT), "hint": text(data.get("hint"), 500)}
end

function quiz(data):
    if type(data) == "List":
        data = {"questions": data}
    end
    if type(data) != "Dictionary":
        call fail("quiz must be a JSON object")
    end
    source = data.get("questions")
    if source == None and first_key(data, ["q", "question"]) != None:
        source = [data]
    end
    questions = []
    number = 1
    for item in list_of(source, 50, "questions"):
        questions.append(question(item, number))
        number += 1
    end
    if not questions:
        call fail("quiz has no questions")
    end
    return {"title": text(data.get("title")), "shuffle": boolean(data.get("shuffle")), "questions": questions}
end

# ---------------------------------------------------------------- form / controls

function control(data, seen):
    if type(data) != "Dictionary":
        call fail("each control must be an object")
    end
    kind = CONTROL_TYPES.get(text(data.get("type", "slider")).lower())
    if kind == None:
        call fail("unknown control type " + text(data.get("type"), 40))
    end
    ident = data.get("id", data.get("name"))
    if kind != "button":
        if not identifier(ident):
            call fail("control id must be a short name like loan_amount")
        end
        if ident in seen or ident in ["pi", "e", "true", "false", "and", "or", "not"]:
            call fail("duplicate or reserved control id " + ident)
        end
        call seen.append(ident)
    elif not identifier(ident):
        ident = ""
    end
    result = {"id": ident, "type": kind, "label": text(first_key(data, ["label", "title"], ident), 200), "unit": text(data.get("unit"), 16), "help": text(first_key(data, ["help", "hint"], ""), 300)}
    if kind == "slider" or kind == "number":
        low = number_or(data.get("min"), 0)
        high = number_or(data.get("max"), 100)
        if high <= low:
            call fail("control " + ident + ": max must be greater than min")
        end
        step = number_or(data.get("step"), None)
        if step == None or step <= 0:
            step = 1
            if high - low <= 10 and (type(low) == "Float" or type(high) == "Float"):
                step = 0.1
            end
        end
        if (high - low) / step > 1000000:
            step = (high - low) / 1000000
        end
        value = number_or(data.get("value", data.get("default")), low)
        result["min"] = low
        result["max"] = high
        result["step"] = step
        result["value"] = max(low, min(high, value))
    elif kind == "toggle" or kind == "checkbox":
        result["value"] = boolean(data.get("value", data.get("default")))
    elif kind == "select":
        options = []
        for item in list_of(data.get("options"), 50, "options"):
            if type(item) == "Dictionary":
                value = item.get("value", item.get("label"))
                if not (is_number(value) or type(value) == "String" or type(value) == "Bool"):
                    value = text(value)
                end
                options.append({"label": text(first_key(item, ["label", "value"], ""), 120), "value": value})
            elif is_number(item) or type(item) == "String":
                options.append({"label": text(item, 120), "value": item})
            end
        end
        if not options:
            call fail("control " + ident + " needs options")
        end
        result["options"] = options
        result["value"] = options[0]["value"]
        wanted = data.get("value", data.get("default"))
        for option in options:
            if wanted != None and option["value"] == wanted:
                result["value"] = wanted
            end
        end
        result["radio"] = text(data.get("type")).lower() == "radio"
    elif kind == "text":
        result["value"] = text(data.get("value", data.get("default")), 500)
        result["placeholder"] = text(data.get("placeholder"), 120)
    elif kind == "button":
        action = text(data.get("action", "send")).lower()
        if action not in ["send", "reset"]:
            call fail("button action must be send or reset")
        end
        result["action"] = action
    end
    return result
end

function form(data):
    if type(data) != "Dictionary":
        call fail("form must be a JSON object")
    end
    seen = []
    controls = []
    for item in list_of(first_key(data, ["controls", "fields", "inputs"], []), 40, "controls"):
        controls.append(control(item, seen))
    end
    if not controls:
        call fail("form has no controls")
    end
    outputs = []
    for item in list_of(first_key(data, ["outputs", "results", "computed"], []), 20, "outputs"):
        if type(item) != "Dictionary":
            call fail("each output must be an object with expr")
        end
        formula = text(first_key(item, ["expr", "formula", "value"], ""), rich_expr.MAX_LENGTH + 1)
        problem = None
        try:
            tree = rich_expr.parse(formula)
            for name in rich_expr.variables(tree):
                if name not in seen:
                    problem = "unknown name " + name
                end
            end
        else:
            problem = String(last_error())
            if problem.startswith("ExprError: "):
                problem = problem[11:]
            end
        end
        outputs.append({"label": text(first_key(item, ["label", "title"], ""), 200), "expr": formula, "format": text(item.get("format"), 16), "unit": text(item.get("unit"), 16), "error": problem})
    end
    submit = data.get("submit", data.get("send"))
    label = ""
    if submit == True:
        label = "Send to LuxAI"
    elif type(submit) == "String":
        label = text(submit, 60)
    end
    for item in controls:
        if item["type"] == "button" and item["action"] == "send" and not label:
            label = item["label"]
        end
    end
    return {"title": text(data.get("title")), "description": text(first_key(data, ["description", "text"], ""), MAX_LONG_TEXT), "controls": controls, "outputs": outputs, "submit": label}
end

# ---------------------------------------------------------------- table

function csv_rows(source):
    # CSV (carka/strednik) nebo TSV s uvozovkami "" podle RFC 4180
    lines = source.replace("\r\n", "\n").replace("\r", "\n")
    first = lines.split("\n")[0]
    separator = ","
    if first.count("\t") > first.count(",") and first.count("\t") > 0:
        separator = "\t"
    elif first.count(";") > first.count(","):
        separator = ";"
    end
    rows = []
    row = []
    cell = []
    quoted = False
    index = 0
    count = len(lines)
    while index < count:
        char = lines[index]
        if quoted:
            if char == "\"":
                if index + 1 < count and lines[index + 1] == "\"":
                    cell.append("\"")
                    index += 1
                else:
                    quoted = False
                end
            else:
                cell.append(char)
            end
        elif char == "\"" and not cell:
            quoted = True
        elif char == separator:
            row.append("".join(cell).strip())
            cell = []
        elif char == "\n":
            row.append("".join(cell).strip())
            cell = []
            if len(row) > 1 or row[0]:
                rows.append(row)
            end
            row = []
            if len(rows) > 2001:
                call fail("too many table rows (max 2000)")
            end
        else:
            cell.append(char)
        end
        index += 1
    end
    if cell or row:
        row.append("".join(cell).strip())
        rows.append(row)
    end
    return rows
end

function table(source):
    stripped = String(source).strip()
    columns = []
    rows = []
    title = ""
    if stripped.startswith("{") or stripped.startswith("["):
        data = decode(stripped)
        if type(data) == "List":
            data = {"rows": data}
        end
        if type(data) != "Dictionary":
            call fail("table must be a JSON object")
        end
        title = text(data.get("title"))
        for item in list_of(first_key(data, ["columns", "header", "headers"], []), 50, "columns"):
            if type(item) == "Dictionary":
                columns.append(text(first_key(item, ["label", "name", "title"], ""), 120))
            else:
                columns.append(text(item, 120))
            end
        end
        source_rows = list_of(first_key(data, ["rows", "data"], []), 2000, "rows")
        if source_rows and type(source_rows[0]) == "Dictionary" and not columns:
            for key in source_rows[0].keys():
                if len(columns) < 50:
                    columns.append(text(key, 120))
                end
            end
        end
        for item in source_rows:
            cells = []
            if type(item) == "Dictionary":
                for key in columns:
                    cells.append(cell_value(item.get(key)))
                end
            elif type(item) == "List":
                for value in item[:50]:
                    cells.append(cell_value(value))
                end
            else:
                cells.append(cell_value(item))
            end
            rows.append(cells)
        end
    else:
        parsed = csv_rows(stripped)
        if not parsed:
            call fail("table is empty")
        end
        for item in parsed:
            if len(item) > 50:
                call fail("too many table columns (max 50)")
            end
        end
        for value in parsed[0][:50]:
            columns.append(value[:120])
        end
        for item in parsed[1:]:
            cells = []
            for value in item[:50]:
                cells.append(value[:1000])
            end
            rows.append(cells)
        end
    end
    width = len(columns)
    for row in rows:
        width = max(width, len(row))
    end
    if width == 0:
        call fail("table has no columns")
    end
    if width > 50:
        call fail("too many table columns (max 50)")
    end
    while len(columns) < width:
        columns.append("")
    end
    for row in rows:
        while len(row) < width:
            row.append("")
        end
    end
    return {"title": title, "columns": columns, "rows": rows}
end

function cell_value(value):
    if value == None:
        return ""
    end
    if type(value) in ["List", "Dictionary"]:
        return String(json.encode(value))[:1000]
    end
    return text(value, 1000)
end

# ---------------------------------------------------------------- map

function coordinate(value, what):
    latitude = None
    longitude = None
    label = ""
    if type(value) == "List" and len(value) >= 2:
        latitude = number_or(value[0], None)
        longitude = number_or(value[1], None)
        if len(value) > 2:
            label = text(value[2], 120)
        end
    elif type(value) == "Dictionary":
        latitude = number_or(first_key(value, ["lat", "latitude"]), None)
        longitude = number_or(first_key(value, ["lon", "lng", "longitude"]), None)
        label = text(first_key(value, ["label", "name", "title"], ""), 120)
    end
    if latitude == None or longitude == None or latitude < -85.05 or latitude > 85.05 or longitude < -180 or longitude > 180:
        call fail(what + " needs a valid latitude and longitude")
    end
    return {"lat": Float(latitude), "lon": Float(longitude), "label": label}
end

function map_block(data):
    if type(data) != "Dictionary":
        call fail("map must be a JSON object")
    end
    markers = []
    for item in list_of(first_key(data, ["markers", "places", "points"], []), 50, "markers"):
        markers.append(coordinate(item, "marker"))
    end
    route = []
    for item in list_of(data.get("route"), 2000, "route points"):
        route.append(coordinate(item, "route point"))
    end
    center = None
    if data.get("center") != None:
        center = coordinate(data["center"], "center")
    end
    if center == None and not markers and not route:
        call fail("map needs a center, markers or a route")
    end
    zoom = number_or(data.get("zoom"), None)
    if zoom != None:
        zoom = max(1, min(18, Int(zoom)))
    end
    return {"title": text(data.get("title")), "center": center, "zoom": zoom, "markers": markers, "route": route}
end

# ---------------------------------------------------------------- gallery

function safe_url(value):
    url = text(value, 2000).strip()
    if not platform.regex_test("(?i)^https?://[^\\s/@]+(/[^\\s]*)?$", url):
        return ""
    end
    return url
end

function gallery(data):
    if type(data) == "List":
        data = {"images": data}
    end
    if type(data) != "Dictionary":
        call fail("gallery must be a JSON object")
    end
    images = []
    for item in list_of(first_key(data, ["images", "items"], []), 20, "images"):
        url = ""
        caption = ""
        if type(item) == "String":
            url = safe_url(item)
        elif type(item) == "Dictionary":
            url = safe_url(first_key(item, ["url", "src", "image"], ""))
            caption = text(first_key(item, ["caption", "title", "alt"], ""), 300)
        end
        if not url:
            call fail("gallery images need http(s) URLs")
        end
        images.append({"url": url, "caption": caption})
    end
    if not images:
        call fail("gallery has no images")
    end
    return {"title": text(data.get("title")), "images": images}
end

# ---------------------------------------------------------------- timeline, checklist

function timeline(source):
    stripped = String(source).strip()
    items = []
    title = ""
    if stripped.startswith("{") or stripped.startswith("["):
        data = decode(stripped)
        if type(data) == "List":
            data = {"items": data}
        end
        if type(data) != "Dictionary":
            call fail("timeline must be a JSON object")
        end
        title = text(data.get("title"))
        for item in list_of(first_key(data, ["items", "events"], []), 100, "timeline items"):
            if type(item) != "Dictionary":
                call fail("timeline items must be objects")
            end
            items.append({"date": text(first_key(item, ["date", "time", "when", "year"], ""), 60), "title": text(first_key(item, ["title", "event", "name"], ""), 200), "text": text(first_key(item, ["text", "description", "detail"], ""), MAX_LONG_TEXT)})
        end
    else:
        for line in stripped.split("\n"):
            line = line.strip()
            if not line:
                continue
            end
            if line.lower().startswith("title ") or line.lower().startswith("title:"):
                title = line[6:].strip()
                continue
            end
            found = platform.regex_findall("^[-*]?\\s*([^:–—-]{1,40}?)\\s*(?::|–|—| - )\\s*(.+)$", line)
            if found:
                items.append({"date": found[0]["groups"][1], "title": found[0]["groups"][2][:200], "text": ""})
            else:
                items.append({"date": "", "title": line[:200], "text": ""})
            end
            if len(items) > 100:
                call fail("too many timeline items (max 100)")
            end
        end
    end
    if not items:
        call fail("timeline has no items")
    end
    return {"title": title, "items": items}
end

function checklist(source):
    stripped = String(source).strip()
    items = []
    title = ""
    if stripped.startswith("{") or stripped.startswith("["):
        data = decode(stripped)
        if type(data) == "List":
            data = {"items": data}
        end
        if type(data) != "Dictionary":
            call fail("checklist must be a JSON object")
        end
        title = text(data.get("title"))
        for item in list_of(first_key(data, ["items", "tasks"], []), 200, "checklist items"):
            if type(item) == "Dictionary":
                items.append({"text": text(first_key(item, ["text", "title", "label"], ""), 500), "done": boolean(first_key(item, ["done", "checked"], False))})
            else:
                items.append({"text": text(item, 500), "done": False})
            end
        end
    else:
        for line in stripped.split("\n"):
            line = line.strip()
            if not line:
                continue
            end
            found = platform.regex_findall("^(?:[-*+]|\\d+[.)])?\\s*\\[([ xX✓])\\]\\s*(.*)$", line)
            if found:
                items.append({"text": found[0]["groups"][2][:500], "done": found[0]["groups"][1] != " "})
            else:
                if line.startswith("#"):
                    title = line.lstrip("#").strip()[:MAX_TEXT]
                    continue
                end
                items.append({"text": platform.regex_replace("^(?:[-*+]|\\d+[.)])\\s+", "", line)[:500], "done": False})
            end
            if len(items) > 200:
                call fail("too many checklist items (max 200)")
            end
        end
    end
    clean = []
    for item in items:
        if item["text"]:
            clean.append(item)
        end
    end
    if not clean:
        call fail("checklist has no items")
    end
    return {"title": title, "items": clean}
end

# ---------------------------------------------------------------- vstup

function parse(kind, source):
    # {"ok": True, "kind", "spec"} nebo {"ok": False, "kind", "error"}; nikdy nevyhodi vyjimku
    source = String(common.fallback(source, ""))
    limit = MAX_SOURCE.get(kind, MAX_JSON)
    if len(source) > limit:
        return {"ok": False, "kind": kind, "error": "block is too large (max " + String(limit // 1024) + " KB)"}
    end
    try:
        spec = None
        if kind == "chart":
            spec = chart(decode(source))
        elif kind == "quiz":
            spec = quiz(decode(source))
        elif kind == "form":
            spec = form(decode(source))
        elif kind == "table":
            spec = table(source)
        elif kind == "map":
            spec = map_block(decode(source))
        elif kind == "gallery":
            spec = gallery(decode(source))
        elif kind == "timeline":
            spec = timeline(source)
        elif kind == "checklist":
            spec = checklist(source)
        elif kind == "diagram" or kind == "math" or kind == "svg":
            if not source.strip():
                call fail("block is empty")
            end
            spec = {"source": source}
        else:
            call fail("unknown block type")
        end
        return {"ok": True, "kind": kind, "spec": spec}
    else:
        problem = String(last_error())
        for prefix in ["RichError: ", "ExprError: "]:
            if problem.startswith(prefix):
                problem = problem[len(prefix):]
            end
        end
        if problem.startswith("TypeError") or problem.startswith("KeyError") or problem.startswith("IndexError") or problem.startswith("ValueError"):
            problem = "unsupported block content"
        end
        return {"ok": False, "kind": kind, "error": problem}
    end
end
