# Bezpecny vyhodnocovac jednoduchych vzorcu pro bloky ```form/```controls (vypoctene vystupy).
# Zadne spousteni kodu: vlastni tokenizer, rekurzivni sestupny parser do stromu a vyhodnoceni
# jen nad cisly, pravdivostnimi hodnotami a texty. Promenne jsou jen hodnoty ovladacich prvku.
#
#   tree = rich_expr.parse("p * r / 12")          chyba -> Error(ExprError: ...)
#   value = rich_expr.evaluate(tree, {"p": 1000, "r": 0.05})
#   text = rich_expr.format_value(value, "0.00")
#
# Operatory: + - * / % ^ (mocnina), unarni - + !, < <= > >= == !=, && || (i and/or/not), c ? a : b
# Funkce: abs min max round floor ceil sqrt pow exp ln log log10 sin cos tan clamp if sum avg
# Konstanty: pi, e, true, false. Limity: delka 500 znaku, 200 tokenu, hloubka 32, 20 000 kroku.
load math
load common

MAX_LENGTH = 500
MAX_TOKENS = 200
MAX_DEPTH = 32
MAX_STEPS = 20000
FUNCTIONS = {"abs": [1, 1], "min": [1, 20], "max": [1, 20], "round": [1, 2], "floor": [1, 1], "ceil": [1, 1], "sqrt": [1, 1], "pow": [2, 2], "exp": [1, 1], "ln": [1, 1], "log": [1, 2], "log10": [1, 1], "sin": [1, 1], "cos": [1, 1], "tan": [1, 1], "clamp": [3, 3], "if": [3, 3], "sum": [1, 20], "avg": [1, 20]}
DIGITS = "0123456789"
NAME_START = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_"
NAME_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789"

function fail(message):
    Error(ExprError: message)
end

function tokenize(text):
    source = String(text)
    if len(source) > MAX_LENGTH:
        call fail("formula is too long")
    end
    tokens = []
    index = 0
    count = len(source)
    while index < count:
        char = source[index]
        if char in " \t\r\n":
            index += 1
            continue
        end
        if len(tokens) >= MAX_TOKENS:
            call fail("formula is too long")
        end
        if char in DIGITS or (char == "." and index + 1 < count and source[index + 1] in DIGITS):
            start = index
            while index < count and (source[index] in DIGITS or source[index] == "."):
                index += 1
            end
            if index < count and source[index] in "eE":
                probe = index + 1
                if probe < count and source[probe] in "+-":
                    probe += 1
                end
                if probe < count and source[probe] in DIGITS:
                    index = probe
                    while index < count and source[index] in DIGITS:
                        index += 1
                    end
                end
            end
            literal = source[start:index]
            if literal.count(".") > 1:
                call fail("invalid number " + literal)
            end
            number = 0
            try:
                if "." in literal or "e" in literal or "E" in literal:
                    number = Float(literal)
                else:
                    number = Int(literal)
                    if len(literal) > 15:
                        number = Float(literal)
                    end
                end
            else:
                call fail("invalid number " + literal)
            end
            tokens.append(["num", number])
            continue
        end
        if char in NAME_START:
            start = index
            while index < count and source[index] in NAME_CHARS:
                index += 1
            end
            word = source[start:index]
            if word == "and":
                tokens.append(["op", "&&"])
            elif word == "or":
                tokens.append(["op", "||"])
            elif word == "not":
                tokens.append(["op", "!"])
            else:
                tokens.append(["name", word])
            end
            continue
        end
        if char == "\"" or char == "'":
            quote = char
            index += 1
            parts = []
            closed = False
            while index < count:
                current = source[index]
                if current == "\\" and index + 1 < count:
                    parts.append(source[index + 1])
                    index += 2
                    continue
                end
                if current == quote:
                    closed = True
                    index += 1
                    break
                end
                parts.append(current)
                index += 1
            end
            if not closed:
                call fail("unterminated text")
            end
            tokens.append(["str", "".join(parts)])
            continue
        end
        pair = source[index:index + 2]
        if pair in ["<=", ">=", "==", "!=", "&&", "||", "**"]:
            if pair == "**":
                pair = "^"
            end
            tokens.append(["op", pair])
            index += 2
            continue
        end
        if char in "+-*/%^<>!?:(),":
            tokens.append(["op", char])
            index += 1
            continue
        end
        if char == "=":
            call fail("use == to compare")
        end
        call fail("unexpected character " + char)
    end
    tokens.append(["end", ""])
    return tokens
end

function parser(tokens):
    return {"tokens": tokens, "index": 0, "depth": 0}
end

function peek(state):
    return state["tokens"][state["index"]]
end

function take(state):
    token = state["tokens"][state["index"]]
    if token[0] != "end":
        state["index"] += 1
    end
    return token
end

function is_op(state, values):
    token = peek(state)
    return token[0] == "op" and token[1] in values
end

function expect(state, value):
    token = take(state)
    if token[0] != "op" or token[1] != value:
        call fail("expected " + value)
    end
end

function enter(state):
    state["depth"] += 1
    if state["depth"] > MAX_DEPTH:
        call fail("formula is nested too deeply")
    end
end

function leave(state):
    state["depth"] -= 1
end

function parse_ternary(state):
    call enter(state)
    condition = parse_or(state)
    if is_op(state, ["?"]):
        call take(state)
        first = parse_ternary(state)
        call expect(state, ":")
        second = parse_ternary(state)
        condition = ["tern", condition, first, second]
    end
    call leave(state)
    return condition
end

function parse_or(state):
    left = parse_and(state)
    while is_op(state, ["||"]):
        call take(state)
        left = ["bin", "||", left, parse_and(state)]
    end
    return left
end

function parse_and(state):
    left = parse_compare(state)
    while is_op(state, ["&&"]):
        call take(state)
        left = ["bin", "&&", left, parse_compare(state)]
    end
    return left
end

function parse_compare(state):
    left = parse_sum(state)
    while is_op(state, ["<", "<=", ">", ">=", "==", "!="]):
        op = take(state)[1]
        left = ["bin", op, left, parse_sum(state)]
    end
    return left
end

function parse_sum(state):
    left = parse_product(state)
    while is_op(state, ["+", "-"]):
        op = take(state)[1]
        left = ["bin", op, left, parse_product(state)]
    end
    return left
end

function parse_product(state):
    left = parse_unary(state)
    while is_op(state, ["*", "/", "%"]):
        op = take(state)[1]
        left = ["bin", op, left, parse_unary(state)]
    end
    return left
end

function parse_unary(state):
    if is_op(state, ["-", "+", "!"]):
        op = take(state)[1]
        call enter(state)
        operand = parse_unary(state)
        call leave(state)
        return ["un", op, operand]
    end
    return parse_power(state)
end

function parse_power(state):
    base = parse_atom(state)
    if is_op(state, ["^"]):
        call take(state)
        call enter(state)
        # mocnina je zprava asociativni a vaze silneji nez unarni minus vlevo: -2^2 = -4, 2^-1 = 0.5
        exponent = parse_unary(state)
        call leave(state)
        return ["bin", "^", base, exponent]
    end
    return base
end

function parse_atom(state):
    token = take(state)
    kind = token[0]
    if kind == "num":
        return ["num", token[1]]
    end
    if kind == "str":
        return ["str", token[1]]
    end
    if kind == "name":
        name = token[1]
        if is_op(state, ["("]):
            call take(state)
            if name not in FUNCTIONS:
                call fail("unknown function " + name)
            end
            arguments = []
            if not is_op(state, [")"]):
                loop:
                    arguments.append(parse_ternary(state))
                    if is_op(state, [","]):
                        call take(state)
                        continue
                    end
                    break
                end
            end
            call expect(state, ")")
            limits = FUNCTIONS[name]
            if len(arguments) < limits[0] or len(arguments) > limits[1]:
                call fail(name + " takes " + String(limits[0]) + "-" + String(limits[1]) + " arguments")
            end
            return ["call", name, arguments]
        end
        if name == "pi":
            return ["num", math.PI]
        elif name == "e":
            return ["num", math.E]
        elif name == "true":
            return ["num", True]
        elif name == "false":
            return ["num", False]
        end
        return ["var", name]
    end
    if kind == "op" and token[1] == "(":
        call enter(state)
        inner = parse_ternary(state)
        call leave(state)
        call expect(state, ")")
        return inner
    end
    if kind == "end":
        call fail("formula ends too early")
    end
    call fail("unexpected " + String(token[1]))
end

function parse(text):
    state = parser(tokenize(text))
    if peek(state)[0] == "end":
        call fail("empty formula")
    end
    tree = parse_ternary(state)
    if peek(state)[0] != "end":
        call fail("unexpected " + String(peek(state)[1]))
    end
    return tree
end

function variables(tree, output=None):
    # jmena promennych ve vzorci (kontrola odkazu na neexistujici ovladaci prvky)
    if output == None:
        output = []
    end
    kind = tree[0]
    if kind == "var":
        if tree[1] not in output:
            output.append(tree[1])
        end
    elif kind == "un":
        call variables(tree[2], output)
    elif kind == "bin":
        call variables(tree[2], output)
        call variables(tree[3], output)
    elif kind == "tern":
        call variables(tree[1], output)
        call variables(tree[2], output)
        call variables(tree[3], output)
    elif kind == "call":
        for argument in tree[2]:
            call variables(argument, output)
        end
    end
    return output
end

function number(value):
    kind = type(value)
    if kind == "Bool":
        if value:
            return 1
        end
        return 0
    end
    if kind == "Int" or kind == "Float":
        return value
    end
    if kind == "String":
        text = value.strip()
        if text:
            try:
                return Float(text.replace(",", "."))
            else:
                call fail("text is not a number")
            end
        end
    end
    call fail("expected a number")
end

function truthy(value):
    if type(value) == "String":
        return value != ""
    end
    return number(value) != 0
end

function finite(value):
    if type(value) == "Float":
        if value != value or value == 1.0 / 0.0 or value == -1.0 / 0.0:
            call fail("result is not a finite number")
        end
    end
    return value
end

function power(base, exponent):
    if type(exponent) == "Int" and type(base) == "Int" and exponent >= 0:
        # Int by pretekl (wrap): velke vysledky jako Float
        approximate = finite(Float(base) ^ min(exponent, 2000))
        if abs(approximate) >= 9.0e15:
            return approximate
        end
        return base ^ exponent
    end
    if type(exponent) == "Int" and abs(exponent) <= 2000:
        if exponent >= 0:
            return finite(Float(base) ^ exponent)
        end
        if base == 0:
            call fail("division by zero")
        end
        return finite(1.0 / (Float(base) ^ (-exponent)))
    end
    if base == 0:
        if exponent > 0:
            return 0.0
        end
        call fail("division by zero")
    end
    if base < 0:
        whole = math.floor(Float(exponent))
        if Float(whole) == Float(exponent) and abs(whole) <= 2000:
            return power(base, whole)
        end
        call fail("power of a negative number")
    end
    product = Float(exponent) * math.log(Float(base))
    if product > 709.0:
        call fail("result is not a finite number")
    end
    return finite(math.exp(product))
end

function step(context):
    context["steps"] += 1
    if context["steps"] > MAX_STEPS:
        call fail("formula is too complex")
    end
end

function evaluate_node(tree, context):
    call step(context)
    kind = tree[0]
    if kind == "num" or kind == "str":
        return tree[1]
    end
    if kind == "var":
        values = context["values"]
        if tree[1] not in values:
            call fail("unknown name " + tree[1])
        end
        value = values[tree[1]]
        if type(value) not in ["Int", "Float", "Bool", "String"]:
            call fail("unsupported value of " + tree[1])
        end
        return value
    end
    if kind == "un":
        operand = evaluate_node(tree[2], context)
        if tree[1] == "!":
            return not truthy(operand)
        end
        value = number(operand)
        if tree[1] == "-":
            return -value
        end
        return value
    end
    if kind == "tern":
        if truthy(evaluate_node(tree[1], context)):
            return evaluate_node(tree[2], context)
        end
        return evaluate_node(tree[3], context)
    end
    if kind == "bin":
        op = tree[1]
        if op == "&&":
            left = evaluate_node(tree[2], context)
            if not truthy(left):
                return False
            end
            return truthy(evaluate_node(tree[3], context))
        end
        if op == "||":
            left = evaluate_node(tree[2], context)
            if truthy(left):
                return True
            end
            return truthy(evaluate_node(tree[3], context))
        end
        left = evaluate_node(tree[2], context)
        right = evaluate_node(tree[3], context)
        if op == "+" and (type(left) == "String" or type(right) == "String"):
            joined = text_of(left) + text_of(right)
            if len(joined) > 2000:
                call fail("text is too long")
            end
            return joined
        end
        if op == "==" or op == "!=":
            same = False
            if type(left) == "String" or type(right) == "String":
                same = text_of(left) == text_of(right)
            else:
                same = number(left) == number(right)
            end
            if op == "==":
                return same
            end
            return not same
        end
        a = number(left)
        b = number(right)
        if op == "+":
            return finite(a + b)
        elif op == "-":
            return finite(a - b)
        elif op == "*":
            return finite(a * b)
        elif op == "/":
            if b == 0:
                call fail("division by zero")
            end
            return finite(a / b)
        elif op == "%":
            if b == 0:
                call fail("division by zero")
            end
            if type(a) == "Int" and type(b) == "Int":
                return a % b
            end
            return finite(Float(a) - Float(b) * Float(math.floor(Float(a) / Float(b))))
        elif op == "^":
            return power(a, b)
        elif op == "<":
            return a < b
        elif op == "<=":
            return a <= b
        elif op == ">":
            return a > b
        elif op == ">=":
            return a >= b
        end
        call fail("unknown operator " + op)
    end
    if kind == "call":
        name = tree[1]
        if name == "if":
            if truthy(evaluate_node(tree[2][0], context)):
                return evaluate_node(tree[2][1], context)
            end
            return evaluate_node(tree[2][2], context)
        end
        values = []
        for argument in tree[2]:
            values.append(number(evaluate_node(argument, context)))
        end
        return call_function(name, values)
    end
    call fail("invalid formula")
end

function call_function(name, values):
    first = values[0]
    if name == "abs":
        return abs(first)
    elif name == "min":
        result = first
        for value in values:
            result = min(result, value)
        end
        return result
    elif name == "max":
        result = first
        for value in values:
            result = max(result, value)
        end
        return result
    elif name == "sum" or name == "avg":
        total = 0
        for value in values:
            total = finite(total + value)
        end
        if name == "avg":
            return total / len(values)
        end
        return total
    elif name == "round":
        digits = 0
        if len(values) > 1:
            digits = Int(values[1])
        end
        if digits < 0 or digits > 12:
            call fail("round digits must be 0-12")
        end
        if type(first) == "Int":
            return first
        end
        if abs(first) > 1.0e15:
            return first
        end
        scale = 10 ^ digits
        scaled = Float(first) * scale
        whole = math.floor(scaled + 0.5)
        if digits == 0:
            return whole
        end
        return Float(whole) / scale
    elif name == "floor" or name == "ceil":
        if type(first) == "Int":
            return first
        end
        if abs(first) > 1.0e15:
            return first
        end
        if name == "floor":
            return math.floor(first)
        end
        return math.ceil(first)
    elif name == "sqrt":
        if first < 0:
            call fail("square root of a negative number")
        end
        return sqrt(first)
    elif name == "pow":
        return power(first, values[1])
    elif name == "exp":
        if first > 709:
            call fail("result is not a finite number")
        end
        return math.exp(first)
    elif name == "ln" or name == "log" or name == "log10":
        if first <= 0:
            call fail("logarithm of a non-positive number")
        end
        if name == "log" and len(values) > 1:
            base = values[1]
            if base <= 0 or base == 1:
                call fail("invalid logarithm base")
            end
            return math.log(first) / math.log(base)
        end
        if name == "log10":
            return math.log10(first)
        end
        return math.log(first)
    elif name == "sin":
        return math.sin(first)
    elif name == "cos":
        return math.cos(first)
    elif name == "tan":
        return finite(math.tan(first))
    elif name == "clamp":
        low = values[1]
        high = values[2]
        if low > high:
            call fail("clamp needs low <= high")
        end
        return max(low, min(high, first))
    end
    call fail("unknown function " + name)
end

function evaluate(tree, values):
    context = {"values": common.fallback(values, {}), "steps": 0}
    return evaluate_node(tree, context)
end

function compute(text, values):
    # [hodnota, None] nebo [None, chyba]; nikdy nevyhodi vyjimku
    try:
        return [evaluate(parse(text), values), None]
    else:
        problem = String(last_error())
        if problem.startswith("ExprError: "):
            problem = problem[11:]
        else:
            problem = "invalid formula"
        end
        return [None, problem]
    end
end

function text_of(value):
    kind = type(value)
    if kind == "String":
        return value
    end
    if kind == "Bool":
        if value:
            return "true"
        end
        return "false"
    end
    return format_value(value, "")
end

function group_digits(text, separator=" ", always=False):
    # 4mistna cisla bez mezery (1234), pokud oddeleni tisicu vzorec nevyzaduje (",")
    negative = text.startswith("-")
    if negative:
        text = text[1:]
    end
    if len(text) <= 3 or (len(text) <= 4 and not always):
        if negative:
            return "-" + text
        end
        return text
    end
    output = []
    length = len(text)
    for index in rang(length):
        output.append(text[index])
        if (length - index - 1) % 3 == 0 and index < length - 1:
            output.append(separator)
        end
    end
    result = "".join(output)
    if negative:
        return "-" + result
    end
    return result
end

function fixed(value, decimals):
    # pevny pocet desetinnych mist bez vedecke notace (zaokrouhleni pul nahoru od nuly)
    number = Float(value)
    negative = number < 0
    if negative:
        number = -number
    end
    if number >= 1.0e15:
        text = String(number)
        if negative:
            return "-" + text
        end
        return text
    end
    scale = 10 ^ decimals
    scaled = Int(math.floor(number * scale + 0.5))
    whole = scaled // scale
    fraction = scaled % scale
    text = String(whole)
    if decimals > 0:
        digits = String(fraction)
        while len(digits) < decimals:
            digits = "0" + digits
        end
        text += "." + digits
    end
    if negative and scaled != 0:
        return "-" + text
    end
    return text
end

function format_value(value, pattern="", unit=""):
    # pattern: "" (az 4 desetinna mista bez koncovych nul), "0", "0.00", "0.0%" (procenta), "," (oddeleni tisicu)
    kind = type(value)
    if kind == "String":
        return value + unit_suffix(unit)
    end
    if kind == "Bool":
        if value:
            return "✓"
        end
        return "✗"
    end
    if value == None:
        return "–"
    end
    pattern = String(common.fallback(pattern, ""))
    number = value
    percent = pattern.endswith("%")
    if percent:
        number = Float(value) * 100
        pattern = pattern[:len(pattern) - 1]
    end
    grouping = "," in pattern
    pattern = pattern.replace(",", "")
    text = ""
    if pattern.startswith("0"):
        decimals = 0
        if "." in pattern:
            decimals = min(10, len(pattern) - pattern.find(".") - 1)
        end
        text = fixed(number, decimals)
    else:
        if type(number) == "Int":
            text = String(number)
        else:
            text = fixed(number, 4)
            if "." in text:
                text = text.rstrip("0").rstrip(".")
            end
            if text == "-0":
                text = "0"
            end
        end
    end
    if grouping or abs(Float(number)) >= 10000:
        parts = text.split(".")
        head = group_digits(parts[0], " ", grouping)
        if len(parts) > 1:
            text = head + "." + parts[1]
        else:
            text = head
        end
    end
    if percent:
        text += " %"
    end
    return text + unit_suffix(unit)
end

function unit_suffix(unit):
    if unit:
        return " " + String(unit)
    end
    return ""
end
