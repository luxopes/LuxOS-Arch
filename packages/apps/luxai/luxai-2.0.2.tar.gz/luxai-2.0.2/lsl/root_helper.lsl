# Shared helper logic. These programs are built separately and are not installed
# or invoked through sudo/pkexec by migration tests.
load platform
load common
load glib
load rootguard
load guard_data
load child_process

function command_args():
    values = []
    for index in rang(1, arg_count()):
        values.append(arg(index))
    end
    return values
end

function die(message, code, setup=False):
    prefix = "luxai-root: "
    if setup:
        prefix = "luxai-root-setup: "
    end
    call platform.stderr(prefix + message + "\n")
    exit(code)
end

function caller(setup=False):
    uid = glib.getenv("PKEXEC_UID")
    if uid == None or not platform.regex_test("^\\d+$", uid):
        if platform.geteuid() == 0:
            call die("must be started through pkexec", 126, setup)
        end
        uid = String(platform.getuid())
    end
    info = platform.user_info(Int(uid))
    if info == None:
        call die("unknown calling user", 126, setup)
    end
    if setup and platform.geteuid() == 0 and info["uid"] < 1000:
        call die("administrator mode is only for normal user accounts", 126, setup)
    end
    return info
end

# Rezim spravce (luxai-root-auto): polkit si heslo pamatuje jen pro proces, ktery ho zadal
# (auth_admin_keep). Pomocnik navic pusti jen primeho rodice /usr/bin/luxai (pkexec spusti
# pomocnika ve svem procesu, takze rodic pomocnika je program, ktery pkexec zavolal), ktery neni
# laden (TracerPid 0) a nema podstrcene knihovny (LD_PRELOAD, LD_AUDIT, LD_LIBRARY_PATH).
LUXAI_EXE = "/usr/bin/luxai"
LOADER_VARS = ["LD_PRELOAD=", "LD_AUDIT=", "LD_LIBRARY_PATH="]

function auto_helper():
    return rootguard.base(arg(0)) == "luxai-root-auto"
end

function parent_pid():
    return __lsl_qbe_s32(__lsl_qbe_call0(__lsl_symbol("getppid")))
end

function environ_entries(raw):
    # /proc/PID/environ: polozky oddelene bajtem 0 (bez prevodu na text, ten by skoncil na prvni 0)
    entries = []
    start = 0
    for index in rang(len(raw) + 1):
        if index == len(raw) or raw[index] == 0:
            if index > start:
                entries.append(platform.utf8_repair(raw[start:index]))
            end
            start = index + 1
        end
    end
    return entries
end

function parent_problem(proc, ppid):
    # Proc rodic nesmi pouzit rezim spravce, nebo None (rodic je neupravena LuxAI).
    if ppid <= 1:
        return "the calling program has exited"
    end
    folder = proc + "/" + String(ppid)
    exe = platform.readlink(folder + "/exe")
    # None zvlast: porovnani None s textem LSL 0.10.8 shodi (SIGSEGV)
    if exe == None:
        return "administrator mode is only for LuxAI itself (caller: unknown)"
    end
    # " (deleted)": bezici LuxAI po aktualizaci - soubor v /usr/bin smi zapsat jen root
    if exe != LUXAI_EXE and exe != LUXAI_EXE + " (deleted)":
        return "administrator mode is only for LuxAI itself (caller: " + exe + ")"
    end
    try:
        status = platform.utf8_repair(platform.read_prefix(folder + "/status", 65536))
        environ = platform.read_prefix(folder + "/environ", 1048576)
    else:
        return "cannot check the calling program"
    end
    tracer = platform.regex_findall("(?m)^TracerPid:\\s*(\\d+)", status)
    if len(tracer) != 1 or tracer[0]["groups"][1] != "0":
        return "LuxAI is being traced by another program"
    end
    for entry in environ_entries(environ):
        for name in LOADER_VARS:
            if entry.startswith(name):
                return "LuxAI was started with " + name[:len(name) - 1]
            end
        end
    end
    return None
end

function check_parent():
    proc = "/proc"
    if platform.geteuid() != 0:
        # testy bez roota: falesny /proc; bez nej se rodic nekontroluje (pomocnik pak nema prava)
        proc = glib.getenv("LUXAI_TEST_PROC")
        if not proc:
            return
        end
    end
    ppid = parent_pid()
    problem = parent_problem(proc, ppid)
    if problem == None and parent_pid() != ppid:
        problem = "the calling program has exited"
    end
    if problem:
        call die("refused: " + problem, guard_data.EXIT_REFUSED)
    end
end

function parse(argv):
    timeout = 120
    workdir = "/"
    command = None
    i = 0
    while i < len(argv):
        token = argv[i]
        if token == "--":
            command = " ".join(argv[i + 1:])
            break
        end
        if token == "--timeout" and i + 1 < len(argv):
            try:
                timeout = Int(argv[i + 1])
            else:
                call die("invalid --timeout", 2)
            end
            i += 2
            continue
        end
        if token == "--cwd" and i + 1 < len(argv):
            workdir = argv[i + 1]
            i += 2
            continue
        end
        call die("usage: luxai-root [--timeout S] [--cwd DIR] -- COMMAND", 2)
    end
    if not command or not command.strip(common.WHITESPACE):
        call die("empty command", 2)
    end
    if len(command) > guard_data.MAX_COMMAND:
        call die("command too long", 2)
    end
    return {"timeout": max(1, min(timeout, guard_data.MAX_TIMEOUT)), "cwd": workdir, "command": command}
end

function command_main(argv):
    if auto_helper():
        call check_parent()
    end
    options = parse(argv)
    user = caller()
    workdir = options["cwd"]
    info = platform.file_info(workdir)
    if info == None or not info["directory"]:
        workdir = "/"
    end
    command = options["command"]
    reason = rootguard.hard_block(command, True, workdir, user["home"])
    if reason or rootguard.feeds_password(command):
        call die("refused by LuxAI safety rules: " + common.fallback(reason, guard_data.R_PASSWORD), guard_data.EXIT_REFUSED)
    end
    if platform.geteuid() == 0:
        call platform.audit_root(user["name"], rootguard.base(arg(0)), workdir, common.words(command)[:2000])
    end
    env = {"PATH": guard_data.ROOT_PATH, "HOME": "/root", "USER": "root", "LOGNAME": "root", "TERM": "dumb", "LANG": common.environment("LANG", "C.UTF-8"), "LUXAI_AGENT": "1", "PAGER": "cat", "SYSTEMD_PAGER": "", "DEBIAN_FRONTEND": "noninteractive", "SUDO_USER": user["name"]}
    result = child_process.run(["/bin/bash", "-c", command], workdir, env, options["timeout"], None, None, False, True, True)
    if result["timed_out"]:
        call die("timed out after " + String(options["timeout"]) + " s", guard_data.EXIT_TIMEOUT)
    end
    if result["cancelled"]:
        call die("stopped by the user", guard_data.EXIT_CANCELLED)
    end
    code = result["exit_code"]
    if code == None:
        call die("cannot determine command exit status", guard_data.EXIT_REFUSED)
    end
    if code < 0:
        return 128 - code
    end
    return code
end

function setup_main(argv):
    # Od 2.0.2 rezim spravce zadne pravidlo polkit nepotrebuje (auth_admin_keep v politice). Pravidlo
    # 49-luxai-root-<uzivatel>.rules z drivejsich verzi pustilo bez hesla kazdy program uzivatele,
    # proto ho enable i disable jen smazou (i kdyz je zavola starsi bezici LuxAI); nic nezapisuji.
    # status: "on" = stare pravidlo jeste existuje.
    if len(argv) != 1 or argv[0] not in ["enable", "disable", "status"]:
        call die("usage: luxai-root-setup enable|disable|status", 2, True)
    end
    user = caller(True)
    if not rootguard.valid_user(user["name"]):
        call die("unsupported user name", 126, True)
    end
    path = rootguard.rule_path(user["name"])
    if platform.geteuid() != 0:
        rules = glib.getenv("LUXAI_RULES_DIR")
        if rules:
            path = common.join(rules, rootguard.base(path))
        end
    end
    if argv[0] == "status":
        if exists(path):
            print "on"
        else:
            print "off"
        end
        return 0
    end
    call platform.unlink(path)
    return 0
end
