load text_calls
load gtk
load gtk_ext
load glib
load common
load markdown
load highlight
load images
load i18n
load ui_data
load ui_dispatch
load time
load platform
load gui_bridge
load json
load rich_ui

selection_state = {"label": 0}
CODE_DISPLAY_LIMIT = 60000
copy_feedback = {"pending": [], "tick": None}

function classes(widget, names):
    for name in names:
        call gtk.widget_add_class(widget, name)
    end
    return widget
end

function selected(state, property, widget):
    if gtk_ext.selection(widget):
        selection_state["label"] = widget
    end
end

function selected_destroyed(state, widget):
    if selection_state["label"] == widget:
        selection_state["label"] = 0
    end
end

function selection_in(root):
    if not root:
        return ""
    end
    label_type = __lsl_qbe_call0(__lsl_symbol("gtk_label_get_type"))
    if __lsl_qbe_call2(__lsl_symbol("g_type_check_instance_is_a"), platform.pointer(root), label_type) != 0:
        return gtk_ext.selection(root)
    end
    container_type = __lsl_qbe_call0(__lsl_symbol("gtk_container_get_type"))
    if __lsl_qbe_call2(__lsl_symbol("g_type_check_instance_is_a"), platform.pointer(root), container_type) == 0:
        return ""
    end
    found = ""
    for child in gtk_ext.children(root):
        text = selection_in(child)
        if text:
            found = text
        end
    end
    return found
end

function selected_text(root=0):
    if selection_state["label"]:
        text = gtk_ext.selection(selection_state["label"])
        if text:
            return text
        end
    end
    return selection_in(root)
end

function label(text="", markup=None, names=None, wrap=False, selectable=False, ellipsize=False, xalign=0.0):
    result = gtk.label_new(String(text).replace("\0", "�"))
    if markup != None:
        call gtk.label_set_markup(result, String(markup).replace("\0", "�"))
    end
    call gtk_ext.label_set_xalign(result, xalign)
    if wrap:
        call gtk_ext.label_set_line_wrap(result, True)
        call gtk_ext.label_set_line_wrap_mode(result, 2)
    end
    if selectable:
        call gtk_ext.label_set_selectable(result, True)
        call gtk_ext.widget_set_can_focus(result, False)
        call gtk_ext.connect(result, "notify::selection-bound", selected, None, 1)
        call gtk_ext.connect(result, "destroy", selected_destroyed, None)
    end
    if ellipsize:
        call gtk_ext.label_set_ellipsize(result, 3)
    end
    return classes(result, common.fallback(names, []))
end

function box(vertical=True, spacing=0, names=None):
    orientation = 0
    if vertical:
        orientation = 1
    end
    return classes(gtk.box_new(orientation, spacing), common.fallback(names, []))
end

function pack(container, widget, expand=False, fill=True, padding=0):
    call gtk.box_pack_start(container, widget, expand, fill, padding)
    return widget
end

function button(title, handler=None, state=None, names=None):
    result = classes(gtk.button_new(i18n.translate(title)), common.fallback(names, []))
    if handler != None:
        call gtk_ext.connect(result, "clicked", handler, state)
    end
    return result
end

function icon_button(icon, title, handler=None, state=None):
    result = gtk.button_new_from_icon_name(icon, 4)
    call gtk.widget_set_tooltip(result, i18n.translate(title))
    if handler != None:
        call gtk_ext.connect(result, "clicked", handler, state)
    end
    return result
end

function scrolled(child, horizontal=2, vertical=1):
    result = gtk.scrolled_window_new()
    call gtk.scrolled_window_set_policy(result, horizontal, vertical)
    call gtk.container_add(result, child)
    return result
end

function text_view(text="", editable=True):
    view = gtk_ext.text_view_new()
    call gtk_ext.text_view_set_wrap_mode(view, 3)
    call gtk_ext.text_view_set_accepts_tab(view, False)
    call gtk_ext.text_view_set_editable(view, editable)
    call gtk_ext.text_buffer_set_text(gtk_ext.text_view_get_buffer(view), text, -1)
    return view
end

function copy_tick(state, arguments):
    for item in copy_feedback["pending"].copy():
        if not item["button"] or time.monotonic() >= item["restore_at"]:
            if item["button"]:
                call gtk.button_set_label(item["button"], i18n.translate("Copy"))
            end
            call copy_feedback["pending"].remove(item)
        end
    end
end

function copy_destroyed(state, widget):
    state["button"] = 0
end

function copied(state, button):
    text = state.get("text", "")
    if state.get("source") != None:
        text = state["source"]["text"]
    end
    call gui_bridge.copy_text(text)
    call gtk.button_set_label(button, i18n.translate("Copied"))
    state["restore_at"] = time.monotonic() + 1.2
    if state not in copy_feedback["pending"]:
        copy_feedback["pending"].append(state)
    end
end

function copy_button(text, source=None, tooltip="", names=None, icon=""):
    state = {"text": text, "source": source, "restore_at": 0.0}
    result = button("Copy", copied, state, common.fallback(names, ["msg-copy", "flat"]))
    call gtk.button_set_relief(result, 2)
    if tooltip:
        call gtk.widget_set_tooltip(result, i18n.translate(tooltip))
    end
    if icon:
        call gtk.button_set_image(result, gtk.image_new_from_icon_name(icon, 1))
        call gtk_ext.button_set_always_show_image(result, True)
    end
    state["button"] = result
    call gtk_ext.connect(result, "destroy", copy_destroyed, state)
    if copy_feedback["tick"] == None:
        copy_feedback["tick"] = ui_dispatch.add_tick(copy_tick)
    end
    return result
end

function text_label(markup):
    result = label("", markup, None, True, True)
    call gtk_ext.widget_set_hexpand(result, True)
    return result
end

function code_widget(block, dark):
    result = box(True, 0, ["md-code"])
    head = box(False, 6, ["md-code-head"])
    name = common.fallback(highlight.language_name(block["lang"]), common.fallback(block["lang"], i18n.translate("code")))
    call pack(head, label(name, None, ["dim", "small"]))
    call gtk.box_pack_end(head, copy_button(block["text"], None, "Copy code", ["flat-small", "flat"]), False, True, 0)
    call pack(result, head)
    # obrovsky blok: zobrazit zacatek (Kopirovat vzdy kopiruje cely kod); GTK label s megabajty
    # markupu by zablokoval okno na desitky sekund
    text = block["text"]
    hidden = 0
    if len(text) > CODE_DISPLAY_LIMIT:
        cut = text[:CODE_DISPLAY_LIMIT]
        if "\n" in cut:
            cut = cut[:common.rfind(cut, "\n")]
        end
        hidden = len(text[len(cut):].split("\n")) - 1
        text = cut
    end
    code = highlight.highlight(text, block["lang"], dark)
    content = label("", "<span font_family=\"monospace\">" + code + "</span>", ["md-code-text"], False, True)
    scroll = scrolled(content, 1, 2)
    call gtk_ext.scrolled_window_set_propagate_natural_height(scroll, True)
    call pack(result, scroll)
    if hidden > 0 or len(block["text"]) > len(text):
        more = label(i18n.translate("The code is too long to show completely; Copy copies all of it.") + " (+" + String(max(1, hidden)) + ")", None, ["dim", "small"], True)
        call gtk_ext.widget_set_margin_start(more, 12)
        call gtk_ext.widget_set_margin_bottom(more, 6)
        call pack(result, more)
    end
    return result
end

function markdown_block(block, dark, ctx=None, final=True):
    code_color = "#e9eaf2"
    link_color = "#2f67e8"
    if dark:
        code_color = "#30324a"
        link_color = "#7aa2ff"
    end
    if ctx == None:
        ctx = {"dark": dark}
    end
    kind = block["type"]
    if kind == "para":
        return text_label(markdown.inline(block["text"], code_color, link_color))
    elif kind == "heading":
        return text_label(markdown.heading_markup(block, code_color, link_color))
    elif kind == "hr":
        return gtk.separator_new(0)
    elif kind == "quote":
        result = box(False, 0, ["md-quote"])
        call pack(result, text_label("<i>" + markdown.inline(block["text"], code_color, link_color) + "</i>"), True)
        return result
    elif kind == "list":
        result = box(True, 3)
        index = 0
        for item in block["items"]:
            row = box(False, 6)
            call gtk_ext.widget_set_margin_start(row, item["level"] * 18)
            prefix = label(markdown.list_item_prefix(item, index), None, ["dim"])
            call gtk_ext.label_set_yalign(prefix, 0.0)
            call gtk_ext.label_set_width_chars(prefix, 2)
            call pack(row, prefix)
            call pack(row, text_label(markdown.inline(item["text"], code_color, link_color)), True)
            call pack(result, row)
            index += 1
        end
        return result
    elif kind == "math":
        # zobrazeny vzorec: nativni sazba (zlomky, odmocniny, matice); pri chybe Pango markup
        if block.get("closed", True) or final:
            native = rich_ui.math_widget(ctx, block["text"])
            if native:
                return native
            end
        end
        result = label("", markdown.math_markup(block), ["md-math"], True, True, False, 0.5)
        call gtk_ext.label_set_justify(result, 2)
        call gtk_ext.widget_set_hexpand(result, True)
        return result
    elif kind == "code":
        if rich_ui.is_rich(block):
            widget = rich_ui.block_widget(block, ctx, final)
            if widget:
                return widget
            end
        end
        return code_widget(block, dark)
    elif kind == "table":
        return rich_ui.markdown_table(block, ctx)
    end
    return 0
end

function markdown_view(text="", dark=False, ctx=None):
    if ctx == None:
        ctx = {}
    end
    ctx["dark"] = dark
    if not ctx.get("id"):
        ctx["id"] = common.random_hex(8)
    end
    state = {"widget": box(True, 8), "text": "", "dark": dark, "ctx": ctx, "rendered": [], "final": True}
    call render_markdown(state, text)
    return state
end

function block_signature(block, key, final):
    # stejny podpis = widget se pri streamovani znovu nepouzije (graf se nevytvari 14x za sekundu)
    rich = block.get("type") == "math" or (block.get("type") == "code" and rich_ui.is_rich(block))
    flag = ""
    if rich and not block.get("closed", True) and final:
        flag = "final"
    end
    return json.encode(block) + "|" + key + "|" + flag
end

function render_markdown(state, text):
    state["text"] = common.fallback(text, "")
    ctx = state.get("ctx")
    if ctx == None:
        ctx = {}
        state["ctx"] = ctx
    end
    dark = state["dark"]
    ctx["dark"] = dark
    if state.get("rendered_dark") != dark:
        call gtk_ext.clear(state["widget"])
        state["rendered"] = []
        state["rendered_dark"] = dark
    end
    final = state.get("final", True)
    # vypsana volani nastroju (<tool_call>) jako kod, ne Markdown (zachova odsazeni, "#" neni nadpis)
    blocks = markdown.parse_blocks(text_calls.display_markdown(state["text"]))
    keys = rich_ui.keys_for(blocks)
    previous = state.get("rendered", [])
    kept = 0
    while kept < len(blocks) and kept < len(previous) and previous[kept][0] == block_signature(blocks[kept], keys[kept], final):
        kept += 1
    end
    # od prvni zmeny dal se widgety vytvori znovu (pri streamovani obvykle jen posledni blok)
    for item in previous[kept:]:
        if item[1]:
            call gtk.widget_destroy(item[1])
        end
    end
    rendered = previous[:kept]
    for index in rang(kept, len(blocks)):
        block = blocks[index]
        ctx["current_key"] = keys[index]
        child = markdown_block(block, dark, ctx, final)
        ctx["current_key"] = ""
        if child:
            call pack(state["widget"], child)
        end
        rendered.append([block_signature(block, keys[index], final), child])
    end
    state["rendered"] = rendered
    call gtk.widget_show_all(state["widget"])
end

function user_bubble(text, image_urls=None, files=None):
    result = box(True, 4)
    call gtk.widget_set_halign(result, 2)
    call gtk_ext.widget_set_margin_start(result, 80)
    if image_urls:
        row = box(False, 6)
        call gtk.widget_set_halign(row, 2)
        for url in image_urls:
            image = images.from_data_url(url, 220, 160)
            widget = 0
            if image:
                widget = gtk.image_new_from_pixbuf(image)
                call glib.object_unref(image)
            else:
                widget = gtk.image_new_from_icon_name("image-x-generic-symbolic", 6)
            end
            call pack(row, widget)
        end
        call pack(result, row)
    end
    if platform.strip(text, common.WHITESPACE) or files:
        bubble = box(True, 4, ["bubble-user"])
        if platform.strip(text, common.WHITESPACE):
            content = label(text, None, None, True, True)
            call gtk_ext.label_set_max_width_chars(content, 70)
            call pack(bubble, content, True)
        end
        for name in common.fallback(files, []):
            row = box(False, 4, ["user-file"])
            call pack(row, gtk.image_new_from_icon_name("text-x-generic-symbolic", 1))
            call pack(row, label(name, None, None, False, False, True))
            call pack(bubble, row)
        end
        call pack(result, bubble)
    end
    call gtk.widget_show_all(result)
    return result
end

function assistant_bubble(text="", dark=False, ctx=None):
    result = box(True, 3)
    call gtk_ext.widget_set_margin_end(result, 40)
    call pack(result, label("LuxAI", None, ["role"]))
    bubble = box(True, 6, ["bubble-ai"])
    thinking = box(False, 8)
    spinner = gtk_ext.spinner_new()
    call pack(thinking, spinner)
    call pack(thinking, label(i18n.translate("Thinking…"), None, ["dim"]))
    view = markdown_view(text, dark, ctx)
    call pack(bubble, thinking)
    call pack(bubble, view["widget"])
    call pack(result, bubble)
    actions = box(False, 4)
    state = {"widget": result, "text": text, "view": view, "thinking": thinking, "spinner": spinner, "actions": actions, "pending": False, "render_at": 0.0, "finished": Bool(text)}
    call pack(actions, copy_button("", state, "Copy the whole answer", ["msg-copy", "flat"], "edit-copy-symbolic"))
    call gtk_ext.widget_set_no_show_all(actions, True)
    call pack(result, actions)
    call gtk.widget_show_all(result)
    # pozdejsi show_all (pridani radku do sloupce) nesmi znovu ukazat "Premyslim" u hotove odpovedi
    call gtk_ext.widget_set_no_show_all(thinking, True)
    if text:
        call gtk.widget_hide(thinking)
        call gtk.widget_show_all(actions)
    else:
        call gtk_ext.spinner_start(spinner)
    end
    return state
end

function append(state, text, reasoning=""):
    if text:
        state["view"]["final"] = False
        state["text"] += text
        call gtk.widget_hide(state["thinking"])
        call gtk_ext.spinner_stop(state["spinner"])
        if not state["pending"]:
            state["pending"] = True
            state["render_at"] = time.monotonic() + 0.07
        end
    end
end

function render_pending(state):
    if state["pending"] and time.monotonic() >= state["render_at"]:
        state["pending"] = False
        call render_markdown(state["view"], state["text"])
        return True
    end
    return False
end

function finish(state, text=None):
    state["finished"] = True
    state["pending"] = False
    call gtk_ext.spinner_stop(state["spinner"])
    call gtk.widget_hide(state["thinking"])
    if text != None:
        state["text"] = text
    end
    state["view"]["final"] = True
    call render_markdown(state["view"], state["text"])
    if platform.strip(state["text"], common.WHITESPACE):
        call gtk.widget_show_all(state["actions"])
    end
end

function message_dialog(parent, primary, secondary="", buttons=None, registry=None):
    # Obdoba Gtk.MessageDialog: tucny hlavni text, vedlejsi text, tlacitka [popisek, odpoved, css trida].
    # Popisky musi byt uz prelozene. Vraci kod odpovedi.
    dialog = gtk_ext.dialog_new()
    call gtk.window_set_title(dialog, "")
    if parent:
        call gtk.window_set_transient_for(dialog, parent)
    end
    call gtk.window_set_modal(dialog, True)
    call gtk.window_set_resizable(dialog, False)
    for item in common.fallback(buttons, [[gtk_ext.gtk_text("_OK"), -5, ""]]):
        widget = gtk_ext.dialog_add_button(dialog, item[0], item[1])
        if len(item) > 2 and item[2]:
            call gtk.widget_add_class(widget, item[2])
        end
    end
    area = gtk_ext.dialog_get_content_area(dialog)
    call gtk.container_set_border_width(area, 18)
    call gtk.box_set_spacing(area, 8)
    title = label("", "<b><big>" + glib.markup_escape(primary) + "</big></b>", None, True, False, False, 0.5)
    call gtk_ext.label_set_max_width_chars(title, 50)
    call gtk_ext.label_set_justify(title, 2)
    call pack(area, title)
    if secondary:
        text = label(secondary, None, None, True, True, False, 0.5)
        call gtk_ext.label_set_max_width_chars(text, 50)
        call gtk_ext.label_set_justify(text, 2)
        call pack(area, text)
    end
    call gtk.widget_show_all(dialog)
    # registry: seznam otevrenych dialogu okna (pri zavreni okna se zavrou)
    if registry != None:
        registry.append(dialog)
    end
    response = gtk_ext.dialog_run(dialog)
    if registry != None:
        if dialog not in registry:
            # okno se zaviralo a dialog uz zniclo
            return -4
        end
        call registry.remove(dialog)
    end
    call gtk.widget_destroy(dialog)
    return response
end
