# lsl: internal-abi
# lsl: link libgtk-3.so.0 libgdk-3.so.0 libgdk_pixbuf-2.0.so.0 libcairo.so.2 libgobject-2.0.so.0 libglib-2.0.so.0
# Nativni widgety bohatych bloku v odpovedich LuxAI (GTK + cairo): graf s popisky pod mysi
# a ovladanim sipkami, SVG, diagram, vzorec, kviz, formular s vypoctenymi vystupy, tabulka
# s razenim, mapa (LuxOS Maps), galerie (jen se souhlasem se siti), casova osa, kontrolni seznam.
#
# Kontext ctx (z ui_widgets): {"dark", "store": slovnik stavu u zpravy (_rich) nebo None,
# "on_save": f(ctx) ulozeni konverzace, "on_send": f(ctx, text) nova zprava, "owner", "id",
# "network": f(ctx) -> "allow"/"ask"/"never"}. Bez kontextu (testy) se stav drzi
# jen v pameti. Neplatny blok se zobrazi jako kod s poznamkou (block_widget vrati 0 -> volajici).
load gtk
load gtk_ext
load glib
load cairo
load i18n
load common
load platform
load json
load time
load gui_bridge
load ui_dispatch
load markdown
load maps
load web
load rich_blocks
load rich_expr
load rich_draw
load rich_svg
load rich_diagram
load rich_math

CSS = "\n.rich-card { background-color: alpha(@lx_fg, 0.025); border: 1px solid @lx_border; border-radius: 12px; padding: 8px 10px; }\n.rich-title { font-weight: 700; }\n.rich-note { color: @lx_dim; font-size: 11px; }\n.rich-error { color: @lx_warn; font-size: 11px; }\n.rich-placeholder { color: @lx_dim; font-style: italic; padding: 8px 12px; border: 1px dashed @lx_border; border-radius: 10px; }\nbutton.rich-tool { padding: 0 6px; min-height: 20px; font-size: 11px; color: @lx_dim; background: none; border: none; box-shadow: none; }\nbutton.rich-tool label { color: @lx_dim; }\nbutton.rich-tool:hover label { color: @lx_fg; }\nbutton.rich-option { padding: 6px 10px; border-radius: 9px; background-image: none; }\nbutton.rich-option label { color: @lx_fg; }\nbutton.rich-option:disabled label, checkbutton.rich-option:disabled label { color: @lx_fg; }\nbutton.rich-correct, checkbutton.rich-correct { background-color: alpha(@lx_ok, 0.20); border-color: @lx_ok; }\nbutton.rich-wrong, checkbutton.rich-wrong { background-color: alpha(@lx_danger, 0.16); border-color: @lx_danger; }\n.rich-correct-text { color: @lx_ok; font-weight: 700; }\n.rich-wrong-text { color: @lx_danger; font-weight: 700; }\n.rich-output { font-weight: 700; font-size: 15px; }\n.rich-value { font-family: monospace; color: @lx_dim; }\n.rich-item { border-left: 2px solid alpha(@lx_accent, 0.45); padding: 2px 0 6px 12px; margin-left: 5px; }\n.rich-date { color: @lx_accent; font-weight: 700; }\n.rich-cell { padding: 3px 10px; border-bottom: 1px solid @lx_border; }\nbutton.rich-head { padding: 3px 10px; font-weight: 700; border-radius: 0; background-image: none; background-color: alpha(@lx_fg, 0.05); border: none; box-shadow: none; }\n.rich-drawing:focus { outline-color: alpha(@lx_accent, 0.7); outline-style: solid; outline-width: 2px; outline-offset: -2px; }\n.rich-done { color: @lx_dim; }\n"
KIND_NAMES = {"chart": "Chart", "quiz": "Quiz", "form": "Calculator", "table": "Table", "diagram": "Diagram", "math": "Formula", "svg": "Image", "map": "Map", "gallery": "Gallery", "timeline": "Timeline", "checklist": "Checklist"}
MAX_TABLE_ROWS = 500
MAX_IMAGE_BYTES = 6291456
save_queue = {"pending": [], "tick": None}
# jen testy (rich_window_test_main): seznam vytvorenych karet
registry = {"enabled": False, "cards": []}
measure_cache = {}

function tr(text):
    return i18n.translate(text)
end

# ---------------------------------------------------------------- male stavebni kameny

function classes(widget, names):
    for name in names:
        call gtk.widget_add_class(widget, name)
    end
    return widget
end

function label(text="", names=None, wrap=False, markup=None, selectable=False):
    result = gtk.label_new(String(text).replace("\0", ""))
    if markup != None:
        call gtk.label_set_markup(result, String(markup).replace("\0", ""))
    end
    call gtk_ext.label_set_xalign(result, 0.0)
    if wrap:
        call gtk_ext.label_set_line_wrap(result, True)
        call gtk_ext.label_set_line_wrap_mode(result, 2)
    end
    if selectable:
        call gtk_ext.label_set_selectable(result, True)
        call gtk_ext.widget_set_can_focus(result, False)
    end
    return classes(result, common.fallback(names, []))
end

function box(vertical=True, spacing=0, names=None):
    orientation = 0
    if vertical:
        orientation = 1
    end
    return classes(gtk.box_new(orientation, spacing), common.fallback(names, []))
end

function pack(container, widget, expand=False):
    call gtk.box_pack_start(container, widget, expand, True, 0)
    return widget
end

function button(title, handler, bound, names=None):
    result = classes(gtk.button_new(title), common.fallback(names, []))
    call gtk_ext.connect(result, "clicked", handler, bound)
    return result
end

function tool_button(title, tooltip, handler, bound):
    result = button(tr(title), handler, bound, ["rich-tool", "flat"])
    call gtk.button_set_relief(result, 2)
    if tooltip:
        call gtk.widget_set_tooltip(result, tr(tooltip))
    end
    return result
end

function markup_text(text, dark):
    code_color = "#e9eaf2"
    link_color = "#2f67e8"
    if dark:
        code_color = "#30324a"
        link_color = "#7aa2ff"
    end
    return markdown.inline(text, code_color, link_color)
end

function scale_factor(widget):
    return max(1, __lsl_qbe_call1(__lsl_symbol("gtk_widget_get_scale_factor"), platform.pointer(widget)))
end

function has_focus(widget):
    return __lsl_qbe_call1(__lsl_symbol("gtk_widget_has_focus"), platform.pointer(widget)) & 255 != 0
end

function clip_visible(cr):
    # False, kdyz je oblast kresleni prazdna (widget mimo viditelnou cast okna)
    data = platform.buffer(32)
    address = platform.address(data)
    call __lsl_qbe_call5(__lsl_symbol("cairo_clip_extents"), platform.pointer(cr), platform.pointer(address), platform.pointer(address) + 8, platform.pointer(address) + 16, platform.pointer(address) + 24)
    x1 = __lsl_float_from_bits(__lsl_qbe_load64(platform.pointer(address)))
    y1 = __lsl_float_from_bits(__lsl_qbe_load64(platform.pointer(address) + 8))
    x2 = __lsl_float_from_bits(__lsl_qbe_load64(platform.pointer(address) + 16))
    y2 = __lsl_float_from_bits(__lsl_qbe_load64(platform.pointer(address) + 24))
    return x2 > x1 and y2 > y1
end

# ---------------------------------------------------------------- stav u zpravy

function block_key(ctx, kind, source):
    if ctx.get("current_key"):
        return ctx["current_key"]
    end
    base = kind + ":" + rich_blocks.hash_text(source)
    counts = ctx.get("counts")
    if counts == None:
        return base
    end
    number = counts.get(base, 0)
    counts[base] = number + 1
    if number == 0:
        return base
    end
    return base + ":" + String(number)
end

function block_state(card):
    ctx = card["ctx"]
    store = ctx.get("store")
    if store == None:
        if "local_state" not in card:
            card["local_state"] = {}
        end
        return card["local_state"]
    end
    if type(store.get(card["key"])) != "Dictionary":
        store[card["key"]] = {}
    end
    return store[card["key"]]
end

function save_tick(state, arguments):
    now = time.monotonic()
    for item in save_queue["pending"].copy():
        if now >= item["at"]:
            call save_queue["pending"].remove(item)
            ctx = item["ctx"]
            if ctx.get("on_save") != None:
                try:
                    call ctx["on_save"](ctx)
                else:
                    call platform.stderr("LuxAI rich state: " + String(last_error()) + "\n")
                end
            end
        end
    end
end

function persist(card, delay=0.0):
    # ulozeni stavu interaktivniho bloku do konverzace (posuvnik: az po 0,6 s klidu)
    ctx = card["ctx"]
    if ctx.get("on_save") == None:
        return
    end
    if save_queue["tick"] == None:
        save_queue["tick"] = ui_dispatch.add_tick(save_tick)
    end
    # kontext obsahuje stav celeho okna: porovnavat jen identifikator, ne obsah slovniku
    for item in save_queue["pending"]:
        if item["ctx"].get("id") == ctx.get("id"):
            item["at"] = time.monotonic() + delay
            return
        end
    end
    save_queue["pending"].append({"ctx": ctx, "at": time.monotonic() + delay})
end

function flush_saves():
    for item in save_queue["pending"]:
        item["at"] = 0.0
    end
    call save_tick(None, None)
end

# ---------------------------------------------------------------- karta a export

function new_card(ctx, kind, source, spec):
    card = {"ctx": ctx, "kind": kind, "source": source, "spec": spec, "dark": Bool(ctx.get("dark")), "alive": True, "key": block_key(ctx, kind, source)}
    card["widget"] = box(True, 6, ["rich-card"])
    card["head"] = box(False, 4)
    title = ""
    if type(spec) == "Dictionary":
        title = String(common.fallback(spec.get("title"), ""))
    end
    heading = label(title, ["rich-title"], True)
    call gtk_ext.label_set_ellipsize(heading, 0)
    call pack(card["head"], heading, True)
    card["heading"] = heading
    call pack(card["widget"], card["head"])
    if not title:
        call gtk_ext.widget_set_no_show_all(heading, True)
    end
    call gtk_ext.connect(card["widget"], "destroy", card_destroyed, card)
    if registry["enabled"]:
        registry["cards"].append(card)
    end
    return card
end

function card_destroyed(card, widget):
    card["alive"] = False
    if card.get("pixbuf"):
        call glib.object_unref(card["pixbuf"])
        card["pixbuf"] = 0
    end
end

function add_tool(card, title, tooltip, handler):
    call gtk.box_pack_end(card["head"], tool_button(title, tooltip, handler, card), False, True, 0)
end

function copy_source(card, widget):
    call gui_bridge.copy_text(card["source"])
    call gtk.button_set_label(widget, tr("Copied"))
end

function save_path(card, title, name):
    toplevel = gtk_ext.widget_get_toplevel(card["widget"])
    dialog = gtk_ext.file_dialog(toplevel, title, 1, False, tr("Save"), tr("Cancel"))
    call gtk_ext.file_chooser_set_do_overwrite_confirmation(dialog, True)
    call gtk_ext.file_chooser_set_current_name(dialog, name)
    # slozka Obrazky (G_USER_DIRECTORY_PICTURES)
    folder = glib.from_c(__lsl_qbe_call1(__lsl_symbol("g_get_user_special_dir"), 4))
    if folder:
        call gtk_ext.file_chooser_set_current_folder(dialog, folder)
    end
    response = gtk_ext.dialog_run(dialog)
    path = glib.take_c(gtk_ext.file_chooser_get_filename(dialog))
    call gtk.widget_destroy(dialog)
    if response == -3 and path:
        return path
    end
    return ""
end

function export_name(card, extension):
    title = ""
    if type(card["spec"]) == "Dictionary" and type(card["spec"].get("title")) == "String":
        title = card["spec"]["title"]
    end
    clean = platform.regex_replace("[^A-Za-z0-9_\\- \\x{80}-\\x{10FFFF}]", "", title).strip().replace(" ", "-")[:60]
    if not clean:
        clean = "luxai-" + card["kind"]
    end
    return clean + "." + extension
end

function export_png(card, widget):
    path = save_path(card, tr("Export as PNG"), export_name(card, "png"))
    if path:
        call note(card, export_file(card, path, "png"))
    end
end

function export_svg(card, widget):
    path = save_path(card, tr("Export as SVG"), export_name(card, "svg"))
    if path:
        call note(card, export_file(card, path, "svg"))
    end
end

function export_csv(card, widget):
    path = save_path(card, tr("Export as CSV"), export_name(card, "csv"))
    if path:
        try:
            call common.atomic_text(path, table_csv(card["spec"]))
            call note(card, tr("Saved"))
        else:
            call note(card, tr("Could not save the file"))
        end
    end
end

function note(card, text):
    if card.get("note") == None:
        card["note"] = label("", ["rich-note"], True)
        call pack(card["widget"], card["note"])
    end
    call gtk.label_set_text(card["note"], text)
    call gtk.widget_show(card["note"])
end

function export_size(card):
    kind = card["kind"]
    if kind == "chart":
        return [640.0, Float(rich_draw.chart_height(card["spec"], 640))]
    elif kind == "diagram":
        layout = card["layout"]
        return rich_diagram.display_size(layout, max(640.0, layout["width"] + 24), card["diagram"]["kind"])
    elif kind == "math":
        return [card["box"]["w"] + 16, card["box"]["a"] + card["box"]["d"] + 16]
    elif kind == "svg":
        return [Float(card["size"][0]), Float(card["size"][1])]
    end
    return [400.0, 300.0]
end

function paint_export(card, cr, width, height, palette):
    call rich_draw.fill_background(cr, width, height, palette)
    kind = card["kind"]
    if kind == "chart":
        call rich_draw.draw_chart(cr, card["spec"], width, height, palette, None)
    elif kind == "diagram":
        call rich_diagram.draw(cr, card["diagram"], card["layout"], width, height, palette)
    elif kind == "math":
        call rich_math.draw(cr, card["box"], width, height, palette)
    end
end

function export_file(card, path, format):
    # PNG ve dvojnasobnem rozliseni, SVG pres cairo (SVG blok: uz sanitovany zdroj)
    try:
        palette = rich_draw.theme(card["dark"])
        if card["kind"] == "svg":
            if format == "svg":
                call common.atomic_text(path, rich_svg.sized(card["info"]["svg"], card["size"][0], card["size"][1]))
                return tr("Saved")
            end
            image = rich_svg.pixbuf(card["info"]["svg"], card["size"][0] * 2, card["size"][1] * 2)
            if image == 0:
                return tr("Could not save the file")
            end
            call __lsl_qbe_call5(__lsl_symbol("gdk_pixbuf_save"), platform.pointer(image), platform.cstr(path), platform.cstr("png"), 0, 0)
            call glib.object_unref(image)
            return tr("Saved")
        end
        size = export_size(card)
        surface = 0
        if format == "svg":
            surface = rich_draw.svg_surface(path, size[0], size[1])
        else:
            surface = rich_draw.png_surface(size[0], size[1], 2.0)
        end
        cr = cairo.create(surface)
        call paint_export(card, cr, size[0], size[1], palette)
        call cairo.destroy(cr)
        if format == "png":
            call cairo.surface_write_to_png(surface, path)
        end
        if not rich_draw.finish_surface(surface):
            return tr("Could not save the file")
        end
        return tr("Saved")
    else:
        return tr("Could not save the file")
    end
end

function error_widget(block, problem, dark):
    # neplatny blok: puvodni text jako kod + poznamka (aby nic nezmizelo)
    result = box(True, 4, ["md-code"])
    head = box(False, 6, ["md-code-head"])
    call pack(head, label(String(block.get("lang", "")), ["dim", "small"]))
    copy_state = {"source": block["text"]}
    call gtk.box_pack_end(head, tool_button("Copy", "Copy code", copy_raw, copy_state), False, True, 0)
    call pack(result, head)
    text = block["text"]
    if len(text) > 20000:
        text = text[:20000] + "\n…"
    end
    content = label(text, ["md-code-text"], False, None, True)
    scroller = gtk.scrolled_window_new()
    call gtk.scrolled_window_set_policy(scroller, 1, 2)
    call gtk.container_add(scroller, content)
    call gtk_ext.scrolled_window_set_propagate_natural_height(scroller, True)
    call gtk.scrolled_window_set_max_content_height(scroller, 320)
    call pack(result, scroller)
    warning = label(tr("This block could not be shown:") + " " + problem, ["rich-error"], True)
    call gtk_ext.widget_set_margin_start(warning, 12)
    call gtk_ext.widget_set_margin_bottom(warning, 6)
    call pack(result, warning)
    return result
end

function copy_raw(state, widget):
    call gui_bridge.copy_text(state["source"])
    call gtk.button_set_label(widget, tr("Copied"))
end

function placeholder(kind):
    name = tr(KIND_NAMES.get(kind, "Chart"))
    return label(tr("{0} – preparing…").replace("{0}", name), ["rich-placeholder"])
end

# ---------------------------------------------------------------- vstup z Markdownu

function keys_for(blocks):
    # klice stavu bohatych bloku v poradi zpravy (stejny blok vickrat: ":1", ":2" ...)
    counts = {}
    output = []
    for block in blocks:
        key = ""
        kind = ""
        if block.get("type") == "code":
            kind = rich_blocks.kind_of(block.get("lang"))
        elif block.get("type") == "table":
            kind = "mdtable"
        end
        if kind:
            text = block.get("text", "")
            if kind == "mdtable":
                text = json.encode([block["header"], block["rows"]])
            end
            base = kind + ":" + rich_blocks.hash_text(text)
            number = counts.get(base, 0)
            counts[base] = number + 1
            key = base
            if number > 0:
                key = base + ":" + String(number)
            end
        end
        output.append(key)
    end
    return output
end

function is_rich(block):
    return block.get("type") == "code" and rich_blocks.kind_of(block.get("lang")) != ""
end

function block_widget(block, ctx, final=True):
    # widget bohateho bloku; rozepsany blok (bez ```) = zastupny text, dokud odpoved neskonci
    kind = rich_blocks.kind_of(block.get("lang"))
    if not block.get("closed", True) and not final:
        return placeholder(kind)
    end
    parsed = rich_blocks.parse(kind, block["text"])
    if not parsed["ok"]:
        return error_widget(block, parsed["error"], ctx.get("dark"))
    end
    widget = 0
    try:
        widget = build(kind, block["text"], parsed["spec"], ctx)
    else:
        problem = String(last_error())
        for prefix in ["DiagramError: ", "SvgError: ", "MathError: ", "RichError: "]:
            if problem.startswith(prefix):
                problem = problem[len(prefix):]
            end
        end
        if ":" in problem and problem.split(":")[0].endswith("Error") and not problem.startswith("unsupported"):
            problem = problem.split(":")[0]
        end
        return error_widget(block, problem, ctx.get("dark"))
    end
    return widget
end

function build(kind, source, spec, ctx):
    if kind == "chart":
        return chart_card(ctx, source, spec)
    elif kind == "svg":
        return svg_card(ctx, source, spec)
    elif kind == "diagram":
        return diagram_card(ctx, source, spec)
    elif kind == "math":
        return math_widget(ctx, spec["source"], source)
    elif kind == "quiz":
        return quiz_card(ctx, source, spec)
    elif kind == "form":
        return form_card(ctx, source, spec)
    elif kind == "table":
        return table_card(ctx, source, spec)
    elif kind == "map":
        return map_card(ctx, source, spec)
    elif kind == "gallery":
        return gallery_card(ctx, source, spec)
    elif kind == "timeline":
        return timeline_card(ctx, source, spec)
    elif kind == "checklist":
        return checklist_card(ctx, source, spec)
    end
    Error(RichError: "unknown block type")
end

# ---------------------------------------------------------------- kresleni (graf, diagram, SVG, vzorec)

function drawing_area(card, width, height, focusable=False):
    area = classes(gtk.drawing_area_new(), ["rich-drawing"])
    call gtk.widget_set_size_request(area, width, height)
    call gtk_ext.connect(area, "draw", drawn, card, 1)
    if focusable:
        call gtk_ext.widget_set_can_focus(area, True)
        call gtk.widget_add_events(area, 4 | 256 | 1024 | 8192)
        call gtk_ext.connect(area, "motion-notify-event", pointer_moved, card, 1)
        call gtk_ext.connect(area, "leave-notify-event", pointer_left, card, 1)
        call gtk_ext.connect(area, "key-press-event", key_pressed, card, 1)
        call gtk_ext.connect(area, "button-press-event", pointer_pressed, card, 1)
    end
    card["area"] = area
    return area
end

function drawn(card, cr, widget):
    if not card["alive"] or not clip_visible(cr):
        return False
    end
    width = gtk.widget_get_allocated_width(widget)
    height = gtk.widget_get_allocated_height(widget)
    palette = rich_draw.theme(card["dark"])
    kind = card["kind"]
    started = time.monotonic()
    if kind == "chart":
        card["hits"] = rich_draw.draw_chart(cr, card["spec"], width, height, palette, card.get("hover"))
    elif kind == "diagram":
        call rich_diagram.draw(cr, card["diagram"], card["layout"], width, height, palette)
    elif kind == "math":
        call rich_math.draw(cr, card["box"], width, height, palette)
    elif kind == "svg":
        call draw_svg(card, cr, widget, width, height)
    end
    card["draw_ms"] = (time.monotonic() - started) * 1000.0
    card["draws"] = card.get("draws", 0) + 1
    return False
end

function draw_svg(card, cr, widget, width, height):
    scale = scale_factor(widget)
    if not card.get("pixbuf") or card.get("pixbuf_scale") != scale or card.get("pixbuf_width") != width:
        if card.get("pixbuf"):
            call glib.object_unref(card["pixbuf"])
        end
        # vykresli se jednou pri prvnim zobrazeni (a pri zmene meritka HiDPI)
        card["pixbuf"] = rich_svg.pixbuf(card["info"]["svg"], card["size"][0] * scale, card["size"][1] * scale)
        card["pixbuf_scale"] = scale
        card["pixbuf_width"] = width
        card["renders"] = card.get("renders", 0) + 1
    end
    if not card["pixbuf"]:
        return
    end
    left = max(0, (width - card["size"][0]) // 2)
    call cairo.save(cr)
    call cairo.translate(cr, left, 0)
    call cairo.scale(cr, 1.0 / scale, 1.0 / scale)
    call gtk.cairo_set_source_pixbuf(cr, card["pixbuf"], 0, 0)
    call cairo.paint(cr)
    call cairo.restore(cr)
end

function pointer_moved(card, event, widget):
    if card["kind"] != "chart" or not card.get("hits"):
        return False
    end
    found = rich_draw.hit_test(card["hits"], gtk.event_x(event), gtk.event_y(event))
    if found != card.get("hover"):
        card["hover"] = found
        call gtk.widget_queue_draw(widget)
    end
    return False
end

function pointer_left(card, event, widget):
    if card.get("hover") != None and not has_focus(widget):
        card["hover"] = None
        call gtk.widget_queue_draw(widget)
    end
    return False
end

function pointer_pressed(card, event, widget):
    call gtk_ext.widget_grab_focus(widget)
    return False
end

function key_pressed(card, event, widget):
    # sipky projdou hodnoty grafu (popisek jako pri najeti mysi), Esc popisek skryje
    key = gtk.event_key_keyval(event)
    hits = card.get("hits")
    if not hits:
        return False
    end
    if key == 65307:
        card["hover"] = None
        call gtk.widget_queue_draw(widget)
        return True
    end
    if key not in [65361, 65363, 65362, 65364]:
        return False
    end
    index = -1
    if card.get("hover") != None:
        for i in rang(len(hits)):
            if hits[i][4] == card["hover"][0] and hits[i][5] == card["hover"][1]:
                index = i
            end
        end
    end
    if key in [65363, 65364]:
        index = (index + 1) % len(hits)
    else:
        if index < 0:
            index = len(hits) - 1
        else:
            index = (index - 1 + len(hits)) % len(hits)
        end
    end
    card["hover"] = [hits[index][4], hits[index][5]]
    call gtk.widget_set_tooltip(widget, hits[index][6])
    call gtk.widget_queue_draw(widget)
    return True
end

function chart_card(ctx, source, spec):
    card = new_card(ctx, "chart", source, spec)
    # nadpis kresli graf sam (i do exportu)
    call gtk.widget_hide(card["heading"])
    call gtk_ext.widget_set_no_show_all(card["heading"], True)
    call add_tool(card, "SVG", "Export as SVG", export_svg)
    call add_tool(card, "PNG", "Export as PNG", export_png)
    call add_tool(card, "Copy", "Copy the block source", copy_source)
    area = drawing_area(card, 260, rich_draw.chart_height(spec, 600), True)
    call gtk_ext.widget_set_hexpand(area, True)
    call gtk.widget_set_tooltip(area, tr("Point at the chart or use the arrow keys to read the values"))
    call pack(card["widget"], area)
    return card["widget"]
end

function diagram_card(ctx, source, spec):
    diagram = rich_diagram.parse(spec["source"])
    layout = rich_diagram.measure(diagram, 600.0)
    card = new_card(ctx, "diagram", source, {"title": ""})
    card["diagram"] = diagram
    card["layout"] = layout
    call add_tool(card, "SVG", "Export as SVG", export_svg)
    call add_tool(card, "PNG", "Export as PNG", export_png)
    call add_tool(card, "Copy", "Copy the block source", copy_source)
    size = rich_diagram.display_size(layout, 600.0, diagram["kind"])
    area = drawing_area(card, size[0], size[1], False)
    if diagram["kind"] == "pie":
        call gtk_ext.widget_set_hexpand(area, True)
        call gtk.widget_set_size_request(area, 260, size[1])
        call pack(card["widget"], area)
        return card["widget"]
    end
    call gtk.widget_set_halign(area, 3)
    scroller = gtk.scrolled_window_new()
    call gtk.scrolled_window_set_policy(scroller, 1, 2)
    call gtk.container_add(scroller, area)
    call gtk_ext.scrolled_window_set_propagate_natural_height(scroller, True)
    call gtk_ext.scrolled_window_set_propagate_natural_width(scroller, False)
    call pack(card["widget"], scroller)
    return card["widget"]
end

function svg_card(ctx, source, spec):
    info = rich_svg.sanitize(spec["source"])
    card = new_card(ctx, "svg", source, {"title": ""})
    card["info"] = info
    card["size"] = rich_svg.display_size(info, 600.0, 560.0)
    call add_tool(card, "SVG", "Export as SVG", export_svg)
    call add_tool(card, "PNG", "Export as PNG", export_png)
    call add_tool(card, "Copy", "Copy the block source", copy_source)
    area = drawing_area(card, card["size"][0], card["size"][1], False)
    call gtk.widget_set_halign(area, 3)
    call pack(card["widget"], area)
    if info["removed"]:
        hidden = label(tr("Unsafe parts of this image were removed (scripts, links, external content)."), ["rich-note"], True)
        call pack(card["widget"], hidden)
    end
    return card["widget"]
end

function math_widget(ctx, tex, source=""):
    # zobrazeny vzorec; pri chybe sazby vrati 0 (volajici pouzije Pango markup)
    box_value = None
    try:
        box_value = rich_math.measure(tex, 17.0, True)
    else:
        return 0
    end
    card = {"ctx": ctx, "kind": "math", "source": common.fallback(source, tex), "spec": {"title": ""}, "dark": Bool(ctx.get("dark")), "alive": True, "box": box_value, "key": ""}
    width = Int(box_value["w"] + 9)
    height = Int(box_value["a"] + box_value["d"] + 9)
    area = drawing_area(card, min(width, 760), height, False)
    call gtk.widget_set_halign(area, 3)
    call gtk.widget_set_tooltip(area, tex[:300])
    call gtk_ext.connect(area, "destroy", card_destroyed, card)
    call gtk_ext.connect(area, "button-press-event", math_pressed, card, 1)
    call gtk.widget_add_events(area, 256)
    if registry["enabled"]:
        registry["cards"].append(card)
    end
    return area
end

function math_pressed(card, event, widget):
    # pravym tlacitkem kopie zdroje LaTeX
    if gtk.event_button(event) == 3:
        call gui_bridge.copy_text(card["source"])
        return True
    end
    return False
end

# ---------------------------------------------------------------- kviz

function shuffled_order(count, seed_text):
    order = []
    for i in rang(count):
        order.append(i)
    end
    seed = 0
    for char in rich_blocks.hash_text(seed_text):
        seed = (seed * 16 + "0123456789abcdef".find(char)) & 2147483647
    end
    i = count - 1
    while i > 0:
        seed = (seed * 1103515245 + 12345) & 2147483647
        j = seed % (i + 1)
        swap = order[i]
        order[i] = order[j]
        order[j] = swap
        i -= 1
    end
    return order
end

function quiz_card(ctx, source, spec):
    card = new_card(ctx, "quiz", source, spec)
    call add_tool(card, "Copy", "Copy the block source", copy_source)
    card["content"] = box(True, 10)
    call pack(card["widget"], card["content"])
    call quiz_build(card)
    return card["widget"]
end

function quiz_build(card):
    call gtk_ext.clear(card["content"])
    spec = card["spec"]
    state = block_state(card)
    if type(state.get("answers")) != "Dictionary":
        state["answers"] = {}
    end
    card["rows"] = []
    letters = "ABCDEFGHIJ"
    for qi in rang(len(spec["questions"])):
        question = spec["questions"][qi]
        row = {"index": qi, "buttons": {}, "checks": {}}
        part = box(True, 5)
        prefix = ""
        if len(spec["questions"]) > 1:
            prefix = String(qi + 1) + ". "
        end
        call pack(part, label("", ["rich-title"], True, "<b>" + glib.markup_escape(prefix) + "</b>" + markup_text(question["q"], card["dark"])))
        order = []
        for i in rang(len(question["options"])):
            order.append(i)
        end
        if spec["shuffle"]:
            order = shuffled_order(len(question["options"]), card["source"] + ":" + String(qi))
        end
        options = box(True, 4)
        position = 0
        for option in order:
            text = letters[position] + "   " + question["options"][option]
            binding = {"card": card, "question": qi, "option": option}
            if question["multiple"]:
                check = gtk.check_button_new(text)
                call classes(check, ["rich-option"])
                row["checks"][String(option)] = check
                call pack(options, check)
            else:
                choice = button(text, quiz_answered, binding, ["rich-option"])
                child = __lsl_qbe_call1(__lsl_symbol("gtk_bin_get_child"), platform.pointer(choice))
                if child:
                    call gtk_ext.label_set_xalign(child, 0.0)
                    call gtk_ext.label_set_line_wrap(child, True)
                end
                row["buttons"][String(option)] = choice
                call pack(options, choice)
            end
            position += 1
        end
        call pack(part, options)
        actions = box(False, 6)
        if question["multiple"]:
            row["check_button"] = button(tr("Check answer"), quiz_checked, {"card": card, "question": qi}, ["pill"])
            call pack(actions, row["check_button"])
        end
        if question["hint"]:
            row["hint_button"] = button(tr("Hint"), quiz_hint, {"card": card, "question": qi}, ["rich-tool", "flat"])
            call pack(actions, row["hint_button"])
        end
        call pack(part, actions)
        row["hint"] = label(tr("Hint:") + " " + question["hint"], ["rich-note"], True)
        call gtk_ext.widget_set_no_show_all(row["hint"], True)
        call pack(part, row["hint"])
        row["result"] = label("", None, True)
        call gtk_ext.widget_set_no_show_all(row["result"], True)
        call pack(part, row["result"])
        call pack(card["content"], part)
        card["rows"].append(row)
        if String(qi) in state.get("hints", []):
            call gtk.widget_show(row["hint"])
        end
        answer = state["answers"].get(String(qi))
        if type(answer) == "List":
            call quiz_show(card, qi, answer)
        end
    end
    footer = box(False, 8)
    card["score"] = label("", ["rich-title"])
    call pack(footer, card["score"], True)
    card["again"] = button(tr("Try again"), quiz_reset, card, ["pill"])
    call gtk_ext.widget_set_no_show_all(card["again"], True)
    call gtk.box_pack_end(footer, card["again"], False, True, 0)
    call pack(card["content"], footer)
    call quiz_score(card)
    call gtk.widget_show_all(card["content"])
end

function quiz_answered(binding, widget):
    card = binding["card"]
    state = block_state(card)
    key = String(binding["question"])
    if key in state["answers"]:
        return
    end
    state["answers"][key] = [binding["option"]]
    call quiz_show(card, binding["question"], [binding["option"]])
    call quiz_score(card)
    call persist(card)
end

function quiz_checked(binding, widget):
    card = binding["card"]
    state = block_state(card)
    key = String(binding["question"])
    row = card["rows"][binding["question"]]
    selected = []
    for option in row["checks"].keys():
        if gtk.toggle_button_get_active(row["checks"][option]):
            selected.append(Int(option))
        end
    end
    if not selected:
        return
    end
    selected.sort()
    state["answers"][key] = selected
    call quiz_show(card, binding["question"], selected)
    call quiz_score(card)
    call persist(card)
end

function quiz_hint(binding, widget):
    card = binding["card"]
    state = block_state(card)
    hints = state.get("hints", [])
    if String(binding["question"]) not in hints:
        hints.append(String(binding["question"]))
    end
    state["hints"] = hints
    call gtk.widget_show(card["rows"][binding["question"]]["hint"])
    call persist(card)
end

function quiz_show(card, qi, answer):
    question = card["spec"]["questions"][qi]
    row = card["rows"][qi]
    correct = question["correct"]
    widgets = row["buttons"]
    if question["multiple"]:
        widgets = row["checks"]
    end
    for option in widgets.keys():
        widget = widgets[option]
        number = Int(option)
        if question["multiple"]:
            call gtk.toggle_button_set_active(widget, number in answer)
        end
        if number in correct:
            call gtk.widget_add_class(widget, "rich-correct")
        elif number in answer:
            call gtk.widget_add_class(widget, "rich-wrong")
        end
        call gtk.widget_set_sensitive(widget, False)
    end
    if row.get("check_button"):
        call gtk.widget_set_sensitive(row["check_button"], False)
    end
    right = sorted(answer) == sorted(correct)
    verdict = ""
    if right:
        verdict = "<span weight=\"bold\" foreground=\"#1f9d55\">✓ " + glib.markup_escape(tr("Correct")) + "</span>"
    else:
        names = []
        letters = "ABCDEFGHIJ"
        verdict = "<span weight=\"bold\" foreground=\"#e5484d\">✗ " + glib.markup_escape(tr("Not quite")) + "</span>"
    end
    if question["explanation"]:
        verdict += "  " + markup_text(question["explanation"], card["dark"])
    end
    call gtk.label_set_markup(row["result"], verdict)
    call gtk.widget_show(row["result"])
end

function quiz_score(card):
    state = block_state(card)
    total = len(card["spec"]["questions"])
    answered = 0
    right = 0
    for qi in rang(total):
        answer = state["answers"].get(String(qi))
        if type(answer) == "List":
            answered += 1
            if sorted(answer) == sorted(card["spec"]["questions"][qi]["correct"]):
                right += 1
            end
        end
    end
    if answered == 0:
        call gtk.label_set_text(card["score"], "")
        return
    end
    text = tr("Score: {0} of {1}").replace("{0}", String(right)).replace("{1}", String(total))
    if answered < total:
        text += "  ·  " + tr("{0} left").replace("{0}", String(total - answered))
    else:
        call gtk.widget_show(card["again"])
    end
    call gtk.label_set_text(card["score"], text)
end

function quiz_reset(card, widget):
    state = block_state(card)
    state["answers"] = {}
    state["hints"] = []
    call quiz_build(card)
    call persist(card)
end

# ---------------------------------------------------------------- formular

function form_card(ctx, source, spec):
    card = new_card(ctx, "form", source, spec)
    call add_tool(card, "Copy", "Copy the block source", copy_source)
    if spec["description"]:
        call pack(card["widget"], label("", None, True, markup_text(spec["description"], card["dark"])))
    end
    state = block_state(card)
    if type(state.get("values")) != "Dictionary":
        state["values"] = {}
    end
    card["controls"] = {}
    grid = gtk.grid_new()
    call gtk.grid_set_row_spacing(grid, 6)
    call gtk.grid_set_column_spacing(grid, 10)
    row = 0
    actions = box(False, 6)
    for control in spec["controls"]:
        kind = control["type"]
        if kind == "button":
            action = control["action"]
            if action == "reset":
                call pack(actions, button(control["label"], form_reset, card, ["pill"]))
            end
            continue
        end
        ident = control["id"]
        value = state["values"].get(ident, control["value"])
        binding = {"card": card, "control": control}
        caption = label(control["label"], None, True)
        call gtk_ext.label_set_max_width_chars(caption, 24)
        widget = 0
        shown = label("", ["rich-value"])
        if kind == "slider":
            widget = gtk.scale_new_with_range(0, control["min"], control["max"], control["step"])
            call gtk.scale_set_draw_value(widget, False)
            call gtk.range_set_value(widget, form_number(value, control))
            call gtk_ext.widget_set_hexpand(widget, True)
            call gtk.widget_set_size_request(widget, 180, -1)
            call gtk_ext.connect(widget, "value-changed", form_changed, binding)
        elif kind == "number":
            widget = gtk.spin_button_new_with_range(control["min"], control["max"], control["step"])
            digits = 0
            if type(control["step"]) == "Float" and control["step"] < 1:
                digits = min(6, len(rich_draw.trim(String(control["step"]))) - 2)
            end
            call __lsl_qbe_call2(__lsl_symbol("gtk_spin_button_set_digits"), platform.pointer(widget), max(0, digits))
            call gtk.spin_button_set_value(widget, form_number(value, control))
            call gtk_ext.connect(widget, "value-changed", form_changed, binding)
        elif kind == "toggle":
            widget = gtk.switch_new()
            call gtk.switch_set_active(widget, Bool(value))
            call gtk.widget_set_halign(widget, 1)
            call gtk_ext.connect(widget, "notify::active", form_notify, binding, 1)
        elif kind == "checkbox":
            widget = gtk.check_button_new("")
            call gtk.toggle_button_set_active(widget, Bool(value))
            call gtk_ext.connect(widget, "toggled", form_changed, binding)
        elif kind == "select":
            widget = gtk.combo_box_text_new()
            active = 0
            for i in rang(len(control["options"])):
                option = control["options"][i]
                call gtk.combo_box_text_append(widget, String(i), option["label"])
                if option["value"] == value:
                    active = i
                end
            end
            call gtk.combo_box_set_active(widget, active)
            call gtk_ext.connect(widget, "changed", form_changed, binding)
        elif kind == "text":
            widget = gtk.entry_new()
            call gtk.entry_set_text(widget, String(value))
            if control.get("placeholder"):
                call gtk.entry_set_placeholder_text(widget, control["placeholder"])
            end
            call gtk_ext.widget_set_hexpand(widget, True)
            call gtk_ext.connect(widget, "changed", form_changed, binding)
        end
        if control["help"]:
            call gtk.widget_set_tooltip(widget, control["help"])
        end
        call gtk.grid_attach(grid, caption, 0, row, 1, 1)
        call gtk.grid_attach(grid, widget, 1, row, 1, 1)
        call gtk.grid_attach(grid, shown, 2, row, 1, 1)
        card["controls"][ident] = {"control": control, "widget": widget, "shown": shown}
        row += 1
    end
    call pack(card["widget"], grid)
    card["outputs"] = []
    if spec["outputs"]:
        results = box(True, 4)
        for output in spec["outputs"]:
            line = box(False, 8)
            call pack(line, label(output["label"], None, True), False)
            value_label = label("", ["rich-output"], True, None, True)
            call gtk.box_pack_end(line, value_label, False, True, 0)
            call pack(results, line)
            card["outputs"].append({"output": output, "label": value_label})
        end
        call pack(card["widget"], gtk.separator_new(0))
        call pack(card["widget"], results)
    end
    if spec["submit"]:
        title = spec["submit"]
        if title == "Send to LuxAI":
            title = tr(title)
        end
        send = button(title, form_send, card, ["pill", "primary"])
        call gtk.widget_set_tooltip(send, tr("Send these values to LuxAI as your next message"))
        call pack(actions, send)
        card["send_button"] = send
    end
    if gtk_ext.children(actions):
        call pack(card["widget"], actions)
    end
    call form_update(card)
    return card["widget"]
end

function form_number(value, control):
    number = rich_blocks.number_or(value, control["min"])
    return max(control["min"], min(control["max"], number))
end

function form_value(entry):
    control = entry["control"]
    widget = entry["widget"]
    kind = control["type"]
    if kind == "slider":
        value = gtk.range_get_value(widget)
        return snap(value, control)
    elif kind == "number":
        return snap(gtk.spin_button_get_value(widget), control)
    elif kind == "toggle":
        return gtk.switch_get_active(widget)
    elif kind == "checkbox":
        return gtk.toggle_button_get_active(widget)
    elif kind == "select":
        index = gtk.combo_box_get_active(widget)
        if index >= 0 and index < len(control["options"]):
            return control["options"][index]["value"]
        end
        return control["value"]
    elif kind == "text":
        return gtk.entry_get_text(widget)
    end
    return None
end

function snap(value, control):
    # hodnota na krok posuvniku; cele kroky jako Int
    step = control["step"]
    count = math_round((value - control["min"]) / step)
    result = control["min"] + count * step
    if type(step) == "Int" and type(control["min"]) == "Int":
        return Int(result)
    end
    return Float(rich_expr.fixed(result, 10))
end

function math_round(value):
    if value >= 0:
        return Int(value + 0.5)
    end
    return -Int(-value + 0.5)
end

function form_values(card):
    values = {}
    for ident in card["controls"].keys():
        values[ident] = form_value(card["controls"][ident])
    end
    return values
end

function form_update(card):
    values = form_values(card)
    for ident in card["controls"].keys():
        entry = card["controls"][ident]
        control = entry["control"]
        if control["type"] in ["slider", "number"]:
            call gtk.label_set_text(entry["shown"], rich_expr.format_value(values[ident], "", control["unit"]))
        elif control["type"] == "text" or control["type"] == "select":
            call gtk.label_set_text(entry["shown"], "")
        end
    end
    for item in card["outputs"]:
        output = item["output"]
        if output["error"]:
            call gtk.label_set_text(item["label"], "⚠ " + output["error"])
            continue
        end
        result = rich_expr.compute(output["expr"], values)
        if result[1] != None:
            call gtk.label_set_text(item["label"], "⚠ " + result[1])
        else:
            call gtk.label_set_text(item["label"], rich_expr.format_value(result[0], output["format"], output["unit"]))
        end
    end
    card["values"] = values
end

function form_changed(binding, widget):
    card = binding["card"]
    call form_update(card)
    state = block_state(card)
    state["values"] = card["values"]
    call persist(card, 0.6)
end

function form_notify(binding, pspec, widget):
    call form_changed(binding, widget)
end

function form_reset(card, widget):
    state = block_state(card)
    state["values"] = {}
    for ident in card["controls"].keys():
        entry = card["controls"][ident]
        control = entry["control"]
        kind = control["type"]
        if kind == "slider":
            call gtk.range_set_value(entry["widget"], control["value"])
        elif kind == "number":
            call gtk.spin_button_set_value(entry["widget"], control["value"])
        elif kind == "toggle":
            call gtk.switch_set_active(entry["widget"], Bool(control["value"]))
        elif kind == "checkbox":
            call gtk.toggle_button_set_active(entry["widget"], Bool(control["value"]))
        elif kind == "select":
            for i in rang(len(control["options"])):
                if control["options"][i]["value"] == control["value"]:
                    call gtk.combo_box_set_active(entry["widget"], i)
                end
            end
        elif kind == "text":
            call gtk.entry_set_text(entry["widget"], String(control["value"]))
        end
    end
    call form_update(card)
    state["values"] = {}
    call persist(card)
end

function form_message(card):
    # text dalsi zpravy uzivatele s hodnotami a vysledky (uzivatel ji odesila sam kliknutim)
    spec = card["spec"]
    title = spec["title"]
    if not title:
        title = tr("Calculator")
    end
    lines = [tr("My values in \"{0}\":").replace("{0}", title)]
    for control in spec["controls"]:
        if control["type"] == "button":
            continue
        end
        value = card["values"].get(control["id"])
        text = rich_expr.format_value(value, "", control["unit"])
        if control["type"] == "select":
            for option in control["options"]:
                if option["value"] == value:
                    text = option["label"]
                end
            end
        elif control["type"] in ["toggle", "checkbox"]:
            text = tr("yes")
            if not value:
                text = tr("no")
            end
        end
        lines.append("- " + control["label"] + ": " + text)
    end
    for item in card["outputs"]:
        lines.append("- " + item["output"]["label"] + ": " + gtk.label_get_text(item["label"]))
    end
    return "\n".join(lines)
end

function form_send(card, widget):
    ctx = card["ctx"]
    text = form_message(card)
    card["sent_text"] = text
    if ctx.get("on_send") != None:
        call ctx["on_send"](ctx, text)
    else:
        call gui_bridge.copy_text(text)
        call note(card, tr("Copied"))
    end
end

# ---------------------------------------------------------------- tabulka (```table i Markdown)

function sort_key(text):
    # [0, cislo] pro cisla (i "1 234,5 Kč", "12 %"), jinak [1, text bez velikosti pismen]
    value = String(text).strip()
    found = platform.regex_findall("^[^0-9+\\-.,]{0,4}\\s*([-+−]?\\s?[0-9][0-9  ]*(?:[.,][0-9]+)?)\\s*[^0-9]{0,6}$", value)
    if found:
        digits = found[0]["groups"][1].replace(" ", "").replace(" ", "").replace(" ", "").replace("−", "-").replace(",", ".")
        try:
            return [0, Float(digits), ""]
        else:
            return [1, 0.0, platform.casefold(value)]
        end
    end
    return [1, 0.0, platform.casefold(value)]
end

function text_less(a, b):
    # LSL neumi < pro texty: sorted() je stabilni a radi texty podle kodu znaku
    if a == b:
        return False
    end
    return sorted([a, b])[0] == a
end

function key_less(a, b):
    if a[0] != b[0]:
        return a[0] < b[0]
    end
    if a[0] == 0:
        return a[1] < b[1]
    end
    return text_less(a[2], b[2])
end

function sort_rows(items, descending):
    # stabilni sluckove razeni [klic, radek]
    if len(items) <= 1:
        return items.copy()
    end
    middle = len(items) // 2
    left = sort_rows(items[:middle], descending)
    right = sort_rows(items[middle:], descending)
    output = []
    i = 0
    j = 0
    while i < len(left) and j < len(right):
        take_right = key_less(right[j][0], left[i][0])
        if descending:
            take_right = key_less(left[i][0], right[j][0])
        end
        if take_right:
            output.append(right[j])
            j += 1
        else:
            output.append(left[i])
            i += 1
        end
    end
    output.extend(left[i:])
    output.extend(right[j:])
    return output
end

function sorted_table_rows(rows, column, descending):
    items = []
    for row in rows:
        value = ""
        if column < len(row):
            value = row[column]
        end
        items.append([sort_key(value), row])
    end
    output = []
    for item in sort_rows(items, descending):
        output.append(item[1])
    end
    return output
end

function csv_cell(value):
    text = String(value)
    if platform.regex_test("[\",\\n\\r;]", text) or text.startswith(" ") or text.endswith(" "):
        return "\"" + text.replace("\"", "\"\"") + "\""
    end
    # vzorce tabulkoveho procesoru se neexportuji jako vzorce (=, +, -, @)
    if text and text[0] in "=+@" :
        return "'" + text
    end
    return text
end

function table_csv(spec):
    lines = []
    cells = []
    for name in spec["columns"]:
        cells.append(csv_cell(name))
    end
    lines.append(",".join(cells))
    for row in spec["rows"]:
        cells = []
        for value in row:
            cells.append(csv_cell(value))
        end
        lines.append(",".join(cells))
    end
    return "\r\n".join(lines) + "\r\n"
end

function table_card(ctx, source, spec, markdown_cells=False):
    card = new_card(ctx, "table", source, spec)
    card["markdown"] = markdown_cells
    call add_tool(card, "CSV", "Export as CSV", export_csv)
    call add_tool(card, "Copy CSV", "Copy the table as CSV", table_copy)
    state = block_state(card)
    grid = classes(gtk.grid_new(), ["md-table"])
    call gtk.widget_set_halign(grid, 1)
    card["grid"] = grid
    scroller = gtk.scrolled_window_new()
    # kratka tabulka v plne vysce, dlouha se svislym posuvnikem (propagace prirozene vysky
    # se svislym posuvnikem v GTK 3 tabulku orizne na jeden radek)
    if len(spec["rows"]) <= 25:
        call gtk.scrolled_window_set_policy(scroller, 1, 2)
        call gtk_ext.scrolled_window_set_propagate_natural_height(scroller, True)
    else:
        call gtk.scrolled_window_set_policy(scroller, 1, 1)
        call gtk.scrolled_window_set_min_content_height(scroller, 420)
    end
    call gtk.container_add(scroller, grid)
    call pack(card["widget"], scroller)
    card["count_note"] = label("", ["rich-note"])
    call gtk_ext.widget_set_no_show_all(card["count_note"], True)
    call pack(card["widget"], card["count_note"])
    call table_fill(card)
    return card["widget"]
end

function table_fill(card):
    call gtk_ext.clear(card["grid"])
    spec = card["spec"]
    state = block_state(card)
    sort = state.get("sort")
    rows = spec["rows"]
    if type(sort) == "List" and len(sort) == 2 and type(sort[0]) == "Int" and sort[0] < len(spec["columns"]):
        rows = sorted_table_rows(rows, sort[0], sort[1] == "desc")
    else:
        sort = None
    end
    for column in rang(len(spec["columns"])):
        title = spec["columns"][column]
        arrow = ""
        if sort != None and sort[0] == column:
            arrow = "  ▲"
            if sort[1] == "desc":
                arrow = "  ▼"
            end
        end
        head = button(title + arrow, table_sort, {"card": card, "column": column}, ["rich-head"])
        child = __lsl_qbe_call1(__lsl_symbol("gtk_bin_get_child"), platform.pointer(head))
        if child:
            call gtk_ext.label_set_xalign(child, 0.0)
        end
        call gtk.widget_set_tooltip(head, tr("Sort by this column"))
        call gtk.grid_attach(card["grid"], head, column, 0, 1, 1)
    end
    shown = min(len(rows), MAX_TABLE_ROWS)
    for r in rang(shown):
        row = rows[r]
        for column in rang(len(spec["columns"])):
            value = ""
            if column < len(row):
                value = row[column]
            end
            cell = None
            if card["markdown"]:
                cell = label("", ["rich-cell"], False, markup_text(value, card["dark"]), True)
            else:
                cell = label(value, ["rich-cell"], False, None, True)
            end
            # zalamovat jen dlouhe bunky: zalomitelne popisky v mrizce pod posuvnikem si GTK 3
            # meri pri nejmensi sirce a tabulka by pak mela pod radky prazdne misto
            if len(value) > 48:
                call gtk_ext.label_set_max_width_chars(cell, 48)
                call gtk_ext.label_set_line_wrap(cell, True)
                call gtk_ext.label_set_line_wrap_mode(cell, 2)
            end
            if sort_key(value)[0] == 0 and not card["markdown"]:
                call gtk_ext.label_set_xalign(cell, 1.0)
            end
            call gtk.grid_attach(card["grid"], cell, column, r + 1, 1, 1)
        end
    end
    if len(rows) > shown:
        call gtk.label_set_text(card["count_note"], tr("Showing {0} of {1} rows (CSV export contains all)").replace("{0}", String(shown)).replace("{1}", String(len(rows))))
        call gtk.widget_show(card["count_note"])
    end
    call gtk.widget_show_all(card["grid"])
end

function table_sort(binding, widget):
    card = binding["card"]
    state = block_state(card)
    sort = state.get("sort")
    direction = "asc"
    if type(sort) == "List" and len(sort) == 2 and sort[0] == binding["column"] and sort[1] == "asc":
        direction = "desc"
    end
    state["sort"] = [binding["column"], direction]
    call table_fill(card)
    call persist(card)
end

function table_copy(card, widget):
    call gui_bridge.copy_text(table_csv(card["spec"]))
    call gtk.button_set_label(widget, tr("Copied"))
end

function markdown_table(block, ctx):
    # Markdown tabulka se stejnym razenim a exportem CSV jako ```table
    spec = {"title": "", "columns": block["header"], "rows": block["rows"]}
    width = len(spec["columns"])
    for row in spec["rows"]:
        width = max(width, len(row))
    end
    columns = spec["columns"].copy()
    while len(columns) < width:
        columns.append("")
    end
    rows = []
    for row in spec["rows"]:
        cells = row.copy()
        while len(cells) < width:
            cells.append("")
        end
        rows.append(cells)
    end
    spec["columns"] = columns
    spec["rows"] = rows
    source = "|" + "|".join(block["header"]) + "|\n"
    for row in block["rows"]:
        source += "|" + "|".join(row) + "|\n"
    end
    return table_card(ctx, source, spec, True)
end

# ---------------------------------------------------------------- mapa

function encode_signed(value):
    number = value << 1
    if value < 0:
        number = ~number
    end
    output = ""
    while number >= 32:
        output += chr((32 | (number & 31)) + 63)
        number = number >> 5
    end
    return output + chr(number + 63)
end

function encode_polyline(points, precision=6):
    # Google polyline (stejne jako luxos-maps encode_polyline)
    factor = 10 ^ precision
    output = ""
    last_lat = 0
    last_lon = 0
    for point in points:
        lat = math_round(point["lat"] * factor)
        lon = math_round(point["lon"] * factor)
        output += encode_signed(lat - last_lat) + encode_signed(lon - last_lon)
        last_lat = lat
        last_lon = lon
    end
    return output
end

function map_preview(spec):
    points = []
    for marker in spec["markers"]:
        points.append(marker)
    end
    if not points and spec["route"]:
        points = [spec["route"][0], spec["route"][len(spec["route"]) - 1]]
    end
    if not points and spec["center"] != None:
        points = [spec["center"]]
    end
    first = points[0]
    last = points[len(points) - 1]
    preview = {"version": 1, "mode": "car", "start": {"lat": first["lat"], "lon": first["lon"], "label": first["label"]}, "end": {"lat": last["lat"], "lon": last["lon"], "label": last["label"]}, "legs": [], "attribution": "© OpenStreetMap contributors"}
    if len(spec["route"]) >= 2:
        preview["legs"].append({"mode": "CAR", "label": "", "color": "#3d7bff", "polyline": encode_polyline(spec["route"], 6), "precision": 6})
    end
    return preview
end

function map_open_arguments(spec):
    if len(spec["route"]) >= 2:
        a = spec["route"][0]
        b = spec["route"][len(spec["route"]) - 1]
        return ["--route", coordinate_text(a), coordinate_text(b)]
    end
    target = spec["center"]
    if spec["markers"]:
        target = spec["markers"][0]
    end
    return [coordinate_text(target)]
end

function coordinate_text(point):
    text = rich_expr.fixed(point["lat"], 6) + "," + rich_expr.fixed(point["lon"], 6)
    label_text = String(point.get("label", "")).replace("(", "").replace(")", "")
    if label_text:
        text += "(" + label_text + ")"
    end
    return text
end

function network_policy(ctx):
    if ctx.get("network") != None:
        try:
            return String(ctx["network"](ctx))
        else:
            return "ask"
        end
    end
    return "ask"
end

function map_card(ctx, source, spec):
    card = new_card(ctx, "map", source, spec)
    call add_tool(card, "Copy", "Copy the block source", copy_source)
    card["picture"] = box(True, 4)
    call pack(card["widget"], card["picture"])
    places = box(True, 2)
    number = 1
    for marker in spec["markers"]:
        text = String(number) + ". " + common.fallback(marker["label"], tr("Place")) + "  ·  " + rich_expr.fixed(marker["lat"], 5) + ", " + rich_expr.fixed(marker["lon"], 5)
        call pack(places, label(text, ["rich-note"], True, None, True))
        number += 1
    end
    if not spec["markers"] and spec["center"] != None:
        call pack(places, label(rich_expr.fixed(spec["center"]["lat"], 5) + ", " + rich_expr.fixed(spec["center"]["lon"], 5), ["rich-note"], False, None, True))
    end
    call pack(card["widget"], places)
    actions = box(False, 6)
    card["actions"] = actions
    if maps.program() != None:
        card["show_button"] = button(tr("Show map"), map_allowed, card, ["pill"])
        call gtk.widget_set_tooltip(card["show_button"], tr("Downloads map tiles from OpenStreetMap through LuxOS Maps"))
        call pack(actions, card["show_button"])
        call pack(actions, button(tr("Open in Maps"), map_open, card, ["pill"]))
    else:
        call pack(actions, label(tr("Install LuxOS Maps to see the map."), ["rich-note"]))
    end
    call pack(card["widget"], actions)
    state = block_state(card)
    policy = network_policy(ctx)
    if maps.program() != None:
        if policy == "never":
            call gtk.widget_set_sensitive(card["show_button"], False)
            call gtk.widget_set_tooltip(card["show_button"], tr("Network access is turned off in LuxAI settings."))
        elif policy == "allow" or state.get("allowed"):
            call map_start(card)
        end
    end
    return card["widget"]
end

function map_allowed(card, widget):
    state = block_state(card)
    state["allowed"] = True
    call persist(card)
    call map_start(card)
end

function map_start(card):
    if card.get("loading"):
        return
    end
    card["loading"] = True
    if card.get("show_button"):
        # pozdejsi show_all bubliny ho nesmi znovu ukazat
        call gtk_ext.widget_set_no_show_all(card["show_button"], True)
        call gtk.widget_hide(card["show_button"])
    end
    card["spinner"] = gtk_ext.spinner_new()
    call gtk_ext.spinner_start(card["spinner"])
    call pack(card["picture"], card["spinner"])
    call gtk.widget_show_all(card["picture"])
    call ui_dispatch.background(map_worker, card, map_preview(card["spec"]))
end

function map_worker(card, preview):
    path = None
    try:
        path = maps.render(preview)
    else:
        path = None
    end
    call ui_dispatch.post(map_done, card, path)
    return path
end

function map_done(card, path):
    if not card["alive"]:
        return
    end
    card["loading"] = False
    if card.get("spinner"):
        call gtk.widget_destroy(card["spinner"])
        card["spinner"] = None
    end
    image = 0
    if path:
        image = gtk.pixbuf_new_from_file_at_scale(path, 560, 320, True)
    end
    if image:
        picture = gtk.image_new_from_pixbuf(image)
        call glib.object_unref(image)
        call gtk.widget_set_halign(picture, 1)
        call pack(card["picture"], picture)
        call pack(card["picture"], label("Map data © OpenStreetMap contributors", ["rich-note"]))
    else:
        call pack(card["picture"], label(tr("The map could not be loaded."), ["rich-note"]))
    end
    call gtk.widget_show_all(card["picture"])
end

function map_open(card, widget):
    if not maps.open_in_maps(map_open_arguments(card["spec"])):
        call note(card, tr("LuxOS Maps could not be opened."))
    end
end

# ---------------------------------------------------------------- galerie

function image_cache_dir():
    base = common.environment("XDG_CACHE_HOME", common.join(glib.home_dir(), ".cache"))
    return common.join(base, "luxai/rich-images")
end

function image_kind(data):
    # jen rastrove formaty (zadne SVG - to by obeslo sanitaci): PNG, JPEG, GIF, WebP
    if len(data) < 12:
        return ""
    end
    if data[0] == 137 and data[1] == 80 and data[2] == 78 and data[3] == 71:
        return "png"
    elif data[0] == 255 and data[1] == 216 and data[2] == 255:
        return "jpg"
    elif data[0] == 71 and data[1] == 73 and data[2] == 70 and data[3] == 56:
        return "gif"
    elif data[0] == 82 and data[1] == 73 and data[2] == 70 and data[3] == 70 and data[8] == 87 and data[9] == 69 and data[10] == 66 and data[11] == 80:
        return "webp"
    end
    return ""
end

function cached_image(url):
    folder = image_cache_dir()
    name = rich_blocks.hash_text(url) + rich_blocks.hash_text("luxai:" + url)
    for extension in ["png", "jpg", "gif", "webp"]:
        path = common.join(folder, name + "." + extension)
        if exists(path):
            return path
        end
    end
    return ""
end

function download_image(url, fetcher=None):
    # stazeni pres web.request (jen verejne adresy, kontrola presmerovani, limit velikosti)
    found = cached_image(url)
    if found:
        return found
    end
    if fetcher == None:
        fetcher = web.new_fetcher(None, None, 30)
    end
    response = web.request(fetcher, url, "GET", None, None, MAX_IMAGE_BYTES)
    if response["status"] != 200 or response.get("truncated"):
        return ""
    end
    data = response["data"]
    kind = image_kind(data)
    if not kind:
        return ""
    end
    folder = image_cache_dir()
    call common.mkdir_private(folder)
    path = common.join(folder, rich_blocks.hash_text(url) + rich_blocks.hash_text("luxai:" + url) + "." + kind)
    call common.atomic_bytes(path, data)
    return path
end

function gallery_card(ctx, source, spec):
    card = new_card(ctx, "gallery", source, spec)
    call add_tool(card, "Copy", "Copy the block source", copy_source)
    card["index"] = 0
    card["paths"] = {}
    card["stage"] = box(True, 6)
    call pack(card["widget"], card["stage"])
    state = block_state(card)
    policy = network_policy(ctx)
    hosts = []
    for image in spec["images"]:
        host = platform.regex_replace("(?i)^https?://([^/:?#]+).*$", "\\1", image["url"])
        if host not in hosts:
            hosts.append(host)
        end
    end
    card["hosts"] = hosts
    cached = True
    for image in spec["images"]:
        if not cached_image(image["url"]):
            cached = False
        end
    end
    if cached or policy == "allow" or (state.get("allowed") and policy != "never"):
        call gallery_start(card)
    else:
        call gallery_consent(card, policy)
    end
    return card["widget"]
end

function gallery_consent(card, policy):
    call gtk_ext.clear(card["stage"])
    count = len(card["spec"]["images"])
    text = tr("Images from the internet: {0}").replace("{0}", String(count)) + " · " + ", ".join(card["hosts"][:5])
    call pack(card["stage"], label(text, ["rich-note"], True))
    if policy == "never":
        call pack(card["stage"], label(tr("Network access is turned off in LuxAI settings."), ["rich-error"], True))
    else:
        load_button = button(tr("Load images"), gallery_allowed, card, ["pill"])
        call gtk.widget_set_tooltip(load_button, tr("LuxAI downloads the images only after you allow it"))
        call gtk.widget_set_halign(load_button, 1)
        call pack(card["stage"], load_button)
    end
    call gtk.widget_show_all(card["stage"])
end

function gallery_allowed(card, widget):
    state = block_state(card)
    state["allowed"] = True
    call persist(card)
    call gallery_start(card)
end

function gallery_start(card):
    call gtk_ext.clear(card["stage"])
    card["image"] = gtk.image_new_from_icon_name("image-loading-symbolic", 6)
    call gtk.widget_set_size_request(card["image"], -1, 200)
    events = gtk.event_box_new()
    call gtk.container_add(events, card["image"])
    call gtk_ext.widget_set_can_focus(events, True)
    call gtk.widget_add_events(events, 1024 | 256)
    call gtk_ext.connect(events, "key-press-event", gallery_key, card, 1)
    call gtk_ext.connect(events, "button-press-event", gallery_click, card, 1)
    call pack(card["stage"], events)
    card["caption"] = label("", ["rich-note"], True)
    call gtk_ext.label_set_justify(card["caption"], 2)
    call gtk_ext.label_set_xalign(card["caption"], 0.5)
    call pack(card["stage"], card["caption"])
    controls = box(False, 6)
    call gtk.widget_set_halign(controls, 3)
    card["previous"] = button("‹", gallery_previous, card, ["pill"])
    call gtk.widget_set_tooltip(card["previous"], tr("Previous image"))
    card["counter"] = label("", ["rich-note"])
    card["next"] = button("›", gallery_next, card, ["pill"])
    call gtk.widget_set_tooltip(card["next"], tr("Next image"))
    call pack(controls, card["previous"])
    call pack(controls, card["counter"])
    call pack(controls, card["next"])
    if len(card["spec"]["images"]) > 1:
        call pack(card["stage"], controls)
    end
    call gtk.widget_show_all(card["stage"])
    call gallery_show(card)
    for image in card["spec"]["images"]:
        call ui_dispatch.background(gallery_worker, card, image["url"])
    end
end

function gallery_worker(card, url):
    path = ""
    try:
        path = download_image(url)
    else:
        path = ""
    end
    call ui_dispatch.post(gallery_loaded, card, [url, path])
    return path
end

function gallery_loaded(card, result):
    if not card["alive"]:
        return
    end
    card["paths"][result[0]] = result[1]
    call gallery_show(card)
end

function gallery_show(card):
    images = card["spec"]["images"]
    index = card["index"]
    item = images[index]
    call gtk.label_set_text(card["caption"], item["caption"])
    call gtk.label_set_text(card["counter"], String(index + 1) + " / " + String(len(images)))
    path = card["paths"].get(item["url"])
    if path == None:
        call gtk.image_set_from_icon_name(card["image"], "image-loading-symbolic", 6)
        return
    end
    pixbuf = 0
    if path:
        pixbuf = gtk.pixbuf_new_from_file_at_scale(path, 540, 360, True)
    end
    if pixbuf:
        call gtk.image_set_from_pixbuf(card["image"], pixbuf)
        call glib.object_unref(pixbuf)
    else:
        call gtk.image_set_from_icon_name(card["image"], "image-missing-symbolic", 6)
        call gtk.label_set_text(card["caption"], item["caption"] + "  (" + tr("could not be loaded") + ")")
    end
end

function gallery_previous(card, widget):
    card["index"] = (card["index"] - 1 + len(card["spec"]["images"])) % len(card["spec"]["images"])
    call gallery_show(card)
end

function gallery_next(card, widget):
    card["index"] = (card["index"] + 1) % len(card["spec"]["images"])
    call gallery_show(card)
end

function gallery_key(card, event, widget):
    key = gtk.event_key_keyval(event)
    if key in [65361, 65362]:
        call gallery_previous(card, widget)
        return True
    elif key in [65363, 65364, 32]:
        call gallery_next(card, widget)
        return True
    end
    return False
end

function gallery_click(card, event, widget):
    call gtk_ext.widget_grab_focus(widget)
    return False
end

# ---------------------------------------------------------------- casova osa, kontrolni seznam

function timeline_card(ctx, source, spec):
    card = new_card(ctx, "timeline", source, spec)
    call add_tool(card, "Copy", "Copy the block source", copy_source)
    items = box(True, 0)
    for item in spec["items"]:
        row = box(True, 1, ["rich-item"])
        if item["date"]:
            call pack(row, label(item["date"], ["rich-date"], True, None, True))
        end
        if item["title"]:
            call pack(row, label("", None, True, "<b>" + markup_text(item["title"], card["dark"]) + "</b>", True))
        end
        if item["text"]:
            call pack(row, label("", None, True, markup_text(item["text"], card["dark"]), True))
        end
        call pack(items, row)
    end
    call pack(card["widget"], items)
    return card["widget"]
end

function checklist_card(ctx, source, spec):
    card = new_card(ctx, "checklist", source, spec)
    call add_tool(card, "Copy", "Copy the block source", copy_source)
    state = block_state(card)
    if type(state.get("done")) != "List":
        done = []
        for i in rang(len(spec["items"])):
            if spec["items"][i]["done"]:
                done.append(i)
            end
        end
        state["done"] = done
    end
    card["checks"] = []
    items = box(True, 2)
    for i in rang(len(spec["items"])):
        check = gtk.check_button_new("")
        child = __lsl_qbe_call1(__lsl_symbol("gtk_bin_get_child"), platform.pointer(check))
        text = label("", None, True, markup_text(spec["items"][i]["text"], card["dark"]))
        if child:
            call gtk.container_remove(check, child)
        end
        call gtk.container_add(check, text)
        call gtk.toggle_button_set_active(check, i in state["done"])
        call gtk_ext.connect(check, "toggled", checklist_toggled, {"card": card, "index": i})
        card["checks"].append([check, text])
        call pack(items, check)
    end
    call pack(card["widget"], items)
    card["progress"] = label("", ["rich-note"])
    call pack(card["widget"], card["progress"])
    call checklist_update(card)
    return card["widget"]
end

function checklist_toggled(binding, widget):
    card = binding["card"]
    state = block_state(card)
    done = []
    for i in rang(len(card["checks"])):
        if gtk.toggle_button_get_active(card["checks"][i][0]):
            done.append(i)
        end
    end
    state["done"] = done
    call checklist_update(card)
    call persist(card)
end

function checklist_update(card):
    state = block_state(card)
    for i in rang(len(card["checks"])):
        text = card["checks"][i][1]
        if i in state["done"]:
            call gtk.widget_add_class(text, "rich-done")
        else:
            call gtk.widget_remove_class(text, "rich-done")
        end
    end
    call gtk.label_set_text(card["progress"], tr("{0} of {1} done").replace("{0}", String(len(state["done"]))).replace("{1}", String(len(card["checks"]))))
end
