# Concrete native tool backend. GTK-specific operations are supplied by a GUI
# bridge; all ordinary command/file operations work without GTK or Python.
load common
load platform
load child_process
load glib
load catalog
load safety
load rootguard
load rootmode
load tool_format
load docs
load feedback
load api
load i18n
load time
load shellwords
load web
load maps
load calendar
load calendar_data
load weather
load weather_data

function new_tools(workdir=None, gui=None, timeout=120, vision=False, environment=None, blocked=None, client=None, chat=False):
    home = glib.home_dir()
    blocked_paths = safety.folders(blocked, home)
    if environment == None:
        environment = child_process.environment()
    end
    # kalendar LuxOS (jen nativni): v Chatu jen cteni, zmeny v Agentovi s potvrzenim
    definitions = catalog.TOOL_DEFS + calendar_data.TOOL_DEFS + weather_data.TOOL_DEFS
    if chat:
        definitions = catalog.DOCS_TOOL_DEFS + catalog.WEB_TOOL_DEFS + catalog.MAP_TOOL_DEFS + calendar_data.READ_DEFS + weather_data.TOOL_DEFS
    end
    return {"home": home, "workdir": common.fallback(workdir, home), "gui": gui, "timeout": timeout, "vision": vision, "env": environment, "blocked": blocked_paths, "client": client, "root_mode": "password", "model": "", "signal": child_process.new_signal(), "definitions": definitions, "execute": execute_callback, "prepare": prepare_callback, "cancel": cancel, "chat": chat, "web": {"web_search": web.tool_search, "web_fetch": web.tool_fetch}}
end

function execute_callback(state, name, arguments, prepared):
    return execute(state, name, arguments, prepared)
end

function prepare_callback(state, name, arguments, allow_screenshot):
    return prepare(state, name, arguments, allow_screenshot)
end

function path(state, value):
    return safety.expand(common.fallback(value, "."), state["workdir"], state["home"])
end

function cancelled(state):
    return child_process.cancelled(state["signal"])
end

function cancel(state):
    call child_process.cancel(state["signal"])
end

function child_env(state):
    env = common.copy(state["env"])
    for key in ["LUXAI_AGENT", "PAGER", "GIT_PAGER", "TERM", "SYSTEMD_PAGER", "DEBIAN_FRONTEND"]:
        env[key] = {"LUXAI_AGENT": "1", "PAGER": "cat", "GIT_PAGER": "cat", "TERM": "dumb", "SYSTEMD_PAGER": "", "DEBIAN_FRONTEND": "noninteractive"}[key]
    end
    return common.without(env, "LUXAI_ORIGIN")
end

function fail(message):
    Error(ToolError: message)
end

function clean_error(text):
    for prefix in ["ToolError: ", "FileError: ", "ProcessError: ", "FeedbackError: ", "WebError: ", "ValueError: ", "TypeError: "]:
        if text.startswith(prefix):
            return text[len(prefix):]
        end
    end
    return text
end

function run(state, argv, timeout=20, input_text=None, check=True):
    if state.get("runner") != None:
        return state["runner"](state, argv, timeout, input_text, check)
    end
    if not glib.find_program_in_path(argv[0]):
        call fail(argv[0] + " is not installed")
    end
    result = child_process.run(argv, state["workdir"], child_env(state), timeout, state["signal"], input_text, False, False, False, False)
    if result["timed_out"]:
        call fail(argv[0] + " timed out")
    end
    if check and result["exit_code"] != 0:
        message = common.fallback(result["stderr"], common.fallback(result["output"], argv[0] + " failed (" + String(result["exit_code"]) + ")"))
        call fail(String(common.strip_text(message))[:2000])
    end
    return {"stdout": result["output"], "stderr": result["stderr"], "returncode": result["exit_code"]}
end

function spawn(state, argv):
    if state.get("spawner") != None:
        call state["spawner"](state, argv)
        return
    end
    if not glib.find_program_in_path(argv[0]):
        call fail(argv[0] + " is not installed")
    end
    call child_process.spawn(argv, state["workdir"], child_env(state))
end

function run_command(state, arguments):
    command = String(arguments["command"])
    if not common.strip_text(command):
        call fail("Empty command")
    end
    workdir = state["workdir"]
    if arguments.get("cwd"):
        workdir = path(state, arguments["cwd"])
    end
    info = platform.file_info(workdir)
    if info == None or not info["directory"]:
        call fail("Working folder does not exist: " + workdir)
    end
    limit = state["timeout"]
    try:
        if arguments.get("timeout"):
            limit = Int(arguments["timeout"])
        end
    else:
        limit = state["timeout"]
    end
    limit = max(1, min(limit, 1800))
    root = rootmode.flag(arguments.get("root"))
    reason = rootguard.hard_block(command, root, workdir, state["home"])
    if reason:
        return {"ok": False, "blocked": True, "error": "Refused by LuxAI safety rules: " + reason + ". Do not try to bypass this."}
    end
    mode = state["root_mode"]
    wall = limit
    argv = [common.fallback(glib.find_program_in_path("bash"), "/bin/sh"), "-c", command]
    if root:
        if not rootmode.available():
            call fail("Running as administrator is not available (pkexec or the LuxAI helper is missing)")
        end
        if mode not in rootmode.MODES:
            mode = "password"
        end
        argv = rootmode.helper_argv(mode, command, workdir, limit)
        wall = limit + 30
        if mode == "password":
            wall = limit + 300
        end
    end
    native = child_process.run(argv, workdir, child_env(state), wall, state["signal"], None, root)
    text = native["output"]
    if native["truncated"]:
        text += "\n… [output larger than 2 MB was cut]"
    end
    code = native["exit_code"]
    timeout = native["timed_out"]
    stopped = native["cancelled"]
    result = {"ok": code == 0 and not timeout and not stopped, "exit_code": code, "output": tool_format.clip_text(text, 24000), "duration_s": native["duration_s"]}
    if root:
        result["as_administrator"] = True
        if code == 130 and not timeout:
            stopped = True
        elif code == 124:
            timeout = True
        else:
            message = rootmode.exit_message(code)
            if message:
                result["error"] = message
                if code == 125:
                    result["blocked"] = True
                end
            end
        end
        call rootmode.log_command(mode, state["model"], command, code, native["duration_s"])
    end
    if timeout:
        result["error"] = "Command timed out after " + String(limit) + " s and was stopped"
    end
    if stopped:
        result["error"] = "Command was stopped by the user"
        result["cancelled"] = True
    end
    return result
end

function read_file(state, arguments):
    filename = path(state, arguments["path"])
    info = platform.file_info(filename)
    if info == None:
        call fail("No such file: " + filename)
    end
    if info["directory"]:
        call fail(filename + " is a folder; use list_directory")
    end
    if info["size"] > 4194304:
        call fail("File is too large to read (" + String(info["size"]) + " bytes)")
    end
    raw = platform.read_prefix(filename, 4194305)
    for index in rang(min(8192, len(raw))):
        if raw[index] == 0:
            call fail("File looks binary; not reading it")
        end
    end
    lines = common.splitlines(platform.utf8_decode(raw))
    start = 1
    count = 200
    try:
        start = max(1, Int(common.fallback(arguments.get("start_line"), 1)))
        count = max(1, min(Int(common.fallback(arguments.get("line_count"), 200)), 2000))
    else:
        start = 1
        count = 200
    end
    selected = lines[start - 1:start - 1 + count]
    content = []
    for index in rang(len(selected)):
        number = String(start + index)
        while len(number) < 5:
            number = " " + number
        end
        content.append(number + "  " + selected[index])
    end
    return {"ok": True, "path": filename, "total_lines": len(lines), "start_line": start, "end_line": start + len(selected) - 1, "content": "\n".join(content)}
end

function current_umask():
    try:
        for line in common.splitlines(readfile("/proc/self/status")):
            if line.startswith("Umask:"):
                result = 0
                for char in line[6:].strip(common.WHITESPACE):
                    result = result * 8 + Int(char)
                end
                return result
            end
        end
    else:
        return 18
    end
    return 18
end

function write_file(state, arguments):
    filename = path(state, arguments["path"])
    info = platform.file_info(filename)
    if info != None and info["directory"]:
        call fail(filename + " is a folder")
    end
    mode = 420 & ~current_umask()
    if info != None:
        mode = info["mode"] & 4095
    end
    call platform.mkdir_parents(common.dirname(filename))
    content = String(arguments["content"])
    call platform.atomic_write(filename, content, mode)
    return {"ok": True, "path": filename, "created": info == None, "bytes": platform.byte_length(content)}
end

function edit_file(state, arguments):
    filename = path(state, arguments["path"])
    text = readfile(filename)
    old = arguments["old_text"]
    new = arguments["new_text"]
    if not old:
        call fail("old_text must not be empty")
    end
    count = text.count(old)
    if count == 0:
        call fail("old_text was not found in the file")
    end
    replace_all = arguments.get("replace_all", False)
    if count > 1 and not replace_all:
        call fail("old_text occurs " + String(count) + " times; make it unique or set replace_all")
    end
    index = text.find(old)
    changed = text[:index] + new + text[index + len(old):]
    replacements = 1
    if replace_all:
        changed = text.replace(old, new)
        replacements = count
    end
    call write_file(state, {"path": filename, "content": changed})
    return {"ok": True, "path": filename, "replacements": replacements, "line": text[:index].count("\n") + 1}
end

function delete_file(state, arguments):
    filename = path(state, arguments["path"])
    info = platform.file_info(filename, False)
    if info == None:
        call fail("No such file: " + filename)
    end
    if info["symlink"] or info["file"]:
        call platform.unlink(filename)
    elif info["directory"]:
        if listdir(filename):
            call fail("Folder is not empty; delete_file never deletes recursively")
        end
        call platform.remove_directory(filename)
    else:
        call fail("No such file: " + filename)
    end
    return {"ok": True, "path": filename, "deleted": True}
end

function move_file(state, arguments):
    source = path(state, arguments["path"])
    target = path(state, arguments["destination"])
    if platform.file_info(source, False) == None:
        call fail("No such file: " + source)
    end
    info = platform.file_info(target)
    if info != None and info["directory"]:
        target = common.join(target, rootguard.base(source))
    end
    if platform.file_info(target, False) != None:
        call fail("Destination already exists: " + target)
    end
    call platform.mkdir_parents(common.dirname(target))
    # GNU mv covers cross-filesystem directories, links, metadata and sparse files.
    call run(state, ["/usr/bin/mv", "-T", "--no-clobber", "--", source, target])
    if platform.file_info(source, False) != None:
        call fail("Destination already exists: " + target)
    end
    return {"ok": True, "from": source, "to": target}
end

function make_directory(state, arguments):
    folder = path(state, arguments["path"])
    call platform.mkdir_parents(folder)
    return {"ok": True, "path": folder}
end

function file_info(state, arguments):
    filename = path(state, arguments["path"])
    info = platform.file_info(filename, False)
    if info == None:
        call fail("No such file: " + filename)
    end
    kind = "file"
    if info["symlink"]:
        kind = "link"
    elif info["directory"]:
        kind = "dir"
    end
    return {"ok": True, "path": filename, "type": kind, "size": info["size"], "mode": info["mode"] & 4095, "modified": platform.format_time(info["mtime"], "%Y-%m-%d %H:%M")}
end

function sort_key(text, index, prefix=""):
    number = String(index)
    while len(number) < 12:
        number = "0" + number
    end
    return prefix + text.lower() + "\0" + number
end

function list_directory(state, arguments):
    folder = path(state, arguments.get("path", "."))
    names = listdir(folder)
    indexed = {}
    keys = []
    for index in rang(len(names)):
        info = platform.file_info(common.join(folder, names[index]), False)
        prefix = "1"
        if info != None and info["directory"]:
            prefix = "0"
        end
        key = sort_key(names[index], index, prefix)
        keys.append(key)
        indexed[key] = names[index]
    end
    entries = []
    for key in sorted(keys)[:500]:
        name = indexed[key]
        info = platform.file_info(common.join(folder, name), False)
        if info == None:
            entries.append({"name": name, "type": "unknown"})
            continue
        end
        kind = "file"
        size = info["size"]
        if info["symlink"]:
            kind = "link"
            size = None
        elif info["directory"]:
            kind = "dir"
            size = None
        end
        entries.append({"name": name, "type": kind, "size": size, "modified": platform.format_time(info["mtime"], "%Y-%m-%d %H:%M")})
    end
    return {"ok": True, "path": folder, "count": len(names), "entries": entries, "truncated": len(names) > 500}
end

function is_blocked(state, filename):
    if not state["blocked"]:
        return False
    end
    actual = safety.real(filename)
    for folder in state["blocked"]:
        if safety.inside(actual, folder):
            return True
        end
    end
    return False
end

function walk(state, root, limit=50000):
    pending = [root]
    output = []
    while pending:
        folder = pending.pop()
        if cancelled(state) or is_blocked(state, folder):
            continue
        end
        names = []
        try:
            names = sorted(listdir(folder))
        else:
            continue
        end
        directories = []
        for name in names:
            filename = common.join(folder, name)
            info = platform.file_info(filename)
            link = platform.file_info(filename, False)
            if info != None and info["directory"]:
                if name not in [".git", "node_modules", "__pycache__", ".cache"] and link != None and not link["symlink"] and not is_blocked(state, filename):
                    directories.append(filename)
                end
            elif not is_blocked(state, filename):
                output.append(filename)
                if len(output) >= limit or cancelled(state):
                    return output
                end
            end
        end
        for index in rang(len(directories) - 1, -1, -1):
            pending.append(directories[index])
        end
    end
    return output
end

function find_files(state, arguments):
    root = path(state, arguments.get("path", "."))
    info = platform.file_info(root)
    if info == None or not info["directory"]:
        call fail("Not a folder: " + root)
    end
    pattern = String(arguments["pattern"])
    glob = pattern
    if not platform.regex_test("[*?\\[]", pattern):
        glob = "*" + pattern + "*"
    end
    found = []
    for filename in walk(state, root):
        relative = filename[len(root.rstrip("/")) + 1:]
        if shell_glob(rootguard.base(filename).lower(), glob.lower()) or ("/" in glob and shell_glob(relative, glob)):
            found.append(filename)
            if len(found) >= 500:
                break
            end
        end
    end
    return {"ok": True, "root": root, "pattern": pattern, "files": found, "truncated": len(found) >= 500}
end

function shell_glob(name, pattern):
    return shellwords.glob_match(name, pattern)
end

function search_text(state, arguments):
    root = path(state, arguments.get("path", "."))
    query = String(arguments["query"])
    expression = query
    if not arguments.get("regex"):
        expression = platform.regex_escape(query)
    end
    expression = "(?i)" + expression
    try:
        call platform.regex_test(expression, "")
    else:
        call fail("Invalid regex: " + clean_error(String(last_error())))
    end
    info = platform.file_info(root)
    files = []
    if info != None and info["file"] and not is_blocked(state, root):
        files = [root]
    else:
        files = walk(state, root, 20000)
    end
    matches = []
    for filename in files:
        if cancelled(state):
            break
        end
        if not shell_glob(rootguard.base(filename), common.fallback(arguments.get("file_pattern"), "*")):
            continue
        end
        raw = None
        try:
            if platform.file_size(filename) > 2097152:
                continue
            end
            raw = platform.read_prefix(filename, 2097153)
        else:
            continue
        end
        binary = False
        for index in rang(min(4096, len(raw))):
            if raw[index] == 0:
                binary = True
                break
            end
        end
        if binary:
            continue
        end
        lines = common.splitlines(platform.utf8_decode(raw))
        for index in rang(len(lines)):
            if platform.regex_test(expression, lines[index]):
                matches.append(filename + ":" + String(index + 1) + ": " + lines[index].strip(common.WHITESPACE)[:300])
                if len(matches) >= 300:
                    break
                end
            end
        end
        if len(matches) >= 300:
            break
        end
    end
    return {"ok": True, "query": query, "matches": "\n".join(matches), "count": len(matches), "truncated": len(matches) >= 300}
end

function which(state, program):
    if state.get("programs") != None:
        return program in state["programs"]
    end
    return Bool(glib.find_program_in_path(program))
end

function open_url(state, arguments):
    url = String(arguments["url"]).strip(common.WHITESPACE)
    if not url:
        call fail("Empty URL")
    end
    if not platform.regex_test("(?i)^(https?|mailto|ftp|file):", url):
        filename = path(state, url)
        if not exists(filename):
            call fail("Only http(s), mailto, ftp, file URLs or existing local paths can be opened")
        end
        url = filename
    end
    call spawn(state, ["xdg-open", url])
    return {"ok": True, "opened": url}
end

function parse_desktop(filename, language=None):
    if language == None:
        language = common.environment("LC_ALL", common.environment("LC_MESSAGES", common.environment("LANG")))
    end
    language = language.split(".")[0]
    short = language.split("_")[0]
    output = {}
    local = {}
    section = None
    try:
        text = platform.utf8_decode(platform.read_prefix(filename, platform.file_size(filename) + 1))
        for line in common.splitlines(text):
            line = line.strip(common.WHITESPACE)
            if line.startswith("["):
                section = line
                continue
            end
            if section != "[Desktop Entry]" or "=" not in line:
                continue
            end
            index = line.find("=")
            key = line[:index].strip(common.WHITESPACE)
            value = line[index + 1:].strip(common.WHITESPACE)
            localized = rootguard.match("^(\\w+)\\[([^\\]]+)\\]$", key)
            if localized != None:
                if localized["groups"][2] in [language, short]:
                    local[localized["groups"][1]] = value
                end
                continue
            end
            output[key] = value
        end
    else:
        return output
    end
    for key in local.keys():
        output[key] = local[key]
    end
    return output
end

function apps(state):
    data_home = common.fallback(state["env"].get("XDG_DATA_HOME"), common.join(state["home"], ".local/share"))
    directories = [data_home] + common.fallback(state["env"].get("XDG_DATA_DIRS"), "/usr/local/share:/usr/share").split(":")
    output = {}
    for directory in directories:
        if not directory:
            continue
        end
        directory = common.join(directory, "applications")
        names = []
        try:
            names = sorted(listdir(directory))
        else:
            continue
        end
        for name in names:
            if not name.endswith(".desktop"):
                continue
            end
            id = name[:len(name) - 8]
            if id in output:
                continue
            end
            info = parse_desktop(common.join(directory, name))
            if info.get("Type", "Application") != "Application" or info.get("NoDisplay") == "true" or info.get("Hidden") == "true":
                output[id] = None
            else:
                output[id] = common.fallback(info.get("Name"), id)
            end
        end
    end
    visible = {}
    for id in output.keys():
        if output[id]:
            visible[id] = output[id]
        end
    end
    return visible
end

function list_apps(state, arguments):
    query = String(common.fallback(arguments.get("query"), "")).lower()
    available = apps(state)
    indexed = {}
    keys = []
    index = 0
    for id in available.keys():
        name = available[id]
        if not query or query in id.lower() or query in name.lower():
            key = sort_key(name, index)
            keys.append(key)
            indexed[key] = {"id": id, "name": name}
        end
        index += 1
    end
    rows = []
    for key in sorted(keys)[:500]:
        rows.append(indexed[key])
    end
    return {"ok": True, "count": len(keys), "apps": rows}
end

function open_app(state, arguments):
    app = String(arguments["app"]).strip(common.WHITESPACE)
    if app.endswith(".desktop"):
        app = app[:len(app) - 8]
    end
    available = apps(state)
    id = app
    if app not in available:
        exact = []
        partial = []
        low = app.lower()
        for key in available.keys():
            if available[key].lower() == low:
                exact.append(key)
            end
            if low in available[key].lower() or low in key.lower():
                partial.append(key)
            end
        end
        candidates = common.fallback(exact, partial)
        if not candidates:
            call fail("No installed application matches '" + app + "'. Use list_apps.")
        end
        id = candidates[0]
        for candidate in candidates:
            if len(candidate) < len(id):
                id = candidate
            end
        end
    end
    launcher = "xdg-open"
    if which(state, "gtk-launch"):
        launcher = "gtk-launch"
    end
    call spawn(state, [launcher, id])
    return {"ok": True, "launched": id, "name": available.get(id, id)}
end

function need_x11(state):
    if not state["env"].get("DISPLAY"):
        call fail("Mouse and keyboard control needs an X11 session (DISPLAY is not set)")
    end
    if state["env"].get("WAYLAND_DISPLAY") and state["env"].get("XDG_SESSION_TYPE") == "wayland":
        call fail("Mouse and keyboard control works only on X11 (this is a Wayland session)")
    end
end

function screenshot(state):
    gui = state["gui"]
    if gui == None or gui.get("screenshot") == None:
        call fail("Screenshots need the graphical session")
    end
    shot = gui["screenshot"](gui)
    result = {"ok": True, "path": shot["path"], "width": shot["width"], "height": shot["height"]}
    try:
        result["windows"] = list_windows(state).get("windows", [])
    else:
        result["windows"] = []
    end
    if shot.get("data_url"):
        result["_image"] = shot["data_url"]
    end
    if state["vision"] and shot.get("data_url"):
        result["note"] = "The screenshot is attached as an image in the next message."
    else:
        result["note"] = "The current model cannot see images. Use the window list (titles, positions) and other tools to understand the screen."
    end
    return result
end

function mouse_move(state, arguments):
    call need_x11(state)
    x = Int(arguments["x"])
    y = Int(arguments["y"])
    call run(state, ["xdotool", "mousemove", String(x), String(y)])
    return {"ok": True, "x": x, "y": y}
end

function mouse_click(state, arguments):
    call need_x11(state)
    x = Int(arguments["x"])
    y = Int(arguments["y"])
    button = Int(common.fallback(arguments.get("button"), 1))
    double = Bool(arguments.get("double", False))
    if button not in [1, 2, 3]:
        call fail("button must be 1, 2 or 3")
    end
    argv = ["xdotool", "mousemove", String(x), String(y), "click"]
    if double:
        argv += ["--repeat", "2", "--delay", "80"]
    end
    call run(state, argv + [String(button)])
    return {"ok": True, "x": x, "y": y, "button": button, "double": double}
end

function scroll(state, arguments):
    call need_x11(state)
    amount = Int(arguments["amount"])
    if amount == 0:
        return {"ok": True, "scrolled": 0}
    end
    steps = min(abs(amount), 50)
    button = "5"
    result = steps
    if amount < 0:
        button = "4"
        result = -steps
    end
    call run(state, ["xdotool", "click", "--repeat", String(steps), "--delay", "30", button])
    return {"ok": True, "scrolled": result}
end

function type_text(state, arguments):
    call need_x11(state)
    text = String(arguments["text"])
    if len(text) > 5000:
        call fail("Text is too long to type (max 5000 characters)")
    end
    call run(state, ["xdotool", "type", "--delay", "12", "--", text], max(20, len(text) // 20))
    return {"ok": True, "typed_chars": len(text)}
end

function press_key(state, arguments):
    call need_x11(state)
    parts = common.split_words(String(arguments["keys"]))
    if not parts:
        call fail("keys must be X11 key names or chords like ctrl+l, Return, alt+Tab")
    end
    for part in parts:
        if not platform.regex_test("^[A-Za-z0-9_+\\-]+$", part):
            call fail("keys must be X11 key names or chords like ctrl+l, Return, alt+Tab")
        end
    end
    call run(state, ["xdotool", "key", "--delay", "40", "--"] + parts)
    return {"ok": True, "keys": parts}
end

function hex_number(value):
    digits = "0123456789abcdef"
    result = ""
    while value > 0:
        result = digits[value % 16] + result
        value = value // 16
    end
    return "0x" + common.fallback(result, "0")
end

function parse_hex(text):
    if text.startswith("0x"):
        text = text[2:]
    end
    value = 0
    for char in text.lower():
        index = "0123456789abcdef".find(char)
        if index < 0:
            call fail("Invalid window id")
        end
        value = value * 16 + index
    end
    return value
end

function window_id(window):
    text = String(window).strip(common.WHITESPACE)
    if platform.regex_test("^0x[0-9a-fA-F]+$", text):
        return text
    end
    if platform.regex_test("^\\d+$", text):
        return hex_number(Int(text))
    end
    return None
end

function parse_wmctrl(text):
    output = []
    for line in common.splitlines(text):
        fields = platform.regex_findall("\\S+", line)
        if len(fields) < 8:
            continue
        end
        parts = []
        for entry in fields[:8]:
            parts.append(entry["groups"][0])
        end
        title = ""
        if len(fields) > 8:
            title = line[fields[8]["start"]:]
        end
        try:
            output.append({"id": parts[0], "desktop": Int(parts[1]), "pid": Int(parts[2]), "x": Int(parts[3]), "y": Int(parts[4]), "width": Int(parts[5]), "height": Int(parts[6]), "title": title})
        else:
            continue
        end
    end
    return output
end

function list_windows(state):
    call need_x11(state)
    windows = []
    if which(state, "wmctrl"):
        windows = parse_wmctrl(run(state, ["wmctrl", "-lpG"])["stdout"])
    elif which(state, "xdotool"):
        ids = common.split_words(run(state, ["xdotool", "search", "--onlyvisible", "--name", "."], 20, None, False)["stdout"])
        for id in ids[:100]:
            name = run(state, ["xdotool", "getwindowname", id], 20, None, False)["stdout"].strip(common.WHITESPACE)
            if name:
                windows.append({"id": hex_number(Int(id)), "title": name})
            end
        end
    else:
        call fail("wmctrl or xdotool is needed to list windows")
    end
    active = ""
    if which(state, "xdotool"):
        result = run(state, ["xdotool", "getactivewindow"], 20, None, False)
        text = common.strip_text(result["stdout"])
        if result["returncode"] == 0 and platform.regex_test("^\\d+$", text):
            active = hex_number(Int(text))
        end
    end
    for window in windows:
        window["active"] = Bool(active) and parse_hex(window["id"]) == parse_hex(active)
    end
    return {"ok": True, "count": len(windows), "windows": windows, "active": active}
end

function focus_window(state, arguments):
    call need_x11(state)
    window = String(arguments["window"])
    id = window_id(window)
    if which(state, "wmctrl"):
        if id:
            call run(state, ["wmctrl", "-ia", id])
        else:
            call run(state, ["wmctrl", "-a", window])
        end
    elif id:
        call run(state, ["xdotool", "windowactivate", String(parse_hex(id))])
    else:
        result = run(state, ["xdotool", "search", "--onlyvisible", "--name", platform.regex_escape(window)], 20, None, False)
        ids = common.split_words(result["stdout"])
        if not ids:
            call fail("No window matches '" + window + "'")
        end
        call run(state, ["xdotool", "windowactivate", ids[0]])
    end
    return {"ok": True, "focused": common.fallback(id, window)}
end

function close_window(state, arguments):
    call need_x11(state)
    id = window_id(arguments["window"])
    if not id:
        call fail("close_window needs a window id from list_windows")
    end
    if which(state, "wmctrl"):
        call run(state, ["wmctrl", "-ic", id])
    else:
        call run(state, ["xdotool", "windowclose", String(parse_hex(id))])
    end
    return {"ok": True, "closed": id}
end

function clipboard_read(state):
    text = None
    gui = state["gui"]
    if gui != None and gui.get("clipboard_text") != None:
        text = gui["clipboard_text"](gui)
    end
    if text == None:
        for argv in [["xclip", "-selection", "clipboard", "-o"], ["xsel", "-ob"], ["wl-paste", "-n"]]:
            if which(state, argv[0]):
                result = run(state, argv, 5, None, False)
                if result["returncode"] == 0:
                    text = result["stdout"]
                    break
                end
            end
        end
    end
    if text == None:
        return {"ok": True, "text": "", "empty": True}
    end
    return {"ok": True, "text": tool_format.clip_text(text, 20000), "length": len(text)}
end

function notify(state, arguments):
    title = String(arguments["title"])
    body = String(arguments.get("body", ""))
    if which(state, "notify-send"):
        call run(state, ["notify-send", "-a", "LuxAI", "-i", "luxai", "--", title[:200], body[:1000]], 20, None, False)
    elif state["gui"] != None and state["gui"].get("notify") != None:
        call state["gui"]["notify"](state["gui"], title, body)
    else:
        call fail("notify-send is not installed")
    end
    return {"ok": True}
end

function system_info(state):
    env = state["env"]
    session = "unknown"
    if env.get("DISPLAY"):
        session = "x11"
    end
    result = {"ok": True, "user": env.get("USER", ""), "home": state["home"], "working_folder": state["workdir"], "session": env.get("XDG_SESSION_TYPE", session), "desktop": env.get("XDG_CURRENT_DESKTOP", ""), "display": env.get("DISPLAY", "")}
    try:
        for line in common.splitlines(readfile("/etc/os-release")):
            if line.startswith("PRETTY_NAME="):
                result["os"] = line[line.find("=") + 1:].strip(common.WHITESPACE).strip("\"")
            end
        end
    else:
        result = result
    end
    available = {}
    for program in ["xdotool", "wmctrl", "xdg-open", "gtk-launch", "notify-send", "git", "python3", "lux", "flatpak"]:
        available[program] = which(state, program)
    end
    result["available"] = available
    return result
end

function flag(value, default):
    if value == None:
        return default
    end
    if type(value) == "String":
        text = value.strip(common.WHITESPACE).lower()
        if text in ["true", "yes", "1", "on"]:
            return True
        end
        if text in ["false", "no", "0", "off", ""]:
            return False
        end
        return default
    end
    return Bool(value)
end

function prepare_feedback(state, arguments, allow_screenshot):
    kind = arguments["kind"]
    title = arguments["title"]
    description = arguments["description"]
    contact = arguments.get("contact_email")
    call feedback.build_payload(kind, title, description, contact)
    system = None
    if flag(arguments.get("include_system_info"), True):
        if state.get("collect_system") != None:
            system = state["collect_system"](state)
        else:
            system = feedback.collect_system()
        end
    end
    notes = []
    shot = None
    if flag(arguments.get("include_screenshot"), False):
        if not allow_screenshot:
            notes.append(i18n.translate("Screenshots are turned off in LuxAI settings; the report is sent without one."))
        elif state["gui"] == None:
            notes.append(i18n.translate("No graphical session; the report is sent without a screenshot."))
        else:
            gui = state["gui"]
            try:
                grab = gui.get("report_screenshot", gui.get("screenshot"))
                screenshot = grab(gui)
                shot = common.fallback(screenshot.get("data_url"), None)
            else:
                message = i18n.translate("The screenshot could not be taken ({0}); the report is sent without one.")
                notes.append(message.replace("{0}", clean_error(String(last_error()))))
            end
            if shot and len(shot) > feedback.SHOT_MAX:
                shot = None
                notes.append(i18n.translate("The screenshot is too large; the report is sent without one."))
            end
        end
    end
    payload = feedback.build_payload(kind, title, description, contact, system, shot)
    account = feedback.account_for(state["client"])
    preview = feedback.describe(payload)
    preview["screenshot"] = payload.get("screenshot")
    preview["notes"] = notes
    preview["signed_in"] = Bool(account[0])
    return {"ok": True, "payload": payload, "preview": preview}
end

function validate_args(name, arguments):
    definition = None
    for item in catalog.TOOL_DEFS:
        if item["function"]["name"] == name:
            definition = item["function"]["parameters"]
            break
        end
    end
    if definition == None:
        call fail("Unknown tool: " + name)
    end
    for key in definition["required"]:
        if key not in arguments and not (name == "list_directory" and key == "path"):
            call fail("Invalid arguments: missing required argument: " + key)
        end
    end
    for key in arguments.keys():
        if key not in definition["properties"]:
            call fail("Invalid arguments: unexpected argument: " + key)
        end
    end
end

function prepare(state, name, arguments, allow_screenshot=True):
    if name in calendar_data.WRITE_TOOLS:
        # nahled udalosti pro potvrzovaci kartu (jen cteni; neplatne argumenty skonci pred dotazem)
        return calendar.prepare(state, name, arguments)
    end
    if name != "send_feedback" or type(arguments) != "Dictionary":
        return None
    end
    try:
        arguments = common.without(arguments, "allow_screenshot")
        call validate_args(name, arguments)
        return prepare_feedback(state, arguments, allow_screenshot)
    else:
        return {"ok": False, "error": clean_error(String(last_error()))}
    end
end

function send_feedback(state, prepared):
    if type(prepared) != "Dictionary" or not prepared.get("ok") or "payload" not in prepared:
        return {"ok": False, "error": "The report was not prepared and approved; nothing was sent."}
    end
    payload = prepared["payload"]
    account = feedback.account_for(state["client"])
    try:
        id = feedback.send(payload, account[0], account[1], 45, cancelled, state)
        return {"ok": True, "id": id, "kind": payload["kind"], "sent_with_account": Bool(account[0]), "system_info_attached": "system" in payload, "screenshot_attached": "screenshot" in payload, "note": "The report was delivered to the author of LuxOS. Tell the user the report ID."}
    else:
        problem = api.caught_error(String(last_error()))
        result = {"ok": False, "error": feedback.human_error(problem), "code": problem["code"]}
        if feedback.can_save(problem):
            result["offline"] = True
            result["_payload"] = payload
            result["note"] = "The report was not sent. The user can save it in the tool card; the Feedback app then sends it automatically later. Tell the user."
        elif problem["code"] == "rate":
            result["note"] = "At most 5 reports per 10 minutes are accepted. Do not retry now; tell the user."
        end
        return result
    end
end

HANDLERS = {"run_command": run_command, "read_file": read_file, "write_file": write_file, "edit_file": edit_file, "delete_file": delete_file, "move_file": move_file, "make_directory": make_directory, "file_info": file_info, "list_directory": list_directory, "find_files": find_files, "search_text": search_text, "open_url": open_url, "list_apps": list_apps, "open_app": open_app, "mouse_move": mouse_move, "mouse_click": mouse_click, "scroll": scroll, "type_text": type_text, "press_key": press_key, "focus_window": focus_window, "close_window": close_window, "notify": notify}

function execute(state, name, arguments, prepared=None):
    if cancelled(state):
        return {"ok": False, "cancelled": True, "error": "Stopped by the user before running"}
    end
    names = []
    for definition in state["definitions"]:
        names.append(definition["function"]["name"])
    end
    if name not in names:
        if state["chat"]:
            return {"ok": False, "error": "Tool " + name + " is not available in Chat mode"}
        end
        return {"ok": False, "error": "Unknown tool: " + name}
    end
    if type(arguments) != "Dictionary":
        return {"ok": False, "error": "Tool arguments must be a JSON object"}
    end
    if name == "send_feedback":
        return send_feedback(state, prepared)
    end
    if name == "map_open" or name.startswith("map_") or name in ["transit_timetable", "current_location"]:
        # mapy pres LuxOS Maps (argumenty kontroluje maps.command jako v Pythonu)
        environment = state["env"]
        if not state["chat"]:
            environment = child_env(state)
        end
        return maps.execute(name, arguments, environment, state["signal"])
    end
    if name in weather_data.TOOLS:
        environment = state["env"]
        if not state["chat"]:
            environment = child_env(state)
        end
        return weather.execute(name, arguments, environment, state["signal"])
    end
    if name in calendar_data.TOOLS:
        state["cancelled"] = cancelled
        return calendar.execute(state, name, arguments, prepared)
    end
    try:
        call validate_args(name, arguments)
        if name in HANDLERS:
            return HANDLERS[name](state, arguments)
        end
        if name == "screenshot":
            return screenshot(state)
        end
        if name == "list_windows":
            return list_windows(state)
        end
        if name == "clipboard_read":
            return clipboard_read(state)
        end
        if name == "system_info":
            return system_info(state)
        end
        if name == "docs_search":
            return docs.search(arguments["query"], arguments.get("collection"))
        end
        if name == "docs_read":
            return docs.read(arguments["path"], arguments.get("heading"))
        end
        if name in ["web_search", "web_fetch"]:
            if state.get("web") == None:
                call fail("Web transport is not connected")
            end
            return state["web"][name](state, arguments)
        end
        call fail("Unknown tool: " + name)
    else:
        return {"ok": False, "error": clean_error(String(last_error()))}
    end
end
