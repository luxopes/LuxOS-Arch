# Rich blocks in LuxAI answers

LuxAI desktop (from 2.0.2-4) renders some fenced code blocks in a model answer natively instead of
showing their source. The model writes plain Markdown; a block whose language tag is listed below
becomes a chart, quiz, form, diagram and so on. This document is the format specification, so other
clients (for example the lux-ai.cz web chat) can render the same answers.

The design is secure by default. The model never sends HTML or JavaScript to run. A client parses the
block content itself and builds its own widgets. Anything it cannot parse is shown as the original code
block with a short error note, so no content disappears.

## Common rules

- A block is a Markdown fenced code block: ```` ```chart ```` … ```` ``` ````. The language tag is not
  case-sensitive. Unknown tags (for example `json` or `python`) stay ordinary code blocks.
- Clients should be tolerant, because models make these mistakes (all seen in real answers): content
  on the same line as the fence (```` ```quiz {"title": …} ````), `json quiz` / `quiz json` tags, a
  closing fence glued to the content (`…]}` followed by ```` ``` ````), a `~~~` closing fence, typographic
  quotes around JSON keys and values, text after the JSON when the closing fence is missing, and LaTeX
  written with doubled backslashes (`\\vec`, `\\(` … `\\)`), which is read as single backslashes.
- JSON blocks must be valid JSON. Clients should also accept trailing commas and `//` comments, because
  models often write them.
- While an answer is streaming, an unclosed block shows a placeholder ("Chart – preparing…"). It is
  rendered when its closing fence arrives, or when the answer ends.
- Size limits (a larger block is shown as code with an error): JSON blocks 64 KB, `svg` and `table`
  256 KB, `mermaid` 20 000 characters, display math 4 000 characters.
- Every rendered block has a **Copy** button (copies the block source). Charts, diagrams, formulas and
  SVG images can be exported as PNG (2× resolution) and SVG. Tables can be copied or exported as CSV.
- Text fields (titles, questions, options, explanations) may contain inline Markdown: bold, italic,
  `code`, links and `$math$`.

## Interactive state

Quiz answers, used hints, checklist ticks, form values, table sorting and network consent for a map
or gallery are saved with the assistant message, so they survive reopening the conversation. LuxAI
desktop stores them in the conversation file as `_rich` on the assistant message:

```json
{"role": "assistant", "content": "...", "_rich": {"quiz:4f9f2cab": {"answers": {"0": [1]}, "hints": ["0"]}}}
```

The key is `<kind>:<FNV-1a 32-bit hash of the block source, 8 hex digits>`. When the same block
appears more than once in one message, later copies get `:1`, `:2` … Markdown tables use the kind
`mdtable` and hash the JSON `[header, rows]`. Fields starting with `_` are never sent to the model.

## ```chart

```json
{"type": "bar", "title": "Revenue by quarter",
 "x": {"categories": ["Q1", "Q2", "Q3", "Q4"], "label": "Quarter"},
 "y": {"label": "mil. CZK", "unit": "", "min": 0, "max": 30},
 "series": [{"name": "2024", "data": [12, 15, 9, 20]}, {"name": "2025", "data": [14, 18, 11, 25], "color": "#f28c28"}],
 "stacked": false}
```

| Field | Meaning |
|---|---|
| `type` | `bar` (alias `column`), `hbar` (or `"horizontal": true`), `line`, `area`, `scatter`, `pie`, `donut` (alias `doughnut`). Default `bar`. |
| `x.categories` | Category labels (also `labels` or `categories` at the top level). Up to 1000. |
| `series[].data` | Numbers or `null` (a gap). For `line`, `area` and `scatter` also `[x, y]` pairs or `{"x":…, "y":…}`, which gives a numeric x axis. |
| `series[].name`, `color` | Legend name; optional `#rgb`/`#rrggbb` color (otherwise a palette for light and dark themes). |
| `y.min`, `y.max`, `y.unit`, `y.label`, `x.label` | Optional axis settings. |
| `stacked` | Stack `bar`, `hbar` and `area` series. |

### Function plots and the coordinate plane

For graphs of functions, vectors and geometry the model should not draw SVG by hand (it often gets the
coordinates wrong). `function` and `plane` charts are computed exactly:

```json
{"type": "function", "title": "y = 2x", "x": [-3, 3], "y": [-6, 6],
 "functions": [{"expr": "2*x", "label": "y = 2x", "color": "#e5484d", "dashed": false}, "sin(x)"],
 "points": [[1, 2, "(1, 2)"], {"x": -1, "y": -2, "label": "(-1, -2)"}], "grid": true, "equal": false}
```

```json
{"type": "plane", "title": "Vector v = (3, 4)",
 "vectors": [{"from": [0, 0], "to": [3, 4], "label": "v"}], "points": [[3, 4]],
 "segments": [{"from": [3, 0], "to": [3, 4], "dashed": true}], "circles": [{"center": [0, 0], "r": 5}],
 "polygons": [[[0, 0], [3, 0], [3, 4]]]}
```

- `functions[].expr` uses the formula language of `form` with the single variable `x`
  (`y = …` / `f(x) = …` prefixes are accepted); it is sampled 400 times over the x range. Errors and
  non-finite values leave gaps (asymptotes of `tan(x)`, `1/x` are not joined).
- `x` and `y` are `[min, max]` or `{"min", "max", "label"}`. Missing ranges come from the objects
  (with a margin); the y range ignores the 2 % most extreme samples so asymptotes do not flatten the plot.
- Axes go through the origin (or along the edge when 0 is outside the range), with nice ticks and
  an optional grid. `equal` (default `true` for `plane`) makes one unit equally long on both axes,
  extending the shorter range rather than cutting anything off.
- Points, vectors (arrows, `[x, y]` = from the origin), segments, circles and polygons are in plane
  coordinates. Pointing at a point, a vector tip or a curve shows its exact coordinates (and the
  length of a vector). Limits: 8 functions, 200 points, 50 vectors, 100 segments, 50 circles,
  20 polygons of max. 100 vertices.

Shorthands: `"data": [{"label": "A", "value": 3}, …]` (one series with categories) and
`"slices": [{"label": "A", "value": 3}]` for pies. A pie uses the first series; values must not be
negative. Limits: 12 series, 5000 points. Pointing at a bar, point or slice shows its value; the arrow
keys step through the values when the chart has keyboard focus.

## ```quiz

```json
{"title": "Solar system", "shuffle": false, "questions": [
  {"q": "Which planet is the **largest**?", "options": ["Earth", "Jupiter", "Saturn"], "correct": 1,
   "explanation": "Jupiter is more than twice as massive as all other planets combined.", "hint": "It has a Great Red Spot."},
  {"q": "Which of these are gas giants?", "options": ["Jupiter", "Venus", "Saturn"], "correct": [0, 2]}
]}
```

- `correct`: option index (0-based), option text, option letter (`"B"`), or a list of them. More than
  one correct answer (or `"multiple": true`) shows check boxes and a **Check answer** button; otherwise
  one click answers the question.
- Aliases: `question`/`text` for `q`, `choices`/`answers` for `options`, `answer` for `correct`,
  `explain`/`why` for `explanation`. A single question can be written without `questions`.
- `shuffle` mixes the options in a stable order (the same every time for the same block).
- Answering is local; nothing is sent to the model. After all questions: "Score: 2 of 3" and
  **Try again**. Limits: 50 questions, 2–10 options.

## ```form (alias ```controls)

```json
{"title": "Mortgage calculator", "description": "Optional text",
 "controls": [
  {"id": "amount", "type": "slider", "label": "Loan amount", "min": 100000, "max": 10000000, "step": 50000, "value": 3000000, "unit": "CZK"},
  {"id": "rate", "type": "number", "label": "Interest rate", "min": 0.1, "max": 15, "step": 0.1, "value": 4.9, "unit": "%"},
  {"id": "years", "type": "select", "label": "Term", "options": [{"label": "20 years", "value": 20}, {"label": "30 years", "value": 30}], "value": 30},
  {"id": "insurance", "type": "toggle", "label": "Payment insurance", "value": false},
  {"type": "button", "label": "Reset", "action": "reset"}],
 "outputs": [{"label": "Monthly payment", "expr": "amount * (rate/1200) / (1 - (1 + rate/1200)^(-years*12))", "format": "0", "unit": "CZK"}],
 "submit": "Send to LuxAI"}
```

Control types: `slider` (alias `range`), `number`, `toggle` (alias `switch`), `checkbox`, `select`
(aliases `dropdown`, `radio`; options are strings, numbers or `{"label", "value"}`), `text`, and
`button` with `"action": "reset"` or `"send"`. Every control except buttons needs a unique `id`
(letters, digits, `_`, max. 40 characters; `pi`, `e`, `true`, `false`, `and`, `or`, `not` are reserved).
Limits: 40 controls, 20 outputs.

`outputs[].expr` is a formula evaluated by a small safe evaluator. It is never code:

- numbers (`1.5`, `2e3`), text in quotes, `true`, `false`, `pi`, `e` and control ids;
- `+ - * / %`, `^` or `**` (power, right-associative, `-2^2 = -4`), `< <= > >= == !=`,
  `&&`/`and`, `||`/`or`, `!`/`not`, `cond ? a : b`, `+` joins text;
- functions `abs min max round(x, digits) floor ceil sqrt pow exp ln log(x[, base]) log10 sin cos tan
  clamp(x, low, high) if(cond, a, b) sum avg`;
- toggles and check boxes are `1`/`0`, text fields are text;
- limits: 500 characters, 200 tokens, nesting 32, 20 000 evaluation steps; errors (division by zero,
  unknown name, overflow) are shown next to the output instead of a value.

`format`: empty (up to 4 decimals), `"0"`, `"0.00"` (fixed decimals), a trailing `%` (multiply by 100),
`","` (thousands separator). Numbers from 10 000 always get a space as the thousands separator.

`submit` (text, or `true` for "Send to LuxAI") adds a button that sends the current values and results
as the user's next message:

```
My values in "Mortgage calculator":
- Loan amount: 3 000 000 CZK
- Term: 30 years
- Monthly payment: 15 921 CZK
```

The user clicks the button, so nothing is sent without their action.

## ```table (alias ```csv)

CSV with a header row (comma, semicolon or tab; RFC 4180 quotes), or JSON:

```json
{"title": "Cities", "columns": ["City", "Population"], "rows": [["Prague", 1384732], ["Brno", 402739]]}
```

`rows` can also be a list of objects (the keys of the first object become the columns). Clicking a
header sorts by that column (numbers, including `1 234,5` or `12 %`, numerically; text without regard
to case); clicking again reverses the order. Limits: 50 columns, 2000 rows (500 shown, CSV export has
all). CSV export protects against spreadsheet formulas (`=`, `+`, `@` get a leading `'`). Ordinary
Markdown tables get the same sorting and CSV export.

## ```mermaid (alias ```diagram)

A Mermaid subset rendered natively, without JavaScript and without the network:

- `flowchart` / `graph` with `TD`, `TB`, `BT`, `LR`, `RL`; node shapes `A[text]`, `A(text)`,
  `A((text))`, `A{text}`, `A{{text}}`, `A[(text)]`, `A[[text]]`, `A([text])`, `A>text]`, `A[/text/]`;
  edges `-->`, `---`, `-.->`, `==>`, `--o`, `--x`, `<-->`, with labels `-->|text|` or `-- text -->`;
  chains `A --> B --> C` and `A & B --> C`. `classDef`, `class`, `style`, `linkStyle`, `click` and
  `subgraph` lines are ignored (the subgraph content stays). Limits: 120 nodes, 240 edges.
- `sequenceDiagram`: `participant X as Label`, `actor X`, messages `->>`, `-->>`, `->`, `-->`, `-x`,
  `--x`, `-)`, `--)` with `: text`, `Note left of|right of|over A[,B]: text`,
  `loop`/`alt`/`else`/`opt`/`par`/`and`/`critical`/`break` … `end`, `autonumber`, `title`.
- `stateDiagram` / `stateDiagram-v2`: `[*] --> A`, `A --> B : label`, `state "Long name" as A`,
  `A : description`, `state X <<choice>>`, `direction LR`.
- `timeline`: `title`, `section`, `period : event : event`, continuation lines `: event`.
- `pie`: `pie title X` and `"Label" : value` (drawn as a chart).

Other diagram types (gantt, class, ER, mindmap …) show the source with an error note.
`<br>` in labels is a line break; other HTML tags are removed.

## ```svg

One `<svg>` element. The client sanitizes it to a safe subset before rendering:

- allowed elements: `svg g defs symbol use path rect circle ellipse line polyline polygon text tspan
  textPath title desc linearGradient radialGradient stop clipPath mask pattern marker switch`;
  `<a>` is unwrapped (its content stays, the link does not); anything else is removed with its content
  (`script`, `style`, `foreignObject`, `image`, `iframe`, `animate`, `set`, `filter` …);
- allowed attributes are geometry and presentation attributes; event handlers (`on…`) and unknown
  attributes are removed; `style` keeps only presentation properties;
- `href`/`xlink:href` only as `#id`; `url(…)` only as `url(#id)`; values with `javascript:`, `data:`,
  `@import` or `expression(` are removed;
- `<!DOCTYPE>` (including entity definitions), comments and processing instructions are dropped;
  entities other than the five XML ones are not expanded;
- `<style>`: only simple rules (`tag`, `.class`, `tag.class`, `#id`, `*`, comma lists) with the allowed
  properties (also the `font` shorthand) are kept – they are copied into the `style` attribute of each
  matching element (by specificity, the element's own `style` wins); `@import` and other at-rules are
  dropped, the `<style>` element itself never reaches the renderer;
- limits: 256 KB, 3000 elements, nesting 40, 200 `<use>` elements.

Defaults for model drawings: without `font-family` on the root the user interface font is used
(Inter on LuxOS; the SVG default would be a serif font); text without its own or inherited `fill`
gets `currentColor`, and the root gets the theme's text colour, so labels stay readable in dark mode.
Geometry is not changed: tests compare the result with `rsvg-convert` of the original SVG.

Without `width`/`height` the drawing fills the answer width (max. 480 px), keeping the `viewBox`
aspect ratio. LuxAI notes under the image when something unsafe was removed.

## Display math

`$$…$$`, `\[…\]` on their own lines and ```` ```math ```` blocks are typeset natively: fractions
(`\frac`, `\dfrac`, `\tfrac`, `\binom`), roots (`\sqrt[n]{}`), sub- and superscripts, big operators with
limits (`\sum`, `\prod`, `\int`, `\lim`, `\max` …), `\left…\right` with stretched delimiters, the
environments `matrix`, `pmatrix`, `bmatrix`, `Bmatrix`, `vmatrix`, `Vmatrix`, `smallmatrix`, `cases`,
`aligned`, `align`, `array`, `gathered`, accents (`\hat`, `\bar`, `\vec`, `\dot`, `\tilde`,
`\overline`, `\underline` …), `\text`, `\operatorname`, `\mathbb`, `\mathbf`, `\mathcal`, Greek letters
and the usual symbols, `\\` for several lines. An unknown command is shown as written (with its
backslash), nothing is dropped; a syntax error
(for example unbalanced braces) falls back to the inline renderer. Inline math (`$…$`, `\(…\)`) stays
in the text line, rendered with Unicode and Pango markup (Greek letters, operators, `\vec`, `a/b`
fractions, roots with a bar over the radicand).

## ```map

```json
{"title": "Prague sights",
 "markers": [{"lat": 50.0909, "lon": 14.4005, "label": "Prague Castle"}, [50.0865, 14.4114, "Charles Bridge"]],
 "route": [[50.0909, 14.4005], [50.0865, 14.4114]], "center": [50.087, 14.42], "zoom": 14}
```

At least one of `center`, `markers` or `route` is required. Limits: 50 markers, 2000 route points;
latitude ±85.05. LuxAI lists the places and offers **Open in Maps** (`luxos-maps --json open`). The
map picture (`luxos-maps --render-preview`, OpenStreetMap tiles) downloads map tiles, so it follows
the LuxAI network setting: "never" – no picture; "ask" (default) – a **Show map** button; "allow" –
shown at once. The consent is remembered for the block.

## ```gallery

```json
{"title": "Photos", "images": [{"url": "https://example.com/castle.jpg", "caption": "Prague Castle"}, "https://example.com/b.png"]}
```

Only `http(s)` URLs without credentials; max. 20 images. Images are downloaded only after the user
allows it (the **Load images** button, or immediately when network access is set to "allow"; never
when it is "never"). Downloads use the same protection as `web_fetch`: public internet addresses
only (no local or private networks), checked redirects, max. 6 MB per image. Only PNG, JPEG, GIF and
WebP are accepted (checked by the file content; SVG is never loaded from the network). Downloaded
images are cached in `~/.cache/luxai/rich-images`. The carousel has previous/next buttons and
arrow-key navigation.

## ```timeline

```json
{"title": "Day plan", "items": [{"date": "09:00", "title": "Prague Castle", "text": "Arrive early."}]}
```

Aliases: `events`, `time`/`when`/`year`, `event`/`name`, `description`. Plain text also works, one
item per line: `1990: Web` or `2007 – iPhone`, with an optional `title …` line. Max. 100 items.

## ```checklist

One task per line (`- [ ] task`, `- [x] done`, `1. task`, plain lines), an optional `# Title` line,
or JSON `{"title": "..", "items": ["task", {"text": "done task", "done": true}]}`. Ticks are saved with
the message. Max. 200 items.

## System prompt (LuxAI desktop)

LuxAI desktop adds a short description of these formats to the system prompt in Chat and Agent mode,
for both Flash and Lite (about 600 tokens): plain text stays the default, at most a few blocks per
answer, valid JSON, and the one-line format of each block. The LuxOS Companion (phone) session does
not get it, because the phone does not render the blocks.
