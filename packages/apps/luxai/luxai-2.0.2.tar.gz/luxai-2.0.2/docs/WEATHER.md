# Počasí v LuxAI

V Chatu i Agentovi jsou dostupné tři nástroje:

- `weather_search(query, limit=5)`: města, souřadnice, země a časové pásmo.
- `weather_forecast(latitude?, longitude?, name?, units="auto", days=7, hours=24)`:
  aktuální počasí, hodinová předpověď a předpověď až na sedm dní. Bez souřadnic
  použije vybrané uložené místo z aplikace Počasí.
- `weather_locations()`: uložená místa a vybrané místo, bez sítě.

Nativní adaptér `lsl/weather.lsl` volá argumentovým polem (bez shellu)
`luxos-weather-query`, dodávané od `luxos-weather 1.0.0-5`. Samostatný název
datového rozhraní zabraňuje otevření staré verze Počasí, která ještě nezná `--json`.
Chybějící rozhraní vrátí návod k instalaci/aktualizaci, nikdy neotevře okno.

Zdrojem dat je aplikace Počasí: stejné Open-Meteo, stejná 30minutová cache,
stejné jednotky a nastavení. Dotaz nenačítá GTK, nic nemění v nastavení a
nezjišťuje polohu podle IP. Bez uloženého místa se vrací `needs_location=true`;
model se zeptá na město. Souřadnice se validují před spuštěním aplikace.
Nástroje nepřijímají vlastní URL ani příkazy.

Výsledek obsahuje `location`, `unit_system`, popisky `units`, `data`
(`current`, `hourly`, `daily`, `tz`, `utc_offset`), čas načtení `fetched`, `stale`,
`error`, `source` a `source_url`. Časy patří cílovému místu. Model musí zřetelně
označit `stale=true` jako poslední známá data a uvést Open-Meteo jako zdroj.
Pravděpodobnost srážek není množství srážek.

Vyhledávání a předpověď dodržují oprávnění „Síť“ (při „nikdy“ se modelu
nenabízejí); uložená místa dodržují oprávnění „Čtení souborů“. Stejně jako čtecí
mapové nástroje nepotřebují samostatné potvrzení. Karty mají přeložené názvy,
souhrn místa, teploty a času a upozornění na stará data.

Příklady: „Jak bude zítra v Praze?“, „Bude odpoledne pršet?“, „Porovnej počasí
v Praze a Brně“, „Ukaž teploty na příštích sedm dní v grafu“. Graf používá
stávající blok `chart`; nepřidává se žádná služba na pozadí.

Testy: `LUXAI_TEST_PATTERN=test_weather.py tools/test-lsl.sh` a celá nativní sada.
Rozhraní Počasí, cache a jednotky se testují v LuxOS v
`packages/luxos-weather/tests/test_luxos_weather.py` s falešným Open-Meteo.
