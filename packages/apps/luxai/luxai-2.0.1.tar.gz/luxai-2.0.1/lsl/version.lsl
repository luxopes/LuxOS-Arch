VERSION = "2.0.1"
APP_ID = "cz.luxai.LuxAI"
