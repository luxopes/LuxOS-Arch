"""Offline prirucka o LuxOS a LSL pro nastroje docs_search a docs_read (jen cteni, bez site).

Dokumentaci instaluje balik luxos-docs do /usr/share/luxos/docs (pro testy LUXAI_DOCS_DIR):
  index.json = {"version": 1, "collections": [{"id": "luxos", "title": "LuxOS",
                "files": [{"path": "luxos/x.md", "title", "summary", "keywords": [...]}]}, ...]}
  a soubory Markdown s nadpisy #, ##, ###.

Vyhledavani: soubory se rozdeli na sekce podle nadpisu (mimo bloky kodu), slova se porovnavaji
bez ohledu na velikost pismen a diakritiku a s jednoduchym odrezanim koncovek (cestina i anglictina),
skore je BM25 s vyssi vahou nadpisu a nazvu/klicovych slov souboru. Cesty se vzdy overi, ze
po rozvinuti symbolickych odkazu zustavaji uvnitr korene dokumentace.
"""
import json
import math
import os
import re
import threading
import unicodedata

DEFAULT_DIR = "/usr/share/luxos/docs"
INDEX = "index.json"
TEXT_EXT = (".md", ".markdown", ".txt")
MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_FILES = 2000
MAX_RESULTS = 10
DEFAULT_RESULTS = 5
MAX_READ_CHARS = 12000         # nejvetsi text vraceny docs_read
SNIPPET_CHARS = 260
MAX_HEADINGS = 300             # nejvice nadpisu v odpovedi docs_read
K1, B = 1.2, 0.75
W_HEADING, W_PARENT, W_FILE, W_BODY = 3.0, 0.5, 1.5, 1.0

# Casta slova bez vyznamu pro hledani (po odstraneni diakritiky)
STOPWORDS = set("""
a aby ale ani at az by byt bude co do i jak jake jaky je jeho jen jestli jsem jsou k kam kde kdy kdyz ke
ktera ktere ktery mam mi mit muze muzu na nad nebo neco o od po pod pri pro proc s se si sve ta tak take
tam to tu u uz v ve vsechno z za ze
the an and are as at be by can do does for from how i in is it my of on or that this to what when where
which why with you your
""".split())

# Koncovky odrezane pri porovnani slov (nejdelsi nejdriv); kmen ma aspon 4 znaky
SUFFIXES = sorted("""
ovani eni ani ostmi ovych ovymi ove ovi ovy ova ach ech ich ami emi ymi ama ych ich em om um ou am at et it
ek ky ku ka ce ci ho mu ie es ing ed er ly s y u a e i o
""".split(), key=len, reverse=True)

_WORD = re.compile(r"[a-z0-9]+")
_HEADING = re.compile(r"^(#{1,3})[ \t]+(.+?)[ \t#]*$")
_FENCE = re.compile(r"^\s*(```|~~~)")


class DocsError(Exception):
    pass


def docs_dir():
    return os.environ.get("LUXAI_DOCS_DIR") or DEFAULT_DIR


def fold(text):
    """Mala pismena bez diakritiky ("Balíčky" -> "balicky")."""
    s = unicodedata.normalize("NFKD", str(text).lower())
    return "".join(c for c in s if not unicodedata.combining(c))


def stem(word):
    if len(word) <= 4 or word.isdigit():
        return word
    for suf in SUFFIXES:
        if word.endswith(suf) and len(word) - len(suf) >= 4:
            return word[:-len(suf)]
    return word


def terms(text, keep_stopwords=False):
    """Slova textu pro porovnani (bez diakritiky, s odriznutou koncovkou)."""
    out = []
    for w in _WORD.findall(fold(text)):
        if not keep_stopwords and (w in STOPWORDS or len(w) < 2 and not w.isdigit()):
            continue
        out.append(stem(w))
    return out


def _counts(words, weight, into):
    for w in words:
        into[w] = into.get(w, 0.0) + weight


def split_sections(text):
    """Sekce souboru Markdown: [{"heading", "level", "path", "start", "end"}] (radky start..end-1).
    Nadpisy uvnitr bloku kodu (``` / ~~~) se ignoruji; text pred prvnim nadpisem je sekce s heading ""."""
    lines = text.splitlines()
    heads, fence = [], None
    for i, line in enumerate(lines):
        m = _FENCE.match(line)
        if m:
            fence = None if fence == m.group(1) else (fence or m.group(1))
            continue
        if fence:
            continue
        h = _HEADING.match(line)
        if h:
            heads.append((i, len(h.group(1)), h.group(2).strip()))
    secs = []
    if not heads or heads[0][0] > 0:
        end = heads[0][0] if heads else len(lines)
        if any(x.strip() for x in lines[:end]):
            secs.append({"heading": "", "level": 0, "path": [], "start": 0, "end": end})
    stack = []
    for n, (i, level, title) in enumerate(heads):
        while stack and stack[-1][0] >= level:
            stack.pop()
        stack.append((level, title))
        end = heads[n + 1][0] if n + 1 < len(heads) else len(lines)
        secs.append({"heading": title, "level": level, "path": [t for _l, t in stack], "start": i, "end": end})
    return secs, lines


def safe_path(root, rel):
    """Absolutni cesta k souboru uvnitr korene dokumentace, jinak DocsError.
    Odmita absolutni cesty, '..', NUL a symbolicke odkazy vedouci ven."""
    rel = str(rel or "").strip().replace("\\", "/")
    if not rel or "\0" in rel or rel.startswith("/") or rel.startswith("~"):
        raise DocsError("Invalid documentation path: use a path from docs_search, e.g. luxos/lux.md")
    parts = [p for p in rel.split("/") if p not in ("", ".")]
    if not parts or any(p == ".." for p in parts):
        raise DocsError("Invalid documentation path: it must stay inside the documentation folder")
    real_root = os.path.realpath(root)
    full = os.path.realpath(os.path.join(real_root, *parts))
    if os.path.commonpath([real_root, full]) != real_root or full == real_root:
        raise DocsError("Invalid documentation path: it must stay inside the documentation folder")
    return full


class Library:
    """Nactena dokumentace: soubory, sekce a statistiky pro BM25."""

    def __init__(self, root):
        self.root = root
        self.collections = []      # [{"id", "title"}]
        self.files = {}            # rel -> {"collection", "title", "summary", "keywords", "abs"}
        self.sections = []         # sekce s klici file, heading, level, path, start, end, tf, len
        self.lines = {}            # rel -> radky souboru
        self.df = {}
        self.avg_len = 1.0
        self._load()

    # ---- nacteni ----------------------------------------------------------------------
    def _index(self):
        path = os.path.join(self.root, INDEX)
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        except FileNotFoundError:
            return None
        except (OSError, ValueError) as e:
            raise DocsError(f"The documentation index is damaged ({type(e).__name__}); reinstall luxos-docs") from None
        if not isinstance(data, dict) or not isinstance(data.get("collections"), list):
            raise DocsError("The documentation index has an unknown format; reinstall luxos-docs")
        return data

    def _scan(self):
        """Bez index.json: kazda podslozka je kolekce, soubory .md v ni."""
        cols = []
        for name in sorted(os.listdir(self.root)):
            d = os.path.join(self.root, name)
            if not os.path.isdir(d):
                continue
            files = []
            for dirpath, _dirs, names in os.walk(d):
                for n in sorted(names):
                    if n.endswith(TEXT_EXT):
                        files.append({"path": os.path.relpath(os.path.join(dirpath, n), self.root)})
            cols.append({"id": name, "title": name, "files": files})
        return {"collections": cols}

    def _load(self):
        data = self._index() or self._scan()
        total = 0
        for col in data["collections"]:
            if not isinstance(col, dict) or not isinstance(col.get("id"), str):
                continue
            cid = col["id"]
            self.collections.append({"id": cid, "title": str(col.get("title") or cid)})
            for entry in col.get("files") or []:
                if total >= MAX_FILES:
                    break
                if isinstance(entry, str):
                    entry = {"path": entry}
                if not isinstance(entry, dict) or not isinstance(entry.get("path"), str):
                    continue
                rel = entry["path"].strip()
                while rel.startswith("./"):
                    rel = rel[2:]
                try:
                    full = safe_path(self.root, rel)
                except DocsError:
                    continue   # polozka indexu mimo koren se preskoci
                if rel in self.files or not os.path.isfile(full) or os.path.getsize(full) > MAX_FILE_BYTES:
                    continue
                try:
                    with open(full, encoding="utf-8", errors="replace") as f:
                        text = f.read()
                except OSError:
                    continue
                kw = entry.get("keywords") if isinstance(entry.get("keywords"), list) else []
                info = {"collection": cid, "title": str(entry.get("title") or os.path.basename(rel)),
                        "summary": str(entry.get("summary") or ""), "keywords": [str(k) for k in kw], "abs": full}
                self.files[rel] = info
                total += 1
                self._add_file(rel, info, text)
        n = len(self.sections)
        self.avg_len = (sum(s["len"] for s in self.sections) / n) if n else 1.0

    def _add_file(self, rel, info, text):
        secs, lines = split_sections(text)
        self.lines[rel] = lines
        file_terms = {}
        _counts(terms(info["title"] + " " + " ".join(info["keywords"]) + " " + info["summary"]), W_FILE, file_terms)
        for s in secs:
            tf = dict(file_terms)
            _counts(terms(s["heading"]), W_HEADING, tf)
            _counts(terms(" ".join(s["path"][:-1])), W_PARENT, tf)   # nadrazene nadpisy maji mensi vahu
            body = lines[s["start"] + (1 if s["level"] else 0):s["end"]]
            _counts(terms("\n".join(body)), W_BODY, tf)
            s.update(file=rel, tf=tf, len=sum(tf.values()) or 1.0)
            self.sections.append(s)
            for t in tf:
                self.df[t] = self.df.get(t, 0) + 1

    # ---- dotazy -----------------------------------------------------------------------
    def collection_id(self, name):
        if not name:
            return None
        f = fold(name).strip()
        for c in self.collections:
            if fold(c["id"]) == f or fold(c["title"]) == f:
                return c["id"]
        raise DocsError("Unknown documentation collection {0!r}; available: {1}".format(
            name, ", ".join(c["id"] for c in self.collections)))

    def section_text(self, s):
        return "\n".join(self.lines[s["file"]][s["start"]:s["end"]]).strip()

    def expand(self, term):
        """Slovo dotazu -> [(slovo v dokumentaci, vaha)]. Bez presne shody i slova se spolecnym zacatkem
        (cesky tvar "balicky" najde "balik", "instalace" najde "instalovat")."""
        if term in self.df:
            return [(term, 1.0)]
        if len(term) < 4 or term.isdigit():
            return []
        out = []
        for v in self.df:
            if v[:4] != term[:4]:
                continue
            common = len(os.path.commonprefix([v, term]))
            if common >= max(4, min(len(v), len(term)) - 2):
                out.append((v, 0.7))
        return out

    def search(self, query, collection=None, limit=DEFAULT_RESULTS):
        col = self.collection_id(collection)
        q = terms(query)
        if not q:
            q = terms(query, keep_stopwords=True)
        q = list(dict.fromkeys(q))
        if not q:
            return []
        expanded = [self.expand(t) for t in q]
        n = len(self.sections)
        phrase = " ".join(_WORD.findall(fold(query)))
        scored = []
        for s in self.sections:
            if col and self.files[s["file"]]["collection"] != col:
                continue
            score, hit = 0.0, 0
            norm = K1 * (1 - B + B * s["len"] / self.avg_len)
            for alts in expanded:
                part = 0.0
                for t, w in alts:
                    f = s["tf"].get(t)
                    if f:
                        df = self.df.get(t, 0)
                        idf = math.log(1 + (n - df + 0.5) / (df + 0.5))
                        part = max(part, w * idf * f * (K1 + 1) / (f + norm))
                if part:
                    hit += 1
                    score += part
            if not hit:
                continue
            score *= (0.5 + 0.5 * hit / len(q))   # sekce s vice slovy dotazu ma prednost
            if len(q) > 1 and phrase and phrase in " ".join(_WORD.findall(fold(" ".join(s["path"]) + " " +
                                                                                self.section_text(s)))):
                score *= 1.5
            scored.append((score, s))
        scored.sort(key=lambda x: (-x[0], x[1]["file"], x[1]["start"]))
        out = []
        for score, s in scored[:max(1, min(int(limit or DEFAULT_RESULTS), MAX_RESULTS))]:
            info = self.files[s["file"]]
            out.append({"collection": info["collection"], "file": s["file"], "title": info["title"],
                        "heading": " > ".join(s["path"]), "snippet": self.snippet(s, {t for alts in expanded for t, _w in alts}),
                        "score": round(score, 2)})
        return out

    def snippet(self, s, q):
        """Kratky usek textu sekce kolem prvniho radku se slovem dotazu."""
        lines = self.lines[s["file"]][s["start"] + (1 if s["level"] else 0):s["end"]]
        lines = [x.strip() for x in lines if x.strip() and not _FENCE.match(x)]
        if not lines:
            return ""
        qs = set(q)
        best = 0
        for i, x in enumerate(lines):
            if qs & set(terms(x)):
                best = i
                break
        text = re.sub(r"\s+", " ", " ".join(lines[best:best + 6]))
        return text if len(text) <= SNIPPET_CHARS else text[:SNIPPET_CHARS - 1].rstrip() + "…"

    def resolve(self, path):
        """Relativni cesta souboru v knihovne (presna, bez kolekce nebo bez pripony .md)."""
        rel = str(path or "").strip().replace("\\", "/")
        if rel.startswith("./"):
            rel = rel[2:]
        safe_path(self.root, rel)      # odmitne pruchod mimo koren i u neexistujicich souboru
        if rel in self.files:
            return rel
        want = rel if rel.endswith(TEXT_EXT) else rel + ".md"
        if want in self.files:
            return want
        cands = [r for r in self.files if r.endswith("/" + want) or os.path.basename(r) == want]
        if len(cands) == 1:
            return cands[0]
        if cands:
            raise DocsError("Ambiguous documentation path {0!r}; use one of: {1}".format(path, ", ".join(cands)))
        raise DocsError("No documentation file {0!r}; use a path returned by docs_search".format(path))

    def read(self, path, heading=None, limit=MAX_READ_CHARS):
        rel = self.resolve(path)
        info = self.files[rel]
        secs = [s for s in self.sections if s["file"] == rel]
        headings = [("#" * s["level"] + " " + s["heading"]) for s in secs if s["level"]]
        out = {"ok": True, "collection": info["collection"], "file": rel, "title": info["title"]}
        if heading:
            s = self.find_section(secs, heading)
            if s is None:
                return {"ok": False, "file": rel,
                        "error": "No section {0!r} in {1}; pick one of the headings".format(heading, rel),
                        "headings": headings[:MAX_HEADINGS]}
            end = s["end"]
            for o in secs:   # sekce vcetne svych podsekci (do dalsiho nadpisu stejne nebo vyssi urovne)
                if o["start"] > s["start"] and o["level"] and o["level"] <= s["level"]:
                    end = o["start"]
                    break
            else:
                end = len(self.lines[rel])
            text = "\n".join(self.lines[rel][s["start"]:end]).strip()
            out["heading"] = " > ".join(s["path"])
        else:
            text = "\n".join(self.lines[rel]).strip()
        if len(text) > limit:
            cut = text.rfind("\n", 0, limit)
            text = text[:cut if cut > limit // 2 else limit].rstrip()
            shown = set(text.splitlines())
            rest = [h for h in headings if h not in shown]    # nadpisy casti, ktere se nevesly
            out["truncated"] = True
            out["note"] = ("The text was shortened. Read the remaining parts with docs_read(path, heading) "
                           "using one of the headings.")
            out["headings"] = rest[:MAX_HEADINGS]
            if len(rest) > MAX_HEADINGS:
                out["more_headings"] = len(rest) - MAX_HEADINGS
        out["content"] = text
        return out

    @staticmethod
    def find_section(secs, heading):
        h = fold(heading).strip().lstrip("#").strip()
        h = re.sub(r"\s+", " ", h)
        if not h:
            return None
        named = [s for s in secs if s["level"]]
        for test in (lambda s: fold(s["heading"]) == h,
                     lambda s: fold(" > ".join(s["path"])) == h,
                     lambda s: fold(" > ".join(s["path"])).endswith(h),
                     lambda s: h in fold(s["heading"])):
            for s in named:
                if test(s):
                    return s
        return None


_cache = {"key": None, "lib": None}
_lock = threading.Lock()


def _stamp(root):
    """Klic cache: koren a casy zmen indexu i souboru (po aktualizaci luxos-docs se knihovna nacte znovu)."""
    out = [os.path.realpath(root)]
    try:
        out.append(os.stat(os.path.join(root, INDEX)).st_mtime_ns)
    except OSError:
        out.append(None)
    try:
        out.append(os.stat(root).st_mtime_ns)
    except OSError:
        out.append(None)
    return tuple(out)


def library(root=None):
    """Nactena knihovna (cache), nebo None, kdyz dokumentace neni nainstalovana."""
    root = root or docs_dir()
    if not os.path.isdir(root):
        return None
    key = _stamp(root)
    with _lock:
        if _cache["key"] == key and _cache["lib"] is not None:
            return _cache["lib"]
        lib = Library(root)
        _cache.update(key=key, lib=lib)
        return lib


def missing_result():
    return {"ok": False, "docs_missing": True,
            "error": "The offline LuxOS documentation is not installed (package luxos-docs, folder {0}). Answer "
                     "from general knowledge and say that the reference was not available; the user can install "
                     "it with `lux install luxos-docs`.".format(docs_dir())}


def search(query, collection=None, limit=DEFAULT_RESULTS):
    if not isinstance(query, str) or not query.strip():
        return {"ok": False, "error": "query must be a non-empty string"}
    if collection is not None and not isinstance(collection, str):
        return {"ok": False, "error": "collection must be a string"}
    try:
        lib = library()
        if lib is None:
            return missing_result()
        if not lib.files:
            return dict(missing_result(), error="The LuxOS documentation folder contains no documents.")
        res = lib.search(query.strip()[:500], collection or None, limit)
    except (DocsError, OSError) as e:
        return {"ok": False, "error": str(e) if isinstance(e, DocsError) else f"{type(e).__name__}: {e}"}
    out = {"ok": True, "query": query.strip()[:500], "results": res}
    if collection:
        out["collection"] = collection
    if res:
        out["hint"] = "Read more with docs_read(path=file, heading=heading)."
    else:
        out["note"] = ("No matching section. Try other or fewer words (Czech or English), or another collection: "
                       + ", ".join(c["id"] for c in lib.collections))
    return out


def read(path, heading=None):
    if not isinstance(path, str) or not path.strip():
        return {"ok": False, "error": "path must be a non-empty string"}
    if heading is not None and not isinstance(heading, str):
        return {"ok": False, "error": "heading must be a string"}
    try:
        lib = library()
        if lib is None:
            return missing_result()
        return lib.read(path, heading or None)
    except (DocsError, OSError) as e:
        return {"ok": False, "error": str(e) if isinstance(e, DocsError) else f"{type(e).__name__}: {e}"}
