"""Zvyrazneni syntaxe v blocich kodu (bez zavislosti, jen regularni vyrazy) -> Pango markup.

  highlight(code, lang, dark)  -> escapovany Pango markup se <span foreground=...> (prosty text zustava
                                  stejny, takze vyber mysi i kopirovani daji puvodni kod)
  language_name(lang)          -> citelny nazev jazyka pro hlavicku bloku ("Python", "Bash" ...) nebo None

Jazyky: Python, Bash/shell, LSL (Lux Simple Lang), JavaScript/TypeScript, C/C++, JSON, HTML/XML, CSS,
SQL, YAML/TOML/INI, diff a nekolik dalsich C-podobnych (Java, Go, Rust, C#, PHP, Kotlin). Neznamy jazyk:
obecne zvyrazneni (retezce, cisla, komentare). Barvy jsou pro svetly i tmavy motiv (kontrast aspon 4.5:1
vuci pozadi bloku kodu, viz testy).
"""
import functools
import re
from html import escape as _esc

MAX_CHARS = 200000              # vetsi blok se nezvyraznuje (rychlost)

# Barvy podle motivu (pozadi bloku kodu: svetle #f3f4f8, tmave #15161f)
PALETTE = {
    False: {"keyword": "#c4162a", "string": "#0a3069", "comment": "#5f6670", "number": "#0550ae",
            "builtin": "#7239c9", "type": "#8a3a00", "variable": "#8a3a00", "tag": "#116329", "attr": "#0550ae",
            "function": "#6639ba", "deleted": "#b31d28", "inserted": "#116329", "meta": "#5f6670"},
    True: {"keyword": "#ff7b72", "string": "#a5d6ff", "comment": "#8b949e", "number": "#79c0ff",
           "builtin": "#d2a8ff", "type": "#ffa657", "variable": "#ffa657", "tag": "#7ee787", "attr": "#79c0ff",
           "function": "#d2a8ff", "deleted": "#ffa198", "inserted": "#7ee787", "meta": "#8b949e"},
}
CODE_BG = {False: "#f3f4f8", True: "#15161f"}

ALIASES = {
    "py": "python", "python3": "python", "py3": "python", "python": "python", "pyw": "python", "ipython": "python",
    "sh": "bash", "bash": "bash", "shell": "bash", "zsh": "bash", "console": "bash", "shellsession": "bash",
    "ksh": "bash", "terminal": "bash", "fish": "bash",
    "lsl": "lsl", "lux": "lsl",
    "js": "javascript", "javascript": "javascript", "jsx": "javascript", "mjs": "javascript", "cjs": "javascript",
    "node": "javascript",
    "ts": "typescript", "typescript": "typescript", "tsx": "typescript",
    "c": "c", "h": "c", "cpp": "cpp", "c++": "cpp", "cc": "cpp", "cxx": "cpp", "hpp": "cpp", "hh": "cpp",
    "json": "json", "jsonc": "json", "json5": "json", "geojson": "json",
    "html": "html", "htm": "html", "xhtml": "html", "xml": "xml", "svg": "xml", "xsl": "xml", "plist": "xml",
    "css": "css", "scss": "css", "less": "css",
    "sql": "sql", "mysql": "sql", "postgresql": "sql", "postgres": "sql", "sqlite": "sql", "plsql": "sql",
    "yaml": "yaml", "yml": "yaml", "toml": "toml", "ini": "ini", "conf": "ini", "cfg": "ini", "desktop": "ini",
    "diff": "diff", "patch": "diff",
    "java": "java", "go": "go", "golang": "go", "rust": "rust", "rs": "rust", "cs": "csharp", "csharp": "csharp",
    "c#": "csharp", "php": "php", "kotlin": "kotlin", "kt": "kotlin",
}
NAMES = {"python": "Python", "bash": "Bash", "lsl": "LSL", "javascript": "JavaScript", "typescript": "TypeScript",
         "c": "C", "cpp": "C++", "json": "JSON", "html": "HTML", "xml": "XML", "css": "CSS", "sql": "SQL",
         "yaml": "YAML", "toml": "TOML", "ini": "INI", "diff": "Diff", "java": "Java", "go": "Go", "rust": "Rust",
         "csharp": "C#", "php": "PHP", "kotlin": "Kotlin"}


def canonical(lang):
    lang = (lang or "").strip().lower()
    return ALIASES.get(lang, "")


def language_name(lang):
    c = canonical(lang)
    if c:
        return NAMES[c]
    return None


def _words(text):
    return r"\b(?:" + "|".join(sorted(set(text.split()), key=len, reverse=True)) + r")\b"


# ---- spolecne vzory ------------------------------------------------------------------------------
NUM = r"\b(?:0[xX][0-9a-fA-F_]+|0[bB][01_]+|0[oO][0-7_]+|\d[\d_]*(?:\.\d[\d_]*)?(?:[eE][+-]?\d+)?)[a-zA-Z]{0,3}\b" \
      r"|(?<![\w.])\.\d+(?:[eE][+-]?\d+)?\b"
DQ = r'"(?:\\.|[^"\\\n])*"?'
SQ = r"'(?:\\.|[^'\\\n])*'?"
BT = r"`(?:\\.|[^`\\])*`?"
C_COMMENT = r"//[^\n]*|/\*[\s\S]*?(?:\*/|\Z)"
HASH_COMMENT = r"#[^\n]*"

PY_KW = """and as assert async await break class continue def del elif else except finally for from global if import
in is lambda nonlocal not or pass raise return try while with yield match case"""
PY_BUILTIN = """print len range str int float bool list dict set tuple open isinstance enumerate zip map filter sorted
sum min max abs any all super object type repr input format iter next hasattr getattr setattr round reversed
self cls Exception ValueError TypeError KeyError IndexError OSError RuntimeError"""
SH_KW = """if then else elif fi for while until do done case esac function in select return local export readonly
declare set unset shift exit break continue time"""
SH_BUILTIN = """echo printf cd pwd source alias test read eval exec trap kill sudo cat grep sed awk ls cp mv rm mkdir
chmod chown find xargs tar curl wget git systemctl journalctl lux flatpak python3 head tail sort uniq wc tee touch
ln which env true false"""
LSL_KW = """if elif else for while loop function class safe try unsafe lock end return call load as in and or not
break continue global from import"""
LSL_BUILTIN = """print len range String Int Float Bool List Tuple Dictionary Set RealArray IntArray FloatArray
ByteArray Function Any Error check del type input arg readfile writefile chr ord self"""
JS_KW = """break case catch class const continue debugger default delete do else export extends finally for
function if import in instanceof let new return super switch this throw try typeof var void while with yield async
await of static get set from as"""
TS_KW = JS_KW + """ interface type enum implements readonly declare namespace abstract private protected public
keyof infer is satisfies"""
JS_CONST = "true false null undefined NaN Infinity"
JS_BUILTIN = """console Math JSON Promise Array Object String Number Boolean Map Set Date RegExp Error document
window require module exports process globalThis fetch setTimeout"""
TS_TYPES = "string number boolean any unknown void never object bigint symbol"
C_KW = """auto break case const continue default do else enum extern for goto if inline register restrict return
sizeof static struct switch typedef union volatile while"""
CPP_KW = C_KW + """ alignas alignof and asm catch class constexpr consteval constinit co_await co_return
co_yield decltype delete dynamic_cast explicit export friend mutable namespace new noexcept not operator or
private protected public reinterpret_cast static_assert static_cast template this throw try typeid typename using
virtual override final"""
C_TYPES = """int char void float double long short unsigned signed bool size_t ssize_t int8_t int16_t int32_t
int64_t uint8_t uint16_t uint32_t uint64_t FILE wchar_t _Bool"""
CPP_TYPES = C_TYPES + " std string vector map unique_ptr shared_ptr auto nullptr_t"
C_CONST = "NULL true false nullptr EOF stdin stdout stderr"
SQL_KW = """select from where and or not insert into values update set delete create table drop alter add column
index view join left right inner outer full cross on as group by order having limit offset union all distinct
case when then else end is null like in between exists primary key foreign references unique default check
begin commit rollback transaction if returning with asc desc grant revoke truncate"""
SQL_FN = "count sum avg min max coalesce now length upper lower substr round cast date"
SQL_TYPES = "int integer bigint smallint text varchar char boolean real float double numeric decimal date timestamp blob serial uuid json jsonb"  # noqa: E501
JAVA_KW = """abstract assert break case catch class const continue default do else enum extends final finally for
goto if implements import instanceof interface native new package private protected public return static strictfp
super switch synchronized this throw throws transient try volatile while var record"""
JAVA_TYPES = "boolean byte char double float int long short void String Integer Object List Map"
GO_KW = """break case chan const continue default defer else fallthrough for func go goto if import interface map
package range return select struct switch type var"""
GO_TYPES = "bool byte complex64 complex128 error float32 float64 int int8 int16 int32 int64 rune string uint uint8 uint16 uint32 uint64 uintptr any"  # noqa: E501
RUST_KW = """as async await break const continue crate dyn else enum extern fn for if impl in let loop match mod
move mut pub ref return self Self static struct super trait type unsafe use where while"""
RUST_TYPES = "bool char str String i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize f32 f64 Vec Option Result Box"
CS_KW = """abstract as base break case catch checked class const continue default delegate do else enum event
explicit extern finally fixed for foreach goto if implicit in interface internal is lock namespace new operator out
override params private protected public readonly ref return sealed sizeof stackalloc static struct switch this
throw try typeof unchecked unsafe using virtual volatile while async await var"""
CS_TYPES = "bool byte char decimal double float int long object sbyte short string uint ulong ushort void"
PHP_KW = """abstract and array as break callable case catch class clone const continue declare default do echo else
elseif empty enddeclare endfor endforeach endif endswitch endwhile extends final finally fn for foreach function
global goto if implements include include_once instanceof insteadof interface isset list match namespace new or
print private protected public require require_once return static switch throw trait try unset use var while yield"""
KT_KW = """as break class continue do else for fun if in interface is null object package return super this throw
try typealias val var when while by catch constructor init finally import override private public internal data
sealed open companion suspend"""


def _rules(lang):
    """Seznam (typ_tokenu, regex) pro jazyk; poradi = priorita (komentare a retezce prvni)."""
    if lang == "python":
        return [("comment", HASH_COMMENT),
                ("string", r"(?i:[rbuf]{0,2})(?:\"\"\"[\s\S]*?(?:\"\"\"|\Z)|'''[\s\S]*?(?:'''|\Z))"),
                ("string", r"(?i:[rbuf]{0,2})(?:" + DQ + "|" + SQ + ")"),
                ("meta", r"^[ \t]*@[\w.]+"), ("function", r"(?<=\bdef )\w+|(?<=\bclass )\w+"),
                ("type", r"\b(?:True|False|None)\b"), ("keyword", _words(PY_KW)),
                ("builtin", _words(PY_BUILTIN)), ("number", NUM)]
    if lang == "bash":
        return [("comment", r"(?<![^\s;|&(])#[^\n]*"), ("string", r"'[^']*'?"),
                ("string", r'"(?:\\.|[^"\\])*"?'),
                ("variable", r"\$\{[^}\n]*\}?|\$\w+|\$[@*#?$!0-9-]"),
                ("keyword", _words(SH_KW)), ("builtin", _words(SH_BUILTIN)),
                ("attr", r"(?<![\w-])--?[A-Za-z][\w-]*"), ("number", r"\b\d+\b")]
    if lang == "lsl":
        return [("comment", r"#[^\n]*|/\*[\s\S]*?(?:\*/|\Z)"), ("string", DQ), ("string", SQ),
                ("function", r"(?<=\bfunction )\w+|(?<=\bclass )\w+"), ("type", r"\b(?:True|False|None)\b"),
                ("keyword", _words(LSL_KW)), ("builtin", _words(LSL_BUILTIN)), ("number", NUM)]
    if lang in ("javascript", "typescript"):
        rules = [("comment", C_COMMENT), ("string", DQ), ("string", SQ), ("string", BT),
                 ("function", r"(?<=\bfunction )\w+|(?<=\bclass )\w+"),
                 ("type", _words(JS_CONST)), ("keyword", _words(TS_KW if lang == "typescript" else JS_KW)),
                 ("builtin", _words(JS_BUILTIN)), ("number", NUM)]
        if lang == "typescript":
            rules.insert(-2, ("type", _words(TS_TYPES)))
        return rules
    if lang in ("c", "cpp"):
        return [("comment", C_COMMENT), ("meta", r"^[ \t]*#[ \t]*\w+[^\n]*"), ("string", DQ),
                ("string", r"'(?:\\.|[^'\\\n]){1,8}'"),
                ("type", _words(CPP_TYPES if lang == "cpp" else C_TYPES)),
                ("keyword", _words(CPP_KW if lang == "cpp" else C_KW)), ("builtin", _words(C_CONST)),
                ("function", r"\b[A-Za-z_]\w*(?=\s*\()"), ("number", NUM)]
    if lang == "json":
        return [("comment", C_COMMENT), ("attr", DQ + r"(?=\s*:)"), ("string", DQ),
                ("type", r"\b(?:true|false|null)\b"), ("number", r"-?\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b")]
    if lang == "css":
        return [("comment", r"/\*[\s\S]*?(?:\*/|\Z)"), ("string", DQ), ("string", SQ),
                ("keyword", r"@[\w-]+|!important"), ("attr", r"(?<![\w-])-{0,2}[a-zA-Z][\w-]*(?=\s*:[^;{}\n]*[;}])"),
                ("number", r"#[0-9a-fA-F]{3,8}\b|(?<![\w-])-?\d*\.?\d+(?:px|em|rem|%|vh|vw|vmin|vmax|s|ms|deg|fr|pt|ch|ex)?\b"),
                ("builtin", r"[\w-]+(?=\()"), ("tag", r"(?<![\w-])[.#][A-Za-z_][\w-]*")]
    if lang == "sql":
        return [("comment", r"--[^\n]*|/\*[\s\S]*?(?:\*/|\Z)"), ("string", r"'(?:''|[^'])*'?"),
                ("attr", r'"(?:""|[^"])*"?|`[^`]*`?'), ("type", r"(?i:" + _words(SQL_TYPES) + ")"),
                ("keyword", r"(?i:" + _words(SQL_KW) + ")"), ("builtin", r"(?i:" + _words(SQL_FN) + r")(?=\s*\()"),
                ("number", r"\b\d+(?:\.\d+)?\b")]
    if lang in ("yaml", "toml", "ini"):
        return [("comment", r"(?<![^\s])[#;][^\n]*"), ("meta", r"^[ \t]*\[[^\]\n]*\]"),
                ("string", DQ), ("string", SQ), ("attr", r"^[ \t]*-?[ \t]*[\w.\-/]+(?=[ \t]*[:=])"),
                ("type", r"\b(?:true|false|null|yes|no|on|off|True|False)\b"), ("number", NUM)]
    if lang == "diff":
        return [("meta", r"^(?:@@[^\n]*|diff [^\n]*|index [^\n]*|\+\+\+[^\n]*|---[^\n]*)"),
                ("inserted", r"^\+[^\n]*"), ("deleted", r"^-[^\n]*")]
    if lang in ("java", "go", "rust", "csharp", "php", "kotlin"):
        kw = {"java": JAVA_KW, "go": GO_KW, "rust": RUST_KW, "csharp": CS_KW, "php": PHP_KW, "kotlin": KT_KW}[lang]
        types = {"java": JAVA_TYPES, "go": GO_TYPES, "rust": RUST_TYPES, "csharp": CS_TYPES}.get(lang, "")
        rules = [("comment", C_COMMENT + ("|" + HASH_COMMENT if lang == "php" else "")), ("string", DQ),
                 ("string", SQ if lang != "rust" else r"'(?:\\.|[^'\\\n])'"), ("string", BT if lang == "go" else DQ),
                 ("type", r"\b(?:true|false|null|nil|None|Some|Ok|Err)\b"), ("keyword", _words(kw))]
        if types:
            rules.append(("type", _words(types)))
        if lang == "php":
            rules.append(("variable", r"\$\w+"))
        return rules + [("function", r"\b[A-Za-z_]\w*(?=\s*\()"), ("number", NUM)]
    # obecny: komentare, retezce, cisla
    return [("comment", r"(?<![^\s])(?:#|//)[^\n]*|/\*[\s\S]*?(?:\*/|\Z)"), ("string", DQ), ("string", SQ),
            ("number", NUM)]


@functools.lru_cache(maxsize=None)
def _compiled(lang):
    rules = _rules(lang)
    parts = [f"(?P<t{i}>{rx})" for i, (_kind, rx) in enumerate(rules)]
    return re.compile("|".join(parts), re.M), [kind for kind, _rx in rules]


def esc(text):
    return _esc(text, quote=False)


def _span(kind, text, colors):
    color = colors.get(kind)
    if not color or not text:
        return esc(text)
    style = ' style="italic"' if kind == "comment" else ""
    weight = ' weight="bold"' if kind == "keyword" else ""
    return f'<span foreground="{color}"{style}{weight}>{esc(text)}</span>'


def _tokens(code, lang, colors):
    rx, kinds = _compiled(lang)
    out, pos = [], 0
    for m in rx.finditer(code):
        if m.start() == m.end():
            continue
        out.append(esc(code[pos:m.start()]))
        kind = kinds[int(m.lastgroup[1:])]
        out.append(_span(kind, m.group(0), colors))
        pos = m.end()
    out.append(esc(code[pos:]))
    return "".join(out)


_TAG = re.compile(r"<!--[\s\S]*?(?:-->|\Z)|<!\[CDATA\[[\s\S]*?(?:\]\]>|\Z)|<![^>]*>?|<\?[\s\S]*?(?:\?>|\Z)"
                  r"|</?[A-Za-z][\w:.-]*(?:\s+[^<>]*?)?/?>|&\w+;|&#\w+;")
_ATTR = re.compile(r"([\w:.@-]+)(\s*=\s*)(\"[^\"]*\"?|'[^']*'?|[^\s\"'>]+)?|(\"[^\"]*\"|'[^']*')")


def _markup_lang(code, colors, html):
    out, pos = [], 0
    while True:
        m = _TAG.search(code, pos)
        if m is None:
            break
        out.append(esc(code[pos:m.start()]))
        t = m.group(0)
        pos = m.end()
        if t.startswith("<!--") or t.startswith("<!") or t.startswith("<?"):
            out.append(_span("comment" if t.startswith("<!--") else "meta", t, colors))
            continue
        if t.startswith("&"):
            out.append(_span("number", t, colors))
            continue
        name = re.match(r"</?[\w:.-]+", t).group(0)
        out.append(_span("tag", name, colors))
        rest = t[len(name):]
        end = re.search(r"/?>$", rest)
        inner, close = (rest[:end.start()], end.group(0)) if end else (rest, "")
        ipos = 0
        for a in _ATTR.finditer(inner):
            out.append(esc(inner[ipos:a.start()]))
            if a.group(1):
                out.append(_span("attr", a.group(1), colors) + esc(a.group(2) or "") +
                           _span("string", a.group(3) or "", colors))
            else:
                out.append(_span("string", a.group(4), colors))
            ipos = a.end()
        out.append(esc(inner[ipos:]))
        out.append(_span("tag", close, colors))
        # obsah <script> a <style> jako JavaScript / CSS
        tag = name.lstrip("<").lower()
        if html and tag in ("script", "style") and not close.startswith("/"):
            endm = re.compile(rf"</{tag}\s*>", re.I).search(code, pos)
            stop = endm.start() if endm else len(code)
            out.append(_tokens(code[pos:stop], "javascript" if tag == "script" else "css", colors))
            pos = stop
    out.append(esc(code[pos:]))
    return "".join(out)


@functools.lru_cache(maxsize=128)
def highlight(code, lang="", dark=False):
    """Kod -> Pango markup. Prosty text vysledku je vzdy presne `code`."""
    code = code or ""
    if len(code) > MAX_CHARS:
        return esc(code)
    colors = PALETTE[bool(dark)]
    c = canonical(lang)
    if c in ("html", "xml"):
        return _markup_lang(code, colors, c == "html")
    return _tokens(code, c or "generic", colors)
