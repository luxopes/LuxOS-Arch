"""Preklady: _("English") -> text v jazyce uzivatele.

Nejdriv se nacte systemovy soubor LuxOS (/usr/share/luxos/i18n/<jazyk>.tsv,
stejny jako pouziva luxos_i18n.py), potom vlastni soubor aplikace
(<koren aplikace>/i18n/<jazyk>.tsv), ktery ma prednost.
Format: radek "anglicky<TAB>preklad", radky s # jsou komentare.
"""
import os

APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SYSTEM_DIR = "/usr/share/luxos/i18n"


def detect_lang(env=None):
    env = os.environ if env is None else env
    lang = env.get("LC_ALL") or env.get("LC_MESSAGES") or env.get("LANG") or "en"
    return lang.split("_")[0].split(".")[0].split("@")[0] or "en"


def load_tsv(path, into):
    """Doplni preklady ze souboru do slovniku; chybejici soubor se ignoruje."""
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                if line.startswith("#") or "\t" not in line:
                    continue
                k, v = line.rstrip("\n").split("\t", 1)
                if k and v:
                    into[k] = v
    except OSError:
        pass
    return into


LANG = detect_lang()
_TR = {}
if LANG != "en":
    load_tsv(os.path.join(SYSTEM_DIR, f"{LANG}.tsv"), _TR)
    load_tsv(os.path.join(APP_ROOT, "i18n", f"{LANG}.tsv"), _TR)


def _(text):
    return _TR.get(text, text)
