"""Prilohy zpravy uzivatele: obrazky (vlozene ze schranky nebo ze souboru) a textove soubory.

Vrstva je nezavisla na GTK (prevod obrazku na JPEG/PNG data URL dela app.py pres GdkPixbuf).
Zprava s prilohami ma obsah jako seznam casti (OpenAI format):
  [{"type": "text", "text": <text uzivatele>}, {"type": "text", "text": <obsah textoveho souboru>},
   {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,..."}}]
a navic klice "_text" (co uzivatel napsal) a "_attachments" ([{"kind", "name"}]) pro zobrazeni v okne.
Obrazky v historii zustavaji vzdy; co z nich model dostane, urcuje agent.api_messages podle modelu.
"""
import mimetypes
import os

from .i18n import _

MAX_IMAGES = 4              # obrazku v jedne zprave (stejne jako agent.MAX_HISTORY_IMAGES)
MAX_ATTACHMENTS = 8
MAX_TEXT_CHARS = 60000      # textovy soubor se do zpravy vlozi nejvyse v teto delce
MAX_IMAGE_FILE = 25 * 1024 * 1024
MAX_IMAGE_URL_CHARS = 300000  # data URL jednoho obrazku po zmenseni (limit tela pozadavku serveru)
TEXT_SNIFF = 8192


class AttachmentError(Exception):
    pass


def classify(path):
    """"image" | "text" | "other" podle pripony a obsahu souboru."""
    mime = mimetypes.guess_type(path)[0] or ""
    if mime.startswith("image/") and mime != "image/svg+xml":
        return "image"
    try:
        with open(path, "rb") as f:
            head = f.read(TEXT_SNIFF)
    except OSError:
        return "other"
    if head.startswith((b"\x89PNG", b"\xff\xd8\xff", b"GIF8", b"BM")) or (head[:4] == b"RIFF" and
                                                                         head[8:12] == b"WEBP"):
        return "image"
    if b"\0" in head:
        return "other"
    try:
        head.decode("utf-8")
    except UnicodeDecodeError as e:
        # rozdeleny vicebajtovy znak na konci ukazky je v poradku
        if e.start < len(head) - 4:
            return "other"
    return "text"


def text_attachment(path):
    """{"kind": "text", "name", "text"} z textoveho souboru (zkraceneho na MAX_TEXT_CHARS)."""
    name = os.path.basename(path)
    try:
        with open(path, "rb") as f:
            raw = f.read(MAX_TEXT_CHARS * 4 + 1)
    except OSError as e:
        raise AttachmentError(_("{0} cannot be read: {1}").format(name, e.strerror or e)) from None
    text = raw.decode("utf-8", "replace")
    truncated = len(text) > MAX_TEXT_CHARS or len(raw) > MAX_TEXT_CHARS * 4
    if truncated:
        text = text[:MAX_TEXT_CHARS]
    return {"kind": "text", "name": name, "text": text, "truncated": truncated}


def text_part(att):
    """Cast zpravy s obsahem textoveho souboru."""
    note = f"\n[file truncated to the first {MAX_TEXT_CHARS} characters]" if att.get("truncated") else ""
    fence = "````" if "```" in att["text"] else "```"
    return {"type": "text", "text": f"Attached file \"{att['name']}\":\n{fence}\n{att['text']}\n{fence}{note}"}


def check_limits(current, kind):
    """Chybova hlaska, kdyz dalsi priloha daneho druhu prekroci limit, jinak None."""
    if len(current) >= MAX_ATTACHMENTS:
        return _("At most {0} attachments can be added to one message.").format(MAX_ATTACHMENTS)
    if kind == "image" and sum(1 for a in current if a["kind"] == "image") >= MAX_IMAGES:
        return _("At most {0} images can be added to one message.").format(MAX_IMAGES)
    return None


def user_message(text, attachments):
    """Zprava uzivatele (dict pro historii) z textu a priloh."""
    text = text or ""
    if not attachments:
        return {"role": "user", "content": text}
    parts = [{"type": "text", "text": text}] if text.strip() else []
    parts += [text_part(a) for a in attachments if a["kind"] == "text"]
    parts += [{"type": "image_url", "image_url": {"url": a["url"]}} for a in attachments if a["kind"] == "image"]
    return {"role": "user", "content": parts, "_text": text,
            "_attachments": [{"kind": a["kind"], "name": a.get("name") or ""} for a in attachments]}


def message_parts(m):
    """(text uzivatele, [data URL obrazku], [nazvy textovych souboru]) pro zobrazeni zpravy."""
    c = m.get("content")
    if isinstance(c, str):
        return c, [], []
    images = [p["image_url"].get("url", "") for p in c or [] if isinstance(p, dict) and p.get("type") == "image_url"
              and isinstance(p.get("image_url"), dict)]
    files = [a.get("name", "") for a in m.get("_attachments") or [] if a.get("kind") == "text"]
    if isinstance(m.get("_text"), str):
        text = m["_text"]
    else:
        text = "\n".join(p.get("text", "") for p in c or [] if isinstance(p, dict) and p.get("type") == "text")
    return text, images, files
