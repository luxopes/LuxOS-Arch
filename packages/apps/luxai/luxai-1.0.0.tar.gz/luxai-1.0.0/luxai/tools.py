"""Nastroje agenta LuxAI: shell, soubory, aplikace a URL, obrazovka, mys a klavesnice, okna,
schranka, oznameni, hlaseni chyb a napadu autorovi LuxOS (send_feedback).

Vrstva je nezavisla na GTK: veci, ktere musi bezet v hlavnim vlakne (snimek obrazovky,
schranka), dodava objekt `gui` (viz GuiBridge v app.py). Kazdy nastroj vraci slovnik
{"ok": bool, ...}; klic "_image" (data URL) aplikace prilozi modelu, pokud umi obrazky.
Prikazy maji casovy limit a lze je prerusit (cancel() zabije celou skupinu procesu).
"""
import fnmatch
import json
import os
import re
import shutil
import signal
import subprocess
import tempfile
import threading
import time

from . import feedback
from .api import LuxError
from .i18n import _
from .safety import expand

MAX_RESULT_CHARS = 30000       # nejvetsi vysledek nastroje posilany modelu
MAX_COMMAND_CAPTURE = 2 * 1024 * 1024
MAX_READ_BYTES = 4 * 1024 * 1024
DEFAULT_TIMEOUT = 120
MAX_TIMEOUT = 1800
MAX_LIST = 500


def _fn(name, desc, props=None, required=()):
    return {"type": "function", "function": {
        "name": name, "description": desc,
        "parameters": {"type": "object", "properties": props or {}, "required": list(required)}}}


S = {"type": "string"}
I = {"type": "integer"}
B = {"type": "boolean"}

TOOL_DEFS = [
    _fn("run_command", "Run a bash command on the user's computer and return its output and exit code. "
        "Runs non-interactively (no stdin, no sudo password prompt) in the working folder unless cwd is given. "
        "For administrator rights use pkexec (the user enters the password in the system dialog); never pass "
        "a password with sudo -S, echo/printf pipes or here-strings. "
        "Default timeout 120 s. Prefer the file tools for reading and editing files.",
        {"command": S, "cwd": S, "timeout": dict(I, description="seconds, max 1800")}, ["command"]),
    _fn("read_file", "Read a UTF-8 text file with line numbers. Default 200 lines from start_line (1-based).",
        {"path": S, "start_line": I, "line_count": I}, ["path"]),
    _fn("write_file", "Create or overwrite a UTF-8 text file (parent folders are created).",
        {"path": S, "content": S}, ["path", "content"]),
    _fn("edit_file", "Replace an exact, unique old_text with new_text in a file. Use replace_all only when every "
        "occurrence should change.", {"path": S, "old_text": S, "new_text": S, "replace_all": B},
        ["path", "old_text", "new_text"]),
    _fn("delete_file", "Delete one file or an empty folder (never recursive).", {"path": S}, ["path"]),
    _fn("move_file", "Move or rename a file or folder. Fails if the destination exists.",
        {"path": S, "destination": S}, ["path", "destination"]),
    _fn("make_directory", "Create a folder (with parents).", {"path": S}, ["path"]),
    _fn("list_directory", "List a folder: names, types and sizes.", {"path": S}, ["path"]),
    _fn("find_files", "Find files by glob pattern (e.g. '*.pdf') recursively under path.",
        {"path": S, "pattern": S}, ["pattern"]),
    _fn("search_text", "Search text (or a regex) in files under path; returns matching lines.",
        {"query": S, "path": S, "regex": B, "file_pattern": S}, ["query"]),
    _fn("open_url", "Open a URL (or a local file) with the default application, e.g. the web browser.",
        {"url": S}, ["url"]),
    _fn("list_apps", "List installed desktop applications (desktop id and name), optionally filtered.",
        {"query": S}),
    _fn("open_app", "Launch an installed application by its desktop id (from list_apps) or name.",
        {"app": S}, ["app"]),
    _fn("screenshot", "Take a screenshot of the whole screen. If the model can see images the picture is attached; "
        "otherwise you get the screen size and the list of open windows."),
    _fn("mouse_move", "Move the mouse pointer to screen pixel coordinates.", {"x": I, "y": I}, ["x", "y"]),
    _fn("mouse_click", "Click at screen pixel coordinates. button 1=left 2=middle 3=right; double for double-click.",
        {"x": I, "y": I, "button": I, "double": B}, ["x", "y"]),
    _fn("scroll", "Scroll the mouse wheel; negative amount scrolls up, positive down.", {"amount": I}, ["amount"]),
    _fn("type_text", "Type text into the focused window as keyboard input.", {"text": S}, ["text"]),
    _fn("press_key", "Press keys or chords separated by spaces, e.g. 'ctrl+l', 'Return', 'alt+Tab'.",
        {"keys": S}, ["keys"]),
    _fn("list_windows", "List open windows: id, desktop, position, size, title, and the active window."),
    _fn("focus_window", "Bring a window to front by its id (from list_windows) or by part of its title.",
        {"window": S}, ["window"]),
    _fn("close_window", "Close a window gracefully by its id (from list_windows).", {"window": S}, ["window"]),
    _fn("clipboard_read", "Read the current text in the clipboard."),
    _fn("notify", "Show a desktop notification to the user.", {"title": S, "body": S}, ["title"]),
    _fn("system_info", "Basic information: OS, user, home, working folder, screen session, available tools."),
    _fn("send_feedback", "Send a bug report, an idea or other feedback about LuxOS directly to the author of LuxOS "
        "(the same as the LuxOS Feedback app). Use it only when the user asked to report something about LuxOS, or "
        "explicitly agreed after you suggested it. Write title and description in the user's language. Before "
        "sending, the user sees the complete report and exactly what is attached and must approve it; a denial "
        "means do not send. Never put passwords, tokens or personal data into the text.",
        {"kind": {"type": "string", "enum": list(feedback.KINDS),
                  "description": "bug = something does not work, idea = suggestion, other = question or comment"},
         "title": dict(S, description="short summary of the problem or idea (one line)"),
         "description": dict(S, description="detailed description: what happened, steps to reproduce, expected vs "
                                            "actual behaviour, affected app and when it started; for an idea how it "
                                            "would help"),
         "include_screenshot": dict(B, description="attach a screenshot of the current screen (default false)"),
         "include_system_info": dict(B, description="attach anonymised system information: LuxOS and hardware "
                                                    "versions and recent error messages (default true)"),
         "contact_email": dict(S, description="only if the user explicitly wants a reply and gave this address")},
        ["kind", "title", "description"]),
]
TOOL_NAMES = [t["function"]["name"] for t in TOOL_DEFS]

# Lidske nazvy pro karty v UI
LABELS = {
    "run_command": "Run command", "read_file": "Read file", "write_file": "Write file", "edit_file": "Edit file",
    "delete_file": "Delete", "move_file": "Move", "make_directory": "Create folder",
    "list_directory": "List folder", "find_files": "Find files", "search_text": "Search text",
    "open_url": "Open link", "list_apps": "List apps", "open_app": "Open app", "screenshot": "Screenshot",
    "mouse_move": "Move mouse", "mouse_click": "Click", "scroll": "Scroll", "type_text": "Type text",
    "press_key": "Press keys", "list_windows": "List windows", "focus_window": "Focus window",
    "close_window": "Close window", "clipboard_read": "Read clipboard", "notify": "Notification",
    "system_info": "System info", "send_feedback": "Report to LuxOS",
}


def subject(name, args):
    """Hlavni argument nastroje pro kratky popis v karte."""
    args = args if isinstance(args, dict) else {}
    for key in ("command", "path", "url", "app", "pattern", "query", "keys", "text", "window", "title"):
        if name == "send_feedback" and key != "title":
            continue
        if args.get(key):
            v = str(args[key]).strip().replace("\n", " ⏎ ")
            if name == "move_file" and args.get("destination"):
                v += " → " + str(args["destination"])
            return v if len(v) <= 140 else v[:137] + "…"
    if "x" in args and "y" in args:
        return f"{args.get('x')}, {args.get('y')}"
    if "amount" in args:
        return str(args["amount"])
    return ""


def clip_text(text, limit):
    """Zkrati text: zachova zacatek a konec, uprostred poznamka o vynechani."""
    if len(text) <= limit:
        return text
    head = limit * 2 // 3
    tail = limit - head - 80
    return text[:head] + f"\n… [{len(text) - head - tail} characters omitted] …\n" + text[-tail:]


def encode_result(result, limit=MAX_RESULT_CHARS):
    """Vysledek nastroje -> JSON text pro model (bez interniho klice _image), s limitem velikosti."""
    clean = {k: v for k, v in result.items() if not k.startswith("_")}
    raw = json.dumps(clean, ensure_ascii=False)
    if len(raw) <= limit:
        return raw
    for key in ("output", "content", "matches", "entries", "files", "windows", "apps"):
        if key in clean and isinstance(clean[key], str):
            over = len(raw) - limit + 200
            clean[key] = clip_text(clean[key], max(1000, len(clean[key]) - over))
            clean["truncated"] = True
        elif key in clean and isinstance(clean[key], list):
            while len(json.dumps(clean, ensure_ascii=False)) > limit and len(clean[key]) > 10:
                clean[key] = clean[key][: len(clean[key]) * 2 // 3]
                clean["truncated"] = True
    raw = json.dumps(clean, ensure_ascii=False)
    return raw if len(raw) <= limit else clip_text(raw, limit)


class ToolError(Exception):
    pass


class Tools:
    def __init__(self, workdir=None, gui=None, timeout=DEFAULT_TIMEOUT, vision=False, env=None, blocked=(),
                 client=None):
        self.home = os.path.expanduser("~")
        # zakazane slozky z nastaveni: find_files/search_text do nich pri prochazeni nevstupuji
        self.blocked = [os.path.realpath(expand(b, self.home, self.home)) for b in blocked or ()]
        self.workdir = workdir or self.home
        self.gui = gui
        self.timeout = timeout
        self.vision = vision
        self.env = env if env is not None else os.environ
        self._proc = None
        self._lock = threading.Lock()
        self.cancelled = threading.Event()
        self.client = client      # LuxClient aplikace (ucet pro send_feedback); None = ucet LuxOS / anonymne

    # ---- obecne --------------------------------------------------------------------
    def definitions(self):
        return TOOL_DEFS

    def path(self, p):
        return expand(p or ".", self.workdir, self.home)

    def cancel(self):
        """Prerusi bezici prikaz (SIGTERM skupine procesu, po 2 s SIGKILL)."""
        self.cancelled.set()
        with self._lock:
            proc = self._proc
        if proc is not None and proc.poll() is None:
            _kill_group(proc)

    def prepare(self, name, args, allow_screenshot=True):
        """Priprava pred potvrzenim: u send_feedback sestavi presne hlaseni (text, systemove udaje,
        snimek), ktere uzivatel uvidi v karte a ktere se po schvaleni odesle beze zmeny.
        Vraci None (nastroj nic nepripravuje), {"ok": True, "payload", "preview"} nebo {"ok": False, "error"}."""
        if name != "send_feedback" or not isinstance(args, dict):
            return None
        try:
            args = {k: v for k, v in args.items() if k != "allow_screenshot"}
            return self._prepare_feedback(allow_screenshot=allow_screenshot, **args)
        except TypeError as e:
            return {"ok": False, "error": f"Invalid arguments: {e}"}
        except feedback.FeedbackError as e:
            return {"ok": False, "error": str(e)}

    def execute(self, name, args, prepared=None):
        if name not in TOOL_NAMES:
            return {"ok": False, "error": f"Unknown tool: {name}"}
        if not isinstance(args, dict):
            return {"ok": False, "error": "Tool arguments must be a JSON object"}
        if name == "send_feedback":
            return self.t_send_feedback(prepared)
        try:
            return getattr(self, "t_" + name)(**args)
        except TypeError as e:
            return {"ok": False, "error": f"Invalid arguments: {e}"}
        except ToolError as e:
            return {"ok": False, "error": str(e)}
        except OSError as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    def _run(self, argv, timeout=20, input_text=None, check=True):
        """Kratky pomocny prikaz (xdotool, wmctrl ...) bez shellu."""
        if not shutil.which(argv[0]):
            raise ToolError(f"{argv[0]} is not installed")
        try:
            r = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, input=input_text,
                               env=self._child_env())
        except subprocess.TimeoutExpired:
            raise ToolError(f"{argv[0]} timed out") from None
        if check and r.returncode != 0:
            raise ToolError((r.stderr or r.stdout or f"{argv[0]} failed ({r.returncode})").strip()[:2000])
        return r

    def _child_env(self):
        env = dict(self.env)
        env.update({"LUXAI_AGENT": "1", "PAGER": "cat", "GIT_PAGER": "cat", "TERM": "dumb",
                    "SYSTEMD_PAGER": "", "DEBIAN_FRONTEND": "noninteractive"})
        env.pop("LUXAI_ORIGIN", None)
        return env

    # ---- shell ---------------------------------------------------------------------------
    def t_run_command(self, command, cwd=None, timeout=None):
        if not str(command).strip():
            raise ToolError("Empty command")
        cwd = self.path(cwd) if cwd else self.workdir
        if not os.path.isdir(cwd):
            raise ToolError(f"Working folder does not exist: {cwd}")
        try:
            limit = int(timeout) if timeout else self.timeout
        except (TypeError, ValueError):
            limit = self.timeout
        limit = max(1, min(limit, MAX_TIMEOUT))
        self.cancelled.clear()
        shell = shutil.which("bash") or "/bin/sh"
        out = tempfile.TemporaryFile()
        try:
            proc = subprocess.Popen([shell, "-c", command], cwd=cwd, stdin=subprocess.DEVNULL, stdout=out,
                                    stderr=subprocess.STDOUT, start_new_session=True, env=self._child_env())
        except OSError as e:
            out.close()
            raise ToolError(f"Cannot start command: {e}") from None
        with self._lock:
            self._proc = proc
        start = time.monotonic()
        timed_out = cancelled = False
        try:
            while proc.poll() is None:
                if self.cancelled.is_set():
                    cancelled = True
                    _kill_group(proc)
                    break
                if time.monotonic() - start > limit:
                    timed_out = True
                    _kill_group(proc)
                    break
                time.sleep(0.05)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                pass
            cancelled = cancelled or (self.cancelled.is_set() and not timed_out)
            out.seek(0)
            data = out.read(MAX_COMMAND_CAPTURE + 1)
        finally:
            with self._lock:
                self._proc = None
            out.close()
        text = data[:MAX_COMMAND_CAPTURE].decode("utf-8", "replace")
        if len(data) > MAX_COMMAND_CAPTURE:
            text += "\n… [output larger than 2 MB was cut]"
        result = {"ok": proc.returncode == 0 and not timed_out and not cancelled,
                  "exit_code": proc.returncode, "output": clip_text(text, 24000),
                  "duration_s": round(time.monotonic() - start, 2)}
        if timed_out:
            result["error"] = f"Command timed out after {limit} s and was stopped"
        if cancelled:
            result["error"] = "Command was stopped by the user"
            result["cancelled"] = True
        return result

    # ---- soubory --------------------------------------------------------------------
    def t_read_file(self, path, start_line=1, line_count=200):
        p = self.path(path)
        if os.path.isdir(p):
            raise ToolError(f"{p} is a folder; use list_directory")
        size = os.path.getsize(p)
        if size > MAX_READ_BYTES:
            raise ToolError(f"File is too large to read ({size} bytes)")
        with open(p, "rb") as f:
            raw = f.read()
        if b"\0" in raw[:8192]:
            raise ToolError("File looks binary; not reading it")
        lines = raw.decode("utf-8", "replace").splitlines()
        try:
            start = max(1, int(start_line or 1))
            count = max(1, min(int(line_count or 200), 2000))
        except (TypeError, ValueError):
            start, count = 1, 200
        sel = lines[start - 1:start - 1 + count]
        body = "\n".join(f"{start + i:>5}  {line}" for i, line in enumerate(sel))
        return {"ok": True, "path": p, "total_lines": len(lines), "start_line": start,
                "end_line": start + len(sel) - 1, "content": body}

    def t_write_file(self, path, content):
        p = self.path(path)
        if os.path.isdir(p):
            raise ToolError(f"{p} is a folder")
        existed = os.path.exists(p)
        os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
        mode = os.stat(p).st_mode & 0o7777 if existed else None
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(p), prefix=".luxai-")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(str(content))
            if mode is not None:
                os.chmod(tmp, mode)
            else:
                os.chmod(tmp, 0o644 & ~_umask())
            os.replace(tmp, p)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
        return {"ok": True, "path": p, "created": not existed, "bytes": len(str(content).encode("utf-8"))}

    def t_edit_file(self, path, old_text, new_text, replace_all=False):
        p = self.path(path)
        with open(p, encoding="utf-8") as f:
            text = f.read()
        if not old_text:
            raise ToolError("old_text must not be empty")
        n = text.count(old_text)
        if n == 0:
            raise ToolError("old_text was not found in the file")
        if n > 1 and not replace_all:
            raise ToolError(f"old_text occurs {n} times; make it unique or set replace_all")
        new = text.replace(old_text, new_text) if replace_all else text.replace(old_text, new_text, 1)
        self.t_write_file(p, new)
        line = text[:text.index(old_text)].count("\n") + 1
        return {"ok": True, "path": p, "replacements": n if replace_all else 1, "line": line}

    def t_delete_file(self, path):
        p = self.path(path)
        if os.path.islink(p) or os.path.isfile(p):
            os.unlink(p)
        elif os.path.isdir(p):
            if os.listdir(p):
                raise ToolError("Folder is not empty; delete_file never deletes recursively")
            os.rmdir(p)
        else:
            raise ToolError(f"No such file: {p}")
        return {"ok": True, "path": p, "deleted": True}

    def t_move_file(self, path, destination):
        src, dst = self.path(path), self.path(destination)
        if not os.path.lexists(src):
            raise ToolError(f"No such file: {src}")
        if os.path.isdir(dst):
            dst = os.path.join(dst, os.path.basename(src))
        if os.path.lexists(dst):
            raise ToolError(f"Destination already exists: {dst}")
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.move(src, dst)
        return {"ok": True, "from": src, "to": dst}

    def t_make_directory(self, path):
        p = self.path(path)
        os.makedirs(p, exist_ok=True)
        return {"ok": True, "path": p}

    def t_list_directory(self, path="."):
        p = self.path(path)
        entries = []
        with os.scandir(p) as it:
            items = sorted(it, key=lambda e: (not e.is_dir(follow_symlinks=False), e.name.lower()))
        for e in items[:MAX_LIST]:
            try:
                st = e.stat(follow_symlinks=False)
                kind = "link" if e.is_symlink() else "dir" if e.is_dir() else "file"
                entries.append({"name": e.name, "type": kind, "size": st.st_size if kind == "file" else None,
                                "modified": time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime))})
            except OSError:
                entries.append({"name": e.name, "type": "unknown"})
        return {"ok": True, "path": p, "count": len(items), "entries": entries,
                "truncated": len(items) > MAX_LIST}

    def _is_blocked(self, path):
        if not self.blocked:
            return False
        p = os.path.realpath(path)
        return any(p == b or p.startswith(b.rstrip("/") + "/") for b in self.blocked)

    def _walk(self, root, limit_files=50000):
        n = 0
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in (".git", "node_modules", "__pycache__", ".cache")
                           and not os.path.islink(os.path.join(dirpath, d))
                           and not self._is_blocked(os.path.join(dirpath, d))]
            dirnames.sort()
            for fname in sorted(filenames):
                n += 1
                if n > limit_files or self.cancelled.is_set():
                    return
                yield os.path.join(dirpath, fname)

    def t_find_files(self, pattern, path="."):
        root = self.path(path)
        if not os.path.isdir(root):
            raise ToolError(f"Not a folder: {root}")
        self.cancelled.clear()
        found = []
        pat = pattern if any(c in pattern for c in "*?[") else f"*{pattern}*"
        for f in self._walk(root):
            if fnmatch.fnmatch(os.path.basename(f).lower(), pat.lower()) or \
                    ("/" in pat and fnmatch.fnmatch(os.path.relpath(f, root), pat)):
                found.append(f)
                if len(found) >= MAX_LIST:
                    break
        return {"ok": True, "root": root, "pattern": pattern, "files": found, "truncated": len(found) >= MAX_LIST}

    def t_search_text(self, query, path=".", regex=False, file_pattern="*"):
        root = self.path(path)
        self.cancelled.clear()
        try:
            rx = re.compile(query if regex else re.escape(query), re.I)
        except re.error as e:
            raise ToolError(f"Invalid regex: {e}") from None
        matches = []
        files = [root] if os.path.isfile(root) else self._walk(root, 20000)
        for f in files:
            if not fnmatch.fnmatch(os.path.basename(f), file_pattern or "*"):
                continue
            try:
                if os.path.getsize(f) > 2 * 1024 * 1024:
                    continue
                with open(f, "rb") as fh:
                    raw = fh.read()
            except OSError:
                continue
            if b"\0" in raw[:4096]:
                continue
            for i, line in enumerate(raw.decode("utf-8", "replace").splitlines(), 1):
                if rx.search(line):
                    matches.append(f"{f}:{i}: {line.strip()[:300]}")
                    if len(matches) >= 300:
                        break
            if len(matches) >= 300:
                break
        return {"ok": True, "query": query, "matches": "\n".join(matches), "count": len(matches),
                "truncated": len(matches) >= 300}

    # ---- aplikace a URL ------------------------------------------------------------------
    def t_open_url(self, url):
        url = str(url).strip()
        if not url:
            raise ToolError("Empty URL")
        if not re.match(r"^(https?|mailto|ftp|file):", url, re.I):
            p = self.path(url)
            if not os.path.exists(p):
                raise ToolError("Only http(s), mailto, ftp, file URLs or existing local paths can be opened")
            url = p
        self._spawn(["xdg-open", url])
        return {"ok": True, "opened": url}

    def _spawn(self, argv):
        if not shutil.which(argv[0]):
            raise ToolError(f"{argv[0]} is not installed")
        subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True, env=self._child_env())

    def _desktop_dirs(self):
        data_home = self.env.get("XDG_DATA_HOME") or os.path.join(self.home, ".local/share")
        dirs = [data_home] + (self.env.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share").split(":")
        return [os.path.join(d, "applications") for d in dirs if d]

    def apps(self):
        """{desktop_id: name} viditelnych aplikaci."""
        res = {}
        for d in self._desktop_dirs():
            try:
                names = sorted(os.listdir(d))
            except OSError:
                continue
            for fname in names:
                if not fname.endswith(".desktop"):
                    continue
                did = fname[:-8]
                if did in res:
                    continue
                info = parse_desktop(os.path.join(d, fname))
                if info.get("Type", "Application") != "Application" or info.get("NoDisplay") == "true" \
                        or info.get("Hidden") == "true":
                    res[did] = None
                    continue
                res[did] = info.get("Name") or did
        return {k: v for k, v in res.items() if v}

    def t_list_apps(self, query=""):
        q = str(query or "").lower()
        apps = [{"id": k, "name": v} for k, v in sorted(self.apps().items(), key=lambda kv: kv[1].lower())
                if not q or q in k.lower() or q in v.lower()]
        return {"ok": True, "count": len(apps), "apps": apps[:MAX_LIST]}

    def t_open_app(self, app):
        app = str(app).strip()
        if app.endswith(".desktop"):
            app = app[:-8]
        apps = self.apps()
        did = app if app in apps else None
        if did is None:
            low = app.lower()
            cands = [k for k, v in apps.items() if v.lower() == low] or \
                    [k for k, v in apps.items() if low in v.lower() or low in k.lower()]
            if not cands:
                raise ToolError(f"No installed application matches '{app}'. Use list_apps.")
            did = sorted(cands, key=len)[0]
        if shutil.which("gtk-launch"):
            self._spawn(["gtk-launch", did])
        else:
            self._spawn(["xdg-open", did])
        return {"ok": True, "launched": did, "name": apps.get(did, did)}

    # ---- obrazovka, mys, klavesnice ------------------------------------------------
    def _need_x11(self):
        if not self.env.get("DISPLAY"):
            raise ToolError("Mouse and keyboard control needs an X11 session (DISPLAY is not set)")
        if self.env.get("WAYLAND_DISPLAY") and self.env.get("XDG_SESSION_TYPE") == "wayland":
            raise ToolError("Mouse and keyboard control works only on X11 (this is a Wayland session)")

    def t_screenshot(self):
        if self.gui is None:
            raise ToolError("Screenshots need the graphical session")
        shot = self.gui.screenshot()  # {"path", "width", "height", "data_url"}
        result = {"ok": True, "path": shot["path"], "width": shot["width"], "height": shot["height"]}
        try:
            result["windows"] = self.t_list_windows().get("windows", [])
        except ToolError:
            result["windows"] = []
        if shot.get("data_url"):
            # snimek zustava v historii i pro model bez obrazku (po prepnuti na model s obrazky ho uvidi)
            result["_image"] = shot["data_url"]
        if self.vision and shot.get("data_url"):
            result["note"] = "The screenshot is attached as an image in the next message."
        else:
            result["note"] = ("The current model cannot see images. Use the window list (titles, positions) "
                              "and other tools to understand the screen.")
        return result

    def t_mouse_move(self, x, y):
        self._need_x11()
        self._run(["xdotool", "mousemove", str(int(x)), str(int(y))])
        return {"ok": True, "x": int(x), "y": int(y)}

    def t_mouse_click(self, x, y, button=1, double=False):
        self._need_x11()
        button = int(button or 1)
        if button not in (1, 2, 3):
            raise ToolError("button must be 1, 2 or 3")
        argv = ["xdotool", "mousemove", str(int(x)), str(int(y)), "click"]
        if double:
            argv += ["--repeat", "2", "--delay", "80"]
        self._run(argv + [str(button)])
        return {"ok": True, "x": int(x), "y": int(y), "button": button, "double": bool(double)}

    def t_scroll(self, amount):
        self._need_x11()
        amount = int(amount)
        if amount == 0:
            return {"ok": True, "scrolled": 0}
        steps = min(abs(amount), 50)
        self._run(["xdotool", "click", "--repeat", str(steps), "--delay", "30", "4" if amount < 0 else "5"])
        return {"ok": True, "scrolled": steps if amount > 0 else -steps}

    def t_type_text(self, text):
        self._need_x11()
        text = str(text)
        if len(text) > 5000:
            raise ToolError("Text is too long to type (max 5000 characters)")
        self._run(["xdotool", "type", "--delay", "12", "--", text], timeout=max(20, len(text) // 20))
        return {"ok": True, "typed_chars": len(text)}

    def t_press_key(self, keys):
        self._need_x11()
        parts = str(keys).split()
        if not parts or not all(re.match(r"^[A-Za-z0-9_+\-]+$", k) for k in parts):
            raise ToolError("keys must be X11 key names or chords like ctrl+l, Return, alt+Tab")
        self._run(["xdotool", "key", "--delay", "40", "--"] + parts)
        return {"ok": True, "keys": parts}

    # ---- okna ---------------------------------------------------------------------------
    def t_list_windows(self):
        self._need_x11()
        windows = []
        if shutil.which("wmctrl"):
            out = self._run(["wmctrl", "-lpG"]).stdout
            windows = parse_wmctrl(out)
        elif shutil.which("xdotool"):
            out = self._run(["xdotool", "search", "--onlyvisible", "--name", "."], check=False).stdout
            for wid in out.split()[:100]:
                name = self._run(["xdotool", "getwindowname", wid], check=False).stdout.strip()
                if name:
                    windows.append({"id": hex(int(wid)), "title": name})
        else:
            raise ToolError("wmctrl or xdotool is needed to list windows")
        active = ""
        if shutil.which("xdotool"):
            r = self._run(["xdotool", "getactivewindow"], check=False)
            if r.returncode == 0 and r.stdout.strip().isdigit():
                active = hex(int(r.stdout.strip()))
        for w in windows:
            w["active"] = bool(active) and int(w["id"], 16) == int(active, 16)
        return {"ok": True, "count": len(windows), "windows": windows, "active": active}

    @staticmethod
    def _window_id(window):
        w = str(window).strip()
        if re.match(r"^0x[0-9a-fA-F]+$", w):
            return w
        if w.isdigit():
            return hex(int(w))
        return None

    def t_focus_window(self, window):
        self._need_x11()
        wid = self._window_id(window)
        if shutil.which("wmctrl"):
            self._run(["wmctrl", "-ia", wid] if wid else ["wmctrl", "-a", str(window)])
        elif wid:
            self._run(["xdotool", "windowactivate", str(int(wid, 16))])
        else:
            r = self._run(["xdotool", "search", "--onlyvisible", "--name", re.escape(str(window))], check=False)
            ids = r.stdout.split()
            if not ids:
                raise ToolError(f"No window matches '{window}'")
            self._run(["xdotool", "windowactivate", ids[0]])
        return {"ok": True, "focused": wid or str(window)}

    def t_close_window(self, window):
        self._need_x11()
        wid = self._window_id(window)
        if not wid:
            raise ToolError("close_window needs a window id from list_windows")
        if shutil.which("wmctrl"):
            self._run(["wmctrl", "-ic", wid])
        else:
            self._run(["xdotool", "windowclose", str(int(wid, 16))])
        return {"ok": True, "closed": wid}

    # ---- schranka, oznameni, system ------------------------------------------------
    def t_clipboard_read(self):
        text = None
        if self.gui is not None:
            text = self.gui.clipboard_text()
        if text is None:
            for argv in (["xclip", "-selection", "clipboard", "-o"], ["xsel", "-ob"], ["wl-paste", "-n"]):
                if shutil.which(argv[0]):
                    r = self._run(argv, timeout=5, check=False)
                    if r.returncode == 0:
                        text = r.stdout
                        break
        if text is None:
            return {"ok": True, "text": "", "empty": True}
        return {"ok": True, "text": clip_text(text, 20000), "length": len(text)}

    def t_notify(self, title, body=""):
        if shutil.which("notify-send"):
            self._run(["notify-send", "-a", "LuxAI", "-i", "luxai", "--", str(title)[:200], str(body)[:1000]],
                      check=False)
        elif self.gui is not None:
            self.gui.notify(str(title), str(body))
        else:
            raise ToolError("notify-send is not installed")
        return {"ok": True}

    def t_system_info(self):
        info = {"ok": True, "user": self.env.get("USER", ""), "home": self.home, "working_folder": self.workdir,
                "session": self.env.get("XDG_SESSION_TYPE", "x11" if self.env.get("DISPLAY") else "unknown"),
                "desktop": self.env.get("XDG_CURRENT_DESKTOP", ""), "display": self.env.get("DISPLAY", "")}
        try:
            with open("/etc/os-release") as f:
                for line in f:
                    if line.startswith("PRETTY_NAME="):
                        info["os"] = line.split("=", 1)[1].strip().strip('"')
        except OSError:
            pass
        info["available"] = {x: bool(shutil.which(x)) for x in
                             ("xdotool", "wmctrl", "xdg-open", "gtk-launch", "notify-send", "git", "python3",
                              "pacman", "flatpak")}
        return info

    # ---- hlaseni autorovi LuxOS ------------------------------------------------------------
    def _prepare_feedback(self, kind, title, description, include_screenshot=False, include_system_info=True,
                          contact_email=None, allow_screenshot=True):
        include_screenshot, include_system_info = _flag(include_screenshot, False), _flag(include_system_info, True)
        # Nejdriv overit text (bez sberu udaju a snimku, pokud je hlaseni stejne neplatne)
        feedback.build_payload(kind, title, description, contact_email)
        notes = []
        system = feedback.collect_system() if include_system_info else None
        shot = None
        if include_screenshot:
            if not allow_screenshot:
                notes.append(_("Screenshots are turned off in LuxAI settings; the report is sent without one."))
            elif self.gui is None:
                notes.append(_("No graphical session; the report is sent without a screenshot."))
            else:
                try:
                    grab = getattr(self.gui, "report_screenshot", None)
                    s = grab() if grab else self.gui.screenshot()
                    shot = s.get("data_url") or None
                except (ToolError, OSError, TimeoutError) as e:
                    notes.append(_("The screenshot could not be taken ({0}); the report is sent without one.")
                                 .format(e))
                if shot and len(shot) > feedback.SHOT_MAX:
                    shot = None
                    notes.append(_("The screenshot is too large; the report is sent without one."))
        payload = feedback.build_payload(kind, title, description, contact_email, system, shot)
        token, _origin = feedback.account_for(self.client)
        # nahled jen pro kartu v UI (modelu se neposila)
        preview = dict(feedback.describe(payload), screenshot=payload.get("screenshot"), notes=notes,
                       signed_in=bool(token))
        return {"ok": True, "payload": payload, "preview": preview}

    def t_send_feedback(self, prepared=None):
        """Odesle jen hlaseni pripravene pres prepare() a schvalene uzivatelem."""
        if not isinstance(prepared, dict) or not prepared.get("ok") or "payload" not in prepared:
            return {"ok": False, "error": "The report was not prepared and approved; nothing was sent."}
        payload = prepared["payload"]
        token, origin = feedback.account_for(self.client)
        self.cancelled.clear()
        try:
            rid = feedback.send(payload, token, origin, should_stop=self.cancelled.is_set)
        except LuxError as e:
            res = {"ok": False, "error": feedback.human_error(e), "code": e.code}
            if feedback.can_save(e):
                res["offline"] = True
                res["_payload"] = payload   # tlacitko v karte ulozi presne toto hlaseni do fronty
                res["note"] = ("The report was not sent. The user can save it in the tool card; the Feedback app "
                               "then sends it automatically later. Tell the user.")
            elif e.code == "rate":
                res["note"] = "At most 5 reports per 10 minutes are accepted. Do not retry now; tell the user."
            return res
        return {"ok": True, "id": rid, "kind": payload["kind"], "sent_with_account": bool(token),
                "system_info_attached": "system" in payload, "screenshot_attached": "screenshot" in payload,
                "note": "The report was delivered to the author of LuxOS. Tell the user the report ID."}


def _flag(value, default):
    """Pravdivostni argument modelu (true/false, "true"/"false", 1/0, chybejici -> default)."""
    if value is None:
        return default
    if isinstance(value, str):
        v = value.strip().lower()
        if v in ("true", "yes", "1", "on"):
            return True
        if v in ("false", "no", "0", "off", ""):
            return False
        return default
    return bool(value)


def _umask():
    m = os.umask(0)
    os.umask(m)
    return m


def _kill_group(proc):
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        return
    for _ in range(40):
        if proc.poll() is not None:
            break
        time.sleep(0.05)
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass


def parse_desktop(path):
    """Klice sekce [Desktop Entry] (Name v lokalizaci uzivatele, je-li)."""
    lang = (os.environ.get("LC_ALL") or os.environ.get("LC_MESSAGES") or os.environ.get("LANG") or "")
    lang = lang.split(".")[0]
    short = lang.split("_")[0]
    out, local = {}, {}
    sect = None
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if line.startswith("["):
                    sect = line
                    continue
                if sect != "[Desktop Entry]" or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip()
                m = re.match(r"^(\w+)\[([^\]]+)\]$", k)
                if m:
                    if m.group(2) in (lang, short):
                        local[m.group(1)] = v.strip()
                    continue
                out[k] = v.strip()
    except OSError:
        pass
    out.update(local)
    return out


def parse_wmctrl(out):
    """Vystup `wmctrl -lpG` -> seznam oken."""
    res = []
    for line in out.splitlines():
        parts = line.split(None, 8)
        if len(parts) < 8:
            continue
        wid, desk, pid, x, y, w, h, host = parts[:8]
        title = parts[8] if len(parts) > 8 else ""
        try:
            res.append({"id": wid, "desktop": int(desk), "pid": int(pid), "x": int(x), "y": int(y),
                        "width": int(w), "height": int(h), "title": title})
        except ValueError:
            continue
    return res
