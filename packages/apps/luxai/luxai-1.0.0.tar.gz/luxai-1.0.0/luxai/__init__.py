"""LuxAI - AI asistent pro LuxOS (chat a agent, ktery umi pracovat s pocitacem)."""
__version__ = "1.0.0"
APP_ID = "cz.luxai.LuxAI"
