"""Spusteni: python3 -m luxai  nebo  python3 /usr/lib/luxai/luxai/__main__.py"""
import os
import sys

if __package__ in (None, ""):
    # Spusteno jako skript: misto adresare balicku pridat jeho rodice (nestinit jmena modulu)
    here = os.path.dirname(os.path.abspath(__file__))
    sys.path[:] = [p for p in sys.path if os.path.abspath(p or ".") != here]
    sys.path.insert(0, os.path.dirname(here))

from luxai.app import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
