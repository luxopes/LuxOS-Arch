"""LuxAI - okno aplikace (GTK 3): postranni panel s historii, vyber modelu, prepinac
Chat/Agent, bubliny zprav s Markdownem, karty nastroju s potvrzovanim, tlacitko Stop.
"""
import json
import os
import shutil
import subprocess
import threading
import time

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
gi.require_version("Pango", "1.0")
from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk, Pango  # noqa: E402

from . import APP_ID, __version__  # noqa: E402
from . import markdown as md  # noqa: E402
from . import feedback  # noqa: E402
from .agent import Run  # noqa: E402
from .api import LuxClient, LuxError, load_account, usage_for  # noqa: E402
from .i18n import APP_ROOT, _  # noqa: E402
from . import titles  # noqa: E402
from .safety import Permissions  # noqa: E402
from .settings_window import SETTINGS_CSS, SettingsWindow  # noqa: E402
from .store import Conversation, Settings, Store  # noqa: E402
from .tools import LABELS, Tools, subject  # noqa: E402

REGISTER_URL = "https://lux-ai.cz/register"
ICON_FILE = os.path.join(APP_ROOT, "data", "luxai.png")
SHOT_DIR = os.path.join(os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"), "luxai", "screenshots")

CSS = """
window.luxai, .luxai-main { background-color: @lx_bg; color: @lx_fg; }
.sidebar { background-color: @lx_side; border-right: 1px solid @lx_border; }
.sidebar list { background: transparent; }
.sidebar list row { border-radius: 9px; margin: 1px 8px; padding: 7px 10px; }
.sidebar list row:selected { background-color: alpha(@lx_accent, 0.85); color: white; }
.sidebar list row:selected .dim { color: rgba(255,255,255,0.75); }
.side-title { font-size: 11px; font-weight: 700; color: @lx_dim; margin: 10px 18px 4px; }
.conv-title { font-weight: 600; }
.dim { color: @lx_dim; }
.small { font-size: 11px; }
.row-delete { padding: 0 4px; min-height: 20px; min-width: 20px; border: none; background: none; box-shadow: none; }
.search { border-radius: 9px; margin: 8px 10px 2px; }
.account { padding: 10px 12px; border-top: 1px solid @lx_border; }
.avatar { border-radius: 999px; min-width: 30px; min-height: 30px; color: white; font-weight: 800;
          background-image: linear-gradient(135deg, #3d6bff, #8a4dff); }
levelbar trough { min-height: 5px; border-radius: 3px; background-color: alpha(@lx_fg, 0.10); border: none; }
levelbar block.filled { border-radius: 3px; background-color: @lx_accent; border: none; }
levelbar block.empty { background: none; border: none; }
.segmented button { padding: 3px 16px; font-weight: 600; }
.segmented button:checked { background-image: none; background-color: @lx_accent; color: white; }
.bubble-user { background-image: linear-gradient(135deg, #3d7bff, #6a5cff); color: white;
               border-radius: 18px 18px 4px 18px; padding: 9px 14px; }
.bubble-user label { color: white; }
.bubble-ai { background-color: @lx_card; border: 1px solid @lx_border; border-radius: 18px 18px 18px 4px;
             padding: 10px 15px; }
.role { font-size: 11px; font-weight: 700; color: @lx_dim; margin: 0 6px; }
.md-code { background-color: @lx_code; border-radius: 10px; border: 1px solid @lx_border; }
.md-code-head { padding: 3px 6px 0 12px; }
.md-code-text { padding: 6px 12px 10px 12px; font-family: monospace; }
.md-quote { border-left: 3px solid alpha(@lx_accent, 0.7); padding-left: 10px; }
.md-table { border: 1px solid @lx_border; border-radius: 8px; }
.md-cell { padding: 4px 10px; border-bottom: 1px solid @lx_border; }
.md-head { font-weight: 700; background-color: alpha(@lx_fg, 0.05); }
button.flat-small { padding: 1px 8px; min-height: 22px; font-size: 11px; }
.tool-card { background-color: @lx_card; border: 1px solid @lx_border; border-radius: 12px; padding: 8px 12px; }
.tool-card.waiting { border-color: alpha(@lx_accent, 0.8); }
.tool-card.danger { border-color: @lx_danger; background-color: alpha(@lx_danger, 0.08); }
.tool-name { font-weight: 700; }
.tool-subject { font-family: monospace; font-size: 12px; color: @lx_dim; }
.tool-pre { font-family: monospace; font-size: 11px; background-color: @lx_code; border-radius: 8px; padding: 8px; }
.dot { border-radius: 999px; min-width: 9px; min-height: 9px; margin-top: 4px; }
.dot.running, .dot.waiting { background-color: @lx_warn; }
.dot.ok { background-color: @lx_ok; }
.dot.error, .dot.blocked { background-color: @lx_danger; }
.dot.denied, .dot.cancelled { background-color: @lx_dim; }
.confirm-text { font-weight: 600; }
.warn-text { color: @lx_danger; font-weight: 600; }
button.allow { background-image: none; background-color: @lx_accent; color: white; border: none; }
button.danger-btn { background-image: none; background-color: @lx_danger; color: white; border: none; }
.error-row { background-color: alpha(@lx_danger, 0.10); border: 1px solid alpha(@lx_danger, 0.5);
             border-radius: 12px; padding: 10px 14px; }
.composer { background-color: @lx_input; border: 1px solid @lx_border; border-radius: 16px; padding: 6px 8px 6px 12px; }
.composer textview, .composer textview text { background-color: transparent; color: @lx_fg; }
button.send { border-radius: 999px; min-width: 32px; min-height: 32px; padding: 0; background-image: none;
              background-color: @lx_accent; color: white; border: none; }
button.send:disabled { background-color: alpha(@lx_fg, 0.15); }
button.stop { border-radius: 999px; padding: 4px 14px; background-image: none; background-color: @lx_danger;
              color: white; border: none; font-weight: 700; }
.agent-banner { background-color: alpha(@lx_accent, 0.10); border-bottom: 1px solid @lx_border; padding: 6px 14px; }
.agent-banner.auto { background-color: alpha(@lx_warn, 0.18); }
.empty-title { font-size: 26px; font-weight: 800; }
.empty-text { color: @lx_dim; }
button.pill { border-radius: 999px; padding: 6px 14px; }
button.primary { background-image: none; background-color: @lx_accent; color: white; border: none; font-weight: 700; }
button.chip { border-radius: 12px; padding: 8px 12px; background-image: none; background-color: @lx_card;
              border: 1px solid @lx_border; box-shadow: none; }
button.chip:hover { border-color: alpha(@lx_accent, 0.7); }
button.chip label, button.pill label, button.primary label, button.send, button.stop label { text-shadow: none; }
.status-line { font-size: 11px; color: @lx_dim; margin: 2px 16px 8px 16px; }
""" + SETTINGS_CSS

DARK = """
@define-color lx_bg #1c1d29; @define-color lx_side #222330; @define-color lx_fg #eceef7;
@define-color lx_dim rgba(236, 238, 247, 0.58); @define-color lx_border rgba(255, 255, 255, 0.09);
@define-color lx_card #262838; @define-color lx_code #15161f; @define-color lx_input #262838;
@define-color lx_accent #4a7dff; @define-color lx_danger #ff5f62; @define-color lx_warn #f2b13a; @define-color lx_ok #35c47a;
"""
LIGHT = """
@define-color lx_bg #fbfbfd; @define-color lx_side #f1f2f7; @define-color lx_fg #1d1d2b;
@define-color lx_dim rgba(29, 29, 43, 0.56); @define-color lx_border rgba(0, 0, 0, 0.09);
@define-color lx_card #ffffff; @define-color lx_code #f3f4f8; @define-color lx_input #ffffff;
@define-color lx_accent #3d7bff; @define-color lx_danger #e5484d; @define-color lx_warn #d48a00; @define-color lx_ok #1f9d55;
"""

SUGGESTIONS = {
    "chat": [("Explain something", "Explain how HTTPS keeps my connection private, in simple terms."),
             ("Write a text", "Write a short, friendly email inviting my team to a Friday lunch."),
             ("Brainstorm", "Give me 5 ideas for a weekend trip in the Czech Republic."),
             ("Help with code", "How do I read a JSON file in Python? Show a short example.")],
    "agent": [("Free disk space", "What is using the most disk space in my home folder?"),
              ("Tidy up Downloads", "List the files in my Downloads folder grouped by type and suggest what to clean up."),
              ("Look at my screen", "Take a screenshot and tell me which windows are open."),
              ("Open a website", "Open lux-ai.cz in the web browser.")],
}


THEME = {"pref": "system", "system_prefer_dark": None}


def system_is_dark():
    s = Gtk.Settings.get_default()
    name = os.environ.get("GTK_THEME") or s.props.gtk_theme_name or ""
    prefer = THEME["system_prefer_dark"]
    if prefer is None:
        prefer = s.props.gtk_application_prefer_dark_theme
    return "dark" in name.lower() or bool(prefer)


def is_dark():
    """Tmavy vzhled podle Nastaveni > Obecne > Motiv (Stejny jako system / Svetly / Tmavy)."""
    if THEME["pref"] == "dark":
        return True
    if THEME["pref"] == "light":
        return False
    return system_is_dark()


def apply_theme_preference(pref):
    """Nastavi preferenci motivu i pro GTK widgety (varianta motivu prefer-dark)."""
    s = Gtk.Settings.get_default()
    if THEME["system_prefer_dark"] is None:
        THEME["system_prefer_dark"] = bool(s.props.gtk_application_prefer_dark_theme)
    THEME["pref"] = pref if pref in ("system", "light", "dark") else "system"
    want = {"dark": True, "light": False}.get(THEME["pref"], THEME["system_prefer_dark"])
    if bool(s.props.gtk_application_prefer_dark_theme) != want:
        s.props.gtk_application_prefer_dark_theme = want


def fmt_int(n):
    return f"{int(n):,}".replace(",", " ")


def label(text="", markup=None, classes=(), xalign=0.0, wrap=False, selectable=False, ellipsize=False):
    lb = Gtk.Label()
    if markup is not None:
        lb.set_markup(markup)
    else:
        lb.set_text(text)
    lb.set_xalign(xalign)
    if wrap:
        lb.set_line_wrap(True)
        lb.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
    if selectable:
        lb.set_selectable(True)
        lb.set_can_focus(False)
    if ellipsize:
        lb.set_ellipsize(Pango.EllipsizeMode.END)
    for c in classes:
        lb.get_style_context().add_class(c)
    return lb


def add_class(widget, *classes):
    ctx = widget.get_style_context()
    for c in classes:
        ctx.add_class(c)
    return widget


def icon_button(icon, tooltip, cb=None, classes=()):
    b = Gtk.Button.new_from_icon_name(icon, Gtk.IconSize.BUTTON)
    b.set_tooltip_text(tooltip)
    if cb:
        b.connect("clicked", lambda *_a: cb())
    add_class(b, *classes)
    return b


def app_icon_pixbuf(size):
    theme = Gtk.IconTheme.get_default()
    try:
        if theme.has_icon("luxai"):
            return theme.load_icon("luxai", size, Gtk.IconLookupFlags.FORCE_SIZE)
        return GdkPixbuf.Pixbuf.new_from_file_at_size(ICON_FILE, size, size)
    except GLib.Error:
        return None


def call_main(fn, timeout=15):
    """Spusti fn v hlavnim vlakne GTK a pocka na vysledek (pro vlakno agenta)."""
    if threading.current_thread() is threading.main_thread():
        return fn()
    box = {}
    ev = threading.Event()

    def run():
        try:
            box["v"] = fn()
        except Exception as e:  # noqa: BLE001
            box["e"] = e
        ev.set()
        return False

    GLib.idle_add(run)
    if not ev.wait(timeout):
        raise TimeoutError("GUI call timed out")
    if "e" in box:
        raise box["e"]
    return box.get("v")


# ---- most mezi nastroji a GUI --------------------------------------------------------
class GuiBridge:
    """Snimek obrazovky a schranka pres GDK (bez zavislosti na ImageMagick/xclip)."""

    def __init__(self, window):
        self.window = window

    def screenshot(self):
        def grab():
            root = Gdk.get_default_root_window()
            w, h = root.get_width(), root.get_height()
            pb = Gdk.pixbuf_get_from_window(root, 0, 0, w, h)
            return pb, w, h

        pb, w, h = call_main(grab)
        os.makedirs(SHOT_DIR, mode=0o700, exist_ok=True)
        path = os.path.join(SHOT_DIR, time.strftime("shot-%Y%m%d-%H%M%S.png"))
        if pb is None:
            if shutil.which("grim"):
                subprocess.run(["grim", path], timeout=20, check=False)
            elif shutil.which("import"):
                subprocess.run(["import", "-window", "root", path], timeout=20, check=False)
            if not os.path.exists(path):
                from .tools import ToolError
                raise ToolError("Could not capture the screen")
            pb = GdkPixbuf.Pixbuf.new_from_file(path)
            w, h = pb.get_width(), pb.get_height()
        else:
            pb.savev(path, "png", [], [])
        os.chmod(path, 0o600)
        scale = min(1.0, 1280 / max(1, w))
        small = pb.scale_simple(max(1, int(w * scale)), max(1, int(h * scale)), GdkPixbuf.InterpType.BILINEAR) \
            if scale < 1 else pb
        ok, buf = small.save_to_bufferv("jpeg", ["quality"], ["80"])
        import base64
        data_url = "data:image/jpeg;base64," + base64.b64encode(buf).decode() if ok else ""
        return {"path": path, "width": w, "height": h, "data_url": data_url}

    def report_screenshot(self):
        """Snimek pro hlaseni autorovi LuxOS: JPEG jako data URL do limitu serveru (stejne kroky jako
        luxos-feedback), bez ukladani na disk."""
        def grab():
            root = Gdk.get_default_root_window()
            return Gdk.pixbuf_get_from_window(root, 0, 0, root.get_width(), root.get_height())

        pb = call_main(grab)
        if pb is None:
            from .tools import ToolError
            raise ToolError("Could not capture the screen")
        import base64
        w, h = pb.get_width(), pb.get_height()
        data = b""
        for width, quality in ((feedback.SHOT_WIDTH, "75"), (1024, "60"), (800, "50")):
            scale = min(1.0, width / max(1, w))
            small = pb.scale_simple(max(1, int(w * scale)), max(1, int(h * scale)), GdkPixbuf.InterpType.BILINEAR)
            ok, buf = small.save_to_bufferv("jpeg", ["quality"], [quality])
            data = bytes(buf) if ok else b""
            if data and len(data) * 4 / 3 < feedback.SHOT_MAX:
                break
        if not data:
            from .tools import ToolError
            raise ToolError("Could not capture the screen")
        return {"data_url": "data:image/jpeg;base64," + base64.b64encode(data).decode(), "width": w, "height": h}

    def clipboard_text(self):
        def read():
            cb = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
            return cb.wait_for_text()
        try:
            return call_main(read)
        except TimeoutError:
            return None

    def notify(self, title, body):
        def show():
            app = self.window.get_application()
            n = Gio.Notification.new(title)
            n.set_body(body)
            if app:
                app.send_notification(None, n)
        call_main(show)

    def screen_size(self):
        scr = Gdk.Screen.get_default()
        return f"{scr.get_width()}x{scr.get_height()} px" if scr else ""


class Clamp(Gtk.Bin):
    """Kontejner, ktery omezi sirku obsahu a vystredi ho (jako AdwClamp)."""

    def __init__(self, maximum=860, margin=24):
        super().__init__()
        self.maximum, self.margin = maximum, margin
        self._last_w = None     # skutecna sirka obsahu z posledniho rozmisteni

    def _w(self, width):
        return max(1, min(width - 2 * self.margin, self.maximum))

    def do_get_request_mode(self):
        return Gtk.SizeRequestMode.HEIGHT_FOR_WIDTH

    def do_get_preferred_width(self):
        child = self.get_child()
        if child is None or not child.get_visible():
            return 0, 0
        m, n = child.get_preferred_width()
        return min(m, self.maximum) + 2 * self.margin, min(n, self.maximum) + 2 * self.margin

    def do_get_preferred_height_for_width(self, width):
        child = self.get_child()
        if child is None or not child.get_visible():
            return 0, 0
        return child.get_preferred_height_for_width(self._w(width))

    def do_get_preferred_height(self):
        # Viewport se pta na vysku bez sirky: pouzit skutecnou sirku (jinak se zalomeny text
        # v uzsim okne pocita na sirku 860 px, vyjde o radky mene a spodek bubliny se orizne)
        if self._last_w:
            child = self.get_child()
            if child is None or not child.get_visible():
                return 0, 0
            return child.get_preferred_height_for_width(self._last_w)
        return self.do_get_preferred_height_for_width(self.maximum + 2 * self.margin)

    def do_size_allocate(self, alloc):
        self.set_allocation(alloc)
        child = self.get_child()
        if child is None or not child.get_visible():
            return
        w = self._w(alloc.width)
        if w != self._last_w:
            self._last_w = w
            GLib.idle_add(lambda: self.queue_resize() or False)   # prepocitat vysku pro novou sirku
        rect = Gdk.Rectangle()
        rect.x = alloc.x + (alloc.width - w) // 2
        rect.y = alloc.y
        rect.width = w
        rect.height = alloc.height
        child.size_allocate(rect)


# ---- Markdown -> widgety ---------------------------------------------------------
class MarkdownView(Gtk.Box):
    def __init__(self, window):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.win = window
        self.text = ""

    def colors(self):
        dark = is_dark()
        return {"code_color": "#30324a" if dark else "#e9eaf2", "link_color": "#7aa2ff" if dark else "#2f67e8"}

    def set_text(self, text):
        self.text = text or ""
        for c in self.get_children():
            self.remove(c)
            c.destroy()
        kw = self.colors()
        for b in md.parse_blocks(self.text):
            w = self._block(b, kw)
            if w is not None:
                self.pack_start(w, False, False, 0)
        self.show_all()

    def _text_label(self, markup):
        lb = label(markup=markup, wrap=True, selectable=True)
        lb.set_hexpand(True)
        return lb

    def _block(self, b, kw):
        t = b["type"]
        if t == "para":
            return self._text_label(md.inline(b["text"], **kw))
        if t == "heading":
            return self._text_label(md.heading_markup(b, **kw))
        if t == "hr":
            return Gtk.Separator()
        if t == "quote":
            box = add_class(Gtk.Box(), "md-quote")
            lb = self._text_label("<i>" + md.inline(b["text"], **kw) + "</i>")
            box.pack_start(lb, True, True, 0)
            return box
        if t == "list":
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
            for n, item in enumerate(b["items"]):
                row = Gtk.Box(spacing=6)
                row.set_margin_start(item["level"] * 18)
                pre = label(md.list_item_prefix(item, n), classes=("dim",))
                pre.set_yalign(0)
                pre.set_width_chars(2)
                row.pack_start(pre, False, False, 0)
                row.pack_start(self._text_label(md.inline(item["text"], **kw)), True, True, 0)
                box.pack_start(row, False, False, 0)
            return box
        if t == "code":
            return self._code(b)
        if t == "table":
            return self._table(b, kw)
        return None

    def _code(self, b):
        box = add_class(Gtk.Box(orientation=Gtk.Orientation.VERTICAL), "md-code")
        head = add_class(Gtk.Box(spacing=6), "md-code-head")
        head.pack_start(label(b["lang"] or _("code"), classes=("dim", "small")), False, False, 0)
        copy = Gtk.Button(label=_("Copy"))
        add_class(copy, "flat-small", "flat")
        copy.set_relief(Gtk.ReliefStyle.NONE)

        def do_copy(_b, text=b["text"]):
            Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).set_text(text, -1)
            copy.set_label(_("Copied"))
            GLib.timeout_add(1200, lambda: (copy.set_label(_("Copy")), False)[1])
        copy.connect("clicked", do_copy)
        head.pack_end(copy, False, False, 0)
        box.pack_start(head, False, False, 0)
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.NEVER)
        sw.set_propagate_natural_height(True)
        lb = label(markup=f'<span font_family="monospace">{md.esc(b["text"])}</span>', selectable=True,
                   classes=("md-code-text",))
        sw.add(lb)
        box.pack_start(sw, False, False, 0)
        return box

    def _table(self, b, kw):
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.NEVER)
        sw.set_propagate_natural_height(True)
        grid = add_class(Gtk.Grid(), "md-table")
        grid.set_halign(Gtk.Align.START)
        rows = [b["header"]] + b["rows"]
        ncol = max(len(r) for r in rows)
        for r, row in enumerate(rows):
            for c in range(ncol):
                cell = row[c] if c < len(row) else ""
                lb = label(markup=md.inline(cell, **kw), selectable=True, classes=("md-cell",))
                if r == 0:
                    add_class(lb, "md-head")
                grid.attach(lb, c, r, 1, 1)
        sw.add(grid)
        return sw


# ---- radky konverzace --------------------------------------------------------------
class UserBubble(Gtk.Box):
    def __init__(self, text):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.set_halign(Gtk.Align.END)
        self.set_margin_start(80)
        bubble = add_class(Gtk.Box(), "bubble-user")
        lb = label(text, wrap=True, selectable=True)
        lb.set_max_width_chars(70)
        bubble.pack_start(lb, True, True, 0)
        self.pack_start(bubble, False, False, 0)
        self.show_all()


class AssistantBubble(Gtk.Box):
    def __init__(self, window, text=""):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        self.win = window
        self.set_margin_end(40)
        self.pack_start(label("LuxAI", classes=("role",)), False, False, 0)
        self.bubble = add_class(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6), "bubble-ai")
        self.bubble.set_halign(Gtk.Align.FILL)
        self.thinking = Gtk.Box(spacing=8)
        self.spinner = Gtk.Spinner()
        self.thinking.pack_start(self.spinner, False, False, 0)
        self.think_label = label(_("Thinking…"), classes=("dim",))
        self.thinking.pack_start(self.think_label, False, False, 0)
        self.view = MarkdownView(window)
        self.bubble.pack_start(self.thinking, False, False, 0)
        self.bubble.pack_start(self.view, False, False, 0)
        self.pack_start(self.bubble, False, False, 0)
        self.text = text
        self._pending = False
        self.show_all()
        if text:
            self.thinking.hide()
            self.view.set_text(text)
        else:
            self.spinner.start()

    def append(self, text, reasoning=""):
        if text:
            self.text += text
            if self.thinking.get_visible():
                self.thinking.hide()
                self.spinner.stop()
            if not self._pending:
                self._pending = True
                GLib.timeout_add(70, self._render)

    def _render(self):
        self._pending = False
        self.view.set_text(self.text)
        self.win.scroll_if_sticky()
        return False

    def finish(self, text=None):
        self.spinner.stop()
        self.thinking.hide()
        if text is not None:
            self.text = text
        self.view.set_text(self.text)


FEEDBACK_KINDS = {"bug": "Bug report", "idea": "Idea", "other": "Something else"}
STATUS_TEXT = {"running": "Running…", "waiting": "Waiting for your approval", "ok": "Done", "error": "Failed",
               "denied": "Denied", "blocked": "Blocked by safety rules", "cancelled": "Stopped"}


def result_summary(name, r):
    """Citelny souhrn vysledku nastroje pro kartu (misto suroveho JSON)."""
    if name == "screenshot":
        return f"{r.get('width')} × {r.get('height')} px · {r.get('path', '')}\n" + \
            _("{0} open windows").format(len(r.get("windows") or []))
    if name == "list_windows":
        return "\n".join(("● " if w.get("active") else "  ") + f"{w.get('id')}  {w.get('title', '')}"
                         for w in r.get("windows") or []) or _("No windows")
    if name == "list_directory":
        return f"{r.get('path')}  ({r.get('count')})\n" + "\n".join(
            e["name"] + ("/" if e.get("type") == "dir" else "") for e in r.get("entries") or [])
    if name == "find_files":
        return "\n".join(r.get("files") or []) or _("Nothing found")
    if name == "search_text":
        return r.get("matches") or _("Nothing found")
    if name == "list_apps":
        return "\n".join(f"{a['name']}  ({a['id']})" for a in r.get("apps") or [])
    if name == "clipboard_read":
        return r.get("text") or _("(empty)")
    if name in ("write_file", "edit_file", "delete_file", "make_directory", "move_file"):
        return " ".join(str(r.get(k)) for k in ("path", "from", "to") if r.get(k))
    if name in ("open_url", "open_app"):
        return str(r.get("opened") or r.get("name") or r.get("launched") or "")
    if name == "send_feedback":
        return _("Report sent. Report ID: {0}").format(r.get("id") or "–")
    return ""


def pixbuf_from_data_url(url, width, height):
    """Nahled obrazku z data URL (snimek v hlaseni) v dane maximalni velikosti, nebo None."""
    import base64
    try:
        raw = base64.b64decode(str(url).split(",", 1)[1])
        loader = GdkPixbuf.PixbufLoader()
        loader.write(raw)
        loader.close()
        pb = loader.get_pixbuf()
    except (IndexError, ValueError, GLib.Error):
        return None
    if pb is None:
        return None
    scale = min(1.0, width / pb.get_width(), height / pb.get_height())
    return pb.scale_simple(max(1, int(pb.get_width() * scale)), max(1, int(pb.get_height() * scale)),
                           GdkPixbuf.InterpType.BILINEAR)


class ToolCard(Gtk.Box):
    def __init__(self, window, call_id, name, args):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.win = window
        self.call_id, self.name, self.args = call_id, name, args
        self.prepared = None    # co presne nastroj odesle (send_feedback), viz set_prepared
        add_class(self, "tool-card")
        self.set_margin_end(40)
        head = Gtk.Box(spacing=8)
        self.dot = add_class(Gtk.Box(), "dot", "running")
        self.dot.set_valign(Gtk.Align.START)
        head.pack_start(self.dot, False, False, 0)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        top = Gtk.Box(spacing=8)
        top.pack_start(label(_(LABELS.get(name, name)), classes=("tool-name",)), False, False, 0)
        self.status = label(_(STATUS_TEXT["running"]), classes=("dim", "small"))
        top.pack_start(self.status, False, False, 0)
        texts.pack_start(top, False, False, 0)
        subj = subject(name, args)
        if subj:
            s = label(subj, classes=("tool-subject",), wrap=True, selectable=True)
            texts.pack_start(s, False, False, 0)
        head.pack_start(texts, True, True, 0)
        self.pack_start(head, False, False, 0)
        self.confirm_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.pack_start(self.confirm_box, False, False, 0)
        self.preview = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.pack_start(self.preview, False, False, 0)
        self.expander = Gtk.Expander(label=_("Details"))
        add_class(self.expander, "small")
        self.details = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.expander.add(self.details)
        self.pack_start(self.expander, False, False, 0)
        self._add_pre(_("Arguments"), self._args_text())
        self.show_all()

    def _args_text(self):
        a = dict(self.args)
        return json.dumps(a, ensure_ascii=False, indent=2)[:6000]

    def _add_pre(self, title, text, into=None):
        into = into or self.details
        into.pack_start(label(title, classes=("dim", "small")), False, False, 0)
        lb = label(text, selectable=True, wrap=True, classes=("tool-pre",))
        into.pack_start(lb, False, False, 0)
        into.show_all()

    def set_status(self, status):
        ctx = self.dot.get_style_context()
        for s in STATUS_TEXT:
            ctx.remove_class(s)
        ctx.add_class(status)
        self.status.set_text(_(STATUS_TEXT.get(status, status)))
        if status != "waiting":
            self.get_style_context().remove_class("waiting")

    def set_prepared(self, preview):
        self.prepared = preview if isinstance(preview, dict) else None

    def set_result(self, result, status):
        self.set_status(status)
        for c in self.confirm_box.get_children():
            c.destroy()
        self.get_style_context().remove_class("danger")
        if not isinstance(result, dict):
            return
        text = ""
        if status == "denied":
            text = _("You denied this action.")
        elif status == "cancelled" and "output" not in result:
            text = _("Stopped before running.")
        elif result.get("error"):
            text = str(result["error"])
        if "output" in result:
            text = (text + "\n" if text else "") + (result.get("output") or _("(no output)"))
            if "exit_code" in result:
                text += f"\n[exit {result['exit_code']}]"
        elif "content" in result and isinstance(result["content"], str):
            text = result["content"]
        elif result.get("ok") and not text and result_summary(self.name, result):
            text = result_summary(self.name, result)
        elif result.get("ok") and not text:
            clean = {k: v for k, v in result.items() if not k.startswith("_") and k != "ok"}
            text = json.dumps(clean, ensure_ascii=False, indent=1)
        lines = text.strip().splitlines()
        short = "\n".join(lines[:4])
        if len(lines) > 4:
            short += "\n…"
        if short:
            pv = label(short[:600], selectable=True, wrap=True, classes=("tool-pre",))
            self.preview.pack_start(pv, False, False, 0)
        if result.get("path") and self.name == "screenshot":
            try:
                pb = GdkPixbuf.Pixbuf.new_from_file_at_size(result["path"], 320, 200)
                img = Gtk.Image.new_from_pixbuf(pb)
                img.set_halign(Gtk.Align.START)
                self.preview.pack_start(img, False, False, 0)
            except GLib.Error:
                pass
        if self.name == "send_feedback" and result.get("offline") and isinstance(result.get("_payload"), dict):
            self._offer_outbox(result["_payload"])
        if text:
            self._add_pre(_("Result"), text[:8000])
        self.preview.show_all()

    def _offer_outbox(self, payload):
        """Bez internetu: ulozit hlaseni do fronty aplikace Zpetna vazba (odesle ho pozdeji)."""
        row = Gtk.Box(spacing=8)
        row.pack_start(label(_("You can save the report; the Feedback app will send it automatically later."),
                             wrap=True, classes=("small",)), True, True, 0)
        b = Gtk.Button(label=_("Save and send later"))
        add_class(b, "allow")
        b.set_valign(Gtk.Align.CENTER)

        def save(*_a):
            for c in row.get_children():
                c.destroy()
            try:
                feedback.save_outbox(payload)
                msg = _("Saved. The Feedback app will send the report when you are online.")
            except OSError as e:
                msg = _("The report could not be saved: {0}").format(e.strerror or e)
            row.pack_start(label(msg, wrap=True, classes=("small",)), True, True, 0)
            row.show_all()

        b.connect("clicked", save)
        row.pack_end(b, False, False, 0)
        self.preview.pack_start(row, False, False, 0)

    def ask(self, kind, reasons, done):
        """Inline potvrzeni. done(answer) s "once" | "always" | "deny"."""
        self.set_status("waiting")
        add_class(self, "waiting")
        box = self.confirm_box
        for c in box.get_children():
            c.destroy()
        self._preview_change(box)
        report = self.name == "send_feedback"
        if kind == "danger":
            add_class(self, "danger")
            box.pack_start(label("⚠ " + _("Potentially dangerous action"), classes=("warn-text",)), False, False, 0)
        elif report:
            box.pack_start(label(_("Send this report to the author of LuxOS?"), classes=("confirm-text",)),
                           False, False, 0)
        elif kind == "confirm":
            box.pack_start(label("⚠ " + _("This may access private data"), classes=("warn-text",)), False, False, 0)
        for r in reasons:
            box.pack_start(label("• " + _(r[:1].upper() + r[1:]), wrap=True, classes=("small",)), False, False, 0)
        if kind == "ask":
            box.pack_start(label(_("Allow LuxAI to do this?"), classes=("confirm-text",)), False, False, 0)
        row = Gtk.Box(spacing=6)
        answered = {"v": False}

        def answer(value):
            if answered["v"]:
                return
            answered["v"] = True
            for c in box.get_children():
                c.destroy()
            done(value)

        def btn(text, value, cls=None):
            b = Gtk.Button(label=text)
            if cls:
                add_class(b, cls)
            b.connect("clicked", lambda *_a: answer(value) if callable(value) is False else value())
            return b

        def second_step():
            for c in box.get_children():
                c.destroy()
            box.pack_start(label(_("Are you sure? This can cause damage that cannot be undone."),
                                 classes=("warn-text",), wrap=True), False, False, 0)
            r2 = Gtk.Box(spacing=6)
            r2.pack_end(btn(_("Yes, run it"), "once", "danger-btn"), False, False, 0)
            r2.pack_end(btn(_("Cancel"), "deny"), False, False, 0)
            box.pack_start(r2, False, False, 0)
            box.show_all()

        if kind == "danger":
            row.pack_end(btn(_("Allow once…"), second_step, "danger-btn"), False, False, 0)
            row.pack_end(btn(_("Deny"), "deny"), False, False, 0)
        elif report:
            row.pack_end(btn(_("Send report"), "once", "allow"), False, False, 0)
            row.pack_end(btn(_("Don't send"), "deny"), False, False, 0)
        elif kind == "confirm":
            row.pack_end(btn(_("Allow once"), "once", "allow"), False, False, 0)
            row.pack_end(btn(_("Deny"), "deny"), False, False, 0)
        else:
            row.pack_end(btn(_("Allow once"), "once", "allow"), False, False, 0)
            row.pack_end(btn(_("Always for this session"), "always"), False, False, 0)
            row.pack_end(btn(_("Deny"), "deny"), False, False, 0)
        box.pack_start(row, False, False, 0)
        self.cancel_ask = lambda: answer("deny")
        box.show_all()

    def _scrolled_pre(self, text, height):
        """Text v ramecku; dlouhy text v posuvne oblasti vysoke `height` px."""
        pre = label(text, selectable=True, wrap=True, classes=("tool-pre",))
        lines = sum(1 + len(x) // 90 for x in text.splitlines())
        if lines * 16 + 20 <= height:
            return pre
        sw = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
        sw.set_min_content_height(height)
        sw.add(pre)
        return sw

    def _preview_report(self, box):
        """Cele hlaseni pro autora LuxOS: druh, text, kontakt, ucet a presne prilohy (rozbalovaci)."""
        p = self.prepared
        if not p:
            box.pack_start(label(_("The report could not be prepared."), classes=("warn-text",)), False, False, 0)
            return
        kind = _(FEEDBACK_KINDS.get(p.get("kind"), str(p.get("kind"))))
        box.pack_start(label(markup="<b>" + GLib.markup_escape_text(_("Type:")) + "</b> " +
                             GLib.markup_escape_text(kind)), False, False, 0)
        box.pack_start(label(_("Report text:"), classes=("dim", "small")), False, False, 0)
        box.pack_start(self._scrolled_pre(p.get("message") or "", 260), False, False, 0)
        if p.get("contact"):
            box.pack_start(label(_("Contact e-mail for a reply: {0}").format(p["contact"]), wrap=True,
                                 classes=("small",)), False, False, 0)
        box.pack_start(label(_("Sent with your LuxAI account.") if p.get("signed_in") else
                             _("Sent anonymously (you are not signed in)."), classes=("dim", "small")),
                       False, False, 0)
        if p.get("system") is not None:
            exp = Gtk.Expander(label=_("System information that will be attached (anonymised)"))
            add_class(exp, "small")
            exp.add(self._scrolled_pre(json.dumps(p["system"], ensure_ascii=False, indent=2), 300))
            box.pack_start(exp, False, False, 0)
        else:
            box.pack_start(label(_("No system information will be attached."), classes=("dim", "small")),
                           False, False, 0)
        shot = p.get("screenshot")
        if p.get("screenshot_bytes"):
            exp = Gtk.Expander(label=_("Screenshot that will be attached ({0} kB)").format(
                round(p["screenshot_bytes"] * 3 / 4 / 1024)))
            add_class(exp, "small")
            pb = pixbuf_from_data_url(shot, 480, 300) if shot else None
            exp.add(Gtk.Image.new_from_pixbuf(pb) if pb else label(_("(preview not available)"),
                                                                  classes=("dim", "small")))
            box.pack_start(exp, False, False, 0)
        else:
            box.pack_start(label(_("No screenshot will be attached."), classes=("dim", "small")), False, False, 0)
        for n in p.get("notes") or []:
            box.pack_start(label("• " + n, wrap=True, classes=("small",)), False, False, 0)

    def _preview_change(self, box):
        """Nahled toho, co se zmeni (obsah zapisovaneho souboru, nahrazovany text, cely prikaz)."""
        a = self.args
        if self.name == "send_feedback":
            self._preview_report(box)
        elif self.name == "write_file" and isinstance(a.get("content"), str):
            lines = a["content"].splitlines()
            text = "\n".join(lines[:12]) + (f"\n… (+{len(lines) - 12})" if len(lines) > 12 else "")
            box.pack_start(label(text or _("(empty file)"), selectable=True, wrap=True, classes=("tool-pre",)),
                           False, False, 0)
        elif self.name == "edit_file":
            old = "\n".join("- " + x for x in str(a.get("old_text", "")).splitlines()[:8])
            new = "\n".join("+ " + x for x in str(a.get("new_text", "")).splitlines()[:8])
            box.pack_start(label(old + "\n" + new, selectable=True, wrap=True, classes=("tool-pre",)),
                           False, False, 0)
        elif self.name in ("run_command", "type_text") and len(str(a.get("command") or a.get("text") or "")) > 140:
            box.pack_start(label(str(a.get("command") or a.get("text"))[:4000], selectable=True, wrap=True,
                                 classes=("tool-pre",)), False, False, 0)


class ErrorRow(Gtk.Box):
    def __init__(self, text, action=None, callback=None):
        super().__init__(spacing=10)
        add_class(self, "error-row")
        self.set_margin_end(40)
        self.pack_start(label(text, wrap=True, selectable=True), True, True, 0)
        if action and callback:
            b = Gtk.Button(label=action)
            add_class(b, "primary", "pill")
            b.set_valign(Gtk.Align.CENTER)
            b.connect("clicked", lambda *_a: callback())
            self.pack_end(b, False, False, 0)
        self.show_all()


# ---- adapter UI pro beh agenta -----------------------------------------------------
class RunUI:
    """Prevadi volani z vlakna agenta do hlavniho vlakna GTK."""

    def __init__(self, win, run_id):
        self.win, self.run_id = win, run_id

    def _idle(self, fn, *args):
        GLib.idle_add(lambda: (self.win.run_id == self.run_id and fn(*args), False)[1])

    def stream_start(self):
        self._idle(self.win.on_stream_start)

    def stream_delta(self, text, reasoning=""):
        self._idle(self.win.on_stream_delta, text, reasoning)

    def stream_end(self, message):
        self._idle(self.win.on_stream_end, message)

    def tool_start(self, call_id, name, args):
        self._idle(self.win.on_tool_start, call_id, name, args)

    def tool_result(self, call_id, name, result, status):
        self._idle(self.win.on_tool_result, call_id, result, status)

    def tool_prepared(self, call_id, name, preview):
        self._idle(self.win.on_tool_prepared, call_id, preview)

    def usage(self, usage):
        self._idle(self.win.on_usage, usage)

    def error(self, err):
        self._idle(self.win.on_run_error, err)

    def finished(self, reason):
        GLib.idle_add(lambda: (self.win.on_run_finished(self.run_id, reason), False)[1])

    def tool_confirm(self, call_id, name, args, kind, reasons):
        ev = threading.Event()
        box = {"v": "deny"}

        def done(value):
            box["v"] = value
            ev.set()

        def show():
            if self.win.run_id != self.run_id:
                done("deny")
            else:
                self.win.on_tool_confirm(call_id, kind, reasons, done)
            return False

        GLib.idle_add(show)
        self.win.pending_confirms.append(done)
        while not ev.wait(0.2):
            if self.win.current_run is None or self.win.current_run.cancelled.is_set():
                return "deny"
        return box["v"]


# ---- hlavni okno -----------------------------------------------------------------------
class LuxAIWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="LuxAI")
        add_class(self, "luxai")
        self.settings = getattr(app, "settings", None) or Settings()
        self.store = Store()
        self.account = load_account()
        self.client = LuxClient(self.account) if self.account else None
        self.user = (self.account or {}).get("user")
        self.signed_state = "ok" if self.account else "signed_out"
        self.mode = self.settings["mode"]
        self.model = self.settings["model"]
        self.conv = Conversation(mode=self.mode, model=self.model)
        self.perms = Permissions(auto_approve=False, policy=self.settings["agent"])
        self.gui = GuiBridge(self)
        self.title_jobs = {}        # conv_id -> TitleJob (nazev konverzace na pozadi)
        self._title_tried = set()   # konverzace, u kterych uz se nazev v tomto behu generoval
        self.settings_win = None
        self.current_run = None
        self.run_id = 0
        self.pending_confirms = []
        self.cards = {}
        self.bubble = None
        self._stick = True
        self._loading_list = False
        w, h = self.settings["window"]
        self.set_default_size(max(720, w), max(520, h))
        pb = app_icon_pixbuf(128)
        if pb:
            self.set_icon(pb)
        self._build()
        self.connect("delete-event", self._on_delete)
        self.refresh_list()
        self.show_all()
        self._update_mode_ui()
        self._show_main()
        self.show_welcome()
        if self.client:
            self.refresh_account()

    # ---- stavba -----------------------------------------------------------------------
    def _build(self):
        hb = Gtk.HeaderBar()
        hb.set_show_close_button(True)
        hb.set_title("LuxAI")
        self.set_titlebar(hb)
        self.btn_sidebar = Gtk.ToggleButton()
        self.btn_sidebar.set_image(Gtk.Image.new_from_icon_name(
            "sidebar-show-symbolic" if Gtk.IconTheme.get_default().has_icon("sidebar-show-symbolic")
            else "view-list-symbolic", Gtk.IconSize.BUTTON))
        self.btn_sidebar.set_tooltip_text(_("Show or hide the sidebar"))
        self.btn_sidebar.set_active(True)
        self.btn_sidebar.connect("toggled", lambda b: self.sidebar.set_visible(b.get_active()))
        hb.pack_start(self.btn_sidebar)
        hb.pack_start(icon_button("document-new-symbolic", _("New conversation") + " (Ctrl+N)",
                                  self.new_conversation))

        seg = add_class(Gtk.Box(), "segmented", "linked")
        self.rb_chat = Gtk.RadioButton.new_with_label(None, _("Chat"))
        self.rb_agent = Gtk.RadioButton.new_with_label_from_widget(self.rb_chat, _("Agent"))
        for rb, mode in ((self.rb_chat, "chat"), (self.rb_agent, "agent")):
            rb.set_mode(False)
            rb.connect("toggled", self._on_mode_toggled, mode)
            seg.pack_start(rb, False, False, 0)
        self.rb_chat.set_tooltip_text(_("Plain conversation, no access to your computer"))
        self.rb_agent.set_tooltip_text(_("LuxAI can work with your computer using tools, with your approval"))
        (self.rb_agent if self.mode == "agent" else self.rb_chat).set_active(True)
        hb.set_custom_title(seg)

        self.btn_menu = Gtk.MenuButton()
        self.btn_menu.set_image(Gtk.Image.new_from_icon_name("open-menu-symbolic", Gtk.IconSize.BUTTON))
        self.btn_menu.set_tooltip_text(_("Settings"))
        self.btn_menu.set_popover(self._build_popover())
        hb.pack_end(self.btn_menu)
        self.model_box = Gtk.ComboBoxText()
        self.model_box.append("flash", _("Flash – smarter"))
        self.model_box.append("lite", _("Lite – faster, larger limit"))
        self.model_box.set_active_id(self.model)
        self.model_box.set_tooltip_text(_("Model"))
        self.model_box.connect("changed", self._on_model_changed)
        hb.pack_end(self.model_box)

        paned = Gtk.Paned()
        self.add(paned)
        self.sidebar = self._build_sidebar()
        paned.pack1(self.sidebar, False, False)
        paned.set_position(self.settings["sidebar"])
        self.paned = paned

        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        add_class(self.stack, "luxai-main")
        paned.pack2(self.stack, True, False)
        self.stack.add_named(self._build_signin(), "signin")
        self.stack.add_named(self._build_chat(), "chat")

        accel = Gtk.AccelGroup()
        self.add_accel_group(accel)
        accel.connect(Gdk.keyval_from_name("n"), Gdk.ModifierType.CONTROL_MASK, 0,
                      lambda *_a: (self.new_conversation(), True)[1])
        accel.connect(Gdk.KEY_Escape, 0, 0, lambda *_a: (self.stop(), True)[1])
        accel.connect(Gdk.keyval_from_name("q"), Gdk.ModifierType.CONTROL_MASK, 0,
                      lambda *_a: (self.close(), True)[1])
        accel.connect(Gdk.KEY_comma, Gdk.ModifierType.CONTROL_MASK, 0, lambda *_a: (self.open_settings(), True)[1])
        accel.connect(Gdk.keyval_from_name("f"), Gdk.ModifierType.CONTROL_MASK, 0,
                      lambda *_a: (self.btn_sidebar.set_active(True), self.search.grab_focus(), True)[2])
        accel.connect(Gdk.KEY_F9, 0, 0,
                      lambda *_a: (self.btn_sidebar.set_active(not self.btn_sidebar.get_active()), True)[1])
        Gtk.Settings.get_default().connect("notify::gtk-theme-name", lambda *_a: self.get_application().apply_css())

    def _build_sidebar(self):
        box = add_class(Gtk.Box(orientation=Gtk.Orientation.VERTICAL), "sidebar")
        box.set_size_request(220, -1)
        self.search = Gtk.SearchEntry()
        self.search.set_placeholder_text(_("Search conversations"))
        add_class(self.search, "search")
        self.search.connect("search-changed", lambda *_a: self.refresh_list())
        box.pack_start(self.search, False, False, 0)
        box.pack_start(label(_("CONVERSATIONS"), classes=("side-title",)), False, False, 0)
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.listbox = Gtk.ListBox()
        self.listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.listbox.connect("row-selected", self._on_row_selected)
        self.listbox.connect("button-press-event", self._on_list_button)
        self.list_empty = label(_("No conversations yet"), classes=("dim", "small"), xalign=0.5)
        self.list_empty.set_margin_top(20)
        self.listbox.set_placeholder(self.list_empty)
        self.list_empty.show()
        sw.add(self.listbox)
        box.pack_start(sw, True, True, 0)

        acc = add_class(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6), "account")
        self.btn_profile = add_class(Gtk.Button(), "profile")
        self.btn_profile.set_relief(Gtk.ReliefStyle.NONE)
        self.btn_profile.set_tooltip_text(_("Account and settings"))
        self.btn_profile.connect("clicked", lambda *_a: self.show_profile_menu())
        top = Gtk.Box(spacing=8)
        self.avatar = add_class(label("?", xalign=0.5), "avatar")
        self.avatar.set_valign(Gtk.Align.CENTER)
        top.pack_start(self.avatar, False, False, 0)
        names = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.acc_name = label(_("Not signed in"), classes=("conv-title",), ellipsize=True)
        self.acc_sub = label("", classes=("dim", "small"), ellipsize=True)
        names.pack_start(self.acc_name, False, False, 0)
        names.pack_start(self.acc_sub, False, False, 0)
        top.pack_start(names, True, True, 0)
        top.pack_end(Gtk.Image.new_from_icon_name("pan-up-symbolic" if Gtk.IconTheme.get_default().has_icon(
            "pan-up-symbolic") else "go-up-symbolic", Gtk.IconSize.MENU), False, False, 0)
        self.btn_profile.add(top)
        acc.pack_start(self.btn_profile, False, False, 0)
        self.usage_bar = Gtk.LevelBar()
        self.usage_bar.set_min_value(0)
        self.usage_bar.set_max_value(1)
        for n in ("low", "high", "full"):
            self.usage_bar.remove_offset_value(n)
        acc.pack_start(self.usage_bar, False, False, 0)
        self.usage_label = label("", classes=("dim", "small"), wrap=True)
        acc.pack_start(self.usage_label, False, False, 0)
        box.pack_end(acc, False, False, 0)
        return box

    def _build_popover(self):
        pop = Gtk.Popover()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_border_width(14)
        box.set_size_request(320, -1)

        def switch_row(title, sub, active, cb):
            row = Gtk.Box(spacing=10)
            t = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            t.pack_start(label(title, classes=("conv-title",)), False, False, 0)
            s = label(sub, classes=("dim", "small"), wrap=True)
            s.set_max_width_chars(36)
            t.pack_start(s, False, False, 0)
            row.pack_start(t, True, True, 0)
            sw = Gtk.Switch()
            sw.set_active(active)
            sw.set_valign(Gtk.Align.CENTER)
            sw.connect("notify::active", lambda w, _p: cb(w.get_active()))
            row.pack_end(sw, False, False, 0)
            return row, sw

        row, self.sw_auto = switch_row(_("Auto-approve actions"),
                                       _("Agent actions run without asking. Dangerous actions still need two "
                                         "confirmations. Resets when LuxAI restarts."), False, self._on_auto)
        box.pack_start(row, False, False, 0)
        row, self.sw_vision = switch_row(_("Model can see images"),
                                         _("Attach screenshots for the current model. Turn on only if the model "
                                           "supports images; uses more tokens."),
                                         bool(self.settings["vision"].get(self.model)), self._on_vision)
        box.pack_start(row, False, False, 0)
        box.pack_start(Gtk.Separator(), False, False, 0)
        row = Gtk.Box(spacing=10)
        row.pack_start(label(_("Working folder"), classes=("conv-title",)), True, True, 0)
        self.folder_btn = Gtk.FileChooserButton(title=_("Working folder"), action=Gtk.FileChooserAction.SELECT_FOLDER)
        self.folder_btn.set_filename(self.workdir())
        self.folder_btn.connect("file-set", self._on_folder)
        self.folder_btn.set_size_request(150, -1)
        row.pack_end(self.folder_btn, False, False, 0)
        box.pack_start(row, False, False, 0)
        row = Gtk.Box(spacing=10)
        row.pack_start(label(_("Command timeout (seconds)"), classes=("conv-title",)), True, True, 0)
        spin = Gtk.SpinButton.new_with_range(10, 1800, 10)
        spin.set_value(int(self.settings["timeout"]))
        spin.connect("value-changed", lambda s: self._set_setting("timeout", int(s.get_value())))
        self.spin_timeout = spin
        row.pack_end(spin, False, False, 0)
        box.pack_start(row, False, False, 0)
        box.pack_start(Gtk.Separator(), False, False, 0)
        for text, cb in ((_("Settings…") + "  (Ctrl+,)", self.open_settings),
                         (_("LuxAI account…"), self.open_account_app), (_("About LuxAI"), self.about)):
            b = Gtk.ModelButton(text=text)
            b.connect("clicked", lambda *_a, f=cb: f())
            box.pack_start(b, False, False, 0)
        box.show_all()
        pop.add(box)
        return pop

    def _build_signin(self):
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        outer.set_valign(Gtk.Align.CENTER)
        outer.set_halign(Gtk.Align.CENTER)
        pb = app_icon_pixbuf(96)
        if pb:
            outer.pack_start(Gtk.Image.new_from_pixbuf(pb), False, False, 0)
        self.signin_title = label("", classes=("empty-title",), xalign=0.5)
        outer.pack_start(self.signin_title, False, False, 0)
        self.signin_text = label("", classes=("empty-text",), xalign=0.5, wrap=True)
        self.signin_text.set_justify(Gtk.Justification.CENTER)
        self.signin_text.set_max_width_chars(52)
        outer.pack_start(self.signin_text, False, False, 0)
        self.btn_signin = Gtk.Button(label=_("Sign in with LuxAI account"))
        add_class(self.btn_signin, "primary", "pill")
        self.btn_signin.set_halign(Gtk.Align.CENTER)
        self.btn_signin.connect("clicked", lambda *_a: self.sign_in())
        outer.pack_start(self.btn_signin, False, False, 6)
        reg = Gtk.LinkButton.new_with_label(REGISTER_URL, _("Create a free account"))
        outer.pack_start(reg, False, False, 0)
        self.signin_status = label("", classes=("dim", "small"), xalign=0.5, wrap=True)
        outer.pack_start(self.signin_status, False, False, 0)
        return outer

    def _build_chat(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.banner = add_class(Gtk.Box(spacing=8), "agent-banner")
        self.banner_icon = Gtk.Image.new_from_icon_name("dialog-information-symbolic", Gtk.IconSize.MENU)
        self.banner.pack_start(self.banner_icon, False, False, 0)
        self.banner_label = label("", classes=("small",), wrap=True)
        self.banner.pack_start(self.banner_label, True, True, 0)
        box.pack_start(self.banner, False, False, 0)

        self.scroll = Gtk.ScrolledWindow()
        self.scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        adj = self.scroll.get_vadjustment()
        adj.connect("value-changed", self._on_scroll_value)
        adj.connect("changed", lambda a: self._stick and a.set_value(a.get_upper() - a.get_page_size()))
        center = Clamp()
        self.column = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        self.column.set_margin_top(18)
        self.column.set_margin_bottom(18)
        center.add(self.column)
        self.scroll.add(center)
        box.pack_start(self.scroll, True, True, 0)

        bottom = Clamp()
        self.composer_col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        bottom.add(self.composer_col)
        comp = add_class(Gtk.Box(spacing=8), "composer")
        overlay = Gtk.Overlay()
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sw.set_propagate_natural_height(True)
        sw.set_max_content_height(200)
        self.input = Gtk.TextView()
        self.input.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.input.set_top_margin(6)
        self.input.set_bottom_margin(6)
        self.input.set_accepts_tab(False)
        self.input.connect("key-press-event", self._on_input_key)
        self.input.get_buffer().connect("changed", self._on_input_changed)
        sw.add(self.input)
        overlay.add(sw)
        self.placeholder = label("", classes=("dim",))
        self.placeholder.set_valign(Gtk.Align.START)
        self.placeholder.set_margin_top(6)
        self.placeholder.set_margin_start(2)
        self.placeholder.set_can_target(False) if hasattr(self.placeholder, "set_can_target") else None
        overlay.add_overlay(self.placeholder)
        overlay.set_overlay_pass_through(self.placeholder, True)
        comp.pack_start(overlay, True, True, 0)
        self.btn_send = Gtk.Button.new_from_icon_name("go-up-symbolic", Gtk.IconSize.BUTTON)
        add_class(self.btn_send, "send")
        self.btn_send.set_valign(Gtk.Align.END)
        self.btn_send.set_tooltip_text(_("Send (Enter)"))
        self.btn_send.connect("clicked", lambda *_a: self.send())
        comp.pack_end(self.btn_send, False, False, 0)
        self.btn_stop = Gtk.Button()
        sbox = Gtk.Box(spacing=6)
        sbox.pack_start(Gtk.Image.new_from_icon_name("media-playback-stop-symbolic", Gtk.IconSize.BUTTON),
                        False, False, 0)
        sbox.pack_start(Gtk.Label(label=_("Stop")), False, False, 0)
        self.btn_stop.add(sbox)
        sbox.show_all()
        add_class(self.btn_stop, "stop")
        self.btn_stop.set_valign(Gtk.Align.END)
        self.btn_stop.set_tooltip_text(_("Stop the answer and any running command (Esc)"))
        self.btn_stop.connect("clicked", lambda *_a: self.stop())
        self.btn_stop.set_no_show_all(True)
        comp.pack_end(self.btn_stop, False, False, 0)
        self.composer_col.pack_start(comp, False, False, 0)
        self.status_line = label("", classes=("status-line",), xalign=0.5, ellipsize=True)
        self.composer_col.pack_start(self.status_line, False, False, 0)
        box.pack_start(bottom, False, False, 6)
        return box

    # ---- rozmery a posouvani ---------------------------------------------------------
    def _on_scroll_value(self, adj):
        self._stick = adj.get_value() >= adj.get_upper() - adj.get_page_size() - 60

    def scroll_if_sticky(self):
        if self._stick:
            adj = self.scroll.get_vadjustment()
            adj.set_value(adj.get_upper() - adj.get_page_size())

    def scroll_to_end(self):
        self._stick = True
        GLib.idle_add(lambda: (self.scroll_if_sticky(), False)[1])

    def add_row(self, widget):
        self.column.pack_start(widget, False, False, 0)
        widget.show()
        self.scroll_if_sticky()
        return widget

    def clear_column(self):
        for c in self.column.get_children():
            c.destroy()
        self.cards = {}
        self.bubble = None

    # ---- nastaveni -----------------------------------------------------------------------
    def workdir(self):
        w = self.settings["workdir"]
        return w if w and os.path.isdir(w) else os.path.expanduser("~")

    def _set_setting(self, key, value):
        self.settings[key] = value
        self.settings.save()
        if self.settings_win is not None:
            self.settings_win.sync()

    def run_prefs(self):
        """Predvolby pro beh (Nastaveni > Chovani AI)."""
        st = self.settings
        return {"style": st["style"], "language": st["language"], "instructions": st["instructions"],
                "max_tokens": st.max_tokens(),
                "temperature": float(st["temperature"]) if st["temperature_custom"] else None}

    def on_setting_changed(self, key):
        """Zmena v okne Nastaveni: hned ji pouzit (ulozeni zajisti okno Nastaveni)."""
        st = self.settings
        if key == "model" and self.model_box.get_active_id() != st["model"] and self.current_run is None:
            self.model_box.set_active_id(st["model"])
        elif key == "vision":
            self.sw_vision.set_active(bool(st["vision"].get(self.model)))
            self._update_mode_ui()
        elif key == "workdir":
            if self.folder_btn.get_filename() != self.workdir():
                self.folder_btn.set_filename(self.workdir())
            self._update_mode_ui()
        elif key == "timeout":
            if int(self.spin_timeout.get_value()) != int(st["timeout"]):
                self.spin_timeout.set_value(int(st["timeout"]))
        elif key == "agent":
            self.perms.set_policy(st["agent"])
            self._update_mode_ui()
        elif key == "mode":
            if self.conv.empty and self.current_run is None:
                (self.rb_agent if st["mode"] == "agent" else self.rb_chat).set_active(True)
        elif key == "keep_history":
            if st["keep_history"]:
                self.save_conversation()
            self.refresh_list()
        elif key == "theme":
            app = self.get_application()
            if app is not None and hasattr(app, "apply_css"):
                app.apply_css()
            else:
                apply_theme_preference(st["theme"])

    def open_settings(self, page=None):
        if self.settings_win is None:
            self.settings_win = SettingsWindow(self)
            self.settings_win.connect("destroy", lambda *_a: setattr(self, "settings_win", None))
        if page:
            self.settings_win.show_page(page)
        self.settings_win.present()
        return self.settings_win

    def _on_auto(self, active):
        self.perms.auto_approve = active
        self._update_mode_ui()

    def _on_vision(self, active):
        v = dict(self.settings["vision"])
        v[self.model] = active
        self._set_setting("vision", v)
        self._update_mode_ui()

    def _on_folder(self, btn):
        path = btn.get_filename()
        if path:
            self._set_setting("workdir", path)
            self._update_mode_ui()

    def _on_model_changed(self, box):
        self.model = box.get_active_id() or "flash"
        self.conv.model = self.model
        if self.settings["model"] != self.model:
            self._set_setting("model", self.model)
        self.sw_vision.set_active(bool(self.settings["vision"].get(self.model)))
        self.update_account_ui()

    def _on_mode_toggled(self, rb, mode):
        if not rb.get_active():
            return
        self.mode = mode
        if hasattr(self, "conv"):
            self.conv.mode = mode
        self._set_setting("mode", mode)
        if hasattr(self, "banner"):
            self._update_mode_ui()
            if self.conv.empty:
                self.show_welcome()

    def _update_mode_ui(self):
        agent = self.mode == "agent"
        self.banner.set_visible(agent)
        ctx = self.banner.get_style_context()
        if self.perms.auto_approve:
            ctx.add_class("auto")
            self.banner_icon.set_from_icon_name("dialog-warning-symbolic", Gtk.IconSize.MENU)
            self.banner_label.set_text(_("Agent mode · Auto-approve is ON: actions run without asking "
                                         "(dangerous ones still ask twice)."))
        else:
            ctx.remove_class("auto")
            self.banner_icon.set_from_icon_name("dialog-information-symbolic", Gtk.IconSize.MENU)
            self.banner_label.set_text(_("Agent mode · LuxAI can work with your computer. You approve every "
                                         "action that changes something."))
        self.placeholder.set_text(_("Ask LuxAI to do something on your computer…") if agent
                                  else _("Message LuxAI…"))
        if self.mode == "agent":
            off = [k for k in ("commands", "write_files", "network") if self.perms.policy.get(k) == "never"]
            if self.perms.policy.get("allowed_folders") or self.perms.policy.get("blocked_folders") or off:
                self.banner_label.set_text(self.banner_label.get_text() + " " +
                                           _("Limits from Settings › Agent permissions apply."))
        vision = _("sees images") if self.settings["vision"].get(self.model) else _("no images")
        self.status_line.set_text(
            (_("Agent") + " · " + _("folder") + f" {self.workdir()} · {vision}") if agent
            else _("LuxAI can make mistakes. Check important information."))

    # ---- ucet -----------------------------------------------------------------------
    def _show_main(self):
        if self.signed_state == "ok":
            self.stack.set_visible_child_name("chat")
            self.input.grab_focus()
        else:
            expired = self.signed_state == "expired"
            self.signin_title.set_text(_("Your session has expired") if expired else _("Welcome to LuxAI"))
            self.signin_text.set_text(
                _("Please sign in again to continue. Your conversations are kept on this computer.") if expired
                else _("Chat with AI or let it work with your computer. Sign in with your LuxAI account – one "
                       "account for all LuxOS apps."))
            self.btn_signin.set_label(_("Sign in again") if expired else _("Sign in with LuxAI account"))
            self.stack.set_visible_child_name("signin")
        self.update_account_ui()

    def update_account_ui(self):
        u = self.user or {}
        if self.signed_state != "ok" or not u:
            self.acc_name.set_text(_("Session expired") if self.signed_state == "expired" else _("Not signed in"))
            self.acc_sub.set_text("")
            self.avatar.set_text("?")
            self.usage_bar.set_value(0)
            self.usage_label.set_text("")
            return
        name = u.get("displayName") or u.get("username") or u.get("email") or "LuxAI"
        self.acc_name.set_text(name)
        self.acc_sub.set_text(u.get("email") or "")
        self.avatar.set_text(name.strip()[:1].upper() or "?")
        used, limit, unlimited = usage_for(u, self.model)
        mname = "Flash" if self.model == "flash" else "Lite"
        if unlimited or not limit:
            self.usage_bar.set_value(0)
            self.usage_label.set_text(_("{0}: {1} tokens this month · unlimited").format(mname, fmt_int(used))
                                      if unlimited else _("{0}: {1} tokens this month").format(mname, fmt_int(used)))
        else:
            self.usage_bar.set_value(min(1.0, used / limit))
            self.usage_label.set_text(_("{0}: {1} / {2} tokens this month").format(mname, fmt_int(used),
                                                                                    fmt_int(limit)))

    def refresh_account(self):
        client = self.client
        if client is None:
            return

        def work():
            try:
                r = client.me()
                GLib.idle_add(self._account_ok, r.get("user"))
            except LuxError as e:
                GLib.idle_add(self._account_err, e)

        threading.Thread(target=work, daemon=True).start()

    def _account_ok(self, user):
        self.user = user
        if self.signed_state != "ok":
            self.signed_state = "ok"
            self._show_main()
        self.update_account_ui()
        return False

    def _account_err(self, err):
        if err.is_auth:
            self.signed_state = "expired"
            if self.current_run is None:
                self._show_main()
            else:
                self.update_account_ui()
        else:
            self.acc_sub.set_text(_("Offline – usage not available"))
        return False

    def reload_account(self):
        self.account = load_account()
        if self.account:
            self.client = LuxClient(self.account)
            self.user = self.account.get("user")
            self.signed_state = "ok"
            self._show_main()
            self.refresh_account()
            GLib.idle_add(self._send_pending_ask)
        else:
            self.client = None
            self.signed_state = "signed_out" if self.signed_state != "expired" else "expired"
            self._show_main()

    def sign_in(self):
        exe = shutil.which("luxos-account")
        if not exe:
            self.signin_status.set_text(_("The LuxOS account tool (luxos-account) is not installed."))
            self.stack.set_visible_child_name("signin")
            return
        self.btn_signin.set_sensitive(False)
        self.signin_status.set_text(_("Finish signing in in the LuxAI account window…"))
        try:
            pid, *_rest = GLib.spawn_async([exe, "login"], flags=GLib.SpawnFlags.DO_NOT_REAP_CHILD)
        except GLib.Error as e:
            self.btn_signin.set_sensitive(True)
            self.signin_status.set_text(str(e.message))
            return

        def done(pid_, status):
            GLib.spawn_close_pid(pid_)
            self.btn_signin.set_sensitive(True)
            self.signin_status.set_text("")
            prev = self.signed_state
            self.reload_account()
            if self.signed_state != "ok" and prev == self.signed_state:
                self.signin_status.set_text(_("Not signed in."))

        GLib.child_watch_add(GLib.PRIORITY_DEFAULT, pid, done)

    def open_account_app(self):
        exe = shutil.which("luxos-account")
        if exe:
            subprocess.Popen([exe], start_new_session=True)
        else:
            Gtk.show_uri_on_window(self, "https://lux-ai.cz", Gdk.CURRENT_TIME)

    # ---- profil (tlacitko uctu dole v postrannim panelu) ------------------------------------
    def show_profile_menu(self):
        pop = Gtk.Popover.new(self.btn_profile)
        pop.set_position(Gtk.PositionType.TOP)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.set_border_width(10)
        box.set_size_request(260, -1)
        u = self.user or {}
        signed = self.signed_state == "ok" and bool(self.account)
        head = Gtk.Box(spacing=10)
        head.set_margin_bottom(4)
        name = u.get("displayName") or u.get("username") or u.get("email") or ""
        av = add_class(label((name.strip()[:1].upper() or "?") if signed else "?", xalign=0.5), "avatar-big")
        av.set_valign(Gtk.Align.CENTER)
        head.pack_start(av, False, False, 0)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        texts.set_valign(Gtk.Align.CENTER)
        if signed:
            texts.pack_start(label(name or "LuxAI", classes=("profile-name",), ellipsize=True), False, False, 0)
            if u.get("email"):
                texts.pack_start(label(u["email"], classes=("dim", "small"), ellipsize=True, selectable=True),
                                 False, False, 0)
            if self.usage_label.get_text():
                texts.pack_start(label(self.usage_label.get_text(), classes=("dim", "small"), wrap=True),
                                 False, False, 0)
        else:
            texts.pack_start(label(_("Session expired") if self.signed_state == "expired" else _("Not signed in"),
                                   classes=("profile-name",)), False, False, 0)
            texts.pack_start(label(_("Sign in with your LuxAI account to chat."), classes=("dim", "small"),
                                   wrap=True), False, False, 0)
        head.pack_start(texts, True, True, 0)
        box.pack_start(head, False, False, 0)
        box.pack_start(Gtk.Separator(), False, False, 4)
        items = [(_("Settings…"), self.open_settings)]
        if signed:
            items += [(_("Manage account"), self.open_account_app), (_("Sign out…"), self.sign_out)]
        else:
            items += [(_("Sign in again") if self.signed_state == "expired" else _("Sign in"), self.sign_in)]
        for text, cb in items:
            b = Gtk.ModelButton(text=text)
            b.connect("clicked", lambda *_a, f=cb: (pop.popdown(), GLib.idle_add(lambda: (f(), False)[1])))
            box.pack_start(b, False, False, 0)
        pop.add(box)
        box.show_all()
        pop.popup()
        self.profile_popover = pop
        return pop

    def sign_out(self):
        d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
                              buttons=Gtk.ButtonsType.NONE, text=_("Sign out of LuxAI?"))
        d.format_secondary_text(_("You will be signed out of your LuxAI account in all LuxOS apps on this computer. "
                                  "Your conversations stay on this computer."))
        d.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        b = d.add_button(_("Sign out"), Gtk.ResponseType.OK)
        add_class(b, "destructive-action")
        resp = d.run()
        d.destroy()
        if resp != Gtk.ResponseType.OK:
            return
        exe = shutil.which("luxos-account")
        if not exe:
            self._message(_("The LuxOS account tool (luxos-account) is not installed."))
            return
        self.stop()
        self._cancel_title_jobs()
        try:
            pid, *_rest = GLib.spawn_async([exe, "logout"], flags=GLib.SpawnFlags.DO_NOT_REAP_CHILD)
        except GLib.Error as e:
            self._message(str(e.message))
            return

        def done(pid_, _status):
            GLib.spawn_close_pid(pid_)
            self.signed_state = "signed_out"
            self.reload_account()
            if self.signed_state == "ok":
                self._message(_("Signing out failed. Try again in the LuxAI account app."))

        GLib.child_watch_add(GLib.PRIORITY_DEFAULT, pid, done)

    def _message(self, text):
        d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.INFO,
                              buttons=Gtk.ButtonsType.OK, text=text)
        d.run()
        d.destroy()

    def clear_history(self, parent=None):
        d = Gtk.MessageDialog(transient_for=parent or self, modal=True, message_type=Gtk.MessageType.WARNING,
                              buttons=Gtk.ButtonsType.NONE, text=_("Delete all conversations?"))
        d.format_secondary_text(_("All saved conversations will be permanently removed from this computer."))
        d.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        b = d.add_button(_("Delete all"), Gtk.ResponseType.OK)
        add_class(b, "destructive-action")
        resp = d.run()
        d.destroy()
        if resp != Gtk.ResponseType.OK:
            return False
        self.stop()
        self._cancel_title_jobs()
        self.store.clear()
        self.conv = Conversation(mode=self.mode, model=self.model)
        self.perms.reset()
        self.show_welcome()
        self.refresh_list()
        return True

    def screenshot_count(self):
        try:
            return len([n for n in os.listdir(SHOT_DIR) if n.endswith(".png")])
        except OSError:
            return 0

    def clear_screenshots(self):
        try:
            names = os.listdir(SHOT_DIR)
        except OSError:
            return
        for n in names:
            if n.startswith("shot-") and n.endswith(".png"):
                try:
                    os.unlink(os.path.join(SHOT_DIR, n))
                except OSError:
                    pass

    def notify_user(self, title, body):
        """Systemove oznameni, jen kdyz je okno v pozadi a uzivatel ho v Nastaveni nevypnul."""
        if not self.settings["notify"] or self.is_active():
            return
        app = self.get_application()
        if app is None:
            return
        n = Gio.Notification.new(title)
        n.set_body(body)
        try:
            app.send_notification("luxai-run", n)
        except GLib.Error:
            pass

    # ---- nazvy konverzaci -------------------------------------------------------------------
    def maybe_generate_title(self):
        """Po prvni vecne zprave a odpovedi necha model lite vymyslet nazev (na pozadi)."""
        conv = self.conv
        if conv.title_source != "fallback" or conv.id in self._title_tried or conv.id in self.title_jobs:
            return None
        topic = titles.topic_text(conv.messages)
        if not topic:
            return None  # zatim jen pozdrav - pocka se na skutecne tema
        answer = titles.first_answer_after(conv.messages, topic)
        if not answer:
            return None
        self._title_tried.add(conv.id)
        conv.title = titles.fallback_title(topic)
        if self.current_run is None:
            self._store_save(conv, touch=False)
        if not self.settings["auto_title"] or self.client is None or not self.account:
            return None
        job = titles.TitleJob(self.account, conv.id, topic, answer,
                              lambda cid, t, src: GLib.idle_add(lambda: (self.on_title(cid, t, src), False)[1]))
        self.title_jobs[conv.id] = job
        return job.start()

    def on_title(self, cid, title, source):
        self.title_jobs.pop(cid, None)
        if not title:
            return
        if cid == self.conv.id:
            conv = self.conv
        elif self.settings["keep_history"]:
            try:
                conv = self.store.load(cid)
            except (OSError, ValueError):
                return
        else:
            return
        if conv.title_source == "manual":
            return  # uzivatel mezitim konverzaci prejmenoval
        conv.title = title
        conv.title_source = source
        if conv is not self.conv or self.current_run is None:
            self._store_save(conv, touch=False)
        self.refresh_list()

    def _cancel_title_jobs(self):
        for job in list(self.title_jobs.values()):
            job.cancel()
        self.title_jobs.clear()

    def rename_conversation(self, cid):
        if cid == self.conv.id:
            conv = self.conv
        else:
            try:
                conv = self.store.load(cid)
            except (OSError, ValueError):
                return
        d = Gtk.Dialog(title=_("Rename conversation"), transient_for=self, modal=True)
        d.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        ok = d.add_button(_("Rename"), Gtk.ResponseType.OK)
        add_class(ok, "suggested-action")
        d.set_default_response(Gtk.ResponseType.OK)
        entry = Gtk.Entry()
        entry.set_text(conv.display_title())
        entry.set_activates_default(True)
        entry.set_width_chars(40)
        area = d.get_content_area()
        area.set_border_width(12)
        area.set_spacing(8)
        area.pack_start(label(_("Name"), classes=("dim", "small")), False, False, 0)
        area.pack_start(entry, False, False, 0)
        d.show_all()
        self.rename_dialog = d
        resp = d.run()
        text = " ".join(entry.get_text().split())[:120]
        d.destroy()
        self.rename_dialog = None
        if resp == Gtk.ResponseType.OK and text:
            self.set_conversation_title(conv, text)

    def set_conversation_title(self, conv, text):
        conv.title = text
        conv.title_source = "manual"
        job = self.title_jobs.pop(conv.id, None)
        if job is not None:
            job.cancel()
        if conv is not self.conv or self.current_run is None:
            self._store_save(conv, touch=False)
        self.refresh_list()

    def _store_save(self, conv, touch=True):
        if not self.settings["keep_history"]:
            return False
        try:
            return self.store.save(conv, touch=touch)
        except OSError:
            return False

    def _row_menu(self, cid):
        menu = Gtk.Menu()
        for text, cb in ((_("Rename…"), lambda: self.rename_conversation(cid)),
                         (_("Delete"), lambda: self.delete_conversation(cid))):
            it = Gtk.MenuItem(label=text)
            it.connect("activate", lambda *_a, f=cb: GLib.idle_add(lambda: (f(), False)[1]))
            menu.append(it)
        menu.show_all()
        menu.attach_to_widget(self.listbox, None)
        return menu

    def _on_list_button(self, lb, ev):
        """Pravy klik na konverzaci: nabidka Prejmenovat / Smazat; dvojklik: prejmenovat."""
        row = lb.get_row_at_y(int(ev.y))
        if row is None or not hasattr(row, "conv_id"):
            return False
        if ev.type == Gdk.EventType.BUTTON_PRESS and ev.button == 3:
            self._row_menu(row.conv_id).popup_at_pointer(ev)
            return True
        if ev.type == Gdk.EventType._2BUTTON_PRESS and ev.button == 1:
            GLib.idle_add(lambda: (self.rename_conversation(row.conv_id), False)[1])
            return True
        return False

    def about(self):
        d = Gtk.AboutDialog(transient_for=self, modal=True)
        d.set_program_name("LuxAI")
        d.set_version(__version__)
        d.set_comments(_("AI assistant that can work with your computer"))
        d.set_website("https://lux-ai.cz")
        pb = app_icon_pixbuf(96)
        if pb:
            d.set_logo(pb)
        d.run()
        d.destroy()

    # ---- seznam konverzaci ------------------------------------------------------------
    def refresh_list(self):
        self._loading_list = True
        for r in self.listbox.get_children():
            r.destroy()
        q = (self.search.get_text() or "").lower()
        today = time.strftime("%Y-%m-%d")
        items = self.store.list()
        if not self.settings["keep_history"]:
            self.list_empty.set_text(_("History is turned off"))
            items = [] if self.conv.empty else [{"id": self.conv.id, "title": "", "mode": self.conv.mode,
                                                 "updated": self.conv.updated or time.time()}]
        else:
            self.list_empty.set_text(_("No conversations yet"))
        for item in items:
            if item["id"] == self.conv.id and not self.conv.empty:
                item = dict(item, title=self.conv.display_title() or item["title"])
            if q and q not in item["title"].lower():
                continue
            row = Gtk.ListBoxRow()
            row.conv_id = item["id"]
            row.set_tooltip_text(item["title"])
            box = Gtk.Box(spacing=6)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            texts.pack_start(label(item["title"], classes=("conv-title",), ellipsize=True), False, False, 0)
            day = time.strftime("%Y-%m-%d", time.localtime(item["updated"]))
            when = time.strftime("%H:%M", time.localtime(item["updated"])) if day == today else \
                time.strftime("%d.%m.%Y", time.localtime(item["updated"]))
            sub = (_("Agent") if item["mode"] == "agent" else _("Chat")) + " · " + when
            texts.pack_start(label(sub, classes=("dim", "small")), False, False, 0)
            box.pack_start(texts, True, True, 0)
            delete = icon_button("user-trash-symbolic", _("Delete conversation"),
                                 lambda cid=item["id"]: self.delete_conversation(cid), ("row-delete",))
            delete.set_valign(Gtk.Align.CENTER)
            box.pack_end(delete, False, False, 0)
            row.add(box)
            self.listbox.add(row)
            if item["id"] == self.conv.id:
                self.listbox.select_row(row)
        self.listbox.show_all()
        self._loading_list = False

    def _on_row_selected(self, _lb, row):
        if self._loading_list or row is None or row.conv_id == self.conv.id:
            return
        self.open_conversation(row.conv_id)

    def open_conversation(self, cid):
        self.stop()
        self.save_conversation()
        try:
            conv = self.store.load(cid)
        except (OSError, ValueError):
            return
        self.conv = conv
        self.model_box.set_active_id(conv.model if conv.model in ("flash", "lite") else self.model)
        (self.rb_agent if conv.mode == "agent" else self.rb_chat).set_active(True)
        self.render_conversation()
        if self.signed_state != "ok":
            # historie je k dispozici i bez prihlaseni, odesilani ne
            self.stack.set_visible_child_name("chat")
            self.add_row(ErrorRow(_("Sign in to continue this conversation."), _("Sign in again")
                                  if self.signed_state == "expired" else _("Sign in"), self.sign_in))
            self.scroll_to_end()
        self.input.grab_focus()

    def render_conversation(self):
        self.clear_column()
        if self.conv.empty:
            self.show_welcome()
            return
        results = {m.get("tool_call_id"): m.get("content") for m in self.conv.messages if m.get("role") == "tool"}
        for m in self.conv.messages:
            role = m.get("role")
            c = m.get("content")
            if role == "user" and isinstance(c, str):
                self.add_row(UserBubble(c))
            elif role == "assistant":
                if c:
                    self.add_row(AssistantBubble(self, c))
                for tc in m.get("tool_calls") or []:
                    fn = tc.get("function") or {}
                    try:
                        args = json.loads(fn.get("arguments") or "{}")
                    except ValueError:
                        args = {}
                    card = ToolCard(self, tc.get("id"), fn.get("name", ""), args if isinstance(args, dict) else {})
                    self.add_row(card)
                    raw = results.get(tc.get("id"))
                    try:
                        res = json.loads(raw) if raw else {"ok": False, "error": _("No result")}
                    except ValueError:
                        res = {"ok": True, "output": raw}
                    if not isinstance(res, dict):
                        res = {"ok": True, "output": str(res)}
                    st = "ok" if res.get("ok") else "blocked" if res.get("blocked") else \
                        "denied" if res.get("permission_denied") else "cancelled" if res.get("cancelled") else "error"
                    card.set_result(res, st)
        self.scroll_to_end()

    def new_conversation(self):
        self.stop()
        self.save_conversation()
        self.conv = Conversation(mode=self.mode, model=self.model)
        self.perms.reset()
        self.listbox.unselect_all()
        self.show_welcome()
        if self.signed_state != "ok":
            self._show_main()
        self.input.grab_focus()

    def save_conversation(self):
        if self._store_save(self.conv) or not self.settings["keep_history"]:
            self.refresh_list()

    def delete_conversation(self, cid):
        d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
                              buttons=Gtk.ButtonsType.NONE, text=_("Delete this conversation?"))
        d.format_secondary_text(_("It will be permanently removed from this computer."))
        d.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        b = d.add_button(_("Delete"), Gtk.ResponseType.OK)
        add_class(b, "destructive-action")
        resp = d.run()
        d.destroy()
        if resp != Gtk.ResponseType.OK:
            return
        if cid == self.conv.id:
            self.stop()
            self.store.delete(cid)
            self.conv = Conversation(mode=self.mode, model=self.model)
            self.show_welcome()
        else:
            self.store.delete(cid)
        self.refresh_list()

    def show_welcome(self):
        if not self.conv.empty:
            return
        self.clear_column()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.set_margin_top(60)
        pb = app_icon_pixbuf(64)
        if pb:
            box.pack_start(Gtk.Image.new_from_pixbuf(pb), False, False, 0)
        box.pack_start(label(_("How can I help you today?"), classes=("empty-title",), xalign=0.5), False, False, 0)
        sub = _("Agent mode: I can run commands, manage files, open apps and control the mouse and keyboard – "
                "always with your approval.") if self.mode == "agent" else \
            _("Ask anything. Switch to Agent mode when you want me to do things on your computer.")
        s = label(sub, classes=("empty-text",), xalign=0.5, wrap=True)
        s.set_justify(Gtk.Justification.CENTER)
        box.pack_start(s, False, False, 0)
        grid = Gtk.Grid(column_spacing=10, row_spacing=10, column_homogeneous=True)
        grid.set_margin_top(16)
        for i, (title, prompt) in enumerate(SUGGESTIONS[self.mode]):
            b = Gtk.Button()
            add_class(b, "chip")
            v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            v.pack_start(label(_(title), classes=("conv-title",)), False, False, 0)
            p = label(_(prompt), classes=("dim", "small"), wrap=True)
            p.set_max_width_chars(36)
            v.pack_start(p, False, False, 0)
            b.add(v)
            b.connect("clicked", lambda *_a, t=_(prompt): self.set_input(t))
            grid.attach(b, i % 2, i // 2, 1, 1)
        box.pack_start(grid, False, False, 0)
        self.column.pack_start(box, False, False, 0)
        box.show_all()

    # ---- vstup ------------------------------------------------------------------------
    def ask(self, text, mode="agent", tries=0):
        """Dotaz zvenku: novy rozhovor v danem rezimu a hned odeslat (po prihlaseni k uctu)."""
        if self.current_run is not None:
            self.set_input(text)            # bezici ukol neprerusovat, dotaz pripravit do pole
            return False
        if tries == 0:
            if not self.conv.empty:
                self.new_conversation()
            (self.rb_agent if mode == "agent" else self.rb_chat).set_active(True)
            self.set_input(text)
        if self.signed_state == "ok" and self.client is not None:
            self.pending_ask = None
            self.send()
        elif tries < 30 and self.signed_state == "ok":
            # klient se jeste pripravuje (start aplikace) - zkusit znovu za chvili
            GLib.timeout_add(300, self.ask, text, mode, tries + 1)
        else:
            # bez prihlaseni: dotaz se odesle hned po prihlaseni k uctu LuxAI
            self.pending_ask = (text, mode)
        return False

    def _send_pending_ask(self):
        pending = getattr(self, "pending_ask", None)
        if pending and self.signed_state == "ok" and self.client is not None and self.current_run is None:
            self.pending_ask = None
            self.ask(*pending)
        return False

    def set_input(self, text):
        self.input.get_buffer().set_text(text)
        self.input.grab_focus()

    def _on_input_changed(self, buf):
        self.placeholder.set_visible(buf.get_char_count() == 0)

    def _on_input_key(self, _w, ev):
        if ev.keyval not in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            return False
        ctrl = bool(ev.state & Gdk.ModifierType.CONTROL_MASK)
        if self.settings["send_key"] == "ctrl_enter":
            if ctrl:
                self.send()
                return True
            return False
        if not (ev.state & Gdk.ModifierType.SHIFT_MASK):
            self.send()
            return True
        return False

    def send(self):
        if self.current_run is not None or self.signed_state != "ok" or self.client is None:
            return
        buf = self.input.get_buffer()
        text = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False).strip()
        if not text:
            return
        buf.set_text("")
        if self.conv.empty:
            self.clear_column()
        self.conv.mode, self.conv.model = self.mode, self.model
        self.conv.messages.append({"role": "user", "content": text})
        self.add_row(UserBubble(text))
        self.scroll_to_end()
        vision = bool(self.settings["vision"].get(self.model))
        tools = None
        if self.mode == "agent":
            tools = Tools(workdir=self.workdir(), gui=self.gui, timeout=int(self.settings["timeout"]), vision=vision,
                          blocked=self.perms.policy.get("blocked_folders") or (), client=self.client)
        self.run_id += 1
        self.pending_confirms = []
        self.current_run = Run(self.client, self.conv, RunUI(self, self.run_id), mode=self.mode, model=self.model,
                               tools=tools, permissions=self.perms, vision=vision, screen=self.gui.screen_size(),
                               prefs=self.run_prefs())
        self._set_running(True)
        self.current_run.start()

    def _set_running(self, running):
        self.btn_send.set_visible(not running)
        self.btn_stop.set_visible(running)
        self.model_box.set_sensitive(not running)
        self.rb_chat.set_sensitive(not running)
        self.rb_agent.set_sensitive(not running)

    def stop(self):
        run = self.current_run
        if run is None:
            return
        run.cancel()
        for done in list(self.pending_confirms):
            try:
                done("deny")
            except Exception:  # noqa: BLE001
                pass
        for card in self.cards.values():
            if hasattr(card, "cancel_ask"):
                for c in card.confirm_box.get_children():
                    c.destroy()
        self.status_line.set_text(_("Stopping…"))

    # ---- udalosti behu ----------------------------------------------------------------
    def on_stream_start(self):
        self.bubble = self.add_row(AssistantBubble(self))
        self.scroll_if_sticky()

    def on_stream_delta(self, text, reasoning):
        if self.bubble is not None:
            self.bubble.append(text, reasoning)

    def on_stream_end(self, message):
        b = self.bubble
        self.bubble = None
        if b is None:
            return
        content = message.get("content")
        if not content:
            b.destroy()
        else:
            b.finish(content)
        self.scroll_if_sticky()

    def on_tool_start(self, call_id, name, args):
        card = ToolCard(self, call_id, name, args)
        self.cards[call_id] = card
        self.add_row(card)

    def on_tool_prepared(self, call_id, preview):
        card = self.cards.get(call_id)
        if card is not None:
            card.set_prepared(preview)

    def on_tool_confirm(self, call_id, kind, reasons, done):
        card = self.cards.get(call_id)
        if card is None:
            done("deny")
            return
        card.ask(kind, reasons, done)
        self.scroll_to_end()
        if not self.is_active():
            self.set_urgency_hint(True)
            self.notify_user(_("LuxAI needs your approval"), _(LABELS.get(card.name, card.name)) + ": " +
                             subject(card.name, card.args))

    def on_tool_result(self, call_id, result, status):
        card = self.cards.get(call_id)
        if card is not None:
            card.set_result(result, status)
            self.scroll_if_sticky()

    def on_usage(self, usage):
        u = self.user
        if not u:
            return
        try:
            total = int(usage.get("total_tokens") or 0)
        except (TypeError, ValueError, AttributeError):
            return
        key = "fastTokens" if self.model == "flash" else "liteTokens"
        u.setdefault("usage", {})[key] = int(u["usage"].get(key, 0) or 0) + total
        self.update_account_ui()

    def on_run_error(self, err):
        if self.bubble is not None:
            if not self.bubble.text:
                self.bubble.destroy()
            else:
                self.bubble.finish()
            self.bubble = None
        if getattr(err, "is_auth", False):
            self.signed_state = "expired"
            self.update_account_ui()
            self.add_row(ErrorRow(err.human(), _("Sign in again"), self.sign_in))
        else:
            self.add_row(ErrorRow(err.human() if isinstance(err, LuxError) else str(err)))
        self.scroll_to_end()

    def on_run_finished(self, run_id, reason):
        if run_id != self.run_id:
            return
        if self.bubble is not None:
            self.bubble.finish()
            self.bubble = None
        self.current_run = None
        self.pending_confirms = []
        self._set_running(False)
        self._update_mode_ui()
        if reason == "cancelled":
            self.add_row(label(_("Stopped."), classes=("dim", "small")))
        elif reason == "limit":
            self.add_row(label(_("Stopped after too many steps. Send a message to continue."),
                               classes=("dim", "small")))
        elif reason == "length":
            self.add_row(label(_("The answer was cut off (length limit)."), classes=("dim", "small")))
        self.save_conversation()
        if reason in ("done", "length"):
            self.maybe_generate_title()
            self.notify_user(_("LuxAI answered"), self.conv.display_title())
        self.set_urgency_hint(False)
        if self.signed_state == "ok":
            GLib.timeout_add(1500, lambda: (self.refresh_account(), False)[1])
        self.scroll_if_sticky()

    def _on_delete(self, *_a):
        if self.settings_win is not None:
            self.settings_win.destroy()
        self.stop()
        self.save_conversation()
        w, h = self.get_size()
        self.settings["window"] = [w, h]
        self.settings["sidebar"] = self.paned.get_position()
        self.settings.save()
        return False


class LuxAIApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.provider = None
        self.window = None
        self.settings = None

    def apply_css(self):
        if self.settings is None:
            self.settings = Settings()
        apply_theme_preference(self.settings["theme"])
        screen = Gdk.Screen.get_default()
        if self.provider is not None:
            Gtk.StyleContext.remove_provider_for_screen(screen, self.provider)
        self.provider = Gtk.CssProvider()
        self.provider.load_from_data(((DARK if is_dark() else LIGHT) + CSS).encode())
        Gtk.StyleContext.add_provider_for_screen(screen, self.provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        if self.window is not None and self.window.get_visible():
            self.window.render_conversation() if not self.window.conv.empty and self.window.current_run is None \
                else None

    def do_activate(self):
        if self.window is None:
            self.apply_css()
            self.window = LuxAIWindow(self)
        self.window.present()

    def do_command_line(self, cmdline):
        """luxai [--agent|--chat] [DOTAZ] - dotaz z Launchpadu nebo Hledani (i do bezici instance)."""
        mode, words = "agent", []
        for a in cmdline.get_arguments()[1:]:
            if a in ("--agent", "--chat"):
                mode = a[2:]
            elif not a.startswith("--"):
                words.append(a)
        self.activate()
        text = " ".join(words).strip()
        if text:
            self.window.ask(text, mode)
        return 0


def main(argv=None):
    import sys
    GLib.set_prgname("luxai")
    GLib.set_application_name("LuxAI")
    app = LuxAIApp()
    return app.run(argv if argv is not None else sys.argv)
