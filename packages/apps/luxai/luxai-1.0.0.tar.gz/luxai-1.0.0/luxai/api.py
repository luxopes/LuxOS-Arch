"""Klient sdileneho uctu LuxAI (lux-ai.cz) pro aplikaci LuxAI.

- ucet (session token) cte jen z ~/.config/luxai/account.json pres
  /usr/lib/luxos/python/luxai_account.py (nebo vestavenou nahradu se stejnym formatem),
- GET /api/me: uzivatel a mesicni spotreba,
- POST /api/ide/chat/completions: OpenAI-kompatibilni chat s nastroji, stream=True -> SSE.

Kazdy pozadavek nese cookie lux_account_session=<token> a hlavicku X-Lux-Client: luxai.
Token se nikdy nevypisuje ani neloguje (ani v chybovych hlaskach).
"""
import http.client
import json
import os
import secrets
import socket
import ssl
import sys
import threading
from urllib.parse import urlsplit

from . import __version__
from .i18n import _

DEFAULT_ORIGIN = "https://lux-ai.cz"
COOKIE = "lux_account_session"
CLIENT = "luxai"
CHAT_PATH = "/api/ide/chat/completions"
ME_PATH = "/api/me"
MODELS = [("flash", "Flash"), ("lite", "Lite")]
LUXOS_PYTHON = "/usr/lib/luxos/python"


# ---- ucet -------------------------------------------------------------------------
def account_file():
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, "luxai", "account.json")


def _system_account_module():
    """Systemovy modul luxai_account (balicek luxos-account), pokud je nainstalovany."""
    if LUXOS_PYTHON not in sys.path and os.path.isdir(LUXOS_PYTHON):
        sys.path.append(LUXOS_PYTHON)
    try:
        import luxai_account  # noqa: PLC0415
    except ImportError:
        return None
    # Modul si cestu urci pri importu; pri jine XDG_CONFIG_HOME (testy) pouzit vlastni cteni
    if getattr(luxai_account, "ACCOUNT_FILE", None) != account_file():
        return None
    return luxai_account


def load_account():
    """Ulozeny ucet (dict se sessionToken) nebo None. Soubor jen cteme, nikdy nezapisujeme."""
    mod = _system_account_module()
    if mod is not None:
        try:
            acc = mod.load()
        except Exception:  # noqa: BLE001
            acc = None
        return acc if isinstance(acc, dict) and acc.get("sessionToken") else None
    try:
        with open(account_file(), encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or not isinstance(data.get("sessionToken"), str) or not data["sessionToken"]:
        return None
    return data


def safe_origin(origin):
    """Povoleny puvod pro odesilani tokenu: https://..., nebo http jen na loopback (testy)."""
    origin = (origin or DEFAULT_ORIGIN).strip().rstrip("/")
    u = urlsplit(origin)
    if u.scheme == "https" and u.hostname:
        return f"https://{u.netloc}"
    if u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost", "::1"):
        return f"http://{u.netloc}"
    return DEFAULT_ORIGIN


def account_origin(account):
    return safe_origin(os.environ.get("LUXAI_ORIGIN") or (account or {}).get("origin") or DEFAULT_ORIGIN)


# ---- chyby --------------------------------------------------------------------------
class LuxError(Exception):
    def __init__(self, code, status=0, detail=""):
        super().__init__(code)
        self.code, self.status, self.detail = code, status, str(detail or "")[:400]

    @property
    def is_auth(self):
        return self.code in ("auth", "signed_out") or self.status in (401, 403)

    def human(self):
        if self.is_auth:
            return _("Your LuxAI session has expired or is not valid. Please sign in again.")
        m = {
            "chat_busy": _("Another conversation is already running on this account. Try again in a moment."),
            "chat_rate": _("Too many requests. Please wait a moment."),
            "rate": _("Too many requests. Please wait a moment."),
            "flash_monthly_limit": _("The monthly Flash limit is used up. Switch to Lite or wait for the next month."),
            "monthly_limit": _("The monthly Lite limit is used up."),
            "unavailable": _("The LuxAI service is not available right now."),
            "model": _("The model failed: {0}").format(self.detail or self.status),
            "network": _("Network error: {0}").format(self.detail),
            "timeout": _("The server did not respond in time."),
            "not_found": _("The LuxAI API endpoint was not found on the server."),
            "protection": _("The server's web protection blocked the request (HTTP {0}).").format(self.status),
            "html_response": _("The server returned a web page instead of an API response (HTTP {0}).").format(self.status),
            "bad_response": _("The server returned an invalid response (HTTP {0}).").format(self.status),
            "invalid_chat": _("The server rejected the request (invalid chat)."),
        }
        if self.code in m:
            return m[self.code]
        return f"{self.code} (HTTP {self.status}) {self.detail}".strip()


def _looks_like_html(raw):
    head = raw.lstrip()[:200].lower()
    return head.startswith("<!doctype html") or head.startswith("<html") or "<head" in head


def error_from_response(status, raw):
    """LuxError z chybove odpovedi serveru (JSON {error, detail} nebo HTML stranka)."""
    try:
        payload = json.loads(raw)
    except ValueError:
        payload = None
    if not isinstance(payload, dict):
        payload = {}
    if not payload and _looks_like_html(raw):
        low = raw.lower()
        code = "protection" if ("wedos.protection" in low or "altcha" in low) else "html_response"
        if status in (401, 403) and code == "html_response":
            code = "auth"
        return LuxError(code, status)
    err = payload.get("error")
    if isinstance(err, dict):
        detail = err.get("message") or ""
        err = err.get("code") or err.get("type") or "model"
    else:
        detail = payload.get("detail") or payload.get("message") or ""
    if status in (401, 403):
        return LuxError("auth", status, "")
    if not err:
        err = "not_found" if status == 404 else f"http_{status}"
    return LuxError(str(err), status, detail if isinstance(detail, str) else json.dumps(detail)[:300])


# ---- SSE ------------------------------------------------------------------------------
class SSEParser:
    """Inkrementalni parser Server-Sent Events. feed(bytes) vraci seznam hodnot 'data'
    (texty); konec streamu oznaci atribut done po zprave [DONE]."""

    def __init__(self):
        self._buf = b""
        self.done = False

    def feed(self, chunk):
        out = []
        self._buf += chunk
        self._buf = self._buf.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
        while b"\n\n" in self._buf and not self.done:
            frame, self._buf = self._buf.split(b"\n\n", 1)
            data = self._frame_data(frame)
            if data is None:
                continue
            if data.strip() == "[DONE]":
                self.done = True
                break
            out.append(data)
        return out

    def flush(self):
        """Posledni ramec bez ukoncujiciho prazdneho radku (server zavrel spojeni)."""
        if self.done or not self._buf.strip():
            return []
        frame, self._buf = self._buf, b""
        data = self._frame_data(frame)
        if data is None:
            return []
        if data.strip() == "[DONE]":
            self.done = True
            return []
        return [data]

    @staticmethod
    def _frame_data(frame):
        lines = []
        for line in frame.decode("utf-8", "replace").split("\n"):
            if line.startswith(":"):
                continue  # komentar / keep-alive
            if line.startswith("data:"):
                v = line[5:]
                lines.append(v[1:] if v.startswith(" ") else v)
        return "\n".join(lines) if lines else None


class StreamAccumulator:
    """Sklada OpenAI chunky (choices[].delta) do vysledne zpravy asistenta."""

    def __init__(self):
        self.content = []
        self.reasoning = []
        self.tool_calls = {}
        self.usage = None
        self.finish = None

    def add_event(self, ev):
        """Zpracuje jeden JSON event; vraci (text_delta, reasoning_delta)."""
        if not isinstance(ev, dict):
            return "", ""
        if ev.get("error"):
            err = ev["error"]
            raise LuxError("model", 200, err.get("message") if isinstance(err, dict) else str(err))
        if ev.get("usage"):
            self.usage = ev["usage"]
        text, think = [], []
        for ch in ev.get("choices") or []:
            delta = ch.get("delta") or ch.get("message") or {}
            c = delta.get("content")
            if isinstance(c, str) and c:
                self.content.append(c)
                text.append(c)
            r = delta.get("reasoning_content") or delta.get("reasoning")
            if isinstance(r, str) and r:
                self.reasoning.append(r)
                think.append(r)
            for i, tc in enumerate(delta.get("tool_calls") or []):
                idx = tc.get("index", i)
                slot = self.tool_calls.setdefault(idx, {"id": "", "type": "function",
                                                        "function": {"name": "", "arguments": ""}})
                if tc.get("id"):
                    slot["id"] = tc["id"]
                fn = tc.get("function") or {}
                if fn.get("name"):
                    slot["function"]["name"] += fn["name"]
                if fn.get("arguments"):
                    a = fn["arguments"]
                    slot["function"]["arguments"] += a if isinstance(a, str) else json.dumps(a)
            if ch.get("finish_reason"):
                self.finish = ch["finish_reason"]
        return "".join(text), "".join(think)

    def message(self):
        msg = {"role": "assistant", "content": "".join(self.content) or None}
        if self.tool_calls:
            calls = []
            seen = set()
            for k in sorted(self.tool_calls):
                tc = self.tool_calls[k]
                if not tc["id"] or tc["id"] in seen:
                    # bez id (nebo zdvojene): jedinecne, aby se nepletlo s volanimi z drivejsich kroku
                    tc["id"] = "call_" + secrets.token_hex(8)
                seen.add(tc["id"])
                calls.append(tc)
            msg["tool_calls"] = calls
        return msg


# ---- HTTP klient --------------------------------------------------------------------
class LuxClient:
    def __init__(self, account=None, origin=None):
        self.account = account
        self.token = (account or {}).get("sessionToken", "")
        self.origin = safe_origin(origin) if origin else account_origin(account)
        self.user = (account or {}).get("user")
        self._conn = None
        self._lock = threading.Lock()
        self._aborted = False

    def __repr__(self):  # token nikdy nezobrazovat
        return f"<LuxClient origin={self.origin} signed_in={bool(self.token)}>"

    @property
    def signed_in(self):
        return bool(self.token)

    def _connection(self, timeout):
        u = urlsplit(self.origin)
        if u.scheme == "https":
            return http.client.HTTPSConnection(u.hostname, u.port or 443, timeout=timeout,
                                               context=ssl.create_default_context())
        return http.client.HTTPConnection(u.hostname, u.port or 80, timeout=timeout)

    def _headers(self, stream, has_body):
        h = {"X-Lux-Client": CLIENT, "User-Agent": f"luxai/{__version__}",
             "Accept": "text/event-stream, application/json" if stream else "application/json"}
        if has_body:
            h["Content-Type"] = "application/json"
        if self.token:
            h["Cookie"] = f"{COOKIE}={self.token}"
        return h

    def _open(self, method, path, body=None, timeout=30, stream=False):
        if not self.token:
            raise LuxError("auth", 401)
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        conn = self._connection(timeout)
        with self._lock:
            self._conn = conn
            self._aborted = False
        try:
            conn.request(method, path, body=data, headers=self._headers(stream, data is not None))
            resp = conn.getresponse()
        except (socket.timeout, TimeoutError):
            conn.close()
            raise LuxError("timeout") from None
        except (OSError, http.client.HTTPException) as e:
            conn.close()
            if self._aborted:
                raise LuxError("cancelled") from None
            raise LuxError("network", 0, type(e).__name__ + ": " + str(e)[:200]) from None
        if resp.status >= 400:
            raw = resp.read(65536).decode("utf-8", "replace")
            conn.close()
            raise error_from_response(resp.status, raw)
        return conn, resp

    def abort(self):
        """Prerusi bezici pozadavek (volatelne z jineho vlakna, napr. tlacitko Stop)."""
        with self._lock:
            self._aborted = True
            conn = self._conn
        if conn is not None and conn.sock is not None:
            try:
                conn.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

    def request_json(self, method, path, body=None, timeout=20):
        conn, resp = self._open(method, path, body, timeout)
        try:
            raw = resp.read().decode("utf-8", "replace")
        finally:
            conn.close()
        if not raw.strip():
            return {}
        try:
            return json.loads(raw)
        except ValueError:
            if _looks_like_html(raw):
                raise LuxError("html_response", resp.status) from None
            raise LuxError("bad_response", resp.status) from None

    def me(self):
        """{"user": {..., "usage": {...}}}; pri neplatne session LuxError s is_auth."""
        r = self.request_json("GET", ME_PATH, timeout=15)
        user = r.get("user") if isinstance(r, dict) else None
        if not user:
            raise LuxError("auth", 401)
        self.user = user
        return r

    def chat_stream(self, body, on_delta=None, should_stop=lambda: False, timeout=300):
        """Streamovane chat completions. on_delta(text, reasoning) se vola z volajiciho vlakna.
        Vraci (assistant_message, finish_reason, usage). Pri preruseni vraci dosavadni cast
        a finish_reason "cancelled"."""
        body = dict(body, stream=True)
        conn, resp = self._open("POST", CHAT_PATH, body, timeout=timeout, stream=True)
        acc = StreamAccumulator()
        ctype = (resp.getheader("Content-Type") or "").lower()
        try:
            if "text/event-stream" not in ctype:
                raw = resp.read().decode("utf-8", "replace")
                if "text/html" in ctype or _looks_like_html(raw):
                    raise LuxError("html_response", resp.status)
                try:
                    ev = json.loads(raw)
                except ValueError:
                    raise LuxError("bad_response", resp.status) from None
                t, r = acc.add_event(ev)
                if on_delta and (t or r):
                    on_delta(t, r)
                return acc.message(), acc.finish, acc.usage
            parser = SSEParser()
            while not parser.done:
                if should_stop() or self._aborted:
                    acc.finish = "cancelled"
                    break
                try:
                    chunk = resp.read1(8192) if hasattr(resp, "read1") else resp.read(8192)
                except (OSError, http.client.HTTPException, ValueError) as e:
                    if should_stop() or self._aborted:
                        acc.finish = "cancelled"
                        break
                    if isinstance(e, (socket.timeout, TimeoutError)):
                        raise LuxError("timeout") from None
                    raise LuxError("network", 0, type(e).__name__) from None
                datas = parser.feed(chunk) if chunk else parser.flush()
                for data in datas:
                    try:
                        ev = json.loads(data)
                    except ValueError:
                        continue
                    t, r = acc.add_event(ev)
                    if on_delta and (t or r):
                        on_delta(t, r)
                if not chunk:
                    break
        finally:
            with self._lock:
                self._conn = None
            conn.close()
        return acc.message(), acc.finish, acc.usage


def usage_for(user, model):
    """(pouzito, limit, neomezeno) pro model z /api/me."""
    usage = (user or {}).get("usage") or {}
    if model == "flash":
        used, limit = usage.get("fastTokens", 0), usage.get("fastLimit", 0)
    else:
        used, limit = usage.get("liteTokens", 0), usage.get("liteLimit", 0)
    try:
        used, limit = int(used or 0), int(limit or 0)
    except (TypeError, ValueError):
        used, limit = 0, 0
    return used, limit, bool(usage.get("unlimited"))
