"""Ulozeni konverzaci (~/.local/share/luxai/conversations/*.json) a nastaveni
(~/.config/luxai/luxai-app.json). Zapis je atomicky (docasny soubor + rename),
soubory 0600, adresare 0700. Obrazky (base64) se do historie neukladaji.
"""
import json
import os
import re
import secrets
import tempfile
import time

SETTINGS_DEFAULTS = {
    "model": "flash",
    "mode": "chat",
    "vision": {"flash": False, "lite": False},
    "workdir": "",
    "timeout": 120,
    "window": [1100, 760],
    "sidebar": 260,
}


def data_dir():
    base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    return os.path.join(base, "luxai")


def config_dir():
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, "luxai")


def atomic_write_json(path, data):
    d = os.path.dirname(path)
    os.makedirs(d, mode=0o700, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".tmp-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def strip_images(messages):
    """Kopie zprav bez obrazku (data URL) a bez docasnych zprav se snimky obrazovky."""
    out = []
    for m in messages:
        if m.get("_transient"):
            continue
        c = m.get("content")
        if isinstance(c, list):
            parts = []
            for p in c:
                if isinstance(p, dict) and p.get("type") == "image_url":
                    parts.append({"type": "text", "text": "[image omitted]"})
                else:
                    parts.append(p)
            m = dict(m, content=parts)
        out.append(m)
    return out


def title_from(text, limit=48):
    t = " ".join(str(text or "").split())
    t = re.sub(r"[#*`_>\[\]]", "", t).strip()
    if not t:
        return ""
    return t if len(t) <= limit else t[:limit - 1].rstrip() + "…"


class Conversation:
    def __init__(self, cid=None, title="", mode="chat", model="flash", messages=None, created=None, updated=None):
        self.id = cid or time.strftime("%Y%m%d-%H%M%S-") + secrets.token_hex(3)
        self.title = title
        self.mode = mode
        self.model = model
        self.messages = messages or []
        self.created = created or time.time()
        self.updated = updated or self.created

    def to_dict(self):
        return {"version": 1, "id": self.id, "title": self.title, "mode": self.mode, "model": self.model,
                "created": self.created, "updated": self.updated, "messages": strip_images(self.messages)}

    @classmethod
    def from_dict(cls, d):
        msgs = d.get("messages")
        if not isinstance(msgs, list):
            msgs = []
        msgs = [m for m in msgs if isinstance(m, dict) and m.get("role") in ("user", "assistant", "tool", "system")]
        return cls(str(d.get("id")), str(d.get("title") or ""), d.get("mode") if d.get("mode") in ("chat", "agent")
                   else "chat", str(d.get("model") or "flash"), msgs, d.get("created"), d.get("updated"))

    @property
    def empty(self):
        return not any(m.get("role") == "user" for m in self.messages)

    def display_title(self):
        if self.title:
            return self.title
        for m in self.messages:
            if m.get("role") == "user" and isinstance(m.get("content"), str):
                return title_from(m["content"])
        return ""


_ID = re.compile(r"^[A-Za-z0-9_-]{1,80}$")


class Store:
    def __init__(self, root=None):
        self.root = root or os.path.join(data_dir(), "conversations")

    def _path(self, cid):
        if not _ID.match(str(cid)):
            raise ValueError("invalid conversation id")
        return os.path.join(self.root, f"{cid}.json")

    def save(self, conv):
        if conv.empty:
            return False
        conv.updated = time.time()
        if not conv.title:
            conv.title = conv.display_title()
        atomic_write_json(self._path(conv.id), conv.to_dict())
        return True

    def load(self, cid):
        with open(self._path(cid), encoding="utf-8") as f:
            return Conversation.from_dict(json.load(f))

    def delete(self, cid):
        try:
            os.unlink(self._path(cid))
            return True
        except OSError:
            return False

    def list(self):
        """Metadata konverzaci od nejnovejsi: [{id, title, mode, model, updated}]."""
        res = []
        try:
            names = os.listdir(self.root)
        except OSError:
            return res
        for n in names:
            if not n.endswith(".json") or not _ID.match(n[:-5]):
                continue
            try:
                with open(os.path.join(self.root, n), encoding="utf-8") as f:
                    d = json.load(f)
                c = Conversation.from_dict(d)
            except (OSError, ValueError, AttributeError):
                continue
            res.append({"id": c.id, "title": c.display_title() or "…", "mode": c.mode, "model": c.model,
                        "updated": c.updated or 0})
        res.sort(key=lambda x: x["updated"], reverse=True)
        return res


class Settings:
    def __init__(self, path=None):
        self.path = path or os.path.join(config_dir(), "luxai-app.json")
        self.data = json.loads(json.dumps(SETTINGS_DEFAULTS))
        try:
            with open(self.path, encoding="utf-8") as f:
                stored = json.load(f)
            if isinstance(stored, dict):
                for k, v in stored.items():
                    if k in SETTINGS_DEFAULTS and type(v) is type(SETTINGS_DEFAULTS[k]):
                        self.data[k] = v
        except (OSError, ValueError):
            pass
        if self.data["model"] not in ("flash", "lite"):
            self.data["model"] = "flash"
        if self.data["mode"] not in ("chat", "agent"):
            self.data["mode"] = "chat"

    def __getitem__(self, k):
        return self.data[k]

    def __setitem__(self, k, v):
        self.data[k] = v

    def get(self, k, default=None):
        return self.data.get(k, default)

    def save(self):
        try:
            atomic_write_json(self.path, self.data)
        except OSError:
            pass
