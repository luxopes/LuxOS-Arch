"""Ulozeni konverzaci (~/.local/share/luxai/conversations/*.json) a nastaveni
(~/.config/luxai/settings.json; starsi ~/.config/luxai/luxai-app.json se pri prvnim
spusteni prevezme). Zapis je atomicky (docasny soubor + rename), soubory 0600, adresare 0700.
Obrazky (base64) se do historie neukladaji.
"""
import json
import os
import re
import secrets
import tempfile
import time

from .safety import normalize_policy

SETTINGS_DEFAULTS = {
    "version": 1,
    "model": "flash",
    "mode": "chat",
    "vision": {"flash": True, "lite": False},      # Flash (GLM Flash) obrazky vidi, Lite ne
    "vision_v2": True,
    "workdir": "",
    "timeout": 120,
    "window": [1100, 760],
    "sidebar": 260,
    # chovani AI
    "style": "balanced",
    "answer_length": "normal",
    "language": "auto",
    "instructions": "",
    "temperature_custom": False,
    "temperature": 0.7,
    "auto_title": True,
    # soukromi, obecne
    "keep_history": True,
    "send_key": "enter",
    "notify": True,
    "theme": "system",
    # opravneni agenta (viz safety.POLICY_DEFAULTS)
    "agent": {},
}
STYLES = ("balanced", "concise", "detailed", "technical", "friendly")
ANSWER_LENGTHS = {"short": 1500, "normal": 4096, "long": 8192}
LANGUAGES = ("auto", "cs", "sk", "en", "de", "pl", "fr", "es", "it", "uk")
CHOICES = {"model": ("flash", "lite"), "mode": ("chat", "agent"), "style": STYLES,
           "answer_length": tuple(ANSWER_LENGTHS), "language": LANGUAGES, "send_key": ("enter", "ctrl_enter"),
           "theme": ("system", "light", "dark")}
MAX_INSTRUCTIONS = 4000


def data_dir():
    base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    return os.path.join(base, "luxai")


def config_dir():
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, "luxai")


def atomic_write_json(path, data):
    d = os.path.dirname(path)
    os.makedirs(d, mode=0o700, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".tmp-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def strip_images(messages):
    """Kopie zprav bez obrazku (data URL) a bez docasnych zprav se snimky obrazovky."""
    out = []
    for m in messages:
        if m.get("_transient"):
            continue
        c = m.get("content")
        if isinstance(c, list):
            parts = []
            for p in c:
                if isinstance(p, dict) and p.get("type") == "image_url":
                    parts.append({"type": "text", "text": "[image omitted]"})
                else:
                    parts.append(p)
            m = dict(m, content=parts)
        out.append(m)
    return out


def title_from(text, limit=48):
    """Nazev z prvnich slov textu (zalozni nazev, kdyz se nazev nepodari vygenerovat)."""
    t = " ".join(str(text or "").split())
    t = re.sub(r"[#*`_>\[\]]", "", t).strip()
    if not t:
        return ""
    if len(t) <= limit:
        return t
    cut = t[:limit - 1]
    if " " in cut[limit // 2:]:
        cut = cut[:cut.rindex(" ")]
    return cut.rstrip(" ,.;:-") + "…"


class Conversation:
    def __init__(self, cid=None, title="", mode="chat", model="flash", messages=None, created=None, updated=None,
                 title_source="fallback"):
        self.id = cid or time.strftime("%Y%m%d-%H%M%S-") + secrets.token_hex(3)
        self.title = title
        # odkud je nazev: "fallback" (prvni slova), "model" (vygenerovany), "manual" (prejmenovano uzivatelem)
        self.title_source = title_source if title_source in ("fallback", "model", "manual") else "fallback"
        self.mode = mode
        self.model = model
        self.messages = messages or []
        self.created = created or time.time()
        self.updated = updated or self.created

    def to_dict(self):
        return {"version": 1, "id": self.id, "title": self.title, "title_source": self.title_source,
                "mode": self.mode, "model": self.model,
                "created": self.created, "updated": self.updated, "messages": strip_images(self.messages)}

    @classmethod
    def from_dict(cls, d):
        msgs = d.get("messages")
        if not isinstance(msgs, list):
            msgs = []
        msgs = [m for m in msgs if isinstance(m, dict) and m.get("role") in ("user", "assistant", "tool", "system")]
        conv = cls(str(d.get("id")), str(d.get("title") or ""), d.get("mode") if d.get("mode") in ("chat", "agent")
                   else "chat", str(d.get("model") or "flash"), msgs, d.get("created"), d.get("updated"),
                   d.get("title_source"))
        if d.get("title_source") not in ("fallback", "model", "manual"):
            # starsi soubory: nazev shodny s prvnimi slovy zpravy je zalozni, jiny nazev zadal uzivatel
            conv.title_source = "fallback" if not conv.title or conv.title == conv.fallback_title() else "manual"
        return conv

    @property
    def empty(self):
        return not any(m.get("role") == "user" for m in self.messages)

    def first_user_text(self):
        for m in self.messages:
            if m.get("role") == "user" and isinstance(m.get("content"), str):
                return m["content"]
        return ""

    def fallback_title(self):
        return title_from(self.first_user_text())

    def display_title(self):
        return self.title or self.fallback_title()


_ID = re.compile(r"^[A-Za-z0-9_-]{1,80}$")


class Store:
    def __init__(self, root=None):
        self.root = root or os.path.join(data_dir(), "conversations")

    def _path(self, cid):
        if not _ID.match(str(cid)):
            raise ValueError("invalid conversation id")
        return os.path.join(self.root, f"{cid}.json")

    def save(self, conv, touch=True):
        if conv.empty:
            return False
        if touch or not conv.updated:
            conv.updated = time.time()
        if not conv.title:
            conv.title = conv.display_title()
        atomic_write_json(self._path(conv.id), conv.to_dict())
        return True

    def load(self, cid):
        with open(self._path(cid), encoding="utf-8") as f:
            return Conversation.from_dict(json.load(f))

    def delete(self, cid):
        try:
            os.unlink(self._path(cid))
            return True
        except OSError:
            return False

    def clear(self):
        """Smaze celou historii konverzaci; vraci pocet smazanych souboru."""
        n = 0
        try:
            names = os.listdir(self.root)
        except OSError:
            return 0
        for name in names:
            if name.endswith(".json") and _ID.match(name[:-5]):
                try:
                    os.unlink(os.path.join(self.root, name))
                    n += 1
                except OSError:
                    pass
        return n

    def list(self):
        """Metadata konverzaci od nejnovejsi: [{id, title, mode, model, updated}]."""
        res = []
        try:
            names = os.listdir(self.root)
        except OSError:
            return res
        for n in names:
            if not n.endswith(".json") or not _ID.match(n[:-5]):
                continue
            try:
                with open(os.path.join(self.root, n), encoding="utf-8") as f:
                    d = json.load(f)
                c = Conversation.from_dict(d)
            except (OSError, ValueError, AttributeError):
                continue
            res.append({"id": c.id, "title": c.display_title() or "…", "mode": c.mode, "model": c.model,
                        "updated": c.updated or 0})
        res.sort(key=lambda x: x["updated"], reverse=True)
        return res


def _valid(key, value, default):
    if isinstance(default, bool):
        return isinstance(value, bool)
    if isinstance(default, float):
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if type(value) is not type(default):
        return False
    if key in CHOICES:
        return value in CHOICES[key]
    return True


class Settings:
    """Nastaveni aplikace v ~/.config/luxai/settings.json (neplatne hodnoty -> vychozi)."""

    def __init__(self, path=None):
        self.path = path or os.path.join(config_dir(), "settings.json")
        self.data = json.loads(json.dumps(SETTINGS_DEFAULTS))
        stored = self._read(self.path)
        if stored is None and path is None:
            stored = self._read(os.path.join(config_dir(), "luxai-app.json"))  # prevzeti z verze 1.0
        for k, v in (stored or {}).items():
            if k in SETTINGS_DEFAULTS and k != "version" and _valid(k, v, SETTINGS_DEFAULTS[k]):
                self.data[k] = v
        self.data["agent"] = normalize_policy(self.data.get("agent"))
        self.data["temperature"] = min(1.5, max(0.0, float(self.data["temperature"])))
        self.data["instructions"] = self.data["instructions"][:MAX_INSTRUCTIONS]
        self.data["timeout"] = min(1800, max(10, int(self.data["timeout"])))
        vis = self.data["vision"]
        self.data["vision"] = {m: bool(vis.get(m)) for m in ("flash", "lite")}
        # Starsi nastaveni melo obrazky u Flash vypnute - jednou zapnout (pak plati volba uzivatele)
        if stored and "vision_v2" not in stored:
            self.data["vision"]["flash"] = True
            self.data["vision_v2"] = True

    @staticmethod
    def _read(path):
        try:
            with open(path, encoding="utf-8") as f:
                stored = json.load(f)
        except (OSError, ValueError):
            return None
        return stored if isinstance(stored, dict) else None

    def __getitem__(self, k):
        return self.data[k]

    def __setitem__(self, k, v):
        self.data[k] = v

    def get(self, k, default=None):
        return self.data.get(k, default)

    def max_tokens(self):
        return ANSWER_LENGTHS.get(self.data["answer_length"], 4096)

    def save(self):
        self.data["agent"] = normalize_policy(self.data.get("agent"))
        try:
            atomic_write_json(self.path, self.data)
        except OSError:
            pass
