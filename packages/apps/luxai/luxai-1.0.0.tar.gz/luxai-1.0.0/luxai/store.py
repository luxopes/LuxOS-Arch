"""Ulozeni konverzaci (~/.local/share/luxai/conversations/*.json) a nastaveni
(~/.config/luxai/settings.json; starsi ~/.config/luxai/luxai-app.json se pri prvnim
spusteni prevezme). Zapis je atomicky (docasny soubor + rename), soubory 0600, adresare 0700.
Obrazky z konverzace (prilohy a snimky obrazovky agenta) se ukladaji jako samostatne soubory
~/.local/share/luxai/images/<id konverzace>/<hash>.<jpg|png|...>; v JSON je misto data URL jen odkaz
"luxai-image:<soubor>". Pri nacteni se odkazy zase nahradi data URL (chybejici soubor -> kratky text).
"""
import base64
import hashlib
import json
import os
import re
import secrets
import shutil
import tempfile
import time

from .safety import normalize_policy

SETTINGS_DEFAULTS = {
    "version": 1,
    "model": "flash",
    "mode": "chat",
    "vision": {"flash": True, "lite": False},      # Flash (GLM Flash) obrazky vidi, Lite ne
    "vision_v2": True,
    "workdir": "",
    "timeout": 120,
    "window": [1100, 760],
    "sidebar": 260,
    # chovani AI
    "style": "balanced",
    "answer_length": "normal",
    "language": "auto",
    "instructions": "",
    "temperature_custom": False,
    "temperature": 0.7,
    "auto_title": True,
    # soukromi, obecne
    "keep_history": True,
    "send_key": "enter",
    "notify": True,
    "theme": "system",
    # opravneni agenta (viz safety.POLICY_DEFAULTS)
    "agent": {},
}
STYLES = ("balanced", "concise", "detailed", "technical", "friendly")
ANSWER_LENGTHS = {"short": 1500, "normal": 4096, "long": 8192}
LANGUAGES = ("auto", "cs", "sk", "en", "de", "pl", "fr", "es", "it", "uk")
CHOICES = {"model": ("flash", "lite"), "mode": ("chat", "agent"), "style": STYLES,
           "answer_length": tuple(ANSWER_LENGTHS), "language": LANGUAGES, "send_key": ("enter", "ctrl_enter"),
           "theme": ("system", "light", "dark")}
MAX_INSTRUCTIONS = 4000


def data_dir():
    base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    return os.path.join(base, "luxai")


def config_dir():
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, "luxai")


def atomic_write_json(path, data):
    d = os.path.dirname(path)
    os.makedirs(d, mode=0o700, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".tmp-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def strip_images(messages):
    """Kopie zprav bez obrazku (data URL) a bez docasnych zprav se snimky obrazovky."""
    out = []
    for m in messages:
        if m.get("_transient"):
            continue
        c = m.get("content")
        if isinstance(c, list):
            parts = []
            for p in c:
                if isinstance(p, dict) and p.get("type") == "image_url":
                    parts.append({"type": "text", "text": "[image omitted]"})
                else:
                    parts.append(p)
            m = dict(m, content=parts)
        out.append(m)
    return out


INTERRUPTED = {"ok": False, "interrupted": True,
               "error": "Interrupted: LuxAI was closed or the conversation was switched before this action "
                        "finished. Check the current state before trying again."}
IMAGE_REF = "luxai-image:"
IMAGE_MISSING = "[image no longer available]"
_IMAGE_TYPES = {"image/jpeg": "jpg", "image/png": "png", "image/gif": "gif", "image/webp": "webp"}
_IMAGE_NAME = re.compile(r"^[0-9a-f]{8,64}\.(jpg|png|gif|webp)$")


def _image_url(part):
    v = part.get("image_url")
    return v.get("url", "") if isinstance(v, dict) else str(v or "")


def _write_private(path, data):
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), prefix=".tmp-")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def externalize_images(messages, folder):
    """Kopie zprav, v nichz jsou obrazky (data URL) ulozene do souboru ve `folder` a nahrazene odkazem.
    Soubory, na ktere uz zadna zprava neodkazuje, se smazou. Docasne zpravy se vynechaji."""
    out, keep = [], set()
    for m in messages:
        if m.get("_transient"):
            continue
        c = m.get("content")
        if isinstance(c, list):
            parts = []
            for p in c:
                if isinstance(p, dict) and p.get("type") == "image_url":
                    url = _image_url(p)
                    name = None
                    if url.startswith(IMAGE_REF) and _IMAGE_NAME.match(url[len(IMAGE_REF):]):
                        name = url[len(IMAGE_REF):]
                    else:
                        head, _sep, data = url.partition(",")
                        mime = head[5:].split(";")[0] if head.startswith("data:") else ""
                        if mime in _IMAGE_TYPES and head.endswith(";base64"):
                            try:
                                raw = base64.b64decode(data, validate=True)
                            except ValueError:
                                raw = b""
                            if raw:
                                name = hashlib.sha256(raw).hexdigest()[:32] + "." + _IMAGE_TYPES[mime]
                                path = os.path.join(folder, name)
                                if not os.path.exists(path):
                                    os.makedirs(folder, mode=0o700, exist_ok=True)
                                    _write_private(path, raw)
                    if name:
                        keep.add(name)
                        parts.append({"type": "image_url", "image_url": {"url": IMAGE_REF + name}})
                    else:
                        parts.append({"type": "text", "text": "[image omitted]"})
                else:
                    parts.append(p)
            m = dict(m, content=parts)
        out.append(m)
    try:
        names = os.listdir(folder)
    except OSError:
        names = []
    for n in names:
        if _IMAGE_NAME.match(n) and n not in keep:
            try:
                os.unlink(os.path.join(folder, n))
            except OSError:
                pass
    return out


def internalize_images(messages, folder):
    """Odkazy "luxai-image:" ve zpravach nahradi data URL ze souboru (na miste, vraci messages)."""
    mimes = {v: k for k, v in _IMAGE_TYPES.items()}
    for m in messages:
        c = m.get("content")
        if not isinstance(c, list):
            continue
        for i, p in enumerate(c):
            if not (isinstance(p, dict) and p.get("type") == "image_url"):
                continue
            url = _image_url(p)
            if url.startswith("data:image/"):
                continue
            name = url[len(IMAGE_REF):] if url.startswith(IMAGE_REF) else ""
            data = None
            if _IMAGE_NAME.match(name):
                try:
                    with open(os.path.join(folder, name), "rb") as f:
                        data = f.read()
                except OSError:
                    data = None
            if data:
                mime = mimes[name.rsplit(".", 1)[1]]
                c[i] = {"type": "image_url", "image_url": {"url": f"data:{mime};base64," +
                                                           base64.b64encode(data).decode()}}
            else:
                c[i] = {"type": "text", "text": IMAGE_MISSING}
    return messages


def message_text(m):
    """Text, ktery napsal uzivatel (u zpravy s prilohami bez obsahu priloh)."""
    if isinstance(m.get("_text"), str):
        return m["_text"]
    c = m.get("content")
    if isinstance(c, str):
        return c
    if isinstance(c, list):
        return "\n".join(p.get("text", "") for p in c if isinstance(p, dict) and p.get("type") == "text")
    return ""


def title_from(text, limit=48):
    """Nazev z prvnich slov textu (zalozni nazev, kdyz se nazev nepodari vygenerovat)."""
    t = " ".join(str(text or "").split())
    t = re.sub(r"[#*`_>\[\]]", "", t).strip()
    if not t:
        return ""
    if len(t) <= limit:
        return t
    cut = t[:limit - 1]
    if " " in cut[limit // 2:]:
        cut = cut[:cut.rindex(" ")]
    return cut.rstrip(" ,.;:-") + "…"


class Conversation:
    def __init__(self, cid=None, title="", mode="chat", model="flash", messages=None, created=None, updated=None,
                 title_source="fallback"):
        self.id = cid or time.strftime("%Y%m%d-%H%M%S-") + secrets.token_hex(3)
        self.title = title
        # odkud je nazev: "fallback" (prvni slova), "model" (vygenerovany), "manual" (prejmenovano uzivatelem)
        self.title_source = title_source if title_source in ("fallback", "model", "manual") else "fallback"
        self.mode = mode
        self.model = model
        self.messages = messages or []
        self.created = created or time.time()
        self.updated = updated or self.created

    def to_dict(self, image_dir=None):
        """Slovnik pro ulozeni; s image_dir se obrazky ulozi do souboru, jinak se vynechaji."""
        from .agent import repair_tool_sequence  # noqa: PLC0415 (agent importuje az pri ulozeni)
        msgs = externalize_images(self.messages, image_dir) if image_dir else strip_images(self.messages)
        # Ulozeni behem bezici akce (prepnuti konverzace, zavreni okna): volani bez vysledku dostane
        # nahradni vysledek, aby ulozena historie byla vzdy platna (jinak invalid_tool_sequence).
        msgs, _notes = repair_tool_sequence(msgs, missing=INTERRUPTED)
        return {"version": 1, "id": self.id, "title": self.title, "title_source": self.title_source,
                "mode": self.mode, "model": self.model,
                "created": self.created, "updated": self.updated, "messages": msgs}

    @classmethod
    def from_dict(cls, d):
        msgs = d.get("messages")
        if not isinstance(msgs, list):
            msgs = []
        msgs = [m for m in msgs if isinstance(m, dict) and m.get("role") in ("user", "assistant", "tool", "system")]
        conv = cls(str(d.get("id")), str(d.get("title") or ""), d.get("mode") if d.get("mode") in ("chat", "agent")
                   else "chat", str(d.get("model") or "flash"), msgs, d.get("created"), d.get("updated"),
                   d.get("title_source"))
        if d.get("title_source") not in ("fallback", "model", "manual"):
            # starsi soubory: nazev shodny s prvnimi slovy zpravy je zalozni, jiny nazev zadal uzivatel
            conv.title_source = "fallback" if not conv.title or conv.title == conv.fallback_title() else "manual"
        return conv

    @property
    def empty(self):
        return not any(m.get("role") == "user" for m in self.messages)

    def first_user_text(self):
        for m in self.messages:
            if m.get("role") == "user" and not m.get("_screenshot") and not m.get("_transient"):
                text = message_text(m)
                if text.strip():
                    return text
        return ""

    def fallback_title(self):
        return title_from(self.first_user_text())

    def display_title(self):
        return self.title or self.fallback_title()


_ID = re.compile(r"^[A-Za-z0-9_-]{1,80}$")


class Store:
    def __init__(self, root=None):
        self.root = root or os.path.join(data_dir(), "conversations")
        self.images_root = os.path.join(os.path.dirname(self.root.rstrip("/")) or ".", "images")

    def _path(self, cid):
        if not _ID.match(str(cid)):
            raise ValueError("invalid conversation id")
        return os.path.join(self.root, f"{cid}.json")

    def image_dir(self, cid):
        if not _ID.match(str(cid)):
            raise ValueError("invalid conversation id")
        return os.path.join(self.images_root, cid)

    def save(self, conv, touch=True):
        if conv.empty:
            return False
        if touch or not conv.updated:
            conv.updated = time.time()
        if not conv.title:
            conv.title = conv.display_title()
        os.makedirs(self.images_root, mode=0o700, exist_ok=True)
        atomic_write_json(self._path(conv.id), conv.to_dict(self.image_dir(conv.id)))
        return True

    def load(self, cid):
        with open(self._path(cid), encoding="utf-8") as f:
            conv = Conversation.from_dict(json.load(f))
        internalize_images(conv.messages, self.image_dir(cid))
        return conv

    def delete(self, cid):
        try:
            shutil.rmtree(self.image_dir(cid))
        except OSError:
            pass
        try:
            os.unlink(self._path(cid))
            return True
        except OSError:
            return False

    def clear(self):
        """Smaze celou historii konverzaci; vraci pocet smazanych souboru."""
        n = 0
        try:
            shutil.rmtree(self.images_root)
        except OSError:
            pass
        try:
            names = os.listdir(self.root)
        except OSError:
            return 0
        for name in names:
            if name.endswith(".json") and _ID.match(name[:-5]):
                try:
                    os.unlink(os.path.join(self.root, name))
                    n += 1
                except OSError:
                    pass
        return n

    def list(self):
        """Metadata konverzaci od nejnovejsi: [{id, title, mode, model, updated}]."""
        res = []
        try:
            names = os.listdir(self.root)
        except OSError:
            return res
        for n in names:
            if not n.endswith(".json") or not _ID.match(n[:-5]):
                continue
            try:
                with open(os.path.join(self.root, n), encoding="utf-8") as f:
                    d = json.load(f)
                c = Conversation.from_dict(d)
            except (OSError, ValueError, AttributeError):
                continue
            res.append({"id": c.id, "title": c.display_title() or "…", "mode": c.mode, "model": c.model,
                        "updated": c.updated or 0})
        res.sort(key=lambda x: x["updated"], reverse=True)
        return res


def _valid(key, value, default):
    if isinstance(default, bool):
        return isinstance(value, bool)
    if isinstance(default, float):
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if type(value) is not type(default):
        return False
    if key in CHOICES:
        return value in CHOICES[key]
    return True


class Settings:
    """Nastaveni aplikace v ~/.config/luxai/settings.json (neplatne hodnoty -> vychozi)."""

    def __init__(self, path=None):
        self.path = path or os.path.join(config_dir(), "settings.json")
        self.data = json.loads(json.dumps(SETTINGS_DEFAULTS))
        stored = self._read(self.path)
        if stored is None and path is None:
            stored = self._read(os.path.join(config_dir(), "luxai-app.json"))  # prevzeti z verze 1.0
        for k, v in (stored or {}).items():
            if k in SETTINGS_DEFAULTS and k != "version" and _valid(k, v, SETTINGS_DEFAULTS[k]):
                self.data[k] = v
        self.data["agent"] = normalize_policy(self.data.get("agent"))
        self.data["temperature"] = min(1.5, max(0.0, float(self.data["temperature"])))
        self.data["instructions"] = self.data["instructions"][:MAX_INSTRUCTIONS]
        self.data["timeout"] = min(1800, max(10, int(self.data["timeout"])))
        vis = self.data["vision"]
        self.data["vision"] = {m: bool(vis.get(m)) for m in ("flash", "lite")}
        # Starsi nastaveni melo obrazky u Flash vypnute - jednou zapnout (pak plati volba uzivatele)
        if stored and "vision_v2" not in stored:
            self.data["vision"]["flash"] = True
            self.data["vision_v2"] = True

    @staticmethod
    def _read(path):
        try:
            with open(path, encoding="utf-8") as f:
                stored = json.load(f)
        except (OSError, ValueError):
            return None
        return stored if isinstance(stored, dict) else None

    def __getitem__(self, k):
        return self.data[k]

    def __setitem__(self, k, v):
        self.data[k] = v

    def get(self, k, default=None):
        return self.data.get(k, default)

    def max_tokens(self):
        return ANSWER_LENGTHS.get(self.data["answer_length"], 4096)

    def save(self):
        self.data["agent"] = normalize_policy(self.data.get("agent"))
        try:
            atomic_write_json(self.path, self.data)
        except OSError:
            pass
