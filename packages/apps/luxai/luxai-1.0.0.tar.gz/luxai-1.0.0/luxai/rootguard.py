"""Tvrde bezpecnostni bloky prikazu a spolecne konstanty rezimu spravce LuxAI.

Modul pouziva aplikace (safety.command_assessment) i pomocnik /usr/lib/luxai/luxai-root, ktery bezi
jako root a pred spustenim prikaz zkontroluje znovu (obrana do hloubky). Proto je zamerne jen se
standardni knihovnou a bez relativnich importu: pomocnik ho nacita primo ze souboru
/usr/lib/luxai/luxai/rootguard.py (stejna pravidla v aplikaci i v pomocnikovi).

hard_block(command, root=..., cwd=..., home=...) vraci duvod odmitnuti (anglicky, UI ho prelozi),
nebo None. Bloky plati vzdy - pro kazdy model a pri jakemkoli nastaveni:
  - rm -rf /, systemovych slozek a domovske slozky (i /*, ~/*, --no-preserve-root, find / -delete),
  - mkfs, wipefs, dd, shred, blkdiscard, zapis na /dev/sd*, nvme*, mmcblk* ..., zapis do tabulky oddilu,
  - fork bomby, chmod/chown -R na / nebo systemove slozky,
  - odstraneni zavadece, EFI oddilu, jader a zakladnich balicku,
  - vypnuti kontroly podpisu balicku (SigLevel = Never / TrustAll, --skippgpcheck),
  - zmeny uctu (userdel, passwd, chpasswd, usermod ...), uprava sudoers, polkit a PAM,
  - zmena rezimu spravce LuxAI samotneho (49-luxai-root.rules, /usr/lib/luxai, ~/.config/luxai),
  - predani hesla do sudo/su.
S root=True (prikaz pobezi jako root) navic: skript stazeny z internetu (curl | sh), kod generovany
za behu (| sh, eval $(...), base64 ... | bash) a nejiste cile (promenne, $(...), neznama pracovni
slozka) u destruktivnich prikazu - kdyz si kontrola neni jista, prikaz odmitne.
"""
import fnmatch
import os
import re
import shlex

# ---- rezim spravce: polkit, pomocnici ---------------------------------------------------------
ACTION_ROOT = "org.luxai.root"            # vzdy heslo spravce (auth_admin)
ACTION_AUTO = "org.luxai.root-auto"       # bez hesla jen s pravidlem 49-luxai-root.rules
ACTION_SETUP = "org.luxai.root-setup"     # zapnuti/vypnuti pravidla (auth_admin)
LIB_DIR = "/usr/lib/luxai"
HELPER = LIB_DIR + "/luxai-root"
HELPER_AUTO = LIB_DIR + "/luxai-root-auto"
SETUP_HELPER = LIB_DIR + "/luxai-root-setup"
RULES_DIR = "/etc/polkit-1/rules.d"
RULE_MARK = "// LuxAI administrator mode"
MAX_TIMEOUT = 1800
MAX_COMMAND = 65536
EXIT_REFUSED = 125
EXIT_TIMEOUT = 124
EXIT_CANCELLED = 130
# PATH prikazu spustenych jako root (jadro lux - pacman, pacman-key ... - je mimo /usr/bin)
ROOT_PATH = "/usr/lib/lux/alpm/bin:/usr/local/sbin:/usr/local/bin:/usr/bin"
_USER_RE = re.compile(r"^[a-z_][a-z0-9_-]{0,31}$")


def valid_user(name):
    """Jmeno uzivatele bezpecne pro pravidlo polkit (bez uvozovek, lomitek ...)."""
    return isinstance(name, str) and bool(_USER_RE.match(name)) and name != "root"


def rule_path(user):
    """Pravidlo polkit pro jednoho uzivatele (kazdy uzivatel si rezim zapina sam)."""
    if not valid_user(user):
        raise ValueError("invalid user name")
    return f"{RULES_DIR}/49-luxai-root-{user}.rules"


def rule_text(user):
    """Obsah /etc/polkit-1/rules.d/49-luxai-root-<user>.rules: akce org.luxai.root-auto (a vypnuti rezimu
    pres org.luxai.root-setup) bez hesla jen pro jednoho uzivatele a jen v mistni aktivni relaci; jinak
    polkit pouzije vychozi auth_admin."""
    if not valid_user(user):
        raise ValueError("invalid user name")
    return (
        RULE_MARK + " (written by " + SETUP_HELPER + ").\n"
        "// Turn it off in LuxAI > Settings > Agent permissions. Only " + ACTION_AUTO + " (the LuxAI root\n"
        "// helper, which refuses blocked commands itself) and " + ACTION_SETUP + " (turning this mode off)\n"
        "// are allowed without a password, only for this user and only in a local, active session;\n"
        "// everything else keeps the default (administrator password).\n"
        "polkit.addRule(function(action, subject) {\n"
        "    if ((action.id == \"" + ACTION_AUTO + "\" || action.id == \"" + ACTION_SETUP + "\") &&\n"
        "            subject.user == \"" + user + "\" && subject.local && subject.active) {\n"
        "        return polkit.Result.YES;\n"
        "    }\n"
        "});\n")


# ---- duvody (v UI prelozene) ----------------------------------------------------------------
R_DELETE = "deletes the whole system, a system folder or a home folder"
R_BOOT = "removes the bootloader, the EFI partition, kernels or core system packages"
R_DISK = "formats, wipes or writes directly to a disk"
R_FORK = "fork bomb"
R_PERMS = "changes owner or permissions of the whole system or a system folder"
R_SIGNATURES = "disables package signature checks"
R_ACCOUNTS = "changes user accounts or passwords"
R_AUTH = "changes sudo, polkit or PAM configuration"
R_SELF = "changes LuxAI administrator mode, settings or account"
R_KERNEL = "crashes or instantly reboots the kernel"
R_REMOTE = "runs a script downloaded from the internet as administrator"
R_DYNAMIC = "runs generated or hidden code as administrator, which cannot be checked"
R_UNSURE = "the target of a destructive command cannot be verified (variable, substitution or unknown folder)"
R_PASSWORD = "feeds a password to sudo or su (use pkexec instead)"
REASONS = (R_DELETE, R_BOOT, R_DISK, R_FORK, R_PERMS, R_SIGNATURES, R_ACCOUNTS, R_AUTH, R_SELF, R_KERNEL,
           R_REMOTE, R_DYNAMIC, R_UNSURE, R_PASSWORD)

# ---- predani hesla do sudo/su ----------------------------------------------------------------
# "echo heslo | sudo -S ...", "sudo -S ... <<< heslo", vlastni SUDO_ASKPASS, "... | su", sshpass -p.
# Volby sudo pred -S (napr. -u uzivatel, -k) se preskakuji, volby spousteneho programu se nepocitaji.
_SUDO_OPT = (r"(?:-[A-Za-z]*[ugpChDrtTU]\s+\S+|--(?:user|group|prompt|close-from|host|chdir|role|type|"
             r"command-timeout|other-user)(?:=\S+|\s+\S+)|-[A-Za-z]+|--[\w-]+(?:=\S+)?)")
_SUDO_STDIN = re.compile(r"(?:^|[^\w.-])(?:\S*/)?sudo(?:\s+" + _SUDO_OPT +
                         r")*?\s+(?:-[A-Za-z]*S[A-Za-z]*|--stdin)(?=$|[\s'\";|&)])")
_PASSWORD_FEED = (
    _SUDO_STDIN,
    re.compile(r"\bSUDO_ASKPASS\s*="),
    re.compile(r"\|\s*(?:\S*/)?su(?:\s|$)"),
    re.compile(r"\bsshpass\b"),
)


def feeds_password(command):
    """True, kdyz prikaz predava heslo programu sudo/su (pres -S, rouru, here-string, SUDO_ASKPASS ...)."""
    text = str(command or "")
    return any(r.search(text) for r in _PASSWORD_FEED)


# ---- chranene cesty ---------------------------------------------------------------------------
SYSTEM_DIRS = frozenset({
    "/", "/bin", "/boot", "/dev", "/efi", "/etc", "/home", "/lib", "/lib32", "/lib64", "/mnt", "/opt", "/proc",
    "/run", "/sbin", "/srv", "/sys", "/tmp", "/usr", "/var", "/media",
    "/usr/bin", "/usr/lib", "/usr/lib32", "/usr/lib64", "/usr/sbin", "/usr/share", "/usr/include", "/usr/local",
    "/usr/lib/modules", "/usr/lib/systemd", "/usr/lib/firmware", "/var/lib", "/var/lib/pacman", "/var/log",
    "/etc/pacman.d", "/etc/systemd", "/var/lib/systemd", "/boot/efi", "/boot/grub", "/boot/loader"})
# slozky, jejichz obsah lze mazat maskou (rm -rf /tmp/*) - ostatni systemove slozky ne
_GLOB_OK = frozenset({"/tmp", "/var/tmp"})
_BOOT = ("/boot", "/efi", "/usr/lib/modules")
_DEVICE = re.compile(r"^/dev/(sd[a-z]+\d*|hd[a-z]+\d*|vd[a-z]+\d*|xvd[a-z]+\d*|nvme\d+(n\d+(p\d+)?)?|"
                     r"mmcblk\d+(p\d+|boot\d+|rpmb)?|dm-\d+|md\d+|md/.+|mapper/.+|disk/.+|block/.+|sr\d+|"
                     r"loop\d+|root|zram\d+|nbd\d+(p\d+)?|ubi.*|mtd.*)$")
_DEVICE_TEXT = re.compile(r"/dev/(sd[a-z]|hd[a-z]|vd[a-z]|xvd[a-z]|nvme\d|mmcblk\d|dm-\d|md\d|mapper/|disk/|"
                          r"block/|root\b|nbd\d|mtd)")
# chranene soubory a slozky (zapis = blok; cteni povolene) -> duvod
_PROTECTED = (
    ("/etc/sudoers", R_AUTH), ("/etc/sudoers.d", R_AUTH), ("/etc/doas.conf", R_AUTH),
    ("/etc/polkit-1", R_AUTH), ("/usr/share/polkit-1", R_AUTH), ("/usr/lib/polkit-1", R_AUTH),
    ("/etc/pam.d", R_AUTH), ("/usr/lib/pam.d", R_AUTH), ("/etc/security", R_AUTH), ("/usr/lib/security", R_AUTH),
    ("/etc/passwd", R_ACCOUNTS), ("/etc/passwd-", R_ACCOUNTS), ("/etc/shadow", R_ACCOUNTS),
    ("/etc/shadow-", R_ACCOUNTS), ("/etc/group", R_ACCOUNTS), ("/etc/group-", R_ACCOUNTS),
    ("/etc/gshadow", R_ACCOUNTS), ("/etc/gshadow-", R_ACCOUNTS), ("/etc/subuid", R_ACCOUNTS),
    ("/etc/subgid", R_ACCOUNTS), ("/etc/login.defs", R_ACCOUNTS),
    (LIB_DIR, R_SELF),
)
# zminka v textu (i v kodu pythonu apod.) + zapisujici prikaz = blok
_PROTECTED_TEXT = (
    (re.compile(r"/etc/sudoers|/etc/doas\.conf|\bsudoers\b"), R_AUTH),
    (re.compile(r"polkit-1|\.rules\b.*polkit|polkit.*\.rules\b"), R_AUTH),
    (re.compile(r"/pam\.d\b|/etc/security/|/lib/security/|\bpam_\w+\.so\b"), R_AUTH),
    (re.compile(r"/etc/(passwd|shadow|group|gshadow|subuid|subgid|login\.defs)\b"), R_ACCOUNTS),
    (re.compile(r"luxai-root|49-luxai|org\.luxai|/usr/lib/luxai\b"), R_SELF),
)
_SELF_ROOT = re.compile(r"\.config/luxai\b|luxai/(account|settings)\.json")
_SIGLEVEL = re.compile(r"siglevel\s*=?\s*[^\n;|&]*\b(never|trustall)\b|--skip(pgpcheck|checksums|integ)\b|"
                       r"--nosig\b|pacman\.conf\b.*\b(never|trustall)\b|\b(never|trustall)\b.*pacman\.conf\b")
_FORK = (re.compile(r"(?:^|[\s;&|({])([^\s;&|(){}=]+)\s*\(\s*\)\s*\{[^}]*?(?<![\w.:-])\1\s*\|\s*&?\s*\1"),
         re.compile(r"\bfunction\s+([\w:.-]+)\s*(?:\(\s*\))?\s*\{[^}]*?(?<![\w.:-])\1\s*\|\s*\1"),
         re.compile(r"\bfork\s*(?:\(\s*\))?\s*while\s+fork\b|\bwhile\s*\(?\s*(?:1|true|True)\s*\)?\s*[:;{]?\s*"
                    r"(?:os\.)?fork\s*\(\)"))
_REDIRECT_DEV = re.compile(r"(?:>|>>|>\||&>|<>)\s*" + _DEVICE_TEXT.pattern)
_SYSRQ = re.compile(r"sysrq-trigger")
_REMOTE = (re.compile(r"\b(curl|wget|fetch|aria2c|xh|https?)\b[^|;&]*\|\s*(?:\S*/)?(?:env\s+(?:-\S+\s+)*)?"
                      r"(?:(?:sudo|doas|pkexec)\s+(?:-\S+\s+)*)?(?:ba|z|da|k|fi|c|tc)?sh\b"),
           re.compile(r"\b(curl|wget|fetch|aria2c)\b[^|;&]*\|\s*(?:\S*/)?(python\d*|perl|ruby|node|php)\b"),
           re.compile(r"\$\(\s*(curl|wget|fetch)\b|<\(\s*(curl|wget|fetch)\b|`\s*(curl|wget|fetch)\b"))
_PIPE_SHELL = re.compile(r"\|\s*(?:\S*/)?(?:env\s+(?:-\S+\s+)*)?(?:(?:sudo|doas|pkexec|nohup|exec)\s+(?:-\S+\s+)*)?"
                         r"(?:ba|z|da|k|fi|c|tc|busybox\s+)?sh\b(?!\s+-c)|\|\s*(?:\S*/)?(python\d*(\.\d+)?|perl|"
                         r"ruby|node|php)\s*(?:-\s*)?(?:$|[;&|)])|\|\s*(?:\S*/)?(?:source|\.)\s+/dev/stdin")

_SHELLS = {"bash", "sh", "zsh", "dash", "ksh", "mksh", "fish", "ash", "csh", "tcsh", "rbash", "busybox"}
_INTERP = {"python", "python2", "python3", "perl", "ruby", "node", "nodejs", "php", "lua", "tclsh", "awk", "gawk",
           "mawk", "nawk"}
_PREFIX = {"env", "nice", "nohup", "time", "command", "exec", "builtin", "stdbuf", "ionice", "timeout", "setsid",
           "chrt", "taskset", "unbuffer", "sudo", "doas", "pkexec", "run0", "flock", "chroot", "nsenter",
           "systemd-run", "caffeinate", "watch", "xargs", "parallel", "strace", "ltrace", "busybox", "firejail",
           "unshare", "cgexec", "numactl", "eatmydata", "fakeroot", "script", "su"}
_KEYWORDS = {"do", "then", "else", "elif", "if", "while", "until", "!", "{", "}", "done", "fi", "esac", "coproc"}
_READONLY = {"cat", "less", "more", "head", "tail", "grep", "egrep", "fgrep", "rg", "ls", "stat", "file", "wc",
             "diff", "cmp", "md5sum", "sha1sum", "sha256sum", "sha512sum", "b2sum", "getent", "id", "namei",
             "lsattr", "test", "[", "[[", "pkaction", "pkcheck", "readlink", "realpath", "echo", "printf", "uniq",
             "cut", "tr", "column", "nl", "strings", "od", "journalctl", "true", "false", "which", "type", "pwd",
             "dirname", "basename", "du", "df", "tree", "bat", "jq", "groups", "whoami", "pacman-conf", "visudo",
             "find", "sort", "wc", "zcat", "zgrep", "xxd", "hexdump", "systemctl", "loginctl", "lsblk", "blkid",
             "findmnt", "mount", "uname", "date", "sleep", "cd", "exit", "return", ":"}
_PART_TOOLS = {"fdisk", "gdisk", "cfdisk", "cgdisk", "sfdisk", "sgdisk", "parted", "partx", "delpart", "resizepart",
               "addpart", "kpartx"}
_PART_RO = {"-l", "--list", "-p", "--print", "-i", "--info", "-v", "--verify", "-d", "--dump", "-J", "--json",
            "-s", "--show-size", "-V", "--list-types", "-T", "-g", "--show-geometry", "--show", "-L", "print",
            "--list-free", "-F", "-x", "--version", "-h", "--help"}
_PARTED_WRITE = {"mklabel", "mktable", "mkpart", "mkpartfs", "rm", "resizepart", "resize", "set", "toggle", "name",
                 "rescue", "mkfs", "move", "cp", "disk_set", "disk_toggle", "type"}
_FS_TOOLS = re.compile(r"^(mkfs(\..+)?|mke2fs|mkswap|mkntfs|mkdosfs|mkexfatfs|mkfs_\w+|mkudffs|mkreiserfs|"
                       r"mkfs\w+|newfs.*|wipefs|shred|blkdiscard|badblocks|scrub|wipe|sg_format|e2image|zerofree)$")
_DEV_WRITERS = {"tee", "cp", "install", "truncate", "ln", "mv", "rsync", "pv", "dd", "cat", "ddrescue", "dcfldd",
                "dc3dd", "flashrom", "xz", "gzip", "zstd", "bzip2", "unzip", "tar", "socat", "nc", "ncat"}
_ACCOUNT_CMDS = {"userdel", "deluser", "usermod", "chpasswd", "useradd", "adduser", "gpasswd", "groupdel",
                 "groupmod", "vipw", "vigr", "newusers", "chsh", "chfn", "pwconv", "pwunconv", "grpconv",
                 "grpunconv", "pwck", "grpck", "lusermod", "luserdel", "smbpasswd", "homectl", "faillock"}
_CORE_PKGS = {"linux", "linux-lts", "linux-zen", "linux-hardened", "linux-rt", "linux-rt-lts", "linux-firmware",
              "grub", "efibootmgr", "systemd", "systemd-libs", "systemd-sysvcompat", "glibc", "pacman", "lux-engine", "base",
              "filesystem", "bash", "coreutils", "sudo", "polkit", "pam", "shadow", "util-linux", "mkinitcpio",
              "dracut", "booster", "refind", "limine", "syslinux", "intel-ucode", "amd-ucode", "archlinux-keyring",
              "gcc-libs", "python", "lux", "luxos-base", "luxos-keyring", "luxai"}
_PKG_TOOLS = {"pacman", "yay", "paru", "pamac", "pikaur", "trizen", "aura", "lux"}
_ASSIGN = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\+?=(.*)$", re.S)
_VAR = re.compile(r"\$(?:\{([A-Za-z_][A-Za-z0-9_]*)(?:(:?[-=+?])([^}]*))?\}|([A-Za-z_][A-Za-z0-9_]*)|([0-9@*#?$!-]))")
_GLOB = re.compile(r"[*?\[]")
_FIND_FILTERS = {"-name", "-iname", "-path", "-ipath", "-regex", "-iregex", "-wholename", "-iwholename",
                 "-newer", "-mtime", "-mmin", "-atime", "-amin", "-ctime", "-cmin", "-size", "-user", "-group",
                 "-empty", "-lname", "-ilname", "-perm", "-uid", "-gid", "-nouser", "-nogroup"}
_MAX_DEPTH = 8
_MAX_SCRIPT = 256 * 1024


class _Found(Exception):
    def __init__(self, reason):
        super().__init__(reason)
        self.reason = reason


class _Ctx:
    def __init__(self, root, cwd, home):
        self.root = root
        self.cwd = cwd
        self.home = home
        self.vars = {}          # jmeno -> seznam moznych hodnot (None = neznama)
        self.depth = 0
        self.scripts = 0

    def block(self, reason):
        raise _Found(reason)

    def unsure(self, reason=R_UNSURE):
        if self.root:
            raise _Found(reason)


def hard_block(command, root=False, cwd=None, home=None):
    """Duvod, proc se prikaz nesmi nikdy spustit (pro jakykoli model a nastaveni), jinak None.
    root=True: prikaz pobezi jako root - plati i bloky "kdyz si nejsi jisty"."""
    text = str(command if command is not None else "")
    home = os.path.normpath(home or os.path.expanduser("~"))
    ctx = _Ctx(bool(root), os.path.normpath(cwd) if cwd else None, home)
    try:
        if "\x00" in text:
            ctx.block(R_DYNAMIC)
        if len(text) > MAX_COMMAND:
            ctx.unsure(R_DYNAMIC)
        _analyze(text, ctx)
    except _Found as f:
        return f.reason
    except RecursionError:
        return R_DYNAMIC if root else None
    return None


# ---- analyza textu ---------------------------------------------------------------------------------
def _dequote(text):
    """Text bez uvozovek a zpetnych lomitek, se zjednodusenymi cestami (/./, //) - proti obfuskaci
    typu r''m, /de\\v/sda, /etc//pam.d."""
    t = re.sub(r"\\\n", "", text)
    t = re.sub(r"[\"'\\]", "", t)
    t = re.sub(r"\$''", "", t)
    for _ in range(4):
        t = re.sub(r"/\./", "/", t)
    return re.sub(r"/{2,}", "/", t)


def _text_checks(text, ctx):
    low = text.lower()
    flat = _dequote(text)
    flow = flat.lower()
    if feeds_password(text) or feeds_password(flat):
        ctx.block(R_PASSWORD)
    for r in _FORK:
        if r.search(text) or r.search(flat):
            ctx.block(R_FORK)
    if _REDIRECT_DEV.search(flat):
        ctx.block(R_DISK)
    if _SYSRQ.search(flat) and (">" in flat or "tee" in flow):
        ctx.block(R_KERNEL)
    if _SIGLEVEL.search(flow):
        ctx.block(R_SIGNATURES)
    if ctx.root:
        if _SELF_ROOT.search(flat):
            ctx.block(R_SELF)
        for r in _REMOTE:
            if r.search(low) or r.search(flow):
                ctx.block(R_REMOTE)
        if _PIPE_SHELL.search(low) or _PIPE_SHELL.search(flow):
            ctx.block(R_DYNAMIC)
        if re.search(r"\b(ba|z|da|k)?sh\s+(-\w+\s+)*<\s*\(", flow) or re.search(r"(^|[\s;&|])(source|\.)\s+<\(", flow):
            ctx.block(R_DYNAMIC)
        if re.search(r"\bbase64\s+(-\w+\s+)*(-d|--decode)\b|\bxxd\s+-r\b|\bopenssl\s+(enc\s+)?(-\w+\s+)*-d\b", flow) \
                and re.search(r"\|\s*\S*(sh|bash|python\d*|perl|eval)\b|\beval\b|\$\(", flow):
            ctx.block(R_DYNAMIC)


def _mentions(flat):
    """Chranena mista zminena v textu (i v retezcich kodu) -> seznam duvodu."""
    return [reason for r, reason in _PROTECTED_TEXT if r.search(flat)]


def _substitutions(text):
    """Vnitrky $(...), <(...), >(...) a `...` (rekurzivni kontrola)."""
    out = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == "\\":
            i += 2
            continue
        if c in "$<>" and i + 1 < n and text[i + 1] == "(":
            depth, j = 1, i + 2
            while j < n and depth:
                if text[j] == "\\":
                    j += 2
                    continue
                if text[j] == "(":
                    depth += 1
                elif text[j] == ")":
                    depth -= 1
                j += 1
            out.append(text[i + 2:j - 1] if depth == 0 else text[i + 2:])
            i = j
            continue
        if c == "`":
            j = text.find("`", i + 1)
            out.append(text[i + 1:j] if j > 0 else text[i + 1:])
            i = j + 1 if j > 0 else n
            continue
        i += 1
    return out


def _tokens(text):
    """Tokeny shellu; oddelovace (;, &&, |, ...) a presmerovani (>, >>, <) jako samostatne tokeny."""
    t = text.replace("\r", "")
    t = re.sub(r"\\\n", "", t)
    t = t.replace("\n", " ; ")
    try:
        lex = shlex.shlex(t, posix=True, punctuation_chars=";&|()<>")
        lex.whitespace_split = True
        lex.commenters = ""
        return list(lex), True
    except ValueError:
        return [x.strip("\"'") for x in re.split(r"(\s+|[;&|()<>]+)", t) if x and not x.isspace()], False


def _simple_commands(tokens):
    """[(tokeny, presmerovani pro zapis, vstup (soubory, here-stringy, "<<"), oddelovac pred)]"""
    cmds, cur, wr, rd, sep = [], [], [], [], ";"
    i = 0
    while i < len(tokens):
        t = tokens[i]
        if t and set(t) <= set(";&|()"):
            if cur or wr or rd:
                cmds.append((cur, wr, rd, sep))
            cur, wr, rd = [], [], []
            sep = t
            i += 1
            continue
        if t and set(t) <= set("<>&|") and ("<" in t or ">" in t):
            if cur and cur[-1].isdigit():
                cur.pop()               # 2> soubor: cislo deskriptoru neni argument
            nxt = tokens[i + 1] if i + 1 < len(tokens) else ""
            if t in ("<<", "<<-"):
                rd.append(("heredoc", nxt))
            elif t == "<<<":
                rd.append(("string", nxt))
            elif ">" in t and "<" not in t:
                if nxt and not (t.endswith("&") and (nxt.isdigit() or nxt == "-")):
                    wr.append(nxt)
            elif nxt:
                rd.append(("file", nxt))
                if ">" in t:
                    wr.append(nxt)      # <> soubor: cteni i zapis
            i += 2
            continue
        cur.append(t)
        i += 1
    if cur or wr or rd:
        cmds.append((cur, wr, rd, sep))
    return cmds


_SUBST_VAR = "${__luxai_subst}"


def _mask_substitutions(text):
    """$(...), `...`, <(...) a >(...) nahradi neznamou promennou: vysledek nelze predem znat."""
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if c == "\\":
            out.append(text[i:i + 2])
            i += 2
            continue
        if c in "$<>" and i + 1 < n and text[i + 1] == "(":
            depth, j = 1, i + 2
            while j < n and depth:
                if text[j] == "\\":
                    j += 2
                    continue
                depth += {"(": 1, ")": -1}.get(text[j], 0)
                j += 1
            out.append(_SUBST_VAR)
            i = j
            continue
        if c == "`":
            j = text.find("`", i + 1)
            out.append(_SUBST_VAR)
            i = j + 1 if j > 0 else n
            continue
        out.append(c)
        i += 1
    return "".join(out)


def _analyze(text, ctx):
    ctx.depth += 1
    try:
        if ctx.depth > _MAX_DEPTH:
            ctx.unsure(R_DYNAMIC)
            return
        _text_checks(text, ctx)
        for inner in _substitutions(text):
            _analyze(inner, ctx)
        tokens, parsed = _tokens(_mask_substitutions(text))
        if not parsed and ctx.root:
            ctx.unsure(R_DYNAMIC)
        cmds = _simple_commands(tokens)
        flat = _dequote(text)
        mentioned = _mentions(flat)
        writers = False
        cwd0 = ctx.cwd
        for toks, wr, rd, sep in cmds:
            if _command(toks, wr, rd, sep, ctx):
                writers = True
        ctx.cwd = cwd0
        if mentioned and writers:
            ctx.block(mentioned[0])
    finally:
        ctx.depth -= 1


# ---- promenne a cesty ------------------------------------------------------------------------------
def _expand_braces(tok, limit=32):
    m = re.search(r"\{([^{}]*,[^{}]*)\}", tok)
    if not m:
        return [tok]
    out = []
    for part in m.group(1).split(","):
        out.extend(_expand_braces(tok[:m.start()] + part + tok[m.end():], limit))
        if len(out) >= limit:
            break
    return out[:limit]


def _values(tok, ctx):
    """Mozne hodnoty tokenu po rozbaleni ~, promennych a {a,b}: [(hodnota, dynamicka)]."""
    homes = [ctx.home] + (["/root"] if ctx.root and ctx.home != "/root" else [])
    variants = [(tok, False)]
    if tok == "~" or tok.startswith("~/"):
        variants = [(h + tok[1:], False) for h in homes]
    elif re.match(r"^~[a-z_][a-z0-9_-]*(/|$)", tok):
        variants = [("/home/" + tok[1:], False)]
    out = []
    for v, dyn in variants:
        out.extend(_subst_vars(v, ctx, dyn))
    res = []
    for v, dyn in out[:64]:
        if "$(" in v or "`" in v or "<(" in v:
            dyn = True
        for b in _expand_braces(v):
            res.append((b, dyn))
    return res[:64]


def _subst_vars(value, ctx, dyn):
    m = _VAR.search(value)
    if not m:
        return [(value, dyn)]
    name = m.group(1) or m.group(4)
    special = m.group(5)
    op, default = m.group(2), m.group(3)
    if special is not None:
        vals = [None]
    elif name == "HOME":
        vals = [ctx.home] + (["/root"] if ctx.root else [])
    elif name == "PWD":
        vals = [ctx.cwd]
    elif name in ctx.vars:
        vals = ctx.vars[name]
    elif op in ("-", ":-", "=", ":=") and default is not None:
        vals = [default]
    else:
        vals = [None]
    out = []
    for v in vals[:16]:
        if v is None:
            # neznama hodnota: zustane prazdna a token je "dynamicky" (rm -rf $X/ -> muze byt /)
            out.extend(_subst_vars(value[:m.start()] + value[m.end():], ctx, True))
        else:
            out.extend(_subst_vars(value[:m.start()] + v + value[m.end():], ctx, dyn))
    return out[:64]


def _abs(value, ctx):
    """Absolutni normalizovana cesta, nebo None (relativni cesta s neznamou pracovni slozkou)."""
    v = value
    if not v.startswith("/"):
        if ctx.cwd is None:
            return None
        v = os.path.join(ctx.cwd, v)
    v = re.sub(r"/{2,}", "/", v)
    n = os.path.normpath(v)
    return "/" if n.startswith("//") else n


def _is_home_root(p, ctx):
    return p in (ctx.home, "/root") or bool(re.match(r"^/home/[^/]+$", p))


def _covers(p, dirs):
    """p je nektera ze slozek nebo jejich nadrazena slozka."""
    if p == "/":
        return True
    return any(d == p or d.startswith(p + "/") for d in dirs)


def _protected_dir(p, ctx, homes=True):
    if _covers(p, SYSTEM_DIRS):
        return True
    if homes and (_is_home_root(p, ctx) or ctx.home.startswith(p + "/")):
        return True
    return False


def _in_boot(p):
    return any(p == b or p.startswith(b + "/") for b in _BOOT)


def _glob_prefix(p):
    """Cast cesty pred prvni slozkou s maskou (/usr/l* -> /usr), nebo None bez masky."""
    if not _GLOB.search(p):
        return None
    parts = p.split("/")
    pre = []
    for part in parts:
        if _GLOB.search(part):
            break
        pre.append(part)
    return "/".join(pre) or "/"


_SAMPLE_NAMES = ("Documents", "Desktop", ".config", ".local", "usr", "etc", "home", "x", "a1")


def _glob_hits(p, ctx, homes=True):
    """Maska v ceste muze zasahnout chranenou slozku (/*, /e*, ~/.*, /usr/l*, /var/lib/pacman/*);
    uzka maska (/etc/*.pacnew, ~/build/*) ne."""
    pre = _glob_prefix(p)
    if pre is None or pre in _GLOB_OK:
        return False
    if not _protected_dir(pre, ctx, homes) and not _in_boot(pre):
        return False
    comp = p[len(pre):].lstrip("/").split("/")[0]
    names = set(_SAMPLE_NAMES) | {os.path.basename(ctx.home)}
    for d in list(SYSTEM_DIRS) + [ctx.home, "/root"] + [b for b, _r in _PROTECTED]:
        if os.path.dirname(d) == pre:
            names.add(os.path.basename(d))
    return any(fnmatch.fnmatchcase(n, comp) for n in names)


def _check_delete(value, ctx, recursive, homes=True, reason=R_DELETE):
    """Kontrola cile mazani/presunu (rm, mv, find -delete)."""
    p = _abs(value, ctx)
    if p is None:
        if recursive:
            ctx.unsure()
        return
    pre = _glob_prefix(p)
    if _in_boot(p) or (pre is not None and _in_boot(pre + "/x")):
        ctx.block(R_BOOT)
    if pre is not None:
        if _glob_hits(p, ctx, homes):
            ctx.block(reason)
        return
    if recursive and _protected_dir(p, ctx, homes):
        ctx.block(reason)
    if p == "/" or _is_home_root(p, ctx) and homes:
        ctx.block(reason)


def _protected_path(p):
    for base, reason in _PROTECTED:
        if p == base or p.startswith(base.rstrip("/") + "/"):
            return reason
    return None


# ---- jednotlive prikazy ----------------------------------------------------------------------------
def _strip(toks, ctx):
    """Odstrani prefixy (env A=B, sudo -u x, nice -n 5, timeout 10, xargs -0 ...).
    Vraci (zbytek, z_xargs). Vnitrni retezce (env -S, su -c) zkontroluje rekurzivne."""
    i, xargs = 0, False
    while i < len(toks):
        t = toks[i]
        b = os.path.basename(t)
        if _ASSIGN.match(t) or t in _KEYWORDS:
            i += 1
            continue
        if b not in _PREFIX:
            break
        i += 1
        if b in ("xargs", "parallel", "watch"):
            xargs = True
        if b == "su":
            # su [-] [uzivatel] [-c PRIKAZ]
            rest = toks[i:]
            if "-c" in rest or "--command" in rest:
                k = rest.index("-c") if "-c" in rest else rest.index("--command")
                if k + 1 < len(rest):
                    _analyze(rest[k + 1], ctx)
            return [], xargs
        if b == "chroot":
            while i < len(toks) and toks[i].startswith("-"):
                i += 1
            if i < len(toks):
                p = _abs(toks[i], ctx)
                if p != "/":
                    ctx.unsure(R_DYNAMIC)
                i += 1
            continue
        if b == "flock" or b == "cgexec":
            while i < len(toks) and toks[i].startswith("-"):
                i += 1
            i += 1
            continue
        # volby prefixu (u nekterych s hodnotou)
        with_val = {"sudo": {"-u", "-g", "-p", "-C", "-h", "-D", "-r", "-t", "-U", "-T", "--user", "--group",
                             "--prompt", "--chdir", "--host"},
                    "env": {"-u", "--unset", "-C", "--chdir"}, "nice": {"-n", "--adjustment"},
                    "ionice": {"-c", "-n", "-p", "-P", "-u"}, "timeout": {"-s", "--signal", "-k", "--kill-after"},
                    "stdbuf": set(), "taskset": set(), "chrt": set(), "pkexec": {"--user"},
                    "xargs": {"-I", "-n", "-P", "-d", "-L", "-s", "-E", "-a", "--arg-file", "--delimiter",
                              "--max-args", "--max-procs", "--replace"},
                    "systemd-run": {"-p", "--property", "-u", "--unit", "-E", "--setenv", "--uid", "--gid",
                                    "-M", "--machine"},
                    "doas": {"-u", "-C"}, "run0": {"-u", "--user", "-g", "--group", "-D", "--chdir"},
                    "nsenter": {"-t", "--target"}, "numactl": set(), "strace": {"-o", "-e", "-p", "-s"},
                    "script": {"-c", "--command"}, "firejail": set(), "unshare": set(),
                    "watch": {"-n", "--interval"}}.get(b, set())
        while i < len(toks) and toks[i].startswith("-") and toks[i] != "--":
            opt = toks[i]
            if b == "env" and opt in ("-S", "--split-string") and i + 1 < len(toks):
                _analyze(toks[i + 1], ctx)
                return [], xargs
            if b == "env" and opt.startswith("--split-string="):
                _analyze(opt.split("=", 1)[1], ctx)
                return [], xargs
            if b == "script" and opt in ("-c", "--command") and i + 1 < len(toks):
                _analyze(toks[i + 1], ctx)
                return [], xargs
            i += 1
            if opt in with_val and i < len(toks):
                i += 1
        if i < len(toks) and toks[i] == "--":
            i += 1
        if b == "timeout" and i < len(toks) and re.match(r"^\d+(\.\d+)?[smhd]?$", toks[i]):
            i += 1
        if b == "script" and i < len(toks):
            i += 1  # soubor zaznamu
        if b in ("nice",) and i < len(toks) and re.match(r"^-?\d+$", toks[i]):
            i += 1
    return toks[i:], xargs


def _script_file(path, ctx):
    """Kontrola obsahu spousteneho skriptu (bash skript.sh, source, ./skript se #!)."""
    if not ctx.root:
        return
    ctx.scripts += 1
    if ctx.scripts > 8:
        ctx.unsure(R_DYNAMIC)
        return
    try:
        st = os.stat(path)
    except OSError:
        return
    if not os.path.isfile(path):
        return
    if st.st_size > _MAX_SCRIPT:
        ctx.unsure(R_DYNAMIC)
        return
    try:
        with open(path, "rb") as f:
            data = f.read(_MAX_SCRIPT + 1)
    except OSError:
        return
    if b"\x00" in data[:8192]:
        return
    _analyze(data.decode("utf-8", "replace"), ctx)


def _command(raw, wr, rd, sep, ctx):
    """Kontrola jednoho jednoducheho prikazu. Vraci True, pokud prikaz neco meni (neni jen cteci)."""
    # prirazeni promennych (X=/ ; export X=/ ; for X in a b)
    toks = list(raw)
    while toks and toks[0] in _KEYWORDS:
        toks = toks[1:]
    if toks and toks[0] == "for" and len(toks) >= 2:
        name = toks[1]
        vals = []
        if "in" in toks:
            for t in toks[toks.index("in") + 1:]:
                for v, dyn in _values(t, ctx):
                    vals.append(None if dyn else v)
        ctx.vars[name] = vals or [None]
        return False
    if toks and toks[0] in ("export", "declare", "local", "readonly", "typeset", "let"):
        for t in toks[1:]:
            m = _ASSIGN.match(t)
            if m:
                ctx.vars[m.group(1)] = [None if d else v for v, d in _values(m.group(2), ctx)][:16] or [None]
        return False
    if toks and toks[0] in ("read", "mapfile", "readarray"):
        for t in toks[1:]:
            if re.match(r"^[A-Za-z_]\w*$", t):
                ctx.vars[t] = [None]
        return False
    k = 0
    assigns = []
    while k < len(toks) and _ASSIGN.match(toks[k]):
        assigns.append(_ASSIGN.match(toks[k]))
        k += 1
    if k == len(toks):
        for m in assigns:
            ctx.vars[m.group(1)] = [None if d else v for v, d in _values(m.group(2), ctx)][:16] or [None]
        # jen prirazeni; zapis presmerovanim se kontroluje nize
        toks = []
    rest, xargs = _strip(toks, ctx) if toks else ([], False)
    writes = _check_redirects(wr, ctx)
    if not rest:
        return writes
    name_tok = rest[0]
    if re.search(r"[$`]", name_tok) or _GLOB.search(name_tok):
        # neznamy program ($(echo rm) -rf /): u roota odmitnout, jinak aspon zkontrolovat zname cile
        ctx.unsure(R_DYNAMIC)
        if any(re.match(r"^-[A-Za-z]*[rR]", a) for a in rest[1:]):
            for a in rest[1:]:
                for v, d in _values(a, ctx):
                    if v and not v.startswith("-"):
                        _check_delete(v, ctx, True)
        return True
    name = os.path.basename(name_tok)
    args = rest[1:]
    vals = []          # rozbalene argumenty: seznam (puvodni, [(hodnota, dynamicka)])
    for a in args:
        vals.append((a, _values(a, ctx)))
    flat_args = [v for _a, vs in vals for v, _d in vs]
    dyn_args = any(d for _a, vs in vals for _v, d in vs)
    shorts = "".join(a[1:] for a in args if a.startswith("-") and not a.startswith("--"))
    longs = {a.split("=", 1)[0] for a in args if a.startswith("--")}

    def targets(skip_values=()):
        out, after = [], False
        it = iter(range(len(vals)))
        for idx in it:
            a, vs = vals[idx]
            if a == "--" and not after:
                after = True
                continue
            if not after and a.startswith("-") and a != "-":
                if a in skip_values:
                    next(it, None)
                continue
            out.extend(vs)
        return out

    # cd: pracovni slozka pro dalsi prikazy
    if name == "cd":
        t = targets()
        if not t:
            ctx.cwd = ctx.home
        elif len(t) == 1 and not t[0][1]:
            ctx.cwd = _abs(t[0][0], ctx) if t[0][0] != "-" else None
        else:
            ctx.cwd = None
        return False
    # shell, eval, source, interprety
    if name in _SHELLS:
        if name == "busybox":
            return _command(args, [], [], sep, ctx) if args else False
        cflag = next((i for i, a in enumerate(args) if a.startswith("-") and not a.startswith("--")
                      and "c" in a[1:]), None)
        if cflag is not None:
            if cflag + 1 < len(args):
                _analyze(args[cflag + 1], ctx)
            return True
        for kind, body in rd:
            if kind == "string":
                _analyze(body, ctx)
        files = [a for a in args if not a.startswith("-")]
        if files:
            for v, d in _values(files[0], ctx):
                p = _abs(v, ctx)
                if d or p is None:
                    ctx.unsure(R_DYNAMIC)
                else:
                    _script_file(p, ctx)
        elif sep in ("|", "|&") or rd:
            ctx.unsure(R_DYNAMIC)
        return True
    if name == "eval":
        code = " ".join(args)
        if re.search(r"[$`]", code):
            ctx.unsure(R_DYNAMIC)
        _analyze(code, ctx)
        return True
    if name in ("source", "."):
        if args:
            for v, d in _values(args[0], ctx):
                p = _abs(v, ctx)
                if d or p is None or p.startswith("/dev/") or p.startswith("/proc/"):
                    ctx.unsure(R_DYNAMIC)
                else:
                    _script_file(p, ctx)
        return True
    if re.sub(r"[\d.]+$", "", name) in _INTERP:
        _interpreter(name, args, sep, rd, ctx)
        return True
    if "/" in name_tok:
        p = _abs(name_tok, ctx)
        if p and not p.startswith(("/usr/", "/bin/", "/sbin/")):
            _script_file(p, ctx)
    if xargs and name in ("rm", "chmod", "chown", "chgrp", "shred", "dd", "mv", "find", "truncate", "wipefs",
                          "unlink", "rmdir") or xargs and _FS_TOOLS.match(name):
        ctx.unsure()

    # --- mazani a presuny
    if name in ("rm", "unlink", "rmdir"):
        recursive = name == "rm" and ("r" in shorts.lower() or "--recursive" in longs)
        if "--no-preserve-root" in longs:
            ctx.block(R_DELETE)
        for v, d in targets():
            if d:
                if recursive or _GLOB.search(v):
                    ctx.unsure()
                if not v:
                    continue    # prazdna neznama hodnota; zname casti se kontroluji (rm -rf $X/ -> "/")
            _check_delete(v, ctx, recursive or name == "rmdir")
        return True
    if name == "mv":
        t = targets({"-t", "--target-directory", "-S", "--suffix"})
        srcs = t[:-1] if len(t) > 1 else t
        for v, d in srcs:
            if d:
                ctx.unsure()
                if not v:
                    continue
            _check_delete(v, ctx, True)
        return True
    if name == "find":
        starts = []
        for a, vs in vals:
            if a.startswith("-") or a in ("(", "!", ")"):
                break
            starts.extend(vs)
        acts = {"-delete", "-exec", "-execdir", "-ok", "-okdir"}
        if any(a in acts for a in args):
            filtered = any(a in _FIND_FILTERS for a in args)
            for v, d in starts or [(".", False)]:
                if d:
                    ctx.unsure()
                    if not v:
                        continue
                p = _abs(v, ctx)
                if p is None:
                    ctx.unsure()
                    continue
                if p == "/" or _in_boot(p) or _GLOB.search(p) and _glob_hits(p, ctx):
                    ctx.block(R_BOOT if _in_boot(p) else R_DELETE)
                if p in _GLOB_OK or p == "/var/log":
                    continue
                if _protected_dir(p, ctx, homes=False) or not filtered and _protected_dir(p, ctx):
                    ctx.block(R_DELETE)
            for i, a in enumerate(args):
                if a in acts - {"-delete"}:
                    j = i + 1
                    inner = []
                    while j < len(args) and args[j] not in (";", "\\;", "+"):
                        inner.append(args[j])
                        j += 1
                    if inner:
                        _command(inner, [], [], ";", ctx)
            return True
        return False
    # --- prava a vlastnik
    if name in ("chmod", "chown", "chgrp", "setfacl", "chattr", "chcon", "setfattr"):
        recursive = "R" in shorts or "--recursive" in longs or (name == "setfacl" and "R" in shorts)
        t = targets({"--reference", "--from"})
        if name in ("chmod", "chown", "chgrp", "chattr") and t and not t[0][0].startswith("/") and \
                not t[0][0].startswith("~") and not t[0][0].startswith("$"):
            t = t[1:]           # rezim nebo vlastnik
        for v, d in t:
            p = _abs(v, ctx)
            if d or p is None:
                if recursive:
                    ctx.unsure()
                continue
            if _glob_hits(p, ctx, homes=False):
                ctx.block(R_PERMS)
            if recursive and _protected_dir(p, ctx, homes=False):
                ctx.block(R_PERMS)
            if p == "/" or p in ("/usr", "/etc", "/bin", "/sbin", "/lib", "/lib64", "/boot", "/var", "/home",
                                 "/usr/bin", "/usr/lib"):
                ctx.block(R_PERMS)
            r = _protected_path(p)
            if r:
                ctx.block(r)
        return True
    # --- disky
    if name == "dd" or name in ("ddrescue", "dcfldd", "dc3dd"):
        for a, vs in vals:
            if a.startswith("of="):
                for v, d in _values(a[3:], ctx):
                    p = _abs(v, ctx)
                    if d or p is None:
                        ctx.unsure()
                    elif _DEVICE.match(p) or p.startswith("/dev/") and _GLOB.search(p):
                        ctx.block(R_DISK)
                    elif _in_boot(p):
                        ctx.block(R_BOOT)
                    elif _protected_path(p):
                        ctx.block(_protected_path(p))
        if name != "dd" and any(_DEVICE.match(v) for v in flat_args[1:]):
            ctx.block(R_DISK)
        return True
    if _FS_TOOLS.match(name):
        if name == "wipefs" and not ({"a", "o"} & set(shorts) or {"--all", "--offset"} & longs):
            return False    # jen vypis
        if name == "badblocks" and "w" not in shorts and "n" not in shorts:
            return False
        for a, vs in vals:
            if a.startswith("-"):
                continue
            for v, d in vs:
                p = _abs(v, ctx)
                if d or p is None:
                    ctx.unsure()
                elif _DEVICE.match(p) or p.startswith("/dev/"):
                    ctx.block(R_DISK)
                elif name in ("shred", "wipe", "scrub"):
                    r = _protected_path(p)
                    if r or _in_boot(p):
                        ctx.block(r or R_BOOT)
        if name == "blkdiscard":
            ctx.block(R_DISK)
        return True
    if name in _PART_TOOLS:
        if name == "parted":
            if any(a.lower() in _PARTED_WRITE for a in args) or not any(a in ("-l", "--list", "print")
                                                                        for a in args):
                ctx.block(R_DISK)
            return False
        opts = [a for a in args if a.startswith("-")]
        if name in ("partx", "kpartx", "delpart", "resizepart", "addpart"):
            if name in ("delpart", "resizepart", "addpart") or any(o in ("-d", "--delete", "-a", "--add", "-u",
                                                                          "--update") for o in opts):
                ctx.block(R_DISK)
            return False
        if not opts or any(o not in _PART_RO and not o.startswith("--list") for o in opts):
            ctx.block(R_DISK)
        return False
    if name == "cryptsetup" and any(a in ("luksFormat", "erase", "luksErase", "reencrypt", "luksKillSlot",
                                          "luksRemoveKey", "format", "tcryptDump") for a in args):
        ctx.block(R_DISK)
    if name == "nvme" and any(a in ("format", "sanitize", "delete-ns", "detach-ns", "write-zeroes", "write")
                              for a in args):
        ctx.block(R_DISK)
    if name == "hdparm" and any(a.startswith(("--security-erase", "--trim-sector-ranges", "--write-sector",
                                              "--make-bad-sector", "--dco-restore", "--security-set-pass",
                                              "--fwdownload")) for a in args):
        ctx.block(R_DISK)
    if name in ("zpool", "zfs") and any(a in ("destroy", "labelclear", "create") for a in args):
        ctx.block(R_DISK)
    if name in ("lvremove", "vgremove", "pvremove", "pvcreate", "vgcreate", "lvcreate") or \
            name == "mdadm" and any(a.startswith("--zero-superblock") or a == "--create" for a in args) or \
            name == "dmsetup" and any(a in ("remove_all", "wipe_table") for a in args) or \
            name == "flashrom" and any(a in ("-w", "--write", "-E", "--erase") for a in args):
        ctx.block(R_DISK)
    if name in _DEV_WRITERS and name != "dd":
        for v in flat_args:
            if _DEVICE.match(v):
                if name in ("cat", "pv", "xz", "gzip", "zstd", "bzip2", "tar", "unzip"):
                    continue    # cteni z disku (zapis by byl presmerovanim, viz vyse)
                ctx.block(R_DISK)
    # --- ucty, sudoers
    if name in _ACCOUNT_CMDS:
        if name in ("pwck", "grpck") and ("r" in shorts or "--read-only" in longs):
            return False
        if name == "faillock" and "--reset" not in longs:
            return False
        ctx.block(R_ACCOUNTS)
    if name == "passwd":
        opts = {a for a in args if a.startswith("-")}
        if opts & {"-S", "--status"} and opts <= {"-S", "--status", "-a", "--all"}:
            return False    # jen stav uctu
        ctx.block(R_ACCOUNTS)
    if name == "chage" and not ({"l"} & set(shorts) or "--list" in longs):
        ctx.block(R_ACCOUNTS)
    if name == "visudo":
        if "c" in shorts or "--check" in longs:
            return False
        ctx.block(R_AUTH)
    if name in ("sudoedit", "pam-auth-update", "authselect"):
        ctx.block(R_AUTH)
    # --- balicky, zavadec
    if name in _PKG_TOOLS:
        removing = any(re.match(r"^-[A-Za-z]*R", a) for a in args) or "--remove" in longs or \
            name in ("lux", "pamac") and args[:1] and args[0] in ("remove", "uninstall", "rm", "purge")
        if removing:
            for v in flat_args:
                if not v.startswith("-") and (v in _CORE_PKGS or re.match(r"^linux(-[a-z0-9]+)*$", v)):
                    ctx.block(R_BOOT)
            if dyn_args:
                ctx.unsure()
        if any(a in ("--dbonly",) for a in args) and removing:
            ctx.block(R_BOOT)
    if name == "efibootmgr" and ("B" in shorts or "--delete-bootnum" in longs or "--delete" in longs):
        ctx.block(R_BOOT)
    if name == "bootctl" and any(a in ("remove", "unlink", "cleanup") for a in args):
        ctx.block(R_BOOT)
    if name in ("makepkg", "pacman", "yay", "paru") and any(a in ("--skippgpcheck", "--skipchecksums",
                                                                  "--skipinteg", "--nosign") for a in args):
        ctx.block(R_SIGNATURES)
    if name == "pacman-key" and any(a in ("--delete", "-d", "--edit-key") for a in args):
        ctx.block(R_SIGNATURES)
    # --- zapis do chranenych souboru (tee, cp, sed -i, ln, install, truncate, chmod ...)
    readonly = name in _READONLY
    if name == "find" or name == "sort" and ("o" in shorts or "--output" in longs):
        readonly = False
    if name == "systemctl" and not (args[:1] and args[0] in ("status", "cat", "show", "is-active", "is-enabled",
                                                              "list-units", "list-unit-files", "list-timers",
                                                              "is-failed", "--failed")):
        readonly = False
    if name == "mount" and args:
        readonly = False
    if not readonly:
        for v, d in [x for _a, vs in vals for x in vs]:
            p = _abs(v, ctx) if "/" in v or v.startswith("~") else None
            if p:
                r = _protected_path(p)
                if r:
                    ctx.block(r)
                if ctx.root and _SELF_ROOT.search(p):
                    ctx.block(R_SELF)
    return not readonly or writes


def _check_redirects(wr, ctx):
    """Zapis presmerovanim (> soubor). Vraci True, pokud nejaky je (mimo /dev/null)."""
    any_write = False
    for t in wr:
        for v, d in _values(t, ctx):
            if v in ("/dev/null", "/dev/stdout", "/dev/stderr", "/dev/tty") or re.match(r"^&?\d+$", v):
                continue
            any_write = True
            p = _abs(v, ctx)
            if d or p is None:
                continue
            if _DEVICE.match(p):
                ctx.block(R_DISK)
            if p.startswith("/proc/sysrq"):
                ctx.block(R_KERNEL)
            r = _protected_path(p)
            if r:
                ctx.block(r)
            if _in_boot(p) and re.search(r"(vmlinuz|initramfs|\.efi$|/EFI/|loader/|grub)", p, re.I):
                ctx.block(R_BOOT)
    return any_write


def _interpreter(name, args, sep, rd, ctx):
    """python -c, perl -e ... : retezce v kodu se zkontroluji jako prikazy shellu."""
    code = None
    for i, a in enumerate(args):
        if a in ("-c", "-e", "-E", "-r", "--eval", "-p") or re.match(r"^-[a-zA-Z]*[ceE]$", a):
            if i + 1 < len(args):
                code = args[i + 1]
            break
    base = re.sub(r"[\d.]+$", "", name)
    if code is None:
        script = next((a for a in args if not a.startswith("-")), None)
        if base in ("awk", "gawk", "mawk", "nawk"):
            code = script
        elif script is None or script == "-":
            if sep in ("|", "|&") or rd:
                ctx.unsure(R_DYNAMIC)
            return
        else:
            code = _interp_file(script, ctx)     # python3 skript.py: obsah skriptu stejne jako -c
    if code is None:
        return
    for lit in re.findall(r"\"((?:[^\"\\]|\\.)*)\"|'((?:[^'\\]|\\.)*)'", code):
        s = lit[0] or lit[1]
        if s and re.search(r"\s", s):
            _analyze(s, ctx)
    if ctx.root:
        flat = _dequote(code)
        if re.search(r"rmtree|unlink|remove|rmdir|truncate|system|popen|exec|spawn|subprocess|open\s*\(", flat):
            for p in re.findall(r"(?<![\w.])(/[\w./-]*)", flat):
                q = os.path.normpath(re.sub(r"/{2,}", "/", p)) if p != "/" else "/"
                if q == "/" or _protected_dir(q, ctx) or _protected_path(q) or _in_boot(q) or _DEVICE.match(q):
                    ctx.block(R_DYNAMIC)


def _interp_file(script, ctx):
    """Obsah skriptu interpretu (python3 oprava.py) pro kontrolu jako kod z -c; jen u roota."""
    if not ctx.root:
        return None
    for v, d in _values(script, ctx):
        p = _abs(v, ctx)
        if d or p is None:
            ctx.unsure(R_DYNAMIC)
            return None
        try:
            if not os.path.isfile(p):
                return None
            if os.path.getsize(p) > _MAX_SCRIPT:
                ctx.unsure(R_DYNAMIC)
                return None
            with open(p, "rb") as f:
                data = f.read(_MAX_SCRIPT + 1)
        except OSError:
            return None
        if b"\x00" in data[:8192]:
            ctx.unsure(R_DYNAMIC)        # zkompilovany soubor (.pyc ...) nelze zkontrolovat
            return None
        return data.decode("utf-8", "replace")
    return None
