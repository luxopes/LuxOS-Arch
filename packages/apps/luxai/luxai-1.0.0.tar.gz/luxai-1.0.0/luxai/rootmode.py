"""Rezim spravce LuxAI: prikazy agenta jako root.

Nastaveni > Opravneni agenta > "Prikazy spravce" (policy["root_mode"]):
  password - kazdy prikaz jako root: dve potvrzeni karty a heslo spravce v systemovem dialogu (vychozi),
  nopass   - bez hesla, kazdy prikaz jedno potvrzeni karty (jen model Flash),
  noask    - bez hesla a bez potvrzeni (jen model Flash).
Model Lite ma vzdy "password". Tvrde bloky (rootguard.hard_block: rm -rf /, mkfs, zapis na disk,
sudoers/polkit/PAM, ucty, rezim spravce sam ...) plati vzdy - v aplikaci i znovu v pomocnikovi
/usr/lib/luxai/luxai-root, ktery bezi jako root.

Bez hesla funguje pres pravidlo polkit 49-luxai-root-<uzivatel>.rules, ktere zapise
luxai-root-setup (pkexec, jednou heslo spravce). Kazdy prikaz jako root se zapise do
~/.local/state/luxai/root-commands.log a do systemoveho zurnalu (pomocnik).
"""
import os
import re
import subprocess
import time

from . import rootguard

MODES = ("password", "nopass", "noask")
DEFAULT_MODE = "password"
ROOT_MODELS = ("flash",)          # rezim bez hesla jen pro chytrejsi model
LOG_MAX = 512 * 1024


def effective_mode(policy, model):
    """Rezim pro dany model: Lite (a cokoli mimo ROOT_MODELS) vzdy "password"."""
    mode = (policy or {}).get("root_mode")
    if mode not in MODES or model not in ROOT_MODELS:
        return DEFAULT_MODE
    return mode


# sudo/pkexec na pozici prikazu bez voleb (sudo -u jiny_uzivatel apod. se neprevadi)
_LEADING = re.compile(r"^\s*(?:\S*/)?(?:sudo|pkexec)\s+(?!-)")
_INNER = re.compile(r"(^|&&|\|\||[;|\n(])(\s*)(?:\S*/)?(?:sudo|pkexec)\s+(?!-)")


def normalize_run_command(args):
    """run_command, ktery zacina "sudo ..." nebo "pkexec ...", prevede na root=true bez sudo/pkexec
    (vcetne dalsich "sudo" na zacatku prikazu za &&, ;, |). Vraci novy slovnik argumentu."""
    if not isinstance(args, dict):
        return args
    out = dict(args)
    root = flag(out.get("root"))
    cmd = str(out.get("command", ""))
    if _LEADING.match(cmd):
        root = True
        cmd = _INNER.sub(lambda m: m.group(1) + m.group(2), cmd).lstrip()
        out["command"] = cmd
    if root:
        out["root"] = True
    else:
        out.pop("root", None)
    return out


def flag(value):
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on")
    return bool(value)


def helper_argv(mode, command, cwd, timeout):
    """argv pro pkexec. password -> luxai-root (vzdy heslo), nopass/noask -> luxai-root-auto."""
    helper = rootguard.HELPER if mode == DEFAULT_MODE else rootguard.HELPER_AUTO
    return ["pkexec", helper, "--timeout", str(int(timeout)), "--cwd", cwd or "/", "--", command]


def available():
    return os.path.exists(rootguard.HELPER) and bool(_which("pkexec"))


def _which(name):
    for d in os.environ.get("PATH", "/usr/bin").split(":"):
        p = os.path.join(d or ".", name)
        if os.access(p, os.X_OK):
            return p
    return None


# ---- zapnuti / vypnuti (luxai-root-setup) ---------------------------------------------------
def rule_active():
    """True, kdyz polkit povoli org.luxai.root-auto bez hesla (pravidlo existuje a relace je aktivni).
    /etc/polkit-1/rules.d bezny uzivatel cist nemuze, proto pkcheck."""
    if not _which("pkcheck"):
        return False
    try:
        r = subprocess.run(["pkcheck", "--action-id", rootguard.ACTION_AUTO, "--process", str(os.getpid())],
                           stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return False
    return r.returncode == 0


def set_rule(enable):
    """Zapne/vypne pravidlo bez hesla (pkexec - pri zapnuti dialog s heslem spravce).
    Vraci (ok, chyba). Blokuje - volat mimo hlavni vlakno GTK."""
    if not os.path.exists(rootguard.SETUP_HELPER) or not _which("pkexec"):
        return False, "LuxAI administrator mode is not installed (update LuxAI)"
    try:
        r = subprocess.run(["pkexec", rootguard.SETUP_HELPER, "enable" if enable else "disable"],
                           stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=300)
    except (OSError, subprocess.TimeoutExpired) as e:
        return False, str(e)
    if r.returncode == 0:
        return True, ""
    if r.returncode in (126, 127):
        return False, "the administrator password was not entered"
    return False, (r.stderr or r.stdout or f"exit code {r.returncode}").strip()[:300]


# ---- zaznam -----------------------------------------------------------------------------
def log_path():
    base = os.environ.get("XDG_STATE_HOME") or os.path.expanduser("~/.local/state")
    return os.path.join(base, "luxai", "root-commands.log")


def log_command(mode, model, command, exit_code, duration):
    """Jeden radek na prikaz jako root (cas, rezim, model, kod, trvani, prikaz). Chyby zapisu ignoruje."""
    path = log_path()
    try:
        os.makedirs(os.path.dirname(path), mode=0o700, exist_ok=True)
        if os.path.exists(path) and os.path.getsize(path) > LOG_MAX:
            os.replace(path, path + ".1")
        one = " ".join(str(command).split())
        if len(one) > 2000:
            one = one[:2000] + "…"
        line = "%s\t%s\t%s\texit=%s\t%.1fs\t%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), mode, model,
                                                    exit_code, duration, one)
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        with os.fdopen(fd, "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass


def exit_message(code):
    """Srozumitelna chyba pro model podle kodu pkexec/pomocnika, nebo None."""
    if code == rootguard.EXIT_REFUSED:
        return "Refused by LuxAI safety rules (administrator helper). Do not try to bypass this."
    if code in (126, 127):
        return ("Administrator rights were not granted (the password dialog was cancelled or the password was "
                "wrong). Do not retry the same command; tell the user what it would do and let them decide.")
    if code == rootguard.EXIT_TIMEOUT:
        return "Command timed out and was stopped"
    if code == rootguard.EXIT_CANCELLED:
        return "Command was stopped by the user"
    return None
