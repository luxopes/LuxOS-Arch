"""Maly Markdown renderer: text -> bloky, radkove formatovani -> Pango markup.

Bloky: heading, para, list (polozky s urovni odsazeni), code (s jazykem), quote, hr, table.
Neukonceny blok kodu (pri streamovani) se bere jako blok kodu az do konce textu.
"""
import re
from html import escape as _esc

FENCE = re.compile(r"^\s{0,3}(`{3,}|~{3,})\s*([\w+#.-]*)")
HEADING = re.compile(r"^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$")
LIST_ITEM = re.compile(r"^(\s*)([-*+]|\d{1,3}[.)])\s+(.*)$")
TASK = re.compile(r"^\[([ xX])\]\s+(.*)$")
HR = re.compile(r"^\s{0,3}([-*_])(\s*\1){2,}\s*$")
TABLE_SEP = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")


def esc(text):
    return _esc(text, quote=False)


def _split_row(line):
    s = line.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|") and not s.endswith("\\|"):
        s = s[:-1]
    cells = re.split(r"(?<!\\)\|", s)
    return [c.strip().replace("\\|", "|") for c in cells]


def parse_blocks(text):
    lines = (text or "").replace("\r\n", "\n").replace("\t", "    ").split("\n")
    blocks = []
    para = []
    i = 0

    def flush_para():
        if para:
            blocks.append({"type": "para", "text": "\n".join(para)})
            para.clear()

    while i < len(lines):
        line = lines[i]
        m = FENCE.match(line)
        if m:
            flush_para()
            fence = m.group(1)
            lang = m.group(2)
            body = []
            i += 1
            closed = False
            while i < len(lines):
                if lines[i].strip().startswith(fence[0] * len(fence)) and not lines[i].strip().strip(fence[0]):
                    closed = True
                    i += 1
                    break
                body.append(lines[i])
                i += 1
            blocks.append({"type": "code", "lang": lang, "text": "\n".join(body), "closed": closed})
            continue
        if not line.strip():
            flush_para()
            i += 1
            continue
        m = HEADING.match(line)
        if m:
            flush_para()
            blocks.append({"type": "heading", "level": len(m.group(1)), "text": m.group(2)})
            i += 1
            continue
        if HR.match(line) and not para:
            blocks.append({"type": "hr"})
            i += 1
            continue
        if "|" in line and i + 1 < len(lines) and TABLE_SEP.match(lines[i + 1]) and "-" in lines[i + 1]:
            flush_para()
            header = _split_row(line)
            rows = []
            i += 2
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                rows.append(_split_row(lines[i]))
                i += 1
            blocks.append({"type": "table", "header": header, "rows": rows})
            continue
        if line.lstrip().startswith(">"):
            flush_para()
            q = []
            while i < len(lines) and lines[i].lstrip().startswith(">"):
                q.append(re.sub(r"^\s*>\s?", "", lines[i]))
                i += 1
            blocks.append({"type": "quote", "text": "\n".join(q)})
            continue
        m = LIST_ITEM.match(line)
        if m:
            flush_para()
            items = []
            ordered = m.group(2)[0].isdigit()
            while i < len(lines):
                m = LIST_ITEM.match(lines[i])
                if m:
                    indent = len(m.group(1)) // 2
                    marker = m.group(2)
                    body = m.group(3)
                    item = {"level": min(indent, 4), "ordered": marker[0].isdigit(),
                            "number": int(re.sub(r"\D", "", marker) or 0) if marker[0].isdigit() else None,
                            "text": body, "checked": None}
                    t = TASK.match(body)
                    if t:
                        item["checked"] = t.group(1) != " "
                        item["text"] = t.group(2)
                    items.append(item)
                    i += 1
                elif lines[i].strip() and lines[i].startswith("  ") and items:
                    items[-1]["text"] += " " + lines[i].strip()  # pokracovani polozky
                    i += 1
                else:
                    break
            blocks.append({"type": "list", "ordered": ordered, "items": items})
            continue
        para.append(line.strip() if not line.endswith("  ") else line.strip() + "\n")
        i += 1
    flush_para()
    return blocks


# ---- radkove formatovani ------------------------------------------------------------
_INLINE = re.compile(
    r"(?P<code>`+)(?P<code_body>.+?)(?P=code)"
    r"|\[(?P<link_text>[^\]]+)\]\((?P<link_url>[^)\s]+)(?:\s+\"[^\"]*\")?\)"
    r"|(?P<auto><?(?P<auto_url>https?://[^\s<>()]+[^\s<>().,;:!?'\"])>?)"
    r"|(?P<b3>\*\*\*|___)(?P<b3_body>.+?)(?P=b3)"
    r"|(?P<b2>\*\*|__)(?P<b2_body>.+?)(?P=b2)"
    r"|(?P<st>~~)(?P<st_body>.+?)~~"
    r"|(?<![\w*])\*(?P<i1_body>[^*\s](?:[^*]*[^*\s])?)\*(?!\*)"
    r"|(?<![\w_])_(?P<i2_body>[^_\s](?:[^_]*[^_\s])?)_(?![\w_])",
    re.S)


def inline(text, code_color=None, link_color=None):
    """Markdown radku -> Pango markup (vse ostatni escapovane)."""
    out = []
    pos = 0
    text = text or ""
    for m in _INLINE.finditer(text):
        out.append(esc(text[pos:m.start()]))
        pos = m.end()
        if m.group("code"):
            body = m.group("code_body")
            if body.startswith(" ") and body.endswith(" ") and body.strip():
                body = body[1:-1]
            attrs = ' font_family="monospace"'
            if code_color:
                attrs += f' background="{code_color}"'
            out.append(f"<span{attrs}>{esc(body)}</span>")
        elif m.group("link_text") is not None:
            url = m.group("link_url")
            label = inline(m.group("link_text"), code_color, link_color)
            out.append(_link(url, label, link_color))
        elif m.group("auto"):
            url = m.group("auto_url")
            out.append(_link(url, esc(url), link_color))
        elif m.group("b3"):
            out.append(f"<b><i>{inline(m.group('b3_body'), code_color, link_color)}</i></b>")
        elif m.group("b2"):
            out.append(f"<b>{inline(m.group('b2_body'), code_color, link_color)}</b>")
        elif m.group("st"):
            out.append(f"<s>{inline(m.group('st_body'), code_color, link_color)}</s>")
        elif m.group("i1_body") is not None:
            out.append(f"<i>{inline(m.group('i1_body'), code_color, link_color)}</i>")
        elif m.group("i2_body") is not None:
            out.append(f"<i>{inline(m.group('i2_body'), code_color, link_color)}</i>")
    out.append(esc(text[pos:]))
    return "".join(out)


def _link(url, label_markup, color):
    if not re.match(r"^(https?|mailto|file):", url, re.I):
        return label_markup
    href = _esc(url, quote=True)
    if color:
        return f'<a href="{href}"><span foreground="{color}">{label_markup}</span></a>'
    return f'<a href="{href}">{label_markup}</a>'


HEADING_SIZES = {1: "x-large", 2: "large", 3: "medium", 4: "medium", 5: "medium", 6: "medium"}


def heading_markup(block, **kw):
    size = HEADING_SIZES.get(block["level"], "medium")
    return f'<span size="{size}" weight="bold">{inline(block["text"], **kw)}</span>'


def list_item_prefix(item, index):
    if item.get("checked") is not None:
        return "☑" if item["checked"] else "☐"
    if item["ordered"]:
        n = item["number"] if item["number"] is not None else index + 1
        return f"{n}."
    return ("•", "◦", "▪", "•", "◦")[item["level"] % 5]


def table_text(block, width_limit=40):
    """Tabulka jako zarovnany text (pouziva se pro kopirovani a testy)."""
    rows = [block["header"]] + block["rows"]
    ncol = max(len(r) for r in rows)
    rows = [r + [""] * (ncol - len(r)) for r in rows]
    widths = [min(width_limit, max(len(r[c]) for r in rows)) for c in range(ncol)]
    lines = []
    for n, r in enumerate(rows):
        lines.append(" | ".join(r[c][:width_limit].ljust(widths[c]) for c in range(ncol)).rstrip())
        if n == 0:
            lines.append("-+-".join("-" * w for w in widths))
    return "\n".join(lines)


def to_plain(text):
    """Text bez Markdown znacek (napr. pro nahled v historii)."""
    return re.sub(r"<[^>]+>", "", inline(text)).replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
