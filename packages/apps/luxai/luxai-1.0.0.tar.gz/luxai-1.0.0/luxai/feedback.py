"""Hlaseni chyb a napadu autorovi LuxOS z rezimu Agent (nastroj send_feedback).

Format je stejny jako v aplikaci Zpetna vazba (luxos-feedback v balicku luxos-desktop):
POST https://lux-ai.cz/api/feedback s JSON
  {"kind": "bug"|"idea"|"other", "message": str (10-8000 znaku), "contact"?: e-mail,
   "system"?: {...}, "screenshot"?: "data:image/jpeg;base64,...", "app": str, "version": str}
a hlavickou X-Lux-Client: luxos; prihlaseny ucet LuxAI se prilozi jako cookie (jinak anonymne).
Server povoli 5 hlaseni za 10 minut (chyba "rate", HTTP 429).

luxos-feedback je samostatny skript (ne modul), proto jsou sber systemovych udaju a pravidla
anonymizace prevzate sem beze zmeny (test test_feedback.py je s nim porovnava, je-li k dispozici).
Bez internetu lze hlaseni ulozit do ~/.local/share/luxos/feedback-outbox ve stejnem formatu;
aplikace Zpetna vazba ho odesle pri dalsim spusteni (luxos-feedback --send-outbox).

Modul nezavisi na GTK. Nic se neodesila bez predchoziho schvaleni uzivatelem (viz agent.py).
"""
import http.client
import json
import os
import re
import socket
import ssl
import subprocess
import time
from urllib.parse import urlsplit

from . import __version__
from .api import COOKIE, LuxError, account_origin, error_from_response, load_account, safe_origin
from .i18n import _

ENDPOINT = "/api/feedback"
CLIENT = "luxos"            # stejna hlavicka X-Lux-Client jako luxos-feedback
APP = "luxai"
KINDS = ("bug", "idea", "other")
MIN_LEN, MAX_LEN = 10, 8000
SYSTEM_MAX = 30000          # server bere nejvys ~32 KB
SHOT_WIDTH, SHOT_MAX = 1280, 1_400_000
RETRY_WAIT = 2.0
SAVE_CODES = ("network", "timeout", "unavailable")   # chyby, pri kterych lze hlaseni ulozit na pozdeji

# Chybove kody serveru (stejne texty jako v luxos-feedback)
ERRORS = {
    "rate": "You have sent many reports in a short time. Please try again later.",
    "message_length": "The message must have 10 to 8000 characters.",
    "invalid_contact": "The e-mail address does not look valid.",
    "too_large": "The report is too large. Try it without the screenshot.",
    "invalid_screenshot": "The screenshot could not be accepted. Try it without the screenshot.",
}


def outbox_dir():
    base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    return os.path.join(base, "luxos", "feedback-outbox")


# ---- systemove udaje (bez osobnich dat) - prevzato z luxos-feedback ------------------------
RE_EMAIL = re.compile(r"[\w.+-]+@[\w-]+(\.[\w-]+)+")
RE_SECRET = re.compile(r"(?i)\b(token|password|passwd|secret|cookie|session|authorization|api[_-]?key)\b(\s*[=:]\s*)\S+")
RE_LONG = re.compile(r"[A-Za-z0-9_\-+=]{32,}")   # bez "/" - cesty nechat citelne
RE_IP = re.compile(r"(?<![\w.-])\d{1,3}(\.\d{1,3}){3}(?!\w|\.\d)")
RE_MAC = re.compile(r"\b[0-9a-fA-F]{2}(:[0-9a-fA-F]{2}){5}\b")


def identity():
    """(domovska slozka, uzivatel, pocitac) - to, co se z textu odstranuje."""
    home = os.path.expanduser("~")
    return home, os.environ.get("USER") or os.path.basename(home), socket.gethostname()


def redact(text, home=None, user=None, host=None):
    """Odstrani cestu domu, jmeno uzivatele/pocitace, e-maily, IP/MAC a vse, co vypada jako tajny klic."""
    h, u, n = identity()
    home, user, host = home or h, user or u, host or n
    text = text.replace(home, "~")
    text = RE_EMAIL.sub("<email>", text)
    text = RE_SECRET.sub(lambda m: m.group(1) + m.group(2) + "<redacted>", text)
    text = RE_LONG.sub("<redacted>", text)
    text = RE_MAC.sub("<mac>", text)
    text = RE_IP.sub("<ip>", text)
    for word, repl in ((user, "<user>"), (host, "<host>")):
        if len(word) >= 3:
            text = re.sub(r"(?<![\w-])" + re.escape(word) + r"(?![\w-])", repl, text)
    return text


def log_lines(text, n=50, **who):
    lines = [redact(line, **who)[:300] for line in text.splitlines() if line.strip() and not line.startswith("-- ")]
    return lines[-n:]


def _run(*cmd, timeout=8):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip() if r.returncode == 0 else ""
    except (OSError, subprocess.TimeoutExpired):
        return ""


def _read(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return ""


def collect_system(run=_run, read=_read, env=None):
    """Slovnik presne toho, co se odesle (stejne klice jako luxos-feedback); run/read jen pro testy."""
    env = os.environ if env is None else env
    home = os.path.expanduser("~")
    osr = {}
    for line in read("/etc/os-release").splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            osr[k] = v.strip('"')
    mem = re.search(r"MemTotal:\s+(\d+)", read("/proc/meminfo"))
    cpu = re.search(r"model name\s*:\s*(.+)", read("/proc/cpuinfo"))
    gpu = [re.sub(r" \(rev .*\)$", "", line.split(": ", 1)[-1])
           for line in run("lspci").splitlines() if re.search(r"VGA|3D|Display", line)]
    pkgs = {}
    for line in run("pacman", "-Q").splitlines():
        name, _sp, ver = line.partition(" ")
        if re.match(r"^(luxos|lux$|lux-|luxai|lsl|linux$|linux-lts$|linux-zen$|mesa$|xorg-server$|xfce4-session$)", name):
            pkgs[name] = ver
    try:
        disk = os.statvfs("/")
        free = round(disk.f_bavail * disk.f_frsize / 1e9, 1)
    except OSError:
        free = 0
    try:
        uptime = int(float((read("/proc/uptime") or "0").split()[0]) // 60)
    except (ValueError, IndexError):
        uptime = 0
    info = {
        "os": osr.get("PRETTY_NAME", "LuxOS"),
        "osBuild": osr.get("BUILD_ID") or osr.get("VERSION_ID") or "",
        "kernel": os.uname().release,
        "computer": " ".join(x for x in (read("/sys/class/dmi/id/sys_vendor"),
                                          read("/sys/class/dmi/id/product_name")) if x),
        "cpu": re.sub(r"\s+", " ", cpu.group(1)) if cpu else "",
        "cpuCores": os.cpu_count() or 0,
        "gpu": gpu[:3],
        "memoryGB": round(int(mem.group(1)) / 1024 / 1024, 1) if mem else 0,
        "diskFreeGB": free,
        "session": " ".join(x for x in (env.get("XDG_CURRENT_DESKTOP", ""), env.get("XDG_SESSION_TYPE", "")) if x),
        "language": env.get("LANG", ""),
        "uptimeMin": uptime,
        "packages": pkgs,
        "userErrors": log_lines(run("journalctl", "--user", "-b", "-p", "err", "-n", "50", "--no-pager",
                                    "-o", "short", timeout=10)),
        "systemErrors": log_lines(run("journalctl", "-b", "-p", "err", "-n", "50", "--no-pager",
                                      "-o", "short", timeout=10)),
        "xsessionErrors": log_lines(read(os.path.join(home, ".xsession-errors"))),
    }
    # Systemovy zurnal muze obsahovat i radky uzivatelskeho - neposilat je dvakrat
    seen = set(info["userErrors"])
    info["systemErrors"] = [line for line in info["systemErrors"] if line not in seen]
    shrink_system(info)
    return info


def shrink_system(info, limit=SYSTEM_MAX):
    """Limit velikosti: nejdriv zkratit logy (nejdelsi seznam na polovinu, nejstarsi radky pryc)."""
    while len(json.dumps(info, ensure_ascii=False).encode()) > limit:
        longest = max(("userErrors", "systemErrors", "xsessionErrors"), key=lambda k: len(info.get(k) or []))
        if not info.get(longest):
            break
        info[longest] = info[longest][len(info[longest]) // 2 + 1:]
    return info


# ---- sestaveni hlaseni -------------------------------------------------------------------
class FeedbackError(Exception):
    """Neplatne argumenty nastroje (model je ma opravit, nic se neodesila)."""


def compose_message(title, description):
    title = re.sub(r"\s+", " ", str(title or "")).strip()
    description = str(description or "").strip()
    if title and description:
        return f"{title}\n\n{description}"
    return title or description


def build_payload(kind, title, description, contact=None, system=None, screenshot=None):
    """Telo pozadavku presne ve formatu luxos-feedback. Text i titulek se anonymizuji
    (cesty domu, e-maily, tokeny ...), kontakt zustava tak, jak ho uzivatel zadal."""
    kind = str(kind or "").strip().lower()
    if kind not in KINDS:
        raise FeedbackError("kind must be one of: bug, idea, other")
    message = redact(compose_message(title, description))
    if len(message) < MIN_LEN:
        raise FeedbackError(f"The report text is too short (at least {MIN_LEN} characters).")
    if len(message) > MAX_LEN:
        raise FeedbackError(f"The report text is too long ({len(message)} characters, at most {MAX_LEN}). "
                            "Shorten the description.")
    payload = {"kind": kind, "message": message, "app": APP, "version": __version__}
    contact = str(contact or "").strip()
    if contact:
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", contact):
            raise FeedbackError("contact_email does not look like a valid e-mail address")
        payload["contact"] = contact
    if system is not None:
        payload["system"] = system
    if screenshot:
        if not str(screenshot).startswith("data:image/"):
            raise FeedbackError("invalid screenshot")
        payload["screenshot"] = screenshot
    return payload


def describe(payload):
    """Co presne se prilozi - pro kartu potvrzeni a vysledek pro model."""
    return {"kind": payload.get("kind"), "message": payload.get("message", ""),
            "contact": payload.get("contact", ""), "system": payload.get("system"),
            "screenshot_bytes": len(payload.get("screenshot") or "")}


# ---- odeslani a fronta ---------------------------------------------------------------------
def _connection(origin, timeout):
    u = urlsplit(origin)
    if u.scheme == "https":
        return http.client.HTTPSConnection(u.hostname, u.port or 443, timeout=timeout,
                                           context=ssl.create_default_context())
    return http.client.HTTPConnection(u.hostname, u.port or 80, timeout=timeout)


def post(payload, token=None, origin=None, timeout=45):
    """Jeden pokus o odeslani; vraci odpoved serveru (dict). Chyba -> LuxError."""
    origin = safe_origin(origin) if origin else account_origin(None)
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {"X-Lux-Client": CLIENT, "User-Agent": f"luxai/{__version__}", "Accept": "application/json",
               "Content-Type": "application/json"}
    if token:
        headers["Cookie"] = f"{COOKIE}={token}"
    conn = _connection(origin, timeout)
    try:
        conn.request("POST", ENDPOINT, body=data, headers=headers)
        resp = conn.getresponse()
        raw = resp.read(65536).decode("utf-8", "replace")
    except (socket.timeout, TimeoutError):
        raise LuxError("timeout") from None
    except (OSError, http.client.HTTPException) as e:
        raise LuxError("network", 0, type(e).__name__) from None
    finally:
        conn.close()
    if resp.status >= 400:
        err = error_from_response(resp.status, raw)
        if resp.status == 429 and err.code.startswith("http_"):
            err = LuxError("rate", 429)
        raise err
    try:
        out = json.loads(raw) if raw.strip() else {}
    except ValueError:
        raise LuxError("bad_response", resp.status) from None
    return out if isinstance(out, dict) else {}


def send(payload, token=None, origin=None, timeout=45, should_stop=lambda: False):
    """Odesle hlaseni; vraci id. Pri vypadku site / chybe serveru zkusi jeste jednou (jako luxos-feedback)."""
    for attempt in (1, 2):
        try:
            return str(post(payload, token, origin, timeout).get("id") or "")
        except LuxError as e:
            retry = e.code in ("network", "timeout") or e.status >= 500
            if attempt == 2 or not retry or should_stop():
                raise
            time.sleep(RETRY_WAIT)
    return ""


def can_save(err):
    return isinstance(err, LuxError) and (err.code in SAVE_CODES or err.status >= 500)


def save_outbox(payload):
    """Ulozi hlaseni do fronty aplikace Zpetna vazba (stejny nazev a format souboru); vraci cestu."""
    d = outbox_dir()
    os.makedirs(d, mode=0o700, exist_ok=True)
    path = os.path.join(d, time.strftime("%Y%m%d-%H%M%S-") + os.urandom(4).hex() + ".json")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(payload, f, ensure_ascii=False)
    return path


def human_error(err):
    """Srozumitelna hlaska chyby odeslani (v jazyce uzivatele)."""
    code = getattr(err, "code", "")
    if code in ERRORS:
        return _(ERRORS[code])
    if code in ("network", "timeout"):
        return _("LuxOS could not reach the server. Check the internet connection.")
    if isinstance(err, LuxError) and err.is_auth:
        return err.human()
    return _("Sending failed ({0}).").format(code or getattr(err, "status", ""))


def account_for(client=None):
    """(token, origin) pro odeslani: z klienta aplikace, jinak z uctu LuxOS (nebo anonymne)."""
    if client is not None and getattr(client, "origin", None):
        return getattr(client, "token", "") or None, client.origin
    acc = load_account()
    return ((acc or {}).get("sessionToken") or None), account_origin(acc)
