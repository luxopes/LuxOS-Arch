"""Jednoduchy LaTeX -> Unicode / Pango markup pro matematiku v odpovedich (bez zavislosti).

  to_markup(tex, display=False)  -> Pango markup (escapovany), pismena promennych kurzivou
  to_text(tex)                    -> prosty Unicode text (bez znacek)
  bare_markup(text)               -> radek prozy s "holymi" prikazy LaTeXu mimo $...$ (napr.
                                     "1/π = 12 · \\sum_{k=0}^{\\infty} ..."), escapovany markup

Podporuje recka pismena, operatory a relace, \\sum \\prod \\int \\lim s mezemi (jako dolni/horni index),
\\frac, \\sqrt, ^ a _ (Unicode indexy, kdyz to jde, jinak <sup>/<sub>), \\left \\right, \\text, \\mathbb,
\\mathcal, akcenty (\\hat \\bar \\vec ...), \\binom, prostredi (\\begin{cases} ...). Neznamy prikaz se
vypise bez zpetneho lomitka. Vstup je vzdy escapovany, vystup je platny Pango markup.
"""
import re
from html import escape as _esc

GREEK = {
    "alpha": "α", "beta": "β", "gamma": "γ", "delta": "δ", "epsilon": "ϵ", "varepsilon": "ε", "zeta": "ζ",
    "eta": "η", "theta": "θ", "vartheta": "ϑ", "iota": "ι", "kappa": "κ", "lambda": "λ", "mu": "μ", "nu": "ν",
    "xi": "ξ", "omicron": "ο", "pi": "π", "varpi": "ϖ", "rho": "ρ", "varrho": "ϱ", "sigma": "σ", "varsigma": "ς",
    "tau": "τ", "upsilon": "υ", "phi": "ϕ", "varphi": "φ", "chi": "χ", "psi": "ψ", "omega": "ω",
    "Gamma": "Γ", "Delta": "Δ", "Theta": "Θ", "Lambda": "Λ", "Xi": "Ξ", "Pi": "Π", "Sigma": "Σ",
    "Upsilon": "Υ", "Phi": "Φ", "Psi": "Ψ", "Omega": "Ω",
}
SYMBOLS = {
    # operatory
    "cdot": "·", "times": "×", "div": "÷", "pm": "±", "mp": "∓", "ast": "∗", "star": "⋆", "circ": "∘",
    "bullet": "∙", "oplus": "⊕", "ominus": "⊖", "otimes": "⊗", "odot": "⊙", "wedge": "∧", "land": "∧",
    "vee": "∨", "lor": "∨", "neg": "¬", "lnot": "¬", "cap": "∩", "cup": "∪", "setminus": "∖", "nabla": "∇",
    "partial": "∂", "infty": "∞", "emptyset": "∅", "varnothing": "∅", "forall": "∀", "exists": "∃",
    "nexists": "∄", "in": "∈", "notin": "∉", "ni": "∋", "subset": "⊂", "supset": "⊃", "subseteq": "⊆",
    "supseteq": "⊇", "aleph": "ℵ", "hbar": "ℏ", "ell": "ℓ", "Re": "ℜ", "Im": "ℑ", "wp": "℘", "angle": "∠",
    "degree": "°", "prime": "′", "top": "⊤", "bot": "⊥", "perp": "⊥", "parallel": "∥", "mid": "∣",
    "dagger": "†", "ddagger": "‡", "triangle": "△", "square": "□", "checkmark": "✓",
    # relace
    "leq": "≤", "le": "≤", "geq": "≥", "ge": "≥", "neq": "≠", "ne": "≠", "approx": "≈", "equiv": "≡",
    "sim": "∼", "simeq": "≃", "cong": "≅", "propto": "∝", "ll": "≪", "gg": "≫", "prec": "≺", "succ": "≻",
    "leqslant": "⩽", "geqslant": "⩾", "doteq": "≐", "models": "⊨", "vdash": "⊢",
    # sipky
    "to": "→", "rightarrow": "→", "leftarrow": "←", "gets": "←", "leftrightarrow": "↔", "Rightarrow": "⇒",
    "Leftarrow": "⇐", "Leftrightarrow": "⇔", "implies": "⟹", "impliedby": "⟸", "iff": "⟺", "mapsto": "↦",
    "longrightarrow": "⟶", "longleftarrow": "⟵", "longmapsto": "⟼", "uparrow": "↑", "downarrow": "↓",
    "hookrightarrow": "↪", "rightleftharpoons": "⇌", "nearrow": "↗", "searrow": "↘",
    # tecky a zavorky
    "cdots": "⋯", "ldots": "…", "dots": "…", "dotsc": "…", "dotsb": "⋯", "vdots": "⋮", "ddots": "⋱",
    "langle": "⟨", "rangle": "⟩", "lceil": "⌈", "rceil": "⌉", "lfloor": "⌊", "rfloor": "⌋", "vert": "|",
    "Vert": "‖", "lvert": "|", "rvert": "|", "lVert": "‖", "rVert": "‖", "backslash": "∖",
    "lbrace": "{", "rbrace": "}", "lbrack": "[", "rbrack": "]",
    "therefore": "∴", "because": "∵", "qed": "∎", "S": "§", "P": "¶", "copyright": "©",
}
# velke operatory: meze se pisou jako indexy za symbolem
BIG_OPS = {"sum": "∑", "prod": "∏", "coprod": "∐", "int": "∫", "iint": "∬", "iiint": "∭", "oint": "∮",
           "bigcup": "⋃", "bigcap": "⋂", "bigoplus": "⨁", "bigotimes": "⨂", "bigvee": "⋁", "bigwedge": "⋀",
           "bigsqcup": "⨆"}
FUNCTIONS = {"sin", "cos", "tan", "cot", "sec", "csc", "arcsin", "arccos", "arctan", "sinh", "cosh", "tanh",
             "coth", "log", "ln", "lg", "exp", "lim", "liminf", "limsup", "max", "min", "sup", "inf", "det", "dim",
             "ker", "deg", "gcd", "lcm", "arg", "Pr", "hom", "mod", "bmod", "tr", "rank", "sgn", "sign"}
SPACES = {",": " ", ":": " ", ";": " ", " ": " ", "quad": "  ", "qquad": "    ", "!": "", "enspace": " ",
          "thinspace": " ", "medspace": " ", "thickspace": " ", "negthinspace": "", "space": " "}
IGNORED = {"left", "right", "big", "Big", "bigg", "Bigg", "bigl", "bigr", "Bigl", "Bigr", "biggl", "biggr",
           "Biggl", "Biggr", "middle", "displaystyle", "textstyle", "scriptstyle", "limits", "nolimits",
           "nonumber", "notag", "label", "tag", "rm", "it", "bf", "cal", "mathstrut", "strut", "phantom",
           "hphantom", "vphantom", "boxed", "underbrace", "overbrace", "color", "textcolor", "cancel",
           "begin", "end", "operatorname"}  # begin/end/operatorname maji vlastni obsluhu
TEXT_CMDS = {"text", "textrm", "textnormal", "mathrm", "mbox", "textup", "mathup", "operatorname", "textsf",
             "mathsf", "texttt", "mathtt", "hbox"}
BOLD_CMDS = {"textbf", "mathbf", "boldsymbol", "bm", "pmb"}
ITALIC_CMDS = {"textit", "mathit", "emph"}
ACCENTS = {"hat": "\u0302", "widehat": "\u0302", "bar": "\u0304", "overline": "\u0305", "vec": "\u20d7",
           "dot": "\u0307", "ddot": "\u0308", "tilde": "\u0303", "widetilde": "\u0303", "check": "\u030c",
           "breve": "\u0306", "acute": "\u0301", "grave": "\u0300", "underline": "\u0332", "mathring": "\u030a"}
BLACKBOARD = {"N": "ℕ", "Z": "ℤ", "Q": "ℚ", "R": "ℝ", "C": "ℂ", "P": "ℙ", "H": "ℍ", "E": "𝔼", "F": "𝔽",
              "1": "𝟙", "0": "𝟘"}
SUP = dict(zip("0123456789+-=()niabcdefghjklmoprstuvwxyzABDEGHIJKLMNOPRTUVW−αβγδεθιφχ",
               "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁼⁽⁾ⁿⁱᵃᵇᶜᵈᵉᶠᵍʰʲᵏˡᵐᵒᵖʳˢᵗᵘᵛʷˣʸᶻᴬᴮᴰᴱᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᴿᵀᵁⱽᵂ⁻ᵅᵝᵞᵟᵋᶿᶥᵠᵡ"))
SUP.update({"′": "′", "*": "*", "∗": "*", " ": ""})
SUB = dict(zip("0123456789+-=()aehijklmnoprstuvx−βγρφχ", "₀₁₂₃₄₅₆₇₈₉₊₋₌₍₎ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓ₋ᵦᵧᵨᵩᵪ"))
SUB.update({" ": ""})
DELIMS = {"(": "(", ")": ")", "[": "[", "]": "]", "|": "|", ".": "", "/": "/", "<": "⟨", ">": "⟩"}
ENV_DROP = {"aligned", "align", "align*", "gathered", "gather", "gather*", "equation", "equation*", "split",
            "array", "matrix", "eqnarray", "multline"}
BRACKET_ENVS = {"pmatrix": ("(", ")"), "bmatrix": ("[", "]"), "Bmatrix": ("{", "}"), "vmatrix": ("|", "|"),
                "Vmatrix": ("‖", "‖"), "cases": ("{ ", ""), "dcases": ("{ ", "")}

_CMD = re.compile(r"\\([A-Za-z]+\*?|.)")
KNOWN = set(GREEK) | set(SYMBOLS) | set(BIG_OPS) | FUNCTIONS | {"frac", "dfrac", "tfrac", "cfrac", "sqrt",
                                                               "binom", "dbinom", "tbinom", "mathbb", "mathcal",
                                                               "mathfrak", "not", "infty"} | TEXT_CMDS | set(ACCENTS)
# Holy LaTeX v proze: aspon jeden znamy prikaz (\sum, \frac, \alpha ...), ne napr. cesta C:\Users
_BARE_HINT = re.compile(r"\\(" + "|".join(sorted((re.escape(k) for k in KNOWN), key=len, reverse=True)) +
                        r")(?![A-Za-z])|[\w)\]]\^(?:\{|\(|\w)")


def esc(s):
    return _esc(s, quote=False)


class _Node:
    """Kus vystupu: markup a prosty text (pro rozhodnuti o Unicode indexech a zavorkach)."""
    __slots__ = ("markup", "plain", "simple", "big")

    def __init__(self, markup="", plain="", simple=True, big=False):
        self.markup, self.plain, self.simple, self.big = markup, plain, simple, big


def _join(nodes):
    return _Node("".join(n.markup for n in nodes), "".join(n.plain for n in nodes),
                 all(n.simple for n in nodes))


class _Parser:
    def __init__(self, src, loose=False):
        self.s = src
        self.i = 0
        self.loose = loose          # proza s holymi prikazy: bez kurzivy, '-' zustava, '{' doslova

    # ---- zakladni cteni --------------------------------------------------------------------
    def peek(self):
        return self.s[self.i] if self.i < len(self.s) else ""

    def skip_ws(self):
        while self.i < len(self.s) and self.s[self.i] in " \t\n":
            self.i += 1

    def parse(self, stop=None):
        """Posloupnost atomu az do konce nebo znaku stop ('}' / ']')."""
        nodes = []
        while self.i < len(self.s):
            c = self.s[self.i]
            if stop and c == stop:
                break
            if c in "^_":
                self.i += 1
                while nodes and nodes[-1].plain == " ":
                    nodes.pop()             # "x ^ 2" -> zaklad je x, ne mezera
                self.skip_ws()
                base = nodes.pop() if nodes else _Node()
                nodes.append(self.script(base, c))
                continue
            n = self.atom(stop)
            if n is not None:
                nodes.append(n)
        return _join(nodes)

    def group(self):
        """Argument prikazu: {..} nebo jeden atom."""
        self.skip_ws()
        if self.peek() == "{":
            self.i += 1
            n = self.parse("}")
            if self.peek() == "}":
                self.i += 1
            return n
        if not self.peek():
            return _Node()
        return self.atom(None) or _Node()

    def raw_group(self):
        """Doslovny obsah {..} (pro \\text, \\begin)."""
        self.skip_ws()
        if self.peek() != "{":
            m = _CMD.match(self.s, self.i)
            if m:
                self.i = m.end()
                return m.group(1)
            c = self.peek()
            self.i += 1 if c else 0
            return c
        depth, start = 0, self.i
        while self.i < len(self.s):
            ch = self.s[self.i]
            if ch == "\\":
                self.i += 2
                continue
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    self.i += 1
                    return self.s[start + 1:self.i - 1]
            self.i += 1
        return self.s[start + 1:]

    def optional(self):
        """Volitelny argument [..] (\\sqrt[n]{x})."""
        if self.peek() != "[":
            return None
        self.i += 1
        n = self.parse("]")
        if self.peek() == "]":
            self.i += 1
        return n

    # ---- indexy ----------------------------------------------------------------------------------
    def script(self, base, kind):
        if self.loose and self.peek() == "(":
            arg = self.paren_group()
        elif self.loose and self.peek().isdigit():
            m = re.match(r"\d+", self.s[self.i:])      # v proze 2^10 = 2¹⁰ (LaTeX by vzal jen 1)
            self.i += m.end()
            arg = _Node(m.group(0), m.group(0))
        else:
            arg = self.group()
        table, tag = (SUP, "sup") if kind == "^" else (SUB, "sub")
        if arg.simple and arg.plain and all(ch in table for ch in arg.plain):
            uni = "".join(table[ch] for ch in arg.plain)
            return _Node(base.markup + esc(uni), base.plain + uni, base.simple, base.big)
        return _Node(f"{base.markup}<{tag}>{arg.markup}</{tag}>", base.plain + arg.plain, False, base.big)

    def paren_group(self):
        """V proze x^(3k+3/2): obsah zavorek je cely exponent (zavorky jen seskupuji)."""
        depth, start = 0, self.i
        j = self.i
        while j < len(self.s):
            if self.s[j] == "(":
                depth += 1
            elif self.s[j] == ")":
                depth -= 1
                if depth == 0:
                    inner = _Parser(self.s[start + 1:j], self.loose).parse()
                    self.i = j + 1
                    return inner
            j += 1
        self.i += 1
        return _Node("(", "(")

    # ---- atomy -------------------------------------------------------------------------------
    def atom(self, stop):
        c = self.s[self.i]
        if c == "\\":
            return self.command()
        if c == "{":
            if self.loose:
                self.i += 1
                return _Node("{", "{")
            self.i += 1
            n = self.parse("}")
            if self.peek() == "}":
                self.i += 1
            return n
        if c == "}":
            self.i += 1
            return None if not self.loose else _Node("}", "}")
        if c == "&" and not self.loose:
            self.i += 1
            return _Node("\u2003", "\u2003")      # zarovnani (cases, aligned): siroka mezera
        if c == "~" and not self.loose:
            self.i += 1
            return _Node(" ", " ")
        if c == "'" and not self.loose:
            self.i += 1
            return _Node("′", "′")
        if c == "-" and not self.loose:
            self.i += 1
            return _Node("−", "−")
        if c == "*" and not self.loose:
            self.i += 1
            return _Node("∗", "∗")
        if c.isalpha() and c.isascii() and not self.loose:
            j = self.i
            while j < len(self.s) and self.s[j].isalpha() and self.s[j].isascii():
                j += 1
            word = self.s[self.i:j]
            self.i = j
            return _Node(f"<i>{esc(word)}</i>", word, True)
        if c in " \n\t" and not self.loose:
            while self.i < len(self.s) and self.s[self.i] in " \n\t":
                self.i += 1
            # mezeru autora zachovat jako jednu (LaTeX je ignoruje, ale "a + b" se cte lepe nez "a+b")
            return _Node(" ", " ")
        self.i += 1
        return _Node(esc(c), c)

    def command(self):
        m = _CMD.match(self.s, self.i)
        if not m:
            self.i += 1
            return _Node("\\", "\\")
        name = m.group(1)
        self.i = m.end()
        if name == "\\":
            return _Node("\n", "\n", False)
        if name in SPACES:
            return _Node(SPACES[name], SPACES[name])
        if name in "{}%$&#_|":
            return _Node(esc(name), name)
        if name in GREEK or name in ("partial", "nabla"):
            if not self.loose and re.match(r"[ \t]+[A-Za-z0-9]", self.s[self.i:]):
                self.skip_ws()          # "\\alpha x" = αx, "\\partial f" = ∂f (mezera jen ukoncuje prikaz)
            if name not in GREEK:
                return self.op(SYMBOLS[name])
            ch = GREEK[name]
            return _Node(ch if self.loose or name[0].isupper() else f"<i>{ch}</i>", ch)
        if name in SYMBOLS:
            return self.op(SYMBOLS[name])
        if name in BIG_OPS:
            ch = BIG_OPS[name]
            return _Node(esc(ch), ch, True, True)
        if name in FUNCTIONS:
            word = "mod" if name == "bmod" else name
            if name in ("mod", "bmod"):
                return _Node(" mod ", " mod ")
            return _Node(esc(word), word, True, name in ("lim", "max", "min", "sup", "inf", "liminf", "limsup"))
        if name in ("frac", "dfrac", "tfrac", "cfrac"):
            return self.frac(self.group(), self.group())
        if name in ("binom", "dbinom", "tbinom"):
            n, k = self.group(), self.group()
            return _Node(f"(<sup>{n.markup}</sup><sub>{k.markup}</sub>)", f"C({n.plain}, {k.plain})", False)
        if name == "sqrt":
            idx = self.optional()
            arg = self.group()
            root = "√"
            if idx is not None:
                deg = {"2": "", "3": "∛", "4": "∜"}.get(idx.plain)
                if deg is not None:
                    root = deg or "√"
                elif all(ch in SUP for ch in idx.plain):
                    root = "".join(SUP[ch] for ch in idx.plain) + "√"
                else:
                    root = f"<sup>{idx.markup}</sup>√"
            body = arg.markup if _atomic(arg.plain) else f"({arg.markup})"
            plain = arg.plain if _atomic(arg.plain) else f"({arg.plain})"
            return _Node(root + body, "√" + plain, arg.simple)
        if name in TEXT_CMDS:
            txt = self.raw_group()
            if name == "operatorname":
                return _Node(esc(txt.replace("*", "")), txt, True, True)
            return _Node(esc(_strip_text(txt)), _strip_text(txt), True)
        if name in BOLD_CMDS:
            arg = self.group()
            return _Node(f"<b>{arg.markup}</b>", arg.plain, arg.simple)
        if name in ITALIC_CMDS:
            arg = self.group()
            return _Node(f"<i>{arg.markup}</i>", arg.plain, arg.simple)
        if name == "mathbb":
            txt = _strip_text(self.raw_group())
            out = "".join(BLACKBOARD.get(ch, ch) for ch in txt)
            return _Node(esc(out), out)
        if name in ("mathcal", "mathscr"):
            txt = _strip_text(self.raw_group())
            out = "".join(_script_letter(ch) for ch in txt)
            return _Node(esc(out), out)
        if name == "mathfrak":
            txt = _strip_text(self.raw_group())
            return _Node(esc(txt), txt)
        if name in ACCENTS:
            arg = self.group()
            mark = ACCENTS[name]
            if not arg.plain:
                return _Node(esc(name), name)       # akcent bez argumentu: jen jmeno
            if len(arg.plain) == 1 or name in ("overline", "underline"):
                plain = "".join(ch + mark for ch in arg.plain) if len(arg.plain) > 1 else arg.plain + mark
                if arg.markup.startswith("<i>") and len(arg.plain) == 1:
                    return _Node(f"<i>{esc(plain)}</i>", plain)
                return _Node(esc(plain), plain)
            return _Node(arg.markup + esc(mark), arg.plain + mark, arg.simple)
        if name == "not":
            nxt = self.group()
            neg = {"=": "≠", "<": "≮", ">": "≯", "≤": "≰", "≥": "≱", "∈": "∉", "⊂": "⊄", "⊆": "⊈", "∼": "≁",
                   "≡": "≢", "≈": "≉", "∃": "∄", "|": "∤", "∣": "∤"}.get(nxt.plain.strip())
            if neg:
                return self.op(neg)
            return _Node(nxt.markup + "\u0338", nxt.plain + "\u0338")
        if name in ("left", "right", "bigl", "bigr", "Bigl", "Bigr", "big", "Big", "bigg", "Bigg", "biggl",
                    "biggr", "Biggl", "Biggr", "middle"):
            self.skip_ws()
            m2 = _CMD.match(self.s, self.i)
            if m2:
                d = m2.group(1)
                if d in ("{", "}", "|"):
                    self.i = m2.end()
                    return _Node(esc(d if d != "|" else "‖"), d)
                return None           # \left\langle -> zpracuje dalsi prikaz
            c = self.peek()
            if c in DELIMS:
                self.i += 1
                return _Node(esc(DELIMS[c]), DELIMS[c])
            return None
        if name == "begin":
            env = self.raw_group()
            if env in ("array", "tabular"):
                if self.peek() == "{":
                    self.raw_group()       # specifikace sloupcu
            if env in BRACKET_ENVS:
                o = BRACKET_ENVS[env][0]
                return _Node(esc(o), o)
            return None
        if name == "end":
            env = self.raw_group()
            if env in BRACKET_ENVS:
                c = BRACKET_ENVS[env][1]
                return _Node(esc(c), c) if c else None
            return None
        if name in ("color", "textcolor"):
            self.raw_group()
            return self.group() if name == "textcolor" else None
        if name in ("label", "tag", "phantom", "hphantom", "vphantom"):
            self.raw_group()
            return None
        if name in ("boxed", "underbrace", "overbrace", "cancel"):
            return self.group()
        if name in IGNORED:
            return None
        # neznamy prikaz: jmeno bez zpetneho lomitka
        return _Node(esc(name), name)

    def op(self, ch):
        return _Node(esc(ch), ch)

    def frac(self, a, b):
        if re.fullmatch(r"\d{1,3}", a.plain) and re.fullmatch(r"\d{1,3}", b.plain):
            num = "".join(SUP[d] for d in a.plain)
            den = "".join(SUB[d] for d in b.plain)
            return _Node(num + "⁄" + den, a.plain + "/" + b.plain)
        am = a.markup if _atomic(a.plain) else f"({a.markup})"
        bm = b.markup if _atomic(b.plain) else f"({b.markup})"
        ap = a.plain if _atomic(a.plain) else f"({a.plain})"
        bp = b.plain if _atomic(b.plain) else f"({b.plain})"
        return _Node(f"{am}/{bm}", f"{ap}/{bp}", a.simple and b.simple)


def _atomic(plain):
    """Staci bez zavorek? Jedno cislo/promenna, f(x), (a+b) nebo (3k)! ano; a+b, x y, (3k)!(k!)³ ne."""
    p = plain.strip()
    if not p:
        return True
    if re.search(r"[\s+\-−±∓=<>≤≥≠·×,/÷]", p) and not (p[0] in "([{" and _closes_at_end(_core(p))):
        return False
    core = _core(p)
    j = next((k for k, ch in enumerate(core) if ch in "([{"), None)
    if j is None:
        return True
    return bool(re.fullmatch(r"\w*", core[:j])) and _closes_at_end(core[j:])


def _core(p):
    """Bez koncovych !, carek a hornich indexu ((3k)!² -> (3k))."""
    return p.rstrip("!′'" + "".join(SUP.values()))


def _closes_at_end(p):
    pairs = {"(": ")", "[": "]", "{": "}"}
    depth = 0
    for i, ch in enumerate(p):
        if ch in pairs:
            depth += 1
        elif ch in pairs.values():
            depth -= 1
            if depth == 0 and i != len(p) - 1:
                return False
    return depth == 0 and p[-1] == pairs[p[0]]


def _strip_text(txt):
    return re.sub(r"\\([{}%$&#_ ])", r"\1", txt).replace("~", " ")


def _script_letter(ch):
    table = {"A": "𝒜", "B": "ℬ", "C": "𝒞", "D": "𝒟", "E": "ℰ", "F": "ℱ", "G": "𝒢", "H": "ℋ", "I": "ℐ",
             "J": "𝒥", "K": "𝒦", "L": "ℒ", "M": "ℳ", "N": "𝒩", "O": "𝒪", "P": "𝒫", "Q": "𝒬", "R": "ℛ",
             "S": "𝒮", "T": "𝒯", "U": "𝒰", "V": "𝒱", "W": "𝒲", "X": "𝒳", "Y": "𝒴", "Z": "𝒵"}
    return table.get(ch, ch)


_REL = "=<>≤≥≠≈≡∼≃≅∝≪≫→←↔⇒⇐⇔⟹⟸⟺↦∈∉⊂⊃⊆⊇±∓×÷·+−"
_SPACE_AROUND = re.compile(r"[ \t]*([=<>≤≥≠≈≡∼≃≅∝≪≫→←↔⇒⇐⇔⟹⟸⟺↦∈∉⊂⊃⊆⊇])\s*")


def _spacing(markup):
    """Mezery kolem relaci (v markupu; uvnitr indexu <sup>/<sub> ne)."""
    out, depth = [], 0
    for part in re.split(r"(<[^>]+>)", markup):
        if part.startswith("<"):
            if part in ("<sup>", "<sub>"):
                depth += 1
            elif part in ("</sup>", "</sub>"):
                depth -= 1
            out.append(part)
        elif depth == 0:
            out.append(_SPACE_AROUND.sub(r" \1 ", part.replace("&lt;", "<").replace("&gt;", ">"))
                       .replace("<", "&lt;").replace(">", "&gt;"))
        else:
            out.append(part)
    return re.sub(r"[ \t]{2,}", " ", "".join(out)).strip(" ")


def to_markup(tex, display=False):
    """LaTeX (bez $) -> Pango markup."""
    tex = (tex or "").strip()
    if not tex:
        return ""
    n = _Parser(tex).parse()
    markup = _spacing(n.markup)
    lines = [ln.strip() for ln in markup.split("\n")]
    return "\n".join(ln for ln in lines if ln) if display else " ".join(ln for ln in lines if ln)


def to_text(tex, display=False):
    """Prosty text (pro testy a kopirovani): markup bez znacek, Unicode indexy zustavaji."""
    m = to_markup(tex, display)
    return _unmarkup(m)


def _unmarkup(m):
    m = re.sub(r"<sup>(.*?)</sup>", r"^(\1)", m)
    m = re.sub(r"<sub>(.*?)</sub>", r"_(\1)", m)
    m = re.sub(r"<[^>]+>", "", m)
    return m.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")


def has_bare_latex(text):
    return bool(_BARE_HINT.search(text or ""))


def bare_markup(text):
    """Proza s holymi prikazy LaTeXu -> markup: prevede jen prikazy, {..} za nimi a ^/_ indexy
    (x^2, x_{i}, (−1)^k, 640320^(3k+3/2)); ostatni text zustane (escapovany)."""
    p = _Parser(text or "", loose=True)
    s = p.s
    nodes = []
    while p.i < len(s):
        c = s[p.i]
        if c in "^_" and nodes and nodes[-1].plain.strip() and _script_ok(s, p.i, c):
            p.i += 1
            nodes.append(p.script(nodes.pop(), c))
            continue
        if c == "\\":
            m = _CMD.match(s, p.i)
            name = m.group(1) if m else ""
            if name and (name in KNOWN or name in IGNORED or name in SPACES or name in ("{", "}", "\\")):
                n = p.command()
                if n is not None:
                    nodes.append(n)
                continue
        # obycejny text: souvisle useky bez mezer (posledni usek je zaklad pripadneho indexu)
        m = _BARE_CHUNK.match(s, p.i)
        chunk = m.group(0) if m and m.end() > p.i else c
        nodes.append(_Node(esc(chunk), chunk))
        p.i += len(chunk)
    return "".join(n.markup for n in nodes)


_BARE_CHUNK = re.compile(r"\s+|[^\s\\^_]+")


def _script_ok(s, i, kind):
    """V proze: ^ vzdy pred {..}, (..) nebo znakem; _ jen x_{..}, x_1 (ne snake_case)."""
    nxt = s[i + 1] if i + 1 < len(s) else ""
    if not nxt or nxt in " \n\t":
        return False
    if kind == "^":
        return i > 0 and s[i - 1] not in " \n\t"
    if nxt == "{":
        return True
    word = re.search(r"\\?[A-Za-z0-9]+$", s[:i])
    if word and not word.group(0).startswith("\\") and len(word.group(0)) > 1 and not word.group(0).isdigit():
        return False            # snake_case, file_name
    after = s[i + 2] if i + 2 < len(s) else ""
    return nxt.isalnum() and not (after.isalnum() or after == "_")


# ---- vyhledani matematiky v textu (pro markdown.inline) --------------------------------------------
# $$..$$, \[..\], \(..\), $..$ (pravidla pandoc: za otviracim $ neni mezera, pred zaviracim neni mezera
# a za nim neni cislice - "$5 a $10" neni matematika)
INLINE_MATH = (r"(?P<mdd>\$\$)(?P<mdd_body>.+?)\$\$"
               r"|\\\[(?P<mbr_body>.+?)\\\]"
               r"|\\\((?P<mpar_body>.+?)\\\)"
               r"|(?<![\\$\w])\$(?P<md_body>[^\s$](?:[^$\n]*?[^\s$\\])?)\$(?![\d$])")
