"""LuxAI - okno Nastaveni (ve stylu Nastaveni macOS a ostatnich aplikaci LuxOS):
vlevo kategorie, vpravo skupiny radku. Kazda zmena se hned ulozi do ~/.config/luxai/settings.json
a hlavni okno ji pres on_setting_changed() okamzite pouzije (opravneni agenta, model, motiv ...).
"""
import os

from gi.repository import GLib, Gtk, Pango

from .i18n import _
from .safety import normalize_policy

SETTINGS_CSS = """
.settings-side { background-color: @lx_side; border-right: 1px solid @lx_border; }
.settings-side list { background: transparent; }
.settings-side list row { border-radius: 8px; margin: 1px 8px; padding: 7px 10px; }
.settings-side list row:selected { background-color: alpha(@lx_accent, 0.85); color: white; }
.settings-page { background-color: @lx_bg; }
.page-title { font-size: 20px; font-weight: 800; margin: 18px 4px 2px; }
.group { border-radius: 12px; border: 1px solid @lx_border; background-color: @lx_card; }
.group-title { font-weight: 700; font-size: 13px; margin: 16px 4px 6px; }
.group-foot { font-size: 11px; color: @lx_dim; margin: 6px 6px 0; }
.srow { padding: 9px 14px; }
.srow-sep { border-top: 1px solid @lx_border; }
.hint { font-size: 11px; color: @lx_dim; }
.locked { color: @lx_dim; }
.folder-path { font-family: monospace; font-size: 12px; }
.instructions { border: 1px solid @lx_border; border-radius: 8px; background-color: @lx_input; padding: 6px; }
.instructions textview, .instructions textview text { background-color: transparent; color: @lx_fg; }
.kbd { font-family: monospace; font-size: 12px; padding: 2px 8px; border-radius: 6px;
       border: 1px solid @lx_border; background-color: @lx_code; }
button.destructive { background-image: none; background-color: @lx_danger; color: white; border: none; }
button.destructive label { color: white; text-shadow: none; }
.profile-name { font-weight: 800; font-size: 14px; }
.avatar-big { border-radius: 999px; min-width: 44px; min-height: 44px; color: white; font-weight: 800;
              font-size: 18px; background-image: linear-gradient(135deg, #3d6bff, #8a4dff); }
button.profile { padding: 4px 6px; border-radius: 10px; border: none; background: none; box-shadow: none; }
button.profile:hover { background-color: alpha(@lx_fg, 0.06); }
"""

LANGUAGE_CHOICES = [("cs", "Čeština"), ("sk", "Slovenčina"), ("en", "English"), ("de", "Deutsch"),
                    ("pl", "Polski"), ("fr", "Français"), ("es", "Español"), ("it", "Italiano"),
                    ("uk", "Українська")]


def _icon(*names):
    theme = Gtk.IconTheme.get_default()
    for n in names:
        if theme.has_icon(n):
            return Gtk.Image.new_from_icon_name(n, Gtk.IconSize.MENU)
    return Gtk.Image.new_from_icon_name(names[-1], Gtk.IconSize.MENU)


def _cls(widget, *classes):
    ctx = widget.get_style_context()
    for c in classes:
        ctx.add_class(c)
    return widget


def _label(text, *classes, wrap=False, xalign=0.0, chars=0):
    lb = Gtk.Label(label=text, xalign=xalign)
    if wrap:
        lb.set_line_wrap(True)
        lb.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
    if chars:
        lb.set_max_width_chars(chars)
    return _cls(lb, *classes)


def home_short(path):
    home = os.path.expanduser("~")
    return "~" + path[len(home):] if path == home or path.startswith(home + "/") else path


class Group(Gtk.Box):
    """Skupina radku (zaoblena karta) s nadpisem."""

    def __init__(self, page, title, foot=None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        if title:
            page.pack_start(_label(title, "group-title"), False, False, 0)
        _cls(self, "group")
        page.pack_start(self, False, False, 0)
        if foot:
            page.pack_start(_label(foot, "group-foot", wrap=True, chars=80), False, False, 0)
        self.rows = 0

    def row(self, title, widget=None, hint=None):
        box = _cls(Gtk.Box(spacing=12), "srow")
        if self.rows:
            _cls(box, "srow-sep")
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER, spacing=1)
        t = _label(title, wrap=True)
        text.pack_start(t, False, False, 0)
        if hint:
            text.pack_start(_label(hint, "hint", wrap=True, chars=56), False, False, 0)
        box.pack_start(text, True, True, 0)
        if widget is not None:
            widget.set_valign(Gtk.Align.CENTER)
            box.pack_end(widget, False, False, 0)
        self.pack_start(box, False, False, 0)
        self.rows += 1
        return box

    def widget_row(self, widget):
        box = _cls(Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6), "srow")
        if self.rows:
            _cls(box, "srow-sep")
        box.pack_start(widget, False, False, 0)
        self.pack_start(box, False, False, 0)
        self.rows += 1
        return box


class SettingsWindow(Gtk.Window):
    PAGES = [("general", "General"), ("ai", "AI behaviour"), ("agent", "Agent permissions"),
             ("privacy", "Privacy & history"), ("shortcuts", "Keyboard shortcuts")]

    def __init__(self, win):
        super().__init__(title=_("Settings"), transient_for=win)
        _cls(self, "luxai")
        self.win = win
        self.settings = win.settings
        self.set_default_size(860, 620)
        self.set_position(Gtk.WindowPosition.CENTER_ON_PARENT)
        self.set_type_hint(1)  # Gdk.WindowTypeHint.DIALOG
        hb = Gtk.HeaderBar(title=_("Settings"))
        hb.set_show_close_button(True)
        self.set_titlebar(hb)
        self._save_id = 0
        self._instr_id = 0
        self.widgets = {}

        paned = Gtk.Box()
        self.add(paned)
        side = _cls(Gtk.Box(orientation=Gtk.Orientation.VERTICAL), "settings-side")
        side.set_size_request(210, -1)
        self.nav = Gtk.ListBox()
        self.nav.set_selection_mode(Gtk.SelectionMode.BROWSE)
        self.nav.set_margin_top(10)
        side.pack_start(self.nav, True, True, 0)
        paned.pack_start(side, False, False, 0)
        self.stack = _cls(Gtk.Stack(), "settings-page")
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        paned.pack_start(self.stack, True, True, 0)

        icons = {"general": ("preferences-system-symbolic", "emblem-system-symbolic"),
                 "ai": ("starred-symbolic", "dialog-information-symbolic"),
                 "agent": ("security-high-symbolic", "dialog-password-symbolic"),
                 "privacy": ("preferences-system-privacy-symbolic", "user-trash-symbolic"),
                 "shortcuts": ("preferences-desktop-keyboard-shortcuts-symbolic", "input-keyboard-symbolic")}
        titles = {"general": _("General"), "ai": _("AI behaviour"), "agent": _("Agent permissions"),
                  "privacy": _("Privacy & history"), "shortcuts": _("Keyboard shortcuts")}
        builders = {"general": self._page_general, "ai": self._page_ai, "agent": self._page_agent,
                    "privacy": self._page_privacy, "shortcuts": self._page_shortcuts}
        for key, _title in self.PAGES:
            row = Gtk.ListBoxRow()
            row.page = key
            b = Gtk.Box(spacing=10)
            b.pack_start(_icon(*icons[key]), False, False, 0)
            b.pack_start(_label(titles[key]), False, False, 0)
            row.add(b)
            self.nav.add(row)
            self.stack.add_named(self._page(titles[key], builders[key]), key)
        self.nav.connect("row-selected", lambda _l, r: r is not None and self.stack.set_visible_child_name(r.page))
        self.nav.select_row(self.nav.get_row_at_index(0))
        self.connect("key-press-event", self._on_key)
        self.connect("destroy", lambda *_a: self._flush())
        self.show_all()

    # ---- obecne ----------------------------------------------------------------------
    def _on_key(self, _w, ev):
        from gi.repository import Gdk
        if ev.keyval == Gdk.KEY_Escape:
            self.close()
            return True
        return False

    def show_page(self, key):
        for row in self.nav.get_children():
            if row.page == key:
                self.nav.select_row(row)

    def _page(self, title, build):
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        outer.set_margin_start(28)
        outer.set_margin_end(28)
        outer.set_margin_bottom(24)
        outer.pack_start(_label(title, "page-title"), False, False, 0)
        build(outer)
        sw.add(outer)
        return sw

    def _set(self, key, value):
        self.settings[key] = value
        self._schedule_save()
        self.win.on_setting_changed(key)

    def _set_agent(self, key, value):
        pol = dict(self.settings["agent"])
        pol[key] = value
        self.settings["agent"] = normalize_policy(pol)
        self._schedule_save()
        self.win.on_setting_changed("agent")

    def _schedule_save(self):
        if self._save_id:
            GLib.source_remove(self._save_id)
        self._save_id = GLib.timeout_add(300, self._save_now)

    def _save_now(self):
        self._save_id = 0
        self.settings.save()
        return False

    def _flush(self):
        if self._instr_id:
            GLib.source_remove(self._instr_id)
            self._instr_save()
        if self._save_id:
            GLib.source_remove(self._save_id)
            self._save_now()

    def combo(self, options, current, on_change):
        c = Gtk.ComboBoxText()
        for key, text in options:
            c.append(key, text)
        c.set_active_id(current)
        c.connect("changed", lambda w: w.get_active_id() and on_change(w.get_active_id()))
        return c

    def switch(self, active, on_change, sensitive=True):
        s = Gtk.Switch()
        s.set_active(bool(active))
        s.set_sensitive(sensitive)
        s.connect("notify::active", lambda w, _p: on_change(w.get_active()))
        return s

    # ---- Obecne -------------------------------------------------------------------------
    def _page_general(self, page):
        g = Group(page, _("Appearance"))
        g.row(_("Theme"), self.combo([("system", _("Same as system")), ("light", _("Light")), ("dark", _("Dark"))],
                                     self.settings["theme"], lambda v: self._set("theme", v)))
        g = Group(page, _("Messages"))
        g.row(_("Send message with"), self.combo([("enter", _("Enter (Shift+Enter for a new line)")),
                                                  ("ctrl_enter", _("Ctrl+Enter (Enter for a new line)"))],
                                                 self.settings["send_key"], lambda v: self._set("send_key", v)))
        g.row(_("Notifications"), self.switch(self.settings["notify"], lambda v: self._set("notify", v)),
              _("Notify me when LuxAI finishes an answer or needs my approval while the window is in the "
                "background."))
        g = Group(page, _("Start"))
        g.row(_("Mode for new conversations"),
              self.combo([("chat", _("Chat")), ("agent", _("Agent"))], self.settings["mode"],
                         lambda v: self._set("mode", v)),
              _("LuxAI also remembers the mode you used last."))

    # ---- Chovani AI ------------------------------------------------------------------------
    def _page_ai(self, page):
        g = Group(page, _("Model"))
        self.widgets["model"] = self.combo([("flash", _("Flash – smarter")), ("lite", _("Lite – faster, larger limit"))],
                                           self.settings["model"], lambda v: self._set("model", v))
        g.row(_("Default model"), self.widgets["model"], _("Used for new conversations. You can switch it any time "
                                                          "in the toolbar."))
        for m, name in (("flash", "Flash"), ("lite", "Lite")):
            sw = self.switch(self.settings["vision"].get(m), lambda v, m=m: self._set_vision(m, v))
            self.widgets["vision_" + m] = sw
            g.row(_("{0} can see images").format(name), sw,
                  _("Attach screenshots in Agent mode. Turn on only if the model supports images."))

        g = Group(page, _("Answers"))
        g.row(_("Response style"), self.combo(
            [("balanced", _("Balanced")), ("concise", _("Concise")), ("detailed", _("Detailed")),
             ("technical", _("Technical")), ("friendly", _("Friendly"))],
            self.settings["style"], lambda v: self._set("style", v)))
        g.row(_("Answer length"), self.combo(
            [("short", _("Short")), ("normal", _("Normal")), ("long", _("Long"))],
            self.settings["answer_length"], lambda v: self._set("answer_length", v)),
            _("Maximum length of one answer. Agent mode always keeps enough room for its tools."))
        g.row(_("Language"), self.combo([("auto", _("Same as my message"))] + LANGUAGE_CHOICES,
                                        self.settings["language"], lambda v: self._set("language", v)))
        box = Gtk.Box(spacing=8)
        scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0.0, 1.5, 0.1)
        scale.set_value(self.settings["temperature"])
        scale.set_digits(1)
        scale.set_value_pos(Gtk.PositionType.RIGHT)
        scale.set_size_request(170, -1)
        scale.set_sensitive(self.settings["temperature_custom"])
        scale.connect("value-changed", lambda s: self._set("temperature", round(s.get_value(), 2)))
        sw = self.switch(self.settings["temperature_custom"],
                         lambda v: (scale.set_sensitive(v), self._set("temperature_custom", v)))
        box.pack_start(scale, False, False, 0)
        box.pack_start(sw, False, False, 0)
        g.row(_("Creativity (temperature)"), box,
              _("Off = the model's default. Lower is more precise, higher more creative. Applied only if the model "
                "supports it."))

        g = Group(page, _("Custom instructions"),
                  _("Added to every conversation. They cannot give the agent more permissions than set in Agent "
                    "permissions."))
        frame = _cls(Gtk.ScrolledWindow(), "instructions")
        frame.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        frame.set_size_request(-1, 110)
        tv = Gtk.TextView()
        tv.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        tv.get_buffer().set_text(self.settings["instructions"])
        tv.get_buffer().connect("changed", self._on_instructions)
        self.instructions = tv
        frame.add(tv)
        g.widget_row(_label(_("What should LuxAI know about you or how should it answer? E.g. \"Call me Tom. "
                              "Prefer metric units and short answers.\""), "hint", wrap=True, chars=80))
        g.widget_row(frame)

        g = Group(page, _("Conversations"))
        g.row(_("Name conversations automatically"),
              self.switch(self.settings["auto_title"], lambda v: self._set("auto_title", v)),
              _("After the first answer the fast Lite model suggests a short title. You can rename a conversation "
                "any time (right-click it in the sidebar)."))

    def _set_vision(self, model, value):
        v = dict(self.settings["vision"])
        v[model] = bool(value)
        self._set("vision", v)

    def _on_instructions(self, _buf):
        if self._instr_id:
            GLib.source_remove(self._instr_id)
        self._instr_id = GLib.timeout_add(500, self._instr_save)

    def _instr_save(self):
        self._instr_id = 0
        buf = self.instructions.get_buffer()
        text = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False)
        self._set("instructions", text[:4000])
        return False

    # ---- Opravneni agenta --------------------------------------------------------------------
    def _page_agent(self, page):
        pol = self.settings["agent"]
        ask = ("ask", _("Always ask"))
        allow = ("allow", _("Allow without asking"))
        never = ("never", _("Never"))
        g = Group(page, _("What Agent mode may do"),
                  _("Dangerous actions (deleting your home folder, formatting disks, shutting down …) always need "
                    "two confirmations, and LuxAI never touches its account and settings files. \"Always ask\" "
                    "still offers \"Always for this session\" on the approval card."))
        rows = [
            ("commands", _("Run commands"), [ask, ("risky", _("Ask only for risky commands")), never],
             _("With \"risky only\", read-only commands such as ls, df or git status run without asking.")),
            ("read_files", _("Read files"), [("allow", _("Allow")), ask, never],
             _("Private files (keys, passwords, .env) always need your confirmation.")),
            ("write_files", _("Write and delete files"), [ask, allow, never],
             _("Creating, editing, moving and deleting files and folders.")),
            ("network", _("Network access"), [ask, allow, never],
             _("Opening web links, downloads and network tools (curl, git clone, package installs). Detected from "
               "the command – for strict isolation also set Run commands to Never.")),
            ("open_apps", _("Open apps and links"), [ask, allow, never], None),
            ("input", _("Control mouse and keyboard"), [ask, allow, never],
             _("Clicking, typing, pressing keys and closing windows.")),
            ("screen", _("Screenshots and clipboard"), [ask, allow, never],
             _("Sends what is on your screen or in the clipboard to the model.")),
        ]
        for key, title, opts, hint in rows:
            c = self.combo(opts, pol[key], lambda v, k=key: self._set_agent(k, v))
            self.widgets["agent_" + key] = c
            g.row(title, c, hint)
        lock = Gtk.Box(spacing=6)
        lock.pack_start(_icon("system-lock-screen-symbolic", "changes-prevent-symbolic", "dialog-password-symbolic"),
                        False, False, 0)
        on = _label(_("Always on"), "locked")
        lock.pack_start(on, False, False, 0)
        self.widgets["sudo"] = on  # zamcene: v nastaveni nejde vypnout (viz safety.normalize_policy)
        g.row(_("Always ask before sudo / root"), lock,
              _("Locked on: commands with administrator rights (sudo, pkexec, su) always need two confirmations."))

        g = Group(page, _("Folders"),
                  _("Shell commands are checked for blocked folders in their paths, but a command cannot be fully "
                    "confined. Set Run commands to Never for strict folder limits."))
        self.folder_btn = Gtk.FileChooserButton(title=_("Working folder"), action=Gtk.FileChooserAction.SELECT_FOLDER)
        self.folder_btn.set_filename(self.win.workdir())
        self.folder_btn.connect("file-set", lambda b: b.get_filename() and self._set("workdir", b.get_filename()))
        self.folder_btn.set_size_request(200, -1)
        g.row(_("Working folder"), self.folder_btn, _("Relative paths and commands start here."))
        self._folder_list(g, "allowed_folders", _("Allowed folders"),
                          _("If you add folders here, the agent can work with files only inside them. Empty = "
                            "anywhere (system files need extra confirmation)."))
        self._folder_list(g, "blocked_folders", _("Blocked folders"),
                          _("The agent never reads or changes anything in these folders."))

        g = Group(page, _("Commands"))
        spin = Gtk.SpinButton.new_with_range(10, 1800, 10)
        spin.set_value(int(self.settings["timeout"]))
        spin.connect("value-changed", lambda s: self._set("timeout", int(s.get_value())))
        self.widgets["timeout"] = spin
        g.row(_("Command timeout (seconds)"), spin, _("Long-running commands are stopped after this time."))

    def _folder_list(self, group, key, title, hint):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        head = Gtk.Box(spacing=8)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        texts.pack_start(_label(title), False, False, 0)
        texts.pack_start(_label(hint, "hint", wrap=True, chars=56), False, False, 0)
        head.pack_start(texts, True, True, 0)
        add = Gtk.Button(label=_("Add folder…"))
        add.set_valign(Gtk.Align.CENTER)
        head.pack_end(add, False, False, 0)
        box.pack_start(head, False, False, 0)
        lst = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        box.pack_start(lst, False, False, 0)
        self.widgets["list_" + key] = lst

        def refill():
            for c in lst.get_children():
                c.destroy()
            folders = self.settings["agent"].get(key) or []
            if not folders:
                lst.pack_start(_label(_("No folders"), "hint"), False, False, 0)
            for f in folders:
                row = Gtk.Box(spacing=6)
                row.pack_start(_icon("folder-symbolic"), False, False, 0)
                lb = _label(home_short(f), "folder-path")
                lb.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
                row.pack_start(lb, True, True, 0)
                rm = Gtk.Button.new_from_icon_name("list-remove-symbolic", Gtk.IconSize.BUTTON)
                rm.set_relief(Gtk.ReliefStyle.NONE)
                rm.set_tooltip_text(_("Remove"))
                rm.connect("clicked", lambda *_a, f=f: remove(f))
                row.pack_end(rm, False, False, 0)
                lst.pack_start(row, False, False, 0)
            lst.show_all()

        def remove(folder):
            self._set_agent(key, [x for x in self.settings["agent"].get(key) or [] if x != folder])
            refill()

        def pick(*_a):
            d = Gtk.FileChooserDialog(title=title, transient_for=self, action=Gtk.FileChooserAction.SELECT_FOLDER)
            d.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
            d.add_button(_("Add"), Gtk.ResponseType.OK)
            d.set_current_folder(os.path.expanduser("~"))
            resp = d.run()
            path = d.get_filename()
            d.destroy()
            if resp == Gtk.ResponseType.OK and path:
                self.add_folder(key, path)
                refill()

        add.connect("clicked", pick)
        self.widgets["refill_" + key] = refill
        refill()
        group.widget_row(box)

    def add_folder(self, key, path):
        cur = list(self.settings["agent"].get(key) or [])
        path = os.path.normpath(os.path.expanduser(path))
        if path not in cur:
            cur.append(path)
        self._set_agent(key, cur)
        r = self.widgets.get("refill_" + key)
        if r:
            r()

    # ---- Soukromi a historie -------------------------------------------------------------------
    def _page_privacy(self, page):
        g = Group(page, _("History"))
        g.row(_("Keep conversation history"),
              self.switch(self.settings["keep_history"], lambda v: self._set("keep_history", v)),
              _("When off, new conversations are not saved on this computer and disappear when you close them."))
        self.count_label = _label("", "hint")
        btn = _cls(Gtk.Button(label=_("Clear all history…")), "destructive")
        btn.connect("clicked", lambda *_a: (self.win.clear_history(self), self._update_counts()))
        g.row(_("Saved conversations"), btn, None)
        g.widget_row(self.count_label)
        g = Group(page, _("Screenshots"))
        self.shot_label = _label("", "hint")
        b2 = Gtk.Button(label=_("Delete screenshots"))
        b2.connect("clicked", lambda *_a: (self.win.clear_screenshots(), self._update_counts()))
        g.row(_("Screenshots taken by the agent"), b2, None)
        g.widget_row(self.shot_label)
        g = Group(page, _("Data on this computer"),
                  _("Your messages are sent to the LuxAI service (lux-ai.cz) to generate answers and titles. The "
                    "agent runs tools only on this computer."))
        from .store import config_dir, data_dir
        for title, path in ((_("Conversations"), os.path.join(data_dir(), "conversations")),
                            (_("Settings file"), os.path.join(config_dir(), "settings.json"))):
            lb = _label(home_short(path), "folder-path")
            lb.set_selectable(True)
            g.row(title, lb)
        self._update_counts()

    def _update_counts(self):
        n = len(self.win.store.list())
        self.count_label.set_text(_("{0} conversations saved").format(n))
        self.shot_label.set_text(_("{0} screenshots").format(self.win.screenshot_count()))

    # ---- Klavesove zkratky ---------------------------------------------------------------------
    def _page_shortcuts(self, page):
        g = Group(page, _("Conversation"))
        send = "Ctrl+Enter" if self.settings["send_key"] == "ctrl_enter" else "Enter"
        newline = "Enter" if self.settings["send_key"] == "ctrl_enter" else "Shift+Enter"
        for title, keys in ((_("Send message"), send), (_("New line"), newline),
                            (_("Stop the answer or command"), "Esc"), (_("New conversation"), "Ctrl+N"),
                            (_("Search conversations"), "Ctrl+F")):
            g.row(title, _label(keys, "kbd"))
        g = Group(page, _("Application"))
        for title, keys in ((_("Settings"), "Ctrl+,"), (_("Show or hide the sidebar"), "F9"),
                            (_("Quit"), "Ctrl+Q")):
            g.row(title, _label(keys, "kbd"))

    # ---- synchronizace s hlavnim oknem -----------------------------------------------------
    def sync(self):
        """Zmeny provedene jinde (rychla nabidka v hlavnim okne) promitne do okna Nastaveni."""
        w = self.widgets
        if "model" in w:
            w["model"].set_active_id(self.settings["model"])
        for m in ("flash", "lite"):
            sw = w.get("vision_" + m)
            if sw is not None and sw.get_active() != bool(self.settings["vision"].get(m)):
                sw.set_active(bool(self.settings["vision"].get(m)))
        if "timeout" in w and int(w["timeout"].get_value()) != int(self.settings["timeout"]):
            w["timeout"].set_value(int(self.settings["timeout"]))
        if self.folder_btn.get_filename() != self.win.workdir():
            self.folder_btn.set_filename(self.win.workdir())
