# LuxAI

AI asistent pro LuxOS jako desktopová aplikace (Python 3 + GTK 3). Stejný asistent jako
[Lux Code](../Lux-Code), ale s grafickým rozhraním a dvěma režimy:

- **Chat** – obyčejná konverzace se streamovanými odpověďmi, Markdown (nadpisy, seznamy,
  tabulky, bloky kódu s tlačítkem Kopírovat, odkazy), historie konverzací v postranním panelu.
- **Agent** – LuxAI pracuje s počítačem pomocí nástrojů: shell, čtení/zápis/úprava/mazání
  souborů, výpis a hledání souborů, otevírání aplikací a URL (`gtk-launch`, `xdg-open`),
  snímek obrazovky, myš a klávesnice (`xdotool`), seznam/aktivace/zavření oken (`wmctrl`),
  schránka, oznámení. Každé volání nástroje je karta s výsledkem a podrobnostmi.
  Nástroj `send_feedback` pošle hlášení chyby / nápad autorovi LuxOS (viz níže).

V obou režimech má model offline příručku LuxOS a LSL z balíku `luxos-docs`
(`/usr/share/luxos/docs`, pro testy `LUXAI_DOCS_DIR`): `docs_search(query, collection?)` vrátí
nejlepší sekce (soubor, nadpis, úryvek; hledání bez ohledu na velikost písmen a diakritiku, BM25)
a `docs_read(path, heading?)` přečte soubor nebo jednu sekci. Nástroje jen čtou soubory uvnitř
složky příručky (cesty s `..`, absolutní a symbolické odkazy ven odmítnou) a nevyžadují schválení;
v režimu Chat jsou kromě nich jen webové nástroje (viz níže). Bez nainstalované příručky vrátí srozumitelnou chybu.

Ke zprávě lze přiložit obrázky a textové soubory: tlačítko **+** vedle pole pro zprávu (výběr souborů),
**Ctrl+V** obrázku nebo souborů zkopírovaných ve správci souborů. Přílohy se ukážou jako náhledy
s křížkem pro odebrání. Obrázky se zmenší a převedou na JPEG (do ~220 kB), textové soubory se vloží jako
text (nejvýše 60 000 znaků), jiné soubory aplikace odmítne se srozumitelnou hláškou. Nejvýše 4 obrázky
a 8 příloh v jedné zprávě.

## Web (web_search, web_fetch)

V obou režimech (Chat i Agent) může model hledat na webu a číst stránky (`luxai/web.py`):

- `web_search(query, max_results?)` – nejvýše 8 výsledků (název, URL, úryvek). Nejdřív přes účet LuxAI
  (`POST /api/ide/search` s cookie účtu, stejný endpoint jako Lux Code; vyhledávač a jeho klíč jsou na
  serveru). Když server klienta `luxai` nepřijme (401/403/404 …), LuxAI to v relaci už nezkouší a hledá
  přímo přes DuckDuckGo HTML (`https://html.duckduckgo.com/html/`, bez klíče).
- `web_fetch(url)` – jen `http(s)`, bez cookies a přihlašovacích údajů (URL s `user:heslo@` odmítne),
  nejvýše 5 přesměrování, stáhne nejvýše 2 MB, z HTML vytáhne čitelný text (bez skriptů, stylů, navigace,
  patičky; přednost má `<main>`/`<article>`) a zkrátí ho na 20 000 znaků. Jen textové typy (HTML, text,
  JSON, XML …). User-Agent `LuxAI/<verze> (LuxOS)`, časový limit 15 s na spojení a 40 s celkem.
- **SSRF:** název serveru se přeloží a každá adresa musí být veřejná (žádný loopback, LAN, link-local,
  CGNAT, multicast, IPv4 v IPv6 …); spojení jde přímo na ověřenou adresu (bez druhého DNS dotazu), TLS
  ověřuje certifikát pro původní název. Totéž při každém přesměrování.
- **Nedůvěryhodná data:** výsledek nese `"untrusted": true`, poznámku pro model a text ohraničený značkami
  `<<<UNTRUSTED WEB CONTENT …>>>` / `<<<END OF UNTRUSTED WEB CONTENT>>>` (značky uvnitř obsahu se
  znehodnotí). Systémová zpráva modelu říká, že pokyny z webu nesmí plnit.
- **Ochrana před prompt injection:** jakmile je v konverzaci výsledek `web_search`/`web_fetch`
  (`safety.web_tainted`, platí i po znovuotevření uložené konverzace), každý `run_command` (i jako root
  v režimu správce bez potvrzení) a `type_text` se potvrzuje jednotlivě – i při *Automaticky schvalovat*
  a „Vždy v této relaci“. Nebezpečné akce dál vyžadují dvě potvrzení, tvrdé bloky zůstávají.
- **Ochrana před vynesením dat v URL** (`web.fetch_trusted`): bez dotazu otevře `web_fetch` jen URL, kterou
  doslova napsal uživatel nebo vrátilo `web_search` v této konverzaci (stejná URL, `#fragment` se ignoruje),
  a odkazy na stejný server ze stránky, kterou už `web_fetch` přečetl – ty jen bez query stringu (`?…`).
  Odkazy stránky se ukládají u zprávy (`_links`, modelu se neposílají). Jakoukoli jinou URL (sestavenou
  modelem, s jiným query stringem) musí uživatel jednorázově schválit – i v Chatu a i při automatickém
  schvalování; karta ukáže celou URL.
- Oprávnění: v Chatu se nástroje spouští bez dotazu (Chat nemá přístup k počítači). V Agentovi je
  `web_search` bez dotazu a `web_fetch` je síťová akce podle nastavení *Přístup k síti* (výchozí „ptát se“).
  „Nikdy“ oba nástroje modelu vůbec nenabídne.

## Matematika, kód a kopírování

- Matematika v odpovědích (`luxai/mathtex.py`, bez závislostí): `$…$`, `\(…\)`, `$$…$$` a `\[…\]`
  (samostatný řádek = vystředěná rovnice) i „holý“ LaTeX v textu (`\sum_{k=0}^{\infty}`, `x^2`) se převede na
  Unicode a Pango markup: řecká písmena, operátory a relace, `\sum \prod \int \lim` s mezemi, `\frac`,
  `\sqrt`, horní/dolní indexy (Unicode, jinak `<sup>/<sub>`), `\left \right`, `\text`, `\mathbb`, akcenty,
  `cases`/`pmatrix`. Neznámý příkaz se vypíše bez zpětného lomítka. Bloky a řádkový kód zůstávají beze změny,
  `$5 a $10` není matematika.
- Bloky kódu mají zvýraznění syntaxe (`luxai/highlight.py`, vlastní lehký tokenizér: Python, Bash, LSL,
  JavaScript/TypeScript, C/C++, JSON, HTML/XML, CSS, SQL, YAML/TOML/INI, diff, Java, Go, Rust, C#, PHP,
  Kotlin, jinak obecné řetězce/čísla/komentáře), barvy pro světlý i tmavý motiv (kontrast ≥ 4,5 : 1)
  a skutečný název jazyka v hlavičce.
- Kopírování: text zpráv lze vybrat myší a zkopírovat **Ctrl+C** (fokus zůstává v poli pro zprávu),
  pod každou odpovědí je **Kopírovat** (celá odpověď v Markdownu) a u bloku kódu **Kopírovat** (jen kód).
  Schránka se předá správci schránky (`store()`) a na X11 ji drží i `xclip`, takže vydrží i po zavření LuxAI.

## Názvy konverzací

Po první věcné zprávě a první odpovědi LuxAI na pozadí požádá nejlevnější model **lite**
(stejně jako web lux-ai.cz) o krátký název v jazyce konverzace; UI se nikdy neblokuje. Pozdrav
(„ahoj“, „hi“) název neurčuje – čeká se na skutečné téma. Při chybě zůstane záložní název
z prvních slov zprávy. Konverzaci lze kdykoli přejmenovat (pravé tlačítko / dvojklik v seznamu);
ručně zadaný název se už nepřepisuje. Pokud na účtu zrovna běží jiný požadavek (`chat_busy`),
název i hlavní dotaz to po 2 s zkusí znovu. Vypnout: Nastavení › Chování AI.

## Nastavení

Tlačítko profilu dole v postranním panelu otevře nabídku (jméno, e-mail, spotřeba, **Nastavení…**,
**Spravovat účet** = `luxos-account`, **Odhlásit se…** = `luxos-account logout`, platí pro celý
LuxOS). Nastavení (také Ctrl+, nebo nabídka ⋮):

- **Obecné** – motiv (systém/světlý/tmavý), odesílání Enter / Ctrl+Enter, oznámení, režim nových konverzací.
- **Chování AI** – výchozí model, obrázky pro Flash/Lite, styl odpovědí (vyvážený, stručný, podrobný,
  technický, přátelský), délka odpovědi (`max_tokens` 1500/4096/8192, agent vždy aspoň 4096), jazyk,
  vlastní teplota (posílá se jen když je zapnutá), vlastní pokyny (do systémové zprávy), automatické názvy.
- **Oprávnění agenta** – viz níže; pracovní složka, povolené a zakázané složky, časový limit příkazů.
- **Soukromí a historie** – ukládání historie, smazání celé historie, smazání snímků obrazovky.
- **Klávesové zkratky** – přehled (Enter, Esc, Ctrl+N, Ctrl+F, Ctrl+, , F9, Ctrl+Q).

## Účet

LuxAI používá jen sdílený účet LuxOS (`docs/luxai-account.md` v LuxOS-Arch): token čte
z `~/.config/luxai/account.json` (soubor nikdy nezapisuje), volá
`POST https://lux-ai.cz/api/ide/chat/completions` (SSE) a `GET /api/me` s cookie
`lux_account_session` a hlavičkou `X-Lux-Client: luxai`. Modely `flash` a `lite`, měsíční
spotřeba je vidět dole v postranním panelu. Bez účtu (nebo při 401/403) aplikace nabídne
**Přihlásit se účtem LuxAI** / **Přihlásit se znovu**, což spustí `luxos-account login`
a po jeho skončení účet znovu načte. Token se nikde nevypisuje ani neloguje.

## Bezpečnost agenta

Model potvrzování vychází z Lux Code (`permissions.lsl`, `safety.lsl`):

| Úroveň | Příklady | Chování |
|---|---|---|
| čtení | `read_file`, `list_directory`, `find_files`, `search_text`, `list_windows` | bez dotazu |
| akce | shell, zápis/mazání, myš/klávesnice, zavření okna, otevření aplikace/URL, snímek obrazovky, schránka | karta **Povolit jednou / Vždy v této relaci / Zamítnout**; přepínač *Automaticky schvalovat* dotaz přeskočí |
| citlivé | čtení `~/.ssh`, `.env`, klíčů; odeslání hlášení autorovi LuxOS (`send_feedback`) | vždy jednorázové potvrzení |
| nebezpečné | vypnutí PC, `sudo` uvnitř příkazu, `curl … \| sh`, zápis mimo domovskou složku, příkaz jako root (podle režimu správce)… | **dvě potvrzení**, nelze povolit natrvalo ani automaticky |
| blokované | token účtu LuxAI (`account.json`), tvrdé bloky `rootguard.hard_block` (`rm -rf /`, `~` nebo systémové složky, `mkfs`, `dd`/zápis na disk, fork bomba, `chmod -R` systému, zavaděč/EFI/jádra, `SigLevel = Never`, účty, sudoers/polkit/PAM, režim správce sám), předání hesla do sudo/su (`echo … \| sudo -S`, `sudo -S … <<<`, `SUDO_ASKPASS=`, `… \| su`, `sshpass`) | vždy odmítnuto, pro každý model a při jakémkoli nastavení |

Nastavení › Oprávnění agenta upravuje úroveň „akce“ po kategoriích (`safety.TOOL_CATEGORY`):
spouštět příkazy (vždy se ptát / ptát se jen u rizikových / nikdy), číst soubory (povolit / ptát se / nikdy),
zapisovat a mazat, přístup k síti, otevírat aplikace a odkazy, ovládat myš a klávesnici, snímky obrazovky
a schránka (ptát se / povolit bez dotazu / nikdy). „Nikdy“ nástroj modelu vůbec nenabídne a volání odmítne,
„jen u rizikových“ spustí bez dotazu jen zjevně čtecí příkazy (`ls`, `df`, `git status` … bez přesměrování
do souboru a bez `$(…)`). Síť se rozpoznává z příkazu (curl, wget, git clone, pip/npm/pacman -S, URL)
a z `open_url` http(s) – je to heuristika, ne síťová izolace. Povolené složky omezí souborové nástroje jen
na ně (symlinky se rozbalují), zakázané složky jsou vždy odmítnuté a `find_files`/`search_text` do nich
nevstupují; u shellu se kontroluje pracovní složka a cesty v příkazu. Nebezpečné a citlivé akce nastavení
nezmírní; soubory `~/.config/luxai/` (účet i nastavení) agent nezmění. Model hesla nikdy nezadává, nehádá ani
je nepředává rourou (`sudo -S` apod. je blokované).

### Režim správce (příkazy jako root)

Agent spouští příkazy jako root přes `run_command` s `root=true` (příkaz začínající `sudo`/`pkexec` se na
něj převede, `luxai/rootmode.py`). Běží přes `pkexec /usr/lib/luxai/luxai-root[-auto]`: pomocník příkaz
znovu zkontroluje `rootguard.hard_block` (stejná pravidla jako aplikace), spustí ho s čistým prostředím,
hlídá limit a skončí, když aplikace zavře stdin (Zastavit). Kódy: 125 odmítnuto, 124 limit, 130 zastaveno.
Nastavení › Oprávnění agenta › **Příkazy správce** (`policy["root_mode"]`):

| Režim | Chování |
|---|---|
| Pokaždé chtít heslo (výchozí) | dvě potvrzení karty + heslo správce v dialogu polkit (`org.luxai.root`) |
| Bez hesla, každý příkaz schválit | jedno potvrzení karty, bez hesla (`org.luxai.root-auto`) – jen model Flash |
| Bez hesla a bez ptaní | bez karty i hesla – jen model Flash |

Model Lite má vždy „heslo“. Zapnutí bez hesla zapíše (`pkexec luxai-root-setup enable`, jednou heslo
správce) `/etc/polkit-1/rules.d/49-luxai-root-<uživatel>.rules`: bez hesla smí jen `org.luxai.root-auto`
(a vypnutí režimu), jen tento uživatel v místní aktivní relaci. Tvrdé bloky platí v každém režimu; jiné
nebezpečné důvody (čtení hesel, vypnutí PC, `sudo -u`) dál chtějí dvě potvrzení. Každý příkaz jako root se
zapíše do `~/.local/state/luxai/root-commands.log` a do žurnálu (`journalctl -t luxai-root`). Tvrdé bloky
chrání před chybou modelu, ne před záměrným útokem: kdo smí spouštět příkazy jako root, může je obejít
(např. vlastním programem), proto je režim bez hesla volitelný a jen pro Flash.

Příkazy běží neinteraktivně (stdin `/dev/null`), s časovým limitem (výchozí 120 s, nastavitelný)
ve vlastní skupině procesů; **Zastavit** (nebo Esc) přeruší odpověď modelu i běžící příkaz.
Výstupy nástrojů se pro model zkracují (max. 30 000 znaků). Automatické schvalování se po
restartu vždy vypne. Karta nástroje ukazuje stav: *Čeká na schválení* → po schválení hned *Probíhá*
(s ukazatelem a uplynulým časem) → *Hotovo* / *Selhalo* / *Zastaveno*.

Obrázky (přílohy i snímky obrazovky agenta) zůstávají v historii konverzace vždy, i když aktuální model
obrázky nevidí. Teprve při sestavení dotazu se pro model bez obrázků (Lite, nebo vypnuté *Model vidí
obrázky*) nahradí krátkou poznámkou. Modelu s obrázky se posílají jen **nejnovější 4 obrázky** z historie
o celkové velikosti nejvýše 360 000 znaků data URL (`agent.MAX_HISTORY_IMAGES`,
`MAX_HISTORY_IMAGE_CHARS`; šetří tokeny a vejde se do limitu požadavku serveru 768 KiB), starší se
nahradí poznámkou. Po přepnutí z Lite na Flash tak Flash uvidí poslední obrázky znovu.

Před každým dotazem se posloupnost volání nástrojů zkontroluje a opraví podle pravidel serveru
(`agent.repair_tool_sequence`): za voláním musí hned následovat právě jedna odpověď na každé volání;
chybějící odpověď (přerušená akce, uložení při přepnutí konverzace) se doplní náhradní, osiřelé
a zdvojené odpovědi se vynechají, volání nástroje, který model v dotazu nemá (zakázaný v nastavení,
neexistující), se převede na poznámku v textu. Rozbitá historie tak chat nikdy nezablokuje.

## Hlášení autorovi LuxOS

Když uživatel chce nahlásit chybu nebo nápad k LuxOS (nebo souhlasí, když to agent navrhne), agent zavolá
`send_feedback` (druh `bug`/`idea`/`other`, název, podrobný popis s kroky, očekávaným a skutečným chováním,
volitelně snímek obrazovky a anonymizované systémové údaje, volitelně e-mail pro odpověď). Systémová zpráva
modelu zakazuje odeslání bez výslovného souhlasu uživatele a vyžaduje text v jazyce uživatele.

Formát je stejný jako aplikace Zpětná vazba (`luxos-feedback`): `POST https://lux-ai.cz/api/feedback`,
hlavička `X-Lux-Client: luxos`, cookie účtu LuxAI (bez účtu anonymně), `app: "luxai"`. Sběr systémových
údajů a pravidla anonymizace (domovská složka, jméno uživatele/počítače, e-maily, IP/MAC, tokeny a dlouhé
klíče) jsou převzaté z `luxos-feedback` (`luxai/feedback.py`; test je s ním porovnává); stejně se
anonymizuje i text hlášení. Hlášení se sestaví **před** potvrzením a karta ukáže celý text, druh, účet/anonymně,
rozbalovací systémové údaje a snímek; po schválení se odešle přesně to. Nástroj se potvrzuje vždy
(neplatí „Vždy v této relaci“, automatické schvalování ani „povolit“ u sítě), přístup k síti = „nikdy“
ho zakáže, snímky obrazovky = „nikdy“ odešle hlášení bez snímku. Po odeslání karta ukáže ID hlášení;
limit serveru je 5 hlášení za 10 minut. Bez internetu (nebo při chybě serveru) karta nabídne
**Uložit a odeslat později** – hlášení se uloží do `~/.local/share/luxos/feedback-outbox` a odešle ho
aplikace Zpětná vazba při dalším spuštění.

## Spuštění ze zdrojů

```sh
cd ~/LuxAI
python3 -m luxai
```

Závislosti (Arch): `python python-gobject gtk3 xdotool wmctrl luxos-account luxos-i18n`.

## Data

- konverzace: `~/.local/share/luxai/conversations/*.json` (0600),
- obrázky z konverzací: `~/.local/share/luxai/images/<id konverzace>/` (0600; mažou se se smazáním
  konverzace nebo celé historie),
- nastavení: `~/.config/luxai/settings.json` (0600; starší `luxai-app.json` se při prvním spuštění převezme),
- snímky obrazovky: `~/.cache/luxai/screenshots/`.

## Překlady

Texty UI jsou anglicky a překládají se přes `_()`: nejdřív systémový
`/usr/share/luxos/i18n/<jazyk>.tsv` (balíček luxos-i18n), pak vlastní `i18n/<jazyk>.tsv`.

## Testy

```sh
python3 -I -m unittest discover -s tests            # bez sítě a bez displeje
env -u DISPLAY LUXAI_GUI_TEST=1 xvfb-run -a python3 -m unittest discover -s tests -p test_gui.py   # okno, jen ve virtuálním X
python3 tests/fake_server.py 8765                    # falešný server pro ruční zkoušky (LUXAI_ORIGIN=http://127.0.0.1:8765)
```

GUI testy běží jen pod `xvfb-run` (nebo s `LUXOS_TEST_X=1` ve VM), nikdy na skutečné obrazovce.
`LUXAI_ORIGIN` přijímá jen `https://…` nebo `http://` na loopback.

## Balíček

`~/LuxOS-Arch/packages/apps/luxai/make-source.sh` vytvoří `luxai-<verze>.tar.gz` a aktualizuje
PKGBUILD; balíček instaluje do `/usr/lib/luxai`, spouštěč `/usr/bin/luxai`.
