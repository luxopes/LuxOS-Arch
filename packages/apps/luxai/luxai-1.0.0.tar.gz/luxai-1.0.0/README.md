# LuxAI

AI asistent pro LuxOS jako desktopová aplikace (Python 3 + GTK 3). Stejný asistent jako
[Lux Code](../Lux-Code), ale s grafickým rozhraním a dvěma režimy:

- **Chat** – obyčejná konverzace se streamovanými odpověďmi, Markdown (nadpisy, seznamy,
  tabulky, bloky kódu s tlačítkem Kopírovat, odkazy), historie konverzací v postranním panelu.
- **Agent** – LuxAI pracuje s počítačem pomocí nástrojů: shell, čtení/zápis/úprava/mazání
  souborů, výpis a hledání souborů, otevírání aplikací a URL (`gtk-launch`, `xdg-open`),
  snímek obrazovky, myš a klávesnice (`xdotool`), seznam/aktivace/zavření oken (`wmctrl`),
  schránka, oznámení. Každé volání nástroje je karta s výsledkem a podrobnostmi.

## Názvy konverzací

Po první věcné zprávě a první odpovědi LuxAI na pozadí požádá nejlevnější model **lite**
(stejně jako web lux-ai.cz) o krátký název v jazyce konverzace; UI se nikdy neblokuje. Pozdrav
(„ahoj“, „hi“) název neurčuje – čeká se na skutečné téma. Při chybě zůstane záložní název
z prvních slov zprávy. Konverzaci lze kdykoli přejmenovat (pravé tlačítko / dvojklik v seznamu);
ručně zadaný název se už nepřepisuje. Pokud na účtu zrovna běží jiný požadavek (`chat_busy`),
název i hlavní dotaz to po 2 s zkusí znovu. Vypnout: Nastavení › Chování AI.

## Nastavení

Tlačítko profilu dole v postranním panelu otevře nabídku (jméno, e-mail, spotřeba, **Nastavení…**,
**Spravovat účet** = `luxos-account`, **Odhlásit se…** = `luxos-account logout`, platí pro celý
LuxOS). Nastavení (také Ctrl+, nebo nabídka ⋮):

- **Obecné** – motiv (systém/světlý/tmavý), odesílání Enter / Ctrl+Enter, oznámení, režim nových konverzací.
- **Chování AI** – výchozí model, obrázky pro Flash/Lite, styl odpovědí (vyvážený, stručný, podrobný,
  technický, přátelský), délka odpovědi (`max_tokens` 1500/4096/8192, agent vždy aspoň 4096), jazyk,
  vlastní teplota (posílá se jen když je zapnutá), vlastní pokyny (do systémové zprávy), automatické názvy.
- **Oprávnění agenta** – viz níže; pracovní složka, povolené a zakázané složky, časový limit příkazů.
- **Soukromí a historie** – ukládání historie, smazání celé historie, smazání snímků obrazovky.
- **Klávesové zkratky** – přehled (Enter, Esc, Ctrl+N, Ctrl+F, Ctrl+, , F9, Ctrl+Q).

## Účet

LuxAI používá jen sdílený účet LuxOS (`docs/luxai-account.md` v LuxOS-Arch): token čte
z `~/.config/luxai/account.json` (soubor nikdy nezapisuje), volá
`POST https://lux-ai.cz/api/ide/chat/completions` (SSE) a `GET /api/me` s cookie
`lux_account_session` a hlavičkou `X-Lux-Client: luxai`. Modely `flash` a `lite`, měsíční
spotřeba je vidět dole v postranním panelu. Bez účtu (nebo při 401/403) aplikace nabídne
**Přihlásit se účtem LuxAI** / **Přihlásit se znovu**, což spustí `luxos-account login`
a po jeho skončení účet znovu načte. Token se nikde nevypisuje ani neloguje.

## Bezpečnost agenta

Model potvrzování vychází z Lux Code (`permissions.lsl`, `safety.lsl`):

| Úroveň | Příklady | Chování |
|---|---|---|
| čtení | `read_file`, `list_directory`, `find_files`, `search_text`, `list_windows` | bez dotazu |
| akce | shell, zápis/mazání, myš/klávesnice, zavření okna, otevření aplikace/URL, snímek obrazovky, schránka | karta **Povolit jednou / Vždy v této relaci / Zamítnout**; přepínač *Automaticky schvalovat* dotaz přeskočí |
| citlivé | čtení `~/.ssh`, `.env`, klíčů | vždy jednorázové potvrzení |
| nebezpečné | `rm -rf ~` nebo `/`, `mkfs`, `dd` na disk, vypnutí PC, `sudo`, `curl … \| sh`, zápis mimo domovskou složku… | **dvě potvrzení**, nelze povolit natrvalo ani automaticky |
| blokované | token účtu LuxAI (`account.json`), změna `/` nebo `~` samotných | vždy odmítnuto |

Nastavení › Oprávnění agenta upravuje úroveň „akce“ po kategoriích (`safety.TOOL_CATEGORY`):
spouštět příkazy (vždy se ptát / ptát se jen u rizikových / nikdy), číst soubory (povolit / ptát se / nikdy),
zapisovat a mazat, přístup k síti, otevírat aplikace a odkazy, ovládat myš a klávesnici, snímky obrazovky
a schránka (ptát se / povolit bez dotazu / nikdy). „Nikdy“ nástroj modelu vůbec nenabídne a volání odmítne,
„jen u rizikových“ spustí bez dotazu jen zjevně čtecí příkazy (`ls`, `df`, `git status` … bez přesměrování
do souboru a bez `$(…)`). Síť se rozpoznává z příkazu (curl, wget, git clone, pip/npm/pacman -S, URL)
a z `open_url` http(s) – je to heuristika, ne síťová izolace. Povolené složky omezí souborové nástroje jen
na ně (symlinky se rozbalují), zakázané složky jsou vždy odmítnuté a `find_files`/`search_text` do nich
nevstupují; u shellu se kontroluje pracovní složka a cesty v příkazu. **Vždy se ptát před sudo/root je
zamčené**: sudo/doas/pkexec/su/run0 (i za `env`, `nohup`, `timeout`, s plnou cestou, v `$(…)` nebo
`bash -c`) jsou vždy nebezpečné = dvě potvrzení. Nebezpečné a citlivé akce nastavení nezmírní; soubory
`~/.config/luxai/` (účet i nastavení) agent nezmění.

Příkazy běží neinteraktivně (stdin `/dev/null`), s časovým limitem (výchozí 120 s, nastavitelný)
ve vlastní skupině procesů; **Zastavit** (nebo Esc) přeruší odpověď modelu i běžící příkaz.
Výstupy nástrojů se pro model zkracují (max. 30 000 znaků). Automatické schvalování se po
restartu vždy vypne. Snímky obrazovky se modelu posílají jen při zapnutém *Model vidí obrázky*
a jen v nejbližším dotazu; do historie se neukládají.

## Spuštění ze zdrojů

```sh
cd ~/LuxAI
python3 -m luxai
```

Závislosti (Arch): `python python-gobject gtk3 xdotool wmctrl luxos-account luxos-i18n`.

## Data

- konverzace: `~/.local/share/luxai/conversations/*.json` (0600),
- nastavení: `~/.config/luxai/settings.json` (0600; starší `luxai-app.json` se při prvním spuštění převezme),
- snímky obrazovky: `~/.cache/luxai/screenshots/`.

## Překlady

Texty UI jsou anglicky a překládají se přes `_()`: nejdřív systémový
`/usr/share/luxos/i18n/<jazyk>.tsv` (balíček luxos-i18n), pak vlastní `i18n/<jazyk>.tsv`.

## Testy

```sh
python3 -I -m unittest discover -s tests            # bez sítě a bez displeje
LUXAI_GUI_TEST=1 DISPLAY=:99 python3 -I -m unittest discover -s tests -p test_gui.py   # okno (např. Xvfb :99)
python3 tests/fake_server.py 8765                    # falešný server pro ruční zkoušky (LUXAI_ORIGIN=http://127.0.0.1:8765)
```

`LUXAI_ORIGIN` přijímá jen `https://…` nebo `http://` na loopback.

## Balíček

`~/LuxOS-Arch/packages/apps/luxai/make-source.sh` vytvoří `luxai-<verze>.tar.gz` a aktualizuje
PKGBUILD; balíček instaluje do `/usr/lib/luxai`, spouštěč `/usr/bin/luxai`.
