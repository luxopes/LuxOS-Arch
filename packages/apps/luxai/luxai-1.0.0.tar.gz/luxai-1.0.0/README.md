# LuxAI

AI asistent pro LuxOS jako desktopová aplikace (Python 3 + GTK 3). Stejný asistent jako
[Lux Code](../Lux-Code), ale s grafickým rozhraním a dvěma režimy:

- **Chat** – obyčejná konverzace se streamovanými odpověďmi, Markdown (nadpisy, seznamy,
  tabulky, bloky kódu s tlačítkem Kopírovat, odkazy), historie konverzací v postranním panelu.
- **Agent** – LuxAI pracuje s počítačem pomocí nástrojů: shell, čtení/zápis/úprava/mazání
  souborů, výpis a hledání souborů, otevírání aplikací a URL (`gtk-launch`, `xdg-open`),
  snímek obrazovky, myš a klávesnice (`xdotool`), seznam/aktivace/zavření oken (`wmctrl`),
  schránka, oznámení. Každé volání nástroje je karta s výsledkem a podrobnostmi.
  Nástroj `send_feedback` pošle hlášení chyby / nápad autorovi LuxOS (viz níže).

V obou režimech má model offline příručku LuxOS a LSL z balíku `luxos-docs`
(`/usr/share/luxos/docs`, pro testy `LUXAI_DOCS_DIR`): `docs_search(query, collection?)` vrátí
nejlepší sekce (soubor, nadpis, úryvek; hledání bez ohledu na velikost písmen a diakritiku, BM25)
a `docs_read(path, heading?)` přečte soubor nebo jednu sekci. Nástroje jen čtou soubory uvnitř
složky příručky (cesty s `..`, absolutní a symbolické odkazy ven odmítnou) a nevyžadují schválení;
v režimu Chat jiné nástroje nejsou. Bez nainstalované příručky vrátí srozumitelnou chybu.

Ke zprávě lze přiložit obrázky a textové soubory: tlačítko **+** vedle pole pro zprávu (výběr souborů),
**Ctrl+V** obrázku nebo souborů zkopírovaných ve správci souborů. Přílohy se ukážou jako náhledy
s křížkem pro odebrání. Obrázky se zmenší a převedou na JPEG (do ~220 kB), textové soubory se vloží jako
text (nejvýše 60 000 znaků), jiné soubory aplikace odmítne se srozumitelnou hláškou. Nejvýše 4 obrázky
a 8 příloh v jedné zprávě.

## Názvy konverzací

Po první věcné zprávě a první odpovědi LuxAI na pozadí požádá nejlevnější model **lite**
(stejně jako web lux-ai.cz) o krátký název v jazyce konverzace; UI se nikdy neblokuje. Pozdrav
(„ahoj“, „hi“) název neurčuje – čeká se na skutečné téma. Při chybě zůstane záložní název
z prvních slov zprávy. Konverzaci lze kdykoli přejmenovat (pravé tlačítko / dvojklik v seznamu);
ručně zadaný název se už nepřepisuje. Pokud na účtu zrovna běží jiný požadavek (`chat_busy`),
název i hlavní dotaz to po 2 s zkusí znovu. Vypnout: Nastavení › Chování AI.

## Nastavení

Tlačítko profilu dole v postranním panelu otevře nabídku (jméno, e-mail, spotřeba, **Nastavení…**,
**Spravovat účet** = `luxos-account`, **Odhlásit se…** = `luxos-account logout`, platí pro celý
LuxOS). Nastavení (také Ctrl+, nebo nabídka ⋮):

- **Obecné** – motiv (systém/světlý/tmavý), odesílání Enter / Ctrl+Enter, oznámení, režim nových konverzací.
- **Chování AI** – výchozí model, obrázky pro Flash/Lite, styl odpovědí (vyvážený, stručný, podrobný,
  technický, přátelský), délka odpovědi (`max_tokens` 1500/4096/8192, agent vždy aspoň 4096), jazyk,
  vlastní teplota (posílá se jen když je zapnutá), vlastní pokyny (do systémové zprávy), automatické názvy.
- **Oprávnění agenta** – viz níže; pracovní složka, povolené a zakázané složky, časový limit příkazů.
- **Soukromí a historie** – ukládání historie, smazání celé historie, smazání snímků obrazovky.
- **Klávesové zkratky** – přehled (Enter, Esc, Ctrl+N, Ctrl+F, Ctrl+, , F9, Ctrl+Q).

## Účet

LuxAI používá jen sdílený účet LuxOS (`docs/luxai-account.md` v LuxOS-Arch): token čte
z `~/.config/luxai/account.json` (soubor nikdy nezapisuje), volá
`POST https://lux-ai.cz/api/ide/chat/completions` (SSE) a `GET /api/me` s cookie
`lux_account_session` a hlavičkou `X-Lux-Client: luxai`. Modely `flash` a `lite`, měsíční
spotřeba je vidět dole v postranním panelu. Bez účtu (nebo při 401/403) aplikace nabídne
**Přihlásit se účtem LuxAI** / **Přihlásit se znovu**, což spustí `luxos-account login`
a po jeho skončení účet znovu načte. Token se nikde nevypisuje ani neloguje.

## Bezpečnost agenta

Model potvrzování vychází z Lux Code (`permissions.lsl`, `safety.lsl`):

| Úroveň | Příklady | Chování |
|---|---|---|
| čtení | `read_file`, `list_directory`, `find_files`, `search_text`, `list_windows` | bez dotazu |
| akce | shell, zápis/mazání, myš/klávesnice, zavření okna, otevření aplikace/URL, snímek obrazovky, schránka | karta **Povolit jednou / Vždy v této relaci / Zamítnout**; přepínač *Automaticky schvalovat* dotaz přeskočí |
| citlivé | čtení `~/.ssh`, `.env`, klíčů; odeslání hlášení autorovi LuxOS (`send_feedback`) | vždy jednorázové potvrzení |
| nebezpečné | `rm -rf ~` nebo `/`, `mkfs`, `dd` na disk, vypnutí PC, `sudo`, `curl … \| sh`, zápis mimo domovskou složku… | **dvě potvrzení**, nelze povolit natrvalo ani automaticky |
| blokované | token účtu LuxAI (`account.json`), změna `/` nebo `~` samotných, předání hesla do sudo/su (`echo … \| sudo -S`, `sudo -S … <<<`, `SUDO_ASKPASS=`, `… \| su`, `sshpass`) | vždy odmítnuto |

Nastavení › Oprávnění agenta upravuje úroveň „akce“ po kategoriích (`safety.TOOL_CATEGORY`):
spouštět příkazy (vždy se ptát / ptát se jen u rizikových / nikdy), číst soubory (povolit / ptát se / nikdy),
zapisovat a mazat, přístup k síti, otevírat aplikace a odkazy, ovládat myš a klávesnici, snímky obrazovky
a schránka (ptát se / povolit bez dotazu / nikdy). „Nikdy“ nástroj modelu vůbec nenabídne a volání odmítne,
„jen u rizikových“ spustí bez dotazu jen zjevně čtecí příkazy (`ls`, `df`, `git status` … bez přesměrování
do souboru a bez `$(…)`). Síť se rozpoznává z příkazu (curl, wget, git clone, pip/npm/pacman -S, URL)
a z `open_url` http(s) – je to heuristika, ne síťová izolace. Povolené složky omezí souborové nástroje jen
na ně (symlinky se rozbalují), zakázané složky jsou vždy odmítnuté a `find_files`/`search_text` do nich
nevstupují; u shellu se kontroluje pracovní složka a cesty v příkazu. **Vždy se ptát před sudo/root je
zamčené**: sudo/doas/pkexec/su/run0 (i za `env`, `nohup`, `timeout`, s plnou cestou, v `$(…)` nebo
`bash -c`) jsou vždy nebezpečné = dvě potvrzení. Nebezpečné a citlivé akce nastavení nezmírní; soubory
`~/.config/luxai/` (účet i nastavení) agent nezmění. Práva roota agent získává jen přes `pkexec`: uživatel
akci schválí v kartě a heslo zadá sám do systémového dialogu (polkit). Model hesla nikdy nezadává, nehádá
ani je nepředává rourou (`sudo -S` apod. je blokované); `sudo` bez terminálu o heslo požádat nemůže.

Příkazy běží neinteraktivně (stdin `/dev/null`), s časovým limitem (výchozí 120 s, nastavitelný)
ve vlastní skupině procesů; **Zastavit** (nebo Esc) přeruší odpověď modelu i běžící příkaz.
Výstupy nástrojů se pro model zkracují (max. 30 000 znaků). Automatické schvalování se po
restartu vždy vypne. Karta nástroje ukazuje stav: *Čeká na schválení* → po schválení hned *Probíhá*
(s ukazatelem a uplynulým časem) → *Hotovo* / *Selhalo* / *Zastaveno*.

Obrázky (přílohy i snímky obrazovky agenta) zůstávají v historii konverzace vždy, i když aktuální model
obrázky nevidí. Teprve při sestavení dotazu se pro model bez obrázků (Lite, nebo vypnuté *Model vidí
obrázky*) nahradí krátkou poznámkou. Modelu s obrázky se posílají jen **nejnovější 4 obrázky** z historie
o celkové velikosti nejvýše 360 000 znaků data URL (`agent.MAX_HISTORY_IMAGES`,
`MAX_HISTORY_IMAGE_CHARS`; šetří tokeny a vejde se do limitu požadavku serveru 768 KiB), starší se
nahradí poznámkou. Po přepnutí z Lite na Flash tak Flash uvidí poslední obrázky znovu.

Před každým dotazem se posloupnost volání nástrojů zkontroluje a opraví podle pravidel serveru
(`agent.repair_tool_sequence`): za voláním musí hned následovat právě jedna odpověď na každé volání;
chybějící odpověď (přerušená akce, uložení při přepnutí konverzace) se doplní náhradní, osiřelé
a zdvojené odpovědi se vynechají, volání nástroje, který model v dotazu nemá (zakázaný v nastavení,
neexistující), se převede na poznámku v textu. Rozbitá historie tak chat nikdy nezablokuje.

## Hlášení autorovi LuxOS

Když uživatel chce nahlásit chybu nebo nápad k LuxOS (nebo souhlasí, když to agent navrhne), agent zavolá
`send_feedback` (druh `bug`/`idea`/`other`, název, podrobný popis s kroky, očekávaným a skutečným chováním,
volitelně snímek obrazovky a anonymizované systémové údaje, volitelně e-mail pro odpověď). Systémová zpráva
modelu zakazuje odeslání bez výslovného souhlasu uživatele a vyžaduje text v jazyce uživatele.

Formát je stejný jako aplikace Zpětná vazba (`luxos-feedback`): `POST https://lux-ai.cz/api/feedback`,
hlavička `X-Lux-Client: luxos`, cookie účtu LuxAI (bez účtu anonymně), `app: "luxai"`. Sběr systémových
údajů a pravidla anonymizace (domovská složka, jméno uživatele/počítače, e-maily, IP/MAC, tokeny a dlouhé
klíče) jsou převzaté z `luxos-feedback` (`luxai/feedback.py`; test je s ním porovnává); stejně se
anonymizuje i text hlášení. Hlášení se sestaví **před** potvrzením a karta ukáže celý text, druh, účet/anonymně,
rozbalovací systémové údaje a snímek; po schválení se odešle přesně to. Nástroj se potvrzuje vždy
(neplatí „Vždy v této relaci“, automatické schvalování ani „povolit“ u sítě), přístup k síti = „nikdy“
ho zakáže, snímky obrazovky = „nikdy“ odešle hlášení bez snímku. Po odeslání karta ukáže ID hlášení;
limit serveru je 5 hlášení za 10 minut. Bez internetu (nebo při chybě serveru) karta nabídne
**Uložit a odeslat později** – hlášení se uloží do `~/.local/share/luxos/feedback-outbox` a odešle ho
aplikace Zpětná vazba při dalším spuštění.

## Spuštění ze zdrojů

```sh
cd ~/LuxAI
python3 -m luxai
```

Závislosti (Arch): `python python-gobject gtk3 xdotool wmctrl luxos-account luxos-i18n`.

## Data

- konverzace: `~/.local/share/luxai/conversations/*.json` (0600),
- obrázky z konverzací: `~/.local/share/luxai/images/<id konverzace>/` (0600; mažou se se smazáním
  konverzace nebo celé historie),
- nastavení: `~/.config/luxai/settings.json` (0600; starší `luxai-app.json` se při prvním spuštění převezme),
- snímky obrazovky: `~/.cache/luxai/screenshots/`.

## Překlady

Texty UI jsou anglicky a překládají se přes `_()`: nejdřív systémový
`/usr/share/luxos/i18n/<jazyk>.tsv` (balíček luxos-i18n), pak vlastní `i18n/<jazyk>.tsv`.

## Testy

```sh
python3 -I -m unittest discover -s tests            # bez sítě a bez displeje
env -u DISPLAY LUXAI_GUI_TEST=1 xvfb-run -a python3 -m unittest discover -s tests -p test_gui.py   # okno, jen ve virtuálním X
python3 tests/fake_server.py 8765                    # falešný server pro ruční zkoušky (LUXAI_ORIGIN=http://127.0.0.1:8765)
```

GUI testy běží jen pod `xvfb-run` (nebo s `LUXOS_TEST_X=1` ve VM), nikdy na skutečné obrazovce.
`LUXAI_ORIGIN` přijímá jen `https://…` nebo `http://` na loopback.

## Balíček

`~/LuxOS-Arch/packages/apps/luxai/make-source.sh` vytvoří `luxai-<verze>.tar.gz` a aktualizuje
PKGBUILD; balíček instaluje do `/usr/lib/luxai`, spouštěč `/usr/bin/luxai`.
