# LuxAI

AI asistent pro LuxOS jako desktopová aplikace (Python 3 + GTK 3). Stejný asistent jako
[Lux Code](../Lux-Code), ale s grafickým rozhraním a dvěma režimy:

- **Chat** – obyčejná konverzace se streamovanými odpověďmi, Markdown (nadpisy, seznamy,
  tabulky, bloky kódu s tlačítkem Kopírovat, odkazy), historie konverzací v postranním panelu.
- **Agent** – LuxAI pracuje s počítačem pomocí nástrojů: shell, čtení/zápis/úprava/mazání
  souborů, výpis a hledání souborů, otevírání aplikací a URL (`gtk-launch`, `xdg-open`),
  snímek obrazovky, myš a klávesnice (`xdotool`), seznam/aktivace/zavření oken (`wmctrl`),
  schránka, oznámení. Každé volání nástroje je karta s výsledkem a podrobnostmi.

## Účet

LuxAI používá jen sdílený účet LuxOS (`docs/luxai-account.md` v LuxOS-Arch): token čte
z `~/.config/luxai/account.json` (soubor nikdy nezapisuje), volá
`POST https://lux-ai.cz/api/ide/chat/completions` (SSE) a `GET /api/me` s cookie
`lux_account_session` a hlavičkou `X-Lux-Client: luxai`. Modely `flash` a `lite`, měsíční
spotřeba je vidět dole v postranním panelu. Bez účtu (nebo při 401/403) aplikace nabídne
**Přihlásit se účtem LuxAI** / **Přihlásit se znovu**, což spustí `luxos-account login`
a po jeho skončení účet znovu načte. Token se nikde nevypisuje ani neloguje.

## Bezpečnost agenta

Model potvrzování vychází z Lux Code (`permissions.lsl`, `safety.lsl`):

| Úroveň | Příklady | Chování |
|---|---|---|
| čtení | `read_file`, `list_directory`, `find_files`, `search_text`, `list_windows` | bez dotazu |
| akce | shell, zápis/mazání, myš/klávesnice, zavření okna, otevření aplikace/URL, snímek obrazovky, schránka | karta **Povolit jednou / Vždy v této relaci / Zamítnout**; přepínač *Automaticky schvalovat* dotaz přeskočí |
| citlivé | čtení `~/.ssh`, `.env`, klíčů | vždy jednorázové potvrzení |
| nebezpečné | `rm -rf ~` nebo `/`, `mkfs`, `dd` na disk, vypnutí PC, `sudo`, `curl … \| sh`, zápis mimo domovskou složku… | **dvě potvrzení**, nelze povolit natrvalo ani automaticky |
| blokované | token účtu LuxAI (`account.json`), změna `/` nebo `~` samotných | vždy odmítnuto |

Příkazy běží neinteraktivně (stdin `/dev/null`), s časovým limitem (výchozí 120 s, nastavitelný)
ve vlastní skupině procesů; **Zastavit** (nebo Esc) přeruší odpověď modelu i běžící příkaz.
Výstupy nástrojů se pro model zkracují (max. 30 000 znaků). Automatické schvalování se po
restartu vždy vypne. Snímky obrazovky se modelu posílají jen při zapnutém *Model vidí obrázky*
a jen v nejbližším dotazu; do historie se neukládají.

## Spuštění ze zdrojů

```sh
cd ~/LuxAI
python3 -m luxai
```

Závislosti (Arch): `python python-gobject gtk3 xdotool wmctrl luxos-account luxos-i18n`.

## Data

- konverzace: `~/.local/share/luxai/conversations/*.json` (0600),
- nastavení: `~/.config/luxai/luxai-app.json`,
- snímky obrazovky: `~/.cache/luxai/screenshots/`.

## Překlady

Texty UI jsou anglicky a překládají se přes `_()`: nejdřív systémový
`/usr/share/luxos/i18n/<jazyk>.tsv` (balíček luxos-i18n), pak vlastní `i18n/<jazyk>.tsv`.

## Testy

```sh
python3 -I -m unittest discover -s tests            # bez sítě a bez displeje
LUXAI_GUI_TEST=1 DISPLAY=:99 python3 -I -m unittest discover -s tests -p test_gui.py   # okno (např. Xvfb :99)
python3 tests/fake_server.py 8765                    # falešný server pro ruční zkoušky (LUXAI_ORIGIN=http://127.0.0.1:8765)
```

`LUXAI_ORIGIN` přijímá jen `https://…` nebo `http://` na loopback.

## Balíček

`~/LuxOS-Arch/packages/apps/luxai/make-source.sh` vytvoří `luxai-<verze>.tar.gz` a aktualizuje
PKGBUILD; balíček instaluje do `/usr/lib/luxai`, spouštěč `/usr/bin/luxai`.
