# `luxai --remote-session` – protokol pro most LuxOS Companion

Bezhlavý režim nativní LuxAI pro Bluetooth most LuxOS Companion (telefon posílá dotazy LuxAI
přes most na počítači). Implementace: `lsl/remote_session.lsl`, vstup v `lsl/main.lsl`.
Jen nativní LSL verze; Python reference (`luxai/`) tento režim nemá.

```sh
luxai --remote-session      # most spustí proces a mluví s ním přes stdin/stdout
```

- Nevytváří `GtkApplication` ani okno a nepotřebuje displej ani D-Bus. Dotaz se proto nikdy
  nepředá běžící desktopové instanci (a ta ho nemůže převzít).
- Používá stejný přihlášený účet (`~/.config/luxai/account.json`), nastavení
  (`settings.json`: model, styl, jazyk, délka odpovědi, pracovní složka, timeout, oprávnění
  agenta) a stejná bezpečnostní pravidla jako aplikace. Účet a nastavení se čtou znovu pro každý
  dotaz, takže přihlášení/odhlášení a změny v aplikaci platí hned. Žádná nová oprávnění.
- Běží pod uživatelem, který ho spustil; most ho musí spouštět pod přihlášeným uživatelem.

## Formát

Jeden JSON objekt na řádek, UTF-8, ukončený `\n`. stdin = most → LuxAI, stdout = LuxAI → most,
stderr jen pro logy. Řádek je nejvýše 256 KiB; neznámé klíče se ignorují.

### LuxAI → most

| Zpráva | Význam |
|---|---|
| `{"type":"ready","protocol":1}` | první řádek po spuštění |
| `{"type":"delta","reply_to":ID,"text":str}` | další kus textu odpovědi (jen text odpovědi, nikdy reasoning) |
| `{"type":"done","reply_to":ID}` | dotaz úspěšně dokončen |
| `{"type":"error","reply_to":ID\|null,"code":str,"message":str}` | dotaz skončil chybou (`reply_to` je `null`, pokud řádek nešel přiřadit) |

Každý přijatý `request` skončí právě jednou zprávou `done` nebo `error` se svým `reply_to`.
`message` je text pro uživatele v jazyce prostředí (`LANG`, překlady z `i18n/`).

### Most → LuxAI

| Zpráva | Význam |
|---|---|
| `{"type":"request","id":UUID,"text":str,"mode":"chat"\|"agent"}` | nový dotaz; `id` je řetězec do 128 znaků, `text` 1–8000 znaků, `mode` výchozí `chat` |
| `{"type":"cancel","request_id":UUID}` | co nejdřív zastavit běžící dotaz – stejná cesta jako tlačítko Stop v aplikaci (přeruší stream, ukončí skupinu procesů nástroje). Neznámé nebo už dokončené `request_id` se tiše ignoruje. |

Konec vstupu (EOF na stdin) zruší běžící dotaz (ten ještě dostane `error` `cancelled`, pokud most
stdout čte) a proces skončí s kódem 0.

### Chybové kódy

| `code` | Kdy |
|---|---|
| `busy` | už běží jiný dotaz (běží vždy nejvýše jeden) |
| `not_signed_in` | LuxAI není přihlášená nebo relace vypršela (HTTP 401/403) |
| `monthly_limit` | vyčerpaný měsíční limit (`flash_monthly_limit`, `monthly_limit`) |
| `rate_limited` | příliš mnoho dotazů nebo na účtu běží jiná konverzace (HTTP 429) |
| `network` | síťová chyba nebo timeout |
| `service_unavailable` | služba nedostupná, ochrana webu, HTML místo API, neplatná odpověď, 5xx |
| `too_large` | dotaz je pro server příliš velký |
| `model_error` | chyba modelu nebo odmítnutý chat |
| `cancelled` | dotaz zrušen (`cancel` nebo EOF) |
| `too_long` | `text` má víc než 8000 znaků |
| `invalid_request` | řádek není JSON objekt/UTF-8, chybí `id`/`text`, neplatný `mode`, neznámý `type`, příliš dlouhý řádek |
| `internal` | jiná chyba |

## Konverzace

Historie se drží jen v paměti po dobu běhu procesu (jedna konverzace, oba režimy se mohou střídat)
a **neukládá se** do historie desktopové aplikace: nevzniká soubor v
`~/.local/share/luxai/conversations`, nepřibude položka v postranním panelu a negeneruje se název.
Důvod: aplikace by o konverzaci za běhu nevěděla (nepřenačítá cizí zápisy) a dotazy z telefonu
zůstanou soukromé na telefonu. Nový proces = nová konverzace.

Model dostane navíc krátkou systémovou poznámku, že píše uživatel z telefonu přes LuxOS Companion,
vidí jen text odpovědi a akce vyžadující potvrzení se odmítnou. Text dotazu se vždy jen posílá
modelu jako zpráva uživatele; nikdy se sám nespouští jako příkaz.

## Agent a potvrzování

Nástroje posuzuje stejný posuzovač jako v aplikaci (`safety.judge`: kategorie a úrovně z
nastavení, blokované/povolené složky, tvrdé bloky, web-taint, nedůvěryhodný `web_fetch`).

- Nástroje, které aplikace spustí bez dotazu (`allow`, např. čtení souborů, výpis složky,
  `docs_*`, bezpečné příkazy v režimu „risky“), běží normálně.
- Vše, co by v aplikaci ukázalo potvrzovací kartu (`ask`, `confirm`/citlivé, `danger`,
  `send_feedback`), se **odmítne**. Protokol 1 nemá potvrzení na telefonu a bezhlavý proces nemá
  okno s kartou (karty jsou součástí hlavního okna aplikace; přenést je do běžící instance by
  vyžadovalo nové IPC). Model dostane výsledek nástroje `permission_denied` s textem „This action
  requires confirmation on the computer (Tato akce vyžaduje potvrzení na počítači)…“ a pokynem
  nezkoušet to jinak; uživatel uvidí v odpovědi řádek
  `⚠ Tato akce vyžaduje potvrzení na počítači (nástroj: příkaz).` Odpověď pak normálně doběhne (`done`).
- Navíc oproti aplikaci se vzdáleně **nikdy** nespustí příkaz jako správce (`root=true`, `sudo`,
  `pkexec`), ani když je v nastavení režim správce „bez ptaní“ (`noask`), a nástroje ovládající
  plochu (myš, klávesnice, okna, snímek obrazovky, schránka) ani při úrovni „povolit“: na plochu
  z telefonu nikdo nevidí. Obojí se odmítne stejně jako akce vyžadující potvrzení.
  Otevírání aplikací/URL/Map (`open_apps`) se řídí nastavením jako v aplikaci (výchozí „ptát se“ = odmítnuto).
- Kalendář LuxOS: `calendar_list_events` (jen čtení) běží z telefonu v Chatu i Agentovi.
  `calendar_create_event`, `calendar_update_event` a `calendar_delete_event` vyžadují potvrzení,
  takže se vzdáleně vždy odmítnou (i kdyby je posuzovač někdy povolil) a soubor se nezmění. Telefon
  má pro zápis do kalendáře vlastní `calendar.note.create` přes most; systémová poznámka to modelu
  připomene.
- „Vždy v této relaci“ se nikdy nezapamatuje (nic se neschvaluje); auto-schvalování neexistuje.
- Bezpečnost procesu: protokol používá soukromé kopie stdin/stdout; fd 0 je přesměrovaný na
  `/dev/null` a fd 1 na stderr, takže žádný nástroj, knihovna ani spuštěná aplikace nemůže číst
  dotazy ani psát do protokolu.

## Testy

`tests_lsl/test_remote_session.py` (součást `tools/test-lsl.sh`) spouští skutečný `luxai
--remote-session` proti loopback API v dočasném profilu: streamování a `done`, historie v paměti,
žádný reasoning, `busy`, `cancel` a pokračování, `not_signed_in` (bez účtu i s neplatnou relací),
neplatné řádky a `too_long`, odmítnutí příkazu vyžadujícího potvrzení (soubor nevznikne, česká
hláška), bezpečný nástroj běží, root/`sudo`/nebezpečný příkaz a vstup na plochu se odmítnou i při
`noask`/„povolit“, výpis kalendáře v Chatu i Agentovi funguje a jeho změny se odmítnou (soubor beze
změny), EOF během dotazu i v klidu → kód 0.
