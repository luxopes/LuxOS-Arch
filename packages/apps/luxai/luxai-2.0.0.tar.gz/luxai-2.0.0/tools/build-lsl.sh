#!/usr/bin/env bash
set -euo pipefail
project_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
cd -- "$project_root"
# Preklad do docasneho souboru a prejmenovani: funguje i kdyz vysledny program prave bezi
compile_to() {
    local temporary
    temporary=$(mktemp "$2.XXXXXX")
    if ! lsl compile --unsafe --target linux-x86_64-gnu "$1" "$temporary"; then
        rm -f -- "$temporary"
        return 1
    fi
    chmod 755 -- "$temporary"
    mv -f -- "$temporary" "$2"
}
case "${1:-parity}" in
  parity)
    mkdir -p build
    compile_to lsl/bridge.lsl build/luxai-parity
    printf '%s\n' 'Built build/luxai-parity (test driver; requires a JSON fixture file).'
    ;;
  release-check)
    python3 tools/check-lsl-release.py
    ;;
  candidate-check)
    python3 tools/check-lsl-release.py --candidate
    ;;
  helpers)
    mkdir -p build
    compile_to lsl/root_command_main.lsl build/luxai-root
    cp -p build/luxai-root build/luxai-root-auto.new && mv -f build/luxai-root-auto.new build/luxai-root-auto
    compile_to lsl/root_setup_main.lsl build/luxai-root-setup
    printf '%s\n' 'Built native administrator helpers in build/ (not installed).'
    ;;
  app)
    mkdir -p build
    compile_to lsl/main.lsl build/luxai
    printf '%s\n' 'Built native desktop application in build/luxai (not installed; migration verification is still in progress).'
    ;;
  *)
    printf '%s\n' 'Usage: tools/build-lsl.sh [parity|helpers|app|candidate-check|release-check]' >&2
    exit 2
    ;;
esac
