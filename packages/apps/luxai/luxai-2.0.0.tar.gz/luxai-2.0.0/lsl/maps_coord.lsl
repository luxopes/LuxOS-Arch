# Souradnice pro LuxOS Maps (stejne jako luxai/maps.py coord/point), bez dalsich zavislosti.

function coord(value):
    # 6 desetinnych mist bez koncovych nul; zaokrouhleni od nuly jako Python int(x + 0.5)
    scaled = Float(value) * 1000000.0
    number = 0
    if scaled >= 0:
        number = Int(scaled + 0.5)
    else:
        number = -Int(-scaled + 0.5)
    end
    sign = ""
    if number < 0:
        sign = "-"
        number = -number
    end
    whole = number // 1000000
    fraction = number % 1000000
    text = sign + String(whole)
    if fraction:
        digits = String(fraction)
        while len(digits) < 6:
            digits = "0" + digits
        end
        text += "." + digits.rstrip("0")
    end
    if text == "-0":
        return "0"
    end
    return text
end

function point(latitude, longitude):
    return coord(latitude) + "," + coord(longitude)
end
