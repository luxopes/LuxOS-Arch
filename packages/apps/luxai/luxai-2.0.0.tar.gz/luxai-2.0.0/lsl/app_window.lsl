# Native GTK desktop window, backed by app_model and the original tool policy.
# No Python process or installed LuxAI instance is used by this implementation.
load gtk
load gtk_ext
load glib
load common
load platform
load time
load json
load ui_widgets
load ui_cards
load ui_format
load ui_data
load ui_dispatch
load app_model
load settings_window
load store
load settings
load api
load agent_core
load safety
load safety_data
load attachments
load images
load gui_bridge
load child_process
load catalog
load tool_format
load i18n
load version

function action_button(state, title, action, data=None, names=None):
    return ui_widgets.button(title, clicked, {"owner": state, "action": action, "data": data}, names)
end

function action_icon(state, icon, title, action, data=None):
    return ui_widgets.icon_button(icon, title, clicked, {"owner": state, "action": action, "data": data})
end

function icon(state, size):
    path = common.join(state["app_root"], "data/luxai.png")
    if exists(path):
        return gtk.pixbuf_new_from_file_at_scale(path, size, size, True)
    end
    return 0
end

function apply_theme(state):
    preferences = gtk.settings_get_default()
    if state.get("system_dark") == None:
        state["system_dark"] = gtk.object_get_bool(preferences, "gtk-application-prefer-dark-theme")
    end
    dark = state["settings"]["theme"] == "dark"
    if state["settings"]["theme"] == "system":
        theme_name = common.environment("GTK_THEME")
        if not theme_name:
            theme_name = gtk.object_get_string(preferences, "gtk-theme-name")
        end
        theme_name = String(theme_name).lower()
        dark = Bool(state["system_dark"]) or "dark" in theme_name
    end
    state["dark"] = dark
    call gtk.object_set_bool(preferences, "gtk-application-prefer-dark-theme", dark)
    if state.get("css_provider"):
        call gtk.css_remove(state["css_provider"])
    end
    colors = ui_data.LIGHT
    if dark:
        colors = ui_data.DARK
    end
    state["css_provider"] = gtk.css_load(colors + ui_data.CSS)
end

function build_header(state):
    bar = gtk_ext.header_bar_new()
    call gtk_ext.header_bar_set_title(bar, "LuxAI")
    call gtk_ext.header_bar_set_show_close_button(bar, True)
    call gtk_ext.window_set_titlebar(state["widget"], bar)
    toggle = gtk.toggle_button_new("")
    sidebar_icon = "view-list-symbolic"
    if gtk_ext.icon_theme_has_icon("sidebar-show-symbolic"):
        sidebar_icon = "sidebar-show-symbolic"
    end
    call gtk.button_set_image(toggle, gtk.image_new_from_icon_name(sidebar_icon, 4))
    # toggle_button_new("") ma prazdny popisek: bez always-show-image by GTK obrazek skryl
    # (Python Gtk.ToggleButton() popisek nema)
    call gtk_ext.button_set_always_show_image(toggle, True)
    call gtk.widget_set_tooltip(toggle, i18n.translate("Show or hide the sidebar"))
    call gtk.toggle_button_set_active(toggle, True)
    call gtk_ext.connect(toggle, "toggled", sidebar_toggled, state)
    state["sidebar_toggle"] = toggle
    call gtk_ext.header_bar_pack_start(bar, toggle)
    new_button = action_icon(state, "document-new-symbolic", "New conversation", "new")
    call gtk.widget_set_tooltip(new_button, i18n.translate("New conversation") + " (Ctrl+N)")
    call gtk_ext.header_bar_pack_start(bar, new_button)
    segment = ui_widgets.box(False, 0, ["segmented", "linked"])
    chat = gtk_ext.radio_button_new_with_label_from_widget(0, i18n.translate("Chat"))
    agent = gtk_ext.radio_button_new_with_label_from_widget(chat, i18n.translate("Agent"))
    state["mode_chat"] = chat
    state["mode_agent"] = agent
    for item in [[chat, "chat"], [agent, "agent"]]:
        call gtk_ext.toggle_button_set_mode(item[0], False)
        call gtk_ext.connect(item[0], "toggled", mode_toggled, {"owner": state, "mode": item[1]})
        call ui_widgets.pack(segment, item[0])
    end
    call gtk.widget_set_tooltip(chat, i18n.translate("Plain conversation, no access to your computer"))
    call gtk.widget_set_tooltip(agent, i18n.translate("LuxAI can work with your computer using tools, with your approval"))
    call gtk_ext.header_bar_set_custom_title(bar, segment)
    model = gtk.combo_box_text_new()
    call gtk.combo_box_text_append(model, "flash", i18n.translate("Flash – smarter"))
    call gtk.combo_box_text_append(model, "lite", i18n.translate("Lite – faster, larger limit"))
    call gtk_ext.combo_box_set_active_id(model, state["model"])
    call gtk_ext.connect(model, "changed", model_changed, state)
    call gtk.widget_set_tooltip(model, i18n.translate("Model"))
    state["model_combo"] = model
    call gtk_ext.header_bar_pack_end(bar, action_icon(state, "open-menu-symbolic", "Settings", "quick_menu"))
    call gtk_ext.header_bar_pack_end(bar, model)
end

function build_sidebar(state):
    root = ui_widgets.box(True, 0, ["sidebar"])
    call gtk.widget_set_size_request(root, 220, -1)
    button = ui_widgets.classes(gtk.button_new_empty(), ["new-chat"])
    inner = ui_widgets.box(False, 8)
    call ui_widgets.pack(inner, gtk.image_new_from_icon_name("list-add-symbolic", 4))
    call ui_widgets.pack(inner, ui_widgets.label(i18n.translate("New chat")))
    call gtk.box_pack_end(inner, ui_widgets.label("Ctrl+N", None, ["new-chat-key"]), False, True, 0)
    call gtk.container_add(button, inner)
    call gtk_ext.connect(button, "clicked", clicked, {"owner": state, "action": "new", "data": None})
    state["new_button"] = button
    call gtk.widget_set_tooltip(button, i18n.translate("New conversation") + " (Ctrl+N)")
    call ui_widgets.pack(root, button)
    search = ui_widgets.classes(gtk_ext.search_entry_new(), ["search"])
    call gtk.entry_set_placeholder_text(search, i18n.translate("Search conversations"))
    call gtk_ext.connect(search, "search-changed", search_changed, state)
    state["search"] = search
    call ui_widgets.pack(root, search)
    call ui_widgets.pack(root, ui_widgets.label(i18n.translate("CONVERSATIONS"), None, ["side-title"]))
    list = gtk.list_box_new()
    call gtk.list_box_set_selection_mode(list, 1)
    state["listbox"] = list
    call gtk_ext.connect(list, "row-selected", row_selected, state, 1)
    call gtk_ext.connect(list, "button-press-event", list_button, state, 1)
    empty = ui_widgets.label(i18n.translate("No conversations yet"), None, ["dim", "small"], False, False, False, 0.5)
    call gtk_ext.widget_set_margin_top(empty, 20)
    call gtk_ext.list_box_set_placeholder(list, empty)
    call gtk.widget_show(empty)
    state["list_empty"] = empty
    call ui_widgets.pack(root, ui_widgets.scrolled(list), True)
    account = ui_widgets.box(True, 6, ["account"])
    profile = gtk.button_new_empty()
    call gtk.widget_add_class(profile, "profile")
    call gtk.button_set_relief(profile, 2)
    call gtk.widget_set_tooltip(profile, i18n.translate("Account and settings"))
    call gtk_ext.connect(profile, "clicked", clicked, {"owner": state, "action": "profile", "data": None})
    state["profile_button"] = profile
    top = ui_widgets.box(False, 8)
    avatar = ui_widgets.label("?", None, ["avatar"], False, False, False, 0.5)
    call gtk.widget_set_valign(avatar, 3)
    state["avatar"] = avatar
    call ui_widgets.pack(top, avatar)
    names = ui_widgets.box(True, 0)
    state["account_name"] = ui_widgets.label("", None, ["conv-title"], False, False, True)
    state["account_sub"] = ui_widgets.label("", None, ["dim", "small"], False, False, True)
    call ui_widgets.pack(names, state["account_name"])
    call ui_widgets.pack(names, state["account_sub"])
    call ui_widgets.pack(top, names, True)
    arrow = "go-up-symbolic"
    if gtk_ext.icon_theme_has_icon("pan-up-symbolic"):
        arrow = "pan-up-symbolic"
    end
    call gtk.box_pack_end(top, gtk.image_new_from_icon_name(arrow, 1), False, True, 0)
    call gtk.container_add(profile, top)
    call ui_widgets.pack(account, profile)
    state["usage_bar"] = gtk.level_bar_new()
    for name in ["low", "high", "full"]:
        call gtk_ext.level_bar_remove_offset_value(state["usage_bar"], name)
    end
    call ui_widgets.pack(account, state["usage_bar"])
    state["usage_label"] = ui_widgets.label("", None, ["dim", "small"], True)
    call ui_widgets.pack(account, state["usage_label"])
    call gtk.box_pack_end(root, account, False, True, 0)
    return root
end

function build_signin(state):
    root = ui_widgets.box(True, 14)
    call gtk.widget_set_halign(root, 3)
    call gtk.widget_set_valign(root, 3)
    image = icon(state, 96)
    if image:
        call ui_widgets.pack(root, gtk.image_new_from_pixbuf(image))
        call glib.object_unref(image)
    end
    state["signin_title"] = ui_widgets.label("", None, ["empty-title"], False, False, False, 0.5)
    state["signin_text"] = ui_widgets.label("", None, ["empty-text"], True, False, False, 0.5)
    call gtk_ext.label_set_justify(state["signin_text"], 2)
    call gtk_ext.label_set_max_width_chars(state["signin_text"], 52)
    call ui_widgets.pack(root, state["signin_title"])
    call ui_widgets.pack(root, state["signin_text"])
    state["signin_button"] = action_button(state, "Sign in with LuxAI account", "sign_in", None, ["primary", "pill"])
    call gtk.widget_set_halign(state["signin_button"], 3)
    call ui_widgets.pack(root, state["signin_button"], False, True, 6)
    call ui_widgets.pack(root, gtk_ext.link_button_new_with_label("https://lux-ai.cz/register", i18n.translate("Create a free account")))
    state["signin_status"] = ui_widgets.label("", None, ["dim", "small"], True, False, False, 0.5)
    call ui_widgets.pack(root, state["signin_status"])
    return root
end

function build_chat(state):
    root = ui_widgets.box(True, 0)
    banner = ui_widgets.box(False, 8, ["agent-banner"])
    state["banner"] = banner
    state["banner_icon"] = gtk.image_new_from_icon_name("dialog-information-symbolic", 1)
    state["banner_label"] = ui_widgets.label("", None, ["small"], True)
    call ui_widgets.pack(banner, state["banner_icon"])
    call ui_widgets.pack(banner, state["banner_label"], True)
    call gtk_ext.widget_set_no_show_all(banner, True)
    call ui_widgets.pack(root, banner)
    column = ui_widgets.box(True, 14)
    call gtk_ext.widget_set_margin_top(column, 18)
    call gtk_ext.widget_set_margin_bottom(column, 18)
    state["column"] = column
    state["scroll"] = ui_widgets.scrolled(column)
    adjustment = gtk_ext.scrolled_window_get_vadjustment(state["scroll"])
    state["adjustment"] = adjustment
    call gtk_ext.connect(adjustment, "value-changed", scrolled, state)
    call gtk_ext.connect(adjustment, "changed", adjustment_changed, state)
    call ui_widgets.pack(root, state["scroll"], True)
    bottom = ui_widgets.box(True, 0)
    state["composer_column"] = bottom
    state["attach_note"] = ui_widgets.label("", None, ["attach-note"], True)
    state["attach_bar"] = ui_widgets.box(False, 6, ["attach-bar"])
    for widget in [state["attach_note"], state["attach_bar"]]:
        call gtk_ext.widget_set_no_show_all(widget, True)
        call ui_widgets.pack(bottom, widget)
    end
    composer = ui_widgets.box(False, 8, ["composer"])
    attach = action_icon(state, "list-add-symbolic", "Attach images or files", "attach")
    call gtk.widget_add_class(attach, "attach")
    call gtk.widget_set_valign(attach, 2)
    call ui_widgets.pack(composer, attach)
    input = ui_widgets.text_view()
    call gtk_ext.text_view_set_top_margin(input, 6)
    call gtk_ext.text_view_set_bottom_margin(input, 6)
    call gtk_ext.connect(input, "key-press-event", input_key, state, 1)
    call gtk_ext.connect(input, "paste-clipboard", pasted, state)
    call gtk_ext.connect(gtk_ext.text_view_get_buffer(input), "changed", input_changed, state)
    state["input"] = input
    scroll = ui_widgets.scrolled(input)
    call gtk_ext.scrolled_window_set_propagate_natural_height(scroll, True)
    call gtk.scrolled_window_set_max_content_height(scroll, 200)
    overlay = gtk.overlay_new()
    call gtk.container_add(overlay, scroll)
    placeholder = ui_widgets.label("", None, ["dim"])
    call gtk.widget_set_valign(placeholder, 1)
    call gtk_ext.widget_set_margin_top(placeholder, 6)
    call gtk_ext.widget_set_margin_start(placeholder, 2)
    call gtk.overlay_add_overlay(overlay, placeholder)
    call gtk_ext.overlay_set_overlay_pass_through(overlay, placeholder, True)
    state["placeholder"] = placeholder
    call ui_widgets.pack(composer, overlay, True)
    state["send_button"] = action_icon(state, "go-up-symbolic", "Send (Enter)", "send")
    call gtk.widget_add_class(state["send_button"], "send")
    call gtk.widget_set_valign(state["send_button"], 2)
    call gtk.box_pack_end(composer, state["send_button"], False, True, 0)
    stop = ui_widgets.classes(gtk.button_new_empty(), ["stop"])
    stop_box = ui_widgets.box(False, 6)
    call ui_widgets.pack(stop_box, gtk.image_new_from_icon_name("media-playback-stop-symbolic", 4))
    call ui_widgets.pack(stop_box, ui_widgets.label(i18n.translate("Stop")))
    call gtk.container_add(stop, stop_box)
    call gtk.widget_show_all(stop_box)
    call gtk.widget_set_tooltip(stop, i18n.translate("Stop the answer and any running command (Esc)"))
    call gtk_ext.connect(stop, "clicked", clicked, {"owner": state, "action": "stop", "data": None})
    state["stop_button"] = stop
    call gtk_ext.widget_set_no_show_all(state["stop_button"], True)
    call gtk.widget_set_valign(state["stop_button"], 2)
    call gtk.box_pack_end(composer, state["stop_button"], False, True, 0)
    call ui_widgets.pack(bottom, composer)
    state["status_line"] = ui_widgets.label("", None, ["status-line"], False, False, True, 0.5)
    call ui_widgets.pack(bottom, state["status_line"])
    call ui_widgets.pack(root, bottom, False, True, 6)
    return root
end

function new_window(application, app_root, account=None, load_saved_account=True):
    state = app_model.new_model(handle_event, account, load_saved_account)
    state["application"] = application
    state["app_root"] = app_root
    state["widget"] = gtk.window_new("LuxAI")
    state["gui"] = gui_bridge.new_bridge(application)
    state["settings_window"] = None
    state["cards"] = {}
    state["bubble"] = None
    state["rows"] = {}
    state["loading_list"] = False
    state["syncing"] = True
    state["stick"] = True
    state["welcome"] = True
    state["refresh_at"] = 0.0
    state["dialogs"] = []
    state["on_setting_changed"] = app_model.setting_changed
    state["store_count"] = store_count
    state["screenshot_count"] = screenshot_count
    state["clear_history"] = clear_history
    state["clear_screenshots"] = clear_screenshots
    call gtk.widget_add_class(state["widget"], "luxai")
    if application:
        call gtk_ext.window_set_application(state["widget"], application)
    end
    size = state["settings"]["window"]
    call gtk.window_set_default_size(state["widget"], max(720, size[0]), max(520, size[1]))
    icon_images = []
    for size in [16, 24, 32, 48, 64, 128, 256]:
        path = common.join(state["app_root"], "data/icons/luxai-" + String(size) + ".png")
        image = 0
        if exists(path):
            image = gtk.pixbuf_new_from_file_at_scale(path, size, size, True)
        end
        if image:
            icon_images.append(image)
        end
    end
    if not icon_images:
        image = icon(state, 128)
        if image:
            icon_images.append(image)
        end
    end
    if icon_images:
        call gtk_ext.window_set_icon_list(state["widget"], icon_images)
        for image in icon_images:
            call glib.object_unref(image)
        end
    end
    call apply_theme(state)
    call build_header(state)
    paned = gtk_ext.paned_new(0)
    state["paned"] = paned
    call gtk.container_add(state["widget"], paned)
    state["sidebar"] = build_sidebar(state)
    call gtk_ext.paned_pack1(paned, state["sidebar"], False, False)
    call gtk_ext.paned_set_position(paned, state["settings"]["sidebar"])
    stack = ui_widgets.classes(gtk_ext.stack_new(), ["luxai-main"])
    state["stack"] = stack
    call gtk_ext.stack_set_transition_type(stack, 1)
    call gtk_ext.paned_pack2(paned, stack, True, False)
    call gtk_ext.stack_add_named(stack, build_signin(state), "signin")
    call gtk_ext.stack_add_named(stack, build_chat(state), "chat")
    call gtk_ext.connect(stack, "size-allocate", allocated, state, 1)
    call gtk_ext.connect(state["widget"], "key-press-event", window_key, state, 1)
    call gtk_ext.connect(state["widget"], "delete-event", delete_event, state, 1)
    call gtk_ext.connect(state["widget"], "destroy", destroyed, state)
    state["theme_signal"] = gtk_ext.connect(gtk.settings_get_default(), "notify::gtk-theme-name", system_theme_changed, state, 1)
    call enable_drop(state)
    state["syncing"] = False
    state["tick"] = ui_dispatch.add_tick(tick, state)
    call refresh_list(state)
    call gtk.widget_show_all(state["widget"])
    call update_mode(state)
    call show_main(state)
    call welcome(state)
    return state
end

function clear_column(state):
    call gtk_ext.clear(state["column"])
    state["cards"] = {}
    state["bubble"] = None
end

function add_row(state, widget):
    call ui_widgets.pack(state["column"], widget)
    call gtk.widget_show_all(widget)
end

function scroll_end(state):
    state["stick"] = True
    call adjustment_changed(state, state["adjustment"])
end

function adjustment_changed(state, adjustment):
    if state["stick"]:
        call gtk_ext.adjustment_set_value(adjustment, max(0.0, gtk_ext.adjustment_get_upper(adjustment) - gtk_ext.adjustment_get_page_size(adjustment)))
    end
end

function scrolled(state, adjustment):
    state["stick"] = gtk_ext.adjustment_get_value(adjustment) >= gtk_ext.adjustment_get_upper(adjustment) - gtk_ext.adjustment_get_page_size(adjustment) - 60
end

function allocated(state, allocation, widget):
    # Jako Clamp v Pythonu (max. 860 px uprostred). Okraje se NESMI menit primo v size-allocate:
    # queue_resize behem rozmistovani GTK 3 ztrati, sloupec pak zustane s vyskou pro starou sirku
    # (zalomeny text pretece pres dalsi zpravu, nova zprava nedostane misto). Proto az po navratu
    # do hlavni smycky.
    width = __lsl_qbe_load32(platform.pointer(allocation) + 8)
    margin = min(width // 2, max(24, (width - 860) // 2))
    if state.get("column_margin_wanted", -1) != margin:
        state["column_margin_wanted"] = margin
        call ui_dispatch.post(apply_margin, state)
    end
end

function apply_margin(state, arguments):
    margin = state.get("column_margin_wanted", -1)
    if not state["alive"] or margin < 0 or state.get("column_margin", -1) == margin:
        return
    end
    state["column_margin"] = margin
    for child in [state["column"], state["composer_column"]]:
        call gtk_ext.widget_set_margin_start(child, margin)
        call gtk_ext.widget_set_margin_end(child, margin)
    end
end

function input_changed(state, buffer):
    if state.get("placeholder"):
        call gtk.widget_set_visible(state["placeholder"], not gtk_ext.buffer_text(buffer))
    end
end

function set_input(state, text):
    call gtk_ext.text_buffer_set_text(gtk_ext.text_view_get_buffer(state["input"]), text, -1)
    call gtk_ext.widget_grab_focus(state["input"])
end

function note(state, text):
    call gtk.label_set_text(state["attach_note"], text)
    call gtk.widget_set_visible(state["attach_note"], Bool(text))
end

function welcome(state):
    if not store.conversation_empty(state["conversation"]):
        return
    end
    call clear_column(state)
    state["welcome"] = True
    root = ui_widgets.box(True, 12)
    call gtk_ext.widget_set_margin_top(root, 60)
    image = icon(state, 64)
    if image:
        call ui_widgets.pack(root, gtk.image_new_from_pixbuf(image))
        call glib.object_unref(image)
    end
    call ui_widgets.pack(root, ui_widgets.label(i18n.translate("How can I help you today?"), None, ["empty-title"], False, False, False, 0.5))
    text = "Ask anything. Switch to Agent mode when you want me to do things on your computer."
    if state["mode"] == "agent":
        text = "Agent mode: I can run commands, manage files, open apps and control the mouse and keyboard – always with your approval."
    end
    subtitle = ui_widgets.label(i18n.translate(text), None, ["empty-text"], True, False, False, 0.5)
    call gtk_ext.label_set_justify(subtitle, 2)
    call ui_widgets.pack(root, subtitle)
    grid = gtk.grid_new()
    call gtk.grid_set_column_spacing(grid, 10)
    call gtk.grid_set_row_spacing(grid, 10)
    call gtk.grid_set_column_homogeneous(grid, True)
    call gtk_ext.widget_set_margin_top(grid, 16)
    index = 0
    for suggestion in ui_data.SUGGESTIONS[state["mode"]]:
        button = gtk.button_new_empty()
        call gtk.widget_add_class(button, "chip")
        column = ui_widgets.box(True, 2)
        call ui_widgets.pack(column, ui_widgets.label(i18n.translate(suggestion[0]), None, ["conv-title"]))
        label = ui_widgets.label(i18n.translate(suggestion[1]), None, ["dim", "small"], True)
        call gtk_ext.label_set_max_width_chars(label, 36)
        call ui_widgets.pack(column, label)
        call gtk.container_add(button, column)
        call gtk_ext.connect(button, "clicked", clicked, {"owner": state, "action": "suggestion", "data": i18n.translate(suggestion[1])})
        call gtk.grid_attach(grid, button, index % 2, index // 2, 1, 1)
        index += 1
    end
    call ui_widgets.pack(root, grid)
    call add_row(state, root)
end

function result_status(result):
    if result.get("ok"):
        return "ok"
    elif result.get("blocked"):
        return "blocked"
    elif result.get("permission_denied"):
        return "denied"
    elif result.get("cancelled"):
        return "cancelled"
    end
    return "error"
end

function render_conversation(state):
    call clear_column(state)
    if store.conversation_empty(state["conversation"]):
        call welcome(state)
        return
    end
    state["welcome"] = False
    results = {}
    route_maps = {}
    for message in state["conversation"]["messages"]:
        if message.get("role") == "tool":
            results[common.fallback(message.get("tool_call_id"), "")] = message.get("content")
            if type(message.get("_map")) == "Dictionary":
                # nahled trasy (ulozeny u zpravy, ne pro model)
                route_maps[common.fallback(message.get("tool_call_id"), "")] = message["_map"]
            end
        end
    end
    for message in state["conversation"]["messages"]:
        role = message.get("role")
        if role == "user" and not message.get("_screenshot") and not message.get("_transient"):
            parts = attachments.message_parts(message)
            if platform.strip(parts[0], common.WHITESPACE) or parts[1] or parts[2]:
                call add_row(state, ui_widgets.user_bubble(parts[0], parts[1], parts[2]))
            end
        elif role == "assistant":
            if message.get("content"):
                bubble = ui_widgets.assistant_bubble(message["content"], state["dark"])
                call add_row(state, bubble["widget"])
            end
            for call_record in common.fallback(message.get("tool_calls"), []):
                fn = common.fallback(call_record.get("function"), {})
                args = {}
                try:
                    args = json.decode(common.fallback(fn.get("arguments"), "{}"))
                    if type(args) != "Dictionary":
                        args = {}
                    end
                else:
                    args = {}
                end
                id = common.fallback(call_record.get("id"), "")
                card = ui_cards.new_card(id, fn.get("name", ""), args)
                state["cards"][id] = card
                call add_row(state, card["widget"])
                raw = results.get(id)
                result = {"ok": False, "error": i18n.translate("No result")}
                if raw:
                    try:
                        result = json.decode(raw)
                    else:
                        result = {"ok": True, "output": raw}
                    end
                end
                if type(result) != "Dictionary":
                    result = {"ok": True, "output": String(result)}
                end
                if id in route_maps:
                    result["_map"] = route_maps[id]
                end
                call ui_cards.set_result(card, result, result_status(result))
            end
        end
    end
    call scroll_end(state)
end

function refresh_list(state):
    state["loading_list"] = True
    call gtk_ext.clear(state["listbox"])
    state["rows"] = {}
    query = gtk.entry_get_text(state["search"]).lower()
    today = glib.date_time_format("%Y-%m-%d")
    if state["settings"]["keep_history"]:
        call gtk.label_set_text(state["list_empty"], i18n.translate("No conversations yet"))
    else:
        call gtk.label_set_text(state["list_empty"], i18n.translate("History is turned off"))
    end
    for item in app_model.list_conversations(state):
        if query and query not in item["title"].lower():
            continue
        end
        row = gtk_ext.list_box_row_new()
        state["rows"][String(row)] = item["id"]
        call gtk.widget_set_tooltip(row, item["title"])
        root = ui_widgets.box(False, 6)
        texts = ui_widgets.box(True, 0)
        call ui_widgets.pack(texts, ui_widgets.label(item["title"], None, ["conv-title"], False, False, True))
        day = platform.format_time(Int(item["updated"]), "%Y-%m-%d")
        format = "%d.%m.%Y"
        if day == today:
            format = "%H:%M"
        end
        when = platform.format_time(Int(item["updated"]), format)
        mode_name = "Chat"
        if item["mode"] == "agent":
            mode_name = "Agent"
        end
        call ui_widgets.pack(texts, ui_widgets.label(i18n.translate(mode_name) + " · " + when, None, ["dim", "small"]))
        call ui_widgets.pack(root, texts, True)
        remove = action_icon(state, "user-trash-symbolic", "Delete conversation", "delete", item["id"])
        call gtk.widget_add_class(remove, "row-delete")
        call gtk.widget_set_valign(remove, 3)
        call gtk.box_pack_end(root, remove, False, True, 0)
        call gtk.container_add(row, root)
        call gtk.list_box_insert(state["listbox"], row, -1)
        if item["id"] == state["conversation"]["id"]:
            call gtk_ext.list_box_select_row(state["listbox"], row)
        end
    end
    call gtk.widget_show_all(state["listbox"])
    state["loading_list"] = False
end

function search_changed(state, widget):
    call refresh_list(state)
end

function row_selected(state, row, widget):
    if state["loading_list"] or not row:
        return
    end
    id = state["rows"].get(String(row))
    if id and id != state["conversation"]["id"]:
        # Otevreni prestavi seznam (gtk_widget_destroy vsech radku). GtkListBox ale po
        # "row-selected" dal pracuje s vybranym radkem (row-activated, kurzor) -> pouziti
        # uvolneneho radku (SIGSEGV). Proto az po navratu do hlavni smycky (jako GLib.idle_add).
        call ui_dispatch.post(open_later, {"owner": state, "id": id})
    end
end

function open_later(binding, arguments):
    state = binding["owner"]
    if state["alive"] and not state["closing"] and binding["id"] != state["conversation"]["id"]:
        call app_model.open_conversation(state, binding["id"])
    end
end

function menu_finished(state, widget):
    call ui_dispatch.post(destroy_popover, widget)
end

function rename_later(binding, arguments):
    state = binding["owner"]
    if state["alive"] and not state["closing"]:
        call rename(state, binding["id"])
    end
end

function list_button(state, event, widget):
    button = gtk.event_button(event)
    kind = __lsl_qbe_load32(platform.pointer(event))
    if button != 3 and not (button == 1 and kind == 5):
        return False
    end
    row = gtk_ext.list_box_get_row_at_y(widget, Int(gtk.event_y(event)))
    if not row:
        return False
    end
    id = state["rows"].get(String(row))
    if not id:
        return False
    end
    if button == 1:
        # GDK_2BUTTON_PRESS: prejmenovat az po navratu do hlavni smycky (jako GLib.idle_add)
        call ui_dispatch.post(rename_later, {"owner": state, "id": id})
        return True
    end
    if kind != 4:
        return False
    end
    menu = gtk_ext.menu_new()
    call __lsl_qbe_call1(__lsl_symbol("g_object_ref_sink"), platform.pointer(menu))
    for item in [["Rename…", "rename"], ["Delete", "delete"]]:
        entry = gtk_ext.menu_item_new_with_label(i18n.translate(item[0]))
        call gtk_ext.connect(entry, "activate", clicked, {"owner": state, "action": item[1], "data": id})
        call gtk_ext.menu_shell_append(menu, entry)
    end
    call gtk_ext.menu_attach_to_widget(menu, widget, 0)
    call gtk_ext.connect(menu, "selection-done", menu_finished, state)
    call gtk.widget_show_all(menu)
    call gtk_ext.menu_popup_at_pointer(menu, event)
    return True
end

function sidebar_toggled(state, widget):
    if state.get("sidebar"):
        call gtk.widget_set_visible(state["sidebar"], Bool(gtk.toggle_button_get_active(widget)))
    end
end

function update_mode(state):
    state["syncing"] = True
    agent = state["mode"] == "agent"
    call gtk.toggle_button_set_active(state["mode_chat"], not agent)
    call gtk.toggle_button_set_active(state["mode_agent"], agent)
    call gtk_ext.combo_box_set_active_id(state["model_combo"], state["model"])
    running = state["current_run"] != None
    for widget in [state["mode_chat"], state["mode_agent"], state["model_combo"]]:
        call gtk.widget_set_sensitive(widget, not running)
    end
    call gtk.widget_set_visible(state["send_button"], not running)
    call gtk.widget_set_visible(state["stop_button"], running)
    call gtk.widget_set_visible(state["banner"], agent)
    call gtk.widget_remove_class(state["banner"], "auto")
    text = "Agent mode · LuxAI can work with your computer. You approve every action that changes something."
    image = "dialog-information-symbolic"
    if state["permissions"]["auto_approve"]:
        text = "Agent mode · Auto-approve is ON: actions run without asking (dangerous ones still ask twice)."
        image = "dialog-warning-symbolic"
        call gtk.widget_add_class(state["banner"], "auto")
    end
    text = i18n.translate(text)
    policy = state["permissions"]["policy"]
    limited = Bool(policy["allowed_folders"]) or Bool(policy["blocked_folders"])
    for key in ["commands", "write_files", "network"]:
        if policy.get(key) == "never":
            limited = True
        end
    end
    if limited and agent:
        text += " " + i18n.translate("Limits from Settings › Agent permissions apply.")
    end
    call gtk.label_set_text(state["banner_label"], text)
    call gtk.image_set_from_icon_name(state["banner_icon"], image, 1)
    placeholder = "Message LuxAI…"
    if agent:
        placeholder = "Ask LuxAI to do something on your computer…"
    end
    call gtk.label_set_text(state["placeholder"], i18n.translate(placeholder))
    status = i18n.translate("LuxAI can make mistakes. Check important information.")
    if agent:
        vision = "no images"
        if state["settings"]["vision"].get(state["model"]):
            vision = "sees images"
        end
        status = i18n.translate("Agent") + " · " + i18n.translate("folder") + " " + app_model.workdir(state) + " · " + i18n.translate(vision)
    end
    call gtk.label_set_text(state["status_line"], status)
    if state.get("quick_widgets"):
        controls = state["quick_widgets"]
        call gtk.switch_set_active(controls["auto"], Bool(state["permissions"]["auto_approve"]))
        call gtk.switch_set_active(controls["vision"], Bool(state["settings"]["vision"].get(state["model"])))
        call gtk.spin_button_set_value(controls["timeout"], state["settings"]["timeout"])
        call gtk.button_set_label(controls["folder"], settings_window.home_short(app_model.workdir(state)))
    end
    state["syncing"] = False
    call update_account(state)
end

function show_main(state):
    if state["signed_state"] == "ok":
        call gtk_ext.stack_set_visible_child_name(state["stack"], "chat")
        call gtk_ext.widget_grab_focus(state["input"])
    else:
        expired = state["signed_state"] == "expired"
        title = "Welcome to LuxAI"
        text = "Chat with AI or let it work with your computer. Sign in with your LuxAI account – one account for all LuxOS apps."
        button = "Sign in with LuxAI account"
        if expired:
            title = "Your session has expired"
            text = "Please sign in again to continue. Your conversations are kept on this computer."
            button = "Sign in again"
        end
        call gtk.label_set_text(state["signin_title"], i18n.translate(title))
        call gtk.label_set_text(state["signin_text"], i18n.translate(text))
        call gtk.button_set_label(state["signin_button"], i18n.translate(button))
        call gtk_ext.stack_set_visible_child_name(state["stack"], "signin")
    end
    call update_account(state)
end

function update_account(state):
    user = common.fallback(state["user"], {})
    if state["signed_state"] != "ok" or not user:
        title = "Not signed in"
        if state["signed_state"] == "expired":
            title = "Session expired"
        end
        call gtk.label_set_text(state["account_name"], i18n.translate(title))
        call gtk.label_set_text(state["account_sub"], "")
        call gtk.label_set_text(state["avatar"], "?")
        call gtk.level_bar_set_value(state["usage_bar"], 0.0)
        call gtk.label_set_text(state["usage_label"], "")
        return
    end
    name = String(common.fallback(user.get("displayName"), common.fallback(user.get("username"), common.fallback(user.get("email"), "LuxAI"))))
    call gtk.label_set_text(state["account_name"], name)
    call gtk.label_set_text(state["account_sub"], common.fallback(user.get("email"), ""))
    call gtk.label_set_text(state["avatar"], common.fallback(String(platform.strip(name, common.WHITESPACE))[:1].upper(), "?"))
    usage = api.usage_for(user, state["model"])
    model = "Lite"
    if state["model"] == "flash":
        model = "Flash"
    end
    text = "{0}: {1} tokens this month"
    if usage[2]:
        text = "{0}: {1} tokens this month · unlimited"
    elif usage[1]:
        text = "{0}: {1} / {2} tokens this month"
    end
    text = i18n.translate(text).replace("{0}", model).replace("{1}", ui_format.fmt_int(usage[0])).replace("{2}", ui_format.fmt_int(usage[1]))
    fraction = 0.0
    if not usage[2] and usage[1]:
        fraction = min(1.0, Float(usage[0]) / usage[1])
    end
    call gtk.level_bar_set_value(state["usage_bar"], fraction)
    call gtk.label_set_text(state["usage_label"], text)
end

function persist_setting(state, key, value):
    state["settings"][key] = value
    call app_model.save_settings(state)
    call app_model.setting_changed(state, key)
    if state["settings_window"] != None:
        call settings_window.sync(state["settings_window"])
    end
end

function mode_toggled(binding, widget):
    state = binding["owner"]
    if state["syncing"] or not gtk.toggle_button_get_active(widget) or state["current_run"] != None:
        return
    end
    state["mode"] = binding["mode"]
    state["conversation"]["mode"] = state["mode"]
    call persist_setting(state, "mode", state["mode"])
    call update_mode(state)
    if store.conversation_empty(state["conversation"]):
        call welcome(state)
    end
end

function model_changed(state, widget):
    if state["syncing"] or state["current_run"] != None:
        return
    end
    value = glib.from_c(gtk_ext.combo_box_get_active_id(widget))
    if value not in ["flash", "lite"]:
        return
    end
    state["model"] = value
    state["conversation"]["model"] = value
    call persist_setting(state, "model", value)
    call update_mode(state)
end

function tick(state, arguments):
    if not state["alive"] or state["closing"]:
        return
    end
    if state["bubble"] != None:
        if ui_widgets.render_pending(state["bubble"]):
            call adjustment_changed(state, state["adjustment"])
        end
    end
    for card in state["cards"].values():
        call ui_cards.tick(card)
    end
    if state["refresh_at"] and time.monotonic() >= state["refresh_at"]:
        state["refresh_at"] = 0.0
        call app_model.refresh_account(state)
    end
end

function system_theme_changed(state, property, widget):
    if state["alive"] and not state["closing"]:
        call apply_theme(state)
        if state["current_run"] == None and not store.conversation_empty(state["conversation"]):
            call render_conversation(state)
        end
    end
end

function refresh_attachments(state):
    call gtk_ext.clear(state["attach_bar"])
    for attachment in state["attachments"]:
        row = ui_widgets.box(False, 6, ["attach-chip"])
        image = 0
        if attachment["kind"] == "image":
            image = images.from_data_url(attachment["url"], 56, 40)
        end
        if image:
            call ui_widgets.pack(row, gtk.image_new_from_pixbuf(image))
            call glib.object_unref(image)
        else:
            name = "text-x-generic-symbolic"
            if attachment["kind"] == "image":
                name = "image-x-generic-symbolic"
            end
            call ui_widgets.pack(row, gtk.image_new_from_icon_name(name, 4))
        end
        label = ui_widgets.label(attachment.get("name", ""), None, ["small"], False, False, True)
        call gtk_ext.label_set_max_width_chars(label, 18)
        call ui_widgets.pack(row, label)
        remove = action_button(state, "×", "remove_attachment", attachment)
        call gtk.widget_set_tooltip(remove, i18n.translate("Remove attachment"))
        call ui_widgets.pack(row, remove)
        call ui_widgets.pack(state["attach_bar"], row)
    end
    call gtk.widget_show_all(state["attach_bar"])
    call gtk.widget_set_visible(state["attach_bar"], Bool(state["attachments"]))
end

function add_image(state, image, name):
    problem = attachments.check_limits(state["attachments"], "image")
    if problem:
        call note(state, problem)
        return False
    end
    url = images.encode_image(image)
    if not url:
        call note(state, ui_format.format_text("{0} cannot be read as an image.", name))
        return False
    end
    state["attachments"].append({"kind": "image", "name": name, "url": url})
    text = ""
    if not state["settings"]["vision"].get(state["model"]):
        text = i18n.translate("The current model cannot see images. They stay in the conversation and are sent when you switch to a model that can see images.")
    end
    call note(state, text)
    call refresh_attachments(state)
    return True
end

function add_attachment(state, path):
    if type(path) != "String" or "\0" in path:
        return False
    end
    name = attachments.basename(path)
    kind = attachments.classify(path)
    if kind == "image":
        image = 0
        try:
            if platform.file_size(path) > attachments.MAX_IMAGE_FILE:
                call note(state, ui_format.format_text("{0} is too large to attach.", name))
                return False
            end
            image = gtk.pixbuf_new_from_file(path)
        else:
            image = 0
        end
        if not image:
            call note(state, ui_format.format_text("{0} cannot be read as an image.", name))
            return False
        end
        result = add_image(state, image, name)
        call glib.object_unref(image)
        return result
    elif kind == "text":
        problem = attachments.check_limits(state["attachments"], "text")
        if problem:
            call note(state, problem)
            return False
        end
        try:
            attachment = attachments.text_attachment(path)
            state["attachments"].append(attachment)
            text = ""
            if attachment["truncated"]:
                text = ui_format.format_text("{0} is long; only its beginning is attached.", name)
            end
            call note(state, text)
            call refresh_attachments(state)
            return True
        else:
            call note(state, tools_error(String(last_error())))
            return False
        end
    end
    call note(state, ui_format.format_text("{0} cannot be attached: only images and text files are supported.", name))
    return False
end

function tools_error(text):
    for prefix in ["AttachmentError: ", "FileError: ", "ProcessError: ", "ToolError: "]:
        if text.startswith(prefix):
            return text[len(prefix):]
        end
    end
    return text
end

function choose_attachments(state):
    chooser = gtk_ext.file_dialog(state["widget"], i18n.translate("Attach images or files"), 0, True, i18n.translate("Attach"), i18n.translate("Cancel"))
    call gtk_ext.file_chooser_set_current_folder(chooser, app_model.workdir(state))
    response = gtk_ext.dialog_run(chooser)
    paths = []
    if response == -3:
        paths = gtk_ext.selected_files(chooser)
    end
    call gtk.widget_destroy(chooser)
    for path in paths:
        call add_attachment(state, path)
    end
end

function attach_uris(state, uris):
    handled = False
    for uri in uris:
        path = gtk_ext.path_from_uri(uri)
        if path:
            info = platform.file_info(path)
            if info != None and info["file"]:
                call add_attachment(state, path)
                handled = True
            end
        end
    end
    return handled
end

function pasted(state, widget):
    clipboard = gtk_ext.clipboard()
    raw_uris = __lsl_qbe_call1(__lsl_symbol("gtk_clipboard_wait_for_uris"), platform.pointer(clipboard))
    handled = attach_uris(state, gtk_ext.string_vector(raw_uris))
    if not handled and __lsl_qbe_call1(__lsl_symbol("gtk_clipboard_wait_is_image_available"), platform.pointer(clipboard)) != 0:
        text = gtk_ext.clipboard_text()
        if text:
            text = platform.strip(text, common.WHITESPACE)
            if text and not (text.startswith("http://") or text.startswith("https://") or text.startswith("file://") or text.startswith("data:")):
                return
            end
        end
        image = __lsl_qbe_call1(__lsl_symbol("gtk_clipboard_wait_for_image"), platform.pointer(clipboard))
        if image != 0:
            call add_image(state, image, i18n.translate("Pasted image"))
            call glib.object_unref(image)
            handled = True
        end
    end
    if handled:
        call __lsl_qbe_call2(__lsl_symbol("g_signal_stop_emission_by_name"), platform.pointer(widget), platform.cstr("paste-clipboard"))
    end
end

function enable_drop(state):
    targets = platform.buffer(16)
    mime = "text/uri-list"
    call __lsl_qbe_store64(platform.address(targets), platform.cstr(mime))
    call __lsl_qbe_store32(platform.address(targets) + 8, 0)
    call __lsl_qbe_store32(platform.address(targets) + 12, 0)
    call __lsl_qbe_call5(__lsl_symbol("gtk_drag_dest_set"), platform.pointer(state["widget"]), 7, platform.address(targets), 1, 1)
    call gtk_ext.connect_drop(state["widget"], dropped, state)
end

function dropped(state, context, x, y, selection, info, timestamp):
    uris = __lsl_qbe_call1(__lsl_symbol("gtk_selection_data_get_uris"), platform.pointer(selection))
    handled = attach_uris(state, gtk_ext.string_vector(uris))
    call __lsl_qbe_call4(__lsl_symbol("gtk_drag_finish"), platform.pointer(context), platform.pointer(handled), 0, platform.pointer(timestamp))
end

function message_dialog(state, title, text="", parent=0, accept="", cancel=False, destructive=False):
    # jako Gtk.MessageDialog v Pythonu: s cancel otazka (Zrusit + akce), jinak informace s OK
    buttons = []
    if cancel:
        style = ""
        if destructive:
            style = "destructive-action"
        end
        buttons = [[i18n.translate("Cancel"), -6, ""], [i18n.translate(accept), -5, style]]
    else:
        label = gtk_ext.gtk_text("_OK")
        if accept:
            label = i18n.translate(accept)
        end
        buttons = [[label, -5, ""]]
    end
    secondary = ""
    if text:
        secondary = i18n.translate(text)
    end
    owner = common.fallback(parent, state["widget"])
    response = ui_widgets.message_dialog(owner, i18n.translate(title), secondary, buttons, state["dialogs"])
    return response == -5
end

function error_row(state, text, action="", title=""):
    root = ui_widgets.box(False, 10, ["error-row"])
    call gtk_ext.widget_set_margin_end(root, 40)
    call ui_widgets.pack(root, ui_widgets.label(text, None, None, True, True), True)
    if action:
        button = action_button(state, title, action, None, ["primary", "pill"])
        call gtk.widget_set_valign(button, 3)
        call gtk.box_pack_end(root, button, False, True, 0)
    end
    call add_row(state, root)
end

function clear_history(state, parent):
    if message_dialog(state, "Delete all conversations?", "All saved conversations will be permanently removed from this computer.", parent, "Delete all", True, True):
        call app_model.clear_history(state)
    end
end

function store_count(state):
    repository = store.Store(state["store_root"])
    return len(repository.list())
end

function screenshot_count(state):
    count = 0
    if exists(gui_bridge.shot_dir()):
        for name in listdir(gui_bridge.shot_dir()):
            if name.endswith(".png"):
                count += 1
            end
        end
    end
    return count
end

function clear_screenshots(state, parent):
    folder = gui_bridge.shot_dir()
    if exists(folder):
        for name in listdir(folder):
            if name.startswith("shot-") and name.endswith(".png"):
                try:
                    call platform.unlink(common.join(folder, name))
                else:
                    continue
                end
            end
        end
    end
end

function rename(state, id):
    conversation = state["conversation"]
    if conversation["id"] != id:
        try:
            conversation = app_model.load_conversation(state, id)
        else:
            return
        end
    end
    dialog = gtk_ext.dialog_new()
    call gtk.window_set_title(dialog, i18n.translate("Rename conversation"))
    call gtk.window_set_transient_for(dialog, state["widget"])
    call gtk.window_set_modal(dialog, True)
    call gtk_ext.dialog_add_button(dialog, i18n.translate("Cancel"), -6)
    call gtk.widget_add_class(gtk_ext.dialog_add_button(dialog, i18n.translate("Rename"), -5), "suggested-action")
    call gtk_ext.dialog_set_default_response(dialog, -5)
    entry = gtk.entry_new()
    call gtk.entry_set_text(entry, store.display_title(conversation))
    call gtk_ext.entry_set_width_chars(entry, 40)
    call gtk_ext.entry_set_activates_default(entry, True)
    area = gtk_ext.dialog_get_content_area(dialog)
    call gtk.container_set_border_width(area, 12)
    call gtk.box_set_spacing(area, 8)
    call ui_widgets.pack(area, ui_widgets.label(i18n.translate("Name"), None, ["dim", "small"]))
    call ui_widgets.pack(area, entry)
    state["dialogs"].append(dialog)
    call gtk.widget_show_all(dialog)
    response = gtk_ext.dialog_run(dialog)
    text = ""
    if dialog in state["dialogs"]:
        text = gtk.entry_get_text(entry)
        call state["dialogs"].remove(dialog)
        call gtk.widget_destroy(dialog)
    else:
        response = -4
    end
    if response == -5:
        call app_model.rename(state, id, text)
    end
end

function about(state):
    dialog = gtk_ext.about_dialog_new()
    call gtk.window_set_transient_for(dialog, state["widget"])
    call gtk.window_set_modal(dialog, True)
    call gtk_ext.about_dialog_set_program_name(dialog, "LuxAI")
    call gtk_ext.about_dialog_set_version(dialog, version.VERSION)
    call gtk_ext.about_dialog_set_comments(dialog, i18n.translate("AI assistant that can work with your computer"))
    call gtk_ext.about_dialog_set_website(dialog, "https://lux-ai.cz")
    image = icon(state, 96)
    if image:
        call gtk_ext.about_dialog_set_logo(dialog, image)
        call glib.object_unref(image)
    end
    state["dialogs"].append(dialog)
    call gtk_ext.dialog_run(dialog)
    if dialog in state["dialogs"]:
        call state["dialogs"].remove(dialog)
        call gtk.widget_destroy(dialog)
    end
end

function show_uri(state, uri):
    problem = platform.buffer(8)
    result = __lsl_qbe_call4(__lsl_symbol("gtk_show_uri_on_window"), platform.pointer(state["widget"]), platform.cstr(uri), 0, platform.address(problem))
    if result == 0:
        failure = __lsl_qbe_load64(platform.address(problem))
        text = "Cannot open link"
        if failure != 0:
            text = glib.from_c(__lsl_qbe_load64(failure + 8))
            call __lsl_qbe_call1(__lsl_symbol("g_error_free"), failure)
        end
        call message_dialog(state, text)
    end
end

function release_watch(record, arguments):
    call platform.release_callback(record)
end

function account_child_done(job, pid, status):
    call __lsl_qbe_call1(__lsl_symbol("g_spawn_close_pid"), platform.pointer(pid))
    call ui_dispatch.post(release_watch, job["record"])
    state = job["owner"]
    if not state["alive"] or state["closing"]:
        return
    end
    call gtk.widget_set_sensitive(state["signin_button"], True)
    call gtk.label_set_text(state["signin_status"], "")
    if job["action"] == "logout":
        state["signed_state"] = "signed_out"
    end
    call app_model.reload_account(state)
    if job["action"] == "login" and state["signed_state"] != "ok" and state["signed_state"] == job["previous"]:
        call gtk.label_set_text(state["signin_status"], i18n.translate("Not signed in."))
    elif job["action"] == "logout" and state["signed_state"] == "ok":
        call message_dialog(state, "Signing out failed. Try again in the LuxAI account app.")
    end
end

function account_action(state, action):
    if action == "logout":
        if not message_dialog(state, "Sign out of LuxAI?", "You will be signed out of your LuxAI account in all LuxOS apps on this computer. Your conversations stay on this computer.", 0, "Sign out", True, True):
            return
        end
    end
    program = glib.find_program_in_path("luxos-account")
    if not program:
        if action == "logout":
            call message_dialog(state, "The LuxOS account tool (luxos-account) is not installed.")
        else:
            call gtk.label_set_text(state["signin_status"], i18n.translate("The LuxOS account tool (luxos-account) is not installed."))
            call gtk_ext.stack_set_visible_child_name(state["stack"], "signin")
        end
        return
    end
    if action == "logout":
        call app_model.stop(state)
        call app_model.cancel_titles(state)
    else:
        call gtk.widget_set_sensitive(state["signin_button"], False)
        call gtk.label_set_text(state["signin_status"], i18n.translate("Finish signing in in the LuxAI account window…"))
    end
    try:
        pid = child_process.spawn([program, action], app_model.workdir(state), child_process.environment(), True)
        job = {"owner": state, "action": action, "previous": state["signed_state"]}
        record = 0
        lock platform.callback_lock:
            record = glib.record_bound(account_child_done, 2, job)
        end
        job["record"] = record
        call __lsl_qbe_call3(__lsl_symbol("g_child_watch_add"), platform.pointer(pid), glib.callback_third(), platform.pointer(record))
    else:
        problem = tools_error(String(last_error()))
        if action == "logout":
            call message_dialog(state, problem)
        else:
            call gtk.widget_set_sensitive(state["signin_button"], True)
            call gtk.label_set_text(state["signin_status"], problem)
        end
    end
end

function open_account(state):
    program = glib.find_program_in_path("luxos-account")
    if program:
        call child_process.spawn([program], app_model.workdir(state), child_process.environment())
    else:
        call show_uri(state, "https://lux-ai.cz")
    end
end

function notify_user(state, title, body):
    if state["settings"]["notify"] and not gtk.window_is_active(state["widget"]) and state["application"]:
        call gui_bridge.notify(state["gui"], title, body)
    end
end

function destroy_popover(widget, arguments):
    call gtk.widget_destroy(widget)
    call glib.object_unref(widget)
end

function popover_closed(binding, widget):
    state = binding["owner"]
    if state.get(binding["key"]) == widget:
        state[binding["key"]] = 0
        if binding["key"] == "quick_popover":
            state["quick_widgets"] = {}
        end
        # The native popdown call still uses the widget after emitting closed.
        # Keep our reference until that call has unwound to the main loop.
        call ui_dispatch.post(destroy_popover, widget)
    end
end

function quick_switch(binding, property, widget):
    state = binding["owner"]
    if state["syncing"]:
        return
    end
    active = Bool(gtk.switch_get_active(widget))
    if binding["key"] == "auto":
        state["permissions"]["auto_approve"] = active
        call update_mode(state)
    else:
        state["settings"]["vision"][state["model"]] = active
        call persist_setting(state, "vision", state["settings"]["vision"])
    end
end

function quick_timeout(state, widget):
    if not state["syncing"]:
        call persist_setting(state, "timeout", Int(gtk.spin_button_get_value(widget)))
    end
end

function quick_menu(state, anchor):
    if state.get("quick_popover"):
        call gtk_ext.popover_popdown(state["quick_popover"])
    end
    popover = gtk_ext.popover_new(anchor)
    call __lsl_qbe_call1(__lsl_symbol("g_object_ref_sink"), platform.pointer(popover))
    state["quick_popover"] = popover
    root = ui_widgets.box(True, 10)
    call gtk.container_set_border_width(root, 14)
    call gtk.widget_set_size_request(root, 320, -1)
    controls = {}
    for item in [["auto", "Auto-approve actions", "Agent actions run without asking. Dangerous actions still need two confirmations. Resets when LuxAI restarts.", state["permissions"]["auto_approve"]], ["vision", "Model can see images", "Attach screenshots for the current model. Turn on only if the model supports images; uses more tokens.", state["settings"]["vision"].get(state["model"])]]:
        row = ui_widgets.box(False, 10)
        texts = ui_widgets.box(True, 0)
        call ui_widgets.pack(texts, ui_widgets.label(i18n.translate(item[1]), None, ["conv-title"]))
        label = ui_widgets.label(i18n.translate(item[2]), None, ["dim", "small"], True)
        call gtk_ext.label_set_max_width_chars(label, 36)
        call ui_widgets.pack(texts, label)
        call ui_widgets.pack(row, texts, True)
        switch = gtk.switch_new()
        call gtk.switch_set_active(switch, Bool(item[3]))
        call gtk.widget_set_valign(switch, 3)
        call gtk_ext.connect(switch, "notify::active", quick_switch, {"owner": state, "key": item[0]}, 1)
        controls[item[0]] = switch
        call gtk.box_pack_end(row, switch, False, True, 0)
        call ui_widgets.pack(root, row)
    end
    call ui_widgets.pack(root, gtk.separator_new(0))
    row = ui_widgets.box(False, 10)
    call ui_widgets.pack(row, ui_widgets.label(i18n.translate("Working folder"), None, ["conv-title"]), True)
    controls["folder"] = action_button(state, settings_window.home_short(app_model.workdir(state)), "folder")
    call gtk.widget_set_size_request(controls["folder"], 150, -1)
    call ui_widgets.pack(row, controls["folder"])
    call ui_widgets.pack(root, row)
    row = ui_widgets.box(False, 10)
    call ui_widgets.pack(row, ui_widgets.label(i18n.translate("Command timeout (seconds)"), None, ["conv-title"]), True)
    spin = gtk.spin_button_new_with_range(10.0, 1800.0, 10.0)
    call gtk.spin_button_set_value(spin, state["settings"]["timeout"])
    call gtk_ext.connect(spin, "value-changed", quick_timeout, state)
    controls["timeout"] = spin
    call ui_widgets.pack(row, spin)
    call ui_widgets.pack(root, row)
    call ui_widgets.pack(root, gtk.separator_new(0))
    for item in [[i18n.translate("Settings…") + "  (Ctrl+,)", "settings"], ["LuxAI account…", "account"], ["About LuxAI", "about"]]:
        call ui_widgets.pack(root, action_button(state, item[0], item[1]))
    end
    state["quick_widgets"] = controls
    call gtk.container_add(popover, root)
    call gtk_ext.connect(popover, "closed", popover_closed, {"owner": state, "key": "quick_popover"})
    call gtk.widget_show_all(root)
    call gtk_ext.popover_popup(popover)
end

function profile_menu(state):
    if state.get("profile_popover"):
        call gtk_ext.popover_popdown(state["profile_popover"])
    end
    popover = gtk_ext.popover_new(state["profile_button"])
    call __lsl_qbe_call1(__lsl_symbol("g_object_ref_sink"), platform.pointer(popover))
    state["profile_popover"] = popover
    call gtk_ext.popover_set_position(popover, 2)
    root = ui_widgets.box(True, 4)
    call gtk.container_set_border_width(root, 10)
    call gtk.widget_set_size_request(root, 260, -1)
    user = common.fallback(state["user"], {})
    signed = state["signed_state"] == "ok" and Bool(state["account"])
    head = ui_widgets.box(False, 10)
    call gtk_ext.widget_set_margin_bottom(head, 4)
    name = String(common.fallback(user.get("displayName"), common.fallback(user.get("username"), common.fallback(user.get("email"), ""))))
    letter = "?"
    if signed:
        letter = common.fallback(String(platform.strip(name, common.WHITESPACE))[:1].upper(), "?")
    end
    avatar = ui_widgets.label(letter, None, ["avatar-big"], False, False, False, 0.5)
    call gtk.widget_set_valign(avatar, 3)
    call ui_widgets.pack(head, avatar)
    texts = ui_widgets.box(True, 1)
    call gtk.widget_set_valign(texts, 3)
    if signed:
        call ui_widgets.pack(texts, ui_widgets.label(common.fallback(name, "LuxAI"), None, ["profile-name"], False, False, True))
        if user.get("email"):
            call ui_widgets.pack(texts, ui_widgets.label(user["email"], None, ["dim", "small"], False, True, True))
        end
        usage = gtk.label_get_text(state["usage_label"])
        if usage:
            call ui_widgets.pack(texts, ui_widgets.label(usage, None, ["dim", "small"], True))
        end
    else:
        title = "Not signed in"
        if state["signed_state"] == "expired":
            title = "Session expired"
        end
        call ui_widgets.pack(texts, ui_widgets.label(i18n.translate(title), None, ["profile-name"]))
        call ui_widgets.pack(texts, ui_widgets.label(i18n.translate("Sign in with your LuxAI account to chat."), None, ["dim", "small"], True))
    end
    call ui_widgets.pack(head, texts, True)
    call ui_widgets.pack(root, head)
    call ui_widgets.pack(root, gtk.separator_new(0), False, True, 4)
    call ui_widgets.pack(root, action_button(state, "Settings…", "settings"))
    if signed:
        call ui_widgets.pack(root, action_button(state, "Manage account", "account"))
        call ui_widgets.pack(root, action_button(state, "Sign out…", "sign_out"))
    else:
        title = "Sign in"
        if state["signed_state"] == "expired":
            title = "Sign in again"
        end
        call ui_widgets.pack(root, action_button(state, title, "sign_in"))
    end
    call gtk.container_add(popover, root)
    call gtk_ext.connect(popover, "closed", popover_closed, {"owner": state, "key": "profile_popover"})
    call gtk.widget_show_all(root)
    call gtk_ext.popover_popup(popover)
end

function close_popovers(state):
    for key in ["quick_popover", "profile_popover"]:
        if state.get(key):
            call gtk_ext.popover_popdown(state[key])
        end
    end
end

function send(state):
    text = gtk_ext.buffer_text(gtk_ext.text_view_get_buffer(state["input"]))
    if app_model.send(state, text, state["gui"], gui_bridge.screen_size()):
        call gtk_ext.text_buffer_set_text(gtk_ext.text_view_get_buffer(state["input"]), "", -1)
        call note(state, "")
        call scroll_end(state)
    end
end

function ask(state, text, mode="agent"):
    if state["current_run"] != None:
        call set_input(state, text)
        return
    end
    if not store.conversation_empty(state["conversation"]):
        call app_model.new_conversation(state)
    end
    state["mode"] = mode
    state["conversation"]["mode"] = mode
    call persist_setting(state, "mode", mode)
    call set_input(state, text)
    if state["signed_state"] == "ok" and state["client"] != None:
        state["pending_ask"] = None
        call send(state)
    else:
        state["pending_ask"] = [text, mode]
    end
end

function clicked(binding, widget):
    state = binding["owner"]
    action = binding["action"]
    data = binding.get("data")
    if not state["alive"] or state["closing"]:
        return
    end
    if action not in ["quick_menu", "profile"]:
        call close_popovers(state)
    end
    if action == "new":
        call app_model.new_conversation(state)
    elif action == "send":
        call send(state)
    elif action == "stop":
        call app_model.stop(state)
    elif action == "suggestion":
        call set_input(state, data)
    elif action == "settings":
        if state["settings_window"] == None:
            call settings_window.new_window(state)
        else:
            call gtk.window_present(state["settings_window"]["widget"])
        end
    elif action == "quick_menu":
        call quick_menu(state, widget)
    elif action == "profile":
        call profile_menu(state)
    elif action == "sign_in":
        call account_action(state, "login")
    elif action == "sign_out":
        call account_action(state, "logout")
    elif action == "account":
        call open_account(state)
    elif action == "about":
        call about(state)
    elif action == "attach":
        call choose_attachments(state)
    elif action == "remove_attachment":
        if data in state["attachments"]:
            call state["attachments"].remove(data)
        end
        call note(state, "")
        call refresh_attachments(state)
    elif action == "folder":
        chooser = gtk_ext.file_dialog(state["widget"], i18n.translate("Working folder"), 2, False, "", i18n.translate("Cancel"))
        call gtk_ext.file_chooser_set_current_folder(chooser, app_model.workdir(state))
        response = gtk_ext.dialog_run(chooser)
        path = glib.take_c(gtk_ext.file_chooser_get_filename(chooser))
        call gtk.widget_destroy(chooser)
        if response == -3 and path:
            call persist_setting(state, "workdir", path)
        end
    elif action == "delete":
        if message_dialog(state, "Delete this conversation?", "It will be permanently removed from this computer.", 0, "Delete", True, True):
            call app_model.delete(state, data)
        end
    elif action == "rename":
        call rename(state, data)
    end
end

function input_key(state, event, widget):
    key = gtk.event_key_keyval(event)
    if key not in [65293, 65421]:
        return False
    end
    modifiers = gtk.event_key_state(event)
    if state["settings"]["send_key"] == "ctrl_enter":
        if (modifiers & 4) != 0:
            call send(state)
            return True
        end
    elif (modifiers & 1) == 0:
        call send(state)
        return True
    end
    return False
end

function window_key(state, event, widget):
    key = gtk.event_key_keyval(event)
    ctrl = (gtk.event_key_state(event) & 4) != 0
    if key == 65307:
        call app_model.stop(state)
        return True
    elif key == 65478:
        call gtk.toggle_button_set_active(state["sidebar_toggle"], not gtk.toggle_button_get_active(state["sidebar_toggle"]))
        return True
    end
    if not ctrl:
        return False
    end
    if key in [110, 78]:
        call app_model.new_conversation(state)
    elif key in [113, 81]:
        call gtk.window_close(state["widget"])
    elif key == 44:
        call clicked({"owner": state, "action": "settings"}, widget)
    elif key in [102, 70]:
        call gtk.toggle_button_set_active(state["sidebar_toggle"], True)
        call gtk_ext.widget_grab_focus(state["search"])
    elif key in [99, 67, 65379]:
        if gtk_ext.focus_has_selection(state["widget"]):
            return False
        end
        text = ui_widgets.selected_text(state["column"])
        if not text:
            return False
        end
        call gui_bridge.copy_text(text)
    else:
        return False
    end
    return True
end

function handle_event(state, name, arguments):
    if state["closing"] and name != "closed":
        return
    end
    if name == "user_message":
        if state["welcome"]:
            call clear_column(state)
            state["welcome"] = False
        end
        parts = attachments.message_parts(arguments[0])
        call add_row(state, ui_widgets.user_bubble(parts[0], parts[1], parts[2]))
        if parts[1] and not state["settings"]["vision"].get(state["model"]):
            call add_row(state, ui_widgets.label(i18n.translate("The current model cannot see images. They stay in the conversation and are sent when you switch to a model that can see images."), None, ["dim", "small"], True))
        end
        call scroll_end(state)
    elif name == "attachments_changed":
        call refresh_attachments(state)
    elif name == "running_changed":
        call update_mode(state)
    elif name == "conversation_changed":
        call update_mode(state)
        call render_conversation(state)
        call refresh_list(state)
        if state["signed_state"] != "ok":
            if store.conversation_empty(state["conversation"]):
                call show_main(state)
            else:
                call gtk_ext.stack_set_visible_child_name(state["stack"], "chat")
                sign_title = "Sign in"
                if state["signed_state"] == "expired":
                    sign_title = "Sign in again"
                end
                call error_row(state, i18n.translate("Sign in to continue this conversation."), "sign_in", sign_title)
                call scroll_end(state)
            end
        end
        call gtk_ext.widget_grab_focus(state["input"])
    elif name == "history_changed":
        call refresh_list(state)
    elif name == "stream_start":
        state["bubble"] = ui_widgets.assistant_bubble("", state["dark"])
        call add_row(state, state["bubble"]["widget"])
        call adjustment_changed(state, state["adjustment"])
    elif name == "stream_delta":
        if state["bubble"] != None:
            state["bubble"]["view"]["dark"] = state["dark"]
            call ui_widgets.append(state["bubble"], arguments[0], arguments[1])
        end
    elif name == "stream_end":
        if state["bubble"] != None:
            content = arguments[0].get("content")
            if content:
                call ui_widgets.finish(state["bubble"], content)
            else:
                call gtk.widget_destroy(state["bubble"]["widget"])
            end
            state["bubble"] = None
        end
        call adjustment_changed(state, state["adjustment"])
    elif name == "tool_start":
        card = ui_cards.new_card(arguments[0], arguments[1], arguments[2])
        state["cards"][arguments[0]] = card
        call add_row(state, card["widget"])
    elif name == "tool_prepared":
        if arguments[0] in state["cards"]:
            call ui_cards.set_prepared(state["cards"][arguments[0]], arguments[2])
        end
    elif name == "tool_confirm":
        request = arguments[0]
        card = state["cards"].get(request["id"])
        if card == None:
            call app_model.confirmation_done(request, "deny")
        else:
            call ui_cards.ask(card, request["kind"], request["reasons"], request["done"], request)
            call scroll_end(state)
            if not gtk.window_is_active(state["widget"]):
                call gtk_ext.window_set_urgency_hint(state["widget"], True)
                call notify_user(state, i18n.translate("LuxAI needs your approval"), i18n.translate(tool_format.label(card["name"])) + ": " + tool_format.subject(card["name"], card["args"]))
            end
        end
    elif name == "tool_running":
        card = state["cards"].get(arguments[0])
        if card != None and not card["done"] and card["state"] != "running":
            call ui_cards.set_status(card, "running")
        end
    elif name == "tool_result":
        card = state["cards"].get(arguments[0])
        if card != None:
            call ui_cards.set_result(card, arguments[2], arguments[3])
            call adjustment_changed(state, state["adjustment"])
        end
    elif name == "stopping":
        for card in state["cards"].values():
            if not card["answered"]:
                call ui_cards.answer(card, "deny")
            end
        end
        call gtk.label_set_text(state["status_line"], i18n.translate("Stopping…"))
    elif name == "usage":
        call update_account(state)
    elif name == "error":
        if state["bubble"] != None:
            if state["bubble"]["text"]:
                call ui_widgets.finish(state["bubble"])
            else:
                call gtk.widget_destroy(state["bubble"]["widget"])
            end
            state["bubble"] = None
        end
        if api.is_auth(arguments[0]):
            call update_account(state)
            call error_row(state, api.human(arguments[0]), "sign_in", "Sign in again")
        else:
            call error_row(state, api.human(arguments[0]))
        end
        call scroll_end(state)
    elif name == "finished":
        reason = arguments[0]
        call update_mode(state)
        if arguments[1] != state["conversation"]["id"]:
            return
        end
        if state["bubble"] != None:
            call ui_widgets.finish(state["bubble"])
            state["bubble"] = None
        end
        for card in state["cards"].values():
            if not card["done"]:
                status = "cancelled"
                if reason == "error":
                    status = "error"
                end
                call ui_cards.set_result(card, {"ok": False, "cancelled": True}, status)
            end
        end
        text = ""
        if reason == "cancelled":
            text = "Stopped."
        elif reason == "limit":
            text = "Stopped after too many steps. Send a message to continue."
        elif reason == "length":
            text = "The answer was cut off (length limit)."
        end
        if text:
            call add_row(state, ui_widgets.label(i18n.translate(text), None, ["dim", "small"]))
        end
        if reason in ["done", "length"]:
            call notify_user(state, i18n.translate("LuxAI answered"), store.display_title(state["conversation"]))
        end
        call gtk_ext.window_set_urgency_hint(state["widget"], False)
        if state["signed_state"] == "ok":
            state["refresh_at"] = time.monotonic() + 1.5
        end
        call adjustment_changed(state, state["adjustment"])
    elif name == "account_changed":
        if state["current_run"] == None:
            call show_main(state)
        else:
            call update_account(state)
        end
        if state["pending_ask"] != None and state["signed_state"] == "ok" and state["current_run"] == None:
            pending = state["pending_ask"]
            state["pending_ask"] = None
            call ask(state, pending[0], pending[1])
        end
    elif name == "account_offline":
        call gtk.label_set_text(state["account_sub"], i18n.translate("Offline – usage not available"))
    elif name == "settings_changed":
        key = arguments[0]
        if key == "theme":
            call apply_theme(state)
            if state["current_run"] == None and not store.conversation_empty(state["conversation"]):
                call render_conversation(state)
            end
        end
        call update_mode(state)
        if key == "keep_history":
            call refresh_list(state)
        elif key == "mode" and store.conversation_empty(state["conversation"]):
            call welcome(state)
        end
    elif name == "save_error":
        call error_row(state, arguments[0])
    elif name == "closed":
        if state["widget"]:
            call gtk.widget_destroy(state["widget"])
        end
        if state["application"]:
            call __lsl_qbe_call1(__lsl_symbol("g_application_quit"), platform.pointer(state["application"]))
        end
    end
end

function delete_event(state, event, widget):
    if state["closing"]:
        return True
    end
    if state["settings_window"] != None:
        call gtk.widget_destroy(state["settings_window"]["widget"])
    end
    for dialog in state["dialogs"].copy():
        # odebrat ze seznamu: volajici dialog_run uz ho pak znovu nenici
        call state["dialogs"].remove(dialog)
        call gtk.widget_destroy(dialog)
    end
    state["settings"]["window"] = gtk.window_get_size(widget)
    state["settings"]["sidebar"] = gtk_ext.paned_get_position(state["paned"])
    call gtk.widget_hide(widget)
    call app_model.close(state)
    return True
end

function destroyed(state, widget):
    state["widget"] = 0
    if state.get("tick") != None:
        call ui_dispatch.remove_tick(state["tick"])
    end
    if state.get("theme_signal"):
        call gtk_ext.disconnect(gtk.settings_get_default(), state["theme_signal"])
        state["theme_signal"] = 0
    end
    if state.get("css_provider"):
        call gtk.css_remove(state["css_provider"])
        state["css_provider"] = 0
    end
    if not state["closing"]:
        call app_model.close(state)
    end
end
