# lsl: internal-abi
# lsl: link libcurl.so.4 libglib-2.0.so.0 libc.so.6
# libcurl callbacks run on the requesting worker, never the GTK thread.
load glib
load platform

function ptr(value):
    return __lsl_unbox_int(value)
end

function cstr(text):
    return __lsl_address(text) + 16
end

function bytes_from_pointer(pointer, length):
    output = __lsl_byte_zeros(ptr(length))
    call __lsl_qbe_call3(__lsl_symbol("memcpy"), platform.address(output), ptr(pointer), ptr(length))
    return output
end

function concat_bytes(first, second):
    # nove pole first+second pres memcpy (bez smycky po bajtech)
    output = __lsl_byte_zeros(ptr(len(first) + len(second)))
    if len(first) > 0:
        call __lsl_qbe_call3(__lsl_symbol("memcpy"), platform.address(output), platform.address(first), ptr(len(first)))
    end
    if len(second) > 0:
        call __lsl_qbe_call3(__lsl_symbol("memcpy"), platform.address(output) + ptr(len(first)), platform.address(second), ptr(len(second)))
    end
    return output
end

function slice_bytes(bytes, start, length):
    output = __lsl_byte_zeros(ptr(max(0, length)))
    if length > 0:
        call __lsl_qbe_call3(__lsl_symbol("memcpy"), platform.address(output), platform.address(bytes) + ptr(start), ptr(length))
    end
    return output
end

function find_byte(bytes, value, start=0):
    # index prvniho vyskytu bajtu od start, jinak -1 (memchr)
    if start >= len(bytes):
        return -1
    end
    base = platform.address(bytes)
    found = __lsl_qbe_call3(__lsl_symbol("memchr"), base + ptr(start), ptr(value), ptr(len(bytes) - start))
    if found == 0:
        return -1
    end
    return Int(found - base)
end

function slice_text(bytes, start, length):
    return __lsl_text_from_bytes(bytes, start, length)
end

function text_from_bytes(bytes):
    return __lsl_text_from_bytes(bytes, 0, len(bytes))
end

function receive(state, pointer, size, count):
    length = size * count
    state["last_activity"] = glib.monotonic_time()
    if is_cancelled(state):
        state["cancelled"] = True
        return 0
    end
    try:
        if state["on_chunk"] != None and state["status"] >= 200 and state["status"] < 300:
            chunk = bytes_from_pointer(pointer, length)
            if state["callback_state"] == None:
                call state["on_chunk"](chunk)
            else:
                call state["on_chunk"](state["callback_state"], chunk)
            end
        else:
            available = max(0, state["limit"] - state["body_length"])
            copied = min(available, length)
            if copied > 0:
                call __lsl_qbe_call3(__lsl_symbol("memcpy"), platform.address(state["body"]) + ptr(state["body_length"]), ptr(pointer), ptr(copied))
                state["body_length"] += copied
            end
            if copied < length:
                if state.get("truncate_body"):
                    state["truncated"] = True
                    return 0
                end
                state["error"] = "Response exceeds the size limit"
                return 0
            end
        end
    else:
        state["error"] = String(last_error())
        return 0
    end
    return length
end

function receive_header(state, pointer, size, count):
    length = size * count
    state["last_activity"] = glib.monotonic_time()
    header = text_from_bytes(bytes_from_pointer(pointer, length))
    if header.startswith("HTTP/"):
        pieces = header.split(" ")
        if len(pieces) > 1:
            state["status"] = Int(pieces[1])
            state["headers"] = {}
        end
    elif ":" in header:
        split = header.find(":")
        state["headers"][header[:split].lower()] = header[split + 1:].strip()
    end
    return length
end

function is_cancelled(state):
    if state.get("cancelled"):
        return True
    end
    if state.get("should_stop") != None:
        if state["callback_state"] == None:
            return state["should_stop"]()
        end
        return state["should_stop"](state["callback_state"])
    end
    return False
end

function progress(state, download_total, download_now, upload_total, upload_now):
    if is_cancelled(state):
        state["cancelled"] = True
        return 1
    end
    if state["idle_timeout"] > 0 and glib.monotonic_time() - state["last_activity"] > state["idle_timeout"]:
        state["timed_out"] = True
        return 1
    end
    return 0
end

function set_long(handle, option, value):
    return __lsl_qbe_call3(__lsl_symbol("curl_easy_setopt"), ptr(handle), ptr(option), ptr(value))
end

function set_text(handle, option, value):
    return __lsl_qbe_call3(__lsl_symbol("curl_easy_setopt"), ptr(handle), ptr(option), cstr(value))
end

function request(method, url, headers, body="", timeout=30, on_chunk=None, should_stop=None, limit=4194304, resolve=None, callback_state=None, idle_timeout=False, truncate_body=False):
    if "\0" in url:
        Error(NetworkError: "Invalid URL")
    end
    handle = __lsl_qbe_call0(__lsl_symbol("curl_easy_init"))
    if handle == 0:
        Error(NetworkError: "Cannot initialize HTTP transport")
    end
    state = {"body": platform.buffer(limit), "body_length": 0, "status": 0, "headers": {}, "on_chunk": on_chunk, "should_stop": should_stop, "limit": limit, "cancelled": False, "error": "", "callback_state": callback_state}
    state["last_activity"] = glib.monotonic_time()
    state["idle_timeout"] = 0
    state["timed_out"] = False
    state["truncate_body"] = truncate_body
    state["truncated"] = False
    header_list = 0
    for key in headers.keys():
        value = headers[key]
        if "\r" in key or "\n" in key or "\r" in value or "\n" in value:
            call __lsl_qbe_call1(__lsl_symbol("curl_easy_cleanup"), handle)
            Error(NetworkError: "Invalid HTTP header")
        end
        header = key + ": " + value
        header_list = __lsl_qbe_call2(__lsl_symbol("curl_slist_append"), ptr(header_list), cstr(header))
    end
    writer = 0
    header_writer = 0
    progress_handler = 0
    callback_mutex = IntArray(platform.callback_lock)
    lock callback_mutex:
        writer = glib.record_bound(receive, 3, state)
        header_writer = glib.record_bound(receive_header, 3, state)
        progress_handler = glib.record_bound(progress, 4, state)
    end
    call set_text(handle, 10002, url)
    if idle_timeout:
        state["idle_timeout"] = timeout * 1000000
        call set_long(handle, 13, 0)
        call set_long(handle, 78, timeout)
    else:
        call set_long(handle, 13, timeout)
        call set_long(handle, 78, min(timeout, 15))
    end
    call set_long(handle, 99, 1)
    call set_long(handle, 52, 0)
    call set_long(handle, 181, 3)
    call set_long(handle, 182, 3)
    call set_text(handle, 10102, "")
    call set_text(handle, 10004, "")
    call set_long(handle, 10023, header_list)
    call set_long(handle, 20011, glib.callback_fourth())
    call set_long(handle, 10001, writer)
    call set_long(handle, 20079, glib.callback_fourth())
    call set_long(handle, 10029, header_writer)
    call set_long(handle, 20219, glib.callback_first())
    call set_long(handle, 10057, progress_handler)
    call set_long(handle, 43, 0)
    resolve_list = 0
    if resolve != None:
        for entry in resolve:
            resolve_list = __lsl_qbe_call2(__lsl_symbol("curl_slist_append"), ptr(resolve_list), cstr(entry))
        end
        call set_long(handle, 10203, resolve_list)
    end
    if method != "GET":
        call set_text(handle, 10015, body)
        body_length = __lsl_text_byte_length(body)
        call set_long(handle, 60, body_length)
        call set_text(handle, 10036, method)
    end
    result = __lsl_qbe_call1(__lsl_symbol("curl_easy_perform"), handle)
    call platform.release_callback(writer)
    call platform.release_callback(header_writer)
    call platform.release_callback(progress_handler)
    call __lsl_qbe_call1(__lsl_symbol("curl_easy_cleanup"), handle)
    call __lsl_qbe_call1(__lsl_symbol("curl_slist_free_all"), ptr(header_list))
    if resolve_list != 0:
        call __lsl_qbe_call1(__lsl_symbol("curl_slist_free_all"), ptr(resolve_list))
    end
    data = state["body"][:state["body_length"]]
    return {"status": state["status"], "headers": state["headers"], "text": text_from_bytes(data), "data": data, "code": result, "cancelled": state["cancelled"], "error": state["error"], "timed_out": state["timed_out"], "truncated": state["truncated"]}
end
