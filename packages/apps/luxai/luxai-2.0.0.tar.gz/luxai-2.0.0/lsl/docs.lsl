load common
load platform
load catalog
load math

function docs_dir():
    return common.environment("LUXAI_DOCS_DIR", "/usr/share/luxos/docs")
end

function fold(text):
    normalized = platform.unicode_normalize(String(text).lower(), 2)
    output = []
    for char in normalized:
        if platform.combining_class(char) == 0:
            output.append(char)
        end
    end
    return "".join(output)
end

function stem(word):
    if len(word) <= 4 or platform.regex_test("^\\d+$", word):
        return word
    end
    for suffix in catalog.DOCS_SUFFIXES:
        if word.endswith(suffix) and len(word) - len(suffix) >= 4:
            return word[:len(word) - len(suffix)]
        end
    end
    return word
end

function terms(text, keep_stopwords=False):
    output = []
    for match in platform.regex_findall("[a-z0-9]+", fold(text)):
        word = match["groups"][0]
        if not keep_stopwords and (word in catalog.DOCS_STOPWORDS or (len(word) < 2 and not platform.regex_test("^\\d+$", word))):
            continue
        end
        output.append(stem(word))
    end
    return output
end

function split_sections(text):
    # jako Python str.splitlines() (i \v, \f, \x1c-\x1e, \x85, U+2028, U+2029)
    lines = common.splitlines(text)
    heads = []
    fence = ""
    for index in rang(len(lines)):
        matches = platform.regex_findall("^\\s*(```|~~~)", lines[index])
        if matches:
            value = matches[0]["groups"][1]
            if fence == value:
                fence = ""
            elif not fence:
                fence = value
            end
            continue
        end
        if fence:
            continue
        end
        matches = platform.regex_findall("^(#{1,3})[ \t]+(.+?)[ \t#]*$", lines[index])
        if matches:
            heads.append([index, len(matches[0]["groups"][1]), matches[0]["groups"][2].strip(common.WHITESPACE)])
        end
    end
    sections = []
    if not heads or heads[0][0] > 0:
        finish = len(lines)
        if heads:
            finish = heads[0][0]
        end
        for line in lines[:finish]:
            if line.strip(common.WHITESPACE):
                sections.append({"heading": "", "level": 0, "path": [], "start": 0, "end": finish})
                break
            end
        end
    end
    stack = []
    for index in rang(len(heads)):
        head = heads[index]
        while stack and stack[len(stack) - 1][0] >= head[1]:
            call stack.pop()
        end
        stack.append([head[1], head[2]])
        finish = len(lines)
        if index + 1 < len(heads):
            finish = heads[index + 1][0]
        end
        path = []
        for entry in stack:
            path.append(entry[1])
        end
        sections.append({"heading": head[2], "level": head[1], "path": path, "start": head[0], "end": finish})
    end
    return [sections, lines]
end

function real_allow_missing(path):
    missing = []
    cursor = common.normalize(path)
    while cursor != "/" and platform.realpath(cursor) == "":
        parts = cursor.split("/")
        missing.insert(0, parts[len(parts) - 1])
        cursor = common.dirname(cursor)
    end
    resolved = platform.realpath(cursor)
    for part in missing:
        resolved = common.join(resolved, part)
    end
    return resolved
end

function safe_path(root, relative):
    relative = common.text(relative).strip(common.WHITESPACE).replace("\\", "/")
    if not relative or "\0" in relative or relative.startswith("/") or relative.startswith("~"):
        Error(DocsError: "Invalid documentation path: use a path from docs_search, e.g. luxos/lux.md")
    end
    parts = []
    for part in relative.split("/"):
        if part not in ["", "."]:
            parts.append(part)
        end
    end
    if not parts or ".." in parts:
        Error(DocsError: "Invalid documentation path: it must stay inside the documentation folder")
    end
    real_root = platform.realpath(root)
    full = real_allow_missing(common.join(real_root, "/".join(parts)))
    if not full.startswith(real_root.rstrip("/") + "/") or full == real_root:
        Error(DocsError: "Invalid documentation path: it must stay inside the documentation folder")
    end
    return full
end

function counts(words, weight, into):
    for word in words:
        into[word] = into.get(word, 0.0) + weight
    end
end

function scan_files(root, directory, entries):
    # jako os.walk: nejdriv soubory slozky (serazene), pak podslozky; odkazy na slozky se neprochazeji
    folders = []
    for name in sorted(listdir(directory)):
        path = common.join(directory, name)
        info = platform.file_info(path, False)
        if info != None and info["directory"]:
            folders.append(path)
        elif info != None and info["symlink"] and platform.file_info(path) != None and platform.file_info(path)["directory"]:
            continue
        elif name.endswith(".md") or name.endswith(".markdown") or name.endswith(".txt"):
            entries.append({"path": path[len(root.rstrip("/")) + 1:]})
        end
    end
    for path in folders:
        call scan_files(root, path, entries)
    end
end

function load_index(root):
    index_path = common.join(root, "index.json")
    if exists(index_path):
        data = common.read_json(index_path)
        if data == None:
            Error(DocsError: "The documentation index is damaged (JSONDecodeError); reinstall luxos-docs")
        end
        if type(data) != "Dictionary" or type(data.get("collections")) != "List":
            Error(DocsError: "The documentation index has an unknown format; reinstall luxos-docs")
        end
        return data
    end
    collections = []
    for name in sorted(listdir(root)):
        path = common.join(root, name)
        info = platform.file_info(path)
        if info != None and info["directory"]:
            entries = []
            call scan_files(root, path, entries)
            collections.append({"id": name, "title": name, "files": entries})
        end
    end
    return {"collections": collections}
end

function add_file(library, relative, info, text):
    split = split_sections(text)
    library["lines"][relative] = split[1]
    file_terms = {}
    call counts(terms(info["title"] + " " + " ".join(info["keywords"]) + " " + info["summary"]), 1.5, file_terms)
    for section in split[0]:
        tf = file_terms.copy()
        call counts(terms(section["heading"]), 3.0, tf)
        call counts(terms(" ".join(section["path"][:len(section["path"]) - 1])), 0.5, tf)
        start = section["start"]
        if section["level"]:
            start += 1
        end
        call counts(terms("\n".join(split[1][start:section["end"]])), 1.0, tf)
        section["file"] = relative
        section["tf"] = tf
        length = 0.0
        for value in tf.values():
            length += value
        end
        section["len"] = common.fallback(length, 1.0)
        library["sections"].append(section)
        for word in tf.keys():
            library["df"][word] = library["df"].get(word, 0) + 1
        end
    end
end

function new_library(root):
    library = {"root": root, "collections": [], "files": {}, "sections": [], "lines": {}, "df": {}, "avg_len": 1.0}
    data = load_index(root)
    total = 0
    for collection in data["collections"]:
        if type(collection) != "Dictionary" or type(collection.get("id")) != "String":
            continue
        end
        cid = collection["id"]
        library["collections"].append({"id": cid, "title": String(common.fallback(collection.get("title"), cid))})
        for original in common.fallback(collection.get("files"), []):
            if total >= 2000:
                break
            end
            entry = original
            if type(entry) == "String":
                entry = {"path": entry}
            end
            if type(entry) != "Dictionary" or type(entry.get("path")) != "String":
                continue
            end
            relative = entry["path"].strip(common.WHITESPACE)
            while relative.startswith("./"):
                relative = relative[2:]
            end
            full = ""
            try:
                full = safe_path(root, relative)
            else:
                continue
            end
            file = platform.file_info(full)
            if relative in library["files"] or file == None or not file["file"] or file["size"] > 2097152:
                continue
            end
            text = ""
            try:
                # jako Python open(errors="replace") v textovem rezimu (univerzalni konce radku)
                text = String(platform.utf8_decode(platform.read_prefix(full, 2097152))).replace("\r\n", "\n").replace("\r", "\n")
            else:
                continue
            end
            keywords = []
            if type(entry.get("keywords")) == "List":
                for word in entry["keywords"]:
                    keywords.append(String(word))
                end
            end
            names = relative.split("/")
            info = {"collection": cid, "title": String(common.fallback(entry.get("title"), names[len(names) - 1])), "summary": common.text(entry.get("summary")), "keywords": keywords, "abs": full}
            library["files"][relative] = info
            total += 1
            call add_file(library, relative, info, text)
        end
    end
    if library["sections"]:
        total_length = 0.0
        for section in library["sections"]:
            total_length += section["len"]
        end
        library["avg_len"] = total_length / len(library["sections"])
    end
    return library
end

function collection_id(library, name):
    if not name:
        return None
    end
    folded = fold(name).strip(common.WHITESPACE)
    available = []
    for collection in library["collections"]:
        available.append(collection["id"])
        if fold(collection["id"]) == folded or fold(collection["title"]) == folded:
            return collection["id"]
        end
    end
    Error(DocsError: "Unknown documentation collection " + common.py_repr(name) + "; available: " + ", ".join(available))
end

function section_text(library, section):
    return common.strip_text("\n".join(library["lines"][section["file"]][section["start"]:section["end"]]))
end

function expand(library, term):
    if term in library["df"]:
        return [[term, 1.0]]
    end
    if len(term) < 4 or platform.regex_test("^\\d+$", term):
        return []
    end
    output = []
    for word in library["df"].keys():
        if word[:4] != term[:4]:
            continue
        end
        length = 0
        while length < min(len(word), len(term)) and word[length] == term[length]:
            length += 1
        end
        if length >= max(4, min(len(word), len(term)) - 2):
            output.append([word, 0.7])
        end
    end
    return output
end

function snippet(library, section, query):
    start = section["start"]
    if section["level"]:
        start += 1
    end
    lines = []
    for line in library["lines"][section["file"]][start:section["end"]]:
        if line.strip(common.WHITESPACE) and not platform.regex_test("^\\s*(```|~~~)", line):
            lines.append(line.strip(common.WHITESPACE))
        end
    end
    if not lines:
        return ""
    end
    best = 0
    for index in rang(len(lines)):
        found = False
        for word in terms(lines[index]):
            if word in query:
                found = True
                break
            end
        end
        if found:
            best = index
            break
        end
    end
    text = common.words(" ".join(lines[best:best + 6]))
    if len(text) > 260:
        return text[:259].rstrip(common.WHITESPACE) + "…"
    end
    return text
end

function literal_terms(text):
    words = []
    for found in platform.regex_findall("[a-z0-9]+", fold(text)):
        words.append(found["groups"][0])
    end
    return " ".join(words)
end

function library_search(library, query, collection=None, limit=5):
    selected = collection_id(library, collection)
    words = terms(query)
    if not words:
        words = terms(query, True)
    end
    unique = []
    for word in words:
        if word not in unique:
            unique.append(word)
        end
    end
    if not unique:
        return []
    end
    expanded = []
    query_words = []
    for word in unique:
        alternatives = expand(library, word)
        expanded.append(alternatives)
        for alternative in alternatives:
            query_words.append(alternative[0])
        end
    end
    n = len(library["sections"])
    phrase = literal_terms(query)
    scored = []
    for section in library["sections"]:
        if selected and library["files"][section["file"]]["collection"] != selected:
            continue
        end
        score = 0.0
        hit = 0
        norm = 1.2 * (1 - 0.75 + 0.75 * section["len"] / library["avg_len"])
        for alternatives in expanded:
            part = 0.0
            for alternative in alternatives:
                word = alternative[0]
                frequency = section["tf"].get(word)
                if frequency:
                    df = library["df"].get(word, 0)
                    idf = math.log(1 + (n - df + 0.5) / (df + 0.5))
                    part = max(part, alternative[1] * idf * frequency * 2.2 / (frequency + norm))
                end
            end
            if part:
                hit += 1
                score += part
            end
        end
        if not hit:
            continue
        end
        score *= 0.5 + 0.5 * hit / len(unique)
        if len(unique) > 1 and phrase and phrase in literal_terms(" ".join(section["path"]) + " " + section_text(library, section)):
            score *= 1.5
        end
        row = [score, section]
        index = 0
        while index < len(scored):
            other = scored[index]
            earlier = score > other[0]
            if score == other[0]:
                if section["file"] == other[1]["file"]:
                    earlier = section["start"] < other[1]["start"]
                else:
                    earlier = sorted([section["file"], other[1]["file"]])[0] == section["file"]
                end
            end
            if earlier:
                break
            end
            index += 1
        end
        scored.insert(index, row)
    end
    output = []
    for row in scored[:max(1, min(Int(common.fallback(limit, 5)), 10))]:
        section = row[1]
        info = library["files"][section["file"]]
        output.append({"collection": info["collection"], "file": section["file"], "title": info["title"], "heading": " > ".join(section["path"]), "snippet": snippet(library, section, query_words), "score": Int(row[0] * 100 + 0.5) / 100.0})
    end
    return output
end

function resolve(library, path):
    relative = common.text(path).strip(common.WHITESPACE).replace("\\", "/")
    if relative.startswith("./"):
        relative = relative[2:]
    end
    call safe_path(library["root"], relative)
    if relative in library["files"]:
        return relative
    end
    want = relative
    if not (want.endswith(".md") or want.endswith(".markdown") or want.endswith(".txt")):
        want += ".md"
    end
    if want in library["files"]:
        return want
    end
    candidates = []
    for file in library["files"].keys():
        parts = file.split("/")
        if file.endswith("/" + want) or parts[len(parts) - 1] == want:
            candidates.append(file)
        end
    end
    if len(candidates) == 1:
        return candidates[0]
    end
    if candidates:
        Error(DocsError: "Ambiguous documentation path " + common.py_repr(path) + "; use one of: " + ", ".join(candidates))
    end
    Error(DocsError: "No documentation file " + common.py_repr(path) + "; use a path returned by docs_search")
end

function find_section(sections, heading):
    wanted = common.words(fold(heading).strip(common.WHITESPACE).lstrip("#").strip(common.WHITESPACE))
    if not wanted:
        return None
    end
    for pass in rang(4):
        for section in sections:
            if not section["level"]:
                continue
            end
            name = fold(section["heading"])
            full = fold(" > ".join(section["path"]))
            if (pass == 0 and name == wanted) or (pass == 1 and full == wanted) or (pass == 2 and full.endswith(wanted)) or (pass == 3 and wanted in name):
                return section
            end
        end
    end
    return None
end

function library_read(library, path, heading=None, limit=12000):
    relative = resolve(library, path)
    info = library["files"][relative]
    sections = []
    headings = []
    for section in library["sections"]:
        if section["file"] == relative:
            sections.append(section)
            if section["level"]:
                headings.append("#" * section["level"] + " " + section["heading"])
            end
        end
    end
    output = {"ok": True, "collection": info["collection"], "file": relative, "title": info["title"]}
    text = ""
    if heading:
        section = find_section(sections, heading)
        if section == None:
            return {"ok": False, "file": relative, "error": "No section " + common.py_repr(heading) + " in " + relative + "; pick one of the headings", "headings": headings[:300]}
        end
        finish = len(library["lines"][relative])
        for later in sections:
            if later["start"] > section["start"] and later["level"] and later["level"] <= section["level"]:
                finish = later["start"]
                break
            end
        end
        text = common.strip_text("\n".join(library["lines"][relative][section["start"]:finish]))
        output["heading"] = " > ".join(section["path"])
    else:
        text = common.strip_text("\n".join(library["lines"][relative]))
    end
    if len(text) > limit:
        cut = common.rfind(text[:limit], "\n")
        if cut <= limit // 2:
            cut = limit
        end
        text = common.rstrip_text(text[:cut])
        shown = text.split("\n")
        rest = []
        for title in headings:
            if title not in shown:
                rest.append(title)
            end
        end
        output["truncated"] = True
        output["note"] = "The text was shortened. Read the remaining parts with docs_read(path, heading) using one of the headings."
        output["headings"] = rest[:300]
        if len(rest) > 300:
            output["more_headings"] = len(rest) - 300
        end
    end
    output["content"] = text
    return output
end

cache = {"key": None, "library": None}
cache_lock = IntArray()
cache_lock.append(0)

function library(root=None):
    root = common.fallback(root, docs_dir())
    info = platform.file_info(root)
    if info == None or not info["directory"]:
        return None
    end
    index_info = platform.file_info(common.join(root, "index.json"))
    key = [platform.realpath(root), info["mtime"], info["mtime_ns"], index_info]
    cached = None
    lock cache_lock:
        if cache["key"] == key and cache["library"] != None:
            cached = cache["library"]
        end
    end
    if cached != None:
        return cached
    end
    loaded = new_library(root)
    lock cache_lock:
        cache["key"] = key
        cache["library"] = loaded
    end
    return loaded
end

function missing_result():
    return {"ok": False, "docs_missing": True, "error": "The offline LuxOS documentation is not installed (package luxos-docs, folder " + docs_dir() + "). Answer from general knowledge and say that the reference was not available; the user can install it with `lux install luxos-docs`."}
end

function clean_error(value):
    start = value.find(": ")
    if start >= 0:
        value = value[start + 2:]
    end
    finish = common.rfind(value, " at ")
    if finish >= 0:
        value = value[:finish]
    end
    return value
end

function search(query, collection=None, limit=5):
    if type(query) != "String" or not query.strip(common.WHITESPACE):
        return {"ok": False, "error": "query must be a non-empty string"}
    end
    if collection != None and type(collection) != "String":
        return {"ok": False, "error": "collection must be a string"}
    end
    try:
        loaded = library()
        if loaded == None:
            return missing_result()
        end
        if not loaded["files"]:
            missing = missing_result()
            missing["error"] = "The LuxOS documentation folder contains no documents."
            return missing
        end
        results = library_search(loaded, query.strip(common.WHITESPACE)[:500], collection, limit)
        output = {"ok": True, "query": query.strip(common.WHITESPACE)[:500], "results": results}
        if collection:
            output["collection"] = collection
        end
        if results:
            output["hint"] = "Read more with docs_read(path=file, heading=heading)."
        else:
            available = []
            for item in loaded["collections"]:
                available.append(item["id"])
            end
            output["note"] = "No matching section. Try other or fewer words (Czech or English), or another collection: " + ", ".join(available)
        end
        return output
    else:
        return {"ok": False, "error": clean_error(String(last_error()))}
    end
end

function read(path, heading=None):
    if type(path) != "String" or not path.strip(common.WHITESPACE):
        return {"ok": False, "error": "path must be a non-empty string"}
    end
    if heading != None and type(heading) != "String":
        return {"ok": False, "error": "heading must be a string"}
    end
    try:
        loaded = library()
        if loaded == None:
            return missing_result()
        end
        return library_read(loaded, path, heading)
    else:
        return {"ok": False, "error": clean_error(String(last_error()))}
    end
end
