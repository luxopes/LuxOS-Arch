# iCalendar (RFC 5545) for the LuxAI calendar tools: the parts of the LuxOS Calendar module
# (luxos-desktop lsl/luxos_ics.lsl, Python luxos_calendar_ics.py) that LuxAI needs, with the same
# behaviour: VEVENT (SUMMARY, DTSTART/DTEND/DURATION, RRULE DAILY/WEEKLY/MONTHLY/YEARLY with
# INTERVAL/COUNT/UNTIL/BYDAY/BYMONTHDAY/BYMONTH, EXDATE, RECURRENCE-ID, COLOR, VALARM);
# unknown properties and components are kept unchanged.
#
# Event = Dictionary like in luxos_ics: uid, summary, all_day, start, end (day ordinal or naive
# local seconds, see calendar_time), color, description, location, rrule, rrule_raw, exdates,
# exdate_lines, recurrence_id, extra (lines), alarms (blocks of lines), source, readonly.
load common
load calendar_time
load calendar_clock

COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
WEEKDAYS = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"]
MAX_INSTANCES = 50000
PRODID = "-//LuxOS//Calendar 1.0//EN"
KNOWN = ["UID", "SUMMARY", "DTSTART", "DTEND", "DURATION", "RRULE", "EXDATE", "COLOR", "RECURRENCE-ID", "DESCRIPTION", "LOCATION"]
DAY = 86400
DAYS_BEFORE = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]

# ---- date math (luxos_date) ----------------------------------------------------------------------

function is_leap(year):
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)
end

function days_in_month(year, month):
    if month == 2:
        if is_leap(year):
            return 29
        end
        return 28
    end
    return [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1]
end

function add_months(year, month, delta):
    index = year * 12 + (month - 1) + delta
    return [index // 12, index % 12 + 1]
end

function ordinal(year, month, day):
    y = year - 1
    n = y * 365 + y // 4 - y // 100 + y // 400 + DAYS_BEFORE[month - 1] + day
    if month > 2 and is_leap(year):
        n += 1
    end
    return n
end

function from_ordinal(value):
    n = value - 1
    n400 = n // 146097
    n = n % 146097
    year = n400 * 400 + 1
    n100 = n // 36524
    n = n % 36524
    n4 = n // 1461
    n = n % 1461
    n1 = n // 365
    n = n % 365
    year += n100 * 100 + n4 * 4 + n1
    if n1 == 4 or n100 == 4:
        return [year - 1, 12, 31]
    end
    leap = n1 == 3 and (n4 != 24 or n100 == 3)
    month = (n + 50) >> 5
    before = DAYS_BEFORE[month - 1]
    if month > 2 and leap:
        before += 1
    end
    if before > n:
        month -= 1
        before = DAYS_BEFORE[month - 1]
        if month > 2 and leap:
            before += 1
        end
    end
    return [year, month, n - before + 1]
end

function month_of(day):
    return from_ordinal(day)[1]
end

function day_of(day):
    return from_ordinal(day)[2]
end

# 0 = Monday ... 6 = Sunday
function weekday(day):
    return (day + 6) % 7
end

function make(day, hour, minute, second):
    return day * DAY + hour * 3600 + minute * 60 + second
end

function date_of(moment):
    return moment // DAY
end

function pad(value, width):
    text = String(value)
    while len(text) < width:
        text = "0" + text
    end
    return text
end

function format_date(day):
    ymd = from_ordinal(day)
    return pad(ymd[0], 4) + pad(ymd[1], 2) + pad(ymd[2], 2)
end

function format_moment(moment):
    seconds = moment % DAY
    return format_date(date_of(moment)) + "T" + pad(seconds // 3600, 2) + pad(seconds % 3600 // 60, 2) + pad(seconds % 60, 2)
end

function iso_date(day):
    ymd = from_ordinal(day)
    return pad(ymd[0], 4) + "-" + pad(ymd[1], 2) + "-" + pad(ymd[2], 2)
end

function digits(value):
    if value == "":
        return False
    end
    for char in value:
        if ord(char) < 48 or ord(char) > 57:
            return False
        end
    end
    return True
end

function to_int(value, default):
    text = String(value).strip()
    body = text
    if body.startswith("-") or body.startswith("+"):
        body = body[1:]
    end
    if not digits(body):
        return default
    end
    return Int(text.replace("+", ""))
end

function utf8_length(char):
    code = ord(char)
    if code < 128:
        return 1
    elif code < 2048:
        return 2
    elif code < 65536:
        return 3
    end
    return 4
end

# ---- lines and values ----------------------------------------------------------------------------

function unfold(source):
    body = source.replace("\r\n", "\n").replace("\r", "\n")
    out = []
    for line in body.split("\n"):
        if (line.startswith(" ") or line.startswith("\t")) and len(out) > 0:
            out[len(out) - 1] = out[len(out) - 1] + line[1:]
        elif line.strip() != "":
            out.append(line)
        end
    end
    return out
end

# Fold to at most 75 octets per line without splitting a multi-byte character.
function fold(line, newline="\r\n"):
    out = []
    current = ""
    size = 0
    for char in line:
        n = utf8_length(char)
        if size + n > 75:
            out.append(current)
            current = " "
            size = 1
        end
        current = current + char
        size += n
    end
    out.append(current)
    return newline.join(out)
end

function valid_name(name):
    if name == "":
        return False
    end
    for char in name:
        code = ord(char)
        if not ((code >= 65 and code <= 90) or (code >= 48 and code <= 57) or char == "-"):
            return False
        end
    end
    return True
end

# 'NAME;P=V;Q="a:b":value' -> [NAME, {P: V}, value]; invalid line -> None
function parse_line(line):
    i = 0
    n = len(line)
    quoted = False
    while i < n:
        c = line[i]
        if c == "\"":
            quoted = not quoted
        elif c == ":" and not quoted:
            break
        end
        i += 1
    end
    if i >= n:
        return None
    end
    head = line[0:i]
    value = line[i + 1:]
    parts = []
    current = ""
    quoted = False
    for c in head:
        if c == "\"":
            quoted = not quoted
            current = current + c
        elif c == ";" and not quoted:
            parts.append(current)
            current = ""
        else:
            current = current + c
        end
    end
    parts.append(current)
    name = parts[0].strip().upper()
    if not valid_name(name):
        return None
    end
    params = {}
    for p in parts[1:]:
        cut = p.find("=")
        if cut >= 0:
            params[p[:cut].strip().upper()] = p[cut + 1:].strip().strip("\"")
        end
    end
    return [name, params, value]
end

function unescape(value):
    out = []
    i = 0
    n = len(value)
    while i < n:
        c = value[i]
        if c == "\\" and i + 1 < n:
            following = value[i + 1]
            if following == "n" or following == "N":
                out.append("\n")
            else:
                out.append(following)
            end
            i += 2
            continue
        end
        out.append(c)
        i += 1
    end
    return "".join(out)
end

# TEXT value (RFC 5545 3.3.11). Control characters other than TAB and newline are dropped.
function escape(value):
    clean = []
    for char in String(value).replace("\r\n", "\n").replace("\r", "\n"):
        code = ord(char)
        if char == "\n" or char == "\t" or not (code < 32 or (code >= 127 and code < 160) or code == 8232 or code == 8233):
            clean.append(char)
        end
    end
    return "".join(clean).replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
end

function zone_known(name):
    return calendar_clock.zone_known(name)
end

# DATE or DATE-TIME -> ["D", ordinal] / ["T", naive local time]; invalid -> ValueError
function parse_dt(value, params):
    v = value.strip()
    is_date = params.get("VALUE", "").upper() == "DATE" or (len(v) == 8 and digits(v))
    if is_date:
        if len(v) < 8 or not digits(v[0:8]):
            Error(ValueError: "bad date")
        end
        month = Int(v[4:6])
        day = Int(v[6:8])
        if month < 1 or month > 12 or day < 1 or day > days_in_month(Int(v[0:4]), month) or Int(v[0:4]) < 1:
            Error(ValueError: "bad date")
        end
        return ["D", ordinal(Int(v[0:4]), month, day)]
    end
    n = len(v)
    utc = False
    if n > 0 and v[n - 1] == "Z":
        utc = True
        v = v[0:n - 1]
        n -= 1
    end
    if not (n == 13 or n == 15) or v[8] != "T" or not digits(v[0:8]) or not digits(v[9:]):
        Error(ValueError: "bad date-time")
    end
    second = 0
    if n == 15:
        second = min(Int(v[13:15]), 59)
    end
    month = Int(v[4:6])
    day = Int(v[6:8])
    if Int(v[0:4]) < 1 or month < 1 or month > 12 or day < 1 or day > days_in_month(Int(v[0:4]), month):
        Error(ValueError: "bad date-time")
    end
    hour = Int(v[9:11])
    minute = Int(v[11:13])
    if hour > 23 or minute > 59:
        Error(ValueError: "bad date-time")
    end
    moment = make(ordinal(Int(v[0:4]), month, day), hour, minute, second)
    if utc:
        return ["T", calendar_clock.from_unix(moment - calendar_clock.EPOCH * DAY)]
    end
    zone = params.get("TZID", "")
    if zone != "" and zone != calendar_clock.local_tz_name() and zone_known(zone):
        return ["T", calendar_clock.zone_to_local(moment, zone)]
    end
    return ["T", moment]
end

# RFC 5545 DURATION -> seconds (signed); ValueError when invalid
function parse_duration(value):
    v = value.strip()
    sign = 1
    i = 0
    if v.startswith("-"):
        sign = -1
        i = 1
    elif v.startswith("+"):
        i = 1
    end
    if i >= len(v) or v[i] != "P" or len(v) == i + 1:
        Error(ValueError: "bad duration")
    end
    i += 1
    total = 0
    in_time = False
    seen = ""
    while i < len(v):
        c = v[i]
        if c == "T":
            if in_time:
                Error(ValueError: "bad duration")
            end
            in_time = True
            i += 1
            continue
        end
        start = i
        while i < len(v) and digits(v[i]):
            i += 1
        end
        if start == i or i >= len(v):
            Error(ValueError: "bad duration")
        end
        number = Int(v[start:i])
        unit = v[i]
        i += 1
        if not in_time and unit == "W" and seen == "":
            total += number * 7 * 86400
        elif not in_time and unit == "D" and (seen == "" or seen == "W"):
            total += number * 86400
        elif in_time and unit == "H" and seen.find("H") < 0 and seen.find("M") < 0 and seen.find("S") < 0:
            total += number * 3600
        elif in_time and unit == "M" and seen.find("M") < 0 and seen.find("S") < 0:
            total += number * 60
        elif in_time and unit == "S" and seen.find("S") < 0:
            total += number
        else:
            Error(ValueError: "bad duration")
        end
        seen = seen + unit
    end
    if in_time and (seen == "" or seen.endswith("T")):
        Error(ValueError: "bad duration")
    end
    return sign * total
end

function format_dt(kind, value, tzname):
    if kind == "D":
        return [";VALUE=DATE", format_date(value)]
    end
    if zone_known(tzname):
        return [";TZID=" + tzname, format_moment(value)]
    end
    return ["", format_moment(value)]
end

# ---- events ---------------------------------------------------------------------------------------

function event_new(summary, all_day, start, finish):
    return {"uid": calendar_time.new_uid(), "summary": summary, "all_day": all_day, "start": start, "end": finish, "color": None, "description": "", "location": "", "rrule": None, "rrule_raw": None, "exdates": [], "exdate_lines": [], "recurrence_id": None, "extra": [], "alarms": [], "source": None, "readonly": False}
end

function kind_of(event):
    if event["all_day"]:
        return "D"
    end
    return "T"
end

# Length: days (all-day) or seconds
function duration(event):
    if event["end"] == None:
        if event["all_day"]:
            return 1
        end
        return 0
    end
    return max(event["end"] - event["start"], 0)
end

# Minutes before the start from VALARM (TRIGGER relative to the start), else None
function reminder_minutes(event):
    best = None
    for block in event["alarms"]:
        for line in block:
            p = parse_line(line)
            if p == None or p[0] != "TRIGGER":
                continue
            end
            if p[1].get("VALUE", "").upper() == "DATE-TIME" or p[1].get("RELATED", "START").upper() != "START":
                continue
            end
            seconds = 0
            try:
                seconds = parse_duration(p[2])
            else:
                continue
            end
            minutes = (0 - seconds) // 60
            if minutes >= 0 and (best == None or minutes < best):
                best = minutes
            end
        end
    end
    return best
end

# Same as luxos_ics.set_reminder: None removes; an unchanged reminder keeps its VALARM untouched.
function set_reminder(event, minutes):
    if minutes == reminder_minutes(event) and (minutes != None or len(event["alarms"]) == 0):
        return
    end
    event["alarms"] = []
    if minutes != None:
        summary = common.fallback(event["summary"], "Reminder")
        event["alarms"].append(["BEGIN:VALARM", "ACTION:DISPLAY", "DESCRIPTION:" + escape(summary), "TRIGGER:-PT" + String(minutes) + "M", "END:VALARM"])
    end
end

function parse_rrule(raw):
    rule = {}
    for part in raw.split(";"):
        cut = part.find("=")
        if cut >= 0:
            key = part[:cut].strip().upper()
            if key == "UNTIL":
                rule[key] = part[cut + 1:].strip()
            else:
                rule[key] = part[cut + 1:].strip().upper()
            end
        end
    end
    return rule
end

function has_dtstamp(event):
    for line in event["extra"]:
        if line.upper().startswith("DTSTAMP"):
            return True
        end
    end
    return False
end

function to_lines(event, tzname):
    lines = ["BEGIN:VEVENT", "UID:" + event["uid"]]
    if not has_dtstamp(event):
        lines.append("DTSTAMP:" + format_moment(calendar_time.now_unix() + calendar_clock.EPOCH * DAY) + "Z")
    end
    kind = kind_of(event)
    if event["recurrence_id"] != None:
        pv = format_dt(event["recurrence_id"][0], event["recurrence_id"][1], tzname)
        lines.append("RECURRENCE-ID" + pv[0] + ":" + pv[1])
    end
    pv = format_dt(kind, event["start"], tzname)
    lines.append("DTSTART" + pv[0] + ":" + pv[1])
    if event["end"] != None:
        pv = format_dt(kind, event["end"], tzname)
        lines.append("DTEND" + pv[0] + ":" + pv[1])
    end
    lines.append("SUMMARY:" + escape(event["summary"]))
    if event["description"] != "":
        lines.append("DESCRIPTION:" + escape(event["description"]))
    end
    if event["location"] != "":
        lines.append("LOCATION:" + escape(event["location"]))
    end
    if event["color"] != None and event["color"] != "":
        lines.append("COLOR:" + event["color"])
    end
    if event["rrule_raw"] != None and event["rrule_raw"] != "":
        lines.append("RRULE:" + event["rrule_raw"])
    end
    lines.extend(event["exdate_lines"])
    lines.extend(event["extra"])
    for block in event["alarms"]:
        lines.extend(block)
    end
    lines.append("END:VEVENT")
    return lines
end

# VEVENT lines (without BEGIN/END) -> event; ValueError without DTSTART or with an invalid date
function event_from_lines(lines):
    event = event_new("", False, None, None)
    event["uid"] = ""
    i = 0
    n = len(lines)
    duration_prop = None
    start_kind = None
    end_kind = None
    while i < n:
        line = lines[i]
        up = line.upper()
        if up.startswith("BEGIN:"):
            name = up[6:].strip()
            block = [line]
            depth = 1
            i += 1
            while i < n and depth > 0:
                block.append(lines[i])
                u = lines[i].upper()
                if u.startswith("BEGIN:"):
                    depth += 1
                elif u.startswith("END:"):
                    depth -= 1
                end
                i += 1
            end
            if name == "VALARM":
                event["alarms"].append(block)
            else:
                event["extra"].extend(block)
            end
            continue
        end
        i += 1
        p = parse_line(line)
        if p == None:
            event["extra"].append(line)
            continue
        end
        name = p[0]
        params = p[1]
        value = p[2]
        if name not in KNOWN:
            event["extra"].append(line)
        elif name == "UID":
            event["uid"] = value.strip()
        elif name == "SUMMARY":
            event["summary"] = unescape(value)
        elif name == "DESCRIPTION":
            event["description"] = unescape(value)
        elif name == "LOCATION":
            event["location"] = unescape(value)
        elif name == "COLOR":
            event["color"] = value.strip().lower()
        elif name == "DTSTART":
            kv = parse_dt(value, params)
            event["all_day"] = kv[0] == "D"
            event["start"] = kv[1]
            start_kind = kv[0]
        elif name == "DTEND":
            kv = parse_dt(value, params)
            event["end"] = kv[1]
            end_kind = kv[0]
        elif name == "DURATION":
            duration_prop = parse_duration(value)
        elif name == "RECURRENCE-ID":
            event["recurrence_id"] = parse_dt(value, params)
        elif name == "RRULE":
            event["rrule_raw"] = value.strip()
            event["rrule"] = parse_rrule(value.strip())
        elif name == "EXDATE":
            event["exdate_lines"].append(line)
            for item in value.split(","):
                if item.strip() != "":
                    event["exdates"].append(parse_dt(item, params))
                end
            end
        end
    end
    if event["start"] == None:
        Error(ValueError: "VEVENT without DTSTART")
    end
    if event["end"] == None and duration_prop != None:
        if event["all_day"]:
            event["end"] = event["start"] + duration_prop // 86400
        else:
            event["end"] = event["start"] + duration_prop
        end
    end
    if event["end"] != None and end_kind != None and end_kind != start_kind:
        if end_kind == "T":
            event["end"] = date_of(event["end"])
        else:
            event["end"] = event["end"] * DAY
        end
    end
    if event["end"] != None and event["end"] < event["start"]:
        event["end"] = event["start"]
    end
    return event
end

# Raw text -> calendar {header, events, other, errors}; broken VEVENTs are kept in other
function parse(source):
    cal = {"header": ["VERSION:2.0", "PRODID:" + PRODID], "events": [], "other": [], "errors": 0}
    body = source
    while body.startswith(chr(65279)):
        body = body[1:]
    end
    lines = unfold(body)
    header = []
    i = 0
    n = len(lines)
    in_cal = False
    while i < n:
        line = lines[i]
        up = line.upper().strip()
        if up == "BEGIN:VCALENDAR":
            in_cal = True
            i += 1
            continue
        end
        if up == "END:VCALENDAR":
            in_cal = False
            i += 1
            continue
        end
        if up.startswith("BEGIN:"):
            name = up[6:]
            block = [line]
            depth = 1
            i += 1
            while i < n and depth > 0:
                u = lines[i].upper().strip()
                if u.startswith("BEGIN:"):
                    depth += 1
                elif u.startswith("END:"):
                    depth -= 1
                end
                block.append(lines[i])
                i += 1
            end
            if name == "VEVENT":
                inner = block[1:]
                if block[len(block) - 1].upper().startswith("END:"):
                    inner = block[1:len(block) - 1]
                end
                try:
                    cal["events"].append(event_from_lines(inner))
                else:
                    cal["errors"] += 1
                    cal["other"].append(block)
                end
            else:
                cal["other"].append(block)
            end
            continue
        end
        if in_cal and parse_line(line) != None:
            header.append(line)
        end
        i += 1
    end
    if header:
        cal["header"] = header
    end
    return cal
end

# Whole new calendar text (only for an empty or missing events.ics)
function calendar_text(events, tzname, newline="\r\n"):
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:" + PRODID]
    for event in events:
        lines.extend(to_lines(event, tzname))
    end
    lines.append("END:VCALENDAR")
    out = []
    for line in lines:
        out.append(fold(line, newline) + newline)
    end
    return "".join(out)
end

function event_text(event, tzname, newline):
    out = []
    for line in to_lines(event, tzname):
        out.append(fold(line, newline) + newline)
    end
    return "".join(out)
end

# ---- occurrences (same as luxos_ics.starts/occurrences) --------------------------------------------

function rule_int(rule, key, default):
    value = rule.get(key)
    if value == None:
        return default
    end
    return to_int(value, default)
end

function byday(spec):
    out = []
    if spec == None:
        return out
    end
    for raw in spec.split(","):
        item = raw.strip()
        if len(item) < 2:
            continue
        end
        code = item[len(item) - 2:]
        prefix = item[0:len(item) - 2]
        if code not in WEEKDAYS:
            continue
        end
        nth = None
        if prefix != "":
            body = prefix
            if body.startswith("+") or body.startswith("-"):
                body = body[1:]
            end
            if not digits(body) or len(body) > 2:
                continue
            end
            nth = Int(prefix.replace("+", ""))
        end
        out.append([nth, WEEKDAYS.index(code)])
    end
    return out
end

function bymonth_set(rule):
    out = []
    spec = rule.get("BYMONTH")
    if spec == None:
        return out
    end
    for item in spec.split(","):
        month = to_int(item, 0)
        if month >= 1 and month <= 12 and month not in out:
            out.append(month)
        end
    end
    return out
end

function month_days(year, month, rule, start_day):
    dim = days_in_month(year, month)
    days = []
    bymd = []
    spec = rule.get("BYMONTHDAY")
    if spec != None:
        for item in spec.split(","):
            if item.strip() != "":
                bymd.append(item)
            end
        end
    end
    rule_days = byday(rule.get("BYDAY"))
    if bymd:
        for item in bymd:
            v = to_int(item, 0)
            if v > 0 and v <= dim and v not in days:
                days.append(v)
            elif v < 0 and 0 - v <= dim and dim + v + 1 not in days:
                days.append(dim + v + 1)
            end
        end
    elif rule_days:
        for item in rule_days:
            nth = item[0]
            matches = []
            for d in rang(1, dim + 1):
                if weekday(ordinal(year, month, d)) == item[1]:
                    matches.append(d)
                end
            end
            if nth == None:
                for m in matches:
                    if m not in days:
                        days.append(m)
                    end
                end
            elif nth > 0 and nth <= len(matches):
                if matches[nth - 1] not in days:
                    days.append(matches[nth - 1])
                end
            elif nth < 0 and 0 - nth <= len(matches):
                if matches[len(matches) + nth] not in days:
                    days.append(matches[len(matches) + nth])
                end
            end
        end
    elif day_of(start_day) <= dim:
        days.append(day_of(start_day))
    end
    out = []
    for d in sorted(days):
        out.append(ordinal(year, month, d))
    end
    return out
end

function emit_day(state, day):
    if state["done"]:
        return
    end
    state["n"] += 1
    if state["n"] > MAX_INSTANCES:
        state["done"] = True
        return
    end
    s = day
    if not state["all_day"]:
        s = day * DAY + state["tod"]
    end
    if state["until"] != None and s > state["until"]:
        state["done"] = True
        return
    end
    state["produced"] += 1
    if state["count"] != None and state["produced"] > state["count"]:
        state["done"] = True
        return
    end
    if day >= state["limit"]:
        state["done"] = True
        return
    end
    for ex in state["excluded"]:
        if ex[0] == "D" and ex[1] == day:
            return
        end
        if ex[0] == "T" and not state["all_day"] and ex[1] == s:
            return
        end
    end
    state["out"].append(s)
end

function candidate(state, day):
    if day > state["start_day"]:
        call emit_day(state, day)
    end
end

# Occurrence starts (ascending) before day until_day, in the event's domain
function starts(event, until_day):
    rule = event["rrule"]
    if rule == None:
        return [event["start"]]
    end
    freq = rule.get("FREQ")
    if freq not in ["DAILY", "WEEKLY", "MONTHLY", "YEARLY"]:
        return [event["start"]]
    end
    interval = max(1, rule_int(rule, "INTERVAL", 1))
    count = rule_int(rule, "COUNT", None)
    until = None
    if rule.get("UNTIL"):
        try:
            until = parse_dt(rule["UNTIL"], {})
        else:
            until = None
        end
    end
    all_day = event["all_day"]
    start = event["start"]
    start_day = start
    tod = 0
    if not all_day:
        start_day = date_of(start)
        tod = start - start_day * DAY
    end
    until_value = None
    if until != None:
        if until[0] == "T" and all_day:
            until_value = date_of(until[1])
        elif until[0] == "D" and not all_day:
            until_value = make(until[1], 23, 59, 59)
        else:
            until_value = until[1]
        end
    end
    state = {"out": [], "n": 0, "produced": 0, "done": False, "count": count, "until": until_value, "limit": until_day, "all_day": all_day, "tod": tod, "start_day": start_day, "excluded": event["exdates"]}
    # DTSTART is always the first occurrence (RFC 5545)
    call emit_day(state, start_day)
    months = bymonth_set(rule)
    if freq == "DAILY":
        d = start_day
        while not state["done"]:
            if not months or month_of(d) in months:
                call candidate(state, d)
            end
            d += interval
            if d >= until_day and d > start_day:
                break
            end
        end
    elif freq == "WEEKLY":
        wds = []
        for item in byday(rule.get("BYDAY")):
            if item[1] not in wds:
                wds.append(item[1])
            end
        end
        if not wds:
            wds = [weekday(start_day)]
        end
        wds = sorted(wds)
        wkst = 0
        if rule.get("WKST") in WEEKDAYS:
            wkst = WEEKDAYS.index(rule["WKST"])
        end
        week = start_day - (weekday(start_day) - wkst) % 7
        while not state["done"]:
            days = []
            for wd in wds:
                days.append(week + (wd - wkst) % 7)
            end
            for d in sorted(days):
                if not months or month_of(d) in months:
                    call candidate(state, d)
                end
            end
            week += 7 * interval
            if week >= until_day:
                break
            end
        end
    elif freq == "MONTHLY":
        ym = from_ordinal(start_day)
        y = ym[0]
        m = ym[1]
        while not state["done"]:
            if not months or m in months:
                for d in month_days(y, m, rule, start_day):
                    call candidate(state, d)
                end
            end
            ym = add_months(y, m, interval)
            y = ym[0]
            m = ym[1]
            if y > 9999 or ordinal(y, m, 1) >= until_day:
                break
            end
        end
    else:
        ym = from_ordinal(start_day)
        y = ym[0]
        start_month = ym[1]
        start_dom = ym[2]
        explicit = len(months) > 0 or rule.get("BYDAY") != None or rule.get("BYMONTHDAY") != None
        while not state["done"]:
            if explicit:
                chosen = months
                if not chosen:
                    chosen = [start_month]
                end
                for m in sorted(chosen):
                    for d in month_days(y, m, rule, start_day):
                        call candidate(state, d)
                    end
                end
            elif start_dom <= days_in_month(y, start_month):
                call candidate(state, ordinal(y, start_month, start_dom))
            end
            y += interval
            if y > 9999 or ordinal(y, 1, 1) >= until_day:
                break
            end
        end
    end
    return state["out"]
end

# Occurrences [[start, end]] overlapping the day range <range_start, range_end)
function occurrences(event, range_start, range_end):
    length = duration(event)
    rs = range_start
    re_ = range_end
    if not event["all_day"]:
        rs = range_start * DAY
        re_ = range_end * DAY
    end
    out = []
    for s in starts(event, range_end):
        e = s + length
        if s >= re_:
            break
        end
        if e > rs or (s >= rs and length == 0):
            out.append([s, e])
        end
    end
    return out
end
