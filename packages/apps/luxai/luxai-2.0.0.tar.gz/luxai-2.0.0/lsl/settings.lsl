load common
load catalog
load glib

function config_dir():
    return common.join(common.environment("XDG_CONFIG_HOME", common.join(glib.home_dir(), ".config")), "luxai")
end

function normalize_policy(policy):
    result = common.copy(catalog.POLICY_DEFAULTS)
    if type(policy) == "Dictionary":
        for key in catalog.POLICY_LEVELS.keys():
            if policy.get(key) in catalog.POLICY_LEVELS[key]:
                result[key] = policy[key]
            end
        end
        for key in ["allowed_folders", "blocked_folders"]:
            if type(policy.get(key)) == "List":
                folders = []
                for folder in policy[key]:
                    if type(folder) == "String" and folder.strip(common.WHITESPACE) and len(folders) < 50:
                        folders.append(folder)
                    end
                end
                result[key] = folders
            end
        end
        if policy.get("root_mode") in ["password", "nopass", "noask"]:
            result["root_mode"] = policy["root_mode"]
        end
    end
    result["sudo_confirm"] = True
    return result
end

function valid(key, value, default):
    if type(default) == "Bool":
        return type(value) == "Bool"
    end
    if type(default) == "Float":
        return type(value) == "Int" or type(value) == "Float"
    end
    if type(value) != type(default):
        return False
    end
    if key in catalog.CHOICES:
        return value in catalog.CHOICES[key]
    end
    return True
end

class Settings:
    ctype Public

    function init(self, path=None):
        self.path = path
        if path == None:
            self.path = common.join(config_dir(), "settings.json")
        end
        self.data = common.copy(catalog.SETTINGS_DEFAULTS)
        stored = common.read_json(self.path)
        if type(stored) != "Dictionary":
            stored = None
        end
        if stored == None and path == None:
            stored = common.read_json(common.join(config_dir(), "luxai-app.json"))
        end
        if type(stored) == "Dictionary":
            for key in stored.keys():
                if key in catalog.SETTINGS_DEFAULTS and key != "version" and valid(key, stored[key], catalog.SETTINGS_DEFAULTS[key]):
                    self.data[key] = stored[key]
                end
            end
        end
        self.data["agent"] = normalize_policy(self.data.get("agent"))
        self.data["temperature"] = min(1.5, max(0.0, Float(self.data["temperature"])))
        self.data["instructions"] = self.data["instructions"][:4000]
        self.data["timeout"] = min(1800, max(10, Int(self.data["timeout"])))
        visibility = self.data["vision"]
        self.data["vision"] = {"flash": Bool(visibility.get("flash")), "lite": Bool(visibility.get("lite"))}
        if stored and "vision_v2" not in stored:
            self.data["vision"]["flash"] = True
            self.data["vision_v2"] = True
        end
    end

    function get(self, key, default=None):
        return self.data.get(key, default)
    end

    function max_tokens(self):
        return catalog.ANSWER_LENGTHS.get(self.data["answer_length"], 4096)
    end

    function save(self):
        self.data["agent"] = normalize_policy(self.data.get("agent"))
        try:
            call common.atomic_json(self.path, self.data)
            return True
        else:
            return False
        end
    end
end
