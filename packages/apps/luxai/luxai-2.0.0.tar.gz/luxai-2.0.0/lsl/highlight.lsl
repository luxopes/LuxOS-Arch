load catalog
load common
load platform

function esc(text):
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
end

function canonical(language):
    return catalog.HIGHLIGHT_ALIASES.get(common.text(language).strip(common.WHITESPACE).lower(), "")
end

function language_name(language):
    return catalog.HIGHLIGHT_NAMES.get(canonical(language))
end

function span(kind, text, colors):
    color = colors.get(kind)
    if not color or not text:
        return esc(text)
    end
    style = ""
    if kind == "comment":
        style = " style=\"italic\""
    elif kind == "keyword":
        style = " weight=\"bold\""
    end
    return "<span foreground=\"" + color + "\"" + style + ">" + esc(text) + "</span>"
end

function tokens(code, language, colors):
    rules = catalog.HIGHLIGHT_RULES[language]
    output = []
    position = 0
    for match in platform.regex_findall(rules["pattern"], code, 2):
        if match["start"] == match["end"]:
            continue
        end
        output.append(esc(code[position:match["start"]]))
        kind = ""
        for index in rang(len(rules["indices"])):
            if match["groups"][rules["indices"][index]] != "":
                kind = rules["kinds"][index]
                break
            end
        end
        output.append(span(kind, match["groups"][0], colors))
        position = match["end"]
    end
    output.append(esc(code[position:]))
    return "".join(output)
end

function markup_language(code, colors, html):
    output = []
    position = 0
    while position < len(code):
        matches = platform.regex_findall(catalog.HIGHLIGHT_TAG, code[position:])
        if not matches:
            break
        end
        match = matches[0]
        output.append(esc(code[position:position + match["start"]]))
        text = match["groups"][0]
        position += match["end"]
        if text.startswith("<!--"):
            output.append(span("comment", text, colors))
            continue
        elif text.startswith("<!") or text.startswith("<?"):
            output.append(span("meta", text, colors))
            continue
        elif text.startswith("&"):
            output.append(span("number", text, colors))
            continue
        end
        name = platform.regex_findall("^</?[\\w:.-]+", text)[0]["groups"][0]
        output.append(span("tag", name, colors))
        rest = text[len(name):]
        endings = platform.regex_findall("/?>$", rest)
        inner = rest
        close = ""
        if endings:
            inner = rest[:endings[0]["start"]]
            close = endings[0]["groups"][0]
        end
        inner_position = 0
        for attribute in platform.regex_findall(catalog.HIGHLIGHT_ATTR, inner):
            output.append(esc(inner[inner_position:attribute["start"]]))
            groups = attribute["groups"]
            if groups[1]:
                output.append(span("attr", groups[1], colors) + esc(groups[2]) + span("string", groups[3], colors))
            else:
                output.append(span("string", groups[4], colors))
            end
            inner_position = attribute["end"]
        end
        output.append(esc(inner[inner_position:]))
        output.append(span("tag", close, colors))
        tag = name.lstrip("<").lower()
        if html and tag in ["script", "style"] and not close.startswith("/"):
            end_matches = platform.regex_findall("(?i)</" + tag + "\\s*>", code[position:])
            stop = len(code)
            if end_matches:
                stop = position + end_matches[0]["start"]
            end
            language = "css"
            if tag == "script":
                language = "javascript"
            end
            output.append(tokens(code[position:stop], language, colors))
            position = stop
        end
    end
    output.append(esc(code[position:]))
    return "".join(output)
end

function highlight(code, language="", dark=False):
    code = common.text(code)
    if len(code) > 200000:
        return esc(code)
    end
    palette = "light"
    if dark:
        palette = "dark"
    end
    colors = catalog.HIGHLIGHT_COLORS[palette]
    selected = canonical(language)
    if selected in ["html", "xml"]:
        return markup_language(code, colors, selected == "html")
    end
    return tokens(code, common.fallback(selected, "generic"), colors)
end
