# lsl: internal-abi
load root_helper
load platform
try:
    exit(root_helper.command_main(root_helper.command_args()))
else:
    call platform.stderr("luxai-root: " + String(last_error()) + "\n")
    exit(125)
end
