# lsl: internal-abi
# Public-address classification and one DNS resolution before HTTP pinning.
load platform
load glib
load web_data

function ip(text):
    if "\0" in String(text):
        return None
    end
    text = String(text).split("%")[0]
    data = platform.buffer(16)
    if __lsl_qbe_call3(__lsl_symbol("inet_pton"), 2, platform.cstr(text), platform.address(data)) == 1:
        return {"version": 4, "bytes": data[:4]}
    end
    if __lsl_qbe_call3(__lsl_symbol("inet_pton"), 10, platform.cstr(text), platform.address(data)) == 1:
        return {"version": 6, "bytes": data}
    end
    return None
end

function in_network(bytes, network):
    prefix = network[1]
    target = network[0]
    if len(bytes) != len(target):
        return False
    end
    full = prefix // 8
    for index in rang(full):
        if bytes[index] != target[index]:
            return False
        end
    end
    remaining = prefix % 8
    if remaining != 0:
        mask = (255 << (8 - remaining)) & 255
        if (bytes[full] & mask) != (target[full] & mask):
            return False
        end
    end
    return True
end

function in_any(bytes, networks):
    for network in networks:
        if in_network(bytes, network):
            return True
        end
    end
    return False
end

function ipv4_text(bytes):
    return String(bytes[0]) + "." + String(bytes[1]) + "." + String(bytes[2]) + "." + String(bytes[3])
end

function public_ip(text):
    parsed = ip(text)
    if parsed == None:
        return False
    end
    bytes = parsed["bytes"]
    if parsed["version"] == 6:
        mapped = True
        for index in rang(10):
            if bytes[index] != 0:
                mapped = False
                break
            end
        end
        if mapped and bytes[10] == 255 and bytes[11] == 255:
            return public_ip(ipv4_text(bytes[12:16]))
        end
        if bytes[0] == 32 and bytes[1] == 2:
            return public_ip(ipv4_text(bytes[2:6]))
        end
        nat64 = [0, 100, 255, 155, 0, 0, 0, 0, 0, 0, 0, 0]
        is_nat64 = True
        for index in rang(12):
            if bytes[index] != nat64[index]:
                is_nat64 = False
                break
            end
        end
        if is_nat64:
            return public_ip(ipv4_text(bytes[12:16]))
        end
        if in_any(bytes, web_data.IP6_PRIVATE_NETWORKS) and not in_any(bytes, web_data.IP6_PRIVATE_NETWORKS_EXCEPTIONS):
            return False
        end
        if in_any(bytes, web_data.IP6_OTHER_BLOCKED):
            return False
        end
    else:
        if in_any(bytes, web_data.IP4_PRIVATE_NETWORKS) and not in_any(bytes, web_data.IP4_PRIVATE_NETWORKS_EXCEPTIONS):
            return False
        end
        if in_any(bytes, web_data.IP4_OTHER_BLOCKED):
            return False
        end
    end
    return not in_any(bytes, web_data.IP_EXTRA)
end

function ascii_host(host):
    if "\0" in host:
        Error(WebError: "Invalid host name")
    end
    if ":" in host:
        return host
    end
    value = __lsl_qbe_call1(__lsl_symbol("g_hostname_to_ascii"), platform.cstr(host))
    if value == 0:
        Error(WebError: "Invalid host name")
    end
    return glib.take_c(value)
end

function addresses(host, port):
    host = ascii_host(host)
    hints = platform.buffer(48)
    call __lsl_qbe_store32(platform.address(hints) + 8, 1)
    slot = platform.buffer(8)
    service = String(port)
    status = __lsl_qbe_call4(__lsl_symbol("getaddrinfo"), platform.cstr(host), platform.cstr(service), platform.address(hints), platform.address(slot))
    if status != 0:
        problem = glib.from_c(__lsl_qbe_call1(__lsl_symbol("gai_strerror"), status))
        Error(WebError: "Cannot resolve host " + host + ": " + problem)
    end
    first = __lsl_qbe_load64(platform.address(slot))
    entry = first
    output = []
    while entry != 0:
        family = __lsl_qbe_load32(entry + 4)
        address = __lsl_qbe_load64(entry + 24)
        data = address + 4
        if family == 10:
            data = address + 8
        end
        if family in [2, 10] and address != 0:
            rendered = platform.buffer(80)
            result = __lsl_qbe_call4(__lsl_symbol("inet_ntop"), family, data, platform.address(rendered), 80)
            if result != 0:
                text = glib.from_c(result)
                if text not in output:
                    output.append(text)
                end
            end
        end
        entry = __lsl_qbe_load64(entry + 40)
    end
    if first != 0:
        call __lsl_qbe_call1(__lsl_symbol("freeaddrinfo"), first)
    end
    return output
end

function resolve_public(host, port, resolver=None):
    host = host.strip("[]")
    values = []
    if resolver == None:
        values = addresses(host, port)
    else:
        values = resolver(host, port)
    end
    if not values:
        Error(WebError: "Cannot resolve host " + host)
    end
    for address in values:
        if not public_ip(address):
            Error(WebError: "Blocked: " + host + " resolves to a local or private network address (" + address + "); only public internet addresses can be fetched")
        end
    end
    return values[0]
end
