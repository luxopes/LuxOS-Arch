# lsl: internal-abi
# Test driver for the calendar tools (tests_lsl/test_calendar.py). Not part of the application.
# Runs the real tools backend and safety judge against the calendar of $XDG_DATA_HOME given by
# the test (temporary profile); never the user's calendar.
load common
load json
load platform
load i18n
load tools
load safety
load prompts
load calendar
load calendar_data
load calendar_time
load calendar_clock

hook_plan = {"text": None, "times": 0, "mode": "append_event"}

# Another program (the Calendar app saves without the lock) writes between our read and rename.
function external_write(state, path, attempt):
    if hook_plan["times"] <= 0:
        return
    end
    hook_plan["times"] -= 1
    current = ""
    if exists(path):
        current = String(readfile(path))
    end
    cut = common.rfind(current, "END:VCALENDAR")
    changed = current[:cut] + hook_plan["text"] + current[cut:]
    temporary = path + ".external"
    call writefile(temporary, changed)
    call platform.rename(temporary, path)
end

function run_op(backend, item):
    op = item["op"]
    if op == "execute":
        return tools.execute(backend, item["name"], item.get("args", {}))
    elif op == "prepare":
        return tools.prepare(backend, item["name"], item.get("args", {}))
    elif op == "external":
        hook_plan["text"] = item["text"]
        hook_plan["times"] = item.get("times", 1)
        backend["calendar_hook"] = external_write
        return True
    elif op == "decide":
        permissions = safety.new_permissions(item.get("auto", False), item.get("policy"))
        for name in item.get("always", []):
            call safety.remember(permissions, name, "always")
        end
        return safety.decide(permissions, item["name"], item.get("args", {}), "/tmp", None, False, item.get("mode", "agent"))
    elif op == "definitions":
        chat = tools.new_tools("/tmp", None, 120, False, None, None, None, item.get("chat", False))
        names = []
        for definition in chat["definitions"]:
            names.append(definition["function"]["name"])
        end
        return names
    elif op == "prompt":
        return prompts.system_prompt(item.get("mode", "agent"), "/tmp", False, "", {}, {}, "flash", False, False, False, False, item.get("calendar", True))
    elif op == "summary":
        return calendar.summary(item["name"], item["result"])
    elif op == "when":
        return calendar.when_text(item["event"])
    elif op == "tz":
        return calendar_clock.local_tz_name()
    end
    Error(ValueError: "unknown op " + op)
end

fixture = json.decode(readfile(arg(1)))
call i18n.initialize(fixture.get("app_root", "/nonexistent"), "/nonexistent", {"LANG": fixture.get("lang", "en")})
backend = tools.new_tools(fixture.get("cwd", "/tmp"), None, 120, False, None, None)
results = []
for item in fixture["ops"]:
    try:
        results.append({"ok": True, "value": run_op(backend, item)})
    else:
        results.append({"ok": False, "error": String(last_error())})
    end
end
print json.encode(results)
