load gtk
load gtk_ext
load ui_widgets
load ui_format
load ui_dispatch
load ui_data
load i18n
load common
load platform
load settings
load rootmode
load glib
load time

PAGES = [["general", "General"], ["ai", "AI behaviour"], ["agent", "Agent permissions"], ["privacy", "Privacy & history"], ["shortcuts", "Keyboard shortcuts"]]

function home_short(path):
    home = glib.home_dir()
    if path == home or path.startswith(home + "/"):
        return "~" + path[len(home):]
    end
    return path
end

function group(page, title, foot=""):
    if title:
        call ui_widgets.pack(page, ui_widgets.label(i18n.translate(title), None, ["group-title"]))
    end
    root = ui_widgets.box(True, 0, ["group"])
    call ui_widgets.pack(page, root)
    if foot:
        label = ui_widgets.label(i18n.translate(foot), None, ["group-foot"], True)
        call gtk_ext.label_set_max_width_chars(label, 80)
        call ui_widgets.pack(page, label)
    end
    return {"widget": root, "rows": 0}
end

function row(group, title, widget=0, hint=""):
    root = ui_widgets.box(False, 12, ["srow"])
    if group["rows"]:
        call gtk.widget_add_class(root, "srow-sep")
    end
    texts = ui_widgets.box(True, 1)
    call gtk.widget_set_valign(texts, 3)
    call ui_widgets.pack(texts, ui_widgets.label(i18n.translate(title), None, None, True))
    if hint:
        label = ui_widgets.label(i18n.translate(hint), None, ["hint"], True)
        call gtk_ext.label_set_max_width_chars(label, 56)
        call ui_widgets.pack(texts, label)
    end
    call ui_widgets.pack(root, texts, True)
    if widget:
        call gtk.widget_set_valign(widget, 3)
        call gtk.box_pack_end(root, widget, False, True, 0)
    end
    call ui_widgets.pack(group["widget"], root)
    group["rows"] += 1
    return root
end

function widget_row(group, widget):
    root = ui_widgets.box(True, 6, ["srow"])
    if group["rows"]:
        call gtk.widget_add_class(root, "srow-sep")
    end
    call ui_widgets.pack(root, widget)
    call ui_widgets.pack(group["widget"], root)
    group["rows"] += 1
end

function changed_parent(state, key):
    parent = state["parent"]
    if parent.get("on_setting_changed") != None:
        call parent["on_setting_changed"](parent, key)
    end
    state["save_at"] = time.monotonic() + 0.3
end

function set_value(state, key, value, scope=""):
    if scope:
        state["data"][scope][key] = value
        if scope == "agent":
            state["data"]["agent"] = settings.normalize_policy(state["data"]["agent"])
        end
        call changed_parent(state, scope)
    else:
        state["data"][key] = value
        call changed_parent(state, key)
    end
    if key == "send_key" and "shortcuts" in state["pages"]:
        call build_shortcuts(state, state["pages"]["shortcuts"])
    end
end

function binding_value(binding):
    values = binding["window"]["data"]
    if binding["scope"]:
        values = values[binding["scope"]]
    end
    return values.get(binding["key"])
end

function combo_changed(binding, widget):
    state = binding["window"]
    if state["syncing"] or not state["alive"]:
        return
    end
    value = glib.from_c(gtk_ext.combo_box_get_active_id(widget))
    if not value:
        return
    end
    if binding["key"] == "root_mode":
        call change_root(state, value)
    else:
        call set_value(state, binding["key"], value, binding["scope"])
    end
end

function switch_changed(binding, property, widget):
    state = binding["window"]
    if not state["syncing"] and state["alive"]:
        value = Bool(gtk.switch_get_active(widget))
        call set_value(state, binding["key"], value, binding["scope"])
        if binding["key"] == "temperature_custom":
            call gtk.widget_set_sensitive(state["widgets"]["temperature"]["widget"], value)
        end
    end
end

function spin_changed(binding, widget):
    state = binding["window"]
    if not state["syncing"] and state["alive"]:
        value = gtk.spin_button_get_value(widget)
        call set_value(state, binding["key"], Int(value), binding["scope"])
    end
end

function scale_changed(binding, widget):
    state = binding["window"]
    if not state["syncing"] and state["alive"]:
        value = gtk.range_get_value(widget)
        call set_value(state, binding["key"], Int(value * 100 + 0.5) / 100.0)
    end
end

function register(state, key, kind, widget, scope=""):
    identity = key
    if scope:
        identity = scope + "_" + key
    end
    binding = {"window": state, "key": key, "scope": scope, "kind": kind, "widget": widget}
    state["widgets"][identity] = binding
    return binding
end

function combo(state, key, options, scope=""):
    widget = gtk.combo_box_text_new()
    binding = register(state, key, "combo", widget, scope)
    for option in options:
        call gtk.combo_box_text_append(widget, option[0], i18n.translate(option[1]))
    end
    call gtk_ext.combo_box_set_active_id(widget, String(binding_value(binding)))
    call gtk_ext.connect(widget, "changed", combo_changed, binding)
    return widget
end

function switch(state, key, scope=""):
    widget = gtk.switch_new()
    binding = register(state, key, "switch", widget, scope)
    call gtk.switch_set_active(widget, Bool(binding_value(binding)))
    call gtk_ext.connect(widget, "notify::active", switch_changed, binding, 1)
    return widget
end

function instruction_changed(state, buffer):
    if state["alive"] and not state["syncing"]:
        state["instructions_at"] = time.monotonic() + 0.5
    end
end

function save(state):
    state["save_at"] = 0.0
    state["data"]["agent"] = settings.normalize_policy(state["data"]["agent"])
    try:
        call common.atomic_json(state["parent"]["settings_path"], state["data"])
        return True
    else:
        return False
    end
end

function flush_instructions(state):
    if state["instructions_at"]:
        state["instructions_at"] = 0.0
        text = String(gtk_ext.buffer_text(gtk_ext.text_view_get_buffer(state["instructions"])))
        call set_value(state, "instructions", text[:4000])
    end
end

function tick(state, arguments):
    if not state["alive"]:
        return
    end
    if state["instructions_at"] and time.monotonic() >= state["instructions_at"]:
        call flush_instructions(state)
    end
    if state["save_at"] and time.monotonic() >= state["save_at"]:
        call save(state)
    end
end

function destroyed(state, widget):
    call flush_instructions(state)
    if state["save_at"]:
        call save(state)
    end
    state["alive"] = False
    call ui_dispatch.remove_tick(state["tick"])
    if state["parent"].get("settings_window") == state:
        state["parent"]["settings_window"] = None
    end
end

function key_pressed(state, event, widget):
    if gtk.event_key_keyval(event) == 65307:
        call gtk.widget_destroy(state["widget"])
        return True
    end
    return False
end

function nav_selected(state, row, widget):
    if row:
        index = gtk.list_box_row_get_index(row)
        if index >= 0 and index < len(PAGES):
            call gtk_ext.stack_set_visible_child_name(state["stack"], PAGES[index][0])
        end
    end
end

function show_page(state, key):
    index = 0
    for page in PAGES:
        if page[0] == key:
            call gtk_ext.list_box_select_row(state["nav"], gtk_ext.list_box_get_row_at_index(state["nav"], index))
            return
        end
        index += 1
    end
end

function general(state, page):
    g = group(page, "Appearance")
    call row(g, "Theme", combo(state, "theme", [["system", "Same as system"], ["light", "Light"], ["dark", "Dark"]]))
    g = group(page, "Messages")
    call row(g, "Send message with", combo(state, "send_key", [["enter", "Enter (Shift+Enter for a new line)"], ["ctrl_enter", "Ctrl+Enter (Enter for a new line)"]]))
    call row(g, "Notifications", switch(state, "notify"), "Notify me when LuxAI finishes an answer or needs my approval while the window is in the background.")
    g = group(page, "Start")
    call row(g, "Mode for new conversations", combo(state, "mode", [["chat", "Chat"], ["agent", "Agent"]]), "LuxAI also remembers the mode you used last.")
end

function ai(state, page):
    g = group(page, "Model")
    call row(g, "Default model", combo(state, "model", [["flash", "Flash – smarter"], ["lite", "Lite – faster, larger limit"]]), "Used for new conversations. You can switch it any time in the toolbar.")
    for model in [["flash", "Flash"], ["lite", "Lite"]]:
        call row(g, ui_format.format_text("{0} can see images", model[1]), switch(state, model[0], "vision"), "Attach screenshots in Agent mode. Turn on only if the model supports images.")
    end
    g = group(page, "Answers")
    call row(g, "Response style", combo(state, "style", [["balanced", "Balanced"], ["concise", "Concise"], ["detailed", "Detailed"], ["technical", "Technical"], ["friendly", "Friendly"]]))
    call row(g, "Answer length", combo(state, "answer_length", [["short", "Short"], ["normal", "Normal"], ["long", "Long"]]), "Maximum length of one answer. Agent mode always keeps enough room for its tools.")
    call row(g, "Language", combo(state, "language", [["auto", "Same as my message"]] + ui_data.LANGUAGE_CHOICES))
    control = ui_widgets.box(False, 8)
    scale = gtk.scale_new_with_range(0, 0.0, 1.5, 0.1)
    call gtk.range_set_value(scale, state["data"]["temperature"])
    call gtk.widget_set_size_request(scale, 170, -1)
    call gtk.widget_set_sensitive(scale, state["data"]["temperature_custom"])
    binding = register(state, "temperature", "scale", scale)
    call gtk_ext.connect(scale, "value-changed", scale_changed, binding)
    call ui_widgets.pack(control, scale)
    call ui_widgets.pack(control, switch(state, "temperature_custom"))
    call row(g, "Creativity (temperature)", control, "Off = the model's default. Lower is more precise, higher more creative. Applied only if the model supports it.")
    g = group(page, "Custom instructions", "Added to every conversation. They cannot give the agent more permissions than set in Agent permissions.")
    view = ui_widgets.text_view(state["data"]["instructions"])
    state["instructions"] = view
    call gtk_ext.connect(gtk_ext.text_view_get_buffer(view), "changed", instruction_changed, state)
    scroll = ui_widgets.classes(ui_widgets.scrolled(view), ["instructions"])
    call gtk.widget_set_size_request(scroll, -1, 110)
    call widget_row(g, ui_widgets.label(i18n.translate("What should LuxAI know about you or how should it answer? E.g. \"Call me Tom. Prefer metric units and short answers.\""), None, ["hint"], True))
    call widget_row(g, scroll)
    g = group(page, "Conversations")
    call row(g, "Name conversations automatically", switch(state, "auto_title"), "After the first answer the fast Lite model suggests a short title. You can rename a conversation any time (right-click it in the sidebar).")
end

function root_done(state, result):
    old = state["root_old"]
    value = state["root_requested"]
    if result[0]:
        call set_value(state, "root_mode", value, "agent")
        if not state["alive"]:
            call save(state)
        end
    elif state["alive"]:
        call gtk_ext.combo_box_set_active_id(state["widgets"]["agent_root_mode"]["widget"], old)
        if value != "password":
            problem = String(common.fallback(result[1], ""))
            secondary = ""
            if problem:
                secondary = i18n.translate(problem[:1].upper() + problem[1:])
            end
            call ui_widgets.message_dialog(state["widget"], i18n.translate("Administrator mode was not turned on"), secondary)
        end
    end
    state["root_busy"] = False
    if state["alive"]:
        call gtk.widget_set_sensitive(state["widgets"]["agent_root_mode"]["widget"], True)
    end
end

function root_worker(state, arguments):
    result = rootmode.set_rule(state["root_requested"] != "password")
    call ui_dispatch.post(root_done, state, result)
end

function change_root(state, value):
    old = state["data"]["agent"].get("root_mode", "password")
    if value == old or state["root_busy"]:
        return
    end
    if (old != "password") == (value != "password"):
        call set_value(state, "root_mode", value, "agent")
        return
    end
    state["root_busy"] = True
    state["root_old"] = old
    state["root_requested"] = value
    call gtk.widget_set_sensitive(state["widgets"]["agent_root_mode"]["widget"], False)
    call ui_dispatch.background(root_worker, state)
end

function pick_folder(binding, button):
    state = binding["window"]
    # seznamy slozek: titulek podle seznamu a tlacitko Pridat (jako v Pythonu)
    title = common.fallback(binding.get("title"), "Working folder")
    accept = ""
    if binding["key"] != "workdir":
        accept = i18n.translate("Add")
    end
    chooser = gtk_ext.file_dialog(state["widget"], i18n.translate(title), 2, False, accept, i18n.translate("Cancel"))
    call gtk_ext.file_chooser_set_current_folder(chooser, glib.home_dir())
    response = gtk_ext.dialog_run(chooser)
    path = glib.take_c(gtk_ext.file_chooser_get_filename(chooser))
    call gtk.widget_destroy(chooser)
    if response != -3 or not path:
        return
    end
    if binding["key"] == "workdir":
        call set_value(state, "workdir", path)
        call gtk.button_set_label(button, home_short(path))
    else:
        call add_folder(state, binding["key"], path)
    end
end

function folder_removed(binding, widget):
    state = binding["window"]
    folders = []
    for path in state["data"]["agent"][binding["key"]]:
        if path != binding["path"]:
            folders.append(path)
        end
    end
    call set_value(state, binding["key"], folders, "agent")
    call refill_folders(state, binding["key"])
end

function refill_folders(state, key):
    container = state["folder_lists"][key]
    call gtk_ext.clear(container)
    folders = state["data"]["agent"][key]
    if not folders:
        call ui_widgets.pack(container, ui_widgets.label(i18n.translate("No folders"), None, ["hint"]))
    end
    for path in folders:
        root = ui_widgets.box(False, 6)
        call ui_widgets.pack(root, gtk.image_new_from_icon_name("folder-symbolic", 1))
        label = ui_widgets.label(home_short(path), None, ["folder-path"], False, False, True)
        call gtk_ext.label_set_ellipsize(label, 2)
        call ui_widgets.pack(root, label, True)
        call ui_widgets.pack(root, ui_widgets.icon_button("list-remove-symbolic", "Remove", folder_removed, {"window": state, "key": key, "path": path}))
        call ui_widgets.pack(container, root)
    end
    call gtk.widget_show_all(container)
end

function add_folder(state, key, path):
    path = common.expand(path)
    folders = state["data"]["agent"][key].copy()
    if path not in folders:
        folders.append(path)
    end
    call set_value(state, key, folders, "agent")
    call refill_folders(state, key)
end

PAGE_ICONS = {"general": ["preferences-system-symbolic", "emblem-system-symbolic"], "ai": ["starred-symbolic", "dialog-information-symbolic"], "agent": ["security-high-symbolic", "dialog-password-symbolic"], "privacy": ["preferences-system-privacy-symbolic", "user-trash-symbolic"], "shortcuts": ["preferences-desktop-keyboard-shortcuts-symbolic", "input-keyboard-symbolic"]}

function folder_list(state, group, key, title, hint):
    root = ui_widgets.box(True, 4)
    head = ui_widgets.box(False, 8)
    texts = ui_widgets.box(True, 0)
    call ui_widgets.pack(texts, ui_widgets.label(i18n.translate(title)))
    call ui_widgets.pack(texts, ui_widgets.label(i18n.translate(hint), None, ["hint"], True))
    call ui_widgets.pack(head, texts, True)
    call ui_widgets.pack(head, ui_widgets.button("Add folder…", pick_folder, {"window": state, "key": key, "title": title}))
    call ui_widgets.pack(root, head)
    list = ui_widgets.box(True, 2)
    state["folder_lists"][key] = list
    call ui_widgets.pack(root, list)
    call refill_folders(state, key)
    call widget_row(group, root)
end

function agent(state, page):
    ask = ["ask", "Always ask"]
    allow = ["allow", "Allow without asking"]
    never = ["never", "Never"]
    g = group(page, "What Agent mode may do", "Dangerous actions (deleting your home folder, formatting disks, shutting down …) always need two confirmations, and LuxAI never touches its account and settings files. \"Always ask\" still offers \"Always for this session\" on the approval card.")
    rows = [
        ["commands", "Run commands", [ask, ["risky", "Ask only for risky commands"], never], "With \"risky only\", read-only commands such as ls, df or git status run without asking."],
        ["read_files", "Read files", [["allow", "Allow"], ask, never], "Private files (keys, passwords, .env) always need your confirmation."],
        ["write_files", "Write and delete files", [ask, allow, never], "Creating, editing, moving and deleting files and folders."],
        ["network", "Network access", [ask, allow, never], "Opening web links, downloads and network tools (curl, git clone, package installs). Detected from the command – for strict isolation also set Run commands to Never."],
        ["open_apps", "Open apps and links", [ask, allow, never], ""],
        ["input", "Control mouse and keyboard", [ask, allow, never], "Clicking, typing, pressing keys and closing windows."],
        ["screen", "Screenshots and clipboard", [ask, allow, never], "Sends what is on your screen or in the clipboard to the model."]]
    for item in rows:
        call row(g, item[1], combo(state, item[0], item[2], "agent"), item[3])
    end
    call row(g, "Administrator commands", combo(state, "root_mode", [["password", "Ask for the password every time"], ["nopass", "Without password, approve each command"], ["noask", "Without password and without asking"]], "agent"), "Commands the agent runs as administrator (root). Without password only with the Flash model; Lite always asks for the password. Turning it on asks for the administrator password once. Destructive commands (deleting the system or home folder, formatting disks, removing the bootloader, changing accounts, sudo or polkit) are always refused. Every command is logged in ~/.local/state/luxai/root-commands.log.")
    g = group(page, "Folders", "Shell commands are checked for blocked folders in their paths, but a command cannot be fully confined. Set Run commands to Never for strict folder limits.")
    folder = ui_widgets.button(home_short(common.fallback(state["data"]["workdir"], glib.home_dir())), pick_folder, {"window": state, "key": "workdir"})
    state["folder_button"] = folder
    call row(g, "Working folder", folder, "Relative paths and commands start here.")
    call folder_list(state, g, "allowed_folders", "Allowed folders", "If you add folders here, the agent can work with files only inside them. Empty = anywhere (system files need extra confirmation).")
    call folder_list(state, g, "blocked_folders", "Blocked folders", "The agent never reads or changes anything in these folders.")
    g = group(page, "Commands")
    spin = gtk.spin_button_new_with_range(10.0, 1800.0, 10.0)
    call gtk.spin_button_set_value(spin, state["data"]["timeout"])
    binding = register(state, "timeout", "spin", spin)
    call gtk_ext.connect(spin, "value-changed", spin_changed, binding)
    call row(g, "Command timeout (seconds)", spin, "Long-running commands are stopped after this time.")
end

function privacy_action(binding, button):
    state = binding["window"]
    parent = state["parent"]
    if parent.get(binding["action"]) != None:
        call parent[binding["action"]](parent, state["widget"])
    end
    call update_counts(state)
end

function update_counts(state):
    parent = state["parent"]
    count = 0
    shots = 0
    if parent.get("store_count") != None:
        count = parent["store_count"](parent)
    end
    if parent.get("screenshot_count") != None:
        shots = parent["screenshot_count"](parent)
    end
    call gtk.label_set_text(state["count_label"], ui_format.format_text("{0} conversations saved", count))
    call gtk.label_set_text(state["shot_label"], ui_format.format_text("{0} screenshots", shots))
end

function privacy(state, page):
    g = group(page, "History")
    call row(g, "Keep conversation history", switch(state, "keep_history"), "When off, new conversations are not saved on this computer and disappear when you close them.")
    call row(g, "Saved conversations", ui_widgets.button("Clear all history…", privacy_action, {"window": state, "action": "clear_history"}, ["destructive"]))
    state["count_label"] = ui_widgets.label("", None, ["hint"])
    call widget_row(g, state["count_label"])
    g = group(page, "Screenshots")
    call row(g, "Screenshots taken by the agent", ui_widgets.button("Delete screenshots", privacy_action, {"window": state, "action": "clear_screenshots"}))
    state["shot_label"] = ui_widgets.label("", None, ["hint"])
    call widget_row(g, state["shot_label"])
    g = group(page, "Data on this computer", "Your messages are sent to the LuxAI service (lux-ai.cz) to generate answers and titles. The agent runs tools only on this computer.")
    for item in [["Conversations", common.join(common.environment("XDG_DATA_HOME", common.join(glib.home_dir(), ".local/share")), "luxai/conversations")], ["Settings file", state["parent"]["settings_path"]]]:
        call row(g, item[0], ui_widgets.label(home_short(item[1]), None, ["folder-path"], False, True))
    end
    call update_counts(state)
end

function build_shortcuts(state, page):
    call gtk_ext.clear(page)
    g = group(page, "Conversation")
    send = "Enter"
    newline = "Shift+Enter"
    if state["data"]["send_key"] == "ctrl_enter":
        send = "Ctrl+Enter"
        newline = "Enter"
    end
    for item in [["Send message", send], ["New line", newline], ["Stop the answer or command", "Esc"], ["New conversation", "Ctrl+N"], ["Search conversations", "Ctrl+F"]]:
        call row(g, item[0], ui_widgets.label(item[1], None, ["kbd"]))
    end
    g = group(page, "Application")
    for item in [["Settings", "Ctrl+,"], ["Show or hide the sidebar", "F9"], ["Quit", "Ctrl+Q"]]:
        call row(g, item[0], ui_widgets.label(item[1], None, ["kbd"]))
    end
    call gtk.widget_show_all(page)
end

function sync(state):
    if not state["alive"]:
        return
    end
    state["syncing"] = True
    for binding in state["widgets"].values():
        value = binding_value(binding)
        if binding["kind"] == "combo":
            call gtk_ext.combo_box_set_active_id(binding["widget"], String(value))
        elif binding["kind"] == "switch":
            call gtk.switch_set_active(binding["widget"], Bool(value))
        elif binding["kind"] == "spin":
            call gtk.spin_button_set_value(binding["widget"], value)
        elif binding["kind"] == "scale":
            call gtk.range_set_value(binding["widget"], value)
        end
    end
    call gtk.widget_set_sensitive(state["widgets"]["temperature"]["widget"], state["data"]["temperature_custom"])
    call gtk.button_set_label(state["folder_button"], home_short(common.fallback(state["data"]["workdir"], glib.home_dir())))
    for key in state["folder_lists"].keys():
        call refill_folders(state, key)
    end
    call update_counts(state)
    state["syncing"] = False
end

function new_window(parent, page="general"):
    window = gtk.window_new(i18n.translate("Settings"))
    call gtk.widget_add_class(window, "luxai")
    call gtk.window_set_default_size(window, 860, 620)
    call gtk.window_set_transient_for(window, parent["widget"])
    call gtk.window_set_position(window, 4)
    call gtk.window_set_type_hint(window, 1)
    bar = gtk_ext.header_bar_new()
    call gtk_ext.header_bar_set_title(bar, i18n.translate("Settings"))
    call gtk_ext.header_bar_set_show_close_button(bar, True)
    call gtk_ext.window_set_titlebar(window, bar)
    state = {"widget": window, "parent": parent, "data": parent["settings"], "widgets": {}, "folder_lists": {}, "pages": {}, "alive": True, "syncing": False, "root_busy": False, "save_at": 0.0, "instructions_at": 0.0}
    root = ui_widgets.box(False, 0)
    call gtk.container_add(window, root)
    side = ui_widgets.box(True, 0, ["settings-side"])
    call gtk.widget_set_size_request(side, 210, -1)
    nav = gtk.list_box_new()
    call gtk.list_box_set_selection_mode(nav, 2)
    call gtk_ext.widget_set_margin_top(nav, 10)
    call ui_widgets.pack(side, nav, True)
    call ui_widgets.pack(root, side)
    stack = ui_widgets.classes(gtk_ext.stack_new(), ["settings-page"])
    call gtk_ext.stack_set_transition_type(stack, 1)
    call ui_widgets.pack(root, stack, True)
    state["nav"] = nav
    state["stack"] = stack
    builders = {"general": general, "ai": ai, "agent": agent, "privacy": privacy, "shortcuts": build_shortcuts}
    for item in PAGES:
        entry = ui_widgets.box(False, 10)
        names = PAGE_ICONS[item[0]]
        name = names[1]
        if gtk_ext.icon_theme_has_icon(names[0]):
            name = names[0]
        end
        call ui_widgets.pack(entry, gtk.image_new_from_icon_name(name, 1))
        call ui_widgets.pack(entry, ui_widgets.label(i18n.translate(item[1])))
        call gtk.list_box_insert(nav, entry, -1)
        outer = ui_widgets.box(True, 0)
        call gtk_ext.widget_set_margin_start(outer, 28)
        call gtk_ext.widget_set_margin_end(outer, 28)
        call gtk_ext.widget_set_margin_bottom(outer, 24)
        call ui_widgets.pack(outer, ui_widgets.label(i18n.translate(item[1]), None, ["page-title"]))
        content = ui_widgets.box(True, 0)
        state["pages"][item[0]] = content
        call builders[item[0]](state, content)
        call ui_widgets.pack(outer, content)
        scroll = ui_widgets.scrolled(outer)
        call gtk_ext.stack_add_named(stack, scroll, item[0])
    end
    call gtk_ext.connect(nav, "row-selected", nav_selected, state, 1)
    call gtk_ext.connect(window, "key-press-event", key_pressed, state, 1)
    call gtk_ext.connect(window, "destroy", destroyed, state)
    state["tick"] = ui_dispatch.add_tick(tick, state)
    parent["settings_window"] = state
    call show_page(state, page)
    call gtk.widget_show_all(window)
    return state
end
