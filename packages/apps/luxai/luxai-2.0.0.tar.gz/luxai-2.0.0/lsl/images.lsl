# lsl: internal-abi
# lsl: link libgdk_pixbuf-2.0.so.0 libgobject-2.0.so.0 libglib-2.0.so.0
# Headless GdkPixbuf conversion. Every returned pixbuf owns one reference.
load common
load platform
load transport
load glib
load gtk

function ptr(value):
    return __lsl_unbox_int(value)
end

function clear_error(slot):
    problem = __lsl_qbe_load64(platform.address(slot))
    if problem != 0:
        call __lsl_qbe_call1(__lsl_symbol("g_error_free"), problem)
        call __lsl_qbe_store64(platform.address(slot), 0)
    end
end

function from_bytes(bytes):
    loader = __lsl_qbe_call0(__lsl_symbol("gdk_pixbuf_loader_new"))
    errors = __lsl_byte_zeros(8)
    accepted = __lsl_qbe_call4(__lsl_symbol("gdk_pixbuf_loader_write"), loader, platform.address(bytes), len(bytes), platform.address(errors))
    call clear_error(errors)
    closed = __lsl_qbe_call2(__lsl_symbol("gdk_pixbuf_loader_close"), loader, platform.address(errors))
    call clear_error(errors)
    image = 0
    if accepted != 0 and closed != 0:
        borrowed = __lsl_qbe_call1(__lsl_symbol("gdk_pixbuf_loader_get_pixbuf"), loader)
        if borrowed != 0:
            image = __lsl_qbe_call1(__lsl_symbol("g_object_ref"), borrowed)
        end
    end
    call __lsl_qbe_call1(__lsl_symbol("g_object_unref"), loader)
    return image
end

function scale(image, width, height):
    return __lsl_qbe_call4(__lsl_symbol("gdk_pixbuf_scale_simple"), ptr(image), ptr(width), ptr(height), 2)
end

function from_data_url(url, width, height):
    if type(url) != "String" or "," not in url:
        return 0
    end
    bytes = ByteArray()
    try:
        bytes = common.base64_decode_lenient(String(url)[url.find(",") + 1:])
    else:
        return 0
    end
    image = from_bytes(bytes)
    if image == 0:
        return 0
    end
    w = gtk.pixbuf_get_width(image)
    h = gtk.pixbuf_get_height(image)
    factor = min(1.0, min(Float(width) / w, Float(height) / h))
    small = scale(image, max(1, Int(w * factor)), max(1, Int(h * factor)))
    call glib.object_unref(image)
    return small
end

function jpeg_bytes(image, quality):
    output_slot = __lsl_byte_zeros(8)
    size_slot = __lsl_byte_zeros(8)
    error_slot = __lsl_byte_zeros(8)
    keys = glib.cstr_array(["quality"])
    values = glib.cstr_array([String(quality)])
    format = "jpeg"
    success = __lsl_qbe_call7(__lsl_symbol("gdk_pixbuf_save_to_bufferv"), ptr(image), platform.address(output_slot), platform.address(size_slot), platform.cstr(format), glib.array_data(keys), glib.array_data(values), platform.address(error_slot))
    call clear_error(error_slot)
    output = ByteArray()
    buffer = __lsl_qbe_load64(platform.address(output_slot))
    length = __lsl_qbe_load64(platform.address(size_slot))
    if success != 0 and buffer != 0:
        output = transport.bytes_from_pointer(buffer, length)
    end
    if buffer != 0:
        call __lsl_qbe_call1(__lsl_symbol("g_free"), buffer)
    end
    return output
end

function screenshot_data_url(image):
    # snimek obrazovky pro model jako GuiBridge.screenshot v Pythonu: sirka nejvyse 1280, JPEG 80
    width = gtk.pixbuf_get_width(image)
    height = gtk.pixbuf_get_height(image)
    factor = min(1.0, 1280.0 / max(1, width))
    small = image
    if factor < 1.0:
        small = scale(image, max(1, Int(width * factor)), max(1, Int(height * factor)))
    end
    bytes = jpeg_bytes(small, "80")
    if factor < 1.0:
        call glib.object_unref(small)
    end
    if not bytes:
        return ""
    end
    return "data:image/jpeg;base64," + common.base64_encode(bytes)
end

function encode_image(image):
    if image == 0:
        return ""
    end
    width = gtk.pixbuf_get_width(image)
    height = gtk.pixbuf_get_height(image)
    source = image
    has_alpha = __lsl_qbe_call1(__lsl_symbol("gdk_pixbuf_get_has_alpha"), ptr(image))
    owns_source = False
    if has_alpha != 0:
        source = __lsl_qbe_call5(__lsl_symbol("gdk_pixbuf_new"), 0, 0, 8, ptr(width), ptr(height))
        if source == 0:
            return ""
        end
        owns_source = True
        call __lsl_qbe_call2(__lsl_symbol("gdk_pixbuf_fill"), ptr(source), 4294967295)
        call __lsl_qbe_call12(__lsl_symbol("gdk_pixbuf_composite"), ptr(image), ptr(source), 0, 0, ptr(width), ptr(height), Float(0), Float(0), Float(1), Float(1), 2, 255)
    end
    result = ""
    for configuration in [[1568, "85"], [1280, "80"], [1024, "70"], [800, "60"], [640, "50"]]:
        factor = min(1.0, Float(configuration[0]) / max(1, max(width, height)))
        small = source
        if factor < 1.0:
            small = scale(source, max(1, Int(width * factor)), max(1, Int(height * factor)))
        end
        bytes = jpeg_bytes(small, configuration[1])
        if factor < 1.0:
            call glib.object_unref(small)
        end
        if len(bytes) == 0:
            break
        end
        url = "data:image/jpeg;base64," + common.base64_encode(bytes)
        if len(url) <= 300000:
            result = url
            break
        end
    end
    if owns_source:
        call glib.object_unref(source)
    end
    return result
end
