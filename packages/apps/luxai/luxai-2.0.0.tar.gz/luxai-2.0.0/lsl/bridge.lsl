# lsl: internal-abi
# Differential test entry point. Not part of the application UI.
load common
load protocol
load settings
load store
load i18n
load json
load api
load mathtex
load highlight
load markdown
load titles
load attachments
load docs
load rootmode
load images
load gtk
load glib
load time
load tool_format
load prompts
load catalog
load testing
load feedback
load platform
load rootguard
load safety
load child_process
load tools
load net_address
load urls
load html_content
load web
load shellwords
load maps
load maps_coord

cancel_target = None
process_cancel_target = None

function process_cancel_worker():
    call time.sleep(0.15)
    call child_process.cancel(process_cancel_target)
end

function cancel_worker():
    call time.sleep(0.12)
    call api.abort(cancel_target)
end

function dispatch(request):
    global cancel_target
    global process_cancel_target
    operation = request["operation"]
    data = request.get("data", {})
    if operation == "public_ip":
        return net_address.public_ip(data)
    elif operation == "web_fixture":
        return testing.web_fixture(data)
    elif operation == "parse_ddg":
        return web.parse_ddg(data, request.get("limit", 8))
    elif operation == "same_host_links":
        return web.same_host_links(request["url"], data)
    elif operation == "urls_in_text":
        return web.urls_in_text(data)
    elif operation == "trusted_urls":
        return sorted(web.trusted_urls(data))
    elif operation == "check_url":
        try:
            return {"value": urls.check(data)}
        else:
            return {"error": tools.clean_error(String(last_error()))}
        end
    elif operation == "normalize_url":
        return urls.normalize(data)
    elif operation == "url_join":
        return urls.join(request["base"], data)
    elif operation == "html_text":
        return html_content.to_text(data)
    elif operation == "html_stats":
        started = time.monotonic()
        source = readfile(data)
        parsed = html_content.to_text(source)
        return {"characters": len(parsed["text"]), "duration": time.monotonic() - started}
    elif operation == "html_unescape":
        return html_content.unescape(data)
    elif operation == "web_decode":
        return web.decode(common.base64_decode(data), request.get("charset", ""))
    elif operation == "tool_fixture":
        return testing.tool_fixture(data)
    elif operation == "tool_sequence":
        backend = tools.new_tools(request["cwd"], None, request.get("timeout", 120), False, request.get("env"), request.get("blocked"))
        if request.get("cancelled"):
            call tools.cancel(backend)
        end
        output = []
        for item in data:
            output.append(tools.execute(backend, item["name"], item.get("args", {})))
        end
        return output
    elif operation == "parse_wmctrl":
        return tools.parse_wmctrl(data)
    elif operation == "parse_desktop":
        return tools.parse_desktop(data, request.get("language"))
    elif operation == "child_process_cancel":
        process_cancel_target = child_process.new_signal()
        worker = thread_spawn(process_cancel_worker)
        result = child_process.run(data, request.get("cwd", "/tmp"), request.get("env"), 10, process_cancel_target)
        call thread_join(worker)
        return result
    elif operation == "child_process":
        return child_process.run(data, request.get("cwd", "/tmp"), request.get("env"), request.get("timeout", 5), None, request.get("input"), False, False, False, request.get("merge", True), request.get("limit", 2097152))
    elif operation == "child_process_pre_cancel":
        signal = child_process.new_signal()
        call child_process.cancel(signal)
        return child_process.run(data, request.get("cwd"), None, 5, signal)
    elif operation == "utf8_decode":
        return platform.utf8_decode(common.base64_decode(data))
    elif operation == "safety_assess":
        return safety.assess(request["name"], data, request.get("cwd"), request.get("home"))
    elif operation == "safety_decide":
        permissions = safety.new_permissions(request.get("auto_approve", False), request.get("policy"))
        permissions["model"] = request.get("model", "flash")
        permissions["always"] = request.get("always", [])
        return safety.decide(permissions, request["name"], data, request.get("cwd"), request.get("home"), request.get("tainted", False), request.get("mode", "agent"), request.get("fetch_trusted", True))
    elif operation == "safety_hidden":
        return sorted(safety.hidden_tools(safety.new_permissions(False, data)))
    elif operation == "safety_remember":
        permissions = safety.new_permissions(False, request.get("policy"))
        answers = []
        for item in data:
            if item[0] == "reset":
                call safety.reset(permissions)
                answers.append(None)
            else:
                answers.append(safety.remember(permissions, item[0], item[1]))
            end
        end
        return {"answers": answers, "always": sorted(permissions["always"])}
    elif operation == "web_fetch_real":
        return web.fetch(data)
    elif operation == "safety_path":
        return safety.path_permission(data, request.get("policy", {}), request.get("cwd"), request.get("home"))
    elif operation == "safety_network":
        return safety.command_uses_network(data)
    elif operation == "safety_read_only":
        return safety.is_read_only_command(data)
    elif operation == "rootguard":
        return rootguard.hard_block(data, request.get("root", False), request.get("cwd"), request.get("home"))
    elif operation == "shellwords":
        return shellwords.split(data, request.get("punctuation", ";&|()<>"))
    elif operation == "guard_rule":
        return rootguard.rule_text(data)
    elif operation == "normalize_policy":
        return settings.normalize_policy(data)
    elif operation == "settings":
        return settings.Settings(request["path"]).data
    elif operation == "repair_tool_sequence":
        return protocol.repair_tool_sequence(data, request.get("declared"), request.get("missing"))[0]
    elif operation == "api_messages":
        return protocol.api_messages(data, request.get("mode", "agent"), request.get("vision", True), request.get("declared"))
    elif operation == "trim_history":
        return protocol.trim_history(data, request.get("budget", 160000), request.get("max_messages", 190))
    elif operation == "title_from":
        return store.title_from(data, request.get("limit", 48))
    elif operation == "strip_images":
        return store.strip_images(data)
    elif operation == "message_text":
        return protocol.message_text(data)
    elif operation == "detect_lang":
        return i18n.detect_lang(data)
    elif operation == "load_tsv":
        return i18n.load_tsv(request["path"], data)
    elif operation == "store_roundtrip":
        repository = store.Store(request["path"])
        conversation = store.from_dict(data)
        saved = repository.save(conversation, False)
        loaded = repository.load(conversation["id"])
        return {"saved": saved, "conversation": store.to_dict(loaded), "messages": loaded["messages"], "list": repository.list()}
    elif operation == "store_script":
        repository = store.Store(request["path"])
        output = []
        for step in data:
            action = step[0]
            if action == "save":
                output.append(repository.save(store.from_dict(step[1]), step[2]))
            elif action == "load":
                try:
                    loaded = repository.load(step[1])
                    output.append({"conversation": store.to_dict(loaded), "first_user_text": store.first_user_text(loaded)})
                else:
                    output.append({"error": True})
                end
            elif action == "list":
                rows = []
                for row in repository.list():
                    rows.append([row["id"], row["title"], row["mode"], row["model"]])
                end
                output.append(rows)
            elif action == "delete":
                output.append(repository.delete(step[1]))
            elif action == "clear":
                output.append(repository.clear())
            elif action == "files":
                folder = common.join(request["path"], step[1])
                if exists(folder):
                    output.append(sorted(listdir(folder)))
                else:
                    output.append(None)
                end
            elif action == "write":
                call writefile(common.join(request["path"], step[1]), step[2])
                output.append(None)
            elif action == "sleep":
                call time.sleep(step[1])
                output.append(None)
            end
        end
        return output
    elif operation == "settings_script":
        call __lsl_qbe_call3(__lsl_symbol("g_setenv"), platform.cstr("XDG_CONFIG_HOME"), platform.cstr(request["config_home"]), 1)
        current = settings.Settings(request.get("path"))
        output = []
        for step in data:
            if step[0] == "set":
                current.data[step[1]] = step[2]
            elif step[0] == "save":
                output.append(current.save())
            elif step[0] == "reload":
                current = settings.Settings(request.get("path"))
                output.append(common.copy(current.data))
            elif step[0] == "max_tokens":
                output.append(current.max_tokens())
            elif step[0] == "file":
                output.append(common.read_json(step[1]))
            end
        end
        return output
    elif operation == "store_list":
        return store.Store(request["path"]).list()
    elif operation == "store_delete":
        return store.Store(request["path"]).delete(data)
    elif operation == "store_clear":
        return store.Store(request["path"]).clear()
    elif operation == "base64_roundtrip":
        return common.base64_encode(common.base64_decode(data))
    elif operation == "safe_origin":
        return api.safe_origin(data)
    elif operation == "api_error":
        return api.error_from_response(request["status"], data)
    elif operation == "usage_for":
        return api.usage_for(data, request.get("model", "flash"))
    elif operation == "sse":
        parser = api.new_parser()
        output = []
        for chunk in data:
            output += api.parser_feed(parser, common.base64_decode(chunk))
        end
        output += api.parser_flush(parser)
        return {"data": output, "done": parser["done"]}
    elif operation == "accumulator":
        accumulator = api.new_accumulator()
        deltas = []
        for event in data:
            deltas.append(api.add_event(accumulator, event))
        end
        return {"message": api.accumulator_message(accumulator), "finish": accumulator["finish"], "usage": accumulator["usage"], "deltas": deltas}
    elif operation == "http_chat":
        client = api.new_client({"sessionToken": request.get("token", "good-token")}, request["origin"])
        return api.chat_stream(client, data)
    elif operation == "http_chat_error":
        client = api.new_client({"sessionToken": request.get("token", "good-token")}, request["origin"])
        try:
            result = api.chat_stream(client, data)
            content = String(common.fallback(result[0].get("content"), ""))
            return {"value": {"length": len(content), "finish": result[1]}}
        else:
            return {"error": api.caught_error(String(last_error()))}
        end
    elif operation == "http_me":
        client = api.new_client({"sessionToken": request.get("token", "good-token")}, request["origin"])
        return api.me(client)
    elif operation == "math_markup":
        return mathtex.to_markup(data, request.get("display", False))
    elif operation == "math_text":
        return mathtex.to_text(data, request.get("display", False))
    elif operation == "math_bare":
        return mathtex.bare_markup(data)
    elif operation == "math_hint":
        return mathtex.has_bare_latex(data)
    elif operation == "highlight":
        return highlight.highlight(data, request.get("language", ""), request.get("dark", False))
    elif operation == "markdown_block_markup":
        output = []
        for block in markdown.parse_blocks(data):
            if block["type"] == "heading":
                output.append(["heading", markdown.heading_markup(block, request.get("code_color"), request.get("link_color"))])
            elif block["type"] == "math":
                output.append(["math", markdown.math_markup(block)])
            elif block["type"] == "list":
                prefixes = []
                for index in rang(len(block["items"])):
                    prefixes.append(markdown.list_item_prefix(block["items"][index], index))
                end
                output.append(["list", prefixes])
            end
        end
        return output
    elif operation == "highlight_name":
        return [highlight.canonical(data), highlight.language_name(data)]
    elif operation == "markdown_blocks":
        return markdown.parse_blocks(data)
    elif operation == "markdown_inline":
        return markdown.inline(data, request.get("code_color"), request.get("link_color"))
    elif operation == "markdown_plain":
        return markdown.to_plain(data)
    elif operation == "markdown_table":
        return markdown.table_text(data, request.get("width_limit", 40))
    elif operation == "smalltalk":
        return titles.smalltalk(data)
    elif operation == "clean_title":
        return titles.clean_title(data, request.get("fallback", ""))
    elif operation == "topic":
        return titles.topic(data)
    elif operation == "title_request":
        return titles.title_request(data, request.get("answer", ""))
    elif operation == "generate_title":
        client = api.new_client({"sessionToken": "good-token"}, request["origin"])
        return titles.generate_title(client, data)
    elif operation == "generate_title_result":
        client = api.new_client({"sessionToken": "good-token"}, request["origin"])
        try:
            return {"title": titles.generate_title(client, data, request.get("answer", ""), None, request.get("retries", 1))}
        else:
            return {"error": api.caught_error(String(last_error()))["code"]}
        end
    elif operation == "classify":
        return attachments.classify(data)
    elif operation == "text_attachment":
        return attachments.text_attachment(data)
    elif operation == "text_attachment_checked":
        try:
            call attachments.text_attachment(data)
            return {"error": None}
        else:
            text = String(last_error())
            if text.startswith("AttachmentError: "):
                text = text[17:]
            end
            return {"error": text}
        end
    elif operation == "attachment_limits":
        return attachments.check_limits(data, request.get("kind", "text"))
    elif operation == "user_message":
        return attachments.user_message(request.get("text", ""), data)
    elif operation == "message_parts":
        return attachments.message_parts(data)
    elif operation == "docs_terms":
        return docs.terms(data, request.get("keep_stopwords", False))
    elif operation == "docs_sections":
        return docs.split_sections(data)
    elif operation == "docs_search":
        return docs.library_search(docs.library(request["root"]), data, request.get("collection"), request.get("limit", 5))
    elif operation == "docs_read":
        try:
            return docs.library_read(docs.library(request["root"]), data, request.get("heading"), request.get("limit", 12000))
        else:
            return {"ok": False, "error": docs.clean_error(String(last_error()))}
        end
    elif operation == "docs_module":
        # modulove obalky docs.search/read s LUXAI_DOCS_DIR (chybejici/prazdna dokumentace, cache)
        call __lsl_qbe_call3(__lsl_symbol("g_setenv"), platform.cstr("LUXAI_DOCS_DIR"), platform.cstr(request["root"]), 1)
        output = []
        for item in data:
            if item[0] == "search":
                output.append(docs.search(item[1], item[2], item[3]))
            elif item[0] == "read":
                output.append(docs.read(item[1], item[2]))
            elif item[0] == "write":
                call writefile(item[1], item[2])
                output.append(None)
            elif item[0] == "sleep":
                call time.sleep(item[1])
                output.append(None)
            end
        end
        return output
    elif operation == "root_run":
        # run_command root=true pres falesny pkexec (jen v testech; cesty pomocniku z pozadavku)
        rootmode.paths["helper"] = request["helper"]
        rootmode.paths["auto"] = request["helper_auto"]
        call __lsl_qbe_call3(__lsl_symbol("g_setenv"), platform.cstr("PATH"), platform.cstr(request["path"]), 1)
        call __lsl_qbe_call3(__lsl_symbol("g_setenv"), platform.cstr("XDG_STATE_HOME"), platform.cstr(request["state"]), 1)
        backend = tools.new_tools(request["cwd"], None, 120, False, request.get("env"))
        output = []
        for item in data:
            backend["root_mode"] = item[0]
            backend["model"] = "flash"
            output.append(tools.execute(backend, "run_command", item[1]))
        end
        return output
    elif operation == "guard_rule_checked":
        try:
            return {"value": rootguard.rule_text(data)}
        else:
            return {"error": True}
        end
    elif operation == "map_command":
        try:
            return {"value": maps.command(request["name"], data)}
        else:
            text = String(last_error())
            if text.startswith("ValueError: "):
                text = text[12:]
            end
            return {"error": text}
        end
    elif operation == "map_summary":
        return [maps.summary(request["name"], data), maps.error_text(data)]
    elif operation == "map_coord":
        return maps_coord.coord(data)
    elif operation == "screenshot_encode":
        image = gtk.pixbuf_new_from_file(data)
        url = images.screenshot_data_url(image)
        call glib.object_unref(image)
        return {"length": len(url), "head": url[:40]}
    elif operation == "shrink_body":
        result = protocol.shrink_body(data, request.get("limit", protocol.MAX_BODY_BYTES), request.get("everything", False))
        return {"body": result, "size": protocol.body_size(result)}
    elif operation == "root_normalize":
        return rootmode.normalize_run_command(data)
    elif operation == "root_effective_mode":
        return rootmode.effective_mode(data, request.get("model", "flash"))
    elif operation == "root_helper_argv":
        return rootmode.helper_argv(request["mode"], data, request.get("workdir"), request.get("timeout", 120))
    elif operation == "root_exit_message":
        return rootmode.exit_message(data)
    elif operation == "image_encode":
        image = gtk.pixbuf_new_from_file(data)
        encoded = images.encode_image(image)
        call glib.object_unref(image)
        return encoded
    elif operation == "image_preview":
        image = images.from_data_url(data, request.get("width", 220), request.get("height", 160))
        if image == 0:
            return None
        end
        dimensions = [gtk.pixbuf_get_width(image), gtk.pixbuf_get_height(image)]
        call glib.object_unref(image)
        return dimensions
    elif operation == "http_cancel":
        client = api.new_client({"sessionToken": "good-token"}, request["origin"])
        cancel_target = client
        worker = thread_spawn(cancel_worker)
        started = time.perf_counter()
        result = api.chat_stream(client, data)
        call thread_join(worker)
        return {"result": result, "duration": time.perf_counter() - started}
    elif operation == "store_large_roundtrip":
        repository = store.Store(request["path"])
        conversation = repository.load(data)
        count = len(conversation["messages"])
        call repository.save(conversation, False)
        return {"messages": count, "first": conversation["messages"][0]["content"][:12]}
    elif operation == "tool_subject":
        return tool_format.subject(request["name"], data)
    elif operation == "tool_result":
        return tool_format.encode_result(data, request.get("limit", 30000))
    elif operation == "preferences_prompt":
        return prompts.preferences_prompt(data)
    elif operation == "announces_action":
        return prompts.announces_action(data)
    elif operation == "printed_tool_call":
        return prompts.printed_tool_call(data, catalog.TOOL_DEFS)
    elif operation == "system_prompt":
        return prompts.system_prompt(request.get("mode", "agent"), request.get("workdir", "/tmp"), request.get("vision", True), request.get("screen", ""), data, request.get("policy"), request.get("model", "flash"), request.get("docs", False), request.get("web", False), request.get("tainted", False), request.get("maps", False))
    elif operation == "agent_fixture":
        return testing.run_fixture(data)
    elif operation == "feedback_redact":
        return feedback.redact(data, request.get("home"), request.get("user"), request.get("host"))
    elif operation == "feedback_logs":
        return feedback.log_lines(data, request.get("n", 50), request.get("home"), request.get("user"), request.get("host"))
    elif operation == "feedback_build":
        return feedback.build_payload(data.get("kind"), data.get("title"), data.get("description"), data.get("contact"), data.get("system"), data.get("screenshot"))
    elif operation == "feedback_shrink":
        return feedback.shrink_system(data, request.get("limit", 30000))
    elif operation == "feedback_describe":
        return feedback.describe(data)
    elif operation == "feedback_send":
        return feedback.send(data, request.get("token"), request["origin"])
    elif operation == "feedback_outbox":
        path = feedback.save_outbox(data)
        return {"payload": common.read_json(path), "mode": platform.file_info(path)["mode"] & 511, "directory_mode": platform.file_info(common.dirname(path))["mode"] & 511}
    elif operation == "feedback_build_checked":
        try:
            return {"value": feedback.build_payload(data.get("kind"), data.get("title"), data.get("description"), data.get("contact"), data.get("system"), data.get("screenshot"))}
        else:
            return {"error": tools.clean_error(String(last_error()))}
        end
    elif operation == "feedback_errors":
        output = []
        for problem in data:
            output.append([feedback.human_error(problem), feedback.can_save(problem)])
        end
        return output
    elif operation == "feedback_collect_fixture":
        return testing.feedback_fixture(data)
    end
    Error(ValueError: "Unknown differential operation")
end

requests = json.decode(readfile(arg(1)))
results = []
for request in requests:
    try:
        results.append({"ok": True, "value": dispatch(request)})
    else:
        results.append({"ok": False, "error": String(last_error())})
    end
end
print json.encode(results)
