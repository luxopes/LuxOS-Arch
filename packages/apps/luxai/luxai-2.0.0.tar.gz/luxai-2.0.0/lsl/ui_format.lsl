load common
load platform
load json
load i18n
load web_data

function fmt_int(number):
    text = String(Int(number))
    output = []
    length = len(text)
    for index in rang(length):
        output.append(text[index])
        if (length - index - 1) % 3 == 0 and index < length - 1 and text[index] != "-":
            output.append(" ")
        end
    end
    return "".join(output)
end

function format_text(template, value):
    return i18n.translate(template).replace("{0}", String(value))
end

function pretty(value, indent=2):
    text = String(json.encode(value))
    output = []
    depth = 0
    quoted = False
    escaped = False
    previous = ""
    for char in text:
        if not quoted and previous in "[{" and previous != "" and char not in "]}":
            output.append("\n" + " " * (depth * indent))
        end
        if quoted:
            output.append(char)
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == "\"":
                quoted = False
            end
        elif char == "\"":
            quoted = True
            output.append(char)
        elif char in "[{":
            output.append(char)
            depth += 1
        elif char in "]}":
            depth -= 1
            if previous not in "[{":
                output.append("\n" + " " * (depth * indent))
            end
            output.append(char)
        else:
            output.append(char)
            if char == ",":
                output.append("\n" + " " * (depth * indent))
            elif char == ":":
                output.append(" ")
            end
        end
        previous = char
    end
    return "".join(output)
end

function result_summary(name, result):
    if name == "screenshot":
        return String(result.get("width")) + " × " + String(result.get("height")) + " px · " + result.get("path", "") + "\n" + format_text("{0} open windows", len(common.fallback(result.get("windows"), [])))
    elif name == "list_windows":
        lines = []
        for window in common.fallback(result.get("windows"), []):
            prefix = "  "
            if window.get("active"):
                prefix = "● "
            end
            lines.append(prefix + String(window.get("id")) + "  " + window.get("title", ""))
        end
        return common.fallback("\n".join(lines), i18n.translate("No windows"))
    elif name == "list_directory":
        lines = [String(result.get("path")) + "  (" + String(result.get("count")) + ")"]
        for entry in common.fallback(result.get("entries"), []):
            suffix = ""
            if entry.get("type") == "dir":
                suffix = "/"
            end
            lines.append(entry["name"] + suffix)
        end
        return "\n".join(lines)
    elif name == "find_files":
        return common.fallback("\n".join(common.fallback(result.get("files"), [])), i18n.translate("Nothing found"))
    elif name == "search_text":
        return common.fallback(result.get("matches"), i18n.translate("Nothing found"))
    elif name == "list_apps":
        lines = []
        for app in common.fallback(result.get("apps"), []):
            lines.append(app["name"] + "  (" + app["id"] + ")")
        end
        return "\n".join(lines)
    elif name == "clipboard_read":
        return common.fallback(result.get("text"), i18n.translate("(empty)"))
    elif name in ["write_file", "edit_file", "delete_file", "make_directory", "move_file"]:
        parts = []
        for key in ["path", "from", "to"]:
            if result.get(key):
                parts.append(String(result[key]))
            end
        end
        return " ".join(parts)
    elif name in ["open_url", "open_app"]:
        return String(common.fallback(result.get("opened"), common.fallback(result.get("name"), common.fallback(result.get("launched"), ""))))
    elif name == "send_feedback":
        return format_text("Report sent. Report ID: {0}", common.fallback(result.get("id"), "–"))
    elif name == "web_search":
        if result.get("_results") == None:
            if not result.get("count"):
                return i18n.translate("Nothing found")
            end
            text = String(common.fallback(result.get("content"), "")).replace(web_data.UNTRUSTED_BEGIN, "").replace(web_data.UNTRUSTED_END, "")
            return platform.strip(text, common.WHITESPACE)
        end
        lines = []
        index = 1
        for item in result["_results"]:
            lines.append(String(index) + ". " + item.get("title", "") + "\n   " + item.get("url", ""))
            index += 1
        end
        return common.fallback("\n".join(lines), i18n.translate("Nothing found"))
    elif name == "web_fetch":
        lines = []
        for value in [result.get("title"), result.get("url"), format_text("{0} characters of text", fmt_int(common.fallback(result.get("characters"), 0)))]:
            if value:
                lines.append(value)
            end
        end
        return "\n".join(lines)
    end
    return ""
end
