# Shared helper logic. These programs are built separately and are not installed
# or invoked through sudo/pkexec by migration tests.
load platform
load common
load glib
load rootguard
load guard_data
load child_process

function command_args():
    values = []
    for index in rang(1, arg_count()):
        values.append(arg(index))
    end
    return values
end

function die(message, code, setup=False):
    prefix = "luxai-root: "
    if setup:
        prefix = "luxai-root-setup: "
    end
    call platform.stderr(prefix + message + "\n")
    exit(code)
end

function caller(setup=False):
    uid = glib.getenv("PKEXEC_UID")
    if uid == None or not platform.regex_test("^\\d+$", uid):
        if platform.geteuid() == 0:
            call die("must be started through pkexec", 126, setup)
        end
        uid = String(platform.getuid())
    end
    info = platform.user_info(Int(uid))
    if info == None:
        call die("unknown calling user", 126, setup)
    end
    if setup and platform.geteuid() == 0 and info["uid"] < 1000:
        call die("administrator mode is only for normal user accounts", 126, setup)
    end
    return info
end

function parse(argv):
    timeout = 120
    workdir = "/"
    command = None
    i = 0
    while i < len(argv):
        token = argv[i]
        if token == "--":
            command = " ".join(argv[i + 1:])
            break
        end
        if token == "--timeout" and i + 1 < len(argv):
            try:
                timeout = Int(argv[i + 1])
            else:
                call die("invalid --timeout", 2)
            end
            i += 2
            continue
        end
        if token == "--cwd" and i + 1 < len(argv):
            workdir = argv[i + 1]
            i += 2
            continue
        end
        call die("usage: luxai-root [--timeout S] [--cwd DIR] -- COMMAND", 2)
    end
    if not command or not command.strip(common.WHITESPACE):
        call die("empty command", 2)
    end
    if len(command) > guard_data.MAX_COMMAND:
        call die("command too long", 2)
    end
    return {"timeout": max(1, min(timeout, guard_data.MAX_TIMEOUT)), "cwd": workdir, "command": command}
end

function command_main(argv):
    options = parse(argv)
    user = caller()
    workdir = options["cwd"]
    info = platform.file_info(workdir)
    if info == None or not info["directory"]:
        workdir = "/"
    end
    command = options["command"]
    reason = rootguard.hard_block(command, True, workdir, user["home"])
    if reason or rootguard.feeds_password(command):
        call die("refused by LuxAI safety rules: " + common.fallback(reason, guard_data.R_PASSWORD), guard_data.EXIT_REFUSED)
    end
    if platform.geteuid() == 0:
        call platform.audit_root(user["name"], rootguard.base(arg(0)), workdir, common.words(command)[:2000])
    end
    env = {"PATH": guard_data.ROOT_PATH, "HOME": "/root", "USER": "root", "LOGNAME": "root", "TERM": "dumb", "LANG": common.environment("LANG", "C.UTF-8"), "LUXAI_AGENT": "1", "PAGER": "cat", "SYSTEMD_PAGER": "", "DEBIAN_FRONTEND": "noninteractive", "SUDO_USER": user["name"]}
    result = child_process.run(["/bin/bash", "-c", command], workdir, env, options["timeout"], None, None, False, True, True)
    if result["timed_out"]:
        call die("timed out after " + String(options["timeout"]) + " s", guard_data.EXIT_TIMEOUT)
    end
    if result["cancelled"]:
        call die("stopped by the user", guard_data.EXIT_CANCELLED)
    end
    code = result["exit_code"]
    if code == None:
        call die("cannot determine command exit status", guard_data.EXIT_REFUSED)
    end
    if code < 0:
        return 128 - code
    end
    return code
end

function setup_main(argv):
    if len(argv) != 1 or argv[0] not in ["enable", "disable", "status"]:
        call die("usage: luxai-root-setup enable|disable|status", 2, True)
    end
    user = caller(True)
    if not rootguard.valid_user(user["name"]):
        call die("unsupported user name", 126, True)
    end
    path = rootguard.rule_path(user["name"])
    if platform.geteuid() != 0:
        rules = glib.getenv("LUXAI_RULES_DIR")
        if rules:
            path = common.join(rules, rootguard.base(path))
        end
    end
    if argv[0] == "status":
        if exists(path):
            print "on"
        else:
            print "off"
        end
        return 0
    end
    if argv[0] == "disable":
        call platform.unlink(path)
        return 0
    end
    call platform.atomic_write(path, rootguard.rule_text(user["name"]), 420)
    return 0
end
