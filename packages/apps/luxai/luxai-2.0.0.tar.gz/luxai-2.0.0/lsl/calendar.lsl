# LuxAI calendar tools on the LuxOS Calendar's own store ($XDG_DATA_HOME/luxos/calendar/events.ics;
# other *.ics files in that folder are read-only subscribed calendars, like in the Calendar app).
#
# Writes follow the protocol of the LuxOS Companion bridge (luxos_companion/calendar_note.py), so the
# Calendar app, the phone bridge and LuxAI never lose each other's events:
#   - exclusive flock on .events.ics.lock (shared with the bridge),
#   - read the file again under the lock and change only the affected VEVENT text: everything else
#     (other events, VTODO, VTIMEZONE, unknown components and properties) stays byte for byte,
#   - temporary file + fsync, check that the file did not change meanwhile (the Calendar app writes
#     without the lock; if it did, read again and redo the change), atomic rename, fsync the folder.
# The Calendar app notices the change (inotify) and takes over new events before its own next save.
load common
load platform
load i18n
load calendar_time
load calendar_clock
load calendar_ics
load calendar_data

OWN = "events.ics"
LOCK = ".events.ics.lock"
MAX_FILE = 16777216
MAX_RANGE_DAYS = 400
MAX_LIST = 100
MAX_TITLE = 200
MAX_LOCATION = 500
MAX_DESCRIPTION = 8000
MAX_LIST_DESCRIPTION = 300
MAX_TIMED_MINUTES = 44640
MAX_ALL_DAY_DAYS = 366
MAX_REMINDER = 40320
DEFAULT_MINUTES = 60
RETRIES = 5
DAY = 86400
WEEKDAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

function fail(message):
    Error(ToolError: message)
end

function clean_error(text):
    for prefix in ["ToolError: ", "FileError: ", "ValueError: ", "TypeError: ", "KeyError: "]:
        if text.startswith(prefix):
            return text[len(prefix):]
        end
    end
    return text
end

function folder(state):
    env = common.fallback(state.get("env"), {})
    base = common.fallback(env.get("XDG_DATA_HOME"), "")
    if not base.startswith("/"):
        base = common.join(common.fallback(state.get("home"), common.environment("HOME", "/")), ".local/share")
    end
    return common.join(base, "luxos/calendar")
end

# ---- input -------------------------------------------------------------------------------------

function two(text, index):
    part = text[index:index + 2]
    if len(part) != 2 or not calendar_ics.digits(part):
        return None
    end
    return Int(part)
end

# 'YYYY-MM-DD' -> {"kind": "D", "day"}; date-time -> {"kind": "T", "moment" (naive local)}
function parse_when(value, key):
    if type(value) != "String":
        call fail(key + " must be a string like 2026-10-27 or 2026-10-27T14:30")
    end
    text = value.strip()
    bad = key + " is not a valid date or date-time: '" + text[:40] + "' (expected YYYY-MM-DD or YYYY-MM-DDTHH:MM, optionally with an offset like +01:00)"
    if len(text) < 10 or not calendar_ics.digits(text[0:4]) or text[4] != "-" or text[7] != "-":
        call fail(bad)
    end
    year = Int(text[0:4])
    month = two(text, 5)
    day = two(text, 8)
    if month == None or day == None or month < 1 or month > 12 or day < 1 or day > calendar_ics.days_in_month(year, month):
        call fail(bad)
    end
    if year < 1900 or year > 2200:
        call fail(key + " must be between the years 1900 and 2200")
    end
    ordinal = calendar_ics.ordinal(year, month, day)
    if len(text) == 10:
        return {"kind": "D", "day": ordinal}
    end
    if text[10] not in ["T", "t", " "] or len(text) < 16 or text[13] != ":":
        call fail(bad)
    end
    hour = two(text, 11)
    minute = two(text, 14)
    if hour == None or minute == None or hour > 23 or minute > 59:
        call fail(bad)
    end
    second = 0
    rest = text[16:]
    if rest.startswith(":"):
        second = two(rest, 1)
        if second == None or second > 60:
            call fail(bad)
        end
        second = min(second, 59)
        rest = rest[3:]
        if rest.startswith(".") or rest.startswith(","):
            index = 1
            while index < len(rest) and calendar_ics.digits(rest[index]):
                index += 1
            end
            if index == 1:
                call fail(bad)
            end
            rest = rest[index:]
        end
    end
    rest = rest.strip()
    moment = calendar_ics.make(ordinal, hour, minute, second)
    if rest == "":
        if not calendar_clock.exists_locally(moment):
            zone = common.fallback(calendar_clock.local_tz_name(), "local")
            call fail(key + " " + text + " does not exist in the local time zone (" + zone + ") because the clocks change (daylight saving time). Choose another time.")
        end
        return {"kind": "T", "moment": moment}
    end
    offset = 0
    if rest not in ["Z", "z"]:
        sign = 0
        if rest[0] == "+":
            sign = 1
        elif rest[0] == "-" or rest[0] == "−":
            sign = -1
        end
        digits = rest[1:].replace(":", "")
        if sign == 0 or not calendar_ics.digits(digits) or len(digits) not in [2, 4]:
            call fail(bad)
        end
        hours = Int(digits[0:2])
        minutes = 0
        if len(digits) == 4:
            minutes = Int(digits[2:4])
        end
        if hours > 18 or minutes > 59:
            call fail(bad)
        end
        offset = sign * (hours * 3600 + minutes * 60)
    end
    unix = moment - calendar_clock.EPOCH * DAY - offset
    return {"kind": "T", "moment": calendar_clock.from_unix(unix), "unix": unix}
end

function flag(value, key, default):
    if value == None:
        return default
    end
    if type(value) == "Bool":
        return value
    end
    if type(value) == "String" and value.strip().lower() in ["true", "false"]:
        return value.strip().lower() == "true"
    end
    call fail(key + " must be true or false")
end

function integer(value, key, low, high):
    if value == None:
        return None
    end
    number = None
    if type(value) == "Int":
        number = value
    elif type(value) == "Float" and value == Float(Int(value)):
        number = Int(value)
    elif type(value) == "String" and calendar_ics.to_int(value, None) != None:
        number = calendar_ics.to_int(value, None)
    end
    if number == None or number < low or number > high:
        call fail(key + " must be a whole number from " + String(low) + " to " + String(high))
    end
    return number
end

# Text for SUMMARY/LOCATION (one line) or DESCRIPTION (keeps line breaks); control characters dropped.
function clean_text(value, key, limit, multiline=False):
    if value == None:
        return None
    end
    if type(value) != "String":
        call fail(key + " must be a string")
    end
    text = value.replace("\r\n", "\n").replace("\r", "\n")
    out = []
    for char in text:
        code = ord(char)
        if char == "\n":
            if multiline:
                out.append("\n")
            else:
                out.append(" ")
            end
        elif char == "\t":
            out.append(" ")
        elif code < 32 or (code >= 127 and code < 160) or code == 8232 or code == 8233:
            continue
        else:
            out.append(char)
        end
    end
    text = "".join(out).strip()
    if len(text) > limit:
        call fail(key + " is too long (at most " + String(limit) + " characters)")
    end
    return text
end

function unix_of(moment):
    return calendar_clock.unix_of(moment)
end

# Start/end of an event from the arguments. keep = existing event (update) or None (create).
function apply_timing(event, arguments, keep):
    has_start = arguments.get("start") != None
    has_end = arguments.get("end") != None
    has_duration = arguments.get("duration_min") != None
    if has_end and has_duration:
        call fail("Give either end or duration_min, not both")
    end
    duration = integer(arguments.get("duration_min"), "duration_min", 1, MAX_TIMED_MINUTES)
    start = None
    if has_start:
        start = parse_when(arguments["start"], "start")
    end
    default_all_day = False
    if start != None:
        default_all_day = start["kind"] == "D"
    elif keep != None:
        default_all_day = keep["all_day"]
    end
    all_day = flag(arguments.get("all_day"), "all_day", default_all_day)
    if start == None and keep != None:
        if keep["all_day"]:
            start = {"kind": "D", "day": keep["start"]}
        else:
            start = {"kind": "T", "moment": keep["start"]}
        end
    end
    finish = None
    if has_end:
        finish = parse_when(arguments["end"], "end")
    end
    switched = keep != None and keep["all_day"] != all_day
    if all_day:
        first = start.get("day")
        if start["kind"] == "T":
            first = calendar_ics.date_of(start["moment"])
        end
        last = first
        if finish != None:
            last = finish.get("day")
            if finish["kind"] == "T":
                last = calendar_ics.date_of(finish["moment"])
            end
            if last < first:
                call fail("end must not be before start")
            end
        elif duration != None:
            last = first + max(1, (duration + 1439) // 1440) - 1
        elif keep != None and not switched:
            last = first + max(1, calendar_ics.duration(keep)) - 1
        end
        if last - first + 1 > MAX_ALL_DAY_DAYS:
            call fail("An all-day event can last at most " + String(MAX_ALL_DAY_DAYS) + " days")
        end
        event["all_day"] = True
        event["start"] = first
        event["end"] = last + 1
        return
    end
    if start["kind"] == "D":
        call fail("start needs a time (YYYY-MM-DDTHH:MM) for an event that is not all-day")
    end
    begin = start["moment"]
    begin_unix = common.fallback(start.get("unix"), unix_of(begin))
    finish_unix = 0
    if finish != None:
        if finish["kind"] == "D":
            call fail("end needs a time (YYYY-MM-DDTHH:MM) for an event that is not all-day")
        end
        finish_unix = common.fallback(finish.get("unix"), unix_of(finish["moment"]))
    else:
        minutes = duration
        if minutes == None and keep != None and not switched:
            seconds = calendar_ics.duration(keep)
            finish_unix = begin_unix + (unix_of(keep["start"] + seconds) - unix_of(keep["start"]))
        else:
            if minutes == None:
                minutes = DEFAULT_MINUTES
            end
            # real minutes, also across a daylight saving change
            finish_unix = begin_unix + minutes * 60
        end
    end
    finish_moment = calendar_clock.from_unix(finish_unix)
    length = finish_unix - begin_unix
    if length <= 0 and not (finish == None and keep != None and calendar_ics.duration(keep) == 0):
        call fail("end must be after start")
    end
    if length > MAX_TIMED_MINUTES * 60:
        call fail("An event with a time can last at most 31 days; use an all-day event")
    end
    event["all_day"] = False
    event["start"] = begin
    event["end"] = finish_moment
end

function build_new(arguments):
    title = clean_text(arguments.get("title"), "title", MAX_TITLE)
    if not title:
        call fail("title must not be empty")
    end
    if arguments.get("start") == None:
        call fail("start is required")
    end
    event = calendar_ics.event_new(title, False, None, None)
    call apply_timing(event, arguments, None)
    event["location"] = common.fallback(clean_text(arguments.get("location"), "location", MAX_LOCATION), "")
    event["description"] = common.fallback(clean_text(arguments.get("description"), "description", MAX_DESCRIPTION, True), "")
    call calendar_ics.set_reminder(event, integer(arguments.get("reminder_min"), "reminder_min", 0, MAX_REMINDER))
    return event
end

UPDATE_FIELDS = ["title", "start", "end", "duration_min", "all_day", "location", "description", "reminder_min"]

function apply_update(event, arguments):
    changed = []
    for key in UPDATE_FIELDS:
        if arguments.get(key) != None:
            changed.append(key)
        end
    end
    if not changed:
        call fail("Nothing to change: give at least one of " + ", ".join(UPDATE_FIELDS))
    end
    updated = common.copy(event)
    if arguments.get("title") != None:
        title = clean_text(arguments["title"], "title", MAX_TITLE)
        if not title:
            call fail("title must not be empty")
        end
        updated["summary"] = title
    end
    if arguments.get("start") != None or arguments.get("end") != None or arguments.get("duration_min") != None or arguments.get("all_day") != None:
        call apply_timing(updated, arguments, event)
    end
    if arguments.get("location") != None:
        updated["location"] = clean_text(arguments["location"], "location", MAX_LOCATION)
    end
    if arguments.get("description") != None:
        updated["description"] = clean_text(arguments["description"], "description", MAX_DESCRIPTION, True)
    end
    if arguments.get("reminder_min") != None:
        minutes = integer(arguments["reminder_min"], "reminder_min", -1, MAX_REMINDER)
        if minutes < 0:
            minutes = None
        end
        call calendar_ics.set_reminder(updated, minutes)
    end
    return updated
end

function check_uid(arguments):
    uid = arguments.get("uid")
    if type(uid) != "String" or not uid.strip():
        call fail("uid is required (take it from calendar_list_events)")
    end
    uid = uid.strip()
    if len(uid) > 1000 or "\n" in uid or "\r" in uid:
        call fail("uid is not valid")
    end
    return uid
end

function check_arguments(name, arguments):
    allowed = {"calendar_list_events": ["from", "to", "query"], "calendar_create_event": ["title", "start", "end", "duration_min", "all_day", "location", "description", "reminder_min"], "calendar_update_event": ["uid"] + UPDATE_FIELDS, "calendar_delete_event": ["uid"]}[name]
    for key in arguments.keys():
        if key not in allowed:
            call fail("Invalid arguments: unexpected argument: " + key)
        end
    end
end

# ---- reading -----------------------------------------------------------------------------------

function read_text(path, strict=False):
    info = calendar_time.stat_key(path)
    if not info["exists"]:
        return None
    end
    if not info["file"]:
        call fail(path + " is not a file")
    end
    if info["size"] > MAX_FILE:
        call fail("The calendar file is too large (" + String(info["size"]) + " bytes)")
    end
    raw = platform.read_prefix(path, min(info["size"] + 65536, MAX_FILE + 1))
    if strict and not platform.valid_utf8(raw):
        call fail("The calendar file is not valid UTF-8; LuxAI does not change it. Open it in the Calendar app.")
    end
    return platform.utf8_decode(raw)
end

# [{"name", "own", "events"}] for events.ics and the read-only calendars next to it
function load_calendars(state):
    directory = folder(state)
    names = []
    try:
        names = sorted(listdir(directory))
    else:
        return []
    end
    output = []
    for name in names:
        if not name.lower().endswith(".ics") or name.startswith("."):
            continue
        end
        text = None
        try:
            text = read_text(common.join(directory, name))
        else:
            continue
        end
        if text == None:
            continue
        end
        cal = calendar_ics.parse(text)
        own = name == OWN
        for event in cal["events"]:
            event["source"] = name
            event["readonly"] = not own
        end
        output.append({"name": name, "own": own, "events": cal["events"]})
    end
    return output
end

function calendar_name(source):
    if source == None or source == OWN:
        return "LuxOS"
    end
    if source.lower().endswith(".ics"):
        return source[:len(source) - 4]
    end
    return source
end

function iso_moment(moment):
    unix = unix_of(moment)
    offset = calendar_clock.offset_of(unix)
    local = unix + offset + calendar_clock.EPOCH * DAY
    seconds = local % DAY
    text = calendar_ics.iso_date(calendar_ics.date_of(local)) + "T" + calendar_ics.pad(seconds // 3600, 2) + ":" + calendar_ics.pad(seconds % 3600 // 60, 2)
    if seconds % 60:
        text += ":" + calendar_ics.pad(seconds % 60, 2)
    end
    sign = "+"
    if offset < 0:
        sign = "-"
        offset = -offset
    end
    return text + sign + calendar_ics.pad(offset // 3600, 2) + ":" + calendar_ics.pad(offset % 3600 // 60, 2)
end

# Event (or one occurrence of it) as returned to the model and shown in the cards
function public_event(event, start=None, finish=None, description_limit=300):
    if start == None:
        start = event["start"]
        finish = event["start"] + calendar_ics.duration(event)
    end
    output = {"uid": event["uid"], "title": event["summary"], "all_day": event["all_day"]}
    if event["all_day"]:
        output["start"] = calendar_ics.iso_date(start)
        output["end"] = calendar_ics.iso_date(max(start, finish - 1))
    else:
        output["start"] = iso_moment(start)
        output["end"] = iso_moment(finish)
    end
    if event["location"]:
        output["location"] = event["location"]
    end
    if event["description"]:
        text = event["description"]
        if description_limit != None and len(text) > description_limit:
            text = text[:description_limit] + "…"
        end
        output["description"] = text
    end
    output["calendar"] = calendar_name(event.get("source"))
    output["editable"] = not event.get("readonly", False)
    if event["rrule"] != None or event["recurrence_id"] != None:
        output["recurring"] = True
    end
    reminder = calendar_ics.reminder_minutes(event)
    if reminder != None:
        output["reminder_min"] = reminder
    end
    return output
end

function range_bound(value, key, is_end):
    when = parse_when(value, key)
    if when["kind"] == "D":
        day = when["day"]
        if is_end:
            day += 1
        end
        return day * DAY
    end
    return when["moment"]
end

function matches(event, query):
    if not query:
        return True
    end
    for value in [event["summary"], event["location"], event["description"]]:
        if query in platform.casefold(common.fallback(value, "")):
            return True
        end
    end
    return False
end

function list_events(state, arguments):
    call check_arguments("calendar_list_events", arguments)
    begin = range_bound(arguments.get("from"), "from", False)
    finish = range_bound(arguments.get("to"), "to", True)
    if finish <= begin:
        call fail("to must be after from")
    end
    if finish - begin > MAX_RANGE_DAYS * DAY:
        call fail("The range is too long (at most " + String(MAX_RANGE_DAYS) + " days); ask for a shorter period")
    end
    query = ""
    if arguments.get("query") != None:
        query = platform.casefold(common.fallback(clean_text(arguments["query"], "query", 200), ""))
    end
    first_day = calendar_ics.date_of(begin)
    last_day = calendar_ics.date_of(finish - 1) + 1
    begin_unix = unix_of(begin)
    finish_unix = unix_of(finish)
    rows = {}
    keys = []
    for cal in load_calendars(state):
        overrides = {}
        for event in cal["events"]:
            if event["recurrence_id"] != None:
                if event["uid"] not in overrides:
                    overrides[event["uid"]] = []
                end
                overrides[event["uid"]].append(event["recurrence_id"])
            end
        end
        for event in cal["events"]:
            if not matches(event, query):
                continue
            end
            skip = []
            if event["recurrence_id"] == None and event["rrule"] != None:
                skip = overrides.get(event["uid"], [])
            end
            kind = calendar_ics.kind_of(event)
            for item in calendar_ics.occurrences(event, first_day - 1, last_day + 1):
                skipped = False
                for rid in skip:
                    if rid[0] == kind and rid[1] == item[0]:
                        skipped = True
                    end
                end
                if skipped:
                    continue
                end
                if event["all_day"]:
                    starts = unix_of(item[0] * DAY)
                    ends = unix_of(max(item[1], item[0] + 1) * DAY)
                    sort_moment = item[0] * DAY
                    flag_text = "0"
                else:
                    starts = unix_of(item[0])
                    ends = unix_of(item[1])
                    sort_moment = item[0]
                    flag_text = "1"
                end
                inside = starts < finish_unix and (ends > begin_unix or (starts >= begin_unix and ends == starts))
                if not inside:
                    continue
                end
                key = calendar_ics.pad(sort_moment, 16) + flag_text + platform.casefold(event["summary"]) + "\0" + String(len(keys))
                keys.append(key)
                rows[key] = public_event(event, item[0], item[1])
            end
        end
    end
    events = []
    for key in sorted(keys):
        events.append(rows[key])
        if len(events) >= MAX_LIST:
            break
        end
    end
    result = {"ok": True, "from": iso_or_date(arguments.get("from")), "to": iso_or_date(arguments.get("to")), "timezone": common.fallback(calendar_clock.local_tz_name(), "local"), "count": len(keys), "events": events}
    if len(keys) > len(events):
        result["truncated"] = True
        result["note"] = "Only the first " + String(MAX_LIST) + " events are listed; ask for a shorter period."
    end
    return result
end

function iso_or_date(value):
    when = parse_when(value, "date")
    if when["kind"] == "D":
        return calendar_ics.iso_date(when["day"])
    end
    return iso_moment(when["moment"])
end

# Own event by uid (the series, not a RECURRENCE-ID override); errors explain read-only/unknown uids
function find_own(calendars, uid):
    for cal in calendars:
        if not cal["own"]:
            continue
        end
        for event in cal["events"]:
            if event["uid"] == uid and event["recurrence_id"] == None:
                return event
            end
        end
    end
    for cal in calendars:
        for event in cal["events"]:
            if event["uid"] == uid:
                if cal["own"]:
                    call fail("This is a changed single occurrence of a repeating event; LuxAI can change only the whole series. Use the Calendar app for single occurrences.")
                end
                call fail("The event is in the read-only calendar '" + calendar_name(cal["name"]) + "'; only events of the LuxOS calendar can be changed.")
            end
        end
    end
    call fail("No event with uid '" + uid[:120] + "' in the LuxOS calendar. Use calendar_list_events to find the uid.")
end

# ---- writing: splice VEVENT text under the lock --------------------------------------------------

# Top-level VEVENT blocks in the raw text: [{"start", "end", "uid", "override"}] (character offsets)
function vevent_blocks(text):
    blocks = []
    position = 0
    depth = 0
    current = None
    length = len(text)
    while position < length:
        cut = text.find("\n", position)
        if cut < 0:
            cut = length
        else:
            cut += 1
        end
        line = text[position:cut]
        bare = line.strip().upper()
        if not (line.startswith(" ") or line.startswith("\t")) and bare != "":
            if bare.startswith("BEGIN:"):
                depth += 1
                if depth == 2 and bare == "BEGIN:VEVENT":
                    current = {"start": position, "end": None, "uid": "", "override": False}
                end
            elif bare.startswith("END:"):
                if depth == 2 and current != None:
                    current["end"] = cut
                    blocks.append(current)
                    current = None
                end
                depth = max(0, depth - 1)
            end
        end
        position = cut
    end
    for block in blocks:
        inner_depth = 0
        for line in calendar_ics.unfold(text[block["start"]:block["end"]]):
            upper = line.strip().upper()
            if upper.startswith("BEGIN:"):
                inner_depth += 1
                continue
            end
            if upper.startswith("END:"):
                inner_depth -= 1
                continue
            end
            if inner_depth != 1:
                continue
            end
            parsed = calendar_ics.parse_line(line)
            if parsed == None:
                continue
            end
            if parsed[0] == "UID":
                block["uid"] = parsed[2].strip()
            elif parsed[0] == "RECURRENCE-ID":
                block["override"] = True
            end
        end
    end
    return blocks
end

function newline_of(text):
    if "\r\n" in text or not text.strip():
        return "\r\n"
    end
    return "\n"
end

# Position of the last END:VCALENDAR line (start of the line), or -1
function calendar_end(text):
    found = -1
    position = 0
    length = len(text)
    while position < length:
        cut = text.find("\n", position)
        if cut < 0:
            cut = length
        else:
            cut += 1
        end
        if text[position:cut].strip().upper() == "END:VCALENDAR":
            found = position
        end
        position = cut
    end
    return found
end

function splice_create(text, change, tzname):
    event = change["event"]
    if not text.strip():
        return calendar_ics.calendar_text([event], tzname)
    end
    cut = calendar_end(text)
    if cut < 0:
        call fail("The calendar file is damaged (no END:VCALENDAR); LuxAI does not change it. Open it in the Calendar app.")
    end
    return text[:cut] + calendar_ics.event_text(event, tzname, newline_of(text)) + text[cut:]
end

function block_event(text, block):
    lines = calendar_ics.unfold(text[block["start"]:block["end"]])
    return calendar_ics.event_from_lines(lines[1:len(lines) - 1])
end

function splice_update(text, change, tzname):
    output = text
    found = False
    blocks = vevent_blocks(text)
    for index in rang(len(blocks) - 1, -1, -1):
        block = blocks[index]
        if block["uid"] != change["uid"] or block["override"]:
            continue
        end
        current = None
        try:
            current = block_event(text, block)
        else:
            call fail("The event cannot be read from the calendar file; LuxAI does not change it.")
        end
        found = True
        updated = apply_update(current, change["arguments"])
        change["before"] = current
        change["after"] = updated
        output = output[:block["start"]] + calendar_ics.event_text(updated, tzname, newline_of(text)) + output[block["end"]:]
    end
    if not found:
        call fail("The event was deleted or changed in the meantime (no event with uid '" + change["uid"][:120] + "' in the LuxOS calendar).")
    end
    return output
end

function splice_delete(text, change, tzname):
    output = text
    found = False
    blocks = vevent_blocks(text)
    for index in rang(len(blocks) - 1, -1, -1):
        block = blocks[index]
        if block["uid"] != change["uid"]:
            continue
        end
        if not block["override"] and change.get("before") == None:
            try:
                change["before"] = block_event(text, block)
            else:
                change["before"] = None
            end
        end
        found = True
        output = output[:block["start"]] + output[block["end"]:]
    end
    if not found:
        call fail("The event was already deleted (no event with uid '" + change["uid"][:120] + "' in the LuxOS calendar).")
    end
    return output
end

function count_uid(cal, uid):
    count = 0
    for event in cal["events"]:
        if event["uid"] == uid:
            count += 1
        end
    end
    return count
end

# The new text must parse like the old one: same foreign components, only the intended change.
function verify(old_text, new_text, change):
    old = calendar_ics.parse(old_text)
    new = calendar_ics.parse(new_text)
    if len(new["other"]) != len(old["other"]) or new["errors"] != old["errors"]:
        call fail("Internal check failed: other calendar entries would change; nothing was saved.")
    end
    uid = change["uid"]
    expected = len(old["events"]) - count_uid(old, uid) + count_uid(new, uid)
    if len(new["events"]) != expected:
        call fail("Internal check failed: other events would change; nothing was saved.")
    end
    if change["action"] == "delete":
        if count_uid(new, uid) != 0:
            call fail("Internal check failed: the event is still in the file; nothing was saved.")
        end
        return
    end
    for event in new["events"]:
        if event["uid"] == uid and event["recurrence_id"] == None:
            wanted = change.get("after", change.get("event"))
            if event["summary"] != wanted["summary"] or event["description"] != wanted["description"] or event["location"] != wanted["location"] or event["all_day"] != wanted["all_day"]:
                call fail("Internal check failed: the saved event would differ; nothing was saved.")
            end
            return
        end
    end
    call fail("Internal check failed: the saved event cannot be read back; nothing was saved.")
end

SPLICERS = {"create": splice_create, "update": splice_update, "delete": splice_delete}

function cancelled_check(state):
    if state.get("cancelled") != None:
        return state["cancelled"](state)
    end
    return False
end

function write_change(state, change):
    directory = folder(state)
    call platform.mkdir_parents(directory)
    path = common.join(directory, OWN)
    handle = calendar_time.lock_file(common.join(directory, LOCK), 10.0, cancelled_check, state)
    if not handle:
        call fail("The calendar is busy (another program is saving it). Try again in a moment.")
    end
    problem = None
    result = None
    try:
        result = write_locked(state, change, directory, path)
    else:
        problem = String(last_error())
    end
    call calendar_time.unlock_file(handle)
    if problem != None:
        call fail(clean_error(problem))
    end
    return result
end

function write_locked(state, change, directory, path):
    tzname = calendar_clock.local_tz_name()
    for attempt in rang(RETRIES):
        change["before"] = None
        before = calendar_time.stat_key(path)
        text = common.fallback(read_text(path, True), "")
        after = calendar_time.stat_key(path)
        if before["key"] != after["key"]:
            continue
        end
        new_text = SPLICERS[change["action"]](text, change, tzname)
        call verify(text, new_text, change)
        if state.get("calendar_hook") != None:
            # tests: another program writes between our read and our rename
            call state["calendar_hook"](state, path, attempt)
        end
        mode = 420
        if before["exists"]:
            mode = before["mode"] & 511
        end
        temporary = path + ".tmp-" + String(platform.getpid()) + "-" + common.random_hex(8)
        call calendar_time.write_synced(temporary, new_text, mode)
        now = calendar_time.stat_key(path)
        if now["key"] != before["key"]:
            # the Calendar app (no lock) saved meanwhile: read its version and redo the change
            call platform.unlink(temporary)
            continue
        end
        if platform.rename(temporary, path) != 0:
            call platform.unlink(temporary)
            call fail("Cannot save the calendar file: " + platform.strerror(platform.errno_value()))
        end
        call calendar_time.fsync_dir(directory)
        return change
    end
    call fail("The calendar file keeps changing (another program is saving it). Try again in a moment.")
end

function own_state(state, arguments):
    calendars = load_calendars(state)
    uid = check_uid(arguments)
    return {"uid": uid, "event": find_own(calendars, uid)}
end

function create_event(state, arguments, prepared=None):
    call check_arguments("calendar_create_event", arguments)
    event = build_new(arguments)
    change = write_change(state, {"action": "create", "uid": event["uid"], "event": event})
    return {"ok": True, "created": True, "event": public_event(change["event"], None, None, None), "note": "The event is saved in the LuxOS Calendar."}
end

function update_event(state, arguments, prepared=None):
    call check_arguments("calendar_update_event", arguments)
    found = own_state(state, arguments)
    # validate before taking the lock (clear errors for the model)
    call apply_update(found["event"], arguments)
    change = write_change(state, {"action": "update", "uid": found["uid"], "arguments": arguments})
    after = change["after"]
    after["source"] = OWN
    before = change["before"]
    before["source"] = OWN
    return {"ok": True, "updated": True, "event": public_event(after, None, None, None), "before": public_event(before, None, None, None)}
end

function delete_event(state, arguments, prepared=None):
    call check_arguments("calendar_delete_event", arguments)
    found = own_state(state, arguments)
    change = write_change(state, {"action": "delete", "uid": found["uid"]})
    deleted = common.fallback(change.get("before"), found["event"])
    deleted["source"] = OWN
    return {"ok": True, "deleted": True, "event": public_event(deleted, None, None, None)}
end

function execute(state, name, arguments, prepared=None):
    try:
        if type(arguments) != "Dictionary":
            call fail("Tool arguments must be a JSON object")
        end
        if name == "calendar_list_events":
            return list_events(state, arguments)
        elif name == "calendar_create_event":
            return create_event(state, arguments, prepared)
        elif name == "calendar_update_event":
            return update_event(state, arguments, prepared)
        elif name == "calendar_delete_event":
            return delete_event(state, arguments, prepared)
        end
        call fail("Unknown tool: " + name)
    else:
        return {"ok": False, "error": clean_error(String(last_error()))}
    end
end

# Preview for the confirmation card (validated before the user is asked; read-only)
function prepare(state, name, arguments):
    try:
        if type(arguments) != "Dictionary":
            call fail("Tool arguments must be a JSON object")
        end
        call check_arguments(name, arguments)
        if name == "calendar_create_event":
            event = build_new(arguments)
            event["source"] = OWN
            return {"ok": True, "preview": {"action": "create", "event": public_event(event, None, None, 600)}}
        end
        found = own_state(state, arguments)
        event = found["event"]
        if name == "calendar_update_event":
            updated = apply_update(event, arguments)
            return {"ok": True, "preview": {"action": "update", "before": public_event(event, None, None, 600), "event": public_event(updated, None, None, 600)}}
        end
        return {"ok": True, "preview": {"action": "delete", "event": public_event(event, None, None, 600)}}
    else:
        return {"ok": False, "error": clean_error(String(last_error()))}
    end
end

# ---- display (cards) -----------------------------------------------------------------------------

function iso_day(text):
    if type(text) != "String" or len(text) < 10:
        return None
    end
    year = text[0:4]
    if not calendar_ics.digits(year) or two(text, 5) == None or two(text, 8) == None:
        return None
    end
    month = two(text, 5)
    day = two(text, 8)
    if month < 1 or month > 12 or day < 1 or day > calendar_ics.days_in_month(Int(year), month):
        return None
    end
    return calendar_ics.ordinal(Int(year), month, day)
end

function day_text(text):
    day = iso_day(text)
    if day == None:
        return String(text)
    end
    return i18n.translate(WEEKDAY_NAMES[calendar_ics.weekday(day)]) + " " + text[:10]
end

function zone_text(text):
    # abbreviation of the local zone at that moment (CET, CEST), from the ISO offset
    day = iso_day(text)
    if day == None or len(text) < 16:
        return ""
    end
    try:
        when = parse_when(text, "time")
        abbreviation = calendar_time.abbreviation(common.fallback(when.get("unix"), unix_of(when["moment"])))
        if abbreviation and not abbreviation.startswith("+") and not abbreviation.startswith("-"):
            return abbreviation
        end
        return "UTC" + text[len(text) - 6:]
    else:
        return ""
    end
end

# "Tuesday 2026-10-27, 10:00 – 11:00 (CET)" / "Tuesday 2026-10-27 · all day"
function when_text(event):
    start = String(common.fallback(event.get("start"), ""))
    finish = String(common.fallback(event.get("end"), start))
    if event.get("all_day"):
        text = day_text(start)
        if finish[:10] != start[:10]:
            text += " – " + day_text(finish)
        end
        return text + " · " + i18n.translate("all day")
    end
    if len(start) < 16:
        return start
    end
    text = day_text(start) + ", " + start[11:16]
    if len(finish) >= 16:
        if finish[:10] == start[:10]:
            text += " – " + finish[11:16]
        else:
            text += " – " + day_text(finish) + ", " + finish[11:16]
        end
    end
    zone = zone_text(start)
    ending = zone_text(finish)
    if zone and ending and ending != zone:
        zone = zone + " → " + ending
    end
    if zone:
        text += " (" + zone + ")"
    end
    return text
end

# Lines under the title of an event in the cards
function detail_lines(event):
    lines = [when_text(event)]
    if event.get("location"):
        lines.append(i18n.translate("Location: {0}").replace("{0}", String(event["location"])))
    end
    if event.get("reminder_min") != None:
        lines.append(i18n.translate("Reminder: {0} min before").replace("{0}", String(event["reminder_min"])))
    end
    if event.get("calendar") and event["calendar"] != "LuxOS":
        lines.append(i18n.translate("Calendar: {0}").replace("{0}", String(event["calendar"])))
    end
    return lines
end

# Plain text summary of a result (card details, history)
function summary(name, result):
    if type(result) != "Dictionary":
        return ""
    end
    if not result.get("ok"):
        return String(common.fallback(result.get("error"), ""))
    end
    lines = []
    events = []
    if name == "calendar_list_events":
        lines.append(i18n.translate("Events: {0}").replace("{0}", String(result.get("count", 0))))
        events = common.fallback(result.get("events"), [])
    elif type(result.get("event")) == "Dictionary":
        events = [result["event"]]
    end
    for event in events:
        if type(event) != "Dictionary":
            continue
        end
        lines.append(String(event.get("title", "")) + " — " + when_text(event))
    end
    return "\n".join(lines)
end
