# lsl: internal-abi
load root_helper
load platform
try:
    exit(root_helper.setup_main(root_helper.command_args()))
else:
    call platform.stderr("luxai-root-setup: " + String(last_error()) + "\n")
    exit(126)
end
