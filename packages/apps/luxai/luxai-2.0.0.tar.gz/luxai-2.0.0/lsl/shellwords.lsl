# POSIX shlex tokenization without shell execution. Quotes retain word boundaries,
# punctuation runs are separate tokens, and callers can detect malformed input.
load common
load platform

function split(input_text, punctuation=";&|()<>"):
    text = String(input_text)
    tokens = []
    word = []
    active = False
    state = "word"
    quote = ""
    i = 0
    while i < len(text):
        char = text[i]
        if quote != "":
            if char == quote:
                quote = ""
            elif char == "\\" and quote == "\"":
                if i + 1 >= len(text):
                    return {"tokens": [], "parsed": False}
                end
                i += 1
                if text[i] not in "\\\"":
                    word.append("\\")
                end
                word.append(text[i])
            else:
                word.append(char)
            end
        elif char in " \t\r\n":
            if active:
                tokens.append("".join(word))
                word = []
                active = False
            end
            state = "word"
        elif char in punctuation:
            if active and state != "punctuation":
                tokens.append("".join(word))
                word = []
            end
            word.append(char)
            active = True
            state = "punctuation"
        else:
            if active and state == "punctuation":
                tokens.append("".join(word))
                word = []
                active = False
            end
            state = "word"
            active = True
            if char in "\"'":
                quote = char
            elif char == "\\":
                if i + 1 >= len(text):
                    return {"tokens": [], "parsed": False}
                end
                i += 1
                word.append(text[i])
            else:
                word.append(char)
            end
        end
        i += 1
    end
    if quote != "":
        return {"tokens": [], "parsed": False}
    end
    if active:
        tokens.append("".join(word))
    end
    return {"tokens": tokens, "parsed": True}
end

function all_in(text, chars):
    if not text:
        return False
    end
    for char in text:
        if char not in chars:
            return False
        end
    end
    return True
end

function fallback_tokens(text):
    output = []
    for match in platform.regex_findall("[^\\s;&|()<>]+|[;&|()<>]+", text):
        output.append(match["groups"][0].strip("\"'"))
    end
    return output
end

function glob_match(name, pattern):
    expression = []
    i = 0
    while i < len(pattern):
        char = pattern[i]
        if char == "*":
            expression.append(".*")
        elif char == "?":
            expression.append(".")
        elif char == "[":
            j = i + 1
            if j < len(pattern) and pattern[j] == "!":
                j += 1
            end
            if j < len(pattern) and pattern[j] == "]":
                j += 1
            end
            while j < len(pattern) and pattern[j] != "]":
                j += 1
            end
            if j >= len(pattern):
                expression.append("\\[")
            else:
                chars = pattern[i + 1:j].replace("\\", "\\\\")
                if chars.startswith("!"):
                    chars = "^" + chars[1:]
                elif chars.startswith("^"):
                    chars = "\\" + chars
                end
                expression.append("[" + chars + "]")
                i = j
            end
        else:
            expression.append(platform.regex_escape(char))
        end
        i += 1
    end
    return platform.regex_test("(?s)^" + "".join(expression) + "$", name)
end
