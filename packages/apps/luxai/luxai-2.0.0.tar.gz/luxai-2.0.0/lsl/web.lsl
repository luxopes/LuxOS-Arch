# Native web tools: every hop validates all DNS addresses and libcurl connects
# to the selected address with the original host for TLS and HTTP Host.
load common
load platform
load net_address
load urls
load html_content
load web_data
load transport
load api
load json
load time
load i18n
load child_process
load version

function clean_error(text):
    if text.startswith("WebError: "):
        return text[10:]
    end
    return text
end

function new_fetcher(should_stop=None, callback_state=None, deadline=40):
    return {"should_stop": should_stop, "callback_state": callback_state, "deadline": deadline, "started": 0.0}
end

function stopped(fetcher):
    if fetcher.get("should_stop") == None:
        return False
    end
    if fetcher["callback_state"] == None:
        return fetcher["should_stop"]()
    end
    return fetcher["should_stop"](fetcher["callback_state"])
end

function request_stop(fetcher):
    return stopped(fetcher) or time.monotonic() - fetcher["started"] > fetcher["deadline"]
end

function accept_language():
    if i18n.language and i18n.language != "en":
        return i18n.language + ",en;q=0.8"
    end
    return "en"
end

function request(fetcher, url, method="GET", body=None, content_type=None, max_bytes=2097152):
    fetcher["started"] = time.monotonic()
    seen = []
    for hop in rang(6):
        if stopped(fetcher):
            Error(WebError: "Stopped by the user")
        end
        if time.monotonic() - fetcher["started"] > fetcher["deadline"]:
            Error(WebError: "The web request took too long")
        end
        parsed = urls.check(url)
        scheme = parsed[0]
        host = parsed[1]
        port = parsed[2]
        path = parsed[3]
        addresses = []
        if fetcher.get("resolver") != None:
            addresses = fetcher["resolver"](fetcher, host, port)
        else:
            addresses = net_address.addresses(host, port)
        end
        if not addresses:
            Error(WebError: "Cannot resolve host " + host)
        end
        for address in addresses:
            if not net_address.public_ip(address):
                Error(WebError: "Blocked: " + host + " resolves to a local or private network address (" + address + "); only public internet addresses can be fetched")
            end
        end
        ip = addresses[0]
        headers = {"User-Agent": "LuxAI/" + version.VERSION + " (LuxOS)", "Accept-Encoding": "identity", "Connection": "close", "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.5", "Accept-Language": accept_language()}
        if body != None:
            headers["Content-Type"] = common.fallback(content_type, "application/x-www-form-urlencoded")
        end
        ascii = net_address.ascii_host(host)
        server = ascii
        if ":" in server:
            server = "[" + server + "]"
        end
        pinned_url = scheme + "://" + server + ":" + String(port) + path
        resolve = None
        if net_address.ip(ascii) == None:
            target = ip
            if ":" in ip:
                target = "[" + ip + "]"
            end
            # Fresh handle and manual redirects: wildcard also covers curl's
            # canonicalization of case, IDNA and a trailing DNS root dot.
            resolve = [ascii + ":" + String(port) + ":" + target, "*:" + String(port) + ":" + target]
        end
        if fetcher.get("sender") != None:
            response = fetcher["sender"](fetcher, method, pinned_url, headers, common.fallback(body, ""), max_bytes, resolve)
        else:
            response = transport.request(method, pinned_url, headers, common.fallback(body, ""), 15, None, request_stop, max_bytes, resolve, fetcher, True, True)
        end
        status = response["status"]
        if status in [301, 302, 303, 307, 308]:
            location = response["headers"].get("location")
            if not location:
                Error(WebError: "Redirect without a target (HTTP " + String(status) + ")")
            end
            seen.append(url)
            url = urls.join(url, location.strip(common.WHITESPACE))
            if status == 303 or (status in [301, 302] and method == "POST"):
                method = "GET"
                body = None
            end
            continue
        end
        data = response["data"]
        truncated = response.get("truncated", False)
        if stopped(fetcher):
            Error(WebError: "Stopped by the user")
        end
        if time.monotonic() - fetcher["started"] > fetcher["deadline"]:
            if not data:
                Error(WebError: "The web request took too long")
            end
            truncated = True
        end
        if response["code"] != 0 and not truncated:
            if response["code"] == 60:
                Error(WebError: "TLS certificate of " + host + " is not valid")
            end
            if not data:
                if response["code"] == 28 or response.get("timed_out"):
                    Error(WebError: host + " did not respond in time")
                end
                Error(WebError: "Cannot connect to " + host + ": HTTP transport code " + String(response["code"]))
            end
            truncated = True
        end
        content_type = response["headers"].get("content-type", "").lower()
        charset = ""
        matches = platform.regex_findall("charset=[\"']?([\\w.:-]+)", content_type)
        if matches:
            charset = matches[0]["groups"][1]
        end
        return {"url": url, "status": status, "content_type": content_type.split(";")[0].strip(common.WHITESPACE), "charset": charset, "data": data, "truncated": truncated, "redirects": seen}
    end
    Error(WebError: "Too many redirects (more than 5)")
end

function decode(data, charset=""):
    if not charset:
        probe = platform.utf8_decode(data[:4096])
        matches = platform.regex_findall("(?i)<meta[^>]+charset=[\"']?([\\w.:-]+)", probe)
        charset = "utf-8"
        if matches:
            charset = matches[0]["groups"][1]
        end
    end
    return platform.decode_charset(data, charset)
end

function neutralize(text):
    return String(common.fallback(text, "")).replace("<<<", "‹‹‹").replace(">>>", "›››")
end

function wrap_untrusted(text):
    return web_data.UNTRUSTED_BEGIN + "\n" + neutralize(text) + "\n" + web_data.UNTRUSTED_END
end

function same_host_links(page, hrefs):
    host = ""
    try:
        host = urls.split(page)["host"].lower()
    else:
        return []
    end
    output = []
    for href in hrefs:
        try:
            absolute = urls.join(page, html_content.unescape(String(href)).strip(common.WHITESPACE))
            parsed = urls.split(absolute)
            if parsed["scheme"] not in ["http", "https"] or parsed["host"].lower() != host or parsed["query"] or "?" in absolute.split("#")[0]:
                continue
            end
            normal = urls.normalize(absolute)
            if normal and normal not in output:
                output.append(normal)
                if len(output) >= 300:
                    break
                end
            end
        else:
            continue
        end
    end
    return output
end

function fetch(url, max_chars=20000, fetcher=None):
    if fetcher == None:
        fetcher = new_fetcher()
    end
    response = None
    try:
        response = request(fetcher, url)
    else:
        return {"ok": False, "url": String(url)[:500], "error": clean_error(String(last_error()))}
    end
    if response["status"] >= 400:
        return {"ok": False, "url": response["url"], "status": response["status"], "error": "The server answered HTTP " + String(response["status"])}
    end
    content_type = response["content_type"]
    if content_type and not (content_type in web_data.TEXT_TYPES or content_type.startswith("text/") or content_type.endswith("+json") or content_type.endswith("+xml")):
        return {"ok": False, "url": response["url"], "content_type": content_type, "error": "Unsupported content type " + content_type + ": only web pages and text can be read"}
    end
    raw = decode(response["data"], response["charset"])
    title = ""
    hrefs = []
    text = platform.strip(raw, common.WHITESPACE)
    if content_type in ["text/html", "application/xhtml+xml"] or (not content_type and platform.regex_test("(?i)<html|<body", raw[:2000])):
        parsed = html_content.to_text(raw)
        title = String(parsed["title"])
        text = String(parsed["text"])
        hrefs = parsed["links"]
    end
    total = len(text)
    clipped = total > max_chars
    if clipped:
        if "\n" in text[max_chars - 2000:max_chars]:
            text = text[:max_chars]
            text = text[:common.rfind(text, "\n")]
        else:
            text = text[:max_chars]
        end
        text += "\n… [text truncated]"
    end
    result = {"ok": True, "url": response["url"], "title": neutralize(title)[:300], "content_type": common.fallback(content_type, "unknown"), "untrusted": True, "note": web_data.UNTRUSTED_NOTE, "content": wrap_untrusted(text), "characters": total}
    links = same_host_links(response["url"], hrefs)
    if links:
        result["_links"] = links
    end
    if response["redirects"]:
        result["redirected_from"] = response["redirects"][0][:500]
    end
    if clipped or response["truncated"]:
        result["truncated"] = True
    end
    if not platform.strip(text, common.WHITESPACE):
        result["note"] = web_data.UNTRUSTED_NOTE + " The page has no readable text (it may need JavaScript)."
    end
    return result
end

function ddg_target(href):
    href = html_content.unescape(href)
    if href.startswith("//"):
        href = "https:" + href
    end
    parsed = urls.split(href)
    if parsed["host"] and parsed["host"].endswith("duckduckgo.com"):
        if parsed["path"].startswith("/y.js"):
            return ""
        end
        href = ""
        for item in parsed["query"].split("&"):
            if "=" in item:
                index = item.find("=")
                if urls.unquote(item[:index], True) == "uddg":
                    value = urls.unquote(item[index + 1:], True)
                    if value:
                        href = value
                        break
                    end
                end
            end
        end
    end
    if platform.regex_test("(?i)^https?://", href):
        return href
    end
    return ""
end

function parse_ddg(html, limit=8):
    results = []
    field = None
    depth = 0
    ad = False
    for event in html_content.events(html):
        if event[0] == "start":
            classes = common.split_words(event[2].get("class", ""))
            if event[1] == "div" and "result" in classes:
                ad = "result--ad" in classes
            end
            if field != None:
                depth += 1
                continue
            end
            if "result__a" in classes and not ad:
                href = ddg_target(event[2].get("href", ""))
                if href:
                    results.append({"title": "", "url": href, "snippet": ""})
                    field = "title"
                    depth = 1
                end
            elif "result__snippet" in classes and results and not ad:
                field = "snippet"
                depth = 1
            end
        elif event[0] == "end":
            if field != None:
                depth -= 1
                if depth <= 0:
                    field = None
                end
            end
        elif field != None and results:
            results[len(results) - 1][field] += event[1]
        end
    end
    output = []
    seen = []
    for result in results:
        url = result["url"].strip(common.WHITESPACE)
        if url in seen:
            continue
        end
        seen.append(url)
        output.append({"title": common.fallback(common.words(result["title"])[:300], url), "url": url[:1000], "snippet": common.words(result["snippet"])[:500]})
        if len(output) >= limit:
            break
        end
    end
    return output
end

function search_account(client, query, limit=8):
    if client == None or not client.get("token") or client.get("search_unavailable"):
        return None
    end
    data = None
    try:
        data = api.request_json(client, "POST", web_data.SEARCH_PATH, {"query": query, "max_results": limit}, 25)
    else:
        problem = api.caught_error(String(last_error()))
        if api.is_auth(problem) or problem["status"] in [400, 404, 405, 501] or problem["code"] in ["not_found", "html_response", "protection"]:
            client["search_unavailable"] = True
        end
        return None
    end
    if type(data) != "Dictionary" or type(data.get("results")) != "List":
        return None
    end
    output = []
    for item in data["results"]:
        if type(item) != "Dictionary":
            continue
        end
        url = String(common.fallback(item.get("url"), ""))
        if not platform.regex_test("(?i)^https?://", url):
            continue
        end
        output.append({"title": common.words(String(common.fallback(item.get("title"), url)))[:300], "url": url[:1000], "snippet": common.words(String(common.fallback(item.get("content"), common.fallback(item.get("snippet"), ""))))[:500]})
        if len(output) >= limit:
            break
        end
    end
    return output
end

function search(query, max_results=None, client=None, fetcher=None):
    query = common.words(String(common.fallback(query, "")))
    if not query:
        return {"ok": False, "error": "web_search needs a non-empty query"}
    end
    if len(query) > 400:
        return {"ok": False, "error": "The query is too long (max 400 characters)"}
    end
    limit = 8
    try:
        if max_results != None:
            limit = Int(max_results)
        end
    else:
        limit = 8
    end
    limit = max(1, min(limit, 8))
    results = search_account(client, query, limit)
    provider = "luxai"
    if results == None:
        provider = "duckduckgo"
        if fetcher == None:
            fetcher = new_fetcher()
        end
        try:
            response = request(fetcher, web_data.DDG_URL, "POST", "q=" + urls.quote_plus(query) + "&b=", None, 1048576)
            if response["status"] >= 400:
                Error(WebError: "The search provider answered HTTP " + String(response["status"]))
            end
            html = decode(response["data"], response["charset"])
            results = parse_ddg(html, limit)
            if not results and ("anomaly" in html.lower() or response["status"] == 202):
                Error(WebError: "The search provider temporarily refused automated searches; try again in a minute")
            end
        else:
            return {"ok": False, "query": query, "error": "Web search failed: " + clean_error(String(last_error()))}
        end
    end
    clean = []
    parts = []
    for index in rang(len(results)):
        result = results[index]
        item = {"title": neutralize(result["title"]), "url": result["url"], "snippet": neutralize(result["snippet"])}
        clean.append(item)
        parts.append(("[" + String(index + 1) + "] " + item["title"] + "\n" + item["url"] + "\n" + item["snippet"]).rstrip(common.WHITESPACE))
    end
    return {"ok": True, "query": query, "provider": provider, "count": len(clean), "untrusted": True, "note": web_data.UNTRUSTED_NOTE + " Use web_fetch to read a page before relying on details; cite the URLs.", "content": wrap_untrusted(common.fallback("\n\n".join(parts), "(no results)")), "_results": clean}
end

function urls_in_text(text):
    output = []
    for found in platform.regex_findall("(?i)" + web_data.URL_IN_TEXT, String(common.fallback(text, ""))):
        raw = found["groups"][0]
        url = raw.rstrip(".,;:!?)'\"")
        if url.count("(") > url.count(")") and raw[len(url):].startswith(")"):
            url += ")"
        end
        normal = urls.normalize(url)
        if normal:
            output.append(normal)
        end
    end
    return output
end

function message_text(message):
    content = message.get("content")
    if type(content) == "List":
        parts = []
        for part in content:
            if type(part) == "Dictionary" and part.get("type") == "text":
                parts.append(String(common.fallback(part.get("text"), "")))
            end
        end
        return "\n".join(parts)
    end
    if type(content) == "String":
        return content
    end
    return ""
end

function trusted_urls(messages):
    calls = {}
    output = []
    for message in common.fallback(messages, []):
        if type(message) != "Dictionary":
            continue
        end
        role = message.get("role")
        if role == "user" and not message.get("_screenshot") and not message.get("_transient"):
            output += urls_in_text(message_text(message))
        elif role == "assistant":
            for tool_call in common.fallback(message.get("tool_calls"), []):
                if type(tool_call) == "Dictionary" and type(tool_call.get("function")) == "Dictionary":
                    calls[tool_call.get("id")] = tool_call["function"].get("name")
                end
            end
        elif role == "tool":
            name = calls.get(message.get("tool_call_id"))
            if name == "web_search":
                try:
                    data = json.decode(common.fallback(message.get("content"), "{}"))
                    if type(data) == "Dictionary" and data.get("ok"):
                        output += urls_in_text(data.get("content"))
                    end
                else:
                    continue
                end
            elif name == "web_fetch" and type(message.get("_links")) == "List":
                for link in message["_links"][:300]:
                    normal = urls.normalize(link)
                    if normal and not urls.split(normal)["query"]:
                        output.append(normal)
                    end
                end
            end
        end
    end
    unique = []
    for url in output:
        if url not in unique:
            unique.append(url)
        end
    end
    return unique
end

function fetch_trusted(url, messages):
    normal = urls.normalize(url)
    return Bool(normal) and normal in trusted_urls(messages)
end

function permission_trust(permissions, arguments, messages):
    return fetch_trusted(arguments.get("url", ""), messages)
end

function tool_stopped(state):
    return child_process.cancelled(state["signal"])
end

function tool_search(state, arguments):
    call child_process.reset(state["signal"])
    return search(arguments["query"], arguments.get("max_results"), state["client"], new_fetcher(tool_stopped, state))
end

function tool_fetch(state, arguments):
    call child_process.reset(state["signal"])
    return fetch(arguments["url"], 20000, new_fetcher(tool_stopped, state))
end
