# lsl: internal-abi
# Headless GTK integration driver, never the application entry point.
load gtk
load gtk_ext
load ui_widgets
load ui_dispatch
load gui_bridge
load ui_data
load json
load time
load glib
load ui_cards
load settings_window
load settings
load common
load platform
load app_model
load safety_data
load maps

function main_echo(state, arguments):
    return {"text": arguments, "main_thread": ui_dispatch.main_thread() == ui_dispatch.queues["main_thread"]}
end

function background_echo(state, arguments):
    return ui_dispatch.call_main(main_echo, state, arguments)
end

function clicked(state, widget):
    state["clicked"] += 1
end

function changed(state, property, widget):
    state["changed"] += 1
end

function confirmed(state, answer):
    state["answers"].append(answer)
end

function label_rows(container):
    # [text, varovny styl] pro popisky v potvrzovaci casti karty (poradi a barva jako v Pythonu)
    rows = []
    for child in gtk_ext.children(container):
        if __lsl_qbe_call2(__lsl_symbol("g_type_check_instance_is_a"), platform.pointer(child), __lsl_qbe_call0(__lsl_symbol("gtk_label_get_type"))) != 0:
            context = __lsl_qbe_call1(__lsl_symbol("gtk_widget_get_style_context"), platform.pointer(child))
            warn = __lsl_qbe_call2(__lsl_symbol("gtk_style_context_has_class"), platform.pointer(context), platform.cstr("warn-text")) != 0
            rows.append([gtk.label_get_text(child), warn])
        end
    end
    return rows
end

function preference_changed(state, key):
    state["changes"].append(key)
end

call gtk.init()
call ui_dispatch.initialize(1)
provider = gtk.css_load(ui_data.LIGHT + ui_data.CSS)
window = gtk.window_new("LuxAI GTK migration test")
call gtk.window_set_default_size(window, 800, 600)
column = ui_widgets.box(True, 8)
call gtk.container_add(window, column)
call ui_widgets.pack(column, ui_widgets.user_bubble("Ahoj", [], ["soubor.txt"]))
bubble = ui_widgets.assistant_bubble("", False)
call ui_widgets.pack(column, bubble["widget"])
call ui_widgets.append(bubble, "# Hello\n\nA **bold** text, $x^2$.\n\n```python\nprint('hi')\n```\n\n| A | B |\n|---|---|\n| 1 | 2 |\n\n- first\n- second\n\n> quote\n\n---\n")
call ui_widgets.finish(bubble)
view = ui_widgets.text_view("Příliš žluťoučký kůň")
call ui_widgets.pack(column, view)
state = {"clicked": 0, "changed": 0}
button = ui_widgets.button("Test", clicked, state)
call ui_widgets.pack(column, button)
call gtk_ext.connect(button, "notify::sensitive", changed, state, 1)
call gtk.button_clicked(button)
call gtk.widget_set_sensitive(button, False)
baseline = len(glib.handlers)
for index in rang(30):
    temporary = ui_widgets.button("temporary", clicked, state)
    call ui_widgets.pack(column, temporary)
    call gtk.widget_destroy(temporary)
end
call gtk_ext.collect_callbacks(None, None)
call gtk.button_clicked(button)
confirmation = {"answers": []}
card = ui_cards.new_card("danger", "run_command", {"command": "fixture only"})
call ui_widgets.pack(column, card["widget"])
call ui_cards.ask(card, "danger", ["fixture reason"], confirmed, confirmation)
call ui_cards.answer(card, "once")
first_stage_blocked = len(confirmation["answers"]) == 0
call gtk.button_clicked(card["buttons"]["next"])
second_stage = card["stage"]
call gtk.button_clicked(card["buttons"]["once"])
call ui_cards.answer(card, "once")
call ui_cards.set_result(card, {"ok": True, "output": "fixture result", "exit_code": 0}, "ok")
report = ui_cards.new_card("report", "send_feedback", {"kind": "bug", "title": "fixture"})
call ui_widgets.pack(column, report["widget"])
call ui_cards.set_prepared(report, {"kind": "bug", "message": "exact report text", "signed_in": False, "system": {"test": True}})
call ui_cards.ask(report, "ask", [], confirmed, confirmation)
report_always_hidden = "always" not in report["buttons"]
call ui_cards.answer(report, "always")
call gtk.button_clicked(report["buttons"]["deny"])
fetch = ui_cards.new_card("fetch", "web_fetch", {"url": "https://example.test/very/long/path?q=1"})
call ui_widgets.pack(column, fetch["widget"])
call ui_cards.ask(fetch, "confirm", [safety_data.FETCH_UNTRUSTED_REASON], confirmed, confirmation)
fetch_rows = label_rows(fetch["confirm"])
admin = ui_cards.new_card("admin", "run_command", {"command": "lux update", "root": True})
call ui_widgets.pack(column, admin["widget"])
call ui_cards.ask(admin, "ask", [safety_data.ADMIN_REASON], confirmed, confirmation)
ask_rows = label_rows(admin["confirm"])
call ui_cards.answer(fetch, "deny")
call ui_cards.answer(admin, "deny")
route_png = common.join(common.environment("XDG_RUNTIME_DIR", "/tmp"), "route-fixture.png")
call writebytes(route_png, common.base64_decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="))
route_card = ui_cards.new_card("route", "map_transit_route", {"start_latitude": 50.0757, "start_longitude": 14.4199, "end_latitude": 50.0905, "end_longitude": 14.3995})
call ui_widgets.pack(column, route_card["widget"])
route_preview = {"legs": [{"mode": "WALK", "label": "Walk", "color": "#64748B"}, {"mode": "TRAM", "label": "22", "color": "#7A0603"}, {"mode": "TRAM", "label": "<b>x</b>", "color": "red"}]}
route_result = {"ok": True, "itineraries": [{"departure_time": "19:10", "arrival_time": "19:33", "duration": "23 min", "transfers": 0, "legs": [{"transit": True, "mode_name": "Tram", "line": "22", "headsign": "Vypich", "departure_time": "19:11", "from": {"name": "Karlovo náměstí", "platform": "C"}, "delay_min": 1}]}], "_map": {"preview": route_preview, "image": route_png, "open": ["--route", "50.0757,14.4199", "50.0905,14.3995", "--mode", "transit"]}}
call ui_cards.set_result(route_card, route_result, "ok")
route_parts = len(gtk_ext.children(route_card["route_map"]))
route_rows = label_rows(route_card["preview"]) + label_rows(route_card["route_map"])
route_opened = maps.open_in_maps(["Praha"])
consent_card = ui_cards.new_card("where", "current_location", {})
call ui_widgets.pack(column, consent_card["widget"])
call ui_cards.set_result(consent_card, {"ok": False, "error": "consent", "note": "x"}, "error")
consent_rows = label_rows(consent_card["preview"])
copy_tooltip = ""
for child in gtk_ext.children(bubble["actions"]):
    copy_tooltip = glib.take_c(__lsl_qbe_call1(__lsl_symbol("gtk_widget_get_tooltip_text"), platform.pointer(child)))
end
call gtk.widget_show_all(window)
selection_label = ui_widgets.label("selection fixture", None, None, False, True)
call ui_widgets.pack(column, selection_label)
call gtk.widget_show(selection_label)
call __lsl_qbe_call3(__lsl_symbol("gtk_label_select_region"), platform.pointer(selection_label), 0, 9)
selected_text = ui_widgets.selected_text(column)
preferences = settings.Settings()
parent = {"widget": window, "settings": preferences.data, "settings_path": preferences.path, "changes": [], "on_setting_changed": preference_changed}
preferences_window = settings_window.new_window(parent, "ai")
call gtk_ext.combo_box_set_active_id(preferences_window["widgets"]["theme"]["widget"], "dark")
call gtk.switch_set_active(preferences_window["widgets"]["vision_lite"]["widget"], True)
call gtk_ext.text_buffer_set_text(gtk_ext.text_view_get_buffer(preferences_window["instructions"]), "Use Czech. Preserve functionality.", -1)
call settings_window.add_folder(preferences_window, "allowed_folders", "/tmp/fixture/../allowed")
call settings_window.add_folder(preferences_window, "allowed_folders", "/tmp/allowed")
parent["settings"]["model"] = "lite"
call settings_window.sync(preferences_window)
active_model = glib.from_c(gtk_ext.combo_box_get_active_id(preferences_window["widgets"]["model"]["widget"]))
call gtk.widget_destroy(preferences_window["widget"])
saved_preferences = common.read_json(preferences.path)
work = ui_dispatch.background(background_echo, None, "worker→GTK")
deadline = time.monotonic() + 3
while ui_dispatch.completed(work) == 0 and time.monotonic() < deadline:
    call gtk.pump()
    call time.sleep(0.005)
end
result = {"signals": state, "text": gtk_ext.buffer_text(gtk_ext.text_view_get_buffer(view)), "worker": work["value"], "error": work["error"], "markdown_children": len(gtk_ext.children(bubble["view"]["widget"])), "first_stage_blocked": first_stage_blocked, "second_stage": second_stage, "report_always_hidden": report_always_hidden, "answers": confirmation["answers"], "preferences": saved_preferences, "active_model": active_model, "preference_changes": parent["changes"]}
result["elapsed"] = ui_cards.elapsed_text(65)
result["fetch_rows"] = fetch_rows
result["ask_rows"] = ask_rows
result["copy_tooltip"] = copy_tooltip
result["route_parts"] = route_parts
result["route_rows"] = route_rows
result["route_button"] = "open_map" in route_card["buttons"]
result["route_opened"] = route_opened
result["consent_rows"] = consent_rows
result["selection"] = selected_text
call gtk.widget_destroy(card["widget"])
call gtk.widget_destroy(report["widget"])
call gtk.widget_destroy(fetch["widget"])
call gtk.widget_destroy(route_card["widget"])
call gtk.widget_destroy(consent_card["widget"])
call gtk.widget_destroy(admin["widget"])
call gtk.widget_destroy(selection_label)
call gtk_ext.collect_callbacks(None, None)
result["callback_delta"] = len(glib.handlers) - baseline
call gtk.widget_destroy(window)
call gtk.pump()
call ui_dispatch.close()
for worker in ui_dispatch.queues["threads"]:
    call thread_join(worker)
end
print json.encode(result)
