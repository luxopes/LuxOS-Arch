# lsl: internal-abi
# GTK work always runs on the initializing thread. Workers exchange records
# through locked queues; completion is published with an atomic signal.
load platform
load glib
load time

queue_lock = IntArray()
queue_lock.append(0)
queues = {"main": [], "workers": [], "threads": [], "ticks": [], "closing": False, "main_thread": 0, "timer": 0}

function main_thread():
    return __lsl_qbe_call0(__lsl_symbol("pthread_self"))
end

function pump():
    context = __lsl_qbe_call0(__lsl_symbol("g_main_context_default"))
    while __lsl_qbe_call2(__lsl_symbol("g_main_context_iteration"), context, 0) != 0:
        continue
    end
end

function job(handler, state, arguments):
    done = IntArray()
    done.append(0)
    return {"handler": handler, "state": state, "arguments": arguments, "done": done, "value": None, "error": None}
end

function completed(item):
    signal = IntArray(item["done"])
    return atomic_add(signal, 0, 0)
end

function execute(item):
    if completed(item) != 0:
        return
    end
    try:
        item["value"] = item["handler"](item["state"], item["arguments"])
    else:
        item["error"] = String(last_error())
    end
    signal = IntArray(item["done"])
    call atomic_xchg(signal, 0, 1)
end

function drain():
    pending = []
    lock queue_lock:
        while queues["main"]:
            pending.append(queues["main"].pop(0))
        end
    end
    for item in pending:
        call execute(item)
        if item["error"] != None:
            call platform.stderr("LuxAI GUI callback: " + item["error"] + "\n")
        end
    end
    for item in queues["ticks"].copy():
        try:
            call item["handler"](item["state"], None)
        else:
            call platform.stderr("LuxAI GUI tick: " + String(last_error()) + "\n")
        end
    end
    return True
end

function add_tick(handler, state=None):
    item = {"handler": handler, "state": state}
    queues["ticks"].append(item)
    return item
end

function remove_tick(item):
    if item in queues["ticks"]:
        call queues["ticks"].remove(item)
    end
end

function initialize(worker_count=3):
    queues["main_thread"] = main_thread()
    queues["closing"] = False
    if not queues["timer"]:
        queues["timer"] = glib.timeout_add(16, drain)
    end
    for index in rang(worker_count):
        queues["threads"].append(thread_spawn(worker))
    end
end

function post(handler, state, arguments=None):
    item = job(handler, state, arguments)
    lock queue_lock:
        if queues["closing"]:
            Error(GuiError: "The application is closing")
        end
        queues["main"].append(item)
    end
    return item
end

function call_main(handler, state, arguments=None, timeout=15):
    if main_thread() == queues["main_thread"]:
        return handler(state, arguments)
    end
    item = post(handler, state, arguments)
    deadline = time.monotonic() + timeout
    while completed(item) == 0:
        if time.monotonic() >= deadline:
            signal = IntArray(item["done"])
            call atomic_xchg(signal, 0, 2)
            Error(GuiError: "GUI call timed out")
        end
        call time.sleep(0.005)
    end
    if item["error"] != None:
        Error(GuiError: item["error"])
    end
    return item["value"]
end

function background(handler, state, arguments=None):
    item = job(handler, state, arguments)
    lock queue_lock:
        if queues["closing"]:
            Error(GuiError: "The application is closing")
        end
        queues["workers"].append(item)
    end
    return item
end

function worker():
    while True:
        item = None
        closing = False
        lock queue_lock:
            closing = queues["closing"]
            if not closing and queues["workers"]:
                item = queues["workers"].pop(0)
            end
        end
        if closing:
            return
        end
        if item == None:
            call time.sleep(0.01)
        else:
            call execute(item)
        end
    end
end

function close():
    lock queue_lock:
        queues["closing"] = True
        for item in queues["main"] + queues["workers"]:
            item["error"] = "The application is closing"
            signal = IntArray(item["done"])
            call atomic_xchg(signal, 0, 2)
        end
        queues["main"] = []
        queues["workers"] = []
    end
    if queues["timer"]:
        call glib.source_remove(queues["timer"])
        queues["timer"] = 0
    end
end
