VERSION = "2.0.0"
APP_ID = "cz.luxai.LuxAI"
