# lsl: internal-abi
# Headless LuxAI session for the LuxOS Companion Bluetooth bridge (`luxai --remote-session`).
# JSON object per line: stdin = requests from the bridge, stdout = replies, stderr = logs only.
# Reuses the signed-in account, settings, safety rules and agent permissions of the desktop
# app. Nothing is ever auto-approved: a tool that would show an ask/confirm card in the GUI
# pauses the run and asks the phone for a one-time approval bound to the request, the tool
# call and its exact arguments; admin commands, desktop control, send_feedback and DANGER
# actions are always refused. See docs/REMOTE-SESSION.md.
load common
load platform
load glib
load json
load time
load settings
load store
load api
load attachments
load safety
load safety_data
load calendar_data
load rootmode
load tools
load tool_format
load agent_core
load catalog
load i18n

PROTOCOL = 1
CAPABILITIES = ["models", "tools", "approvals"]
# the same choice as the model selector in the GUI toolbar (app_window.build_header)
MODELS = [["flash", "Flash – smarter"], ["lite", "Lite – faster, larger limit"]]
APPROVAL_TIMEOUT_MS = 60000
MAX_TOOL_EVENTS = 100
MAX_DETAIL = 4000
MAX_NAME = 200
MAX_TEXT = 8000
MAX_LINE = 262144
MAX_ID = 128
CONFIRM_REQUIRED = "This action requires confirmation on the computer"
DENY_ERROR = "This action requires confirmation on the computer (Tato akce vyžaduje potvrzení na počítači). The request came from the LuxOS Companion phone app, from which this kind of action (administrator commands, desktop control, feedback, dangerous actions) can never be approved, so the action was NOT executed. Do not try to achieve it through another tool; tell the user they can do it in the LuxAI app on the computer."
PHONE_DENY_ERROR = "The user denied this action in the LuxOS Companion phone app, so it was NOT executed. Do not try to achieve it through another tool."
TIMEOUT_ERROR = "The user did not approve this action in the LuxOS Companion phone app within the time limit, so it was NOT executed. Do not try to achieve it through another tool; the user can ask again."
REMOTE_NOTE = "This request comes from the LuxOS Companion app on the user's phone (through a Bluetooth bridge); the user may not be at the computer and sees your answer text and a short status of each tool call, not tool cards. Keep answers concise and easy to read on a phone. Actions that need the user's confirmation (for example writing files in the home folder, adding, changing or deleting calendar events, opening an app or a link) are shown on the phone, where the user can approve them once; if the user denies them or does not answer in time they are not executed - then do not try another way. Administrator (root/sudo) commands, controlling the desktop (mouse, keyboard, windows, screenshots, clipboard), sending feedback and actions marked dangerous are always refused from the phone; if that happens, explain briefly what the user would have to do in LuxAI on the computer."
REMOTE_CONTROL_REASON = "controls the desktop session, which cannot be watched from the phone"

io_lock = IntArray()
io_lock.append(0)
state_lock = IntArray()
state_lock.append(0)
# busy: a request is running; pending: a job is waiting for the worker; quit: worker exits
flags = IntArray()
for index in rang(3):
    flags.append(0)
end
BUSY = 0
PENDING = 1
QUIT = 2
session = {"in": 0, "out": 1, "conversation": None, "job": None, "run": None, "running_id": None, "approval": None}

function log(text):
    call platform.stderr("LuxAI remote session: " + text + "\n")
end

function write_all(handle, text):
    offset = 0
    length = platform.byte_length(text)
    while offset < length:
        count = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("write"), platform.pointer(handle), platform.cstr(text) + platform.pointer(offset), platform.pointer(length - offset)))
        if count < 0:
            if platform.errno_value() == 4:
                continue
            end
            return False
        end
        offset += count
    end
    return True
end

function send(message):
    line = json.encode(message) + "\n"
    lock io_lock:
        call write_all(session["out"], line)
    end
end

function send_error(reply_to, code, message):
    call send({"type": "error", "reply_to": reply_to, "code": code, "message": message})
end

function error_code(problem):
    # mapovani chyb API na stabilni kody protokolu (viz docs/REMOTE-SESSION.md)
    code = problem.get("code", "")
    if api.is_auth(problem):
        return "not_signed_in"
    end
    if code in ["flash_monthly_limit", "monthly_limit"]:
        return "monthly_limit"
    end
    if code in ["network", "timeout"]:
        return "network"
    end
    if code in ["chat_busy", "chat_rate", "rate"] or problem.get("status") == 429:
        return "rate_limited"
    end
    if code in ["unavailable", "protection", "html_response", "bad_response", "not_found"] or (problem.get("status", 0) >= 500):
        return "service_unavailable"
    end
    if code == "too_large":
        return "too_large"
    end
    if code in ["model", "invalid_chat"]:
        return "model_error"
    end
    return "internal"
end

function preferences(values):
    temperature = None
    if values["temperature_custom"]:
        temperature = Float(values["temperature"])
    end
    return {"style": values["style"], "language": values["language"], "instructions": values["instructions"], "max_tokens": catalog.ANSWER_LENGTHS.get(values["answer_length"], 4096), "temperature": temperature}
end

function workdir(values):
    path = values["workdir"]
    if path:
        info = platform.file_info(path)
        if info != None and info["directory"]:
            return path
        end
    end
    return glib.home_dir()
end

function privileged(name, arguments):
    # administrator commands: root=true, sudo/pkexec/su/doas/run0 anywhere in the command
    if name != "run_command" or type(arguments) != "Dictionary":
        return False
    end
    if rootmode.flag(arguments.get("root")):
        return True
    end
    command = String(common.fallback(arguments.get("command"), ""))
    if platform.regex_test(safety_data.PRIV_ANYWHERE, command):
        return True
    end
    for raw in safety.split_commands(command):
        if safety.uses_privilege(raw):
            return True
        end
    end
    return False
end

function remote_judge(permissions, name, arguments, run):
    # Stejne posouzeni jako v GUI; navic se vzdalene nikdy nespusti prikaz jako spravce
    # (ani v rezimu "noask") a nic, co ovlada plochu (vstup, obrazovka, schranka).
    result = safety.judge(permissions, name, arguments, run)
    if result["action"] == "block":
        return result
    end
    reasons = common.copy(common.fallback(result.get("reasons"), []))
    if privileged(name, arguments):
        if safety_data.ADMIN_REASON not in reasons:
            reasons.append(safety_data.ADMIN_REASON)
        end
        return {"action": "danger", "level": "danger", "reasons": reasons}
    end
    if result["action"] == "allow":
        if name in calendar_data.WRITE_TOOLS:
            # zmeny kalendare vzdy jen se souhlasem (na telefonu jednorazove)
            reasons.append(calendar_data.REASONS[name])
            result = {"action": "ask", "level": "ask", "reasons": reasons}
        elif safety_data.TOOL_CATEGORY.get(name) in ["input", "screen"]:
            reasons.append(REMOTE_CONTROL_REASON)
            result = {"action": "confirm", "level": "sensitive", "reasons": reasons}
        end
    end
    return result
end

function phone_approvable(name, arguments, kind):
    # Only what the GUI asks about at the ask/confirm level. Never: DANGER, administrator
    # commands, desktop input/screen/clipboard/windows, send_feedback.
    if kind not in ["ask", "confirm"] or type(arguments) != "Dictionary":
        return False
    end
    if name in safety_data.ALWAYS_CONFIRM_TOOLS or name == "send_feedback":
        return False
    end
    if safety_data.TOOL_CATEGORY.get(name) in ["input", "screen"] or name in ["list_windows", "focus_window", "close_window", "screenshot", "clipboard_read", "type_text", "press_key", "mouse_move", "mouse_click", "scroll"]:
        return False
    end
    if privileged(name, arguments):
        return False
    end
    return True
end

function redact(text, ui=None):
    # tokens, passwords and Authorization headers never leave the computer in tool details
    value = String(common.fallback(text, ""))
    if ui != None:
        for secret in common.fallback(ui.get("secrets"), []):
            if type(secret) == "String" and len(secret) >= 8:
                value = value.replace(secret, "[redacted]")
            end
        end
    end
    value = platform.regex_replace("(?i)(authorization\\s*[:=]\\s*)(?:(?:bearer|basic|token|digest)\\s+)?[^\\s'\"]+", "\\1[redacted]", value)
    value = platform.regex_replace("(?i)(\\bbearer\\s+)[A-Za-z0-9._~+/=-]{6,}", "\\1[redacted]", value)
    value = platform.regex_replace("(?i)((?:password|passwd|passphrase|pwd|secret|token|api[_-]?key|access[_-]?key|client[_-]?secret|private[_-]?key|cookie)[\"']?\\s*[:=]\\s*[\"']?)[^\\s'\",;&]+", "\\1[redacted]", value)
    value = platform.regex_replace("(?i)(--?(?:password|passwd|pass|token|api-key|apikey|secret)(?:=|\\s+))[^\\s'\"]+", "\\1[redacted]", value)
    value = platform.regex_replace("(?i)(\\b[a-z][a-z0-9+.-]*://[^\\s:/@]+:)[^\\s@/]+@", "\\1[redacted]@", value)
    value = platform.regex_replace("\\b(?:sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|glpat-[A-Za-z0-9_-]{16,}|xox[abprs]-[A-Za-z0-9-]{10,}|AKIA[0-9A-Z]{16}|eyJ[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,})", "[redacted]", value)
    return value
end

function clip(text, limit):
    if len(text) <= limit:
        return text
    end
    return text[:limit - 1] + "…"
end

function args_hash(name, arguments):
    # binds an approval to the exact, immutable tool arguments
    text = name + "\n" + json.encode(arguments)
    return glib.take_c(__lsl_qbe_call3(__lsl_symbol("g_compute_checksum_for_string"), 2, platform.cstr(text), platform.pointer(platform.byte_length(text))))
end

function new_uuid():
    return common.strip_text(String(readfile("/proc/sys/kernel/random/uuid")))
end

function approval_timeout_ms():
    # tests may only shorten the 60 s limit (LUXAI_REMOTE_APPROVAL_TIMEOUT_MS), never extend it
    value = APPROVAL_TIMEOUT_MS
    try:
        text = glib.getenv("LUXAI_REMOTE_APPROVAL_TIMEOUT_MS")
        if text:
            value = max(200, min(APPROVAL_TIMEOUT_MS, Int(String(text))))
        end
    else:
        value = APPROVAL_TIMEOUT_MS
    end
    return value
end

function value_text(value):
    if type(value) == "String":
        return value
    end
    return json.encode(value)
end

function brief(name, arguments):
    # what is running: the approved command for run_command, otherwise label + subject
    if type(arguments) != "Dictionary":
        arguments = {}
    end
    if name == "run_command":
        return String(common.fallback(arguments.get("command"), ""))
    end
    label = i18n.translate(tool_format.label(name))
    subject = tool_format.subject(name, arguments)
    if subject:
        return label + ": " + subject
    end
    return label
end

function describe(name, arguments):
    # full description for the approval on the phone: label, then every argument
    lines = [i18n.translate(tool_format.label(name))]
    if type(arguments) == "Dictionary":
        for key in arguments.keys():
            lines.append(String(key) + ": " + clip(value_text(arguments[key]), 1500))
        end
    end
    return "\n".join(lines)
end

function tool_event(ui, id, name, state, detail):
    known = ui["tool_ids"]
    if id not in known:
        if len(known) >= MAX_TOOL_EVENTS:
            return
        end
        known.append(id)
    end
    call send({"type": "tool", "reply_to": ui["id"], "tool_id": clip(String(id), MAX_NAME), "name": clip(String(name), MAX_NAME), "state": state, "detail": clip(redact(detail, ui), MAX_DETAIL)})
end

function result_detail(ui, id, result, status):
    if status == "denied":
        reason = ui["denials"].get(id)
        if reason == "phone":
            return i18n.translate("Denied on the phone.")
        elif reason == "timeout":
            return i18n.translate("Not approved on the phone in time.")
        end
        return i18n.translate(CONFIRM_REQUIRED)
    end
    if status == "cancelled":
        return i18n.translate("Stopped.")
    end
    if status == "blocked":
        return i18n.translate("Blocked by LuxAI safety rules.")
    end
    if type(result) == "Dictionary" and type(result.get("exit_code")) == "Int":
        return "Exit " + String(result["exit_code"])
    end
    if status == "ok":
        return i18n.translate("Done.")
    end
    error = ""
    if type(result) == "Dictionary":
        error = String(common.fallback(result.get("error"), ""))
    end
    error = common.strip_text(common.fallback(error.split("\n")[0], ""))
    return clip(common.fallback(error, "Error"), 300)
end

function deliver(ui, text):
    if not text:
        return
    end
    if ui["sent"] and ui["needs_break"]:
        text = "\n\n" + text
    end
    ui["needs_break"] = False
    ui["sent"] = True
    call send({"type": "delta", "reply_to": ui["id"], "text": text})
end

function on_event(ui, name, arguments):
    # runs in the worker thread; reasoning (arguments[1] of stream_delta) is never forwarded
    if name == "stream_start":
        ui["buffer"] = ""
        ui["holding"] = ui["mode"] == "agent"
        if ui["sent"]:
            ui["needs_break"] = True
        end
    elif name == "stream_delta":
        text = arguments[0]
        if type(text) != "String" or not text:
            return
        end
        if ui["holding"]:
            ui["buffer"] = ui["buffer"] + text
            start = common.lstrip_text(ui["buffer"])
            if not start:
                return
            end
            # Text that may be tool-call JSON printed by the model waits for the end of the
            # step: agent_core then discards it (stream_end without content) instead of showing it.
            if start.startswith("{") or start.startswith("`"):
                return
            end
            ui["holding"] = False
            text = ui["buffer"]
            ui["buffer"] = ""
        end
        call deliver(ui, text)
    elif name == "stream_end":
        message = arguments[0]
        if ui["buffer"] and type(message) == "Dictionary" and message.get("content"):
            call deliver(ui, ui["buffer"])
        end
        ui["buffer"] = ""
        ui["holding"] = False
    elif name == "tool_start":
        # a new real tool call: an approval of an earlier call can never carry over
        ui["approved"] = None
        ui["calls"][arguments[0]] = {"name": arguments[1], "args": arguments[2]}
    elif name == "tool_running":
        call_info = common.fallback(ui["calls"].get(arguments[0]), {"name": arguments[1], "args": {}})
        call tool_event(ui, arguments[0], arguments[1], "running", brief(arguments[1], call_info["args"]))
    elif name == "tool_result":
        state = "failed"
        if arguments[3] == "ok":
            state = "completed"
        end
        call tool_event(ui, arguments[0], arguments[1], state, result_detail(ui, arguments[0], arguments[2], arguments[3]))
    elif name == "error":
        ui["problem"] = arguments[0]
    end
end

function deny_on_computer(ui, id, name, arguments):
    # Not approvable from the phone (and a headless process has no confirmation card): deny,
    # tell the model (DENY_ERROR in the tool result) and the user (notice in the answer).
    detail = name
    if name == "run_command" and type(arguments) == "Dictionary":
        detail = name + ": " + redact(common.words(String(arguments.get("command", ""))), ui)[:200]
    end
    if ui["sent"]:
        ui["needs_break"] = True
    end
    call deliver(ui, "⚠ " + i18n.translate(CONFIRM_REQUIRED) + " (" + detail + ").")
    ui["needs_break"] = True
    ui["denied"].append(name)
    ui["denials"][id] = "computer"
    ui["deny_error"] = DENY_ERROR
    return "deny"
end

function cancelled(ui):
    signal = IntArray(ui["cancel_signal"])
    return atomic_add(signal, 0, 0) != 0
end

function wait_for_answer(ui, approval):
    while True:
        answer = None
        lock state_lock:
            if approval["answer"] == None:
                if cancelled(ui):
                    approval["answer"] = "cancelled"
                elif time.monotonic() > approval["deadline"]:
                    approval["answer"] = "timeout"
                end
            end
            answer = approval["answer"]
            if answer != None and session["approval"] != None and session["approval"]["approval_id"] == approval["approval_id"]:
                session["approval"] = None
            end
        end
        if answer != None:
            return answer
        end
        call time.sleep(0.02)
    end
end

function confirm(ui, id, name, arguments, kind, reasons):
    # One-time approval on the phone for ask/confirm-level actions; everything else is denied.
    if not phone_approvable(name, arguments, kind) or (id not in ui["tool_ids"] and len(ui["tool_ids"]) >= MAX_TOOL_EVENTS):
        return deny_on_computer(ui, id, name, arguments)
    end
    timeout_ms = approval_timeout_ms()
    approval = {"approval_id": new_uuid(), "request_id": ui["id"], "tool_id": id, "name": name, "hash": args_hash(name, arguments), "deadline": time.monotonic() + timeout_ms / 1000.0, "answer": None}
    detail = clip(redact(describe(name, arguments), ui), MAX_DETAIL)
    lock state_lock:
        session["approval"] = approval
    end
    call tool_event(ui, id, name, "waiting", detail)
    call send({"type": "approval", "reply_to": ui["id"], "tool_id": clip(String(id), MAX_NAME), "approval_id": approval["approval_id"], "name": clip(String(name), MAX_NAME), "detail": detail, "timeout_ms": timeout_ms})
    answer = wait_for_answer(ui, approval)
    if answer == "approved" and not cancelled(ui):
        # "always" is never stored from the phone: the answer is always "once"
        ui["approved"] = {"tool_id": id, "name": name, "hash": approval["hash"]}
        return "once"
    end
    if answer == "timeout":
        ui["denials"][id] = "timeout"
        ui["deny_error"] = TIMEOUT_ERROR
    else:
        ui["denials"][id] = "phone"
        ui["deny_error"] = PHONE_DENY_ERROR
    end
    return "deny"
end

function remote_execute(tools, name, arguments, prepared):
    # defence in depth: an approved action runs only with exactly the approved arguments
    ui = tools["remote_ui"]
    approved = ui.get("approved")
    ui["approved"] = None
    if approved != None and (approved["name"] != name or approved["hash"] != args_hash(name, arguments)):
        return {"ok": False, "blocked": True, "error": "The tool arguments changed after the approval on the phone; the action was NOT executed."}
    end
    return tools["remote_inner"](tools, name, arguments, prepared)
end

function answer_approval(message):
    # in: {"type":"approval","request_id","approval_id","approved"} - accepted exactly once,
    # only for the pending approval of the running request and before it expires
    request_id = message.get("request_id")
    approval_id = message.get("approval_id")
    approved = message.get("approved")
    if type(request_id) != "String" or not request_id or type(approval_id) != "String" or not approval_id or type(approved) != "Bool":
        call send_error(None, "invalid_request", "An approval needs request_id, approval_id and approved (true or false).")
        return
    end
    accepted = False
    lock state_lock:
        pending = session["approval"]
        if pending != None and pending["answer"] == None and pending["approval_id"] == approval_id and pending["request_id"] == request_id and session["running_id"] == request_id and session["run"] != None and not agent_core.is_cancelled(session["run"]) and time.monotonic() <= pending["deadline"]:
            if approved:
                pending["answer"] = "approved"
            else:
                pending["answer"] = "denied"
            end
            session["approval"] = None
            accepted = True
        end
    end
    if not accepted:
        call log("ignored an unknown, late or repeated approval")
    end
end

function models_reply(message):
    id = message.get("id")
    if type(id) != "String" or not id or len(id) > MAX_ID:
        call send_error(None, "invalid_request", "The request needs an id (string, at most 128 characters).")
        return
    end
    if not api.load_account():
        call send_error(id, "not_signed_in", i18n.translate("You are not signed in to LuxAI. Sign in in the LuxAI app on the computer."))
        return
    end
    output = []
    for item in MODELS:
        output.append({"id": item[0], "name": i18n.translate(item[1])})
    end
    call send({"type": "models", "reply_to": id, "models": output})
end

function model_ids():
    output = []
    for item in MODELS:
        output.append(item[0])
    end
    return output
end

function finish(ui, reason):
    lock state_lock:
        session["run"] = None
        session["running_id"] = None
        session["approval"] = None
    end
    call atomic_xchg(flags, BUSY, 0)
    if reason == "cancelled":
        call send_error(ui["id"], "cancelled", i18n.translate("The request was stopped."))
    elif reason == "error":
        problem = common.fallback(ui.get("problem"), api.error("internal"))
        call send_error(ui["id"], error_code(problem), api.human(problem))
    else:
        call send({"type": "done", "reply_to": ui["id"]})
    end
end

function worker():
    while True:
        if atomic_add(flags, QUIT, 0) != 0:
            return None
        end
        if atomic_cas(flags, PENDING, 1, 0) != 1:
            call time.sleep(0.01)
            continue
        end
        job = None
        lock state_lock:
            job = session["job"]
            session["job"] = None
        end
        if job == None:
            continue
        end
        reason = "error"
        try:
            reason = agent_core.run(job["run"])
        else:
            job["ui"]["problem"] = api.error("internal", 0, String(last_error()))
            call log("run failed: " + String(last_error()))
            reason = "error"
        end
        call finish(job["ui"], reason)
    end
end

function start_request(message):
    id = message.get("id")
    if type(id) != "String" or not id or len(id) > MAX_ID:
        call send_error(None, "invalid_request", "The request needs an id (string, at most 128 characters).")
        return
    end
    text = message.get("text")
    mode = message.get("mode", "chat")
    if type(text) != "String" or not common.strip_text(text):
        call send_error(id, "invalid_request", "The request needs a non-empty text.")
        return
    end
    if len(text) > MAX_TEXT:
        call send_error(id, "too_long", "The text is longer than 8000 characters.")
        return
    end
    if mode not in ["chat", "agent"]:
        call send_error(id, "invalid_request", "The mode must be \"chat\" or \"agent\".")
        return
    end
    requested_model = message.get("model")
    if requested_model != None and type(requested_model) != "String":
        call send_error(id, "invalid_request", "The model must be a string.")
        return
    end
    if requested_model != None and requested_model not in model_ids():
        # never silently another model
        call send_error(id, "model_unavailable", i18n.translate("This model is not available in LuxAI."))
        return
    end
    if atomic_add(flags, BUSY, 0) != 0:
        call send_error(id, "busy", i18n.translate("Another request is still running. Wait for it to finish or cancel it."))
        return
    end
    # account and settings are read for every request, so sign-in/out and changes in the
    # desktop app apply immediately
    account = api.load_account()
    if not account:
        call send_error(id, "not_signed_in", i18n.translate("You are not signed in to LuxAI. Sign in in the LuxAI app on the computer."))
        return
    end
    values = settings.Settings().data
    model = values["model"]
    if requested_model != None:
        model = requested_model
    elif model not in model_ids():
        model = "flash"
    end
    conversation = session["conversation"]
    conversation["mode"] = mode
    conversation["model"] = model
    conversation["messages"].append(attachments.user_message(text, []))
    permissions = safety.new_permissions(False, values["agent"])
    permissions["judge"] = remote_judge
    backend_client = api.new_client(account)
    backend = tools.new_tools(workdir(values), None, values["timeout"], False, None, permissions["policy"]["blocked_folders"], backend_client, mode == "chat")
    secrets = []
    for key in ["sessionToken", "token", "cookie"]:
        if type(account.get(key)) == "String":
            secrets.append(account[key])
        end
    end
    ui = {"id": id, "mode": mode, "emit": on_event, "confirm": confirm, "deny_error": DENY_ERROR, "sent": False, "needs_break": False, "buffer": "", "holding": False, "denied": [], "denials": {}, "problem": None, "calls": {}, "tool_ids": [], "approved": None, "secrets": secrets}
    backend["remote_inner"] = backend["execute"]
    backend["execute"] = remote_execute
    backend["remote_ui"] = ui
    run = agent_core.new_run(conversation, api.new_client(account, backend_client["origin"]), ui, backend, permissions, preferences(values), False, "")
    ui["cancel_signal"] = run["cancel_signal"]
    run["system_note"] = REMOTE_NOTE
    call atomic_xchg(flags, BUSY, 1)
    lock state_lock:
        session["run"] = run
        session["running_id"] = id
        session["job"] = {"run": run, "ui": ui}
    end
    call atomic_xchg(flags, PENDING, 1)
end

function cancel_running(request_id=None):
    # the same cancel path as Stop in the GUI (app_model.stop -> agent_core.cancel)
    run = None
    lock state_lock:
        if request_id == None or session["running_id"] == request_id:
            run = session["run"]
        end
    end
    if run != None:
        call agent_core.cancel(run)
    end
end

function handle_line(raw):
    if not platform.valid_utf8(raw):
        call send_error(None, "invalid_request", "The line is not valid UTF-8.")
        return
    end
    line = common.strip_text(platform.utf8_repair(raw))
    if not line:
        return
    end
    message = None
    try:
        message = json.decode(line)
    else:
        message = None
    end
    if type(message) != "Dictionary":
        call send_error(None, "invalid_request", "Each line must be one JSON object.")
        return
    end
    kind = message.get("type")
    if kind == "request":
        call start_request(message)
    elif kind == "models":
        call models_reply(message)
    elif kind == "approval":
        call answer_approval(message)
    elif kind == "cancel":
        target = message.get("request_id")
        if type(target) == "String" and target:
            call cancel_running(target)
        end
    else:
        call send_error(None, "invalid_request", "Unknown message type.")
    end
end

function read_chunk(handle):
    # None = end of input; empty ByteArray = nothing yet (poll timeout or EINTR)
    descriptor = platform.buffer(8)
    call __lsl_qbe_store32(platform.address(descriptor), platform.pointer(handle))
    descriptor[4] = 1
    ready = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("poll"), platform.address(descriptor), 1, 250))
    if ready <= 0:
        return ByteArray()
    end
    chunk = platform.buffer(65536)
    count = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("read"), platform.pointer(handle), platform.address(chunk), 65536))
    if count < 0:
        if platform.errno_value() in [4, 11]:
            return ByteArray()
        end
        return None
    end
    if count == 0:
        return None
    end
    return chunk[:count]
end

function isolate_standard_streams():
    # The protocol uses private copies of stdin/stdout. fd 0 becomes /dev/null and fd 1 goes
    # to stderr, so no tool, library or launched application can read requests or write
    # into the protocol stream.
    session["in"] = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("fcntl"), 0, 1030, 3))
    session["out"] = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("fcntl"), 1, 1030, 3))
    if session["in"] < 0 or session["out"] < 0:
        Error(RemoteError: "standard input/output is not available")
    end
    null = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("open"), platform.cstr("/dev/null"), 524290, 0))
    if null >= 0:
        call __lsl_qbe_call2(__lsl_symbol("dup2"), platform.pointer(null), 0)
        call __lsl_qbe_call1(__lsl_symbol("close"), platform.pointer(null))
    end
    call __lsl_qbe_call2(__lsl_symbol("dup2"), 2, 1)
    # a closed bridge must not kill the process in the middle of a write (EPIPE instead)
    call __lsl_qbe_call2(__lsl_symbol("signal"), 13, 1)
end

function run():
    try:
        call isolate_standard_streams()
    else:
        call log(String(last_error()))
        return 1
    end
    session["conversation"] = store.Conversation(None, "", "chat", "flash")
    worker_id = thread_spawn(worker)
    if worker_id < 0:
        call log("cannot start the worker thread")
        return 1
    end
    call send({"type": "ready", "protocol": PROTOCOL, "capabilities": CAPABILITIES})
    line = ByteArray()
    discarding = False
    while True:
        chunk = read_chunk(session["in"])
        if chunk == None:
            break
        end
        for byte in chunk:
            if byte == 10:
                if discarding:
                    call send_error(None, "invalid_request", "The line is too long.")
                else:
                    try:
                        call handle_line(line)
                    else:
                        call log("request failed: " + String(last_error()))
                        call send_error(None, "internal", "The request could not be processed.")
                    end
                end
                line = ByteArray()
                discarding = False
            elif not discarding:
                line.append(byte)
                if len(line) > MAX_LINE:
                    line = ByteArray()
                    discarding = True
                end
            end
        end
    end
    # EOF: cancel the running request (it still gets its "cancelled" error) and exit 0
    call cancel_running()
    deadline = time.monotonic() + 15
    while (atomic_add(flags, BUSY, 0) != 0 or atomic_add(flags, PENDING, 0) != 0) and time.monotonic() < deadline:
        call time.sleep(0.01)
    end
    if atomic_add(flags, BUSY, 0) != 0:
        call log("the running request did not stop in time")
        call __lsl_qbe_call1(__lsl_symbol("_exit"), 0)
    end
    call atomic_xchg(flags, QUIT, 1)
    call thread_join(worker_id)
    return 0
end
