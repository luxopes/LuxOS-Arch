# lsl: internal-abi
# Headless LuxAI session for the LuxOS Companion Bluetooth bridge (`luxai --remote-session`).
# JSON object per line: stdin = requests from the bridge, stdout = replies, stderr = logs only.
# Reuses the signed-in account, settings, safety rules and agent permissions of the desktop
# app. Nothing is ever auto-approved: every tool that would show a confirmation card in the
# GUI is refused here (the phone cannot confirm in protocol 1). See docs/REMOTE-SESSION.md.
load common
load platform
load glib
load json
load time
load settings
load store
load api
load attachments
load safety
load safety_data
load calendar_data
load rootmode
load tools
load agent_core
load catalog
load i18n

PROTOCOL = 1
MAX_TEXT = 8000
MAX_LINE = 262144
MAX_ID = 128
CONFIRM_REQUIRED = "This action requires confirmation on the computer"
DENY_ERROR = "This action requires confirmation on the computer (Tato akce vyžaduje potvrzení na počítači). The request came from the LuxOS Companion phone app, which cannot confirm actions, so the action was NOT executed. Do not try to achieve it through another tool; tell the user they can do it in the LuxAI app on the computer."
REMOTE_NOTE = "This request comes from the LuxOS Companion app on the user's phone (through a Bluetooth bridge); the user may not be at the computer and sees only your answer text, not tool cards. Keep answers concise and easy to read on a phone. Actions that need the user's confirmation cannot be confirmed from the phone and are refused; if that happens, explain briefly what the user would have to do in LuxAI on the computer. Reading the calendar works; adding, changing or deleting calendar events needs confirmation on the computer (to add a note to the calendar from the phone the user can use the calendar note in the LuxOS Companion app)."
REMOTE_CONTROL_REASON = "controls the desktop session, which cannot be watched from the phone"

io_lock = IntArray()
io_lock.append(0)
state_lock = IntArray()
state_lock.append(0)
# busy: a request is running; pending: a job is waiting for the worker; quit: worker exits
flags = IntArray()
for index in rang(3):
    flags.append(0)
end
BUSY = 0
PENDING = 1
QUIT = 2
session = {"in": 0, "out": 1, "conversation": None, "job": None, "run": None, "running_id": None}

function log(text):
    call platform.stderr("LuxAI remote session: " + text + "\n")
end

function write_all(handle, text):
    offset = 0
    length = platform.byte_length(text)
    while offset < length:
        count = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("write"), platform.pointer(handle), platform.cstr(text) + platform.pointer(offset), platform.pointer(length - offset)))
        if count < 0:
            if platform.errno_value() == 4:
                continue
            end
            return False
        end
        offset += count
    end
    return True
end

function send(message):
    line = json.encode(message) + "\n"
    lock io_lock:
        call write_all(session["out"], line)
    end
end

function send_error(reply_to, code, message):
    call send({"type": "error", "reply_to": reply_to, "code": code, "message": message})
end

function error_code(problem):
    # mapovani chyb API na stabilni kody protokolu (viz docs/REMOTE-SESSION.md)
    code = problem.get("code", "")
    if api.is_auth(problem):
        return "not_signed_in"
    end
    if code in ["flash_monthly_limit", "monthly_limit"]:
        return "monthly_limit"
    end
    if code in ["network", "timeout"]:
        return "network"
    end
    if code in ["chat_busy", "chat_rate", "rate"] or problem.get("status") == 429:
        return "rate_limited"
    end
    if code in ["unavailable", "protection", "html_response", "bad_response", "not_found"] or (problem.get("status", 0) >= 500):
        return "service_unavailable"
    end
    if code == "too_large":
        return "too_large"
    end
    if code in ["model", "invalid_chat"]:
        return "model_error"
    end
    return "internal"
end

function preferences(values):
    temperature = None
    if values["temperature_custom"]:
        temperature = Float(values["temperature"])
    end
    return {"style": values["style"], "language": values["language"], "instructions": values["instructions"], "max_tokens": catalog.ANSWER_LENGTHS.get(values["answer_length"], 4096), "temperature": temperature}
end

function workdir(values):
    path = values["workdir"]
    if path:
        info = platform.file_info(path)
        if info != None and info["directory"]:
            return path
        end
    end
    return glib.home_dir()
end

function remote_judge(permissions, name, arguments, run):
    # Stejne posouzeni jako v GUI; navic se vzdalene nikdy nespusti prikaz jako spravce
    # (ani v rezimu "noask") a nic, co ovlada plochu (vstup, obrazovka, schranka).
    result = safety.judge(permissions, name, arguments, run)
    if result["action"] == "allow":
        reasons = common.copy(common.fallback(result.get("reasons"), []))
        if name == "run_command" and type(arguments) == "Dictionary" and rootmode.flag(arguments.get("root")):
            reasons.append(safety_data.ADMIN_REASON)
            result = {"action": "danger", "level": "danger", "reasons": reasons}
        elif name in calendar_data.WRITE_TOOLS:
            # zmeny kalendare jen s potvrzenim na pocitaci (telefon ma vlastni calendar.note.create)
            reasons.append(calendar_data.REASONS[name])
            result = {"action": "ask", "level": "ask", "reasons": reasons}
        elif safety_data.TOOL_CATEGORY.get(name) in ["input", "screen"]:
            reasons.append(REMOTE_CONTROL_REASON)
            result = {"action": "confirm", "level": "sensitive", "reasons": reasons}
        end
    end
    return result
end

function deliver(ui, text):
    if not text:
        return
    end
    if ui["sent"] and ui["needs_break"]:
        text = "\n\n" + text
    end
    ui["needs_break"] = False
    ui["sent"] = True
    call send({"type": "delta", "reply_to": ui["id"], "text": text})
end

function on_event(ui, name, arguments):
    # runs in the worker thread; reasoning (arguments[1] of stream_delta) is never forwarded
    if name == "stream_start":
        ui["buffer"] = ""
        ui["holding"] = ui["mode"] == "agent"
        if ui["sent"]:
            ui["needs_break"] = True
        end
    elif name == "stream_delta":
        text = arguments[0]
        if type(text) != "String" or not text:
            return
        end
        if ui["holding"]:
            ui["buffer"] = ui["buffer"] + text
            start = common.lstrip_text(ui["buffer"])
            if not start:
                return
            end
            # Text that may be tool-call JSON printed by the model waits for the end of the
            # step: agent_core then discards it (stream_end without content) instead of showing it.
            if start.startswith("{") or start.startswith("`"):
                return
            end
            ui["holding"] = False
            text = ui["buffer"]
            ui["buffer"] = ""
        end
        call deliver(ui, text)
    elif name == "stream_end":
        message = arguments[0]
        if ui["buffer"] and type(message) == "Dictionary" and message.get("content"):
            call deliver(ui, ui["buffer"])
        end
        ui["buffer"] = ""
        ui["holding"] = False
    elif name == "error":
        ui["problem"] = arguments[0]
    end
end

function confirm(ui, id, name, arguments, kind, reasons):
    # Protocol 1 has no phone confirmation and a headless process has no confirmation card:
    # deny, tell the model (DENY_ERROR in the tool result) and the user (notice in the answer).
    detail = name
    if name == "run_command" and type(arguments) == "Dictionary":
        detail = name + ": " + common.words(String(arguments.get("command", "")))[:200]
    end
    if ui["sent"]:
        ui["needs_break"] = True
    end
    call deliver(ui, "⚠ " + i18n.translate(CONFIRM_REQUIRED) + " (" + detail + ").")
    ui["needs_break"] = True
    ui["denied"].append(name)
    return "deny"
end

function finish(ui, reason):
    lock state_lock:
        session["run"] = None
        session["running_id"] = None
    end
    call atomic_xchg(flags, BUSY, 0)
    if reason == "cancelled":
        call send_error(ui["id"], "cancelled", i18n.translate("The request was stopped."))
    elif reason == "error":
        problem = common.fallback(ui.get("problem"), api.error("internal"))
        call send_error(ui["id"], error_code(problem), api.human(problem))
    else:
        call send({"type": "done", "reply_to": ui["id"]})
    end
end

function worker():
    while True:
        if atomic_add(flags, QUIT, 0) != 0:
            return None
        end
        if atomic_cas(flags, PENDING, 1, 0) != 1:
            call time.sleep(0.01)
            continue
        end
        job = None
        lock state_lock:
            job = session["job"]
            session["job"] = None
        end
        if job == None:
            continue
        end
        reason = "error"
        try:
            reason = agent_core.run(job["run"])
        else:
            job["ui"]["problem"] = api.error("internal", 0, String(last_error()))
            call log("run failed: " + String(last_error()))
            reason = "error"
        end
        call finish(job["ui"], reason)
    end
end

function start_request(message):
    id = message.get("id")
    if type(id) != "String" or not id or len(id) > MAX_ID:
        call send_error(None, "invalid_request", "The request needs an id (string, at most 128 characters).")
        return
    end
    text = message.get("text")
    mode = message.get("mode", "chat")
    if type(text) != "String" or not common.strip_text(text):
        call send_error(id, "invalid_request", "The request needs a non-empty text.")
        return
    end
    if len(text) > MAX_TEXT:
        call send_error(id, "too_long", "The text is longer than 8000 characters.")
        return
    end
    if mode not in ["chat", "agent"]:
        call send_error(id, "invalid_request", "The mode must be \"chat\" or \"agent\".")
        return
    end
    if atomic_add(flags, BUSY, 0) != 0:
        call send_error(id, "busy", i18n.translate("Another request is still running. Wait for it to finish or cancel it."))
        return
    end
    # account and settings are read for every request, so sign-in/out and changes in the
    # desktop app apply immediately
    account = api.load_account()
    if not account:
        call send_error(id, "not_signed_in", i18n.translate("You are not signed in to LuxAI. Sign in in the LuxAI app on the computer."))
        return
    end
    values = settings.Settings().data
    model = values["model"]
    conversation = session["conversation"]
    conversation["mode"] = mode
    conversation["model"] = model
    conversation["messages"].append(attachments.user_message(text, []))
    permissions = safety.new_permissions(False, values["agent"])
    permissions["judge"] = remote_judge
    backend_client = api.new_client(account)
    backend = tools.new_tools(workdir(values), None, values["timeout"], False, None, permissions["policy"]["blocked_folders"], backend_client, mode == "chat")
    ui = {"id": id, "mode": mode, "emit": on_event, "confirm": confirm, "deny_error": DENY_ERROR, "sent": False, "needs_break": False, "buffer": "", "holding": False, "denied": [], "problem": None}
    run = agent_core.new_run(conversation, api.new_client(account, backend_client["origin"]), ui, backend, permissions, preferences(values), False, "")
    run["system_note"] = REMOTE_NOTE
    call atomic_xchg(flags, BUSY, 1)
    lock state_lock:
        session["run"] = run
        session["running_id"] = id
        session["job"] = {"run": run, "ui": ui}
    end
    call atomic_xchg(flags, PENDING, 1)
end

function cancel_running(request_id=None):
    # the same cancel path as Stop in the GUI (app_model.stop -> agent_core.cancel)
    run = None
    lock state_lock:
        if request_id == None or session["running_id"] == request_id:
            run = session["run"]
        end
    end
    if run != None:
        call agent_core.cancel(run)
    end
end

function handle_line(raw):
    if not platform.valid_utf8(raw):
        call send_error(None, "invalid_request", "The line is not valid UTF-8.")
        return
    end
    line = common.strip_text(platform.utf8_repair(raw))
    if not line:
        return
    end
    message = None
    try:
        message = json.decode(line)
    else:
        message = None
    end
    if type(message) != "Dictionary":
        call send_error(None, "invalid_request", "Each line must be one JSON object.")
        return
    end
    kind = message.get("type")
    if kind == "request":
        call start_request(message)
    elif kind == "cancel":
        target = message.get("request_id")
        if type(target) == "String" and target:
            call cancel_running(target)
        end
    else:
        call send_error(None, "invalid_request", "Unknown message type.")
    end
end

function read_chunk(handle):
    # None = end of input; empty ByteArray = nothing yet (poll timeout or EINTR)
    descriptor = platform.buffer(8)
    call __lsl_qbe_store32(platform.address(descriptor), platform.pointer(handle))
    descriptor[4] = 1
    ready = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("poll"), platform.address(descriptor), 1, 250))
    if ready <= 0:
        return ByteArray()
    end
    chunk = platform.buffer(65536)
    count = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("read"), platform.pointer(handle), platform.address(chunk), 65536))
    if count < 0:
        if platform.errno_value() in [4, 11]:
            return ByteArray()
        end
        return None
    end
    if count == 0:
        return None
    end
    return chunk[:count]
end

function isolate_standard_streams():
    # The protocol uses private copies of stdin/stdout. fd 0 becomes /dev/null and fd 1 goes
    # to stderr, so no tool, library or launched application can read requests or write
    # into the protocol stream.
    session["in"] = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("fcntl"), 0, 1030, 3))
    session["out"] = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("fcntl"), 1, 1030, 3))
    if session["in"] < 0 or session["out"] < 0:
        Error(RemoteError: "standard input/output is not available")
    end
    null = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("open"), platform.cstr("/dev/null"), 524290, 0))
    if null >= 0:
        call __lsl_qbe_call2(__lsl_symbol("dup2"), platform.pointer(null), 0)
        call __lsl_qbe_call1(__lsl_symbol("close"), platform.pointer(null))
    end
    call __lsl_qbe_call2(__lsl_symbol("dup2"), 2, 1)
    # a closed bridge must not kill the process in the middle of a write (EPIPE instead)
    call __lsl_qbe_call2(__lsl_symbol("signal"), 13, 1)
end

function run():
    try:
        call isolate_standard_streams()
    else:
        call log(String(last_error()))
        return 1
    end
    session["conversation"] = store.Conversation(None, "", "chat", "flash")
    worker_id = thread_spawn(worker)
    if worker_id < 0:
        call log("cannot start the worker thread")
        return 1
    end
    call send({"type": "ready", "protocol": PROTOCOL})
    line = ByteArray()
    discarding = False
    while True:
        chunk = read_chunk(session["in"])
        if chunk == None:
            break
        end
        for byte in chunk:
            if byte == 10:
                if discarding:
                    call send_error(None, "invalid_request", "The line is too long.")
                else:
                    try:
                        call handle_line(line)
                    else:
                        call log("request failed: " + String(last_error()))
                        call send_error(None, "internal", "The request could not be processed.")
                    end
                end
                line = ByteArray()
                discarding = False
            elif not discarding:
                line.append(byte)
                if len(line) > MAX_LINE:
                    line = ByteArray()
                    discarding = True
                end
            end
        end
    end
    # EOF: cancel the running request (it still gets its "cancelled" error) and exit 0
    call cancel_running()
    deadline = time.monotonic() + 15
    while (atomic_add(flags, BUSY, 0) != 0 or atomic_add(flags, PENDING, 0) != 0) and time.monotonic() < deadline:
        call time.sleep(0.01)
    end
    if atomic_add(flags, BUSY, 0) != 0:
        call log("the running request did not stop in time")
        call __lsl_qbe_call1(__lsl_symbol("_exit"), 0)
    end
    call atomic_xchg(flags, QUIT, 1)
    call thread_join(worker_id)
    return 0
end
