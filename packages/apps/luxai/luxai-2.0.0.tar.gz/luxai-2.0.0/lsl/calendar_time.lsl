# lsl: internal-abi
# lsl: link libglib-2.0.so.0 libc.so.6
# Audited native boundary for the calendar tools: local time zone (GLib GTimeZone, thread-safe,
# no TZ environment changes) and the file protocol shared with the LuxOS Calendar and the
# LuxOS Companion bridge (flock, stat identity, fsync, atomic rename).
#
# Times are "naive local" seconds like in the LuxOS Calendar (luxos_ics.lsl / luxos_date.lsl):
# day ordinal (1 = 0001-01-01) * 86400 + seconds of the day.
load glib
load common
load platform

DAY = 86400
EPOCH = 719163
TIME_STANDARD = 0
TIME_DAYLIGHT = 1
TIME_UNIVERSAL = 2

zones = {}
zone_lock = IntArray()
zone_lock.append(0)

function cstr(text):
    return __lsl_address(text) + 16
end

function pointer(value):
    return __lsl_unbox_int(value)
end

# ---- time zones (primitives; the logic is in calendar_clock) ------------------------------------
# NOTE (LSL 0.10.6, internal-abi): Int 0 and None are the same value inside this module, so no
# function here uses None as a "not found" marker: lists and handle 0 are used instead.

# GTimeZone handle for the process local zone ("") or an IANA name; 0 when the name is unknown.
function zone(name=""):
    value = 0
    lock zone_lock:
        if name in zones:
            value = zones[name]
        else:
            if name == "":
                value = __lsl_qbe_call0(__lsl_symbol("g_time_zone_new_local"))
            elif name.find("..") < 0 and not name.startswith("/") and exists("/usr/share/zoneinfo/" + name):
                value = __lsl_qbe_call1(__lsl_symbol("g_time_zone_new_identifier"), cstr(name))
            end
            zones[name] = value
        end
    end
    return value
end

# [offset seconds] of the interval containing `seconds` (kind: standard/daylight local time or
# universal time), [] when there is none (local time in a DST gap)
function offset_at(handle, kind, seconds):
    if handle == 0:
        return []
    end
    interval = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("g_time_zone_find_interval"), pointer(handle), pointer(kind), pointer(seconds)))
    if interval < 0:
        return []
    end
    return [__lsl_qbe_s32(__lsl_qbe_call2(__lsl_symbol("g_time_zone_get_offset"), pointer(handle), pointer(interval)))]
end

function abbreviation(unix):
    handle = zone("")
    if handle == 0:
        return ""
    end
    interval = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("g_time_zone_find_interval"), pointer(handle), TIME_UNIVERSAL, pointer(unix)))
    if interval < 0:
        return ""
    end
    return glib.from_c(__lsl_qbe_call2(__lsl_symbol("g_time_zone_get_abbreviation"), pointer(handle), pointer(interval)))
end

function now_unix():
    return __lsl_qbe_call1(__lsl_symbol("time"), 0)
end

# ---- files: the events.ics write protocol --------------------------------------------------------

# Identity of a file (inode, mtime with ns, size); {"exists": False} when it does not exist.
function stat_key(path):
    call platform.check_path(path)
    data = __lsl_byte_zeros(144)
    status = __lsl_qbe_s32(__lsl_qbe_call2(__lsl_symbol("stat"), cstr(path), platform.address(data)))
    if status != 0:
        return {"exists": False, "key": "-"}
    end
    base = platform.address(data)
    inode = __lsl_qbe_load64(base + 8)
    size = __lsl_qbe_load64(base + 48)
    seconds = __lsl_qbe_load64(base + 88)
    nanos = __lsl_qbe_load64(base + 96)
    mode = __lsl_qbe_load32(base + 24)
    return {"exists": True, "key": String(inode) + ":" + String(seconds) + "." + String(nanos) + ":" + String(size), "size": size, "mode": mode & 4095, "file": (mode & 61440) == 32768}
end

# Exclusive flock on the shared lock file (.events.ics.lock, same as luxos_companion.calendar_note).
# Returns [fd]; [] after `timeout` seconds or when `cancelled(state)` says so.
function lock_file(path, timeout, cancelled, state):
    call platform.check_path(path)
    fd = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("open"), cstr(path), 525377, 420))
    if fd < 0:
        Error(FileError: "Cannot open the calendar lock file: " + platform.strerror(platform.errno_value()))
    end
    waited = 0.0
    while True:
        # LOCK_EX | LOCK_NB
        if __lsl_qbe_s32(__lsl_qbe_call2(__lsl_symbol("flock"), pointer(fd), 6)) == 0:
            return [fd]
        end
        if waited >= timeout or cancelled(state):
            call __lsl_qbe_call1(__lsl_symbol("close"), pointer(fd))
            return []
        end
        call __lsl_qbe_call1(__lsl_symbol("usleep"), 20000)
        waited += 0.02
    end
end

function unlock_file(handle):
    for fd in handle:
        call __lsl_qbe_call2(__lsl_symbol("flock"), pointer(fd), 8)
        call __lsl_qbe_call1(__lsl_symbol("close"), pointer(fd))
    end
end

# New file (O_EXCL) with the whole text, flushed to disk (fsync). Error on failure (file removed).
function write_synced(path, text, mode):
    call platform.check_path(path)
    # O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC
    fd = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("open"), cstr(path), 524481, pointer(mode)))
    if fd < 0:
        Error(FileError: "Cannot create " + path + ": " + platform.strerror(platform.errno_value()))
    end
    failed = False
    offset = 0
    length = platform.byte_length(text)
    while offset < length:
        count = __lsl_qbe_call3(__lsl_symbol("write"), pointer(fd), cstr(text) + pointer(offset), pointer(length - offset))
        if count <= 0:
            failed = True
            break
        end
        offset += count
    end
    if __lsl_qbe_s32(__lsl_qbe_call1(__lsl_symbol("fsync"), pointer(fd))) != 0:
        failed = True
    end
    # the mode is exact (not reduced by umask), like the original file
    call __lsl_qbe_call2(__lsl_symbol("fchmod"), pointer(fd), pointer(mode))
    if __lsl_qbe_s32(__lsl_qbe_call1(__lsl_symbol("close"), pointer(fd))) != 0:
        failed = True
    end
    if failed:
        call platform.unlink(path)
        Error(FileError: "Cannot write the calendar file (disk full or read-only?)")
    end
end

function fsync_dir(path):
    call platform.check_path(path)
    # O_RDONLY | O_DIRECTORY | O_CLOEXEC
    fd = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("open"), cstr(path), 589824, 0))
    if fd >= 0:
        call __lsl_qbe_call1(__lsl_symbol("fsync"), pointer(fd))
        call __lsl_qbe_call1(__lsl_symbol("close"), pointer(fd))
    end
end

function new_uid():
    raw = ""
    try:
        raw = common.strip_text(String(readfile("/proc/sys/kernel/random/uuid")))
    else:
        raw = ""
    end
    if not raw:
        raw = common.random_hex(32)
    end
    return raw + "@luxai"
end
