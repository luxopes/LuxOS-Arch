# Mapy a jizdni rady pres LuxOS Maps (`luxos-maps --json ...`), shodne s luxai/maps.py.
# Na desktopu se nikdy nevola webova sluzba primo: cache, limity, pravidla sluzeb a souhlas
# s polohou ma aplikace Mapy. Vysledek pro model je bez `preview`; nahled trasy (PNG,
# preview a argumenty "Otevrit v Mapach") se uklada u zpravy jako `_map`.
load common
load platform
load child_process
load json
load glib
load catalog
load i18n
load maps_coord

MAX_SUMMARY_ITEMS = 8

function point(latitude, longitude):
    return maps_coord.point(latitude, longitude)
end

function invalid(message):
    Error(ValueError: message)
end

function number(arguments, key, low, high):
    value = arguments.get(key)
    if type(value) not in ["Int", "Float"]:
        call invalid(key + " must be a number")
    end
    if value < low or value > high:
        call invalid(key + " must be between " + String(low) + " and " + String(high))
    end
    return value
end

function integer(arguments, key, default, low, high):
    value = arguments.get(key)
    if type(value) not in ["Int", "Float"]:
        return default
    end
    return max(low, min(high, Int(value)))
end

function text(arguments, key):
    value = arguments.get(key)
    if type(value) == "String":
        return common.strip_text(value)
    end
    return ""
end

function here(arguments):
    return point(number(arguments, "latitude", -90, 90), number(arguments, "longitude", -180, 180))
end

function command(name, arguments):
    # [argv za `luxos-maps --json`, argumenty pro "Otevrit v Mapach" nebo None]
    if type(arguments) != "Dictionary":
        arguments = {}
    end
    if name == "map_geocode":
        query = text(arguments, "query")
        if not query:
            call invalid("query must be a non-empty string")
        end
        return [["search", query, "--limit", String(integer(arguments, "limit", 5, 1, 10))], None]
    elif name == "map_reverse":
        return [["reverse", here(arguments)], None]
    elif name == "map_nearby":
        center = here(arguments)
        category = text(arguments, "category")
        query = text(arguments, "query")
        if category and category not in catalog.MAPS_CATEGORIES:
            call invalid("unknown category " + category)
        end
        if not category and not query:
            call invalid("give a category or a query")
        end
        argv = ["nearby", center]
        if category:
            argv += ["--category", category]
        end
        if query:
            argv += ["--name", query]
        end
        return [argv + ["--radius", String(integer(arguments, "radius_meters", 1500, 50, 10000)), "--limit", String(integer(arguments, "limit", 20, 1, 50))], None]
    elif name in ["map_route", "map_transit_route"]:
        start = point(number(arguments, "start_latitude", -90, 90), number(arguments, "start_longitude", -180, 180))
        finish = point(number(arguments, "end_latitude", -90, 90), number(arguments, "end_longitude", -180, 180))
        if name == "map_route":
            mode = common.fallback(text(arguments, "travel_mode"), "driving")
            if mode not in catalog.MAPS_TRAVEL_MODES:
                call invalid("travel_mode must be driving, walking or cycling")
            end
            profile = catalog.MAPS_TRAVEL_MODES[mode]
            return [["route", start, finish, "--mode", profile], ["--route", start, finish, "--mode", profile]]
        end
        argv = ["transit-route", start, finish, "--max-transfers", String(integer(arguments, "max_transfers", 3, 0, 8)), "--limit", String(integer(arguments, "limit", 3, 1, 5))]
        if text(arguments, "time"):
            argv += ["--time", text(arguments, "time")]
        end
        if arguments.get("arrive_by") == True and type(arguments.get("arrive_by")) == "Bool":
            argv.append("--arrive")
        end
        return [argv, ["--route", start, finish, "--mode", "transit"]]
    elif name == "transit_timetable":
        center = here(arguments)
        kind = common.fallback(text(arguments, "type"), "departures")
        if kind not in ["departures", "arrivals"]:
            call invalid("type must be departures or arrivals")
        end
        argv = ["timetable", center, "--type", kind, "--radius", String(integer(arguments, "radius_meters", 500, 25, 2000)), "--limit", String(integer(arguments, "limit", 8, 1, 12))]
        if text(arguments, "time"):
            argv += ["--time", text(arguments, "time")]
        end
        return [argv, None]
    elif name == "current_location":
        return [["where-am-i"], None]
    elif name == "map_open":
        place = text(arguments, "place")
        start = text(arguments, "route_from")
        finish = text(arguments, "route_to")
        mode = common.fallback(text(arguments, "travel_mode"), "driving")
        if mode not in catalog.MAPS_OPEN_MODES:
            call invalid("travel_mode must be driving, walking, cycling or transit")
        end
        if start and finish:
            return [["open", "--route", start, finish, "--mode", catalog.MAPS_OPEN_MODES[mode]], None]
        end
        if place:
            return [["open", place], None]
        end
        call invalid("give place, or route_from and route_to")
    end
    call invalid("unknown map tool " + name)
end

function program(env=None):
    # jako shutil.which(PROGRAM, path=env PATH)
    path = common.fallback(common.fallback(env, {}).get("PATH"), common.environment("PATH", "/usr/local/bin:/usr/bin:/bin"))
    for folder in String(path).split(":"):
        candidate = common.join(common.fallback(folder, "."), catalog.MAPS_PROGRAM)
        info = platform.file_info(candidate)
        if info != None and info["file"] and (info["mode"] & 73) != 0:
            return candidate
        end
    end
    return None
end

function process_environment(env=None):
    if env == None:
        return child_process.environment()
    end
    return env
end

function run(argv, env=None, signal=None, timeout=None):
    executable = program(env)
    if not executable:
        return {"ok": False, "error": catalog.MAPS_NOT_INSTALLED, "maps_missing": True}
    end
    result = None
    try:
        result = child_process.run([executable, "--json"] + argv, glib.home_dir(), process_environment(env), common.fallback(timeout, catalog.MAPS_TIMEOUT), signal, None, False, False, False, False)
    else:
        return {"ok": False, "error": "LuxOS Maps could not be started: " + String(last_error())}
    end
    if result["cancelled"]:
        return {"ok": False, "cancelled": True, "error": "Stopped by the user"}
    end
    if result["timed_out"]:
        return {"ok": False, "error": "LuxOS Maps did not answer in time"}
    end
    value = None
    try:
        value = json.decode(result["output"])
    else:
        value = None
    end
    if type(value) != "Dictionary":
        detail = String(common.strip_text(common.fallback(result["stderr"], common.fallback(result["output"], ""))))[:300]
        message = "LuxOS Maps returned an invalid answer"
        if detail:
            message += ": " + detail
        end
        return {"ok": False, "error": message}
    end
    if "ok" not in value:
        value["ok"] = result["exit_code"] == 0
    end
    return value
end

function cache_dir(env=None):
    values = common.fallback(env, {})
    base = values.get("XDG_CACHE_HOME")
    if not base:
        base = common.join(common.fallback(values.get("HOME"), glib.home_dir()), ".cache")
    end
    return common.join(common.join(base, "luxai"), "maps")
end

function render(preview, env=None, signal=None):
    # PNG nahledu trasy pres luxos-maps --render-preview (v cache LuxAI); cesta nebo None
    executable = program(env)
    if not executable or type(preview) != "Dictionary":
        return None
    end
    folder = cache_dir(process_environment(env))
    try:
        call common.mkdir_private(folder)
        name = "route-" + common.random_hex(16)
        source = common.join(folder, name + ".json")
        output = common.join(folder, name + ".png")
        call platform.write_exclusive(source, common.python_json(preview))
        result = child_process.run([executable, "--render-preview", source, "--size", catalog.MAPS_PREVIEW_SIZE, "--out", output], glib.home_dir(), process_environment(env), catalog.MAPS_TIMEOUT, signal, None, False, False, False, False)
        call platform.unlink(source)
        info = platform.file_info(output)
        if result["exit_code"] == 0 and info != None and info["file"]:
            return output
        end
        return None
    else:
        return None
    end
end

function execute(name, arguments, env=None, signal=None):
    plan = None
    try:
        plan = command(name, arguments)
    else:
        problem = String(last_error())
        if problem.startswith("ValueError: "):
            problem = problem[12:]
        end
        return {"ok": False, "error": "Invalid arguments: " + problem}
    end
    result = run(plan[0], env, signal)
    if not result.get("ok"):
        if result.get("error") == "consent":
            result["note"] = catalog.MAPS_CONSENT_NOTE
        elif result.get("error") == "busy":
            result["note"] = catalog.MAPS_BUSY_NOTE
        end
        return result
    end
    preview = result.get("preview")
    result = common.without(result, "preview")
    if type(preview) == "Dictionary" and plan[1] != None:
        result["_map"] = {"preview": preview, "image": render(preview, env, signal), "open": plan[1]}
    end
    return result
end

function open_in_maps(open_arguments, env=None):
    # tlacitko "Otevrit v Mapach" na karte trasy (akce uzivatele, okno Map)
    executable = program(env)
    if not executable:
        return False
    end
    arguments = []
    for item in open_arguments:
        arguments.append(String(item))
    end
    try:
        call child_process.spawn([executable, "--json", "open"] + arguments, glib.home_dir(), process_environment(env))
        return True
    else:
        return False
    end
end

# ---- souhrn vysledku pro kartu (jako ToolPresentation v LuxAI pro telefon) ----

function tr(text):
    return i18n.translate(text)
end

function delay(value):
    if type(value) not in ["Int", "Float"] or not value:
        return ""
    end
    minutes = Int(value)
    if minutes > 0:
        return " +" + String(minutes) + " min"
    end
    return " " + String(minutes) + " min"
end

function places(results, distance):
    lines = [tr("Places found: {0}").replace("{0}", String(len(results)))]
    index = 1
    for item in results[:MAX_SUMMARY_ITEMS]:
        if type(item) != "Dictionary":
            index += 1
            continue
        end
        label = common.fallback(item.get("name"), common.fallback(item.get("address"), None))
        if not label:
            label = point(common.fallback(item.get("lat"), 0), common.fallback(item.get("lon"), 0))
        end
        line = String(index) + ". " + String(label)
        if distance and item.get("distance"):
            line += " · " + String(item["distance"])
        end
        lines.append(line)
        if item.get("address") and item.get("address") != item.get("name"):
            lines.append("   " + String(item["address"]))
        end
        index += 1
    end
    return "\n".join(lines)
end

function leg_text(leg):
    if type(leg) != "Dictionary":
        return ""
    end
    if not leg.get("transit"):
        distance = 0
        if type(leg.get("distance_m")) in ["Int", "Float"]:
            distance = Int(leg["distance_m"])
        end
        return "   " + tr("Walk {0} m").replace("{0}", String(distance))
    end
    start = {}
    if type(leg.get("from")) == "Dictionary":
        start = leg["from"]
    end
    parts = []
    for value in [leg.get("mode_name"), leg.get("line")]:
        if value:
            parts.append(String(value))
        end
    end
    output = "   " + " ".join(parts)
    if leg.get("headsign"):
        output += " → " + String(leg["headsign"])
    end
    output += " · " + String(common.fallback(leg.get("departure_time"), "")) + " " + String(common.fallback(start.get("name"), ""))
    if start.get("platform"):
        output += " (" + tr("platform {0}").replace("{0}", String(start["platform"])) + ")"
    end
    output += delay(leg.get("delay_min"))
    if leg.get("cancelled"):
        output += " · " + tr("cancelled")
    end
    return common.rstrip_text(output)
end

function mode_label(mode):
    if mode == "car":
        return tr("By car")
    elif mode == "bike":
        return tr("By bike")
    elif mode == "walk":
        return tr("On foot")
    elif mode == "transit":
        return tr("Public transport")
    end
    return tr("Route")
end

function summary(name, result):
    # citelny souhrn vysledku nastroje map pro kartu (bez suroveho JSON)
    if type(result) != "Dictionary":
        return ""
    end
    if name in ["map_geocode", "map_nearby"]:
        results = []
        if type(result.get("results")) == "List":
            results = result["results"]
        end
        if not results:
            return tr("Nothing found")
        end
        return places(results, name == "map_nearby")
    elif name == "map_reverse":
        if type(result.get("place")) != "Dictionary" or not result["place"]:
            return tr("Nothing found")
        end
        place = result["place"]
        lines = []
        first = String(common.fallback(place.get("name"), common.fallback(place.get("address"), "")))
        if first:
            lines.append(first)
        end
        if place.get("address") and place.get("address") != place.get("name"):
            lines.append(String(place["address"]))
        end
        return "\n".join(lines)
    elif name == "map_route":
        parts = []
        for value in [mode_label(result.get("mode")), String(common.fallback(result.get("distance"), "")), String(common.fallback(result.get("duration"), ""))]:
            if value:
                parts.append(value)
            end
        end
        head = " · ".join(parts)
        ends = []
        for item in [result.get("from"), result.get("to")]:
            if type(item) == "Dictionary":
                label = item.get("name")
                if not label:
                    label = point(common.fallback(item.get("lat"), 0), common.fallback(item.get("lon"), 0))
                end
                ends.append(String(label))
            end
        end
        if len(ends) == 2:
            return head + "\n" + " → ".join(ends)
        end
        return head
    elif name == "map_transit_route":
        items = []
        if type(result.get("itineraries")) == "List":
            items = result["itineraries"]
        end
        if not items:
            return tr("No connection found")
        end
        lines = [tr("Connections found: {0}").replace("{0}", String(len(items)))]
        for item in items[:MAX_SUMMARY_ITEMS]:
            if type(item) != "Dictionary":
                continue
            end
            transfers = common.fallback(item.get("transfers"), 0)
            changes = tr("direct")
            if transfers:
                changes = tr("{0} transfers").replace("{0}", String(transfers))
            end
            line = String(item.get("departure_time", "")) + " → " + String(item.get("arrival_time", "")) + " · " + String(item.get("duration", "")) + " · " + changes
            if item.get("cancelled"):
                line += " · " + tr("cancelled")
            end
            lines.append(line)
            for leg in common.fallback(item.get("legs"), []):
                value = leg_text(leg)
                if value:
                    lines.append(value)
                end
            end
        end
        return "\n".join(lines)
    elif name == "transit_timetable":
        rows = []
        if type(result.get("connections")) == "List":
            rows = result["connections"]
        end
        if not rows:
            return tr("Nothing found")
        end
        title = tr("Departures")
        if result.get("type") == "arrivals":
            title = tr("Arrivals")
        end
        stops = []
        for stop in common.fallback(result.get("stops"), [])[:3]:
            if type(stop) == "String":
                stops.append(stop)
            end
        end
        lines = [title + ": " + ", ".join(stops)]
        for row in rows[:12]:
            if type(row) != "Dictionary":
                continue
            end
            parts = []
            for value in [row.get("mode_name"), row.get("line")]:
                if value:
                    parts.append(String(value))
                end
            end
            line = String(row.get("time", "")) + "  " + " ".join(parts)
            if row.get("headsign"):
                line += " → " + String(row["headsign"])
            end
            if row.get("stop"):
                line += " · " + String(row["stop"])
            end
            if row.get("platform"):
                line += " (" + tr("platform {0}").replace("{0}", String(row["platform"])) + ")"
            end
            line += delay(row.get("delay_min"))
            if row.get("cancelled"):
                line += " · " + tr("cancelled")
            end
            lines.append(line)
        end
        return "\n".join(lines)
    elif name == "current_location":
        if type(result.get("lat")) not in ["Int", "Float"] or type(result.get("lon")) not in ["Int", "Float"]:
            return ""
        end
        output = point(result["lat"], result["lon"])
        if result.get("accuracy_m"):
            output += " · ±" + String(result["accuracy_m"]) + " m"
        end
        return output
    elif name == "map_open":
        return tr("Shown in Maps")
    end
    return ""
end

function error_text(result):
    # chyba nastroje map pro kartu (souhlas s polohou, pretizena sluzba, chybejici Mapy)
    code = ""
    if type(result) == "Dictionary":
        code = common.fallback(result.get("error"), "")
    end
    if code == "consent":
        return tr("Location is not allowed. Open Maps and click the location button once to allow it.")
    elif code == "busy":
        return tr("The map service is busy. Try again later.")
    elif code == "NoRoute":
        return tr("No connection found")
    end
    if type(result) == "Dictionary" and result.get("maps_missing"):
        return tr("LuxOS Maps is not installed (lux install luxos-maps).")
    end
    return String(code)
end
