load common
load catalog
load maps_coord
load calendar_data

function label(name):
    # nazev nastroje v karte (kalendar je jen v nativni verzi, ne v catalog.TOOL_LABELS)
    return catalog.TOOL_LABELS.get(name, calendar_data.LABELS.get(name, name))
end

function calendar_subject(name, arguments):
    if name == "calendar_list_events":
        text = String(common.fallback(arguments.get("from"), ""))
        if arguments.get("to") and String(arguments["to"]) != text:
            text += " – " + String(arguments["to"])
        end
        if arguments.get("query"):
            text += " · " + String(arguments["query"])
        end
        return text
    end
    text = String(common.fallback(arguments.get("title"), ""))
    if arguments.get("start"):
        if text:
            text += " · "
        end
        text += String(arguments["start"])
    end
    return text
end

function numbers(arguments, keys):
    # jako Python isinstance(x, (int, float)) and not bool
    for key in keys:
        if type(arguments.get(key)) not in ["Int", "Float"]:
            return False
        end
    end
    return True
end

function subject(name, arguments):
    if type(arguments) != "Dictionary":
        arguments = {}
    end
    if name in calendar_data.TOOLS:
        value = common.strip_text(calendar_subject(name, arguments)).replace("\n", " ")
        if len(value) > 140:
            value = value[:137] + "…"
        end
        return value
    end
    for key in ["command", "path", "url", "app", "pattern", "query", "keys", "text", "window", "title"]:
        if name == "send_feedback" and key != "title":
            continue
        end
        if arguments.get(key):
            value = String(arguments[key]).strip(common.WHITESPACE).replace("\n", " ⏎ ")
            if name == "move_file" and arguments.get("destination"):
                value += " → " + String(arguments["destination"])
            end
            if name == "docs_read" and arguments.get("heading"):
                value += " › " + String(arguments["heading"]).strip(common.WHITESPACE)
            end
            if len(value) > 140:
                value = value[:137] + "…"
            end
            return value
        end
    end
    if name in ["map_route", "map_transit_route"] and numbers(arguments, ["start_latitude", "start_longitude", "end_latitude", "end_longitude"]):
        return maps_coord.point(arguments["start_latitude"], arguments["start_longitude"]) + " → " + maps_coord.point(arguments["end_latitude"], arguments["end_longitude"])
    end
    if numbers(arguments, ["latitude", "longitude"]):
        return maps_coord.point(arguments["latitude"], arguments["longitude"])
    end
    if name == "map_open" and arguments.get("route_from") and arguments.get("route_to"):
        return common.strip_text(String(arguments["route_from"])) + " → " + common.strip_text(String(arguments["route_to"]))
    end
    if name == "map_open" and arguments.get("place"):
        return String(common.strip_text(String(arguments["place"])))[:140]
    end
    if "x" in arguments and "y" in arguments:
        return String(arguments["x"]) + ", " + String(arguments["y"])
    end
    if "amount" in arguments:
        return String(arguments["amount"])
    end
    return ""
end

function clip_text(text, limit):
    if len(text) <= limit:
        return text
    end
    head = limit * 2 // 3
    tail = limit - head - 80
    return text[:head] + "\n… [" + String(len(text) - head - tail) + " characters omitted] …\n" + text[len(text) - tail:]
end

function encode_result(result, limit=30000):
    clean = {}
    for key in result.keys():
        if not key.startswith("_"):
            clean[key] = result[key]
        end
    end
    raw = common.python_json(clean)
    if len(raw) <= limit:
        return raw
    end
    for key in ["output", "content", "matches", "entries", "files", "windows", "apps"]:
        if key in clean and type(clean[key]) == "String":
            over = len(raw) - limit + 200
            clean[key] = clip_text(clean[key], max(1000, len(clean[key]) - over))
            clean["truncated"] = True
        elif key in clean and type(clean[key]) == "List":
            while len(common.python_json(clean)) > limit and len(clean[key]) > 10:
                clean[key] = clean[key][:len(clean[key]) * 2 // 3]
                clean["truncated"] = True
            end
        end
    end
    raw = common.python_json(clean)
    if len(raw) > limit:
        return clip_text(raw, limit)
    end
    return raw
end
