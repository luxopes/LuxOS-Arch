# lsl: internal-abi
# Headless application lifecycle driver. All account/network state is a fixture.
load app_model
load ui_dispatch
load glib
load json
load time
load common
load store

fixture = json.decode(readfile(arg(1)))
trace = {"events": [], "switched": False, "closed": False}

function event(state, name, arguments):
    trace["events"].append(name)
    if name == "tool_confirm":
        request = arguments[0]
        if fixture.get("action") == "cancel":
            call app_model.stop(state)
        elif fixture.get("action") == "clear":
            call app_model.clear_history(state)
        elif fixture.get("action") == "close":
            call app_model.close(state)
        elif fixture.get("action") == "delete":
            call app_model.delete(state, state["conversation"]["id"])
        else:
            call app_model.confirmation_done(request, fixture.get("answer", "once"))
        end
    elif name == "stream_delta" and fixture.get("action") == "switch" and not trace["switched"]:
        trace["switched"] = True
        call app_model.new_conversation(state)
    elif name == "closed":
        trace["closed"] = True
    elif name == "finished" and fixture.get("action") == "rename":
        call app_model.rename(state, state["conversation"]["id"], "Manual title")
    end
end

call ui_dispatch.initialize(3)
state = app_model.new_model(event, fixture["account"], False)
state["mode"] = fixture.get("mode", "agent")
state["settings"]["workdir"] = fixture["cwd"]
state["settings"]["auto_title"] = fixture.get("auto_title", False)
state["settings"]["keep_history"] = fixture.get("keep_history", True)
state["settings"]["vision"] = {"flash": False, "lite": False}
initial_id = state["conversation"]["id"]
started = app_model.send(state, fixture["text"])
deadline = time.monotonic() + 12
while time.monotonic() < deadline:
    call ui_dispatch.pump()
    if state["current_run"] == None and not state["title_jobs"]:
        break
    end
    call time.sleep(0.005)
end
call ui_dispatch.pump()
rows = app_model.list_conversations(state)
saved = []
for row in rows:
    saved.append(app_model.load_conversation(state, row["id"]))
end
result = {"started": started, "running": state["current_run"] != None, "conversation": state["conversation"], "saved": saved, "events": trace["events"], "initial_id": initial_id, "switched": trace["switched"], "closed": trace["closed"]}
if state["current_run"] != None:
    call app_model.stop(state)
end
call app_model.cancel_titles(state)
call ui_dispatch.close()
for worker in ui_dispatch.queues["threads"]:
    call thread_join(worker)
end
print json.encode(result)
