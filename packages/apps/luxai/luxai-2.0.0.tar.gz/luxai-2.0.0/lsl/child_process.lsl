# lsl: internal-abi
# Linux x86_64 process boundary. posix_spawn creates a fresh session without
# executing LSL callbacks after fork. Captures use anonymous temporary files.
load common
load platform
load glib
load time

function close_fd(fd):
    if fd >= 0:
        call __lsl_qbe_call1(__lsl_symbol("close"), platform.pointer(fd))
    end
end

function environment():
    result = {}
    raw = __lsl_qbe_call0(__lsl_symbol("g_get_environ"))
    i = 0
    while raw != 0:
        item = __lsl_qbe_load64(raw + platform.pointer(i) * 8)
        if item == 0:
            break
        end
        text = glib.from_c(item)
        index = text.find("=")
        if index >= 0:
            result[text[:index]] = text[index + 1:]
        end
        i += 1
    end
    if raw != 0:
        call __lsl_qbe_call1(__lsl_symbol("g_strfreev"), raw)
    end
    return result
end

function spawn(argv, workdir, env, watch=False):
    # GLib reaps asynchronous children itself. setsid isolates the launched app.
    arguments = glib.cstr_array(["/usr/bin/setsid", "--"] + argv)
    strings = []
    for key in env.keys():
        if "\0" in key or "=" in key or "\0" in env[key]:
            Error(ProcessError: "Invalid process environment")
        end
        strings.append(key + "=" + env[key])
    end
    for argument in argv:
        if "\0" in argument:
            Error(ProcessError: "Invalid process argument")
        end
    end
    environment_array = glib.cstr_array(strings)
    pid = platform.buffer(8)
    errors = platform.buffer(8)
    flags = 28
    if watch:
        flags = 30
    end
    ok = __lsl_qbe_call8(__lsl_symbol("g_spawn_async"), platform.cstr(workdir), platform.address(arguments), platform.address(environment_array), platform.pointer(flags), 0, 0, platform.address(pid), platform.address(errors))
    if ok == 0:
        problem = __lsl_qbe_load64(platform.address(errors))
        message = "Cannot launch application"
        if problem != 0:
            message = glib.from_c(__lsl_qbe_load64(problem + 8))
            call __lsl_qbe_call1(__lsl_symbol("g_error_free"), problem)
        end
        Error(ProcessError: message)
    end
    return __lsl_qbe_load32(platform.address(pid))
end

function new_signal():
    signal = IntArray()
    signal.append(0)
    return signal
end

function cancelled(signal):
    target = IntArray(signal)
    return atomic_add(target, 0, 0) != 0
end

function cancel(signal):
    target = IntArray(signal)
    call atomic_xchg(target, 0, 1)
end

function reset(signal):
    target = IntArray(signal)
    call atomic_xchg(target, 0, 0)
end

function error_text(code):
    return glib.from_c(__lsl_qbe_call1(__lsl_symbol("strerror"), platform.pointer(code)))
end

function anonymous_file():
    handle = __lsl_qbe_call0(__lsl_symbol("tmpfile"))
    if handle == 0:
        Error(ProcessError: "Cannot create command capture")
    end
    call __lsl_qbe_call3(__lsl_symbol("fcntl"), platform.pointer(file_fd(handle)), 2, 1)
    return handle
end

function file_fd(handle):
    return __lsl_qbe_s32(__lsl_qbe_call1(__lsl_symbol("fileno"), platform.pointer(handle)))
end

function read_capture(handle, limit):
    data = platform.buffer(limit)
    fd = file_fd(handle)
    offset = 0
    while offset < limit:
        count = __lsl_qbe_call4(__lsl_symbol("pread"), platform.pointer(fd), platform.address(data) + platform.pointer(offset), platform.pointer(limit - offset), platform.pointer(offset))
        if count <= 0:
            break
        end
        offset += count
    end
    return data[:offset]
end

function poll_child(pid):
    status = platform.buffer(4)
    result = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("waitpid"), platform.pointer(pid), platform.address(status), 1))
    if result == 0:
        return {"done": False, "code": 0}
    end
    if result < 0:
        return {"done": False, "code": 0}
    end
    value = __lsl_qbe_load32(platform.address(status))
    if (value & 127) == 0:
        return {"done": True, "code": (value >> 8) & 255}
    end
    return {"done": True, "code": -(value & 127)}
end

function stdin_is_pipe():
    data = platform.buffer(144)
    result = __lsl_qbe_call2(__lsl_symbol("fstat"), 0, platform.address(data))
    if result != 0:
        return False
    end
    kind = __lsl_qbe_load32(platform.address(data) + 24) & 61440
    return kind in [4096, 49152]
end

function stdin_closed():
    descriptor = platform.buffer(8)
    call __lsl_qbe_store32(platform.address(descriptor), 0)
    # pollfd: int fd; short events; short revents (POLLIN|POLLHUP).
    descriptor[4] = 17
    ready = __lsl_qbe_s32(__lsl_qbe_call3(__lsl_symbol("poll"), platform.address(descriptor), 1, 0))
    if ready <= 0:
        return False
    end
    chunk = platform.buffer(4096)
    count = __lsl_qbe_call3(__lsl_symbol("read"), 0, platform.address(chunk), 4096)
    return count == 0
end

function run(argv, workdir, env=None, timeout=120, signal=None, input_text=None, keep_stdin=False, passthrough=False, watch_stdin=False, merge=True, capture_limit=2097152):
    directory = String(common.fallback(workdir, platform.current_dir()))
    if not argv:
        Error(ProcessError: "Empty argument vector")
    end
    for argument in argv:
        if type(argument) != "String" or "\0" in argument:
            Error(ProcessError: "Invalid process argument")
        end
    end
    if "\0" in directory:
        Error(ProcessError: "Invalid working directory")
    end
    if env == None:
        env = environment()
    end
    env_list = []
    for key in env.keys():
        if type(key) != "String" or not key or "=" in key or "\0" in key or type(env[key]) != "String" or "\0" in env[key]:
            Error(ProcessError: "Invalid process environment")
        end
        env_list.append(key + "=" + env[key])
    end
    if signal == None:
        signal = new_signal()
    end
    if cancelled(signal):
        return {"exit_code": 130, "output": "", "stderr": "", "truncated": False, "cancelled": True, "timed_out": False, "duration_s": 0.0, "pid": 0}
    end
    output_file = 0
    error_file = 0
    input_read = -1
    input_write = -1
    actions = platform.buffer(1024)
    attributes = platform.buffer(1024)
    call __lsl_qbe_call1(__lsl_symbol("posix_spawn_file_actions_init"), platform.address(actions))
    call __lsl_qbe_call1(__lsl_symbol("posix_spawnattr_init"), platform.address(attributes))
    # Closed child input must report EPIPE instead of terminating the application.
    # Restore SIGPIPE's default disposition in spawned commands (as Python does).
    call __lsl_qbe_call2(__lsl_symbol("signal"), 13, 1)
    defaults = platform.buffer(128)
    call __lsl_qbe_call1(__lsl_symbol("sigemptyset"), platform.address(defaults))
    call __lsl_qbe_call2(__lsl_symbol("sigaddset"), platform.address(defaults), 13)
    call __lsl_qbe_call2(__lsl_symbol("posix_spawnattr_setsigdefault"), platform.address(attributes), platform.address(defaults))
    # glibc POSIX_SPAWN_SETSID | POSIX_SPAWN_SETSIGDEF.
    call __lsl_qbe_call2(__lsl_symbol("posix_spawnattr_setflags"), platform.address(attributes), 132)
    status = __lsl_qbe_call2(__lsl_symbol("posix_spawn_file_actions_addchdir_np"), platform.address(actions), platform.cstr(directory))
    if input_text != None or keep_stdin:
        ends = platform.buffer(8)
        pipe_status = __lsl_qbe_call2(__lsl_symbol("pipe2"), platform.address(ends), 524288)
        if pipe_status != 0:
            call __lsl_qbe_call1(__lsl_symbol("posix_spawn_file_actions_destroy"), platform.address(actions))
            call __lsl_qbe_call1(__lsl_symbol("posix_spawnattr_destroy"), platform.address(attributes))
            Error(ProcessError: "Cannot create command input")
        end
        input_read = __lsl_qbe_load32(platform.address(ends))
        input_write = __lsl_qbe_load32(platform.address(ends) + 4)
        call __lsl_qbe_call3(__lsl_symbol("posix_spawn_file_actions_adddup2"), platform.address(actions), platform.pointer(input_read), 0)
        call __lsl_qbe_call3(__lsl_symbol("fcntl"), platform.pointer(input_write), 4, 2048)
    else:
        call __lsl_qbe_call5(__lsl_symbol("posix_spawn_file_actions_addopen"), platform.address(actions), 0, platform.cstr("/dev/null"), 0, 0)
    end
    if not passthrough:
        output_file = anonymous_file()
        call __lsl_qbe_call3(__lsl_symbol("posix_spawn_file_actions_adddup2"), platform.address(actions), platform.pointer(file_fd(output_file)), 1)
        if merge:
            call __lsl_qbe_call3(__lsl_symbol("posix_spawn_file_actions_adddup2"), platform.address(actions), platform.pointer(file_fd(output_file)), 2)
        else:
            error_file = anonymous_file()
            call __lsl_qbe_call3(__lsl_symbol("posix_spawn_file_actions_adddup2"), platform.address(actions), platform.pointer(file_fd(error_file)), 2)
        end
    end
    arguments = glib.cstr_array(argv)
    env_array = glib.cstr_array(env_list)
    pid_slot = platform.buffer(4)
    status = __lsl_qbe_call6(__lsl_symbol("posix_spawnp"), platform.address(pid_slot), platform.cstr(argv[0]), platform.address(actions), platform.address(attributes), platform.address(arguments), platform.address(env_array))
    call __lsl_qbe_call1(__lsl_symbol("posix_spawn_file_actions_destroy"), platform.address(actions))
    call __lsl_qbe_call1(__lsl_symbol("posix_spawnattr_destroy"), platform.address(attributes))
    call close_fd(input_read)
    if status != 0:
        call close_fd(input_write)
        if output_file != 0:
            call __lsl_qbe_call1(__lsl_symbol("fclose"), platform.pointer(output_file))
        end
        if error_file != 0:
            call __lsl_qbe_call1(__lsl_symbol("fclose"), platform.pointer(error_file))
        end
        Error(ProcessError: error_text(status))
    end
    pid = __lsl_qbe_load32(platform.address(pid_slot))
    started = time.monotonic()
    interrupted = False
    timed_out = False
    stopped_at = None
    forced = False
    code = None
    input_offset = 0
    input_length = 0
    if input_text != None:
        input_length = platform.byte_length(input_text)
    end
    watch_stdin = watch_stdin and stdin_is_pipe()
    while code == None:
        polled = poll_child(pid)
        if polled["done"]:
            code = polled["code"]
            break
        end
        if stopped_at == None:
            interrupted = cancelled(signal) or (watch_stdin and stdin_closed())
            timed_out = time.monotonic() - started > Float(timeout)
            if interrupted or timed_out:
                call close_fd(input_write)
                input_write = -1
                call platform.kill_group(pid, 15)
                stopped_at = time.monotonic()
            end
        elif time.monotonic() - stopped_at >= 2.0 and not forced:
            call platform.kill_group(pid, 9)
            forced = True
        elif time.monotonic() - stopped_at >= 7.0:
            break
        end
        if input_write >= 0 and input_text != None and input_offset < input_length:
            count = __lsl_qbe_call3(__lsl_symbol("write"), platform.pointer(input_write), platform.cstr(input_text) + platform.pointer(input_offset), platform.pointer(min(65536, input_length - input_offset)))
            if count > 0:
                input_offset += count
            end
        end
        if input_write >= 0 and input_text != None and input_offset >= input_length and not keep_stdin:
            call close_fd(input_write)
            input_write = -1
        end
        call time.sleep(0.02)
    end
    # If TERM ended the leader but descendants ignored it, terminate the group
    # before releasing captures. No unrelated process can join this session.
    if stopped_at != None:
        call platform.kill_group(pid, 9)
    end
    call close_fd(input_write)
    text = ""
    errors = ""
    truncated = False
    if output_file != 0:
        data = read_capture(output_file, capture_limit + 1)
        truncated = len(data) > capture_limit
        text = platform.utf8_decode(data[:capture_limit])
        call __lsl_qbe_call1(__lsl_symbol("fclose"), platform.pointer(output_file))
    end
    if error_file != 0:
        data = read_capture(error_file, capture_limit + 1)
        errors = platform.utf8_decode(data[:capture_limit])
        call __lsl_qbe_call1(__lsl_symbol("fclose"), platform.pointer(error_file))
    end
    return {"exit_code": code, "output": text, "stderr": errors, "truncated": truncated, "cancelled": interrupted, "timed_out": timed_out, "duration_s": Int((time.monotonic() - started) * 100 + 0.5) / 100.0, "pid": pid}
end
