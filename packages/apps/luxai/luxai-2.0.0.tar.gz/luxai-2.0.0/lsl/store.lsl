load common
load protocol
load glib
load process
load time

IMAGE_REF = "luxai-image:"
IMAGE_MISSING = "[image no longer available]"
IMAGE_TYPES = {"image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif"}

function data_dir():
    return common.join(common.environment("XDG_DATA_HOME", common.join(glib.home_dir(), ".local/share")), "luxai")
end

function title_from(text, limit=48):
    clean = common.words(common.text(text))
    for char in "#*`_>[]":
        clean = clean.replace(char, "")
    end
    clean = clean.strip(common.WHITESPACE)
    if len(clean) <= limit:
        return clean
    end
    cut = clean[:limit - 1]
    if " " in cut[limit // 2:]:
        cut = cut[:common.rfind(cut, " ")]
    end
    return cut.rstrip(" ,.;:-") + "…"
end

function valid_image_name(name):
    parts = name.split(".")
    if len(parts) != 2 or len(parts[0]) < 8 or len(parts[0]) > 64 or parts[1] not in ["jpg", "png", "webp", "gif"]:
        return False
    end
    return common.identifier(parts[0], 64, "0123456789abcdef")
end

function strip_images(messages):
    output = []
    for original in messages:
        if original.get("_transient"):
            continue
        end
        message = common.copy(original)
        if type(message.get("content")) == "List":
            parts = []
            for part in message["content"]:
                if type(part) == "Dictionary" and part.get("type") == "image_url":
                    parts.append({"type": "text", "text": "[image omitted]"})
                else:
                    parts.append(part)
                end
            end
            message["content"] = parts
        end
        output.append(message)
    end
    return output
end

function save_image(url, folder):
    if url.startswith(IMAGE_REF) and valid_image_name(url[len(IMAGE_REF):]):
        return url[len(IMAGE_REF):]
    end
    separator = url.find(",")
    if separator < 0:
        return None
    end
    header = url[:separator]
    mime = header[5:].split(";")[0]
    if not header.startswith("data:") or not header.endswith(";base64") or mime not in IMAGE_TYPES:
        return None
    end
    temporary = ""
    try:
        bytes = common.base64_decode(url[separator + 1:])
        if len(bytes) == 0:
            return None
        end
        # Hash binary bytes, not a lossy UTF-8 representation.
        temporary = common.temp_private(folder)
        call writebytes(temporary, bytes)
        checksum = process.check("/usr/bin/sha256sum", ["--", temporary]).split()[0]
        name = checksum[:32] + "." + IMAGE_TYPES[mime]
        destination = common.join(folder, name)
        if exists(destination):
            call common.remove_file(temporary)
        else:
            call process.check("/usr/bin/mv", ["-fT", "--", temporary, destination])
        end
        return name
    else:
        if exists(temporary):
            call common.remove_file(temporary)
        end
        return None
    end
end

function externalize_images(messages, folder):
    output = []
    keep = []
    for original in messages:
        if original.get("_transient"):
            continue
        end
        message = common.copy(original)
        if type(message.get("content")) == "List":
            parts = []
            for part in message["content"]:
                if type(part) == "Dictionary" and part.get("type") == "image_url":
                    name = save_image(protocol.image_part_url(part), folder)
                    if name:
                        keep.append(name)
                        parts.append({"type": "image_url", "image_url": {"url": IMAGE_REF + name}})
                    else:
                        parts.append({"type": "text", "text": "[image omitted]"})
                    end
                else:
                    parts.append(part)
                end
            end
            message["content"] = parts
        end
        output.append(message)
    end
    if exists(folder):
        for name in listdir(folder):
            if valid_image_name(name) and name not in keep:
                call common.remove_file(common.join(folder, name))
            end
        end
    end
    return output
end

function internalize_images(messages, folder):
    mimes = {"jpg": "image/jpeg", "png": "image/png", "webp": "image/webp", "gif": "image/gif"}
    for message in messages:
        content = message.get("content")
        if type(content) != "List":
            continue
        end
        for index in rang(len(content)):
            part = content[index]
            if type(part) != "Dictionary" or part.get("type") != "image_url":
                continue
            end
            url = protocol.image_part_url(part)
            if url.startswith("data:image/"):
                continue
            end
            name = ""
            if url.startswith(IMAGE_REF):
                name = url[len(IMAGE_REF):]
            end
            restored = None
            if valid_image_name(name):
                try:
                    bytes = readbytes(common.join(folder, name))
                    if len(bytes) > 0:
                        restored = "data:" + mimes[name.split(".")[1]] + ";base64," + common.base64_encode(bytes)
                    end
                else:
                    restored = None
                end
            end
            if restored:
                content[index] = {"type": "image_url", "image_url": {"url": restored}}
            else:
                content[index] = {"type": "text", "text": IMAGE_MISSING}
            end
        end
    end
    return messages
end

function conversation_empty(conversation):
    for message in conversation["messages"]:
        if message.get("role") == "user":
            return False
        end
    end
    return True
end

function first_user_text(conversation):
    for message in conversation["messages"]:
        if message.get("role") == "user" and not message.get("_screenshot") and not message.get("_transient"):
            text = protocol.message_text(message)
            if common.strip_text(text):
                return text
            end
        end
    end
    return ""
end

function display_title(conversation):
    return common.fallback(conversation["title"], title_from(first_user_text(conversation)))
end

function to_dict(conversation, image_dir=None):
    messages = []
    if image_dir:
        messages = externalize_images(conversation["messages"], image_dir)
    else:
        messages = strip_images(conversation["messages"])
    end
    messages = protocol.repair_tool_sequence(messages, None, protocol.INTERRUPTED)[0]
    return {"version": 1, "id": conversation["id"], "title": conversation["title"], "title_source": conversation["title_source"], "mode": conversation["mode"], "model": conversation["model"], "created": conversation["created"], "updated": conversation["updated"], "messages": messages}
end

function Conversation(cid=None, title="", mode="chat", model="flash", messages=None, created=None, updated=None, title_source="fallback"):
    id = cid
    if not id:
        id = glib.date_time_format("%Y%m%d-%H%M%S-") + common.random_hex(6)
    end
    if title_source not in ["fallback", "model", "manual"]:
        title_source = "fallback"
    end
    created = common.fallback(created, time.time())
    return {"id": id, "title": title, "title_source": title_source, "mode": mode, "model": model, "messages": common.fallback(messages, []), "created": created, "updated": common.fallback(updated, created)}
end

function from_dict(data):
    if type(data) != "Dictionary":
        Error(ValueError: "Conversation must be an object")
    end
    messages = []
    if type(data.get("messages")) == "List":
        for message in data["messages"]:
            if type(message) == "Dictionary" and message.get("role") in ["user", "assistant", "tool", "system"]:
                messages.append(message)
            end
        end
    end
    mode = "chat"
    if data.get("mode") in ["chat", "agent"]:
        mode = data["mode"]
    end
    conversation = Conversation(String(data.get("id")), common.text(common.fallback(data.get("title"), "")), mode, String(common.fallback(data.get("model"), "flash")), messages, data.get("created"), data.get("updated"), data.get("title_source"))
    if data.get("title_source") not in ["fallback", "model", "manual"]:
        conversation["title_source"] = "manual"
        if not conversation["title"] or conversation["title"] == title_from(first_user_text(conversation)):
            conversation["title_source"] = "fallback"
        end
    end
    return conversation
end

class Store:
    ctype Public

    function init(self, root=None):
        self.root = common.fallback(root, common.join(data_dir(), "conversations"))
        self.images_root = common.join(common.dirname(self.root), "images")
    end

    function path(self, cid):
        if not common.identifier(cid):
            Error(ValueError: "invalid conversation id")
        end
        return common.join(self.root, cid + ".json")
    end

    function image_dir(self, cid):
        if not common.identifier(cid):
            Error(ValueError: "invalid conversation id")
        end
        return common.join(self.images_root, cid)
    end

    function save(self, conversation, touch=True):
        if conversation_empty(conversation):
            return False
        end
        if touch or not conversation["updated"]:
            conversation["updated"] = time.time()
        end
        if not conversation["title"]:
            conversation["title"] = display_title(conversation)
        end
        call common.mkdir_private(self.images_root)
        call common.atomic_json(self.path(conversation["id"]), to_dict(conversation, self.image_dir(conversation["id"])))
        return True
    end

    function load(self, cid):
        conversation = from_dict(common.read_json(self.path(cid)))
        call internalize_images(conversation["messages"], self.image_dir(cid))
        return conversation
    end

    function delete(self, cid):
        path = self.path(cid)
        # chyby mazani se ignoruji jako v Pythonu (OSError)
        try:
            call process.check("/usr/bin/rm", ["-rf", "--", self.image_dir(cid)])
        else:
            call common.text("")
        end
        if exists(path):
            try:
                call common.remove_file(path)
                return True
            else:
                return False
            end
        end
        return False
    end

    function clear(self):
        try:
            call process.check("/usr/bin/rm", ["-rf", "--", self.images_root])
        else:
            call common.text("")
        end
        count = 0
        if exists(self.root):
            for name in listdir(self.root):
                if name.endswith(".json") and common.identifier(name[:len(name) - 5]):
                    try:
                        call common.remove_file(common.join(self.root, name))
                        count += 1
                    else:
                        continue
                    end
                end
            end
        end
        return count
    end

    function list(self):
        output = []
        if not exists(self.root):
            return output
        end
        for name in listdir(self.root):
            if not name.endswith(".json") or not common.identifier(name[:len(name) - 5]):
                continue
            end
            try:
                conversation = from_dict(common.read_json(common.join(self.root, name)))
                row = {"id": conversation["id"], "title": common.fallback(display_title(conversation), "…"), "mode": conversation["mode"], "model": conversation["model"], "updated": common.fallback(conversation["updated"], 0)}
                index = 0
                while index < len(output) and output[index]["updated"] >= row["updated"]:
                    index += 1
                end
                output = output[:index] + [row] + output[index:]
            else:
                continue
            end
        end
        return output
    end
end
