load api
load common
load catalog
load platform
load protocol
load store
load i18n
load time

MAX_ATTEMPTS = 3

function fallback_title(text):
    return store.title_from(text, 48)
end

function smalltalk(text):
    text = common.text(text).lower()
    for char in "!?.,;:👋🙂😊":
        text = text.replace(char, " ")
    end
    return common.words(text) in catalog.SMALLTALK
end

function topic(messages):
    for index in rang(len(messages)):
        message = messages[index]
        if message.get("role") != "user" or message.get("_transient") or message.get("_screenshot"):
            continue
        end
        text = common.words(protocol.message_text(message))
        names = []
        for attachment in common.fallback(message.get("_attachments"), []):
            if type(attachment) == "Dictionary":
                names.append(common.fallback(common.text(attachment.get("name")).strip(common.WHITESPACE), i18n.translate("Pasted image")))
            end
        end
        if text and not smalltalk(text):
            if names:
                return [index, text + "\n[Attached: " + ", ".join(names) + "]", text]
            end
            return [index, protocol.message_text(message), text]
        end
        if names:
            prompt = ""
            if text:
                prompt = text + "\n"
            end
            prompt += "[Attached: " + ", ".join(names) + "]"
            return [index, prompt, ", ".join(names)]
        end
    end
    return None
end

function topic_text(messages):
    value = topic(messages)
    if value != None:
        return value[1]
    end
    return ""
end

function answer_after(messages, index, limit=600):
    output = []
    size = 0
    for message in messages[index + 1:]:
        if message.get("role") == "user" and not message.get("_screenshot") and not message.get("_transient"):
            break
        end
        if message.get("role") == "assistant" and type(message.get("content")) == "String" and common.strip_text(message["content"]):
            text = common.strip_text(message["content"])
            output.append(text)
            size += len(text)
            if size >= limit:
                break
            end
        end
    end
    return "\n".join(output)[:limit]
end

function clean_title(value, fallback=""):
    text = String(common.strip_text(common.text(value))).split("\n")[0]
    text = platform.regex_replace("(?i)^\\s*(název|nazev|title|titulek)\\s*:\\s*", "", text)
    text = platform.regex_replace("[*_`#<>\\[\\]]", "", text)
    text = platform.regex_replace("^[\\s'\"„“”‚‘’«»-]+|[\\s'\"„“”‚‘’«».!?:;,-]+$", "", text)
    text = common.words(text)
    if len(text) > 42:
        cut = text[:42]
        if " " in cut[21:]:
            cut = cut[:common.rfind(cut, " ")]
        end
        text = cut.rstrip(" ,.;:-")
    end
    if len(text) < 2 or text.lower() in catalog.GENERIC_TITLES:
        return fallback
    end
    return text
end

function title_request(user_text, answer_text=""):
    content = "User's first message:\n<<<\n" + String(user_text)[:2000] + "\n>>>"
    if answer_text:
        content += "\nBeginning of the assistant's answer:\n<<<\n" + String(answer_text)[:600] + "\n>>>"
    end
    content += "\nReturn only the title."
    return {"model": "lite", "max_tokens": 48, "messages": [{"role": "system", "content": catalog.TITLE_PROMPT}, {"role": "user", "content": content}]}
end

function generate_title(client, user_text, answer_text="", should_stop=None, retries=1):
    attempt = 0
    model = "lite"
    loop:
        if api.is_cancelled(client) or (should_stop != None and should_stop()):
            call api.raise_error(api.error("cancelled"))
        end
        try:
            body = title_request(user_text, answer_text)
            body["model"] = model
            response = api.chat_stream(client, body, None, should_stop, 30)
            title = clean_title(response[0].get("content"))
            if not title:
                call api.raise_error(api.error("bad_response", 200, "empty title"))
            end
            return title
        else:
            problem = api.caught_error(String(last_error()))
            if api.is_auth(problem) or attempt >= retries or api.is_cancelled(client) or (should_stop != None and should_stop()):
                call api.raise_error(problem)
            end
            attempt += 1
            if problem["code"] == "monthly_limit":
                # jako Python: s modelem flash hned, bez cekani
                model = "flash"
                continue
            end
            duration = 1.0
            if problem["code"] in ["chat_busy", "chat_rate", "rate"]:
                duration = 2.0
            end
            ticks = Int(duration * 20)
            for tick in rang(ticks):
                if api.is_cancelled(client) or (should_stop != None and should_stop()):
                    call api.raise_error(api.error("cancelled"))
                end
                call time.sleep(0.05)
            end
        end
    end
end
