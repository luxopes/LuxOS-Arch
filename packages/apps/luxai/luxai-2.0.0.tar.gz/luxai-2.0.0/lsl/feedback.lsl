load api
load common
load catalog
load glib
load platform
load process
load transport
load json
load i18n
load time
load version

SHOT_WIDTH = 1280
SHOT_MAX = 1400000

function outbox_dir():
    return common.join(common.environment("XDG_DATA_HOME", common.join(glib.home_dir(), ".local/share")), "luxos/feedback-outbox")
end

function identity():
    home = glib.home_dir()
    parts = home.split("/")
    return [home, common.environment("USER", parts[len(parts) - 1]), glib.host_name()]
end

function redact(text, home=None, user=None, host=None):
    who = identity()
    home = common.fallback(home, who[0])
    user = common.fallback(user, who[1])
    host = common.fallback(host, who[2])
    text = text.replace(home, "~")
    text = platform.regex_replace(catalog.FEEDBACK_RE_EMAIL, "<email>", text)
    text = platform.regex_replace(catalog.FEEDBACK_RE_SECRET, "\\1\\2<redacted>", text)
    text = platform.regex_replace(catalog.FEEDBACK_RE_LONG, "<redacted>", text)
    text = platform.regex_replace(catalog.FEEDBACK_RE_MAC, "<mac>", text)
    text = platform.regex_replace(catalog.FEEDBACK_RE_IP, "<ip>", text)
    for entry in [[user, "<user>"], [host, "<host>"]]:
        if len(entry[0]) >= 3:
            text = platform.regex_replace("(?<![\\w-])" + platform.regex_escape(entry[0]) + "(?![\\w-])", entry[1], text)
        end
    end
    return text
end

function log_lines(text, n=50, home=None, user=None, host=None):
    lines = []
    for line in common.splitlines(text):
        if line.strip(common.WHITESPACE) and not line.startswith("-- "):
            lines.append(redact(line, home, user, host)[:300])
        end
    end
    return lines[max(0, len(lines) - n):]
end

function run_command(arguments, timeout=8):
    try:
        result = process.capture_result("/usr/bin/timeout", [String(timeout)] + arguments)
        if result["status"] == 0:
            return common.strip_text(result["stdout"])
        end
    else:
        return ""
    end
    return ""
end

function read_file(path):
    try:
        return common.strip_text(String(platform.utf8_decode(readbytes(path))).replace("\r\n", "\n").replace("\r", "\n"))
    else:
        return ""
    end
end

function collect_run(context, arguments, timeout=8):
    if context.get("run") != None:
        return context["run"](context, arguments, timeout)
    end
    return run_command(arguments, timeout)
end

function collect_read(context, path):
    if context.get("read") != None:
        return context["read"](context, path)
    end
    return read_file(path)
end

function shrink_system(info, limit=30000):
    while platform.byte_length(common.python_json(info)) > limit:
        longest = "userErrors"
        for key in ["systemErrors", "xsessionErrors"]:
            if len(common.fallback(info.get(key), [])) > len(common.fallback(info.get(longest), [])):
                longest = key
            end
        end
        if not info.get(longest):
            break
        end
        info[longest] = info[longest][len(info[longest]) // 2 + 1:]
    end
    return info
end

function collect_system(context=None, environment=None):
    context = common.fallback(context, {})
    if environment == None:
        environment = {"XDG_CURRENT_DESKTOP": glib.getenv("XDG_CURRENT_DESKTOP"), "XDG_SESSION_TYPE": glib.getenv("XDG_SESSION_TYPE"), "LANG": glib.getenv("LANG")}
    end
    home = glib.home_dir()
    os_release = {}
    for line in common.splitlines(collect_read(context, "/etc/os-release")):
        if "=" in line:
            position = line.find("=")
            os_release[line[:position]] = line[position + 1:].strip("\"")
        end
    end
    memory = platform.regex_findall("MemTotal:\\s+(\\d+)", collect_read(context, "/proc/meminfo"))
    cpu = platform.regex_findall("model name\\s*:\\s*(.+)", collect_read(context, "/proc/cpuinfo"))
    gpu = []
    for line in common.splitlines(collect_run(context, ["lspci"])):
        if platform.regex_test("VGA|3D|Display", line):
            position = line.find(": ")
            if position >= 0:
                line = line[position + 2:]
            end
            gpu.append(platform.regex_replace(" \\(rev .*\\)$", "", line))
        end
    end
    packages = {}
    engine = "/usr/lib/lux/alpm/bin/lux-engine"
    if not glib.find_program_in_path(engine):
        engine = "pacman"
    end
    for line in common.splitlines(collect_run(context, [engine, "-Q"])):
        position = line.find(" ")
        name = line
        version = ""
        if position >= 0:
            name = line[:position]
            version = line[position + 1:]
        end
        if platform.regex_test("^(luxos|lux$|lux-|luxai|lsl|linux$|linux-lts$|linux-zen$|linux-luxos$|mesa$|xorg-server$|xfce4-session$)", name):
            packages[name] = version
        end
    end
    uptime = 0
    try:
        first = common.split_words(common.fallback(collect_read(context, "/proc/uptime"), "0"))[0]
        uptime = Int(Float(first) / 60)
    else:
        uptime = 0
    end
    facts = context.get("facts")
    if facts == None:
        facts = platform.system_facts()
    end
    # jako Python: neprazdne casti spojene mezerou, u CPU jen sloucene bile znaky
    parts = []
    for part in [collect_read(context, "/sys/class/dmi/id/sys_vendor"), collect_read(context, "/sys/class/dmi/id/product_name")]:
        if part:
            parts.append(part)
        end
    end
    computer = " ".join(parts)
    model_name = ""
    if cpu:
        model_name = platform.regex_replace("\\s+", " ", String(cpu[0]["groups"][1]))
    end
    memory_gb = 0
    if memory:
        memory_gb = Int(Int(memory[0]["groups"][1]) / 1024.0 / 1024.0 * 10 + 0.5) / 10.0
    end
    session = []
    for key in ["XDG_CURRENT_DESKTOP", "XDG_SESSION_TYPE"]:
        if environment.get(key):
            session.append(environment[key])
        end
    end
    info = {"os": os_release.get("PRETTY_NAME", "LuxOS"), "osBuild": common.fallback(os_release.get("BUILD_ID"), common.fallback(os_release.get("VERSION_ID"), "")), "kernel": facts["kernel"], "computer": computer, "cpu": model_name, "cpuCores": facts["cpuCores"], "gpu": gpu[:3], "memoryGB": memory_gb, "diskFreeGB": facts["diskFreeGB"], "session": " ".join(session), "language": environment.get("LANG", ""), "uptimeMin": uptime, "packages": packages, "userErrors": log_lines(collect_run(context, ["journalctl", "--user", "-b", "-p", "err", "-n", "50", "--no-pager", "-o", "short"], 10)), "systemErrors": log_lines(collect_run(context, ["journalctl", "-b", "-p", "err", "-n", "50", "--no-pager", "-o", "short"], 10)), "xsessionErrors": log_lines(collect_read(context, common.join(home, ".xsession-errors")))}
    filtered = []
    for line in info["systemErrors"]:
        if line not in info["userErrors"]:
            filtered.append(line)
        end
    end
    info["systemErrors"] = filtered
    return shrink_system(info)
end

function compose_message(title, description):
    title = common.words(common.text(title)).strip(common.WHITESPACE)
    description = common.strip_text(common.text(description))
    if title and description:
        return title + "\n\n" + description
    end
    return common.fallback(title, description)
end

function build_payload(kind, title, description, contact=None, system=None, screenshot=None):
    kind = common.text(kind).strip(common.WHITESPACE).lower()
    if kind not in ["bug", "idea", "other"]:
        Error(FeedbackError: "kind must be one of: bug, idea, other")
    end
    message = redact(compose_message(title, description))
    if len(message) < 10:
        Error(FeedbackError: "The report text is too short (at least 10 characters).")
    end
    if len(message) > 8000:
        Error(FeedbackError: "The report text is too long (" + String(len(message)) + " characters, at most 8000). Shorten the description.")
    end
    payload = {"kind": kind, "message": message, "app": "luxai", "version": version.VERSION}
    contact = common.text(contact).strip(common.WHITESPACE)
    if contact:
        if not platform.regex_test("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$", contact):
            Error(FeedbackError: "contact_email does not look like a valid e-mail address")
        end
        payload["contact"] = contact
    end
    if system != None:
        payload["system"] = system
    end
    if screenshot:
        if not String(screenshot).startswith("data:image/"):
            Error(FeedbackError: "invalid screenshot")
        end
        payload["screenshot"] = screenshot
    end
    return payload
end

function describe(payload):
    return {"kind": payload.get("kind"), "message": payload.get("message", ""), "contact": payload.get("contact", ""), "system": payload.get("system"), "screenshot_bytes": len(common.fallback(payload.get("screenshot"), ""))}
end

function post(payload, token=None, origin=None, timeout=45, should_stop=None, callback_state=None):
    origin = api.safe_origin(common.fallback(origin, common.environment("LUXAI_ORIGIN", api.DEFAULT_ORIGIN)))
    headers = {"X-Lux-Client": "luxos", "User-Agent": "luxai/" + version.VERSION, "Accept": "application/json", "Content-Type": "application/json"}
    if token:
        headers["Cookie"] = "lux_account_session=" + token
    end
    response = transport.request("POST", origin + "/api/feedback", headers, json.encode(payload), timeout, None, should_stop, 65536, None, callback_state)
    if response["status"] == 429:
        problem = api.error_from_response(429, response["text"])
        if problem["code"].startswith("http_"):
            problem = api.error("rate", 429)
        end
        call api.raise_error(problem)
    end
    call api.validate_response(response)
    if not common.strip_text(response["text"]):
        return {}
    end
    output = None
    try:
        output = json.decode(response["text"])
    else:
        call api.raise_error(api.error("bad_response", response["status"]))
    end
    if type(output) != "Dictionary":
        return {}
    end
    return output
end

function send(payload, token=None, origin=None, timeout=45, should_stop=None, callback_state=None):
    for attempt in rang(2):
        try:
            return String(common.fallback(post(payload, token, origin, timeout, should_stop, callback_state).get("id"), ""))
        else:
            problem = api.caught_error(String(last_error()))
            retry = problem["code"] in ["network", "timeout"] or problem["status"] >= 500
            stopped = False
            if should_stop != None:
                if callback_state == None:
                    stopped = should_stop()
                else:
                    stopped = should_stop(callback_state)
                end
            end
            if attempt == 1 or not retry or stopped:
                call api.raise_error(problem)
            end
            for tick in rang(40):
                if should_stop != None:
                    if callback_state == None:
                        stopped = should_stop()
                    else:
                        stopped = should_stop(callback_state)
                    end
                    if stopped:
                        call api.raise_error(api.error("cancelled"))
                    end
                end
                call time.sleep(0.05)
            end
        end
    end
    return ""
end

function can_save(problem):
    return type(problem) == "Dictionary" and (problem.get("code") in ["network", "timeout", "unavailable"] or problem.get("status", 0) >= 500)
end

function save_outbox(payload):
    folder = outbox_dir()
    call common.mkdir_private(folder)
    path = common.join(folder, glib.date_time_format("%Y%m%d-%H%M%S-") + common.random_hex(8) + ".json")
    call platform.write_exclusive(path, common.python_json(payload))
    return path
end

function human_error(problem):
    code = problem.get("code", "")
    if code in catalog.FEEDBACK_ERRORS:
        return i18n.translate(catalog.FEEDBACK_ERRORS[code])
    end
    if code in ["network", "timeout"]:
        return i18n.translate("LuxOS could not reach the server. Check the internet connection.")
    end
    if api.is_auth(problem):
        return api.human(problem)
    end
    return i18n.translate("Sending failed ({0}).").replace("{0}", String(common.fallback(code, problem.get("status", ""))))
end

function account_for(client=None):
    if client != None and client.get("origin"):
        return [common.fallback(client.get("token"), None), client["origin"]]
    end
    account = common.fallback(api.load_account(), {})
    origin = api.safe_origin(common.environment("LUXAI_ORIGIN", common.fallback(account.get("origin"), api.DEFAULT_ORIGIN)))
    return [common.fallback(account.get("sessionToken"), None), origin]
end
