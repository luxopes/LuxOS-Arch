# Shared native command guard. Used by the application and privileged helper.
# This module only analyzes commands and reads bounded script prefixes.
load common
load platform
load glib
load shellwords
load guard_data

function match(pattern, text):
    rows = platform.regex_findall(pattern, text)
    if rows:
        return rows[0]
    end
    return None
end

function base(path):
    parts = path.rstrip("/").split("/")
    return parts[len(parts) - 1]
end

function any_match(patterns, text):
    for pattern in patterns:
        if platform.regex_test(pattern, text):
            return True
        end
    end
    return False
end

function valid_user(name):
    return type(name) == "String" and platform.regex_test(guard_data.USER_RE, name) and name != "root"
end

function rule_path(user):
    if not valid_user(user):
        Error(ValueError: "invalid user name")
    end
    return guard_data.RULES_DIR + "/49-luxai-root-" + user + ".rules"
end

function rule_text(user):
    if not valid_user(user):
        Error(ValueError: "invalid user name")
    end
    return guard_data.RULE_MARK + " (written by " + guard_data.SETUP_HELPER + ").\n" + "// Turn it off in LuxAI > Settings > Agent permissions. Only " + guard_data.ACTION_AUTO + " (the LuxAI root\n" + "// helper, which refuses blocked commands itself) and " + guard_data.ACTION_SETUP + " (turning this mode off)\n" + "// are allowed without a password, only for this user and only in a local, active session;\n" + "// everything else keeps the default (administrator password).\n" + "polkit.addRule(function(action, subject) {\n" + "    if ((action.id == \"" + guard_data.ACTION_AUTO + "\" || action.id == \"" + guard_data.ACTION_SETUP + "\") &&\n" + "            subject.user == \"" + user + "\" && subject.local && subject.active) {\n" + "        return polkit.Result.YES;\n" + "    }\n" + "});\n"
end

function feeds_password(command):
    return any_match(guard_data.PASSWORD_FEED, common.fallback(command, ""))
end

function block(ctx, reason):
    ctx["reason"] = reason
    Error(RootguardBlocked: reason)
end

function unsure(ctx, reason=None):
    if ctx["root"]:
        call block(ctx, common.fallback(reason, guard_data.R_UNSURE))
    end
end

function hard_block(command, root=False, workdir=None, home=None):
    text = ""
    if command != None:
        text = String(command)
    end
    home = common.normalize(common.fallback(home, glib.home_dir()))
    if workdir:
        workdir = common.normalize(workdir)
    else:
        workdir = None
    end
    ctx = {"root": Bool(root), "cwd": workdir, "home": home, "vars": {}, "depth": 0, "scripts": 0, "reason": None, "expansions": 0}
    try:
        if "\0" in text:
            call block(ctx, guard_data.R_DYNAMIC)
        end
        if len(text) > guard_data.MAX_COMMAND:
            call unsure(ctx, guard_data.R_DYNAMIC)
        end
        call analyze(text, ctx)
    else:
        if ctx["reason"] != None:
            return ctx["reason"]
        end
        # Parsing/IO implementation errors must never authorize a root command.
        if root:
            return guard_data.R_DYNAMIC
        end
        Error(RootguardError: String(last_error()))
    end
    return None
end

function dequote(text):
    text = platform.regex_replace("\\\\\n", "", text)
    text = platform.regex_replace("[\"'\\\\]", "", text)
    text = platform.regex_replace("\\$''", "", text)
    for index in rang(4):
        text = platform.regex_replace("/\\./", "/", text)
    end
    return platform.regex_replace("/{2,}", "/", text)
end

function text_checks(text, ctx):
    low = text.lower()
    flat = dequote(text)
    flow = flat.lower()
    if feeds_password(text) or feeds_password(flat):
        call block(ctx, guard_data.R_PASSWORD)
    end
    for pattern in guard_data.FORK:
        if platform.regex_test(pattern, text) or platform.regex_test(pattern, flat):
            call block(ctx, guard_data.R_FORK)
        end
    end
    if platform.regex_test(guard_data.REDIRECT_DEV, flat):
        call block(ctx, guard_data.R_DISK)
    end
    if platform.regex_test(guard_data.SYSRQ, flat) and (">" in flat or "tee" in flow):
        call block(ctx, guard_data.R_KERNEL)
    end
    if platform.regex_test(guard_data.SIGLEVEL, flow):
        call block(ctx, guard_data.R_SIGNATURES)
    end
    if ctx["root"]:
        if platform.regex_test(guard_data.SELF_ROOT, flat):
            call block(ctx, guard_data.R_SELF)
        end
        for pattern in guard_data.REMOTE:
            if platform.regex_test(pattern, low) or platform.regex_test(pattern, flow):
                call block(ctx, guard_data.R_REMOTE)
            end
        end
        if platform.regex_test(guard_data.PIPE_SHELL, low) or platform.regex_test(guard_data.PIPE_SHELL, flow):
            call block(ctx, guard_data.R_DYNAMIC)
        end
        if platform.regex_test("\\b(ba|z|da|k)?sh\\s+(-\\w+\\s+)*<\\s*\\(", flow) or platform.regex_test("(^|[\\s;&|])(source|\\.)\\s+<\\(", flow):
            call block(ctx, guard_data.R_DYNAMIC)
        end
        if platform.regex_test("\\bbase64\\s+(-\\w+\\s+)*(-d|--decode)\\b|\\bxxd\\s+-r\\b|\\bopenssl\\s+(enc\\s+)?(-\\w+\\s+)*-d\\b", flow) and platform.regex_test("\\|\\s*\\S*(sh|bash|python\\d*|perl|eval)\\b|\\beval\\b|\\$\\(", flow):
            call block(ctx, guard_data.R_DYNAMIC)
        end
    end
end

function mentions(flat):
    output = []
    for entry in guard_data.PROTECTED_TEXT:
        if platform.regex_test(entry[0], flat):
            output.append(entry[1])
        end
    end
    return output
end

function substitution_end(input_text, start):
    text = String(input_text)
    depth = 1
    j = start + 2
    while j < len(text) and depth != 0:
        if text[j] == "\\":
            j += 2
            continue
        end
        if text[j] == "(":
            depth += 1
        elif text[j] == ")":
            depth -= 1
        end
        j += 1
    end
    return [j, depth]
end

function substitutions(input_text, mask=False):
    text = String(input_text)
    output = []
    i = 0
    while i < len(text):
        char = text[i]
        if char == "\\":
            if mask:
                output.append(text[i:i + 2])
            end
            i += 2
            continue
        end
        if char in "$<>" and i + 1 < len(text) and text[i + 1] == "(":
            boundary = substitution_end(text, i)
            j = boundary[0]
            if mask:
                output.append(guard_data.SUBST_VAR)
            elif boundary[1] == 0:
                output.append(text[i + 2:j - 1])
            else:
                output.append(text[i + 2:])
            end
            i = j
            continue
        end
        if char == "`":
            j = text.find("`", i + 1)
            if mask:
                output.append(guard_data.SUBST_VAR)
            elif j > 0:
                output.append(text[i + 1:j])
            else:
                output.append(text[i + 1:])
            end
            i = len(text)
            if j > 0:
                i = j + 1
            end
            continue
        end
        if mask:
            output.append(char)
        end
        i += 1
    end
    if mask:
        return "".join(output)
    end
    return output
end

function tokens(text):
    text = platform.regex_replace("\\\\\n", "", text.replace("\r", "")).replace("\n", " ; ")
    result = shellwords.split(text)
    if not result["parsed"]:
        result["tokens"] = shellwords.fallback_tokens(text)
    end
    return result
end

function simple_commands(items):
    output = []
    current = []
    writes = []
    reads = []
    separator = ";"
    i = 0
    while i < len(items):
        token = items[i]
        if shellwords.all_in(token, ";&|()"):
            if current or writes or reads:
                output.append([current, writes, reads, separator])
            end
            current = []
            writes = []
            reads = []
            separator = token
            i += 1
            continue
        end
        if shellwords.all_in(token, "<>&|") and ("<" in token or ">" in token):
            if current and platform.regex_test("^\\d+$", current[len(current) - 1]):
                call current.pop()
            end
            next_token = ""
            if i + 1 < len(items):
                next_token = items[i + 1]
            end
            if token in ["<<", "<<-"]:
                reads.append(["heredoc", next_token])
            elif token == "<<<":
                reads.append(["string", next_token])
            elif ">" in token and "<" not in token:
                if next_token and not (token.endswith("&") and (platform.regex_test("^\\d+$", next_token) or next_token == "-")):
                    writes.append(next_token)
                end
            elif next_token:
                reads.append(["file", next_token])
                if ">" in token:
                    writes.append(next_token)
                end
            end
            i += 2
            continue
        end
        current.append(token)
        i += 1
    end
    if current or writes or reads:
        output.append([current, writes, reads, separator])
    end
    return output
end

function analyze(text, ctx):
    ctx["depth"] += 1
    if ctx["depth"] > guard_data.MAX_DEPTH:
        call unsure(ctx, guard_data.R_DYNAMIC)
        ctx["depth"] -= 1
        return
    end
    call text_checks(text, ctx)
    for inner in substitutions(text):
        call analyze(inner, ctx)
    end
    parsed = tokens(substitutions(text, True))
    if not parsed["parsed"] and ctx["root"]:
        call unsure(ctx, guard_data.R_DYNAMIC)
    end
    noted = mentions(dequote(text))
    writers = False
    original = ctx["cwd"]
    for entry in simple_commands(parsed["tokens"]):
        if command(entry[0], entry[1], entry[2], entry[3], ctx):
            writers = True
        end
    end
    ctx["cwd"] = original
    if noted and writers:
        call block(ctx, noted[0])
    end
    ctx["depth"] -= 1
end

function expand_braces(token, limit=32):
    found = match("\\{([^{}]*,[^{}]*)\\}", token)
    if found == None:
        return [token]
    end
    output = []
    for part in found["groups"][1].split(","):
        output += expand_braces(token[:found["start"]] + part + token[found["end"]:], limit)
        if len(output) >= limit:
            break
        end
    end
    return output[:limit]
end

function subst_vars(value, ctx, dynamic):
    ctx["expansions"] += 1
    if ctx["expansions"] > 4096:
        call unsure(ctx, guard_data.R_DYNAMIC)
        return [["", True]]
    end
    found = match(guard_data.VAR, value)
    if found == None:
        return [[value, dynamic]]
    end
    groups = found["groups"]
    name = common.fallback(groups[1], groups[4])
    choices = [None]
    if groups[5]:
        choices = [None]
    elif name == "HOME":
        choices = [ctx["home"]]
        if ctx["root"]:
            choices.append("/root")
        end
    elif name == "PWD":
        choices = [ctx["cwd"]]
    elif name in ctx["vars"]:
        choices = ctx["vars"][name]
    elif groups[2] in ["-", ":-", "=", ":="]:
        choices = [groups[3]]
    end
    output = []
    for choice in choices[:16]:
        if choice == None:
            output += subst_vars(value[:found["start"]] + value[found["end"]:], ctx, True)
        else:
            output += subst_vars(value[:found["start"]] + choice + value[found["end"]:], ctx, dynamic)
        end
    end
    return output[:64]
end

function values(token, ctx):
    variants = [[token, False]]
    if token == "~" or token.startswith("~/"):
        variants = [[ctx["home"] + token[1:], False]]
        if ctx["root"] and ctx["home"] != "/root":
            variants.append(["/root" + token[1:], False])
        end
    elif platform.regex_test("^~[a-z_][a-z0-9_-]*(/|$)", token):
        variants = [["/home/" + token[1:], False]]
    end
    output = []
    ctx["expansions"] = 0
    for entry in variants:
        output += subst_vars(entry[0], ctx, entry[1])
    end
    result = []
    for entry in output[:64]:
        value = entry[0]
        dynamic = entry[1]
        if "$(" in value or "`" in value or "<(" in value:
            dynamic = True
        end
        for expanded in expand_braces(value):
            result.append([expanded, dynamic])
        end
    end
    return result[:64]
end

function absolute(value, ctx):
    if not value.startswith("/"):
        if ctx["cwd"] == None:
            return None
        end
        value = common.join(ctx["cwd"], value)
    end
    return common.normalize(platform.regex_replace("/{2,}", "/", value))
end

function is_home_root(path, ctx):
    return path in [ctx["home"], "/root"] or platform.regex_test("^/home/[^/]+$", path)
end

function covers(path, dirs):
    if path == "/":
        return True
    end
    for directory in dirs:
        if directory == path or directory.startswith(path + "/"):
            return True
        end
    end
    return False
end

function protected_dir(path, ctx, homes=True):
    return covers(path, guard_data.SYSTEM_DIRS) or (homes and (is_home_root(path, ctx) or ctx["home"].startswith(path + "/")))
end

function in_boot(path):
    for boot in guard_data.BOOT:
        if path == boot or path.startswith(boot + "/"):
            return True
        end
    end
    return False
end

function glob_prefix(path):
    if not platform.regex_test(guard_data.GLOB, path):
        return None
    end
    prefix = []
    for part in path.split("/"):
        if platform.regex_test(guard_data.GLOB, part):
            break
        end
        prefix.append(part)
    end
    return common.fallback("/".join(prefix), "/")
end

function glob_hits(path, ctx, homes=True):
    prefix = glob_prefix(path)
    if prefix == None or prefix in guard_data.GLOB_OK:
        return False
    end
    if not protected_dir(prefix, ctx, homes) and not in_boot(prefix):
        return False
    end
    component = path[len(prefix):].lstrip("/").split("/")[0]
    names = guard_data.SAMPLE_NAMES + [base(ctx["home"])]
    directories = guard_data.SYSTEM_DIRS + [ctx["home"], "/root"]
    for entry in guard_data.PROTECTED:
        directories.append(entry[0])
    end
    for directory in directories:
        if common.dirname(directory) == prefix:
            names.append(base(directory))
        end
    end
    for name in names:
        if shellwords.glob_match(name, component):
            return True
        end
    end
    return False
end

function check_delete(value, ctx, recursive, homes=True, reason=None):
    reason = common.fallback(reason, guard_data.R_DELETE)
    path = absolute(value, ctx)
    if path == None:
        if recursive:
            call unsure(ctx)
        end
        return
    end
    prefix = glob_prefix(path)
    if in_boot(path) or (prefix != None and in_boot(prefix + "/x")):
        call block(ctx, guard_data.R_BOOT)
    end
    if prefix != None:
        if glob_hits(path, ctx, homes):
            call block(ctx, reason)
        end
        return
    end
    if recursive and protected_dir(path, ctx, homes):
        call block(ctx, reason)
    end
    if path == "/" or (is_home_root(path, ctx) and homes):
        call block(ctx, reason)
    end
end

function protected_path(path):
    for entry in guard_data.PROTECTED:
        if path == entry[0] or path.startswith(entry[0].rstrip("/") + "/"):
            return entry[1]
        end
    end
    return None
end

PREFIX_VALUES = {"sudo": ["-u", "-g", "-p", "-C", "-h", "-D", "-r", "-t", "-U", "-T", "--user", "--group", "--prompt", "--chdir", "--host"], "env": ["-u", "--unset", "-C", "--chdir"], "nice": ["-n", "--adjustment"], "ionice": ["-c", "-n", "-p", "-P", "-u"], "timeout": ["-s", "--signal", "-k", "--kill-after"], "pkexec": ["--user"], "xargs": ["-I", "-n", "-P", "-d", "-L", "-s", "-E", "-a", "--arg-file", "--delimiter", "--max-args", "--max-procs", "--replace"], "systemd-run": ["-p", "--property", "-u", "--unit", "-E", "--setenv", "--uid", "--gid", "-M", "--machine"], "doas": ["-u", "-C"], "run0": ["-u", "--user", "-g", "--group", "-D", "--chdir"], "nsenter": ["-t", "--target"], "strace": ["-o", "-e", "-p", "-s"], "script": ["-c", "--command"], "watch": ["-n", "--interval"]}

function strip_prefix(items, ctx):
    i = 0
    xargs = False
    while i < len(items):
        token = items[i]
        name = base(token)
        if platform.regex_test(guard_data.ASSIGN, token) or token in guard_data.KEYWORDS:
            i += 1
            continue
        end
        if name not in guard_data.PREFIX:
            break
        end
        i += 1
        if name in ["xargs", "parallel", "watch"]:
            xargs = True
        end
        if name == "su":
            rest = items[i:]
            k = -1
            if "-c" in rest:
                k = rest.index("-c")
            elif "--command" in rest:
                k = rest.index("--command")
            end
            if k >= 0 and k + 1 < len(rest):
                call analyze(rest[k + 1], ctx)
            end
            return [[], xargs]
        end
        if name in ["chroot", "flock", "cgexec"]:
            while i < len(items) and items[i].startswith("-"):
                i += 1
            end
            if name == "chroot" and i < len(items):
                if absolute(items[i], ctx) != "/":
                    call unsure(ctx, guard_data.R_DYNAMIC)
                end
            end
            i += 1
            continue
        end
        with_value = PREFIX_VALUES.get(name, [])
        while i < len(items) and items[i].startswith("-") and items[i] != "--":
            option = items[i]
            if name == "env" and option in ["-S", "--split-string"] and i + 1 < len(items):
                call analyze(items[i + 1], ctx)
                return [[], xargs]
            end
            if name == "env" and option.startswith("--split-string="):
                call analyze(option[option.find("=") + 1:], ctx)
                return [[], xargs]
            end
            if name == "script" and option in ["-c", "--command"] and i + 1 < len(items):
                call analyze(items[i + 1], ctx)
                return [[], xargs]
            end
            i += 1
            if option in with_value and i < len(items):
                i += 1
            end
        end
        if i < len(items) and items[i] == "--":
            i += 1
        end
        if name == "timeout" and i < len(items) and platform.regex_test("^\\d+(\\.\\d+)?[smhd]?$", items[i]):
            i += 1
        end
        if name == "script" and i < len(items):
            i += 1
        end
        if name == "nice" and i < len(items) and platform.regex_test("^-?\\d+$", items[i]):
            i += 1
        end
    end
    return [items[i:], xargs]
end

function read_script(path, ctx, binary_refusal=False):
    if not ctx["root"]:
        return None
    end
    info = platform.file_info(path)
    if info == None or not info["file"]:
        return None
    end
    if info["size"] > guard_data.MAX_SCRIPT:
        call unsure(ctx, guard_data.R_DYNAMIC)
        return None
    end
    data = None
    try:
        data = platform.read_prefix(path, guard_data.MAX_SCRIPT + 1)
    else:
        return None
    end
    for index in rang(min(8192, len(data))):
        if data[index] == 0:
            if binary_refusal:
                call unsure(ctx, guard_data.R_DYNAMIC)
            end
            return None
        end
    end
    return platform.utf8_repair(data)
end

function script_file(path, ctx):
    if not ctx["root"]:
        return
    end
    ctx["scripts"] += 1
    if ctx["scripts"] > 8:
        call unsure(ctx, guard_data.R_DYNAMIC)
        return
    end
    code = read_script(path, ctx)
    if code != None:
        call analyze(code, ctx)
    end
end

function assigned(value, ctx):
    output = []
    for entry in values(value, ctx):
        if entry[1]:
            output.append(None)
        else:
            output.append(entry[0])
        end
    end
    return common.fallback(output[:16], [None])
end

function targets(expanded, skip_values=None):
    skip_values = common.fallback(skip_values, [])
    output = []
    after = False
    i = 0
    while i < len(expanded):
        item = expanded[i]
        argument = item[0]
        i += 1
        if argument == "--" and not after:
            after = True
            continue
        end
        if not after and argument.startswith("-") and argument != "-":
            if argument in skip_values:
                i += 1
            end
            continue
        end
        output += item[1]
    end
    return output
end

function intersects(left, right):
    for value in left:
        if value in right:
            return True
        end
    end
    return False
end

function check_redirects(writes, ctx):
    any_write = False
    for token in writes:
        for entry in values(token, ctx):
            value = entry[0]
            if value in ["/dev/null", "/dev/stdout", "/dev/stderr", "/dev/tty"] or platform.regex_test("^&?\\d+$", value):
                continue
            end
            any_write = True
            path = absolute(value, ctx)
            if entry[1] or path == None:
                continue
            end
            if platform.regex_test(guard_data.DEVICE, path):
                call block(ctx, guard_data.R_DISK)
            end
            if path.startswith("/proc/sysrq"):
                call block(ctx, guard_data.R_KERNEL)
            end
            reason = protected_path(path)
            if reason:
                call block(ctx, reason)
            end
            if in_boot(path) and platform.regex_test("(?i)(vmlinuz|initramfs|\\.efi$|/EFI/|loader/|grub)", path):
                call block(ctx, guard_data.R_BOOT)
            end
        end
    end
    return any_write
end

function interp_file(script, ctx):
    if not ctx["root"]:
        return None
    end
    for entry in values(script, ctx):
        path = absolute(entry[0], ctx)
        if entry[1] or path == None:
            call unsure(ctx, guard_data.R_DYNAMIC)
            return None
        end
        return read_script(path, ctx, True)
    end
    return None
end

function interpreter(name, args, separator, reads, ctx):
    code = None
    for i in rang(len(args)):
        argument = args[i]
        if argument in ["-c", "-e", "-E", "-r", "--eval", "-p"] or platform.regex_test("^-[a-zA-Z]*[ceE]$", argument):
            if i + 1 < len(args):
                code = args[i + 1]
            end
            break
        end
    end
    name = platform.regex_replace("[\\d.]+$", "", name)
    if code == None:
        script = None
        for argument in args:
            if not argument.startswith("-"):
                script = argument
                break
            end
        end
        if name in ["awk", "gawk", "mawk", "nawk"]:
            code = script
        elif script == None or script == "-":
            if separator in ["|", "|&"] or reads:
                call unsure(ctx, guard_data.R_DYNAMIC)
            end
            return
        else:
            code = interp_file(script, ctx)
        end
    end
    if code == None:
        return
    end
    for literal in platform.regex_findall("\"((?:[^\"\\\\]|\\\\.)*)\"|'((?:[^'\\\\]|\\\\.)*)'", code):
        value = common.fallback(literal["groups"][1], literal["groups"][2])
        if value and platform.regex_test("\\s", value):
            call analyze(value, ctx)
        end
    end
    if ctx["root"]:
        flat = dequote(code)
        if platform.regex_test("rmtree|unlink|remove|rmdir|truncate|system|popen|exec|spawn|subprocess|open\\s*\\(", flat):
            for found in platform.regex_findall("(?<![\\w.])(/[\\w./-]*)", flat):
                path = common.normalize(platform.regex_replace("/{2,}", "/", found["groups"][1]))
                if path == "/" or protected_dir(path, ctx) or protected_path(path) or in_boot(path) or platform.regex_test(guard_data.DEVICE, path):
                    call block(ctx, guard_data.R_DYNAMIC)
                end
            end
        end
    end
end

function command(raw, writes, reads, separator, ctx):
    items = raw[:]
    while items and items[0] in guard_data.KEYWORDS:
        items = items[1:]
    end
    if items and items[0] == "for" and len(items) >= 2:
        choices = []
        if "in" in items:
            for token in items[items.index("in") + 1:]:
                choices += assigned(token, ctx)
            end
        end
        ctx["vars"][items[1]] = common.fallback(choices, [None])
        return False
    end
    if items and items[0] in ["export", "declare", "local", "readonly", "typeset", "let"]:
        for token in items[1:]:
            found = match(guard_data.ASSIGN, token)
            if found != None:
                ctx["vars"][found["groups"][1]] = assigned(found["groups"][2], ctx)
            end
        end
        return False
    end
    if items and items[0] in ["read", "mapfile", "readarray"]:
        for token in items[1:]:
            if platform.regex_test("^[A-Za-z_]\\w*$", token):
                ctx["vars"][token] = [None]
            end
        end
        return False
    end
    assignments = []
    k = 0
    while k < len(items) and platform.regex_test(guard_data.ASSIGN, items[k]):
        assignments.append(match(guard_data.ASSIGN, items[k]))
        k += 1
    end
    if k == len(items):
        for found in assignments:
            ctx["vars"][found["groups"][1]] = assigned(found["groups"][2], ctx)
        end
        items = []
    end
    stripped = strip_prefix(items, ctx)
    rest = stripped[0]
    xargs = stripped[1]
    any_write = check_redirects(writes, ctx)
    if not rest:
        return any_write
    end
    name_token = rest[0]
    if platform.regex_test("[$`]", name_token) or platform.regex_test(guard_data.GLOB, name_token):
        call unsure(ctx, guard_data.R_DYNAMIC)
        recursive = False
        for argument in rest[1:]:
            if platform.regex_test("^-[A-Za-z]*[rR]", argument):
                recursive = True
            end
        end
        if recursive:
            for argument in rest[1:]:
                for entry in values(argument, ctx):
                    if entry[0] and not entry[0].startswith("-"):
                        call check_delete(entry[0], ctx, True)
                    end
                end
            end
        end
        return True
    end
    name = base(name_token)
    args = rest[1:]
    expanded = []
    flat_args = []
    dynamic_args = False
    shorts = ""
    longs = []
    for argument in args:
        variants = values(argument, ctx)
        expanded.append([argument, variants])
        for entry in variants:
            flat_args.append(entry[0])
            if entry[1]:
                dynamic_args = True
            end
        end
        if argument.startswith("--"):
            longs.append(argument.split("=")[0])
        elif argument.startswith("-"):
            shorts += argument[1:]
        end
    end
    if name == "cd":
        paths = targets(expanded)
        if not paths:
            ctx["cwd"] = ctx["home"]
        elif len(paths) == 1 and not paths[0][1] and paths[0][0] != "-":
            ctx["cwd"] = absolute(paths[0][0], ctx)
        else:
            ctx["cwd"] = None
        end
        return False
    end
    if name in guard_data.SHELLS:
        if name == "busybox":
            if args:
                return command(args, [], [], separator, ctx)
            end
            return False
        end
        cflag = -1
        files = []
        for i in rang(len(args)):
            if args[i].startswith("-") and not args[i].startswith("--") and "c" in args[i][1:] and cflag < 0:
                cflag = i
            end
            if not args[i].startswith("-"):
                files.append(args[i])
            end
        end
        if cflag >= 0:
            if cflag + 1 < len(args):
                call analyze(args[cflag + 1], ctx)
            end
            return True
        end
        for entry in reads:
            if entry[0] == "string":
                call analyze(entry[1], ctx)
            end
        end
        if files:
            for entry in values(files[0], ctx):
                path = absolute(entry[0], ctx)
                if entry[1] or path == None:
                    call unsure(ctx, guard_data.R_DYNAMIC)
                else:
                    call script_file(path, ctx)
                end
            end
        elif separator in ["|", "|&"] or reads:
            call unsure(ctx, guard_data.R_DYNAMIC)
        end
        return True
    end
    if name == "eval":
        code = " ".join(args)
        if platform.regex_test("[$`]", code):
            call unsure(ctx, guard_data.R_DYNAMIC)
        end
        call analyze(code, ctx)
        return True
    end
    if name in ["source", "."]:
        if args:
            for entry in values(args[0], ctx):
                path = absolute(entry[0], ctx)
                if entry[1] or path == None or path.startswith("/dev/") or path.startswith("/proc/"):
                    call unsure(ctx, guard_data.R_DYNAMIC)
                else:
                    call script_file(path, ctx)
                end
            end
        end
        return True
    end
    if platform.regex_replace("[\\d.]+$", "", name) in guard_data.INTERP:
        call interpreter(name, args, separator, reads, ctx)
        return True
    end
    if "/" in name_token:
        path = absolute(name_token, ctx)
        if path and not platform.regex_test("^/(usr|bin|sbin)/", path):
            call script_file(path, ctx)
        end
    end
    if xargs and (name in ["rm", "chmod", "chown", "chgrp", "shred", "dd", "mv", "find", "truncate", "wipefs", "unlink", "rmdir"] or platform.regex_test(guard_data.FS_TOOLS, name)):
        call unsure(ctx)
    end
    if name in ["rm", "unlink", "rmdir"]:
        recursive = name == "rm" and ("r" in shorts.lower() or "--recursive" in longs)
        if "--no-preserve-root" in longs:
            call block(ctx, guard_data.R_DELETE)
        end
        for entry in targets(expanded):
            if entry[1]:
                if recursive or platform.regex_test(guard_data.GLOB, entry[0]):
                    call unsure(ctx)
                end
                if not entry[0]:
                    continue
                end
            end
            call check_delete(entry[0], ctx, recursive or name == "rmdir")
        end
        return True
    end
    if name == "mv":
        paths = targets(expanded, ["-t", "--target-directory", "-S", "--suffix"])
        if len(paths) > 1:
            paths = paths[:len(paths) - 1]
        end
        for entry in paths:
            if entry[1]:
                call unsure(ctx)
                if not entry[0]:
                    continue
                end
            end
            call check_delete(entry[0], ctx, True)
        end
        return True
    end
    if name == "find":
        starts = []
        for entry in expanded:
            if entry[0].startswith("-") or entry[0] in ["(", "!", ")"]:
                break
            end
            starts += entry[1]
        end
        actions = ["-delete", "-exec", "-execdir", "-ok", "-okdir"]
        if intersects(args, actions):
            filtered = intersects(args, guard_data.FIND_FILTERS)
            for entry in common.fallback(starts, [[".", False]]):
                if entry[1]:
                    call unsure(ctx)
                    if not entry[0]:
                        continue
                    end
                end
                path = absolute(entry[0], ctx)
                if path == None:
                    call unsure(ctx)
                    continue
                end
                if path == "/" or in_boot(path) or (platform.regex_test(guard_data.GLOB, path) and glob_hits(path, ctx)):
                    if in_boot(path):
                        call block(ctx, guard_data.R_BOOT)
                    end
                    call block(ctx, guard_data.R_DELETE)
                end
                if path in guard_data.GLOB_OK or path == "/var/log":
                    continue
                end
                if protected_dir(path, ctx, False) or (not filtered and protected_dir(path, ctx)):
                    call block(ctx, guard_data.R_DELETE)
                end
            end
            for i in rang(len(args)):
                if args[i] in ["-exec", "-execdir", "-ok", "-okdir"]:
                    j = i + 1
                    inner = []
                    while j < len(args) and args[j] not in [";", "\\;", "+"]:
                        inner.append(args[j])
                        j += 1
                    end
                    if inner:
                        call command(inner, [], [], ";", ctx)
                    end
                end
            end
            return True
        end
        return False
    end
    if name in ["chmod", "chown", "chgrp", "setfacl", "chattr", "chcon", "setfattr"]:
        recursive = "R" in shorts or "--recursive" in longs
        paths = targets(expanded, ["--reference", "--from"])
        if name in ["chmod", "chown", "chgrp", "chattr"] and paths and not platform.regex_test("^[/~$]", paths[0][0]):
            paths = paths[1:]
        end
        for entry in paths:
            path = absolute(entry[0], ctx)
            if entry[1] or path == None:
                if recursive:
                    call unsure(ctx)
                end
                continue
            end
            if glob_hits(path, ctx, False) or (recursive and protected_dir(path, ctx, False)) or path in ["/", "/usr", "/etc", "/bin", "/sbin", "/lib", "/lib64", "/boot", "/var", "/home", "/usr/bin", "/usr/lib"]:
                call block(ctx, guard_data.R_PERMS)
            end
            reason = protected_path(path)
            if reason:
                call block(ctx, reason)
            end
        end
        return True
    end
    if name in ["dd", "ddrescue", "dcfldd", "dc3dd"]:
        for item in expanded:
            if item[0].startswith("of="):
                for entry in values(item[0][3:], ctx):
                    path = absolute(entry[0], ctx)
                    if entry[1] or path == None:
                        call unsure(ctx)
                    elif platform.regex_test(guard_data.DEVICE, path) or (path.startswith("/dev/") and platform.regex_test(guard_data.GLOB, path)):
                        call block(ctx, guard_data.R_DISK)
                    elif in_boot(path):
                        call block(ctx, guard_data.R_BOOT)
                    elif protected_path(path):
                        call block(ctx, protected_path(path))
                    end
                end
            end
        end
        if name != "dd":
            for value in flat_args[1:]:
                if platform.regex_test(guard_data.DEVICE, value):
                    call block(ctx, guard_data.R_DISK)
                end
            end
        end
        return True
    end
    if platform.regex_test(guard_data.FS_TOOLS, name):
        if name == "wipefs" and not intersects(shorts, "ao") and not intersects(longs, ["--all", "--offset"]):
            return False
        end
        if name == "badblocks" and "w" not in shorts and "n" not in shorts:
            return False
        end
        for item in expanded:
            if item[0].startswith("-"):
                continue
            end
            for entry in item[1]:
                path = absolute(entry[0], ctx)
                if entry[1] or path == None:
                    call unsure(ctx)
                elif platform.regex_test(guard_data.DEVICE, path) or path.startswith("/dev/"):
                    call block(ctx, guard_data.R_DISK)
                elif name in ["shred", "wipe", "scrub"]:
                    reason = protected_path(path)
                    if reason or in_boot(path):
                        call block(ctx, common.fallback(reason, guard_data.R_BOOT))
                    end
                end
            end
        end
        if name == "blkdiscard":
            call block(ctx, guard_data.R_DISK)
        end
        return True
    end
    if name in guard_data.PART_TOOLS:
        if name == "parted":
            lowered = []
            for argument in args:
                lowered.append(argument.lower())
            end
            if intersects(lowered, guard_data.PARTED_WRITE) or not intersects(args, ["-l", "--list", "print"]):
                call block(ctx, guard_data.R_DISK)
            end
            return False
        end
        options = []
        for argument in args:
            if argument.startswith("-"):
                options.append(argument)
            end
        end
        if name in ["partx", "kpartx", "delpart", "resizepart", "addpart"]:
            if name in ["delpart", "resizepart", "addpart"] or intersects(options, ["-d", "--delete", "-a", "--add", "-u", "--update"]):
                call block(ctx, guard_data.R_DISK)
            end
            return False
        end
        if not options:
            call block(ctx, guard_data.R_DISK)
        end
        for option in options:
            if option not in guard_data.PART_RO and not option.startswith("--list"):
                call block(ctx, guard_data.R_DISK)
            end
        end
        return False
    end
    if name == "cryptsetup" and intersects(args, ["luksFormat", "erase", "luksErase", "reencrypt", "luksKillSlot", "luksRemoveKey", "format", "tcryptDump"]):
        call block(ctx, guard_data.R_DISK)
    end
    if name == "nvme" and intersects(args, ["format", "sanitize", "delete-ns", "detach-ns", "write-zeroes", "write"]):
        call block(ctx, guard_data.R_DISK)
    end
    if name == "hdparm":
        for argument in args:
            if platform.regex_test("^--(security-erase|trim-sector-ranges|write-sector|make-bad-sector|dco-restore|security-set-pass|fwdownload)", argument):
                call block(ctx, guard_data.R_DISK)
            end
        end
    end
    if name in ["zpool", "zfs"] and intersects(args, ["destroy", "labelclear", "create"]):
        call block(ctx, guard_data.R_DISK)
    end
    if name in ["lvremove", "vgremove", "pvremove", "pvcreate", "vgcreate", "lvcreate"] or (name == "dmsetup" and intersects(args, ["remove_all", "wipe_table"])) or (name == "flashrom" and intersects(args, ["-w", "--write", "-E", "--erase"])):
        call block(ctx, guard_data.R_DISK)
    end
    if name == "mdadm":
        for argument in args:
            if argument.startswith("--zero-superblock") or argument == "--create":
                call block(ctx, guard_data.R_DISK)
            end
        end
    end
    if name in guard_data.DEV_WRITERS and name != "dd":
        for value in flat_args:
            if platform.regex_test(guard_data.DEVICE, value) and name not in ["cat", "pv", "xz", "gzip", "zstd", "bzip2", "tar", "unzip"]:
                call block(ctx, guard_data.R_DISK)
            end
        end
    end
    if name in guard_data.ACCOUNT_CMDS:
        if name in ["pwck", "grpck"] and ("r" in shorts or "--read-only" in longs):
            return False
        end
        if name == "faillock" and "--reset" not in longs:
            return False
        end
        call block(ctx, guard_data.R_ACCOUNTS)
    end
    if name == "passwd":
        options = []
        allowed = True
        for argument in args:
            if argument.startswith("-"):
                options.append(argument)
                if argument not in ["-S", "--status", "-a", "--all"]:
                    allowed = False
                end
            end
        end
        if intersects(options, ["-S", "--status"]) and allowed:
            return False
        end
        call block(ctx, guard_data.R_ACCOUNTS)
    end
    if name == "chage" and "l" not in shorts and "--list" not in longs:
        call block(ctx, guard_data.R_ACCOUNTS)
    end
    if name == "visudo":
        if "c" in shorts or "--check" in longs:
            return False
        end
        call block(ctx, guard_data.R_AUTH)
    end
    if name in ["sudoedit", "pam-auth-update", "authselect"]:
        call block(ctx, guard_data.R_AUTH)
    end
    if name in guard_data.PKG_TOOLS:
        removing = "--remove" in longs or (name in ["lux", "pamac"] and args and args[0] in ["remove", "uninstall", "rm", "purge"])
        for argument in args:
            if platform.regex_test("^-[A-Za-z]*R", argument):
                removing = True
            end
        end
        if removing:
            for value in flat_args:
                if not value.startswith("-") and (value in guard_data.CORE_PKGS or platform.regex_test("^linux(-[a-z0-9]+)*$", value)):
                    call block(ctx, guard_data.R_BOOT)
                end
            end
            if dynamic_args:
                call unsure(ctx)
            end
            if "--dbonly" in args:
                call block(ctx, guard_data.R_BOOT)
            end
        end
    end
    if name == "efibootmgr" and ("B" in shorts or intersects(longs, ["--delete-bootnum", "--delete"])):
        call block(ctx, guard_data.R_BOOT)
    end
    if name == "bootctl" and intersects(args, ["remove", "unlink", "cleanup"]):
        call block(ctx, guard_data.R_BOOT)
    end
    if name in ["makepkg", "pacman", "yay", "paru"] and intersects(args, ["--skippgpcheck", "--skipchecksums", "--skipinteg", "--nosign"]):
        call block(ctx, guard_data.R_SIGNATURES)
    end
    if name == "pacman-key" and intersects(args, ["--delete", "-d", "--edit-key"]):
        call block(ctx, guard_data.R_SIGNATURES)
    end
    readonly = name in guard_data.READONLY
    if name == "find" or (name == "sort" and ("o" in shorts or "--output" in longs)):
        readonly = False
    end
    if name == "systemctl" and not (args and args[0] in ["status", "cat", "show", "is-active", "is-enabled", "list-units", "list-unit-files", "list-timers", "is-failed", "--failed"]):
        readonly = False
    end
    if name == "mount" and args:
        readonly = False
    end
    if not readonly:
        for item in expanded:
            for entry in item[1]:
                value = entry[0]
                path = None
                if "/" in value or value.startswith("~"):
                    path = absolute(value, ctx)
                end
                if path:
                    reason = protected_path(path)
                    if reason:
                        call block(ctx, reason)
                    end
                    if ctx["root"] and platform.regex_test(guard_data.SELF_ROOT, path):
                        call block(ctx, guard_data.R_SELF)
                    end
                end
            end
        end
    end
    return not readonly or any_write
end
