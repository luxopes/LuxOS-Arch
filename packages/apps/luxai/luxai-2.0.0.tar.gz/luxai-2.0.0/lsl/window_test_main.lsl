# lsl: internal-abi
# Full native-window integration driver, isolated display/account supplied by tests.
load gtk
load gtk_ext
load app_window
load app_model
load ui_dispatch
load ui_cards
load settings_window
load common
load i18n
load json
load time
load store
load platform
load glib

function is_label(widget):
    return __lsl_qbe_call2(__lsl_symbol("g_type_check_instance_is_a"), platform.pointer(widget), __lsl_qbe_call0(__lsl_symbol("gtk_label_get_type"))) != 0
end

function is_container(widget):
    return __lsl_qbe_call2(__lsl_symbol("g_type_check_instance_is_a"), platform.pointer(widget), __lsl_qbe_call0(__lsl_symbol("gtk_container_get_type"))) != 0
end

# texts of all labels inside a widget (cards: confirmation preview and result rows)
function label_texts(widget, output):
    if is_label(widget):
        output.append(gtk.label_get_text(widget))
    elif is_container(widget):
        for child in gtk_ext.children(widget):
            call label_texts(child, output)
        end
    end
    return output
end

fixture = json.decode(readfile(arg(1)))
confirm_rows = {}
call gtk.init()
call i18n.initialize(fixture["app_root"], "/nonexistent", {"LANG": "en"})
call ui_dispatch.initialize(3)
state = app_window.new_window(0, fixture["app_root"], fixture.get("account"), False)
state["settings"]["workdir"] = fixture["cwd"]
state["settings"]["auto_title"] = fixture.get("auto_title", False)
state["settings"]["vision"] = {"flash": False, "lite": False}
if fixture.get("mode", "agent") == "agent":
    call gtk.toggle_button_set_active(state["mode_agent"], True)
end
call app_window.attach_uris(state, fixture.get("uris", []))
for path in fixture.get("attachments", []):
    call app_window.add_attachment(state, path)
end
call app_window.set_input(state, fixture.get("text", ""))
call gtk.button_clicked(state["send_button"])
deadline = time.monotonic() + 12
while state["current_run"] != None and time.monotonic() < deadline:
    call ui_dispatch.pump()
    for card in state["cards"].values():
        if card["state"] == "waiting" and not card["answered"]:
            confirm_rows[card["name"]] = label_texts(card["confirm"], [])
            if fixture.get("action") == "cancel":
                call gtk.button_clicked(state["stop_button"])
            elif fixture.get("action") == "deny" and "deny" in card["buttons"]:
                call gtk.button_clicked(card["buttons"]["deny"])
            elif "once" in card["buttons"]:
                call gtk.button_clicked(card["buttons"]["once"])
            end
        end
    end
    call time.sleep(0.005)
end
call ui_dispatch.pump()
toggle_image = __lsl_qbe_call1(__lsl_symbol("gtk_button_get_image"), platform.pointer(state["sidebar_toggle"]))
header = {"avatar_xalign": gtk_ext.label_get_xalign(state["avatar"]), "empty_xalign": gtk_ext.label_get_xalign(state["list_empty"]), "avatar_text": gtk.label_get_text(state["avatar"]), "toggle_image_mapped": toggle_image != 0 and __lsl_qbe_call1(__lsl_symbol("gtk_widget_get_mapped"), platform.pointer(toggle_image)) != 0, "toggle_tooltip": glib.take_c(__lsl_qbe_call1(__lsl_symbol("gtk_widget_get_tooltip_text"), platform.pointer(state["sidebar_toggle"]))), "avatar_size": gtk.widget_get_allocation(state["avatar"])}
result = {"header": header, "running": state["current_run"] != None, "conversation": state["conversation"], "cards": [], "rows": len(gtk_ext.children(state["column"])), "history_count": app_window.store_count(state), "input": gtk_ext.buffer_text(gtk_ext.text_view_get_buffer(state["input"]))}
for card in state["cards"].values():
    result["cards"].append({"name": card["name"], "state": card["state"], "done": card["done"], "preview_rows": label_texts(card["preview"], [])})
end
saved_id = state["conversation"]["id"]
call gtk.button_clicked(state["new_button"])
draft_id = state["conversation"]["id"]
call app_model.open_conversation(state, saved_id)
result["reloaded_id"] = state["conversation"]["id"]
result["new_conversation_id"] = draft_id
result["reloaded_rows"] = len(gtk_ext.children(state["column"]))
route_maps = 0
for card in state["cards"].values():
    if card.get("route_map") != None:
        route_maps += 1
    end
end
result["reloaded_route_maps"] = route_maps
result["confirm_rows"] = confirm_rows
reloaded_rows = []
for card in state["cards"].values():
    reloaded_rows.append(label_texts(card["preview"], []))
end
result["reloaded_preview_rows"] = reloaded_rows
call app_window.quick_menu(state, state["model_combo"])
result["quick_controls"] = sorted(state["quick_widgets"].keys())
call app_window.close_popovers(state)
preferences = settings_window.new_window(state, "privacy")
call gtk.widget_destroy(preferences["widget"])
call gtk.window_close(state["widget"])
while state["alive"] and time.monotonic() < deadline:
    call ui_dispatch.pump()
    call time.sleep(0.005)
end
result["closed"] = not state["alive"]
call gtk_ext.collect_callbacks(None, None)
call ui_dispatch.close()
for worker in ui_dispatch.queues["threads"]:
    call thread_join(worker)
end
print json.encode(result)
