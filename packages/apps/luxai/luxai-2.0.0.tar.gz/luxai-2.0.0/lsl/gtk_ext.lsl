# lsl: internal-abi
# lsl: link libgtk-3.so.0 libgdk-3.so.0 libgio-2.0.so.0 libgobject-2.0.so.0 libglib-2.0.so.0
load gtk
load glib
load platform
load common
load ui_dispatch

callback_owners = {}
callback_cleanup = {"pending": [], "tick": None}

function finalized(state, object):
    global callback_owners
    key = state["key"]
    # Weak notifications run during GObject disposal; GTK may still emit
    # signals while unwinding that disposal. Keep records alive until the
    # next main-loop pass, after the complete native call has returned.
    callback_cleanup["pending"].append(state["records"])
    if key in callback_owners:
        callback_owners = common.without(callback_owners, key)
    end
end

function collect_callbacks(state, arguments):
    pending = callback_cleanup["pending"].copy()
    callback_cleanup["pending"] = []
    for records in pending:
        for record in records:
            call platform.release_callback(record)
        end
    end
end

function connect(widget, signal, handler, bound, argument_count=0):
    if callback_cleanup["tick"] == None:
        callback_cleanup["tick"] = ui_dispatch.add_tick(collect_callbacks)
    end
    key = String(widget)
    if key not in callback_owners:
        owner = {"key": key, "records": [], "signals": {}}
        weak_record = 0
        lock platform.callback_lock:
            weak_record = glib.record_bound(finalized, 1, owner)
        end
        owner["records"].append(weak_record)
        callback_owners[key] = owner
        call __lsl_qbe_call3(__lsl_symbol("g_object_weak_ref"), platform.pointer(widget), glib.callback_first(), platform.pointer(weak_record))
    end
    record = 0
    lock platform.callback_lock:
        record = glib.record_bound(handler, Int(argument_count) + 1, bound)
    end
    callback_owners[key]["records"].append(record)
    identity = __lsl_qbe_call6(__lsl_symbol("g_signal_connect_data"), platform.pointer(widget), platform.cstr(signal), glib.callback_first(), platform.pointer(record), 0, 2)
    callback_owners[key]["signals"][String(identity)] = record
    return identity
end

function disconnect(widget, identity):
    key = String(widget)
    if key not in callback_owners or String(identity) not in callback_owners[key]["signals"]:
        return
    end
    owner = callback_owners[key]
    record = owner["signals"][String(identity)]
    call glib.signal_handler_disconnect(widget, identity)
    owner["signals"] = common.without(owner["signals"], String(identity))
    call owner["records"].remove(record)
    callback_cleanup["pending"].append([record])
end

function connect_drop(widget, handler, bound):
    # drag-data-received has six arguments in addition to the widget. The
    # eighth-slot trampoline skips the first native argument (widget), which
    # is already available through bound state, and forwards all six values.
    record = 0
    lock platform.callback_lock:
        record = glib.record_bound(handler, 6, bound)
    end
    key = String(widget)
    identity = __lsl_qbe_call6(__lsl_symbol("g_signal_connect_data"), platform.pointer(widget), platform.cstr("drag-data-received"), glib.callback_eighth(), platform.pointer(record), 0, 0)
    callback_owners[key]["records"].append(record)
    callback_owners[key]["signals"][String(identity)] = record
    return identity
end

function string_vector(raw):
    pointer = platform.pointer(raw)
    values = []
    if pointer == 0:
        return values
    end
    offset = 0
    while __lsl_qbe_load64(pointer + offset) != 0:
        values.append(glib.from_c(__lsl_qbe_load64(pointer + offset)))
        offset += 8
    end
    call __lsl_qbe_call1(__lsl_symbol("g_strfreev"), pointer)
    return values
end

function path_from_uri(uri):
    hostname = platform.buffer(8)
    errors = platform.buffer(8)
    raw = __lsl_qbe_call3(__lsl_symbol("g_filename_from_uri"), platform.cstr(uri), platform.address(hostname), platform.address(errors))
    problem = __lsl_qbe_load64(platform.address(errors))
    if problem != 0:
        call __lsl_qbe_call1(__lsl_symbol("g_error_free"), problem)
    end
    name = __lsl_qbe_load64(platform.address(hostname))
    if name != 0:
        call __lsl_qbe_call1(__lsl_symbol("g_free"), name)
    end
    return glib.take_c(raw)
end

function focus_has_selection(window):
    focus = __lsl_qbe_call1(__lsl_symbol("gtk_window_get_focus"), platform.pointer(window))
    if focus == 0:
        return False
    end
    text_type = __lsl_qbe_call0(__lsl_symbol("gtk_text_view_get_type"))
    if __lsl_qbe_call2(__lsl_symbol("g_type_check_instance_is_a"), focus, text_type) != 0:
        buffer = __lsl_qbe_call1(__lsl_symbol("gtk_text_view_get_buffer"), focus)
        return __lsl_qbe_call1(__lsl_symbol("gtk_text_buffer_get_has_selection"), buffer) != 0
    end
    editable_type = __lsl_qbe_call0(__lsl_symbol("gtk_editable_get_type"))
    if __lsl_qbe_call2(__lsl_symbol("g_type_check_instance_is_a"), focus, editable_type) != 0:
        bounds = platform.buffer(8)
        return __lsl_qbe_call3(__lsl_symbol("gtk_editable_get_selection_bounds"), focus, platform.address(bounds), platform.address(bounds) + 4) != 0
    end
    return False
end

function children(container):
    first = __lsl_qbe_call1(__lsl_symbol("gtk_container_get_children"), platform.pointer(container))
    current = first
    result = []
    while current != 0:
        result.append(__lsl_qbe_load64(current))
        current = __lsl_qbe_load64(current + 8)
    end
    call __lsl_qbe_call1(__lsl_symbol("g_list_free"), first)
    return result
end

function clear(container):
    for child in children(container):
        call gtk.widget_destroy(child)
    end
end

function buffer_text(buffer):
    begin = platform.buffer(80)
    finish = platform.buffer(80)
    call __lsl_qbe_call3(__lsl_symbol("gtk_text_buffer_get_bounds"), platform.pointer(buffer), platform.address(begin), platform.address(finish))
    raw = __lsl_qbe_call4(__lsl_symbol("gtk_text_buffer_get_text"), platform.pointer(buffer), platform.address(begin), platform.address(finish), 0)
    return glib.take_c(raw)
end

function selection(label):
    begin = platform.buffer(4)
    finish = platform.buffer(4)
    found = __lsl_qbe_call3(__lsl_symbol("gtk_label_get_selection_bounds"), platform.pointer(label), platform.address(begin), platform.address(finish))
    if found == 0:
        return ""
    end
    text = String(gtk.label_get_text(label))
    left = __lsl_qbe_load32(platform.address(begin))
    right = __lsl_qbe_load32(platform.address(finish))
    return text[Int(min(left, right)):Int(max(left, right))]
end

function clipboard():
    atom = __lsl_qbe_call2(__lsl_symbol("gdk_atom_intern"), platform.cstr("CLIPBOARD"), 0)
    return __lsl_qbe_call1(__lsl_symbol("gtk_clipboard_get"), atom)
end

function clipboard_text():
    raw = __lsl_qbe_call1(__lsl_symbol("gtk_clipboard_wait_for_text"), platform.pointer(clipboard()))
    if raw == 0:
        return None
    end
    return glib.take_c(raw)
end

function copy(text):
    content = String(text).replace("\0", "�")
    target = clipboard()
    call __lsl_qbe_call3(__lsl_symbol("gtk_clipboard_set_text"), platform.pointer(target), platform.cstr(content), __lsl_text_byte_length(content))
    call __lsl_qbe_call1(__lsl_symbol("gtk_clipboard_store"), platform.pointer(target))
end

function gtk_text(message):
    # preklad z katalogu GTK (napr. "_OK" jako u Gtk.ButtonsType.OK v Pythonu)
    return glib.from_c(__lsl_qbe_call2(__lsl_symbol("g_dgettext"), platform.cstr("gtk30"), platform.cstr(message)))
end

function file_dialog(parent, title, action, multiple=False, accept="", cancel=""):
    # accept/cancel jsou uz prelozene popisky tlacitek (jako v Pythonu _("Attach"), _("Add"))
    dialog = __lsl_qbe_call4(__lsl_symbol("gtk_file_chooser_dialog_new"), platform.cstr(title), platform.pointer(parent), platform.pointer(action), 0)
    if not cancel:
        cancel = gtk_text("_Cancel")
    end
    if not accept:
        accept = gtk_text("_Select")
    end
    call dialog_add_button(dialog, cancel, -6)
    call dialog_add_button(dialog, accept, -3)
    call file_chooser_set_select_multiple(dialog, multiple)
    return dialog
end

function selected_files(chooser):
    first = file_chooser_get_filenames(chooser)
    current = first
    result = []
    while current != 0:
        result.append(glib.take_c(__lsl_qbe_load64(platform.pointer(current))))
        current = __lsl_qbe_load64(platform.pointer(current) + 8)
    end
    call __lsl_qbe_call1(__lsl_symbol("g_slist_free"), platform.pointer(first))
    return result
end

function widget_set_hexpand(widget, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_widget_set_hexpand"), platform.pointer(widget), platform.pointer(enabled))
end

function widget_set_vexpand(widget, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_widget_set_vexpand"), platform.pointer(widget), platform.pointer(enabled))
end

function widget_set_no_show_all(widget, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_widget_set_no_show_all"), platform.pointer(widget), platform.pointer(enabled))
end

function widget_set_can_focus(widget, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_widget_set_can_focus"), platform.pointer(widget), platform.pointer(enabled))
end

function widget_grab_focus(widget):
    return __lsl_qbe_call1(__lsl_symbol("gtk_widget_grab_focus"), platform.pointer(widget))
end

function widget_get_parent(widget):
    return __lsl_qbe_call1(__lsl_symbol("gtk_widget_get_parent"), platform.pointer(widget))
end

function widget_get_toplevel(widget):
    return __lsl_qbe_call1(__lsl_symbol("gtk_widget_get_toplevel"), platform.pointer(widget))
end

function widget_set_margin_start(widget, value):
    return __lsl_qbe_call2(__lsl_symbol("gtk_widget_set_margin_start"), platform.pointer(widget), platform.pointer(value))
end

function widget_set_margin_end(widget, value):
    return __lsl_qbe_call2(__lsl_symbol("gtk_widget_set_margin_end"), platform.pointer(widget), platform.pointer(value))
end

function widget_set_margin_top(widget, value):
    return __lsl_qbe_call2(__lsl_symbol("gtk_widget_set_margin_top"), platform.pointer(widget), platform.pointer(value))
end

function widget_set_margin_bottom(widget, value):
    return __lsl_qbe_call2(__lsl_symbol("gtk_widget_set_margin_bottom"), platform.pointer(widget), platform.pointer(value))
end

function set_float_property(object, name, value):
    # gtk_label_set_xalign ma parametr gfloat; volani pres __lsl_qbe_call preda double a GTK
    # pak cte jen spodni bity (0.5 -> 0.0, vse zarovnane vlevo). GValue typu double a
    # g_object_set_property hodnotu na float prevedou spravne.
    holder = __lsl_byte_zeros(24)
    gvalue = platform.address(holder)
    call __lsl_qbe_call2(__lsl_symbol("g_value_init"), gvalue, 60)
    call __lsl_qbe_call2(__lsl_symbol("g_value_set_double"), gvalue, Float(value))
    call __lsl_qbe_call3(__lsl_symbol("g_object_set_property"), platform.pointer(object), platform.cstr(name), gvalue)
    call __lsl_qbe_call1(__lsl_symbol("g_value_unset"), gvalue)
end

function label_set_xalign(label, value):
    return set_float_property(label, "xalign", value)
end

function label_set_yalign(label, value):
    return set_float_property(label, "yalign", value)
end

function label_get_xalign(label):
    # jen pro testy: skutecne zarovnani popisku (gfloat v xmm0 jako double nejde precist, proto GValue)
    holder = __lsl_byte_zeros(24)
    gvalue = platform.address(holder)
    call __lsl_qbe_call2(__lsl_symbol("g_value_init"), gvalue, 60)
    call __lsl_qbe_call3(__lsl_symbol("g_object_get_property"), platform.pointer(label), platform.cstr("xalign"), gvalue)
    bits = __lsl_qbe_load64(gvalue + 8)
    call __lsl_qbe_call1(__lsl_symbol("g_value_unset"), gvalue)
    return __lsl_float_from_bits(bits)
end

function label_set_line_wrap(label, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_label_set_line_wrap"), platform.pointer(label), platform.pointer(enabled))
end

function label_set_line_wrap_mode(label, mode):
    return __lsl_qbe_call2(__lsl_symbol("gtk_label_set_line_wrap_mode"), platform.pointer(label), platform.pointer(mode))
end

function label_set_selectable(label, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_label_set_selectable"), platform.pointer(label), platform.pointer(enabled))
end

function label_set_max_width_chars(label, count):
    return __lsl_qbe_call2(__lsl_symbol("gtk_label_set_max_width_chars"), platform.pointer(label), platform.pointer(count))
end

function label_set_width_chars(label, count):
    return __lsl_qbe_call2(__lsl_symbol("gtk_label_set_width_chars"), platform.pointer(label), platform.pointer(count))
end

function label_set_ellipsize(label, mode):
    return __lsl_qbe_call2(__lsl_symbol("gtk_label_set_ellipsize"), platform.pointer(label), platform.pointer(mode))
end

function label_set_justify(label, mode):
    return __lsl_qbe_call2(__lsl_symbol("gtk_label_set_justify"), platform.pointer(label), platform.pointer(mode))
end

function header_bar_new():
    return __lsl_qbe_call0(__lsl_symbol("gtk_header_bar_new"))
end

function header_bar_set_title(bar, title):
    return __lsl_qbe_call2(__lsl_symbol("gtk_header_bar_set_title"), platform.pointer(bar), platform.cstr(title))
end

function header_bar_set_subtitle(bar, title):
    return __lsl_qbe_call2(__lsl_symbol("gtk_header_bar_set_subtitle"), platform.pointer(bar), platform.cstr(title))
end

function header_bar_set_show_close_button(bar, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_header_bar_set_show_close_button"), platform.pointer(bar), platform.pointer(enabled))
end

function header_bar_pack_start(bar, widget):
    return __lsl_qbe_call2(__lsl_symbol("gtk_header_bar_pack_start"), platform.pointer(bar), platform.pointer(widget))
end

function header_bar_pack_end(bar, widget):
    return __lsl_qbe_call2(__lsl_symbol("gtk_header_bar_pack_end"), platform.pointer(bar), platform.pointer(widget))
end

function window_set_titlebar(window, bar):
    return __lsl_qbe_call2(__lsl_symbol("gtk_window_set_titlebar"), platform.pointer(window), platform.pointer(bar))
end

function window_set_application(window, application):
    return __lsl_qbe_call2(__lsl_symbol("gtk_window_set_application"), platform.pointer(window), platform.pointer(application))
end

function window_set_icon(window, image):
    return __lsl_qbe_call2(__lsl_symbol("gtk_window_set_icon"), platform.pointer(window), platform.pointer(image))
end

# Ikony okna ve vsech velikostech (16-256 px): ostra ikona v prepinaci oken, liste i Docku.
function window_set_icon_list(window, images):
    items = 0
    for image in images:
        items = __lsl_qbe_call2(__lsl_symbol("g_list_append"), platform.pointer(items), platform.pointer(image))
    end
    call __lsl_qbe_call2(__lsl_symbol("gtk_window_set_icon_list"), platform.pointer(window), platform.pointer(items))
    call __lsl_qbe_call1(__lsl_symbol("g_list_free"), platform.pointer(items))
end

function text_view_new():
    return __lsl_qbe_call0(__lsl_symbol("gtk_text_view_new"))
end

function text_view_get_buffer(view):
    return __lsl_qbe_call1(__lsl_symbol("gtk_text_view_get_buffer"), platform.pointer(view))
end

function text_view_set_wrap_mode(view, mode):
    return __lsl_qbe_call2(__lsl_symbol("gtk_text_view_set_wrap_mode"), platform.pointer(view), platform.pointer(mode))
end

function text_view_set_accepts_tab(view, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_text_view_set_accepts_tab"), platform.pointer(view), platform.pointer(enabled))
end

function text_view_set_editable(view, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_text_view_set_editable"), platform.pointer(view), platform.pointer(enabled))
end

function text_view_set_cursor_visible(view, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_text_view_set_cursor_visible"), platform.pointer(view), platform.pointer(enabled))
end

function text_view_set_left_margin(view, count):
    return __lsl_qbe_call2(__lsl_symbol("gtk_text_view_set_left_margin"), platform.pointer(view), platform.pointer(count))
end

function text_view_set_right_margin(view, count):
    return __lsl_qbe_call2(__lsl_symbol("gtk_text_view_set_right_margin"), platform.pointer(view), platform.pointer(count))
end

function text_view_set_top_margin(view, count):
    return __lsl_qbe_call2(__lsl_symbol("gtk_text_view_set_top_margin"), platform.pointer(view), platform.pointer(count))
end

function text_view_set_bottom_margin(view, count):
    return __lsl_qbe_call2(__lsl_symbol("gtk_text_view_set_bottom_margin"), platform.pointer(view), platform.pointer(count))
end

function text_buffer_set_text(buffer, text, length):
    return __lsl_qbe_call3(__lsl_symbol("gtk_text_buffer_set_text"), platform.pointer(buffer), platform.cstr(text), platform.pointer(length))
end

function stack_new():
    return __lsl_qbe_call0(__lsl_symbol("gtk_stack_new"))
end

function stack_add_named(stack, child, name):
    return __lsl_qbe_call3(__lsl_symbol("gtk_stack_add_named"), platform.pointer(stack), platform.pointer(child), platform.cstr(name))
end

function stack_set_visible_child_name(stack, name):
    return __lsl_qbe_call2(__lsl_symbol("gtk_stack_set_visible_child_name"), platform.pointer(stack), platform.cstr(name))
end

function stack_set_transition_type(stack, mode):
    return __lsl_qbe_call2(__lsl_symbol("gtk_stack_set_transition_type"), platform.pointer(stack), platform.pointer(mode))
end

function expander_new(title):
    return __lsl_qbe_call1(__lsl_symbol("gtk_expander_new"), platform.cstr(title))
end

function expander_set_expanded(expander, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_expander_set_expanded"), platform.pointer(expander), platform.pointer(enabled))
end

function expander_set_label(expander, title):
    return __lsl_qbe_call2(__lsl_symbol("gtk_expander_set_label"), platform.pointer(expander), platform.cstr(title))
end

function list_box_row_new():
    return __lsl_qbe_call0(__lsl_symbol("gtk_list_box_row_new"))
end

function list_box_get_row_at_index(box, index):
    return __lsl_qbe_call2(__lsl_symbol("gtk_list_box_get_row_at_index"), platform.pointer(box), platform.pointer(index))
end

function list_box_select_row(box, row):
    return __lsl_qbe_call2(__lsl_symbol("gtk_list_box_select_row"), platform.pointer(box), platform.pointer(row))
end

function scrolled_window_get_vadjustment(window):
    return __lsl_qbe_call1(__lsl_symbol("gtk_scrolled_window_get_vadjustment"), platform.pointer(window))
end

function scrolled_window_set_propagate_natural_height(window, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_scrolled_window_set_propagate_natural_height"), platform.pointer(window), platform.pointer(enabled))
end

function scrolled_window_set_propagate_natural_width(window, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_scrolled_window_set_propagate_natural_width"), platform.pointer(window), platform.pointer(enabled))
end

function adjustment_get_value(adjustment):
    return __lsl_qbe_fcall1(__lsl_symbol("gtk_adjustment_get_value"), platform.pointer(adjustment))
end

function adjustment_get_upper(adjustment):
    return __lsl_qbe_fcall1(__lsl_symbol("gtk_adjustment_get_upper"), platform.pointer(adjustment))
end

function adjustment_get_page_size(adjustment):
    return __lsl_qbe_fcall1(__lsl_symbol("gtk_adjustment_get_page_size"), platform.pointer(adjustment))
end

function adjustment_set_value(adjustment, value):
    return __lsl_qbe_call2(__lsl_symbol("gtk_adjustment_set_value"), platform.pointer(adjustment), Float(value))
end

function entry_set_visibility(entry, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_entry_set_visibility"), platform.pointer(entry), platform.pointer(enabled))
end

function entry_set_activates_default(entry, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_entry_set_activates_default"), platform.pointer(entry), platform.pointer(enabled))
end

function combo_box_get_active_id(combo):
    return __lsl_qbe_call1(__lsl_symbol("gtk_combo_box_get_active_id"), platform.pointer(combo))
end

function combo_box_set_active_id(combo, identity):
    return __lsl_qbe_call2(__lsl_symbol("gtk_combo_box_set_active_id"), platform.pointer(combo), platform.cstr(identity))
end

function combo_box_text_remove_all(combo):
    return __lsl_qbe_call1(__lsl_symbol("gtk_combo_box_text_remove_all"), platform.pointer(combo))
end

function revealer_new():
    return __lsl_qbe_call0(__lsl_symbol("gtk_revealer_new"))
end

function revealer_set_reveal_child(revealer, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_revealer_set_reveal_child"), platform.pointer(revealer), platform.pointer(enabled))
end

function revealer_set_transition_type(revealer, mode):
    return __lsl_qbe_call2(__lsl_symbol("gtk_revealer_set_transition_type"), platform.pointer(revealer), platform.pointer(mode))
end

function spinner_new():
    return __lsl_qbe_call0(__lsl_symbol("gtk_spinner_new"))
end

function spinner_start(spinner):
    return __lsl_qbe_call1(__lsl_symbol("gtk_spinner_start"), platform.pointer(spinner))
end

function spinner_stop(spinner):
    return __lsl_qbe_call1(__lsl_symbol("gtk_spinner_stop"), platform.pointer(spinner))
end

function link_button_new_with_label(uri, title):
    return __lsl_qbe_call2(__lsl_symbol("gtk_link_button_new_with_label"), platform.cstr(uri), platform.cstr(title))
end

function menu_new():
    return __lsl_qbe_call0(__lsl_symbol("gtk_menu_new"))
end

function menu_item_new_with_label(title):
    return __lsl_qbe_call1(__lsl_symbol("gtk_menu_item_new_with_label"), platform.cstr(title))
end

function menu_shell_append(menu, child):
    return __lsl_qbe_call2(__lsl_symbol("gtk_menu_shell_append"), platform.pointer(menu), platform.pointer(child))
end

function menu_popup_at_pointer(menu, event):
    return __lsl_qbe_call2(__lsl_symbol("gtk_menu_popup_at_pointer"), platform.pointer(menu), platform.pointer(event))
end

function popover_new(relative):
    return __lsl_qbe_call1(__lsl_symbol("gtk_popover_new"), platform.pointer(relative))
end

function popover_popup(popover):
    return __lsl_qbe_call1(__lsl_symbol("gtk_popover_popup"), platform.pointer(popover))
end

function popover_popdown(popover):
    return __lsl_qbe_call1(__lsl_symbol("gtk_popover_popdown"), platform.pointer(popover))
end

function file_chooser_set_select_multiple(chooser, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_file_chooser_set_select_multiple"), platform.pointer(chooser), platform.pointer(enabled))
end

function file_chooser_set_current_folder(chooser, path):
    return __lsl_qbe_call2(__lsl_symbol("gtk_file_chooser_set_current_folder"), platform.pointer(chooser), platform.cstr(path))
end

function file_chooser_get_filename(chooser):
    return __lsl_qbe_call1(__lsl_symbol("gtk_file_chooser_get_filename"), platform.pointer(chooser))
end

function file_chooser_get_filenames(chooser):
    return __lsl_qbe_call1(__lsl_symbol("gtk_file_chooser_get_filenames"), platform.pointer(chooser))
end

function file_chooser_set_do_overwrite_confirmation(chooser, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_file_chooser_set_do_overwrite_confirmation"), platform.pointer(chooser), platform.pointer(enabled))
end

function file_chooser_set_current_name(chooser, name):
    return __lsl_qbe_call2(__lsl_symbol("gtk_file_chooser_set_current_name"), platform.pointer(chooser), platform.cstr(name))
end

function dialog_new():
    return __lsl_qbe_call0(__lsl_symbol("gtk_dialog_new"))
end

function dialog_add_button(dialog, title, response):
    return __lsl_qbe_call3(__lsl_symbol("gtk_dialog_add_button"), platform.pointer(dialog), platform.cstr(title), platform.pointer(response))
end

function dialog_get_content_area(dialog):
    return __lsl_qbe_call1(__lsl_symbol("gtk_dialog_get_content_area"), platform.pointer(dialog))
end

function dialog_set_default_response(dialog, response):
    return __lsl_qbe_call2(__lsl_symbol("gtk_dialog_set_default_response"), platform.pointer(dialog), platform.pointer(response))
end

function dialog_run(dialog):
    return __lsl_qbe_call1(__lsl_symbol("gtk_dialog_run"), platform.pointer(dialog))
end

function container_remove(container, child):
    return __lsl_qbe_call2(__lsl_symbol("gtk_container_remove"), platform.pointer(container), platform.pointer(child))
end

function paned_new(orientation):
    return __lsl_qbe_call1(__lsl_symbol("gtk_paned_new"), platform.pointer(orientation))
end

function paned_pack1(paned, child, resize, shrink):
    return __lsl_qbe_call4(__lsl_symbol("gtk_paned_pack1"), platform.pointer(paned), platform.pointer(child), platform.pointer(resize), platform.pointer(shrink))
end

function paned_pack2(paned, child, resize, shrink):
    return __lsl_qbe_call4(__lsl_symbol("gtk_paned_pack2"), platform.pointer(paned), platform.pointer(child), platform.pointer(resize), platform.pointer(shrink))
end

function paned_set_position(paned, position):
    return __lsl_qbe_call2(__lsl_symbol("gtk_paned_set_position"), platform.pointer(paned), platform.pointer(position))
end

function paned_get_position(paned):
    return __lsl_qbe_call1(__lsl_symbol("gtk_paned_get_position"), platform.pointer(paned))
end

function header_bar_set_custom_title(bar, title):
    return __lsl_qbe_call2(__lsl_symbol("gtk_header_bar_set_custom_title"), platform.pointer(bar), platform.pointer(title))
end

function radio_button_new_with_label_from_widget(group, label):
    return __lsl_qbe_call2(__lsl_symbol("gtk_radio_button_new_with_label_from_widget"), platform.pointer(group), platform.cstr(label))
end

function toggle_button_set_mode(button, mode):
    return __lsl_qbe_call2(__lsl_symbol("gtk_toggle_button_set_mode"), platform.pointer(button), platform.pointer(mode))
end

function list_box_get_row_at_y(box, y):
    return __lsl_qbe_call2(__lsl_symbol("gtk_list_box_get_row_at_y"), platform.pointer(box), platform.pointer(y))
end

function list_box_set_placeholder(box, child):
    return __lsl_qbe_call2(__lsl_symbol("gtk_list_box_set_placeholder"), platform.pointer(box), platform.pointer(child))
end

function list_box_unselect_all(box):
    return __lsl_qbe_call1(__lsl_symbol("gtk_list_box_unselect_all"), platform.pointer(box))
end

function search_entry_new():
    return __lsl_qbe_call0(__lsl_symbol("gtk_search_entry_new"))
end

function overlay_set_overlay_pass_through(overlay, child, enabled):
    return __lsl_qbe_call3(__lsl_symbol("gtk_overlay_set_overlay_pass_through"), platform.pointer(overlay), platform.pointer(child), platform.pointer(enabled))
end

function window_set_urgency_hint(window, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_window_set_urgency_hint"), platform.pointer(window), platform.pointer(enabled))
end

function entry_set_width_chars(entry, count):
    return __lsl_qbe_call2(__lsl_symbol("gtk_entry_set_width_chars"), platform.pointer(entry), platform.pointer(count))
end

function about_dialog_new():
    return __lsl_qbe_call0(__lsl_symbol("gtk_about_dialog_new"))
end

function about_dialog_set_program_name(dialog, name):
    return __lsl_qbe_call2(__lsl_symbol("gtk_about_dialog_set_program_name"), platform.pointer(dialog), platform.cstr(name))
end

function about_dialog_set_version(dialog, version):
    return __lsl_qbe_call2(__lsl_symbol("gtk_about_dialog_set_version"), platform.pointer(dialog), platform.cstr(version))
end

function about_dialog_set_comments(dialog, comments):
    return __lsl_qbe_call2(__lsl_symbol("gtk_about_dialog_set_comments"), platform.pointer(dialog), platform.cstr(comments))
end

function about_dialog_set_website(dialog, website):
    return __lsl_qbe_call2(__lsl_symbol("gtk_about_dialog_set_website"), platform.pointer(dialog), platform.cstr(website))
end

function about_dialog_set_logo(dialog, logo):
    return __lsl_qbe_call2(__lsl_symbol("gtk_about_dialog_set_logo"), platform.pointer(dialog), platform.pointer(logo))
end

function level_bar_remove_offset_value(bar, name):
    return __lsl_qbe_call2(__lsl_symbol("gtk_level_bar_remove_offset_value"), platform.pointer(bar), platform.cstr(name))
end

function popover_set_position(popover, position):
    return __lsl_qbe_call2(__lsl_symbol("gtk_popover_set_position"), platform.pointer(popover), platform.pointer(position))
end

function menu_attach_to_widget(menu, widget, detach):
    return __lsl_qbe_call3(__lsl_symbol("gtk_menu_attach_to_widget"), platform.pointer(menu), platform.pointer(widget), platform.pointer(detach))
end

function button_set_always_show_image(button, enabled):
    return __lsl_qbe_call2(__lsl_symbol("gtk_button_set_always_show_image"), platform.pointer(button), platform.pointer(enabled))
end

function icon_theme_has_icon(name):
    theme = __lsl_qbe_call0(__lsl_symbol("gtk_icon_theme_get_default"))
    if theme == 0:
        return False
    end
    return __lsl_qbe_call2(__lsl_symbol("gtk_icon_theme_has_icon"), platform.pointer(theme), platform.cstr(name)) != 0
end
