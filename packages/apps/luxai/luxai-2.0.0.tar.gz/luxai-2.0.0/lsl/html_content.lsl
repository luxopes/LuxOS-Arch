load common
load platform
load web_data

function number(text, radix):
    value = 0
    for char in text.lower():
        index = "0123456789abcdef".find(char)
        if index < 0 or index >= radix:
            return -1
        end
        value = value * radix + index
        if value > 1114111:
            return 1114112
        end
    end
    return value
end

function entity(text):
    if text.startswith("#"):
        digits = text[1:].rstrip(";")
        radix = 10
        if digits.startswith("x") or digits.startswith("X"):
            radix = 16
            digits = digits[1:]
        end
        value = number(digits, radix)
        if String(value) in web_data.HTML_INVALID_CHARREFS:
            return web_data.HTML_INVALID_CHARREFS[String(value)]
        end
        if value < 0 or value > 1114111 or (value >= 55296 and value <= 57343):
            return "�"
        end
        if value in web_data.HTML_INVALID_CODEPOINTS:
            return ""
        end
        return chr(value)
    end
    if text in web_data.HTML_ENTITIES:
        return web_data.HTML_ENTITIES[text]
    end
    for length in rang(len(text) - 1, 1, -1):
        if text[:length] in web_data.HTML_ENTITIES:
            return web_data.HTML_ENTITIES[text[:length]] + text[length:]
        end
    end
    return "&" + text
end

function unescape(input_text):
    text = String(input_text)
    output = []
    position = 0
    matches = platform.regex_findall("&(#(?:[0-9]+|[xX][0-9a-fA-F]+);?|[^\\t\\n\\f <&#;]{1,32};?)", text)
    for found in matches:
        output.append(text[Int(position):Int(found["start"])])
        output.append(entity(found["groups"][1]))
        position = found["end"]
    end
    output.append(text[Int(position):])
    return "".join(output)
end

function attributes(text):
    output = {}
    for found in platform.regex_findall("([^\\s/>=]+)(?:\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]*)))?", text):
        groups = found["groups"]
        value = common.fallback(groups[2], common.fallback(groups[3], groups[4]))
        output[groups[1].lower()] = unescape(value)
    end
    return output
end

function events(input_html):
    html = String(input_html)
    output = []
    position = 0
    while position < len(html):
        start = html.find("<", position)
        if start < 0:
            output.append(["text", unescape(html[Int(position):])])
            break
        end
        if start > position:
            output.append(["text", unescape(html[Int(position):Int(start)])])
        end
        if html[Int(start):Int(start) + 4] == "<!--":
            finish = html.find("-->", start + 4)
            if finish < 0:
                break
            end
            position = finish + 3
            continue
        end
        quote = ""
        finish = start + 1
        while finish < len(html):
            char = html[Int(finish)]
            if quote:
                if char == quote:
                    quote = ""
                end
            elif char in "\"'":
                quote = char
            elif char == ">":
                break
            end
            finish += 1
        end
        if finish >= len(html):
            output.append(["text", unescape(html[Int(start):])])
            break
        end
        body = html[Int(start) + 1:Int(finish)]
        position = finish + 1
        if body.startswith("!") or body.startswith("?"):
            continue
        end
        end_tag = False
        if body.startswith("/"):
            end_tag = True
            body = body[1:].lstrip(common.WHITESPACE)
        end
        parsed = platform.regex_findall("^([A-Za-z][^\\s/>]*)", body)
        if not parsed:
            output.append(["text", "<"])
            position = start + 1
            continue
        end
        name = parsed[0]["groups"][1].lower()
        if end_tag:
            output.append(["end", name])
        else:
            attrs = attributes(body[parsed[0]["end"]:])
            output.append(["start", name, attrs])
            if body.rstrip(common.WHITESPACE).endswith("/"):
                output.append(["end", name])
            elif name in ["script", "style"]:
                endings = platform.regex_findall("(?i)</\\s*" + name + "\\s*>", html[Int(position):])
                if not endings:
                    break
                end
                ending = endings[0]
                output.append(["text", html[Int(position):Int(position) + Int(ending["start"])]])
                output.append(["end", name])
                position += ending["end"]
            end
        end
    end
    return output
end

function emit(state, text):
    state["all"].append(text)
    if state["main_depth"]:
        state["main"].append(text)
    end
end

function tidy(input_text):
    text = String(input_text)
    lines = []
    for raw_line in text.split("\n"):
        replaced = String(platform.regex_replace("[ \\t ]+", " ", raw_line))
        line = platform.strip(replaced, common.WHITESPACE)
        line = platform.regex_replace("^\\|\\s*", "", line)
        if line or (lines and lines[len(lines) - 1]):
            lines.append(line)
        end
    end
    joined = "\n".join(lines)
    return platform.strip(joined, common.WHITESPACE)
end

function to_text(html):
    state = {"all": [], "main": [], "main_depth": 0, "pre": 0, "title": "", "in_title": False, "skip": [], "links": []}
    parsed_events = events(html)
    for event in parsed_events:
        kind = event[0]
        name = event[1]
        if kind == "text":
            if state["in_title"]:
                state["title"] += name
                continue
            end
            if state["skip"]:
                continue
            end
            if state["pre"]:
                call emit(state, name)
            else:
                call emit(state, platform.regex_replace("\\s+", " ", name))
            end
            continue
        end
        if kind == "start":
            attrs = event[2]
            if name == "title" and not state["title"]:
                state["in_title"] = True
            end
            if name == "body":
                state["skip"] = []
            end
            if name == "a" and len(state["links"]) < 5000 and attrs.get("href"):
                state["links"].append(attrs["href"])
            end
            if state["skip"]:
                if name == state["skip"][len(state["skip"]) - 1] and name not in web_data.VOID:
                    state["skip"].append(name)
                end
                continue
            end
            hidden = "hidden" in attrs or "display:none" in attrs.get("style", "").replace(" ", "") or attrs.get("aria-hidden") == "true"
            if (name in web_data.SKIP or hidden) and name not in web_data.VOID:
                state["skip"].append(name)
                continue
            end
            if name in ["main", "article"]:
                state["main_depth"] += 1
            end
            if name == "pre":
                state["pre"] += 1
            end
            if name in web_data.BLOCK:
                call emit(state, "\n")
            end
            if name in ["h1", "h2", "h3", "h4", "h5", "h6"]:
                call emit(state, "#" * Int(name[1]) + " ")
            elif name == "li":
                call emit(state, "- ")
            elif name in ["td", "th"]:
                call emit(state, " | ")
            end
        else:
            if name == "title":
                state["in_title"] = False
            end
            if state["skip"]:
                if name == state["skip"][len(state["skip"]) - 1]:
                    call state["skip"].pop()
                end
                continue
            end
            if name in ["main", "article"] and state["main_depth"]:
                state["main_depth"] -= 1
            end
            if name == "pre" and state["pre"]:
                state["pre"] -= 1
            end
            if name in web_data.BLOCK:
                call emit(state, "\n")
            end
        end
    end
    main = tidy("".join(state["main"]))
    text = main
    if len(main) < 400:
        text = tidy("".join(state["all"]))
    end
    return {"title": common.words(state["title"]), "text": text, "links": state["links"]}
end
