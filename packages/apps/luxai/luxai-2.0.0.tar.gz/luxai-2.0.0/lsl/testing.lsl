# Test-only deterministic adapters. No shell execution or external side effects.
# Linked by bridge.lsl only; not a production tool backend or permission policy.
load agent_core
load common
load catalog
load settings
load store
load feedback
load json
load safety
load tools as native_tools
load web
load net_address
load urls
load transport
load api
load time

function model_request(state, payload):
    state["bodies"].append(payload)
    index = state["reply_index"]
    state["reply_index"] += 1
    message = common.copy(state["replies"][index])
    if message.get("_error") != None:
        # chyba serveru pro dany krok (napr. HTTP 413)
        call api.raise_error(api.error(message["_error"]["code"], message["_error"].get("status", 0)))
    end
    message["role"] = "assistant"
    finish = "stop"
    if message.get("tool_calls"):
        finish = "tool_calls"
    end
    finish = message.get("_finish", finish)
    message = common.without(message, "_finish")
    if message.get("content"):
        call agent_core.stream_delta(state, message["content"], "")
    end
    return [message, finish, {"total_tokens": 7}]
end

function judge(permissions, name, arguments, state):
    return {"action": permissions["actions"].get(name, "ask"), "reasons": ["fixture policy"]}
end

function confirm(ui, id, name, arguments, action, reasons):
    ui["confirmations"].append([name, action])
    if ui["answers"]:
        return ui["answers"].pop(0)
    end
    return "deny"
end

function execute(tools, name, arguments, prepared):
    tools["executed"].append({"name": name, "arguments": arguments})
    if tools["results"]:
        return tools["results"].pop(0)
    end
    return {"ok": True, "content": "fixture result"}
end

function run_fixture(fixture):
    conversation = store.Conversation("fixture", "", fixture.get("mode", "agent"), fixture.get("model", "flash"), fixture.get("messages", [{"role": "user", "content": "do it"}]), 1, 1)
    ui = {"confirm": confirm, "answers": fixture.get("answers", []), "confirmations": []}
    permissions = {"judge": judge, "actions": fixture.get("actions", {}), "policy": settings.normalize_policy(fixture.get("policy"))}
    if fixture.get("real_permissions"):
        permissions = safety.new_permissions(fixture.get("auto_approve", False), fixture.get("policy"))
    end
    tools = {"definitions": catalog.TOOL_DEFS, "workdir": "/tmp/fixture", "execute": execute, "results": fixture.get("results", []), "executed": []}
    if conversation["mode"] == "chat":
        tools["definitions"] = catalog.DOCS_TOOL_DEFS + catalog.WEB_TOOL_DEFS
    end
    state = agent_core.new_run(conversation, None, ui, tools, permissions, fixture.get("preferences"), fixture.get("vision", False))
    if fixture.get("origin"):
        # skutecny HTTP klient proti loopback serveru (telo jde opravdu po siti)
        state["client"] = api.new_client({"sessionToken": "good-token"}, fixture["origin"])
    else:
        state["request"] = model_request
    end
    state["replies"] = fixture["replies"]
    state["reply_index"] = 0
    state["bodies"] = []
    state["max_steps"] = fixture.get("max_steps", 40)
    reason = agent_core.run(state)
    return {"reason": reason, "messages": conversation["messages"], "bodies": state["bodies"], "confirmations": ui["confirmations"], "executed": tools["executed"], "events": state["events"]}
end

function feedback_read(context, path):
    return context["files"].get(path, "").strip(common.WHITESPACE)
end

function feedback_run(context, arguments, timeout):
    if arguments[0] == "journalctl":
        if "--user" in arguments:
            return context["outputs"].get("user", "")
        end
        return context["outputs"].get("system", "")
    end
    return context["outputs"].get(json.encode(arguments), "")
end

function feedback_fixture(fixture):
    context = {"files": fixture["files"], "outputs": fixture["outputs"], "facts": fixture["facts"], "read": feedback_read, "run": feedback_run}
    return feedback.collect_system(context, fixture["environment"])
end

function tool_runner(state, argv, timeout, input_text, check):
    state["fixture_calls"].append({"argv": argv, "timeout": timeout, "input": input_text, "check": check})
    result = state["fixture_responses"].get(json.encode(argv), {"stdout": "", "stderr": "", "returncode": 0})
    if check and result["returncode"] != 0:
        call native_tools.fail(common.fallback(result["stderr"], result["stdout"]))
    end
    return result
end

function tool_spawner(state, argv):
    state["fixture_spawned"].append(argv)
end

function gui_shot(gui):
    return common.copy(gui["shot"])
end

function gui_clipboard(gui):
    return gui.get("text")
end

function gui_notify(gui, title, body):
    gui["notifications"].append([title, body])
end

function tool_system(state):
    return state["fixture_system"]
end

function tool_fixture(fixture):
    gui = None
    if fixture.get("gui"):
        gui = common.copy(fixture["gui"])
        gui["screenshot"] = gui_shot
        gui["report_screenshot"] = gui_shot
        gui["clipboard_text"] = gui_clipboard
        gui["notify"] = gui_notify
        gui["notifications"] = []
    end
    state = native_tools.new_tools(fixture.get("cwd", "/tmp/fixture"), gui, 120, fixture.get("vision", False), fixture.get("env", {}), fixture.get("blocked"), fixture.get("client"), fixture.get("chat", False))
    state["fixture_calls"] = []
    state["fixture_spawned"] = []
    state["fixture_responses"] = fixture.get("responses", {})
    state["fixture_system"] = fixture.get("system", {})
    state["runner"] = tool_runner
    state["spawner"] = tool_spawner
    state["collect_system"] = tool_system
    state["programs"] = fixture.get("programs", [])
    output = []
    prepared = None
    for item in fixture["calls"]:
        if item.get("prepare"):
            prepared = native_tools.prepare(state, item["name"], item.get("args", {}), item.get("allow_screenshot", True))
            output.append(prepared)
        else:
            output.append(native_tools.execute(state, item["name"], item.get("args", {}), prepared))
        end
    end
    return {"results": output, "commands": state["fixture_calls"], "spawned": state["fixture_spawned"]}
end

function web_resolver(fetcher, host, port):
    fixture = fetcher["fixture"]
    if net_address.ip(host) != None:
        return [host]
    end
    if host not in fixture["hosts"]:
        Error(WebError: "Cannot resolve host " + host)
    end
    return fixture["hosts"][host]
end

function web_sender(fetcher, method, url, headers, body, limit, resolve):
    parsed = urls.split(url)
    fetcher["connections"].append({"url": url, "resolve": resolve, "method": method})
    target = fetcher["fixture"]["origin"] + parsed["path"]
    if parsed["query"]:
        target += "?" + parsed["query"]
    end
    headers["Host"] = parsed["host"]
    return transport.request(method, target, headers, body, 15, None, web.request_stop, limit, None, fetcher, True, True)
end

function web_stopped(fixture):
    return fixture.get("cancelled", False)
end

function web_fixture(fixture):
    fetcher = web.new_fetcher(web_stopped, fixture, fixture.get("deadline", 40))
    fetcher["fixture"] = fixture
    fetcher["resolver"] = web_resolver
    fetcher["sender"] = web_sender
    fetcher["connections"] = []
    output = []
    for item in fixture["calls"]:
        if item["operation"] == "fetch":
            output.append(web.fetch(item["url"], item.get("max_chars", 20000), fetcher))
        elif item["operation"] == "search":
            output.append(web.search(item["query"], item.get("max_results"), fixture.get("client"), fetcher))
        elif item["operation"] in ["request", "request_stats"]:
            try:
                started = time.monotonic()
                result = web.request(fetcher, item["url"], item.get("method", "GET"), item.get("body"))
                if item["operation"] == "request_stats":
                    output.append({"bytes": len(result["data"]), "duration": time.monotonic() - started, "truncated": result["truncated"], "status": result["status"]})
                else:
                    result["data"] = common.base64_encode(result["data"])
                    output.append(result)
                end
            else:
                output.append({"error": web.clean_error(String(last_error()))})
            end
        end
    end
    return {"results": output, "connections": fetcher["connections"]}
end
