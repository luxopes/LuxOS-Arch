# API history invariants shared by the agent and on-disk conversations.
load json
load common
load platform

MAX_HISTORY_IMAGES = 4
MAX_HISTORY_IMAGE_CHARS = 360000
MAX_API_MESSAGES = 190
HISTORY_CHAR_BUDGET = 160000
IMAGE_HIDDEN = "[image omitted: the current model cannot see images]"
IMAGE_OLD = "[older image omitted to save tokens; take a new screenshot or ask the user if you need it]"
MISSING_RESULT = {"ok": False, "interrupted": True, "error": "No result was recorded for this tool call (it was interrupted). Check the current state before trying again."}
INTERRUPTED = {"ok": False, "interrupted": True, "error": "Interrupted: LuxAI was closed or the conversation was switched before this action finished. Check the current state before trying again."}

function image_part_url(part):
    value = part.get("image_url")
    if type(value) == "Dictionary":
        return value.get("url", "")
    end
    return common.text(value)
end

function message_text(message):
    if type(message.get("_text")) == "String":
        return message["_text"]
    end
    content = message.get("content")
    if type(content) == "String":
        return content
    end
    parts = []
    if type(content) == "List":
        for part in content:
            if type(part) == "Dictionary" and part.get("type") == "text":
                parts.append(part.get("text", ""))
            end
        end
    end
    return "\n".join(parts)
end

function call_name(call):
    if type(call) != "Dictionary" or type(call.get("function")) != "Dictionary":
        return None
    end
    return call["function"].get("name")
end

function valid_call(call):
    if type(call) != "Dictionary" or type(call.get("function")) != "Dictionary":
        return None
    end
    id = call.get("id")
    name = call["function"].get("name")
    if type(id) != "String" or len(id) < 1 or len(id) > 200 or not common.identifier(name, 64):
        return None
    end
    arguments = call["function"].get("arguments")
    if arguments == None:
        arguments = ""
    elif type(arguments) != "String":
        arguments = common.python_json(arguments)
    end
    return {"id": id, "type": "function", "function": {"name": name, "arguments": arguments}}
end

function repair_tool_sequence(messages, declared=None, missing=None):
    source = []
    for message in messages:
        if type(message) == "Dictionary":
            source.append(message)
        end
    end
    missing_text = common.python_json_ascii(common.fallback(missing, MISSING_RESULT))
    output = []
    notes = []
    used = []
    for index in rang(len(source)):
        if index in used:
            continue
        end
        message = source[index]
        role = message.get("role")
        if role == "tool":
            notes.append("dropped orphan tool result")
            continue
        end
        calls = None
        if role == "assistant":
            calls = message.get("tool_calls")
        end
        if type(calls) != "List" or not calls:
            if "tool_calls" in message:
                message = common.without(message, "tool_calls")
                if role == "assistant" and not message.get("content"):
                    notes.append("dropped empty assistant message")
                    continue
                end
            end
            output.append(message)
            continue
        end
        good = []
        bad = []
        seen = []
        ids = []
        for candidate in calls:
            checked = valid_call(candidate)
            if checked == None:
                bad.append(candidate)
                notes.append("dropped invalid tool call")
            elif checked["id"] in seen or (declared != None and checked["function"]["name"] not in declared):
                bad.append(checked)
                notes.append("dropped unavailable or duplicate tool call")
            else:
                good.append(checked)
            end
            if checked != None:
                seen.append(checked["id"])
            end
            if type(candidate) == "Dictionary" and candidate.get("id") != None:
                ids.append(candidate["id"])
            end
        end
        results = {}
        for j in rang(index + 1, len(source)):
            if j in used:
                continue
            end
            other = source[j]
            stop = False
            if other.get("role") == "assistant" and type(other.get("tool_calls")) == "List":
                for later in other["tool_calls"]:
                    if type(later) == "Dictionary" and later.get("id") in ids:
                        stop = True
                        break
                    end
                end
            end
            if stop:
                break
            end
            if other.get("role") == "tool" and other.get("tool_call_id") in ids and other.get("tool_call_id") not in results:
                results[other["tool_call_id"]] = j
                used.append(j)
            end
        end
        text = ""
        if type(message.get("content")) == "String":
            text = message["content"]
        end
        for rejected in bad:
            name = "?"
            result = ""
            if type(rejected) == "Dictionary":
                name = common.fallback(call_name(rejected), "?")
                if rejected.get("id") in results:
                    result = common.text(source[results[rejected["id"]]].get("content"))[:300]
                end
            end
            if text:
                text += "\n"
            end
            text += "[Tool call " + String(name)[:64] + " is not available now"
            if result:
                text += "; its result was: " + result
            end
            text += "]"
        end
        cleaned = common.without(message, "tool_calls")
        cleaned["content"] = common.fallback(text, None)
        if not good:
            if cleaned["content"]:
                output.append(cleaned)
            end
            continue
        end
        cleaned["tool_calls"] = good
        output.append(cleaned)
        for call in good:
            if call["id"] not in results:
                notes.append("added missing result")
                output.append({"role": "tool", "tool_call_id": call["id"], "content": missing_text})
            else:
                reply = common.copy(source[results[call["id"]]])
                if reply.get("content") == None:
                    reply["content"] = ""
                elif type(reply["content"]) != "String":
                    reply["content"] = common.python_json(reply["content"])
                end
                output.append(reply)
            end
        end
    end
    return [output, notes]
end

function chosen_images(messages, vision):
    selected = []
    total = 0
    if not vision:
        return selected
    end
    index = len(messages) - 1
    while index >= 0:
        content = messages[index].get("content")
        if type(content) == "List":
            p = len(content) - 1
            while p >= 0:
                part = content[p]
                if type(part) == "Dictionary" and part.get("type") == "image_url":
                    url = image_part_url(part)
                    if len(selected) >= MAX_HISTORY_IMAGES or (len(selected) > 0 and total + len(url) > MAX_HISTORY_IMAGE_CHARS):
                        return selected
                    end
                    if url.startswith("data:image/"):
                        selected.append(String(index) + ":" + String(p))
                        total += len(url)
                    end
                end
                p -= 1
            end
        end
        index -= 1
    end
    return selected
end

function clean_content(content, role, selected, index, vision):
    if type(content) != "List":
        return content
    end
    parts = []
    has_image = False
    for p in rang(len(content)):
        part = content[p]
        if type(part) == "Dictionary" and part.get("type") == "image_url":
            if String(index) + ":" + String(p) in selected:
                parts.append({"type": "image_url", "image_url": {"url": image_part_url(part)}})
                has_image = True
            else:
                replacement = IMAGE_HIDDEN
                if vision:
                    replacement = IMAGE_OLD
                end
                parts.append({"type": "text", "text": replacement})
            end
        elif type(part) == "Dictionary" and part.get("type") == "text":
            parts.append({"type": "text", "text": common.text(part.get("text"))})
        elif type(part) == "String":
            parts.append({"type": "text", "text": part})
        end
    end
    if role == "user" and has_image:
        return parts
    end
    texts = []
    for part in parts:
        if part["type"] == "text" and part["text"]:
            texts.append(part["text"])
        end
    end
    text = "\n\n".join(texts)
    if role == "assistant" and not text:
        return None
    end
    return text
end

function api_messages(messages, mode, vision=True, declared=None):
    source = []
    kept = []
    for original in messages:
        if type(original) != "Dictionary":
            continue
        end
        message = common.copy(original)
        role = message.get("role")
        if role not in ["user", "assistant", "tool", "system"]:
            continue
        end
        if mode != "agent":
            if message.get("_screenshot") or message.get("_transient"):
                continue
            end
            if role == "assistant" and message.get("tool_calls"):
                calls = []
                if type(message["tool_calls"]) == "List" and declared:
                    for call in message["tool_calls"]:
                        if type(call) == "Dictionary" and call_name(call) in declared:
                            calls.append(call)
                            kept.append(call.get("id"))
                        end
                    end
                end
                message = common.without(message, "tool_calls")
                if calls:
                    message["tool_calls"] = calls
                end
            end
            if role == "tool" and message.get("tool_call_id") not in kept:
                continue
            end
            if role == "assistant" and not message.get("content") and not message.get("tool_calls"):
                continue
            end
        end
        source.append(message)
    end
    selected = chosen_images(source, vision)
    output = []
    for index in rang(len(source)):
        message = source[index]
        role = message["role"]
        content = clean_content(message.get("content"), role, selected, index, vision)
        if content == None and role != "assistant":
            content = ""
        end
        clean = {"role": role, "content": content}
        if role == "assistant" and message.get("tool_calls") and (mode == "agent" or declared):
            clean["tool_calls"] = message["tool_calls"]
        end
        if role == "tool":
            clean["tool_call_id"] = message.get("tool_call_id", "")
            if content == None:
                clean["content"] = ""
            elif type(content) != "String":
                clean["content"] = common.python_json_ascii(content)
            end
        end
        output.append(clean)
    end
    if mode == "agent" or declared:
        return repair_tool_sequence(output, declared)[0]
    end
    return output
end

function message_size(message):
    size = len(common.python_json(message))
    content = message.get("content")
    if type(content) == "List":
        for part in content:
            if type(part) == "Dictionary" and part.get("type") == "image_url":
                size -= len(image_part_url(part))
            end
        end
    end
    return size
end

function trim_history(messages, budget=160000, max_messages=190):
    output = messages.copy()
    total = 0
    for message in output:
        total += message_size(message)
    end
    start = 0
    if output and output[0].get("role") == "system":
        start = 1
    end
    while total > budget or len(output) > max_messages:
        users = []
        for index in rang(start, len(output)):
            if output[index].get("role") == "user" and (index == 0 or output[index - 1].get("role") != "tool"):
                users.append(index)
            end
        end
        if len(users) < 2:
            break
        end
        cut = users[1]
        for message in output[start:cut]:
            total -= message_size(message)
        end
        output = output[:start] + output[cut:]
    end
    while total > budget or len(output) > max_messages:
        first = -1
        for index in rang(start, len(output)):
            if output[index].get("role") == "user":
                first = index
                break
            end
        end
        if first < 0:
            break
        end
        step = -1
        for index in rang(first + 2, len(output)):
            if output[index].get("role") == "assistant":
                step = index
                break
            end
        end
        if step < 0:
            break
        end
        for message in output[first + 1:step]:
            total -= message_size(message)
        end
        output = output[:first + 1] + output[step:]
    end
    return output
end

# Proxy lux-ai.cz prijme telo dotazu nejvyse 768 KiB (jinak HTTP 413); rezerva jako v Pythonu
MAX_BODY_BYTES = 716800

function body_size(body):
    # bajty UTF-8 JSON tela (stejne jako api.chat_stream posila)
    return platform.byte_length(json.encode(body))
end

function drop_images(body, items, everything, limit):
    for item in items:
        if not everything and body_size(body) <= limit:
            return
        end
        content = item[0]
        position = item[1]
        content[position] = {"type": "text", "text": IMAGE_OLD}
    end
end

function shrink_body(body, limit=716800, everything=False):
    # Dotaz pod limit serveru: starsi obrazky -> IMAGE_OLD, kratsi historie, nakonec nejnovejsi obrazek.
    # everything=True: hned bez vsech obrazku (po HTTP 413). Jako agent.shrink_body v Pythonu.
    if not everything and body_size(body) <= limit:
        return body
    end
    images = []
    for message in common.fallback(body.get("messages"), []):
        content = message.get("content")
        if type(content) == "List":
            for index in rang(len(content)):
                part = content[index]
                if type(part) == "Dictionary" and part.get("type") == "image_url":
                    images.append([content, index])
                end
            end
        end
    end
    if everything:
        call drop_images(body, images, True, limit)
    elif len(images) > 1:
        call drop_images(body, images[:len(images) - 1], False, limit)
    end
    budget = HISTORY_CHAR_BUDGET
    while body_size(body) > limit and budget > 10000:
        budget = budget // 2
        body["messages"] = trim_history(body["messages"], budget)
    end
    if images:
        call drop_images(body, images[len(images) - 1:], everything, limit)
    end
    return body
end
