# Local time for the calendar tools ("naive local" seconds like the LuxOS Calendar:
# day ordinal * 86400 + seconds of the day) on top of the GTimeZone primitives in calendar_time.
load common
load platform
load calendar_time

DAY = 86400
EPOCH = 719163

function zone_known(name):
    return name != "" and calendar_time.zone(name) != 0
end

function offset_list(name, kind, seconds):
    return calendar_time.offset_at(calendar_time.zone(name), kind, seconds)
end

# Naive local moment -> [unix time]; [] when the local time does not exist (DST gap).
# An ambiguous time (clocks go back) is its first occurrence, like RFC 5545 3.3.5 / Python fold=0.
function to_unix(moment, name=""):
    naive = moment - EPOCH * DAY
    if calendar_time.zone(name) == 0:
        return [naive]
    end
    best = None
    for kind in [calendar_time.TIME_STANDARD, calendar_time.TIME_DAYLIGHT]:
        for offset in offset_list(name, kind, naive):
            candidate = naive - offset
            if best == None or candidate < best:
                best = candidate
            end
        end
    end
    if best == None:
        return []
    end
    return [best]
end

function exists_locally(moment):
    return len(to_unix(moment)) == 1
end

# Like to_unix, but a time in a DST gap is moved forward by the gap (stored or foreign times).
function unix_of(moment, name=""):
    found = to_unix(moment, name)
    if found:
        return found[0]
    end
    naive = moment - EPOCH * DAY
    before = offset_list(name, calendar_time.TIME_UNIVERSAL, naive - DAY)
    if before:
        return naive - before[0]
    end
    return naive
end

# UTC offset (seconds) of the local zone (or of `name`) at a unix time
function offset_of(unix, name=""):
    found = offset_list(name, calendar_time.TIME_UNIVERSAL, unix)
    if found:
        return found[0]
    end
    return 0
end

function from_unix(unix, name=""):
    return unix + offset_of(unix, name) + EPOCH * DAY
end

# Naive time in zone `name` -> naive local time; an unknown zone is floating (unchanged).
function zone_to_local(moment, name):
    if not zone_known(name):
        return moment
    end
    return from_unix(unix_of(moment, name))
end

function now():
    return from_unix(calendar_time.now_unix())
end

# Local zone name written as TZID, like luxos_date.local_tz_name (TZ or /etc/localtime)
function local_tz_name():
    tz = common.environment("TZ", "")
    while tz.startswith(":"):
        tz = tz[1:]
    end
    target = platform.realpath("/etc/localtime")
    if tz.startswith("/"):
        target = platform.realpath(tz)
    elif tz != "":
        # TZ=Europe/Prague or UTC; a POSIX rule string (CET-1CEST) is written as floating time
        if zone_known(tz):
            return tz
        end
        return ""
    end
    cut = target.find("/zoneinfo/")
    if cut >= 0:
        return target[cut + 10:]
    end
    return ""
end
