load common
load protocol
load platform
load transport
load i18n
load fd
load catalog

MAX_IMAGES = 4
MAX_ATTACHMENTS = 8
MAX_TEXT_CHARS = 60000
MAX_IMAGE_FILE = 26214400
MAX_IMAGE_URL_CHARS = 300000

function basename(path):
    parts = path.rstrip("/").split("/")
    return parts[len(parts) - 1]
end

function classify(path):
    lower = path.lower()
    for extension in catalog.IMAGE_EXTENSIONS:
        if lower.endswith(extension):
            return "image"
        end
    end
    head = ByteArray()
    try:
        head = platform.read_prefix(path, 8192)
    else:
        return "other"
    end
    if len(head) >= 2 and head[0] == 66 and head[1] == 77:
        return "image"
    end
    if len(head) >= 3 and head[0] == 255 and head[1] == 216 and head[2] == 255:
        return "image"
    end
    if len(head) >= 4:
        magic = common.base64_encode(head[:4])
        if magic in ["iVBORw==", "R0lGOA=="]:
            return "image"
        end
        if len(head) >= 12 and transport.text_from_bytes(head[:4]) == "RIFF" and transport.text_from_bytes(head[8:12]) == "WEBP":
            return "image"
        end
    end
    for byte in head:
        if byte == 0:
            return "other"
        end
    end
    if not platform.valid_utf8(head, True):
        return "other"
    end
    return "text"
end

function text_attachment(path):
    name = basename(path)
    raw = ByteArray()
    try:
        raw = platform.read_prefix(path, 240001)
    else:
        problem = String(last_error())
        reason = problem
        marker = problem.find(" file: ")
        if marker >= 0:
            reason = problem[marker + 7:]
        end
        Error(AttachmentError: i18n.translate("{0} cannot be read: {1}").replace("{0}", name).replace("{1}", reason))
    end
    # Python: decode("utf-8", "replace")
    text = platform.utf8_decode(raw)
    truncated = len(text) > MAX_TEXT_CHARS or len(raw) > MAX_TEXT_CHARS * 4
    if truncated:
        text = text[:MAX_TEXT_CHARS]
    end
    return {"kind": "text", "name": name, "text": text, "truncated": truncated}
end

function text_part(attachment):
    note = ""
    if attachment.get("truncated"):
        note = "\n[file truncated to the first 60000 characters]"
    end
    fence = "```"
    if "```" in attachment["text"]:
        fence = "````"
    end
    return {"type": "text", "text": "Attached file \"" + attachment["name"] + "\":\n" + fence + "\n" + attachment["text"] + "\n" + fence + note}
end

function check_limits(current, kind):
    if len(current) >= MAX_ATTACHMENTS:
        return i18n.translate("At most {0} attachments can be added to one message.").replace("{0}", "8")
    end
    count = 0
    for attachment in current:
        if attachment["kind"] == "image":
            count += 1
        end
    end
    if kind == "image" and count >= MAX_IMAGES:
        return i18n.translate("At most {0} images can be added to one message.").replace("{0}", "4")
    end
    return None
end

function user_message(text, attachments):
    text = common.text(text)
    if not attachments:
        return {"role": "user", "content": text}
    end
    parts = []
    if common.strip_text(text):
        parts.append({"type": "text", "text": text})
    end
    for attachment in attachments:
        if attachment["kind"] == "text":
            parts.append(text_part(attachment))
        end
    end
    for attachment in attachments:
        if attachment["kind"] == "image":
            parts.append({"type": "image_url", "image_url": {"url": attachment["url"]}})
        end
    end
    metadata = []
    for attachment in attachments:
        metadata.append({"kind": attachment["kind"], "name": common.text(attachment.get("name"))})
    end
    return {"role": "user", "content": parts, "_text": text, "_attachments": metadata}
end

function message_parts(message):
    content = message.get("content")
    if type(content) == "String":
        return [content, [], []]
    end
    images = []
    files = []
    text = protocol.message_text(message)
    for part in common.fallback(content, []):
        if type(part) == "Dictionary" and part.get("type") == "image_url" and type(part.get("image_url")) == "Dictionary":
            images.append(part["image_url"].get("url", ""))
        end
    end
    for attachment in common.fallback(message.get("_attachments"), []):
        if attachment.get("kind") == "text":
            files.append(attachment.get("name", ""))
        end
    end
    return [text, images, files]
end
