# lsl: internal-abi
load common
load platform
load glib
load gtk
load gtk_ext
load images
load feedback
load child_process
load ui_dispatch
load time

function find_program(name):
    return glib.take_c(__lsl_qbe_call1(__lsl_symbol("g_find_program_in_path"), platform.cstr(name)))
end

function shot_dir():
    return common.join(common.environment("XDG_CACHE_HOME", common.join(glib.home_dir(), ".cache")), "luxai/screenshots")
end

function grab(state, arguments):
    root = __lsl_qbe_call0(__lsl_symbol("gdk_get_default_root_window"))
    if root == 0:
        return {"image": 0, "width": 0, "height": 0}
    end
    width = __lsl_qbe_call1(__lsl_symbol("gdk_window_get_width"), root)
    height = __lsl_qbe_call1(__lsl_symbol("gdk_window_get_height"), root)
    image = __lsl_qbe_call5(__lsl_symbol("gdk_pixbuf_get_from_window"), root, 0, 0, width, height)
    return {"image": image, "width": width, "height": height}
end

function screenshot(state):
    capture = ui_dispatch.call_main(grab, state)
    image = capture["image"]
    call common.mkdir_private(shot_dir())
    path = common.join(shot_dir(), platform.format_time(Int(time.time()), "shot-%Y%m%d-%H%M%S.png"))
    if not image:
        program = find_program("grim")
        args = [path]
        if not program:
            program = find_program("import")
            args = ["-window", "root", path]
        end
        if program:
            call child_process.run([program] + args, None, None, 20)
        end
        if not exists(path):
            Error(ToolError: "Could not capture the screen")
        end
        image = gtk.pixbuf_new_from_file(path)
        if not image:
            Error(ToolError: "Could not capture the screen")
        end
    else:
        error = platform.buffer(8)
        success = __lsl_qbe_call6(__lsl_symbol("gdk_pixbuf_savev"), platform.pointer(image), platform.cstr(path), platform.cstr("png"), 0, 0, platform.address(error))
        call images.clear_error(error)
        if not success:
            call glib.object_unref(image)
            Error(ToolError: "Could not save the screenshot")
        end
    end
    call platform.chmod(path, 384)
    width = gtk.pixbuf_get_width(image)
    height = gtk.pixbuf_get_height(image)
    scale = min(1.0, 1280.0 / max(1, width))
    small = images.scale(image, max(1, Int(width * scale)), max(1, Int(height * scale)))
    bytes = images.jpeg_bytes(small, "80")
    call glib.object_unref(small)
    call glib.object_unref(image)
    return {"path": path, "width": width, "height": height, "data_url": "data:image/jpeg;base64," + common.base64_encode(bytes)}
end

function report_screenshot(state):
    capture = ui_dispatch.call_main(grab, state)
    image = capture["image"]
    if not image:
        Error(ToolError: "Could not capture the screen")
    end
    width = gtk.pixbuf_get_width(image)
    height = gtk.pixbuf_get_height(image)
    bytes = ByteArray()
    for choice in [[feedback.SHOT_WIDTH, "75"], [1024, "60"], [800, "50"]]:
        scale = min(1.0, Float(choice[0]) / max(1, width))
        small = images.scale(image, max(1, Int(width * scale)), max(1, Int(height * scale)))
        bytes = images.jpeg_bytes(small, choice[1])
        call glib.object_unref(small)
        if bytes and len(bytes) * 4 / 3 < feedback.SHOT_MAX:
            break
        end
    end
    call glib.object_unref(image)
    if not bytes:
        Error(ToolError: "Could not capture the screen")
    end
    return {"data_url": "data:image/jpeg;base64," + common.base64_encode(bytes), "width": width, "height": height}
end

function read_clipboard(state, arguments):
    return gtk_ext.clipboard_text()
end

function clipboard_text(state):
    try:
        return ui_dispatch.call_main(read_clipboard, state)
    else:
        return None
    end
end

function show_notification(state, arguments):
    application = state.get("application", 0)
    if not application:
        return
    end
    notification = __lsl_qbe_call1(__lsl_symbol("g_notification_new"), platform.cstr(arguments[0]))
    call __lsl_qbe_call2(__lsl_symbol("g_notification_set_body"), notification, platform.cstr(arguments[1]))
    # stejne id jako Python ("luxai-run"): nove oznameni nahradi predchozi
    call __lsl_qbe_call3(__lsl_symbol("g_application_send_notification"), platform.pointer(application), platform.cstr("luxai-run"), notification)
    call glib.object_unref(notification)
end

function notify(state, title, body):
    call ui_dispatch.call_main(show_notification, state, [title, body])
end

function screen_size():
    screen = __lsl_qbe_call0(__lsl_symbol("gdk_screen_get_default"))
    if screen == 0:
        return ""
    end
    width = __lsl_qbe_call1(__lsl_symbol("gdk_screen_get_width"), screen)
    height = __lsl_qbe_call1(__lsl_symbol("gdk_screen_get_height"), screen)
    return String(width) + "x" + String(height) + " px"
end

function new_bridge(application=0):
    return {"application": application, "screenshot": screenshot, "report_screenshot": report_screenshot, "clipboard_text": clipboard_text, "notify": notify}
end

function persist_clipboard(state, text):
    try:
        call child_process.run([state["program"], "-selection", "clipboard", "-i"], None, None, 5, None, text)
    else:
        return
    end
end

function copy_text(text):
    call gtk_ext.copy(text)
    if common.environment("DISPLAY") and common.environment("XDG_SESSION_TYPE") != "wayland" and common.environment("GDK_BACKEND") != "broadway":
        program = glib.find_program_in_path("xclip")
        if program:
            call ui_dispatch.background(persist_clipboard, {"program": program}, text)
        end
    end
end
