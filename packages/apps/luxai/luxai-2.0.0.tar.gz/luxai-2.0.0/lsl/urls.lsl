load common
load platform
load net_address

function split(url):
    url = String(url)
    while url and ord(url[0]) <= 32:
        url = url[1:]
    end
    url = url.replace("\t", "").replace("\r", "").replace("\n", "")
    scheme = ""
    matches = platform.regex_findall("^([A-Za-z][A-Za-z0-9+.-]*):", url)
    if matches:
        scheme = matches[0]["groups"][1].lower()
        url = url[matches[0]["end"]:]
    end
    fragment = ""
    has_fragment = "#" in url
    if "#" in url:
        index = url.find("#")
        fragment = url[index + 1:]
        url = url[:index]
    end
    query = ""
    has_query = "?" in url
    if has_query:
        index = url.find("?")
        query = url[index + 1:]
        url = url[:index]
    end
    authority = ""
    host = ""
    port_text = None
    userinfo = None
    if url.startswith("//"):
        index = url.find("/", 2)
        if index < 0:
            authority = url[2:]
            url = ""
        else:
            authority = url[2:index]
            url = url[index:]
        end
        address = authority
        if "@" in address:
            index = common.rfind(address, "@")
            userinfo = address[:index]
            address = address[index + 1:]
        end
        if address.startswith("["):
            index = address.find("]")
            if index < 0:
                Error(WebError: "Invalid IPv6 URL")
            end
            host = address[1:index]
            if net_address.ip(host) == None and not platform.regex_test("^v[0-9a-fA-F]+\\..+", host):
                Error(WebError: "Invalid IPv6 URL")
            end
            remainder = address[index + 1:]
            if remainder.startswith(":"):
                port_text = remainder[1:]
            end
        else:
            index = address.find(":")
            host = address
            if index >= 0:
                host = address[:index]
                port_text = address[index + 1:]
            end
        end
    end
    port = None
    if port_text != None and port_text != "":
        if not platform.regex_test("^[0-9]+$", port_text):
            Error(WebError: "Invalid port in URL")
        end
        port = Int(port_text)
        if port < 0 or port > 65535:
            Error(WebError: "Invalid port in URL")
        end
    end
    return {"scheme": scheme, "netloc": authority, "host": host.lower(), "port": port, "userinfo": userinfo, "path": url, "query": query, "has_query": has_query, "fragment": fragment, "has_fragment": has_fragment}
end

function check(url):
    url = String(common.fallback(url, "")).strip(common.WHITESPACE)
    if not url:
        Error(WebError: "Empty URL")
    end
    if len(url) > 4000:
        Error(WebError: "URL is too long")
    end
    if "\0" in url:
        Error(WebError: "Invalid host name")
    end
    parsed = split(url)
    if parsed["scheme"] not in ["http", "https"]:
        Error(WebError: "Only http:// and https:// URLs can be fetched")
    end
    if parsed["userinfo"] != None or "@" in parsed["netloc"]:
        Error(WebError: "URLs with user names or passwords are not allowed")
    end
    if not parsed["host"]:
        Error(WebError: "URL has no host")
    end
    if platform.regex_test("[ \\t\\r\\n\\\\]", parsed["host"]):
        Error(WebError: "Invalid host name")
    end
    normalized = platform.unicode_normalize(parsed["netloc"])
    for char in "/?#@:":
        if char not in parsed["netloc"] and char in normalized:
            Error(WebError: "Invalid host name")
        end
    end
    if not parsed["port"]:
        parsed["port"] = 80
        if parsed["scheme"] == "https":
            parsed["port"] = 443
        end
    end
    parsed["path"] = common.fallback(parsed["path"], "/")
    path = parsed["path"]
    if parsed["query"]:
        path += "?" + parsed["query"]
    end
    return [parsed["scheme"], parsed["host"], parsed["port"], path]
end

function authority(parsed, include_user=True):
    host = parsed["host"]
    if ":" in host:
        host = "[" + host + "]"
    end
    if parsed["port"]:
        host += ":" + String(parsed["port"])
    end
    if include_user and parsed["userinfo"] != None:
        host = parsed["userinfo"] + "@" + host
    end
    return host
end

function compose(parsed, fragment=True, preserve_empty=False):
    text = ""
    if parsed["scheme"]:
        text += parsed["scheme"] + ":"
    end
    if parsed["netloc"]:
        text += "//" + parsed["netloc"]
    end
    text += parsed["path"]
    if parsed["query"] or (preserve_empty and parsed.get("has_query")):
        text += "?" + parsed["query"]
    end
    if fragment and (parsed["fragment"] or (preserve_empty and parsed.get("has_fragment"))):
        text += "#" + parsed["fragment"]
    end
    return text
end

function normalize(url):
    try:
        parsed = split(String(common.fallback(url, "")).strip(common.WHITESPACE))
        if parsed["scheme"] not in ["http", "https"] or not parsed["host"]:
            return ""
        end
        parsed["netloc"] = authority(parsed)
        parsed["path"] = common.fallback(parsed["path"], "/")
        return compose(parsed, False)
    else:
        return ""
    end
end

function join(base, href):
    if not href:
        return base
    end
    original = split(base)
    target = split(href)
    if target["scheme"] and target["scheme"] != original["scheme"]:
        return href
    end
    target["scheme"] = common.fallback(target["scheme"], original["scheme"])
    if target["netloc"]:
        return compose(target, True, True)
    end
    target["netloc"] = original["netloc"]
    if not target["path"]:
        target["path"] = original["path"]
        if not target["has_query"]:
            target["query"] = original["query"]
            target["has_query"] = original["has_query"]
        end
        return compose(target, True, True)
    end
    parts = target["path"].split("/")
    if not target["path"].startswith("/"):
        parent = original["path"].split("/")
        parts = parent[:len(parent) - 1] + parts
        filtered = []
        for index in rang(len(parts)):
            if index == 0 or index == len(parts) - 1 or parts[index]:
                filtered.append(parts[index])
            end
        end
        parts = filtered
    end
    resolved = []
    for part in parts:
        if part == "..":
            if resolved:
                call resolved.pop()
            end
        elif part != ".":
            resolved.append(part)
        end
    end
    if parts and parts[len(parts) - 1] in [".", ".."]:
        resolved.append("")
    end
    target["path"] = "/".join(resolved)
    if not target["path"].startswith("/"):
        target["path"] = "/" + target["path"]
    end
    return compose(target, True, True)
end

function unquote(text, plus=False):
    output = ByteArray()
    index = 0
    while index < len(text):
        char = text[index]
        if plus and char == "+":
            output.append(32)
        elif char == "%" and index + 2 < len(text) and platform.regex_test("^[0-9a-fA-F]{2}$", text[index + 1:index + 3]):
            high = "0123456789abcdef".find(text[index + 1].lower())
            low = "0123456789abcdef".find(text[index + 2].lower())
            output.append(high * 16 + low)
            index += 2
        else:
            for byte in platform.utf8_bytes(char):
                output.append(byte)
            end
        end
        index += 1
    end
    return platform.utf8_decode(output)
end

function quote_plus(text):
    output = []
    hex = "0123456789ABCDEF"
    for byte in platform.utf8_bytes(text):
        if byte == 32:
            output.append("+")
        elif (byte >= 65 and byte <= 90) or (byte >= 97 and byte <= 122) or (byte >= 48 and byte <= 57) or byte in [45, 95, 46, 126]:
            output.append(chr(byte))
        else:
            output.append("%" + hex[byte // 16] + hex[byte % 16])
        end
    end
    return "".join(output)
end
