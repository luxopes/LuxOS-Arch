# Native permission assessments. No tools or commands execute in this module.
load common
load platform
load glib
load rootguard
load rootmode
load safety_data
load guard_data
load shellwords
load settings
load web
load calendar_data

function assessment(level="safe", reasons=None):
    return {"level": level, "reasons": common.fallback(reasons, [])}
end

function raise_to(value, level, reason=None):
    if safety_data.ORDER[level] > safety_data.ORDER[value["level"]]:
        value["level"] = level
    end
    if reason and reason not in value["reasons"]:
        value["reasons"].append(reason)
    end
    return value
end

function expand(path, workdir=None, home=None):
    home = common.fallback(home, glib.home_dir())
    path = String(common.fallback(path, "")).strip(common.WHITESPACE)
    if "\0" in path:
        Error(ValueError: "embedded null byte")
    end
    if path == "~" or path.startswith("~/"):
        path = home + path[1:]
    end
    path = path.replace("$HOME", home).replace("${HOME}", home)
    if not path.startswith("/"):
        path = common.join(common.fallback(workdir, home), path)
    end
    return common.normalize(path)
end

function dirname(path):
    if path == "/":
        return "/"
    end
    return common.dirname(path)
end

function account_paths(home):
    xdg = common.environment("XDG_CONFIG_HOME", common.join(home, ".config"))
    return [common.normalize(common.join(xdg, "luxai/account.json")), common.normalize(common.join(home, ".config/luxai/account.json"))]
end

function path_assessment(tool, path, workdir=None, home=None):
    home = common.normalize(common.fallback(home, glib.home_dir()))
    result = assessment("ask")
    if tool in safety_data.FILE_READ_TOOLS:
        result["level"] = "safe"
    end
    path = expand(path, workdir, home)
    credentials = account_paths(home)
    blocked = path in credentials
    if tool in safety_data.FILE_WRITE_TOOLS:
        for account in credentials:
            if account.startswith(path + "/") or dirname(account) == dirname(path):
                blocked = True
            end
        end
    end
    if blocked:
        return raise_to(result, "block", "LuxAI account credentials are never read or changed by the agent")
    end
    relative = path
    if path.startswith(home + "/"):
        relative = path[len(home) + 1:]
    end
    secret = platform.regex_test(safety_data.SECRET_NAMES, path)
    for part in safety_data.SECRET_PARTS:
        if "/" + part + "/" in "/" + relative + "/":
            secret = True
        end
    end
    if secret:
        level = "danger"
        if tool in safety_data.FILE_READ_TOOLS:
            level = "sensitive"
        end
        call raise_to(result, level, "the path may contain passwords or keys")
    end
    if tool in safety_data.FILE_WRITE_TOOLS:
        if path in ["/", home, dirname(home), "/home"]:
            return raise_to(result, "block", "refusing to modify the root or home directory itself")
        end
        if not (path == home or path.startswith(home + "/") or path.startswith("/tmp/") or path.startswith("/var/tmp/")):
            call raise_to(result, "danger", "the path is outside your home folder (system files)")
        end
        if rootguard.base(path) in [".bashrc", ".bash_profile", ".profile", ".zshrc", ".xinitrc", ".xprofile"] or relative.startswith(".config/autostart") or relative.startswith(".config/systemd"):
            call raise_to(result, "danger", "the file is run automatically at login")
        end
    end
    return result
end

function split_commands(command):
    parsed = shellwords.split(command, ";&|()")
    items = parsed["tokens"]
    if not parsed["parsed"]:
        items = common.split_words(command)
    end
    output = []
    current = []
    for token in items:
        if token in safety_data.SEPARATORS or shellwords.all_in(token, ";&|()"):
            if current:
                output.append(current)
            end
            current = []
        else:
            current.append(token)
        end
    end
    if current:
        output.append(current)
    end
    return output
end

function strip_prefix(items):
    i = 0
    while i < len(items):
        token = items[i]
        name = rootguard.base(token)
        if platform.regex_test("^[A-Za-z_][A-Za-z0-9_]*=", token):
            i += 1
        elif name in safety_data.PREFIX_CMDS or name in safety_data.PRIV:
            i += 1
            while i < len(items) and items[i].startswith("-"):
                i += 1
            end
            if name == "timeout" and i < len(items):
                i += 1
            end
        else:
            break
        end
    end
    return items[i:]
end

function uses_privilege(items):
    for token in items:
        name = rootguard.base(token)
        if name in safety_data.PRIV:
            return True
        end
        if platform.regex_test("^[A-Za-z_][A-Za-z0-9_]*=", token) or token.startswith("-") or name in safety_data.PREFIX_CMDS or platform.regex_test("^\\d+(\\.\\d+)?[smhd]?$", token):
            continue
        end
        return False
    end
    return False
end

function command_assessment(command, workdir=None, home=None, root=False):
    home = common.normalize(common.fallback(home, glib.home_dir()))
    result = assessment("ask")
    text = common.fallback(command, "")
    low = text.lower()
    privileged = root or platform.regex_test(safety_data.PRIV_ANYWHERE, text)
    for raw in split_commands(text):
        if uses_privilege(raw):
            privileged = True
        end
    end
    if root:
        call raise_to(result, "danger", safety_data.ADMIN_REASON)
    end
    hard = rootguard.hard_block(text, privileged, workdir, home)
    if hard:
        call raise_to(result, "block", hard)
    end
    if platform.regex_test(":\\s*\\(\\s*\\)\\s*\\{[^}]*:\\s*\\|\\s*:", text):
        call raise_to(result, "danger", "fork bomb")
    end
    if platform.regex_test("(curl|wget|fetch)\\b[^|;&]*\\|\\s*(sudo\\s+)?(ba|z|da|k)?sh\\b", low) or platform.regex_test("\\b(ba|z)?sh\\s+(-c\\s+)?[\"']?\\$\\((curl|wget)", low):
        call raise_to(result, "danger", "runs a script downloaded from the internet")
    end
    if platform.regex_test(">\\s*/dev/(sd|nvme|mmcblk|vd|hd)", low):
        call raise_to(result, "danger", "writes directly to a disk device")
    end
    if platform.regex_test(">\\s*/(etc|boot|usr|bin|lib|sbin)/", low):
        call raise_to(result, "danger", "overwrites system files")
    end
    if ("account.json" in low and "luxai" in low) or platform.regex_test("luxos-account\\s+token", low):
        call raise_to(result, "danger", "accesses the LuxAI account token")
    elif ".config/luxai" in low or "luxai/settings.json" in low:
        call raise_to(result, "danger", "accesses LuxAI settings (including agent permissions)")
    end
    if platform.regex_test("(^|/|\\s)\\.ssh/|id_(rsa|ed25519|ecdsa)|\\.gnupg|/etc/shadow|\\.password-store", low):
        call raise_to(result, "danger", "accesses private keys or passwords")
    end
    if platform.regex_test(safety_data.PRIV_ANYWHERE, text):
        call raise_to(result, "danger", safety_data.ADMIN_REASON)
    end
    if rootguard.feeds_password(text):
        call raise_to(result, "block", guard_data.R_PASSWORD)
    end
    for raw in split_commands(text):
        if uses_privilege(raw):
            call raise_to(result, "danger", safety_data.ADMIN_REASON)
        end
        items = strip_prefix(raw)
        if not items:
            continue
        end
        name = rootguard.base(items[0])
        args = items[1:]
        flags = ""
        long_flags = []
        paths = []
        for argument in args:
            if argument.startswith("--"):
                long_flags.append(argument)
            elif argument.startswith("-"):
                flags += argument[1:]
            else:
                paths.append(argument)
            end
        end
        if name == "rm":
            recursive = "r" in flags.lower() or "--recursive" in long_flags
            for target in paths:
                normal = common.fallback(target.rstrip("/"), "/")
                path = expand(target, workdir, home)
                if target in safety_data.CRITICAL_TARGETS or normal in safety_data.CRITICAL_TARGETS or path in ["/", home, "/home"] or (recursive and (path == dirname(home) or path.count("/") <= 1)):
                    call raise_to(result, "danger", "deletes the whole home folder or system")
                elif recursive and path.startswith(home + "/") and path.count("/") <= home.count("/") + 1 and rootguard.base(path) in ["Documents", "Desktop", "Pictures", "Music", "Videos", "Downloads", ".config", ".local", "Dokumenty", "Plocha", "Obrázky", "Hudba", "Videa", "Stažené"]:
                    call raise_to(result, "danger", "recursively deletes a main personal folder")
                elif recursive and not path.startswith(home + "/") and not path.startswith("/tmp/"):
                    call raise_to(result, "danger", "recursively deletes files outside your home folder")
                end
            end
            if "--no-preserve-root" in long_flags:
                call raise_to(result, "danger", "deletes the whole home folder or system")
            end
        elif name.split(".")[0] in safety_data.DISK or name.startswith("mkfs"):
            call raise_to(result, "danger", "formats or wipes a disk")
        elif name == "dd":
            for argument in args:
                if argument.startswith("of=") and (platform.regex_test(safety_data.DEVICE, argument) or argument[3:].startswith("/dev/sd")):
                    call raise_to(result, "danger", "writes directly to a disk device")
                end
            end
        elif name in safety_data.POWER or (name == "init" and paths and paths[0] in ["0", "6"]) or name == "telinit":
            call raise_to(result, "danger", "shuts down or restarts the computer")
        elif name == "systemctl" and rootguard.intersects(args, ["poweroff", "reboot", "halt", "kexec", "suspend", "hibernate", "hybrid-sleep", "rescue", "emergency", "isolate"]):
            call raise_to(result, "danger", "shuts down or restarts the computer")
        elif name == "loginctl" and rootguard.intersects(args, ["terminate-session", "terminate-user", "kill-session", "kill-user", "poweroff", "reboot"]):
            call raise_to(result, "danger", "ends your desktop session")
        elif name in ["kill", "pkill", "killall"] and ("-1" in args or (paths and paths[len(paths) - 1] == "1") or rootguard.intersects(args, ["Xorg", "xfce4-session", "systemd", "init", "-u"])):
            call raise_to(result, "danger", "kills all processes or the desktop session")
        elif name in ["chmod", "chown", "chgrp", "setfacl"] and ("R" in flags or "--recursive" in long_flags):
            for target in paths:
                path = expand(target, workdir, home)
                if target in safety_data.CRITICAL_TARGETS or path in ["/", home, "/home"] or not path.startswith(home + "/"):
                    call raise_to(result, "danger", "changes permissions of the whole home folder or system")
                end
            end
        elif name == "find" and ("-delete" in args or ("-exec" in args and "rm" in args)):
            start = "."
            if paths:
                start = paths[0]
            end
            path = expand(start, workdir, home)
            if path in ["/", home, "/home"] or not path.startswith(home + "/"):
                call raise_to(result, "danger", "deletes files across the whole home folder or system")
            end
        elif name == "mv" and paths:
            for target in paths[:len(paths) - 1]:
                if expand(target, workdir, home) in ["/", home, "/home"]:
                    call raise_to(result, "danger", "moves the whole home folder or system")
                end
            end
        elif name == "crontab" and "r" in flags:
            call raise_to(result, "danger", "deletes all scheduled tasks")
        elif name == "git" and "push" in args and ("--force" in long_flags or "f" in flags or "--mirror" in long_flags):
            call raise_to(result, "danger", "force-pushes and may overwrite remote history")
        elif name == "git" and "clean" in args and "f" in flags and "x" in flags.lower():
            call raise_to(result, "danger", "deletes all untracked files in the repository")
        elif name in ["pacman", "yay", "paru"]:
            for argument in args:
                if argument.startswith("-R"):
                    call raise_to(result, "danger", "removes installed system packages")
                end
            end
        elif name == "lux" and rootguard.intersects(args, ["--system", "--aur", "--community"]):
            call raise_to(result, "danger", "installs community (AUR) code, which is not checked by LuxOS")
        elif name == "truncate":
            for target in paths:
                if platform.regex_test(safety_data.DEVICE, target):
                    call raise_to(result, "danger", "writes directly to a disk device")
                end
            end
        elif name == "chattr" and "i" in "".join(args):
            call raise_to(result, "danger", "changes immutable file attributes")
        elif name in ["passwd", "usermod", "userdel", "chpasswd", "visudo"]:
            call raise_to(result, "danger", "changes user accounts or passwords")
        elif name in ["iptables", "nft", "ufw"] and rootguard.intersects(args, ["-F", "flush", "--flush", "disable", "reset"]):
            call raise_to(result, "danger", "removes firewall rules")
        end
    end
    return result
end

function assess(name, arguments, workdir=None, home=None):
    args = arguments
    if type(args) != "Dictionary":
        args = {}
    end
    if name == "run_command":
        return command_assessment(String(args.get("command", "")), workdir, home, rootmode.flag(args.get("root")))
    end
    if name in safety_data.FILE_READ_TOOLS or name in safety_data.FILE_WRITE_TOOLS:
        result = path_assessment(name, common.fallback(args.get("path"), "."), workdir, home)
        if name == "move_file":
            destination = path_assessment(name, common.fallback(args.get("destination"), "."), workdir, home)
            call raise_to(result, destination["level"])
            for reason in destination["reasons"]:
                call raise_to(result, destination["level"], reason)
            end
        end
        if name == "search_text" and result["level"] == "safe":
            path = expand(common.fallback(args.get("path"), "."), workdir, home)
            if path in ["/", dirname(common.normalize(common.fallback(home, glib.home_dir())))]:
                call raise_to(result, "ask", "searches the whole system")
            end
        end
        return result
    end
    if name in calendar_data.READ_TOOLS:
        # kalendar LuxOS: cteni bez dotazu (i v Chatu), kazda zmena se potvrzuje kartou (ask)
        return assessment()
    end
    if name in calendar_data.WRITE_TOOLS:
        return assessment("ask", [calendar_data.REASONS[name]])
    end
    if name in safety_data.ALWAYS_CONFIRM_TOOLS:
        return assessment("sensitive", ["sends the report and attachments shown in this card to the author of LuxOS"])
    end
    if name in safety_data.READ_TOOLS:
        return assessment()
    end
    if name == "type_text":
        result = assessment("ask")
        text = String(args.get("text", ""))
        inner = command_assessment(text, workdir, home)
        if rootguard.feeds_password(text):
            call raise_to(result, "block", guard_data.R_PASSWORD)
        end
        if inner["level"] in ["block", "danger"] and platform.regex_test("[a-z]", text):
            if inner["level"] == "danger":
                call raise_to(result, "danger", "types a dangerous command")
            end
            for reason in inner["reasons"]:
                call raise_to(result, inner["level"], reason)
            end
        end
        return result
    end
    if name == "press_key":
        keys = String(args.get("keys", "")).lower().replace(" ", "")
        if platform.regex_test("ctrl\\+alt\\+(delete|backspace|del)", keys):
            return assessment("danger", ["the key combination may end your session"])
        end
    end
    if name == "open_url":
        url = String(args.get("url", "")).strip(common.WHITESPACE).lower()
        if platform.regex_test("^(javascript|data|vbscript):", url):
            return assessment("block", ["unsupported URL type"])
        end
    end
    return assessment("ask")
end

function real(path, seen=None, depth=0):
    if seen == None:
        seen = {}
    end
    if depth > 40:
        return common.normalize(path)
    end
    resolved = "/"
    for part in path.split("/"):
        if part == "" or part == ".":
            continue
        end
        if part == "..":
            resolved = dirname(resolved)
            continue
        end
        candidate = common.join(resolved, part)
        info = platform.file_info(candidate, False)
        if info != None and info["symlink"]:
            if candidate in seen:
                if seen[candidate] == None:
                    resolved = candidate
                else:
                    resolved = seen[candidate]
                end
                continue
            end
            target = platform.readlink(candidate)
            if target != None:
                seen[candidate] = None
                if not target.startswith("/"):
                    target = common.join(resolved, target)
                end
                resolved = real(target, seen, depth + 1)
                seen[candidate] = resolved
                continue
            end
        end
        resolved = candidate
    end
    return resolved
end

function inside(path, folder):
    return path == folder or path.startswith(folder.rstrip("/") + "/")
end

function folders(items, home):
    output = []
    for item in common.fallback(items, []):
        path = real(expand(item, home, home))
        if path not in output:
            output.append(path)
        end
    end
    return output
end

function path_permission(path, policy, workdir=None, home=None):
    home = common.normalize(common.fallback(home, glib.home_dir()))
    path = real(expand(common.fallback(path, "."), workdir, home))
    for blocked in folders(policy.get("blocked_folders"), home):
        if inside(path, blocked):
            return "the folder is blocked in LuxAI settings"
        end
    end
    allowed = folders(policy.get("allowed_folders"), home)
    if allowed:
        for folder in allowed:
            if inside(path, folder):
                return None
            end
        end
        return "the path is outside the folders allowed in LuxAI settings"
    end
    return None
end

function folder_violation(name, args, workdir, home, policy):
    if not policy.get("allowed_folders") and not policy.get("blocked_folders"):
        return None
    end
    home = common.normalize(common.fallback(home, glib.home_dir()))
    if name in safety_data.FILE_READ_TOOLS or name in safety_data.FILE_WRITE_TOOLS:
        paths = [common.fallback(args.get("path"), ".")]
        if name == "move_file":
            paths.append(common.fallback(args.get("destination"), "."))
        end
        for path in paths:
            reason = path_permission(path, policy, workdir, home)
            if reason:
                return reason
            end
        end
        return None
    end
    if name == "open_url":
        url = String(args.get("url", "")).strip(common.WHITESPACE)
        if url.lower().startswith("file:"):
            url = "/" + url[5:].lstrip("/")
        elif platform.regex_test("(?i)^[a-z][a-z0-9+.-]*:", url):
            return None
        end
        return path_permission(url, policy, workdir, home)
    end
    if name == "run_command":
        cwd = common.fallback(args.get("cwd"), workdir)
        reason = path_permission(common.fallback(cwd, home), policy, workdir, home)
        if reason:
            return reason
        end
        blocked = folders(policy.get("blocked_folders"), home)
        if blocked:
            text = String(args.get("command", ""))
            for items in split_commands(text):
                for token in items:
                    if token.startswith("--") and "=" in token:
                        token = token[token.find("=") + 1:]
                    end
                    if not token or token.startswith("-"):
                        continue
                    end
                    relative = expand(token, cwd, home)
                    if platform.regex_test(safety_data.PATHISH, token) or "/" in token or platform.file_info(relative, False) != None:
                        path = real(relative)
                        for folder in blocked:
                            if inside(path, folder):
                                return "the folder is blocked in LuxAI settings"
                            end
                        end
                    end
                end
            end
            for folder in blocked:
                short = ""
                if folder.startswith(home + "/"):
                    short = "~" + folder[len(home):]
                end
                if folder in text or (short and short in text):
                    return "the folder is blocked in LuxAI settings"
                end
            end
        end
    end
    return None
end

function command_uses_network(command):
    text = String(common.fallback(command, ""))
    if platform.regex_test(safety_data.URL, text):
        return True
    end
    for raw in split_commands(text):
        items = strip_prefix(raw)
        if not items:
            continue
        end
        name = rootguard.base(items[0])
        args = items[1:]
        if name in safety_data.NET_CMDS:
            return True
        end
        if name in safety_data.NET_SUB and rootguard.intersects(args, safety_data.NET_SUB[name]):
            return True
        end
        if name in ["pacman", "yay", "paru"]:
            for argument in args:
                if argument.startswith("-S") or (argument.startswith("-U") and "://" in text):
                    return True
                end
            end
        end
        if name == "rsync":
            for argument in args:
                if ":" in argument and not argument.startswith("-"):
                    return True
                end
            end
        end
        if name in ["python", "python3"] and "-m" in args and rootguard.intersects(args, ["http.server", "pip"]):
            return True
        end
    end
    return False
end

function is_network_action(name, args):
    if name == "run_command":
        return command_uses_network(args.get("command", ""))
    end
    if name == "open_url":
        return platform.regex_test("(?i)^\\s*(https?|ftp)://", String(args.get("url", "")))
    end
    return name in ["send_feedback", "web_fetch"]
end

function is_read_only_command(command):
    text = String(common.fallback(command, "")).strip(common.WHITESPACE)
    if not text or "\n" in text:
        return False
    end
    text = platform.regex_replace("\\s(2>&1|2>\\s*/dev/null|>\\s*/dev/null|&>\\s*/dev/null)(?=\\s|$)", " ", " " + text).strip(common.WHITESPACE)
    if platform.regex_test("[<>`]|\\$\\(|\\$\\{|\\|&|&\\s*$", text):
        return False
    end
    if command_assessment(text)["level"] != "ask" or command_uses_network(text):
        return False
    end
    commands = split_commands(text)
    if not commands:
        return False
    end
    for raw in commands:
        if platform.regex_test("^[A-Za-z_][A-Za-z0-9_]*=", raw[0]):
            return False
        end
        name = rootguard.base(raw[0])
        args = raw[1:]
        if name in safety_data.READ_ONLY_SUB:
            if not args or args[0] not in safety_data.READ_ONLY_SUB[name]:
                return False
            end
            continue
        end
        if name not in safety_data.READ_ONLY_CMDS:
            return False
        end
        if name == "find" and rootguard.intersects(args, ["-delete", "-exec", "-execdir", "-ok", "-okdir", "-fprint", "-fprint0", "-fprintf", "-fls"]):
            return False
        end
        for argument in args:
            if name == "sort" and (argument == "-o" or argument.startswith("--output") or (argument.startswith("-") and not argument.startswith("--") and "o" in argument)):
                return False
            end
            if name in ["date", "hostname"] and not argument.startswith("+") and not argument.startswith("-"):
                return False
            end
            if name == "date" and (argument == "-s" or argument.startswith("--set")):
                return False
            end
            if name == "journalctl" and (argument.startswith("--vacuum") or argument in ["--rotate", "--flush"]):
                return False
            end
            if name == "dmesg" and argument in ["-c", "-C", "--clear", "--read-clear"]:
                return False
            end
        end
        if name == "top" and "-b" not in args:
            return False
        end
        if name in ["less", "more"]:
            return False
        end
    end
    return True
end

function web_tainted(messages):
    web_ids = []
    for message in common.fallback(messages, []):
        if type(message) != "Dictionary":
            continue
        end
        if message.get("role") == "assistant":
            for tool_call in common.fallback(message.get("tool_calls"), []):
                if type(tool_call) == "Dictionary" and type(tool_call.get("function")) == "Dictionary" and tool_call["function"].get("name") in safety_data.WEB_TOOLS:
                    web_ids.append(tool_call.get("id"))
                end
            end
        elif message.get("role") == "tool" and message.get("tool_call_id") in web_ids:
            return True
        end
    end
    return False
end

function new_permissions(auto_approve=False, policy=None):
    return {"auto_approve": auto_approve, "always": [], "policy": settings.normalize_policy(policy), "model": "flash", "judge": judge, "remember": remember, "fetch_trusted": web.permission_trust}
end

function set_policy(state, policy):
    state["policy"] = settings.normalize_policy(policy)
end

function hidden_tools(state):
    output = []
    for name in safety_data.TOOL_CATEGORY.keys():
        if state["policy"].get(safety_data.TOOL_CATEGORY[name]) == "never":
            output.append(name)
        end
    end
    return output
end

function decision(action, result):
    return {"action": action, "level": result["level"], "reasons": result["reasons"]}
end

function decide_base(state, name, args, workdir=None, home=None, mode="agent"):
    if type(args) != "Dictionary":
        args = {}
    end
    result = assess(name, args, workdir, home)
    if result["level"] == "block":
        return decision("block", result)
    end
    policy = state["policy"]
    category = safety_data.TOOL_CATEGORY.get(name)
    level = policy.get(category)
    net = is_network_action(name, args) and not (mode != "agent" and name in safety_data.WEB_TOOLS)
    if level == "never":
        return decision("block", raise_to(result, "block", safety_data.CATEGORY_REASON[category]))
    end
    if net and policy["network"] == "never":
        return decision("block", raise_to(result, "block", "network access is turned off in LuxAI settings"))
    end
    reason = folder_violation(name, args, workdir, home, policy)
    if reason:
        return decision("block", raise_to(result, "block", reason))
    end
    if name == "run_command" and rootmode.flag(args.get("root")) and result["level"] == "danger" and result["reasons"] == [safety_data.ADMIN_REASON] and not platform.regex_test(safety_data.PRIV_ANYWHERE, String(args.get("command", ""))):
        root_mode = rootmode.effective_mode(policy, state["model"])
        if root_mode == "noask":
            return decision("allow", result)
        end
        if root_mode == "nopass":
            return decision("confirm", result)
        end
    end
    if result["level"] == "danger":
        return decision("danger", result)
    end
    if result["level"] == "sensitive":
        return decision("confirm", result)
    end
    action = "ask"
    if result["level"] == "safe" and category != "read_files":
        action = "allow"
    elif level == None:
        if result["level"] == "safe":
            action = "allow"
        end
    elif level == "allow":
        if category != "read_files" or result["level"] != "ask":
            action = "allow"
        end
    elif level == "risky":
        if is_read_only_command(args.get("command", "")):
            action = "allow"
        end
    end
    if net and policy["network"] == "ask" and action == "allow":
        call raise_to(result, "ask", "uses the network")
        action = "ask"
    end
    if action == "ask" and (state["auto_approve"] or name in state["always"]):
        action = "allow"
    end
    if name in safety_data.ALWAYS_CONFIRM_TOOLS:
        action = "confirm"
    end
    return decision(action, result)
end

function decide(state, name, args, workdir=None, home=None, tainted=False, mode="agent", fetch_trusted=True):
    result = decide_base(state, name, args, workdir, home, mode)
    if name == "web_fetch" and not fetch_trusted and result["action"] in ["allow", "ask"]:
        call raise_to(result, "sensitive", safety_data.FETCH_UNTRUSTED_REASON)
        result["action"] = "confirm"
    end
    if tainted and name in safety_data.TAINT_GUARDED_TOOLS and result["action"] in ["allow", "ask"]:
        call raise_to(result, "sensitive", safety_data.WEB_TAINT_REASON)
        result["action"] = "confirm"
    end
    return result
end

function remember(state, name, answer):
    if answer == "always":
        if name not in safety_data.ALWAYS_CONFIRM_TOOLS and name not in state["always"]:
            state["always"].append(name)
        end
        return True
    end
    return answer == "once"
end

function reset(state):
    state["always"] = []
end

function judge(permissions, name, args, run):
    conversation = run["conversation"]
    permissions["model"] = conversation["model"]
    workdir = None
    if run["tools"] != None:
        workdir = run["tools"].get("workdir")
    end
    trusted = name != "web_fetch"
    if name == "web_fetch" and permissions.get("fetch_trusted") != None:
        trusted = permissions["fetch_trusted"](permissions, args, conversation["messages"])
    end
    return decide(permissions, name, args, workdir, None, web_tainted(conversation["messages"]), conversation["mode"], trusted)
end
