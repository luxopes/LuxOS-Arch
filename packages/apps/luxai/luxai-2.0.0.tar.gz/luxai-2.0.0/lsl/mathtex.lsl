# LaTeX subset -> Unicode/Pango, preserving the Python renderer's output.
load catalog
load common
load platform
load highlight

function node(markup="", plain="", simple=True, big=False):
    return {"markup": markup, "plain": plain, "simple": simple, "big": big}
end

function join_nodes(nodes):
    markup = []
    plain = []
    simple = True
    for value in nodes:
        markup.append(value["markup"])
        plain.append(value["plain"])
        if not value["simple"]:
            simple = False
        end
    end
    return node("".join(markup), "".join(plain), simple)
end

function parser(source, loose=False):
    return {"source": source, "index": 0, "loose": loose}
end

function peek(state):
    if state["index"] < len(state["source"]):
        return state["source"][state["index"]]
    end
    return ""
end

function skip_ws(state):
    while state["index"] < len(state["source"]) and peek(state) in " \t\n":
        state["index"] += 1
    end
end

function command_match(state):
    matches = platform.regex_findall("^\\\\([A-Za-z]+\\*?|.)", state["source"][state["index"]:])
    if matches:
        return matches[0]
    end
    return None
end

function raw_group(state):
    call skip_ws(state)
    if peek(state) != "{":
        match = command_match(state)
        if match:
            state["index"] += match["end"]
            return match["groups"][1]
        end
        char = peek(state)
        if char:
            state["index"] += 1
        end
        return char
    end
    depth = 0
    start = state["index"]
    while state["index"] < len(state["source"]):
        char = peek(state)
        if char == "\\":
            state["index"] += 2
            continue
        end
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                state["index"] += 1
                return state["source"][start + 1:state["index"] - 1]
            end
        end
        state["index"] += 1
    end
    return state["source"][start + 1:]
end

function group(state):
    call skip_ws(state)
    if peek(state) == "{":
        state["index"] += 1
        value = parse(state, "}")
        if peek(state) == "}":
            state["index"] += 1
        end
        return value
    end
    if not peek(state):
        return node()
    end
    return common.fallback(atom(state), node())
end

function optional(state):
    if peek(state) != "[":
        return None
    end
    state["index"] += 1
    value = parse(state, "]")
    if peek(state) == "]":
        state["index"] += 1
    end
    return value
end

function paren_group(state):
    depth = 0
    start = state["index"]
    for index in rang(start, len(state["source"])):
        char = state["source"][index]
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                state["index"] = index + 1
                return parse(parser(state["source"][start + 1:index], state["loose"]))
            end
        end
    end
    state["index"] += 1
    return node("(", "(")
end

function mapped(text, table):
    output = []
    for char in text:
        if char not in table:
            return None
        end
        output.append(table[char])
    end
    return "".join(output)
end

function script(state, base, kind):
    argument = None
    if state["loose"] and peek(state) == "(":
        argument = paren_group(state)
    elif state["loose"] and platform.regex_test("^\\d$", peek(state)):
        match = platform.regex_findall("^\\d+", state["source"][state["index"]:])[0]
        state["index"] += match["end"]
        argument = node(match["groups"][0], match["groups"][0])
    else:
        argument = group(state)
    end
    table = catalog.MATH_SUB
    tag = "sub"
    if kind == "^":
        table = catalog.MATH_SUP
        tag = "sup"
    end
    unicode = mapped(argument["plain"], table)
    if argument["simple"] and argument["plain"] and unicode != None:
        return node(base["markup"] + highlight.esc(unicode), base["plain"] + unicode, base["simple"], base["big"])
    end
    return node(base["markup"] + "<" + tag + ">" + argument["markup"] + "</" + tag + ">", base["plain"] + argument["plain"], False, base["big"])
end

function parse(state, stop=None):
    nodes = []
    while state["index"] < len(state["source"]):
        char = peek(state)
        if stop and char == stop:
            break
        end
        if char in "^_":
            state["index"] += 1
            while nodes and nodes[len(nodes) - 1]["plain"] == " ":
                call nodes.pop()
            end
            call skip_ws(state)
            base = node()
            if nodes:
                base = nodes.pop()
            end
            nodes.append(script(state, base, char))
            continue
        end
        value = atom(state)
        if value != None:
            nodes.append(value)
        end
    end
    return join_nodes(nodes)
end

function atom(state):
    char = peek(state)
    if char == "\\":
        return command(state)
    end
    if char == "{":
        state["index"] += 1
        if state["loose"]:
            return node("{", "{")
        end
        value = parse(state, "}")
        if peek(state) == "}":
            state["index"] += 1
        end
        return value
    end
    if char == "}":
        state["index"] += 1
        if state["loose"]:
            return node("}", "}")
        end
        return None
    end
    if not state["loose"]:
        substitutions = {"&": " ", "~": " ", "'": "′", "-": "−", "*": "∗"}
        if char in substitutions:
            state["index"] += 1
            return node(substitutions[char], substitutions[char])
        end
        if char in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz":
            start = state["index"]
            while peek(state) and peek(state) in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz":
                state["index"] += 1
            end
            word = state["source"][start:state["index"]]
            return node("<i>" + highlight.esc(word) + "</i>", word)
        end
        if char in " \n\t":
            call skip_ws(state)
            return node(" ", " ")
        end
    end
    state["index"] += 1
    return node(highlight.esc(char), char)
end

function closes_at_end(text):
    if not text or text[0] not in "([{":
        return False
    end
    pairs = {"(": ")", "[": "]", "{": "}"}
    depth = 0
    for index in rang(len(text)):
        char = text[index]
        if char in pairs:
            depth += 1
        elif char in ")]}":
            depth -= 1
            if depth == 0 and index != len(text) - 1:
                return False
            end
        end
    end
    return depth == 0 and text[len(text) - 1] == pairs[text[0]]
end

function core(text):
    return text.rstrip("!′'" + "".join(catalog.MATH_SUP.values()))
end

function atomic(plain):
    text = plain.strip(common.WHITESPACE)
    if not text:
        return True
    end
    if platform.regex_test("[\\s+\\-−±∓=<>≤≥≠·×,/÷]", text) and not (text[0] in "([{" and closes_at_end(core(text))):
        return False
    end
    text = core(text)
    for index in rang(len(text)):
        if text[index] in "([{":
            return platform.regex_test("^\\w*$", text[:index]) and closes_at_end(text[index:])
        end
    end
    return True
end

function fraction(a, b):
    if platform.regex_test("^\\d{1,3}$", a["plain"]) and platform.regex_test("^\\d{1,3}$", b["plain"]):
        return node(mapped(a["plain"], catalog.MATH_SUP) + "⁄" + mapped(b["plain"], catalog.MATH_SUB), a["plain"] + "/" + b["plain"])
    end
    am = a["markup"]
    ap = a["plain"]
    bm = b["markup"]
    bp = b["plain"]
    if not atomic(ap):
        am = "(" + am + ")"
        ap = "(" + ap + ")"
    end
    if not atomic(bp):
        bm = "(" + bm + ")"
        bp = "(" + bp + ")"
    end
    return node(am + "/" + bm, ap + "/" + bp, a["simple"] and b["simple"])
end

function strip_text(text):
    return platform.regex_replace("\\\\([{}%$&#_ ])", "\\1", text).replace("~", " ")
end

function command(state):
    match = command_match(state)
    if not match:
        state["index"] += 1
        return node("\\", "\\")
    end
    name = match["groups"][1]
    state["index"] += match["end"]
    if name == "\\":
        return node("\n", "\n", False)
    end
    if name in catalog.MATH_SPACES:
        return node(catalog.MATH_SPACES[name], catalog.MATH_SPACES[name])
    end
    if name in "{}%$&#_|":
        return node(highlight.esc(name), name)
    end
    if name in catalog.MATH_GREEK or name in ["partial", "nabla"]:
        if not state["loose"] and platform.regex_test("^[ \t]+[A-Za-z0-9]", state["source"][state["index"]:]):
            call skip_ws(state)
        end
        if name not in catalog.MATH_GREEK:
            return node(highlight.esc(catalog.MATH_SYMBOLS[name]), catalog.MATH_SYMBOLS[name])
        end
        char = catalog.MATH_GREEK[name]
        markup = char
        if not state["loose"] and name[0] not in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            markup = "<i>" + char + "</i>"
        end
        return node(markup, char)
    end
    if name in catalog.MATH_SYMBOLS:
        return node(highlight.esc(catalog.MATH_SYMBOLS[name]), catalog.MATH_SYMBOLS[name])
    end
    if name in catalog.MATH_BIG_OPS:
        return node(highlight.esc(catalog.MATH_BIG_OPS[name]), catalog.MATH_BIG_OPS[name], True, True)
    end
    if name in catalog.MATH_FUNCTIONS:
        if name in ["mod", "bmod"]:
            return node(" mod ", " mod ")
        end
        return node(highlight.esc(name), name, True, name in ["lim", "max", "min", "sup", "inf", "liminf", "limsup"])
    end
    if name in ["frac", "dfrac", "tfrac", "cfrac"]:
        numerator = group(state)
        denominator = group(state)
        return fraction(numerator, denominator)
    end
    if name in ["binom", "dbinom", "tbinom"]:
        n = group(state)
        k = group(state)
        return node("(<sup>" + n["markup"] + "</sup><sub>" + k["markup"] + "</sub>)", "C(" + n["plain"] + ", " + k["plain"] + ")", False)
    end
    if name == "sqrt":
        degree = optional(state)
        argument = group(state)
        root = "√"
        if degree != None:
            roots = {"2": "√", "3": "∛", "4": "∜"}
            if degree["plain"] in roots:
                root = roots[degree["plain"]]
            else:
                superscript = mapped(degree["plain"], catalog.MATH_SUP)
                if superscript != None:
                    root = superscript + "√"
                else:
                    root = "<sup>" + degree["markup"] + "</sup>√"
                end
            end
        end
        body = argument["markup"]
        plain = argument["plain"]
        if not atomic(plain):
            body = "(" + body + ")"
            plain = "(" + plain + ")"
        end
        return node(root + body, "√" + plain, argument["simple"])
    end
    if name in catalog.MATH_TEXT_CMDS:
        text = raw_group(state)
        if name == "operatorname":
            return node(highlight.esc(text.replace("*", "")), text, True, True)
        end
        text = strip_text(text)
        return node(highlight.esc(text), text)
    end
    if name in catalog.MATH_BOLD_CMDS or name in catalog.MATH_ITALIC_CMDS:
        argument = group(state)
        tag = "i"
        if name in catalog.MATH_BOLD_CMDS:
            tag = "b"
        end
        return node("<" + tag + ">" + argument["markup"] + "</" + tag + ">", argument["plain"], argument["simple"])
    end
    if name in ["mathbb", "mathcal", "mathscr", "mathfrak"]:
        text = strip_text(raw_group(state))
        output = []
        letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        script_letters = "𝒜ℬ𝒞𝒟ℰℱ𝒢ℋℐ𝒥𝒦ℒℳ𝒩𝒪𝒫𝒬ℛ𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵"
        for char in text:
            if name == "mathbb":
                output.append(catalog.MATH_BLACKBOARD.get(char, char))
            elif name != "mathfrak" and char in letters:
                output.append(script_letters[letters.find(char)])
            else:
                output.append(char)
            end
        end
        plain = "".join(output)
        return node(highlight.esc(plain), plain)
    end
    if name in catalog.MATH_ACCENTS:
        argument = group(state)
        mark = catalog.MATH_ACCENTS[name]
        if not argument["plain"]:
            return node(highlight.esc(name), name)
        end
        if len(argument["plain"]) == 1 or name in ["overline", "underline"]:
            plain = ""
            for char in argument["plain"]:
                plain += char + mark
            end
            markup = highlight.esc(plain)
            if argument["markup"].startswith("<i>") and len(argument["plain"]) == 1:
                markup = "<i>" + markup + "</i>"
            end
            return node(markup, plain)
        end
        return node(argument["markup"] + highlight.esc(mark), argument["plain"] + mark, argument["simple"])
    end
    if name == "not":
        argument = group(state)
        negatives = {"=": "≠", "<": "≮", ">": "≯", "≤": "≰", "≥": "≱", "∈": "∉", "⊂": "⊄", "⊆": "⊈", "∼": "≁", "≡": "≢", "≈": "≉", "∃": "∄", "|": "∤", "∣": "∤"}
        plain = negatives.get(argument["plain"].strip(common.WHITESPACE))
        if plain:
            return node(highlight.esc(plain), plain)
        end
        return node(argument["markup"] + "̸", argument["plain"] + "̸")
    end
    if name in ["left", "right", "bigl", "bigr", "Bigl", "Bigr", "big", "Big", "bigg", "Bigg", "biggl", "biggr", "Biggl", "Biggr", "middle"]:
        call skip_ws(state)
        delimiter = command_match(state)
        if delimiter:
            char = delimiter["groups"][1]
            if char in ["{", "}", "|"]:
                state["index"] += delimiter["end"]
                markup = highlight.esc(char)
                if char == "|":
                    markup = "‖"
                end
                return node(markup, char)
            end
            return None
        end
        char = peek(state)
        if char in catalog.MATH_DELIMS:
            state["index"] += 1
            return node(highlight.esc(catalog.MATH_DELIMS[char]), catalog.MATH_DELIMS[char])
        end
        return None
    end
    if name in ["begin", "end"]:
        environment = raw_group(state)
        if name == "begin" and environment in ["array", "tabular"] and peek(state) == "{":
            call raw_group(state)
        end
        if environment in catalog.MATH_BRACKET_ENVS:
            index = 0
            if name == "end":
                index = 1
            end
            char = catalog.MATH_BRACKET_ENVS[environment][index]
            if char:
                return node(highlight.esc(char), char)
            end
        end
        return None
    end
    if name in ["color", "textcolor"]:
        call raw_group(state)
        if name == "textcolor":
            return group(state)
        end
        return None
    end
    if name in ["label", "tag", "phantom", "hphantom", "vphantom"]:
        call raw_group(state)
        return None
    end
    if name in ["boxed", "underbrace", "overbrace", "cancel"]:
        return group(state)
    end
    if name in catalog.MATH_IGNORED:
        return None
    end
    return node(highlight.esc(name), name)
end

function spacing(markup):
    output = []
    position = 0
    depth = 0
    for match in platform.regex_findall("<[^>]+>", markup):
        text = markup[position:match["start"]]
        if depth == 0:
            text = text.replace("&lt;", "<").replace("&gt;", ">")
            text = platform.regex_replace(catalog.MATH_SPACE_AROUND, " \\1 ", text)
            text = text.replace("<", "&lt;").replace(">", "&gt;")
        end
        output.append(text)
        tag = match["groups"][0]
        if tag in ["<sup>", "<sub>"]:
            depth += 1
        elif tag in ["</sup>", "</sub>"]:
            depth -= 1
        end
        output.append(tag)
        position = match["end"]
    end
    text = markup[position:]
    if depth == 0:
        text = text.replace("&lt;", "<").replace("&gt;", ">")
        text = platform.regex_replace(catalog.MATH_SPACE_AROUND, " \\1 ", text)
        text = text.replace("<", "&lt;").replace(">", "&gt;")
    end
    output.append(text)
    return platform.regex_replace("[ \t]{2,}", " ", "".join(output)).strip(" ")
end

function to_markup(tex, display=False):
    tex = common.text(tex).strip(common.WHITESPACE)
    if not tex:
        return ""
    end
    value = parse(parser(tex))
    lines = []
    for line in spacing(value["markup"]).split("\n"):
        if line.strip(common.WHITESPACE):
            lines.append(line.strip(common.WHITESPACE))
        end
    end
    if display:
        return "\n".join(lines)
    end
    return " ".join(lines)
end

function unmarkup(markup):
    markup = platform.regex_replace("<sup>(.*?)</sup>", "^(\\1)", markup)
    markup = platform.regex_replace("<sub>(.*?)</sub>", "_(\\1)", markup)
    markup = platform.regex_replace("<[^>]+>", "", markup)
    return markup.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
end

function to_text(tex, display=False):
    return unmarkup(to_markup(tex, display))
end

function has_bare_latex(text):
    return platform.regex_test(catalog.MATH_BARE_HINT, common.text(text))
end

function script_ok(source, index, kind):
    if index + 1 >= len(source) or source[index + 1] in " \n\t":
        return False
    end
    next = source[index + 1]
    if kind == "^":
        return index > 0 and source[index - 1] not in " \n\t"
    end
    if next == "{":
        return True
    end
    matches = platform.regex_findall("\\\\?[A-Za-z0-9]+$", source[:index])
    if matches:
        word = matches[0]["groups"][0]
        if not word.startswith("\\") and len(word) > 1 and not platform.regex_test("^\\d+$", word):
            return False
        end
    end
    after = ""
    if index + 2 < len(source):
        after = source[index + 2]
    end
    return platform.regex_test("^[\\p{L}\\p{N}]$", next) and not (platform.regex_test("^[\\p{L}\\p{N}]$", after) or after == "_")
end

function bare_markup(text):
    state = parser(common.text(text), True)
    source = state["source"]
    nodes = []
    while state["index"] < len(source):
        char = peek(state)
        if char in "^_" and nodes and nodes[len(nodes) - 1]["plain"].strip(common.WHITESPACE) and script_ok(source, state["index"], char):
            state["index"] += 1
            base = nodes.pop()
            nodes.append(script(state, base, char))
            continue
        end
        if char == "\\":
            match = command_match(state)
            if match:
                name = match["groups"][1]
                if name in catalog.MATH_KNOWN or name in catalog.MATH_IGNORED or name in catalog.MATH_SPACES or name in ["{", "}", "\\"]:
                    value = command(state)
                    if value != None:
                        nodes.append(value)
                    end
                    continue
                end
            end
        end
        matches = platform.regex_findall("^\\s+|^[^\\s\\\\^_]+", source[state["index"]:])
        chunk = char
        if matches and matches[0]["end"] > 0:
            chunk = matches[0]["groups"][0]
        end
        nodes.append(node(highlight.esc(chunk), chunk))
        state["index"] += len(chunk)
    end
    return join_nodes(nodes)["markup"]
end
