load glib
load common

function detect_lang(environment):
    selected = "en"
    for name in ["LANG", "LC_MESSAGES", "LC_ALL"]:
        if environment.get(name):
            selected = environment[name]
        end
    end
    return common.fallback(selected.split("_")[0].split(".")[0].split("@")[0], "en")
end

function load_tsv(path, into):
    if not exists(path):
        return into
    end
    try:
        # textovy rezim Pythonu: \r\n i samotne \r jsou konce radku
        for item in String(readfile(path)).replace("\r\n", "\n").replace("\r", "\n").split("\n"):
            line = String(item)
            if line.startswith("#") or "\t" not in line:
                continue
            end
            split = line.find("\t")
            key = line[:split]
            value = line[split + 1:]
            if key and value:
                into[key] = value
            end
        end
    else:
        return into
    end
    return into
end

translations = {}
language = "en"

function initialize(app_root, system_dir="/usr/share/luxos/i18n", environment=None):
    global language, translations
    if environment == None:
        environment = {"LC_ALL": glib.getenv("LC_ALL"), "LC_MESSAGES": glib.getenv("LC_MESSAGES"), "LANG": glib.getenv("LANG")}
    end
    language = detect_lang(environment)
    translations = {}
    if language != "en":
        call load_tsv(common.join(system_dir, language + ".tsv"), translations)
        call load_tsv(common.join(common.join(app_root, "i18n"), language + ".tsv"), translations)
    end
end

function translate(text):
    return translations.get(text, text)
end
