load common
load platform
load transport
load settings
load json
load i18n
load version

DEFAULT_ORIGIN = "https://lux-ai.cz"
CHAT_PATH = "/api/ide/chat/completions"

function safe_origin(origin):
    origin = common.text(origin).strip(common.WHITESPACE).rstrip("/")
    matches = platform.regex_findall("(?i)^(https?)://([^/?#]+)", origin)
    if not matches:
        return DEFAULT_ORIGIN
    end
    scheme = matches[0]["groups"][1].lower()
    authority = matches[0]["groups"][2]
    if "@" in authority:
        return DEFAULT_ORIGIN
    end
    host = authority.split(":")[0].lower()
    if authority.startswith("[") and "]" in authority:
        host = authority[1:authority.find("]")]
    end
    if scheme == "https" or host in ["127.0.0.1", "localhost", "::1"]:
        return scheme + "://" + authority
    end
    return DEFAULT_ORIGIN
end

function load_account():
    account = common.read_json(common.join(settings.config_dir(), "account.json"))
    if type(account) == "Dictionary" and type(account.get("sessionToken")) == "String" and account["sessionToken"]:
        return account
    end
    return None
end

function error(code, status=0, detail=""):
    return {"code": code, "status": status, "detail": common.text(detail)[:400]}
end

function is_auth(problem):
    return problem["code"] in ["auth", "signed_out"] or problem["status"] in [401, 403]
end

function human(problem):
    if is_auth(problem):
        return i18n.translate("Your LuxAI session has expired or is not valid. Please sign in again.")
    end
    messages = {
        "chat_busy": "Another conversation is already running on this account. Try again in a moment.",
        "chat_rate": "Too many requests. Please wait a moment.",
        "rate": "Too many requests. Please wait a moment.",
        "flash_monthly_limit": "The monthly Flash limit is used up. Switch to Lite or wait for the next month.",
        "monthly_limit": "The monthly Lite limit is used up.",
        "unavailable": "The LuxAI service is not available right now.",
        "model": "The model failed: {0}",
        "network": "Network error: {0}",
        "timeout": "The server did not respond in time.",
        "not_found": "The LuxAI API endpoint was not found on the server.",
        "protection": "The server's web protection blocked the request (HTTP {0}).",
        "html_response": "The server returned a web page instead of an API response (HTTP {0}).",
        "bad_response": "The server returned an invalid response (HTTP {0}).",
        "invalid_chat": "The server rejected the request (invalid chat).",
        "too_large": "The request is too large – the image or the conversation is too big. Start a new conversation or continue without the image."
    }
    if problem["code"] in messages:
        detail = String(problem["status"])
        if problem["code"] == "network":
            detail = problem["detail"]
        elif problem["code"] == "model":
            detail = String(common.fallback(problem["detail"], problem["status"]))
        end
        return i18n.translate(messages[problem["code"]]).replace("{0}", detail)
    end
    return (problem["code"] + " (HTTP " + String(problem["status"]) + ") " + problem["detail"]).strip(common.WHITESPACE)
end

function looks_like_html(raw):
    head = String(common.lstrip_text(raw)[:200]).lower()
    return head.startswith("<!doctype html") or head.startswith("<html") or "<head" in head
end

function error_from_response(status, raw):
    payload = None
    try:
        payload = json.decode(raw)
    else:
        payload = None
    end
    if type(payload) != "Dictionary":
        payload = {}
    end
    if status == 413:
        # telo dotazu je pro server (proxy lux-ai.cz) prilis velke - i kdyz odpovi HTML strankou
        return error("too_large", 413)
    end
    if not payload and looks_like_html(raw):
        code = "html_response"
        if "wedos.protection" in raw.lower() or "altcha" in raw.lower():
            code = "protection"
        elif status in [401, 403]:
            code = "auth"
        end
        return error(code, status)
    end
    code = payload.get("error")
    detail = common.fallback(payload.get("detail"), common.fallback(payload.get("message"), ""))
    if type(code) == "Dictionary":
        detail = common.fallback(code.get("message"), "")
        code = common.fallback(code.get("code"), common.fallback(code.get("type"), "model"))
    end
    if status in [401, 403]:
        return error("auth", status)
    end
    if not code:
        code = "http_" + String(status)
        if status == 404:
            code = "not_found"
        end
    end
    if type(detail) != "String":
        detail = json.encode(detail)[:300]
    end
    return error(String(code), status, detail)
end

function raise_error(problem):
    Error(LuxError: json.encode(problem))
end

function caught_error(text):
    start = text.find("{")
    finish = common.rfind(text, "}")
    if text.startswith("LuxError:") and start >= 0 and finish > start:
        try:
            return json.decode(text[start:finish + 1])
        else:
            return error("internal", 0, "Invalid error response")
        end
    end
    return error("internal", 0, text)
end

function new_parser():
    return {"buffer": ByteArray(), "done": False, "previous_cr": False}
end

function frame_data(bytes):
    return frame_data_text(transport.text_from_bytes(bytes))
end

function frame_data_text(text):
    lines = []
    found = False
    for item in String(text).split("\n"):
        # String(): rez netypovane promenne je v LSL 0.10.6 pomaly (viz LSL-ISSUES)
        line = String(item)
        if line.startswith("data:"):
            value = line[5:]
            if value.startswith(" "):
                value = value[1:]
            end
            lines.append(value)
            found = True
        end
    end
    if found:
        return "\n".join(lines)
    end
    return None
end

function parser_feed(state, chunk):
    # Rychla cesta pro bezne streamy bez CR: hledani "\n\n" pres memchr misto smycky po bajtech.
    if not state["previous_cr"] and transport.find_byte(chunk, 13) < 0:
        return parser_feed_fast(state, chunk)
    end
    return parser_feed_bytes(state, chunk)
end

function parser_feed_fast(state, chunk):
    output = []
    if state["done"]:
        return output
    end
    buffer = transport.concat_bytes(state["buffer"], chunk)
    start = 0
    position = 0
    while True:
        newline = transport.find_byte(buffer, 10, position)
        if newline < 0 or newline + 1 >= len(buffer):
            break
        end
        if buffer[newline + 1] != 10:
            position = newline + 1
            continue
        end
        data = frame_data_text(transport.slice_text(buffer, start, newline + 1 - start))
        start = newline + 2
        position = start
        if data == None:
            continue
        end
        if common.strip_text(data) == "[DONE]":
            state["done"] = True
            break
        end
        output.append(data)
    end
    if state["done"]:
        state["buffer"] = ByteArray()
    else:
        state["buffer"] = transport.slice_bytes(buffer, start, len(buffer) - start)
    end
    return output
end

function parser_feed_bytes(state, chunk):
    output = []
    for byte in chunk:
        if state["done"]:
            break
        end
        if byte == 10 and state["previous_cr"]:
            state["previous_cr"] = False
            continue
        end
        state["previous_cr"] = byte == 13
        if byte == 13:
            byte = 10
        end
        buffer = state["buffer"]
        if byte == 10 and len(buffer) > 0 and buffer[len(buffer) - 1] == 10:
            data = frame_data(buffer)
            state["buffer"] = ByteArray()
            if data == None:
                continue
            end
            if common.strip_text(data) == "[DONE]":
                state["done"] = True
                break
            end
            output.append(data)
        else:
            buffer.append(byte)
        end
    end
    return output
end

function parser_flush(state):
    if state["done"] or len(state["buffer"]) == 0:
        return []
    end
    data = frame_data(state["buffer"])
    state["buffer"] = ByteArray()
    if data == None:
        return []
    end
    if common.strip_text(data) == "[DONE]":
        state["done"] = True
        return []
    end
    return [data]
end

function new_accumulator():
    return {"content": [], "reasoning": [], "tool_calls": {}, "usage": None, "finish": None}
end

function add_event(state, event):
    if type(event) != "Dictionary":
        return ["", ""]
    end
    if event.get("error"):
        failure = event["error"]
        if type(failure) == "Dictionary":
            failure = failure.get("message")
        end
        call raise_error(error("model", 200, failure))
    end
    if event.get("usage"):
        state["usage"] = event["usage"]
    end
    text = []
    reasoning = []
    for choice in common.fallback(event.get("choices"), []):
        delta = common.fallback(choice.get("delta"), common.fallback(choice.get("message"), {}))
        content = delta.get("content")
        if type(content) == "String" and content:
            state["content"].append(content)
            text.append(content)
        end
        thought = common.fallback(delta.get("reasoning_content"), delta.get("reasoning"))
        if type(thought) == "String" and thought:
            state["reasoning"].append(thought)
            reasoning.append(thought)
        end
        calls = common.fallback(delta.get("tool_calls"), [])
        for index in rang(len(calls)):
            tool_call = calls[index]
            key = String(tool_call.get("index", index))
            if key not in state["tool_calls"]:
                state["tool_calls"][key] = {"id": "", "type": "function", "function": {"name": "", "arguments": ""}}
            end
            slot = state["tool_calls"][key]
            if tool_call.get("id"):
                slot["id"] = tool_call["id"]
            end
            fn = common.fallback(tool_call.get("function"), {})
            if fn.get("name"):
                slot["function"]["name"] += fn["name"]
            end
            if fn.get("arguments"):
                arguments = fn["arguments"]
                if type(arguments) != "String":
                    arguments = json.encode(arguments)
                end
                slot["function"]["arguments"] += arguments
            end
        end
        if choice.get("finish_reason"):
            state["finish"] = choice["finish_reason"]
        end
    end
    return ["".join(text), "".join(reasoning)]
end

function accumulator_message(state):
    message = {"role": "assistant", "content": common.fallback("".join(state["content"]), None)}
    if state["tool_calls"]:
        calls = []
        seen = []
        keys = []
        for key in state["tool_calls"].keys():
            keys.append(Int(key))
        end
        for key in sorted(keys):
            tool_call = state["tool_calls"][String(key)]
            if not tool_call["id"] or tool_call["id"] in seen:
                tool_call["id"] = "call_" + common.random_hex()
            end
            seen.append(tool_call["id"])
            calls.append(tool_call)
        end
        message["tool_calls"] = calls
    end
    return message
end

function usage_for(user, model):
    usage = common.fallback(common.fallback(user, {}).get("usage"), {})
    used = usage.get("liteTokens", 0)
    limit = usage.get("liteLimit", 0)
    if model == "flash":
        used = usage.get("fastTokens", 0)
        limit = usage.get("fastLimit", 0)
    end
    try:
        used = Int(common.fallback(used, 0))
        limit = Int(common.fallback(limit, 0))
    else:
        used = 0
        limit = 0
    end
    return [used, limit, Bool(usage.get("unlimited"))]
end

function new_client(account=None, origin=None):
    account = common.fallback(account, {})
    if not origin:
        origin = common.environment("LUXAI_ORIGIN", common.fallback(account.get("origin"), DEFAULT_ORIGIN))
    end
    signal = IntArray()
    signal.append(0)
    return {"account": account, "token": account.get("sessionToken", ""), "origin": safe_origin(origin), "user": account.get("user"), "cancel_signal": signal}
end

function is_cancelled(client):
    signal = IntArray(client["cancel_signal"])
    return atomic_add(signal, 0, 0) != 0
end

function headers(client, stream=False, has_body=False):
    output = {"X-Lux-Client": "luxai", "User-Agent": "luxai/" + version.VERSION, "Accept": "application/json"}
    if stream:
        output["Accept"] = "text/event-stream, application/json"
    end
    if has_body:
        output["Content-Type"] = "application/json"
    end
    if client["token"]:
        output["Cookie"] = "lux_account_session=" + client["token"]
    end
    return output
end

function validate_response(response):
    if response["cancelled"]:
        call raise_error(error("cancelled"))
    end
    if response["status"] >= 400:
        call raise_error(error_from_response(response["status"], response["text"]))
    end
    if response["error"]:
        call raise_error(error("bad_response", response["status"], response["error"]))
    end
    if response["code"] == 28 or response.get("timed_out"):
        call raise_error(error("timeout"))
    end
    if response["code"] != 0:
        call raise_error(error("network", 0, "HTTP transport code " + String(response["code"])))
    end
end

function request_json(client, method, path, body=None, timeout=20):
    if not client["token"]:
        call raise_error(error("auth", 401))
    end
    encoded = ""
    if body != None:
        encoded = json.encode(body)
    end
    response = transport.request(method, client["origin"] + path, headers(client, False, body != None), encoded, timeout)
    call validate_response(response)
    if not common.strip_text(response["text"]):
        return {}
    end
    try:
        return json.decode(response["text"])
    else:
        if looks_like_html(response["text"]):
            call raise_error(error("html_response", response["status"]))
        end
        call raise_error(error("bad_response", response["status"]))
    end
end

function me(client):
    result = request_json(client, "GET", "/api/me", None, 15)
    if type(result) != "Dictionary" or not result.get("user"):
        call raise_error(error("auth", 401))
    end
    client["user"] = result["user"]
    return result
end

function stream_chunk(state, bytes):
    if stream_should_stop(state):
        state["acc"]["finish"] = "cancelled"
        return
    end
    # Only parse complete frames. Non-SSE responses are buffered for JSON fallback.
    # Surova data jsou potreba jen pro odpoved bez SSE (JSON fallback); dlouhy SSE stream
    # se kvuli nim neprerusuje (Python limit nema).
    # (jen odkazy na kusy, spojeni az v JSON fallbacku; kopirovani po bajtech brzdilo stream)
    if not state["raw_overflow"]:
        if state["raw_length"] + len(bytes) > 4194304:
            state["raw_overflow"] = True
            state["raw_chunks"] = []
        else:
            state["raw_chunks"].append(bytes)
            state["raw_length"] += len(bytes)
        end
    end
    for data in parser_feed(state["parser"], bytes):
        event = None
        try:
            event = json.decode(data)
        else:
            continue
        end
        delta = add_event(state["acc"], event)
        call deliver_delta(state, delta)
    end
end

function never_stop():
    return False
end

function stream_cancelled(state):
    return is_cancelled(state["client"]) or stream_should_stop(state)
end

function stream_should_stop(state):
    if state["stop_context"]:
        return state["stopped"](state["callback_state"])
    end
    return state["stopped"]()
end

function deliver_delta(state, delta):
    if state["on_delta"] != None and (delta[0] or delta[1]):
        if state["callback_state"] != None:
            call state["on_delta"](state["callback_state"], delta[0], delta[1])
        else:
            call state["on_delta"](delta[0], delta[1])
        end
    end
end

function chat_stream(client, body, on_delta=None, should_stop=None, timeout=300, callback_state=None):
    if not client["token"]:
        call raise_error(error("auth", 401))
    end
    request = common.copy(body)
    request["stream"] = True
    signal = IntArray(client["cancel_signal"])
    call atomic_xchg(signal, 0, 0)
    stopped = common.fallback(should_stop, never_stop)
    acc = new_accumulator()
    state = {"acc": acc, "parser": new_parser(), "raw_chunks": [], "raw_length": 0, "stopped": stopped, "on_delta": on_delta, "client": client, "callback_state": callback_state, "stop_context": should_stop != None and callback_state != None, "raw_overflow": False}
    response = transport.request("POST", client["origin"] + CHAT_PATH, headers(client, True, True), json.encode(request), timeout, stream_chunk, stream_cancelled, 4194304, None, state, True)
    if response["cancelled"] or is_cancelled(client):
        acc["finish"] = "cancelled"
        return [accumulator_message(acc), acc["finish"], acc["usage"]]
    end
    if response["error"] and String(response["error"]).startswith("LuxError:") and response["status"] < 400:
        # chyba modelu uprostred streamu (udalost s "error"): stejna LuxError jako v Pythonu, ne bad_response
        call raise_error(caught_error(String(response["error"])))
    end
    call validate_response(response)
    content_type = response["headers"].get("content-type", "").lower()
    if "text/event-stream" not in content_type:
        if state["raw_overflow"]:
            call raise_error(error("bad_response", response["status"]))
        end
        joined = ByteArray()
        for piece in state["raw_chunks"]:
            for byte in piece:
                joined.append(byte)
            end
        end
        raw = transport.text_from_bytes(joined)
        if "text/html" in content_type or looks_like_html(raw):
            call raise_error(error("html_response", response["status"]))
        end
        event = None
        try:
            event = json.decode(raw)
        else:
            call raise_error(error("bad_response", response["status"]))
        end
        delta = add_event(acc, event)
        call deliver_delta(state, delta)
    else:
        for data in parser_flush(state["parser"]):
            event = None
            try:
                event = json.decode(data)
            else:
                continue
            end
            delta = add_event(acc, event)
            call deliver_delta(state, delta)
        end
    end
    return [accumulator_message(acc), acc["finish"], acc["usage"]]
end

function abort(client):
    signal = IntArray(client["cancel_signal"])
    call atomic_xchg(signal, 0, 1)
end
