# Administrator-mode policy and helper integration. Never changes rules on import.
load common
load platform
load glib
load process

MODES = ["password", "nopass", "noask"]
DEFAULT_MODE = "password"
HELPER = "/usr/lib/luxai/luxai-root"
HELPER_AUTO = "/usr/lib/luxai/luxai-root-auto"
SETUP_HELPER = "/usr/lib/luxai/luxai-root-setup"
# Cesty pomocniku; menit je smi jen testovaci ovladac (bridge), aplikace pouziva vychozi.
paths = {"helper": HELPER, "auto": HELPER_AUTO, "setup": SETUP_HELPER}

function effective_mode(policy, model):
    mode = common.fallback(policy, {}).get("root_mode")
    if mode not in MODES or model != "flash":
        return DEFAULT_MODE
    end
    return mode
end

function flag(value):
    if type(value) == "String":
        return value.strip(common.WHITESPACE).lower() in ["1", "true", "yes", "on"]
    end
    return Bool(value)
end

function normalize_run_command(arguments):
    if type(arguments) != "Dictionary":
        return arguments
    end
    result = common.copy(arguments)
    command = String(result.get("command", ""))
    root = flag(result.get("root"))
    if platform.regex_test("^\\s*(?:\\S*/)?(?:sudo|pkexec)\\s+(?!-)", command):
        root = True
        command = platform.regex_replace("(^|&&|\\|\\||[;|\n(])(\\s*)(?:\\S*/)?(?:sudo|pkexec)\\s+(?!-)", "\\1\\2", command).lstrip(common.WHITESPACE)
        result["command"] = command
    end
    if root:
        result["root"] = True
    else:
        result = common.without(result, "root")
    end
    return result
end

function helper_argv(mode, command, workdir, timeout):
    helper = paths["auto"]
    if mode == DEFAULT_MODE:
        helper = paths["helper"]
    end
    return ["pkexec", helper, "--timeout", String(Int(timeout)), "--cwd", common.fallback(workdir, "/"), "--", command]
end

function available():
    return native_helper(paths["helper"]) and Bool(glib.find_program_in_path("pkexec"))
end

function native_helper(path):
    try:
        header = platform.read_prefix(path, 4)
        return len(header) == 4 and header[0] == 127 and header[1] == 69 and header[2] == 76 and header[3] == 70
    else:
        return False
    end
end

function rule_active():
    if not glib.find_program_in_path("pkcheck"):
        return False
    end
    try:
        result = process.capture_result("/usr/bin/timeout", ["10", "pkcheck", "--action-id", "org.luxai.root-auto", "--process", String(platform.getpid())])
        return result["status"] == 0
    else:
        return False
    end
end

function set_rule(enable):
    if not native_helper(paths["setup"]) or not glib.find_program_in_path("pkexec"):
        return [False, "LuxAI administrator mode is not installed (update LuxAI)"]
    end
    action = "disable"
    if enable:
        action = "enable"
    end
    try:
        result = process.capture_result("/usr/bin/timeout", ["300", "pkexec", paths["setup"], action])
        if result["status"] == 0:
            return [True, ""]
        end
        if result["status"] in [126, 127]:
            return [False, "the administrator password was not entered"]
        end
        message = common.fallback(result["stderr"], common.fallback(result["stdout"], "exit code " + String(result["status"])))
        return [False, message.strip(common.WHITESPACE)[:300]]
    else:
        return [False, String(last_error())]
    end
end

function log_path():
    return common.join(common.environment("XDG_STATE_HOME", common.join(glib.home_dir(), ".local/state")), "luxai/root-commands.log")
end

function log_command(mode, model, command, exit_code, duration):
    path = log_path()
    try:
        call common.mkdir_private(common.dirname(path))
        info = platform.file_info(path)
        if info != None and info["size"] > 524288:
            call platform.rename(path, path + ".1")
        end
        one = common.words(String(command))
        if len(one) > 2000:
            one = one[:2000] + "…"
        end
        # Keep one decimal place without relying on unsupported printf formatting.
        tenths = Int(Float(duration) * 10 + 0.5)
        duration_text = String(tenths // 10) + "." + String(tenths % 10)
        line = glib.date_time_format("%Y-%m-%d %H:%M:%S") + "\t" + mode + "\t" + model + "\texit=" + String(exit_code) + "\t" + duration_text + "s\t" + one + "\n"
        call platform.append_private(path, line)
    else:
        return
    end
end

function exit_message(code):
    if code == 125:
        return "Refused by LuxAI safety rules (administrator helper). Do not try to bypass this."
    end
    if code in [126, 127]:
        return "Administrator rights were not granted (the password dialog was cancelled or the password was wrong). Do not retry the same command; tell the user what it would do and let them decide."
    end
    if code == 124:
        return "Command timed out and was stopped"
    end
    if code == 130:
        return "Command was stopped by the user"
    end
    return None
end
