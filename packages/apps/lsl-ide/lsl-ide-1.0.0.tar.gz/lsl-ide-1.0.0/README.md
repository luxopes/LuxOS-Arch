# LSL IDE

*English summary at the end of this file.*

Samostatné vývojové prostředí pro **Lux Simple Lang (LSL)** na Linuxu.
Používá nainstalovanou verzi LSL; pokud žádná není, nabídne instalaci
(jen do IDE, uživatelskou do `~/.local`, nebo systémovou do `/usr/local`).

## Spuštění

```text
./lsl-ide                    # prázdný editor
./lsl-ide program.lsl        # otevře soubor
./lsl-ide ~/projekt          # otevře složku jako projekt
./install.sh                 # zaregistruje `lsl-ide`, ikonu, položku v menu a MIME typ *.lsl
```

Vyžaduje Python 3.10+ a PySide6 nebo PyQt6 (`sudo apt install python3-pyside6.qtwidgets`
nebo `pip install PySide6`). Nic víc; kontrola chyb, spouštění, balíčky i manuál
jdou přes nainstalované `lsl`.

## Co umí

| Oblast | Funkce |
|---|---|
| Editor | zvýraznění syntaxe LSL (klíčová slova, `l"…{expr}"`, čísla `0x/0o/0b`, moduly), čísla řádků, automatické odsazení a doplnění `end`, párování a automatické uzavírání závorek/uvozovek, Ctrl+/ komentář, přesun/duplikace/smazání řádku, hledání a nahrazení, přejít na řádek, více záložek |
| Chyby | průběžná kontrola (`lsl compile` na pozadí ~0,7 s po psaní), vlnovka v textu, tečka v gutteru, panel Problémy s kódem chyby, zprávou a `help:` nápovědou compileru, tooltip po najetí; chyby ze stdlib modulů se otevřou dvojklikem |
| Symbol | panel „Symbol pod kurzorem“ (Ctrl+I, aktualizuje se při pohybu kurzoru): zda jde o klíčové slovo, vestavěnou funkci (s popisem z reference), modul, funkci modulu (podpis, komentář, odkaz na zdroj), lokální funkci/třídu, parametr nebo proměnnou (první a další přiřazení, rozsah), plus seznam výskytů v souboru s odkazy; Ctrl+klik = přejít na definici |
| Doplňování | klíčová slova, vestavěné funkce, funkce a třídy z aktuálního souboru, moduly z `lsl list`, po `modul.` funkce daného modulu s podpisem a komentářem; F12 = přejít na definici (i do stdlib), F1 = manuál |
| Cloud LuxAI | dock „Cloud LuxAI“ (Ctrl+Shift+C) a menu Cloud: kód uložený u účtu LuxAI (128 MB na účet, soubor do 4 MB), dostupný z každého PC s LSL IDE po přihlášení. Strom souborů s kvótou, nahrání otevřené záložky (i neuložené) pod zvolenou cestou, nahrání souborů, otevření (stáhne do lokální složky `~/.local/share/lsl-ide/cloud/<účet>/` a otevře v editoru; při rozdílu se zeptá, kterou verzi použít), stažení všeho jako projekt, přejmenování, mazání. Uložení souboru v lokální složce cloudu (Ctrl+S i zápis agentem) se automaticky nahraje zpět (volitelné). Vyžaduje serverovou část `server/patch_lux_account.py` (část 4) |
| Ochrana paměti | spuštěný program (F5 i agent) běží ve vlastní skupině procesů s limitem adresního prostoru (výchozí polovina RAM, max. 2 GB; menu Spustit → Limit paměti programu…). Program, který alokuje bez konce, skončí chybou `MemoryError` místo zamrznutí celého počítače; hlídač navíc zabije program, když v systému dojde volná paměť. Výstup pro agenta je omezen na 512 KB, timeout zabíjí i podproces přeloženého programu. |
| Spouštění | TUI programy (modul `tui`, alternativní obrazovka) běží přímo v panelu Výstup jako v terminálu: vestavěný emulátor (pyte) vykresluje obrazovku, klávesy včetně šipek, Esc, Ctrl+… jdou přímo programu, velikost terminálu odpovídá panelu; F5 spustí i neuložený kód (nový soubor jde do `/tmp/lsl-ide-UID/`, rozpracovaný soubor jako skrytá kopie vedle originálu, aby fungovaly lokální `load`; soubor na disku se nemění) – `lsl soubor.lsl` v pseudoterminálu s panelem pro stdin (funguje `input`, TUI), Shift+F5 s argumenty, Ctrl+F5 přeloží do binárky (volitelně `--unsafe`), zastavení běžícího procesu, barevný výstup (ANSI/SGR včetně 256 a truecolor barev, tučné, kurzíva; barevné chyby LSL 0.8.2), dvojklik na `soubor.lsl:řádek:sloupec` skočí do kódu |
| Knihovny | správce knihoven: nainstalované (`lsl list`) s verzí a stavem oproti katalogu, katalog registru (`catalog.json`) s instalací, aktualizací (`lsl update NAME`), ověřením původu (`lsl origin`, `lsl check`), instalací ze `libraries.conf`, odinstalací uživatelských knihoven |
| Toolchain | detekce `lsl` (PATH, `~/.local/bin`, `/usr/local/bin`, lokální v IDE), přepínání verzí, `lsl update --check` a aktualizace (`lsl update`, `--system` přes pkexec), stažení stable vydání s ověřením SHA-256 |
| Agent LuxAI | coding agent v docku „Agent LuxAI“ (Ctrl+Shift+A): přihlášení účtem LuxAI (heslo nebo e‑mailový kód), spotřeba se počítá do měsíčního limitu účtu (Flash 50k / Lite 1M tokenů), model volitelný. Plný tool use nad projektem: čtení, zápis a úprava souborů (otevřené záložky se aktualizují), výpis a hledání v souborech, aktuální soubor včetně neuloženého obsahu, kontrola chyb compilerem, spuštění programu s timeoutem, hledání v offline manuálu LSL, index modulů stdlib, otevření v editoru. Zápisy a spouštění se potvrzují, pokud není zapnuto „bez potvrzení“. Ctrl+Shift+E pošle výběr agentovi. Volání nástrojů se zobrazují jako karty (ikona, název, soubor jako odkaz do editoru, stav, náhled výsledku, detail s výsledkem i argumenty). Vyžaduje serverovou část `server/patch_lux_account.py` |
| Manuál | offline `lsl man --plain` vykreslený jako stylovaný HTML (nadpisy, tabulky, zvýrazněné ukázky LSL), kapitoly a hledání, F1 nad slovem, odkazy z panelu Symbol |
| Paměť | při startu se obnoví naposledy otevřené soubory včetně pozice kurzoru a aktivní záložky (Soubor → „Při startu obnovit otevřené soubory“), nabídka Nedávné (20 položek, Alt+číslo), Ctrl+E rychlý výběr z nedávných s filtrem |
| Projekt | strom složky s filtrem `*.lsl`, nový soubor / přejmenování / smazání / spuštění z kontextového menu, panel Symboly (osnova funkcí a tříd) |
| Jazyk | čeština nebo angličtina (Zobrazit → Jazyk; výchozí podle systémového locale, `LSL_IDE_LANG=en` vynutí), projeví se po restartu |
| Vzhled | horní lišta s logem, titulkem a ovládáním okna (lze vypnout v Zobrazit), 11 barevných motivů, výchozí Neon (One Dark/Light, Monokai, Půlnoční fialová, Neon, Nord, Gruvbox, Solarized Dark/Light, GitHub Light, vysoký kontrast) pro UI i editor, F11 celá obrazovka (Esc ukončí), Ctrl+Shift+F11 režim jen editor, volba písma a velikosti, rozložení panelů se pamatuje |

## Klávesové zkratky

| Zkratka | Akce |
|---|---|
| Ctrl+N / Ctrl+O / Ctrl+S | nový / otevřít / uložit |
| Ctrl+Shift+O | otevřít složku |
| F5 / Shift+F5 / Ctrl+F5 | spustit / spustit s argumenty / přeložit |
| Shift+F6 | zastavit program |
| F7 | zkontrolovat chyby teď |
| Ctrl+Space | doplňování |
| F12 / Ctrl+klik / F1 | přejít na definici / manuál |
| Ctrl+I | info o symbolu pod kurzorem |
| Ctrl+F / Ctrl+H / F3 / Ctrl+G | hledat / nahradit / další / na řádek |
| Ctrl+/ | (od)komentovat |
| Alt+↑ / Alt+↓ | posun řádku |
| Ctrl+Shift+D / Ctrl+Shift+K | duplikovat / smazat řádek |
| Ctrl+Shift+P | správce knihoven |
| Ctrl+Shift+A / Ctrl+Shift+E | agent / poslat výběr agentovi |
| Alt+1 / Alt+2 / Alt+3 | Výstup / Problémy / Manuál |
| F11 / Ctrl+Shift+F11 | celá obrazovka / jen editor |

## Jak kontrola chyb funguje

LSL nemá samostatný linter ani LSP, jediný zdroj diagnostiky je compiler.
IDE proto zapíše rozpracovaný text jako skrytý soubor `.lslide-check-PID-název.lsl`
vedle originálu (aby fungovaly lokální `load` moduly), spustí
`lsl compile` do dočasného výstupu a oba soubory hned smaže. Pokud compiler
odmítne kód kvůli `unsafe`, zkusí se `--unsafe`. Compiler hlásí první chybu,
takže se zobrazuje jedna diagnostika najednou.

## Kde IDE ukládá data

- nastavení: `~/.config/lsl-ide/lsl-ide.conf` (QSettings)
- lokální toolchain: `~/.local/share/lsl-ide/toolchain/lsl-VERZE/`, aktivní přes symlink `current`
- uživatelské knihovny (spravuje LSL): `~/.local/lib/lsl/stdlib/`

## Struktura

```text
lsl-ide            spouštěč
install.sh         registrace do menu a MIME
lslide/app.py      hlavní okno, menu, projekt, problémy
lslide/editor.py   editor (gutter, odsazení, závorky, doplňování, tooltips)
lslide/syntax.py   tabulky jazyka + zvýrazňovač
lslide/linter.py   kontrola chyb na pozadí
lslide/diagnostics.py  parser výstupu compileru
lslide/runner.py   spouštění v pseudoterminálu
lslide/packages.py správce knihoven
lslide/install_dialog.py  toolchain: instalace, výběr, aktualizace
lslide/toolchain.py detekce a stažení LSL
lslide/stdlib_index.py index funkcí stdlib pro doplňování
lslide/agent.py    coding agent LuxAI (nástroje, smyčka tool use, panel)
lslide/luxai.py    klient LuxAI účtu a chat completions
server/patch_lux_account.py  serverová část agenta pro lux-account
lslide/manual.py   offline manuál
lslide/symbol_info.py  panel Symbol pod kurzorem
lslide/theme.py    motiv, stylesheet a vektorové ikony
```

## English

LSL IDE is a standalone Qt6 development environment for Lux Simple Lang on Linux.
It uses the installed `lsl` toolchain (or offers to install one: IDE-only, per-user
into `~/.local`, or system-wide via pkexec). Features: LSL syntax highlighting,
background error checking through `lsl compile` with squiggles and a Problems
panel, completion with stdlib index, a symbol-info panel, running programs in a
pseudo-terminal with colored output and stdin, building binaries, a GUI library
manager (catalog, install, update, provenance, uninstall), offline manual, 11
color themes (Neon by default) and a custom header bar.

Run `./lsl-ide [file.lsl | folder]`; `./install.sh` registers the launcher, menu
entry and the `text/x-lsl` MIME type. The UI language follows the system locale;
switch it in View → Language (or set `LSL_IDE_LANG=en`), it applies after restart.
Requires Python 3.10+ with PyQt6 or PySide6.
