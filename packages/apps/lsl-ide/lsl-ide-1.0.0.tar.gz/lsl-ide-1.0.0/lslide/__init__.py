"""LSL IDE — samostatné vývojové prostředí pro Lux Simple Lang (Linux, Qt6)."""
__version__ = "1.0.0"
APP_NAME = "LSL IDE"
