"""Tenká vrstva nad PySide6 / PyQt6, aby IDE běželo s kteroukoli z nich."""
try:
    from PySide6 import QtCore, QtGui, QtWidgets  # noqa: F401
    from PySide6.QtCore import Signal, Slot  # noqa: F401
    QT_LIB = "PySide6"
except ImportError:  # pragma: no cover
    from PyQt6 import QtCore, QtGui, QtWidgets  # noqa: F401
    from PyQt6.QtCore import pyqtSignal as Signal, pyqtSlot as Slot  # noqa: F401
    QT_LIB = "PyQt6"

Qt = QtCore.Qt
# QFileSystemModel je v Qt 6 v QtGui, od PySide6 6.12 jen v QtWidgets
QFileSystemModel = getattr(QtGui, "QFileSystemModel", None) or QtWidgets.QFileSystemModel
