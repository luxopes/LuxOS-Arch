"""Index standardní knihovny a uživatelských balíčků pro doplňování a nápovědu.

Zdroj: `lsl list` (cesty k modulům) → regex nad `function name(args):` a
`class Name`. Načítá se jednou při startu / změně toolchainu a po instalaci
balíčku.
"""
import re
from dataclasses import dataclass, field
from pathlib import Path

from .syntax import RE_FUNC_DEF, RE_CLASS_DEF

RE_LIST_LINE = re.compile(r"^(\S+)\s+(bundled|user)\s+(\S.*)$")


@dataclass
class Symbol:
    name: str
    signature: str
    doc: str = ""
    line: int = 0


@dataclass
class Module:
    name: str
    kind: str
    path: str
    symbols: list = field(default_factory=list)
    doc: str = ""

    def lookup(self, name):
        for s in self.symbols:
            if s.name == name:
                return s
        return None


class StdlibIndex:
    def __init__(self):
        self.modules = {}
        self.stdlib_dir = ""

    def clear(self):
        self.modules = {}

    def load_from_list_output(self, output: str):
        self.clear()
        for line in output.splitlines():
            m = RE_LIST_LINE.match(line.strip())
            if not m:
                continue
            name, kind, path = m.group(1), m.group(2), m.group(3).strip()
            mod = Module(name, kind, path)
            self._scan(mod)
            self.modules[name] = mod
            if kind == "bundled" and not self.stdlib_dir:
                self.stdlib_dir = str(Path(path).parent)
        return self

    def _scan(self, mod: Module):
        try:
            text = Path(mod.path).read_text(encoding="utf-8", errors="replace")
        except OSError:
            return
        lines = text.splitlines()
        head = []
        for l in lines[:12]:
            if l.startswith("#"):
                head.append(l.lstrip("# ").rstrip())
            elif l.strip():
                break
        mod.doc = " ".join(head)[:300]
        for no, line in enumerate(lines, 1):
            if line.startswith("function ") or line.startswith("class "):
                m = RE_FUNC_DEF.match(line)
                if m:
                    name = m.group(1)
                    if name.startswith("_"):
                        continue
                    doc = ""
                    k = no - 2
                    while k >= 0 and lines[k].startswith("#"):
                        doc = lines[k].lstrip("# ").rstrip() + (" " + doc if doc else "")
                        k -= 1
                    mod.symbols.append(Symbol(name, f"{mod.name}.{name}({m.group(2).strip()})", doc, no))
                    continue
                m = RE_CLASS_DEF.match(line)
                if m:
                    mod.symbols.append(Symbol(m.group(1), f"class {mod.name}.{m.group(1)}", "", no))

    def module_names(self):
        return sorted(self.modules)

    def symbols_of(self, module):
        mod = self.modules.get(module)
        return mod.symbols if mod else []
