"""Index standardní knihovny a uživatelských balíčků pro doplňování a nápovědu.

Zdroj: `lsl list` (cesty k modulům) → regex nad `function name(args):` a
`class Name`. Načítá se jednou při startu / změně toolchainu a po instalaci
balíčku.
"""
import re
from dataclasses import dataclass, field
from pathlib import Path

from .syntax import RE_FUNC_DEF, RE_CLASS_DEF

RE_LIST_LINE = re.compile(r"^(\S+)\s+(bundled|user)\s+(\S.*)$")


@dataclass
class Symbol:
    name: str
    signature: str
    doc: str = ""
    line: int = 0


@dataclass
class Module:
    name: str
    kind: str
    path: str
    symbols: list = field(default_factory=list)
    doc: str = ""

    def lookup(self, name):
        for s in self.symbols:
            if s.name == name:
                return s
        return None


def local_module_path(file_path, name):
    """Lokální modul podle pravidel `load`: `load util.text` = `util/text.lsl` vedle souboru."""
    if not file_path or not name:
        return None
    parts = name.split(".")
    if any(not p or p in (".", "..") for p in parts):
        return None
    p = Path(file_path).parent.joinpath(*parts[:-1], parts[-1] + ".lsl")
    return p if p.is_file() else None


class StdlibIndex:
    def __init__(self):
        self.modules = {}
        self.stdlib_dir = ""
        self._local = {}  # cesta -> (mtime_ns, Module) pro lokální moduly projektu

    def resolve(self, name, file_path=""):
        """Modul pro `load name` ze souboru file_path: nejdřív relativně k souboru, pak stdlib / balíčky."""
        p = local_module_path(file_path, name)
        if p is None:
            return self.modules.get(name)
        key = str(p)
        try:
            mtime = p.stat().st_mtime_ns
        except OSError:
            return self.modules.get(name)
        cached = self._local.get(key)
        if cached and cached[0] == mtime:
            return cached[1]
        mod = Module(name.rsplit(".", 1)[-1], "local", key)
        self._scan(mod)
        self._local[key] = (mtime, mod)
        return mod

    def lookup_member(self, names, member, file_path=""):
        """Člen `member` v prvním z modulů `names` (společný alias), který ho exportuje: (Module, Symbol)."""
        first = None
        for name in names or []:
            mod = self.resolve(name, file_path)
            if mod is None:
                continue
            first = first or mod
            sym = mod.lookup(member)
            if sym:
                return mod, sym
        return first, None

    def clear(self):
        self.modules = {}

    def load_from_list_output(self, output: str):
        self.clear()
        for line in output.splitlines():
            m = RE_LIST_LINE.match(line.strip())
            if not m:
                continue
            name, kind, path = m.group(1), m.group(2), m.group(3).strip()
            mod = Module(name, kind, path)
            self._scan(mod)
            self.modules[name] = mod
            if kind == "bundled" and not self.stdlib_dir:
                self.stdlib_dir = str(Path(path).parent)
        return self

    def _scan(self, mod: Module):
        try:
            text = Path(mod.path).read_text(encoding="utf-8", errors="replace")
        except OSError:
            return
        lines = text.splitlines()
        head = []
        gap = False
        for no, l in enumerate(lines[:12]):
            if l.startswith("#"):
                # další blok komentářů (za prázdným řádkem) přilepený k definici je dokumentace
                # funkce/třídy, ne hlavička modulu
                if gap and head and (no == 0 or not lines[no - 1].startswith("#")):
                    k = no
                    while k < len(lines) and lines[k].startswith("#"):
                        k += 1
                    if k < len(lines) and lines[k].startswith(("function ", "class ")):
                        break
                head.append(l.lstrip("# ").rstrip())
            elif l.strip():
                break
            else:
                gap = True
        mod.doc = " ".join(head)[:300]
        for no, line in enumerate(lines, 1):
            if line.startswith("function ") or line.startswith("class "):
                m = RE_FUNC_DEF.match(line)
                if m:
                    name = m.group(1)
                    if name.startswith("_"):
                        continue
                    doc = ""
                    k = no - 2
                    while k >= 0 and lines[k].startswith("#"):
                        doc = lines[k].lstrip("# ").rstrip() + (" " + doc if doc else "")
                        k -= 1
                    mod.symbols.append(Symbol(name, f"{mod.name}.{name}({m.group(2).strip()})", doc, no))
                    continue
                m = RE_CLASS_DEF.match(line)
                if m:
                    mod.symbols.append(Symbol(m.group(1), f"class {mod.name}.{m.group(1)}", "", no))

    def module_names(self):
        return sorted(self.modules)

    def symbols_of(self, module, file_path=""):
        mod = self.resolve(module, file_path)
        return mod.symbols if mod else []
