"""Dialog pro instalaci / výběr / aktualizaci toolchainu LSL.

Tři možnosti instalace ze stable kanálu (https://lsl.lux-ai.cz):
  • jen pro IDE      – rozbalí archiv do ~/.local/share/lsl-ide/toolchain (nic v systému),
  • uživatelská      – bin/lsl-install ~/.local (bez sudo, `lsl update` pak funguje),
  • systémová        – pkexec bin/lsl-install /usr/local.
"""
import os
import shutil
from pathlib import Path

from .qt import QtCore, QtGui, QtWidgets, Qt, Signal
from .i18n import tr
from . import toolchain as tc


class Downloader(QtCore.QThread):
    progress = Signal(int, int)
    done = Signal(object, str)  # (root, tmp, version) | None, error

    def __init__(self, parent=None):
        super().__init__(parent)

    def run(self):
        try:
            ch = tc.fetch_channel()
            art = tc.pick_artifact(ch)
            root, tmp = tc.download_release(art, progress=lambda d, t: self.progress.emit(d, t))
            self.done.emit((root, tmp, ch.get("version", "")), "")
        except Exception as e:  # noqa: BLE001
            self.done.emit(None, str(e))


class ToolchainDialog(QtWidgets.QDialog):
    toolchain_selected = Signal(object)

    def __init__(self, current, settings, parent=None, first_run=False):
        super().__init__(parent)
        self.setWindowTitle(tr("Toolchain LSL"))
        self.resize(760, 520)
        self.settings = settings
        self.current = current
        self._dl = None
        self._proc = None
        self._staged = None

        lay = QtWidgets.QVBoxLayout(self)
        intro = QtWidgets.QLabel(
            tr("<b>LSL nebylo nalezeno.</b> Vyberte, jak ho nainstalovat, nebo ukažte na existující binárku <code>lsl</code>.")
            if first_run else
            tr("Vyberte používanou instalaci LSL, nebo nainstalujte / aktualizujte toolchain.")
        )
        intro.setWordWrap(True)
        lay.addWidget(intro)

        found_box = QtWidgets.QGroupBox(tr("Nalezené instalace"))
        fl = QtWidgets.QVBoxLayout(found_box)
        self.list = QtWidgets.QListWidget()
        self.list.itemDoubleClicked.connect(lambda _i: self._use_selected())
        fl.addWidget(self.list)
        row = QtWidgets.QHBoxLayout()
        self.btn_use = QtWidgets.QPushButton(tr("Použít vybranou"))
        self.btn_use.clicked.connect(self._use_selected)
        self.btn_browse = QtWidgets.QPushButton(tr("Vybrat binárku ručně…"))
        self.btn_browse.clicked.connect(self._browse)
        self.btn_rescan = QtWidgets.QPushButton(tr("Znovu hledat"))
        self.btn_rescan.clicked.connect(self.rescan)
        self.btn_selfupdate = QtWidgets.QPushButton(tr("Zkontrolovat aktualizaci LSL"))
        self.btn_selfupdate.clicked.connect(self._self_update_check)
        row.addWidget(self.btn_use)
        row.addWidget(self.btn_browse)
        row.addWidget(self.btn_rescan)
        row.addStretch(1)
        row.addWidget(self.btn_selfupdate)
        fl.addLayout(row)
        lay.addWidget(found_box)

        inst_box = QtWidgets.QGroupBox(tr("Instalace ze stable kanálu (lsl.lux-ai.cz)"))
        il = QtWidgets.QVBoxLayout(inst_box)
        self.opt_ide = QtWidgets.QRadioButton(tr("Jen pro IDE — do ~/.local/share/lsl-ide/toolchain (nic v systému, bez sudo)"))
        self.opt_user = QtWidgets.QRadioButton(tr("Uživatelská instalace — bin/lsl-install ~/.local (bez sudo; `lsl update` funguje)"))
        self.opt_system = QtWidgets.QRadioButton(tr("Systémová instalace — pkexec bin/lsl-install /usr/local (vyžaduje heslo)"))
        self.opt_ide.setChecked(True)
        for o in (self.opt_ide, self.opt_user, self.opt_system):
            il.addWidget(o)
        prow = QtWidgets.QHBoxLayout()
        self.btn_install = QtWidgets.QPushButton(tr("Stáhnout a nainstalovat"))
        self.btn_install.clicked.connect(self._install)
        self.progress = QtWidgets.QProgressBar()
        self.progress.setVisible(False)
        prow.addWidget(self.btn_install)
        prow.addWidget(self.progress, 1)
        il.addLayout(prow)
        lay.addWidget(inst_box)

        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(150)
        lay.addWidget(self.log)
        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Close)
        btns.rejected.connect(self.reject)
        lay.addWidget(btns)
        self.rescan()

    def log_line(self, s):
        self.log.appendPlainText(s.rstrip())

    def rescan(self):
        self.list.clear()
        override = self.settings.value("toolchain/path", "", str)
        for t in tc.discover(override):
            it = QtWidgets.QListWidgetItem(t.label)
            it.setData(Qt.ItemDataRole.UserRole, t)
            if self.current and os.path.realpath(self.current.path) == os.path.realpath(t.path):
                it.setText("● " + t.label + tr("   (aktivní)"))
            self.list.addItem(it)
        for d in tc.local_toolchains():
            b = d / "bin" / "lsl"
            if not any(os.path.realpath(self.list.item(i).data(Qt.ItemDataRole.UserRole).path) == os.path.realpath(b)
                       for i in range(self.list.count())):
                t = tc.Toolchain(str(b), "ide")
                t.probe_version()
                it = QtWidgets.QListWidgetItem(t.label)
                it.setData(Qt.ItemDataRole.UserRole, t)
                self.list.addItem(it)
        if self.list.count():
            self.list.setCurrentRow(0)

    def _use_selected(self):
        it = self.list.currentItem()
        if not it:
            return
        t = it.data(Qt.ItemDataRole.UserRole)
        if t.kind == "ide":
            tc.switch_local(Path(t.path).parent.parent)
        self.settings.setValue("toolchain/path", t.path)
        self.toolchain_selected.emit(t)
        self.accept()

    def _browse(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, tr("Binárka lsl"), str(Path.home()))
        if not path:
            return
        t = tc.Toolchain(path, "settings")
        if not t.probe_version():
            QtWidgets.QMessageBox.warning(self, "Toolchain", tr("Soubor nevrací verzi (`lsl version`). Není to LSL?"))
            return
        self.settings.setValue("toolchain/path", path)
        self.toolchain_selected.emit(t)
        self.accept()

    # --- stažení + instalace ------------------------------------------------------
    def _install(self):
        self.btn_install.setEnabled(False)
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.log_line(tr("Stahuji stable.json a archiv vydání…"))
        self._dl = Downloader(self)
        self._dl.progress.connect(self._on_progress)
        self._dl.done.connect(self._on_downloaded)
        self._dl.start()

    def _on_progress(self, done, total):
        if total:
            self.progress.setMaximum(total)
            self.progress.setValue(done)
        else:
            self.progress.setMaximum(0)

    def _on_downloaded(self, res, err):
        self.progress.setVisible(False)
        if err:
            self.log_line(tr("Chyba: ") + err)
            self.btn_install.setEnabled(True)
            return
        root, tmp, version = res
        self.log_line(tr('Staženo a ověřeno LSL {0} (SHA-256 OK).').format(version))
        self._staged = (root, tmp, version)
        if self.opt_ide.isChecked():
            try:
                target = tc.install_local(root, version)
                shutil.rmtree(tmp, ignore_errors=True)
                t = tc.Toolchain(str(target / "bin" / "lsl"), "ide")
                t.probe_version()
                self.log_line(tr('Nainstalováno do {0}').format(target))
                self.settings.setValue("toolchain/path", t.path)
                self.toolchain_selected.emit(t)
                self.rescan()
            except Exception as e:  # noqa: BLE001
                self.log_line(tr("Instalace selhala: ") + str(e))
            self.btn_install.setEnabled(True)
            return
        system = self.opt_system.isChecked()
        prefix = "/usr/local" if system else str(Path.home() / ".local")
        try:
            cmd = tc.installer_command(root, prefix, system)
        except RuntimeError as e:
            self.log_line(str(e))
            self.btn_install.setEnabled(True)
            return
        self.log_line("$ " + " ".join(cmd))
        p = QtCore.QProcess(self)
        p.setProcessChannelMode(QtCore.QProcess.ProcessChannelMode.MergedChannels)
        p.readyReadStandardOutput.connect(lambda: self.log_line(bytes(p.readAllStandardOutput()).decode("utf-8", "replace")))
        p.finished.connect(lambda code, _s: self._on_installed(code, prefix, system))
        self._proc = p
        p.start(cmd[0], cmd[1:])

    def _on_installed(self, code, prefix, system):
        root, tmp, version = self._staged or (None, None, "")
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
        self._staged = None
        self.btn_install.setEnabled(True)
        if code != 0:
            self.log_line(tr('Installer skončil s kódem {0}.').format(code))
            return
        binp = Path(prefix) / "bin" / "lsl"
        t = tc.Toolchain(str(binp), "system" if system else "user")
        if t.probe_version():
            self.log_line(tr('Nainstalováno: {0}').format(t.label))
            if not system and str(binp.parent) not in os.environ.get("PATH", "").split(":"):
                self.log_line(tr("Poznámka: ~/.local/bin není v PATH; IDE to nevadí, pro terminál ho přidejte."))
            self.settings.setValue("toolchain/path", t.path)
            self.toolchain_selected.emit(t)
        else:
            self.log_line(tr('Installer skončil, ale {0} nefunguje.').format(binp))
        self.rescan()

    def _self_update_check(self):
        it = self.list.currentItem()
        t = it.data(Qt.ItemDataRole.UserRole) if it else self.current
        if not t:
            return
        self.log_line("$ lsl update --check")
        try:
            out = t.run(["update", "--check"], timeout=60)
            self.log_line((out.stdout + out.stderr).strip())
        except Exception as e:  # noqa: BLE001
            self.log_line(str(e))
            return
        if "up to date" in (out.stdout + out.stderr):
            return
        if t.kind == "ide":
            self.log_line(tr("Lokální toolchain IDE se aktualizuje volbou „Jen pro IDE“ výše (stáhne nové vydání vedle stávajícího)."))
            return
        cmd = ["update"] if t.is_user_updatable() else ["update", "--system"]
        q = QtWidgets.QMessageBox.question(self, tr("Aktualizace LSL"), tr("Spustit `lsl ") + " ".join(cmd) + "`?")
        if q != QtWidgets.QMessageBox.StandardButton.Yes:
            return
        argv = [t.path, *cmd]
        if not t.is_user_updatable():
            if not shutil.which("pkexec"):
                self.log_line(tr("Chybí pkexec; spusťte ručně: sudo ") + " ".join(argv))
                return
            argv = ["pkexec", *argv]
        self.log_line("$ " + " ".join(argv))
        p = QtCore.QProcess(self)
        p.setProcessChannelMode(QtCore.QProcess.ProcessChannelMode.MergedChannels)
        p.readyReadStandardOutput.connect(lambda: self.log_line(bytes(p.readAllStandardOutput()).decode("utf-8", "replace")))
        p.finished.connect(lambda code, _s: (self.log_line(f"[kód {code}]"), self.rescan()))
        self._proc = p
        p.start(argv[0], argv[1:])
