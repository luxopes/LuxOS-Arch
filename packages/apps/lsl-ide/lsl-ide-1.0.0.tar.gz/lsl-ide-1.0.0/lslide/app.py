"""Hlavní okno LSL IDE."""
import json
import os
import sys
from pathlib import Path

from .qt import QtCore, QtGui, QtWidgets, Qt, Signal, QT_LIB, QFileSystemModel
from .i18n import tr
from . import i18n
from . import APP_NAME, __version__
from .editor import CodeEditor
from .linter import Checker
from .runner import RunPanel
from .manual import ManualPanel
from .packages import PackageManager
from .install_dialog import ToolchainDialog
from .stdlib_index import StdlibIndex
from .symbol_info import SymbolPanel
from .agent import AgentPanel
from .cloud import CloudPanel
from . import theme
from . import sandbox
from . import toolchain as tcmod
import tempfile

def available_area():
    """Pracovní plocha primárního monitoru (bez panelů), nebo None bez obrazovky."""
    screen = QtGui.QGuiApplication.primaryScreen()
    return screen.availableGeometry() if screen else None


def default_window_size(area, max_w=1280, max_h=820):
    """Výchozí velikost okna: nejvýš 1280×820, ale vždy do 90 % pracovní plochy monitoru."""
    if area is None or area.width() <= 0 or area.height() <= 0:
        return max_w, max_h
    return min(max_w, int(area.width() * 0.9)), min(max_h, int(area.height() * 0.9))


def settings_profile():
    """Název QSettings profilu. Testy nastavují LSL_IDE_PROFILE, aby nesahaly na uživatelský
    ~/.config/lsl-ide/lsl-ide.conf (přihlášení, motiv, historie)."""
    return os.environ.get("LSL_IDE_PROFILE") or "lsl-ide"


def new_file_template():
    return tr("# Nový program LSL") + '''
load time

function main():
    print "''' + tr("Ahoj z LSL!") + '''"
end

call main()
'''


class FindBar(QtWidgets.QFrame):
    def __init__(self, main):
        super().__init__(main)
        self.setObjectName("findbar")
        self.main = main
        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(4, 2, 4, 2)
        self.find = QtWidgets.QLineEdit()
        self.find.setPlaceholderText(tr("Hledat"))
        self.find.returnPressed.connect(lambda: self.do_find())
        self.replace = QtWidgets.QLineEdit()
        self.replace.setPlaceholderText(tr("Nahradit"))
        self.case = QtWidgets.QCheckBox("Aa")
        self.case.setToolTip(tr("Rozlišovat velikost"))
        self.whole = QtWidgets.QCheckBox(tr("Slovo"))
        b_next = QtWidgets.QToolButton(); b_next.setText(tr("Další")); b_next.clicked.connect(lambda: self.do_find())
        b_prev = QtWidgets.QToolButton(); b_prev.setText(tr("Předchozí")); b_prev.clicked.connect(lambda: self.do_find(back=True))
        b_rep = QtWidgets.QToolButton(); b_rep.setText(tr("Nahradit")); b_rep.clicked.connect(self.do_replace)
        b_all = QtWidgets.QToolButton(); b_all.setText(tr("Nahradit vše")); b_all.clicked.connect(self.do_replace_all)
        b_close = QtWidgets.QToolButton(); b_close.setText("✕"); b_close.clicked.connect(self.hide)
        for w in (self.find, b_prev, b_next, self.case, self.whole, self.replace, b_rep, b_all, b_close):
            lay.addWidget(w)
        lay.setStretch(0, 2)
        lay.setStretch(5, 2)
        QtGui.QShortcut(QtGui.QKeySequence("Escape"), self, self.hide)
        self.hide()

    def flags(self, back=False):
        f = QtGui.QTextDocument.FindFlag(0)
        if back:
            f |= QtGui.QTextDocument.FindFlag.FindBackward
        if self.case.isChecked():
            f |= QtGui.QTextDocument.FindFlag.FindCaseSensitively
        if self.whole.isChecked():
            f |= QtGui.QTextDocument.FindFlag.FindWholeWords
        return f

    def do_find(self, back=False):
        ed = self.main.current_editor()
        q = self.find.text()
        if not ed or not q:
            return False
        if not ed.find(q, self.flags(back)):
            c = ed.textCursor()
            c.movePosition(QtGui.QTextCursor.MoveOperation.End if back else QtGui.QTextCursor.MoveOperation.Start)
            ed.setTextCursor(c)
            return ed.find(q, self.flags(back))
        return True

    def do_replace(self):
        ed = self.main.current_editor()
        if not ed:
            return
        c = ed.textCursor()
        q = self.find.text()
        if c.hasSelection() and (c.selectedText() == q or (not self.case.isChecked() and c.selectedText().lower() == q.lower())):
            c.insertText(self.replace.text())
        self.do_find()

    def do_replace_all(self):
        ed = self.main.current_editor()
        if not ed or not self.find.text():
            return
        c = ed.textCursor()
        c.beginEditBlock()
        c.movePosition(QtGui.QTextCursor.MoveOperation.Start)
        ed.setTextCursor(c)
        n = 0
        while ed.find(self.find.text(), self.flags()):
            ed.textCursor().insertText(self.replace.text())
            n += 1
        c.endEditBlock()
        self.main.statusBar().showMessage(f"Nahrazeno: {n}", 3000)


class HeaderBar(QtWidgets.QFrame):
    """Horní lišta s logem, názvem aplikace, titulkem okna a ovládáním okna."""

    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.setObjectName("headerBar")
        self.setFixedHeight(40)
        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(10, 4, 8, 4)
        lay.setSpacing(8)
        self.logo = QtWidgets.QLabel()
        app_icon = QtWidgets.QApplication.instance().windowIcon()
        self.logo.setPixmap((app_icon if not app_icon.isNull() else theme.icon("logo")).pixmap(28, 28))
        self.app_name = QtWidgets.QLabel(APP_NAME)
        self.app_name.setObjectName("appName")
        self.title = QtWidgets.QLabel("")
        self.title.setObjectName("winTitle")
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.btn_min = QtWidgets.QToolButton(); self.btn_min.setObjectName("winMin")
        self.btn_max = QtWidgets.QToolButton(); self.btn_max.setObjectName("winMax")
        self.btn_close = QtWidgets.QToolButton(); self.btn_close.setObjectName("winClose")
        self.btn_min.clicked.connect(main.showMinimized)
        self.btn_max.clicked.connect(self.toggle_max)
        self.btn_close.clicked.connect(main.close)
        for b in (self.btn_min, self.btn_max, self.btn_close):
            b.setIconSize(QtCore.QSize(16, 16))
            b.setFixedSize(26, 26)
            b.setToolTip({"winMin": tr("Minimalizovat"), "winMax": tr("Maximalizovat"), "winClose": tr("Zavřít")}[b.objectName()])
        lay.addWidget(self.logo)
        lay.addWidget(self.app_name)
        lay.addStretch(1)
        lay.addWidget(self.title, 2)
        lay.addStretch(1)
        lay.addWidget(self.btn_min)
        lay.addWidget(self.btn_max)
        lay.addWidget(self.btn_close)
        main.windowTitleChanged.connect(self.title.setText)
        self._press = None

    def set_colors(self, c):
        self.btn_min.setIcon(theme.icon("minimize", c["text"]))
        self.btn_max.setIcon(theme.icon("restore" if self.main.isMaximized() else "maximize", c["text"]))
        self.btn_close.setIcon(theme.icon("clear", c["text"]))

    def toggle_max(self):
        if self.main.isMaximized():
            self.main.showNormal()
        else:
            self.main.showMaximized()
        self.set_colors(self.main.theme_colors)

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self._press = e.globalPosition().toPoint()

    def mouseMoveEvent(self, e):  # noqa: N802
        if self._press is not None and (e.globalPosition().toPoint() - self._press).manhattanLength() > 4:
            self._press = None
            wh = self.main.windowHandle()
            if wh is not None:
                wh.startSystemMove()

    def mouseReleaseEvent(self, e):  # noqa: N802
        self._press = None

    def mouseDoubleClickEvent(self, e):  # noqa: N802
        self.toggle_max()


class EditorTab(QtWidgets.QWidget):
    """Editor + debounce kontrola chyb."""

    def __init__(self, main, path=""):
        super().__init__(main)
        self.main = main
        self.path = path
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.editor = CodeEditor(self, main.palette_data, main.stdlib_index)
        self.editor.file_path = path
        self.editor.set_font(main.editor_font)
        lay.addWidget(self.editor)
        self.timer = QtCore.QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(700)
        self.timer.timeout.connect(self.check_now)
        self.editor.textChanged.connect(self.timer.start)
        self.editor.document().modificationChanged.connect(lambda _m: main.update_tab_title(self))
        self.editor.cursorPositionChanged.connect(main.update_cursor_status)
        self.editor.cursorPositionChanged.connect(main.symbol_timer.start)
        self.editor.definition_requested.connect(main.goto_definition)

    @property
    def title(self):
        return Path(self.path).name if self.path else tr("bez názvu.lsl")

    def check_now(self):
        if self.main.checker.toolchain and self.main.settings.value("check/enabled", True, bool):
            self.main.checker.check(self.editor.toPlainText(), self.path)

    def load(self, path):
        text = Path(path).read_text(encoding="utf-8", errors="replace")
        self.editor.setPlainText(text)
        self.editor.document().setModified(False)
        self.path = path
        self.editor.file_path = path

    def save(self, path=None):
        path = path or self.path
        if not path:
            return False
        text = self.editor.toPlainText()
        if self.main.settings.value("editor/trim_trailing", True, bool):
            text = "\n".join(l.rstrip() for l in text.split("\n"))
            if text and not text.endswith("\n"):
                text += "\n"
            if text != self.editor.toPlainText():
                c = self.editor.textCursor()
                pos = c.position()
                self.editor.setPlainText(text)
                c.setPosition(min(pos, len(text)))
                self.editor.setTextCursor(c)
        Path(path).write_text(text, encoding="utf-8")
        self.path = path
        self.editor.file_path = path
        self.editor.document().setModified(False)
        return True


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, files=()):
        super().__init__()
        self.settings = QtCore.QSettings("lsl-ide", settings_profile())
        self.setWindowTitle(APP_NAME)
        self.resize(*default_window_size(available_area()))
        theme_name = self.settings.value("ui/theme", theme.DEFAULT_THEME, str)
        if theme_name == "dark":
            theme_name = "one-dark"
        elif theme_name == "light":
            theme_name = "one-light"
        elif theme_name == "dracula":
            theme_name = "midnight-violet"
        self.theme_name = theme_name
        self.palette_data = theme.get(theme_name)["editor"]
        self.editor_font = QtGui.QFont(self.settings.value("editor/font_family", "DejaVu Sans Mono", str),
                                       int(self.settings.value("editor/font_size", 11)))
        self.editor_font.setStyleHint(QtGui.QFont.StyleHint.Monospace)
        self.stdlib_index = StdlibIndex()
        self.toolchain = None
        self.checker = Checker(self)
        self.checker.finished.connect(self.on_check_finished)
        self.theme_colors = theme.get(theme_name)["ui"]
        self._edge_cursor = False
        self._scratch_dir = Path(tempfile.gettempdir()) / f"lsl-ide-{os.getuid()}"

        self._build_ui()
        self._build_actions()
        self._apply_theme()
        self.restoreGeometry(self.settings.value("ui/geometry", QtCore.QByteArray()))
        # uložená velikost z většího monitoru se na menší obrazovku nevejde -> výchozí velikost
        area = available_area()
        if area and not self.isMaximized() and (self.width() > area.width() or self.height() > area.height()):
            self.resize(*default_window_size(area))
        self.restoreState(self.settings.value("ui/state", QtCore.QByteArray()))

        folder = self.settings.value("project/folder", "", str)
        if not folder or not Path(folder).is_dir():
            first = next((f for f in files if Path(f).is_file()), None)
            folder = str(Path(first).resolve().parent) if first else str(Path.home())
        self.open_folder(folder)
        opened = False
        for f in files:
            if Path(f).is_dir():
                self.open_folder(f)
            elif self.open_file(f):
                opened = True
        if not opened and self.settings.value("session/restore", True, bool):
            opened = self.restore_session()
        if not opened:
            self.new_file()
        QtCore.QTimer.singleShot(50, self.init_toolchain)

    # --- UI -----------------------------------------------------------------------
    def _build_ui(self):
        central = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(central)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.setMovable(True)
        self.tabs.setDocumentMode(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self._tab_changed)
        self.findbar = FindBar(self)
        v.addWidget(self.tabs, 1)
        v.addWidget(self.findbar)
        self.setCentralWidget(central)

        # Projekt
        self.project_dock = QtWidgets.QDockWidget(tr("Projekt"), self)
        self.project_dock.setObjectName("projectDock")
        self.fs_model = QFileSystemModel(self)
        self.fs_model.setNameFilters(["*.lsl", "*.conf", "*.md", "*.txt", "*.json"])
        self.fs_model.setNameFilterDisables(False)
        self.tree = QtWidgets.QTreeView()
        self.tree.setModel(self.fs_model)
        self.tree.setHeaderHidden(True)
        for c in (1, 2, 3):
            self.tree.hideColumn(c)
        self.tree.doubleClicked.connect(self._tree_open)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._tree_menu)
        self.project_dock.setWidget(self.tree)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self.project_dock)

        # Spodní panel
        self.bottom = QtWidgets.QTabWidget()
        self.bottom_dock = QtWidgets.QDockWidget(tr("Panely"), self)
        self.bottom_dock.setObjectName("bottomDock")
        self.bottom_dock.setWidget(self.bottom)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.bottom_dock)
        self.run_panel = RunPanel()
        self.run_panel.location_activated.connect(self.goto_location)
        self.run_panel.finished.connect(self._run_finished)
        self.run_panel.screen_mode_changed.connect(self._on_screen_mode)
        self.bottom.addTab(self.run_panel, tr("Výstup"))
        self.problems = QtWidgets.QTreeWidget()
        self.problems.setHeaderLabels([tr("Závažnost"), tr("Kód"), tr("Zpráva"), tr("Soubor"), tr("Řádek"), tr("Nápověda")])
        self.problems.setRootIsDecorated(False)
        self.problems.itemActivated.connect(self._problem_activated)
        self.bottom.addTab(self.problems, tr("Problémy"))
        self.manual = ManualPanel()
        self.bottom.addTab(self.manual, tr("Manuál"))

        # Symboly (osnova)
        self.outline_dock = QtWidgets.QDockWidget(tr("Symboly"), self)
        self.outline_dock.setObjectName("outlineDock")
        self.outline = QtWidgets.QListWidget()
        self.outline.itemActivated.connect(lambda it: self.current_editor().go_to_line(it.data(Qt.ItemDataRole.UserRole)))
        self.outline_dock.setWidget(self.outline)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.outline_dock)
        self.outline_timer = QtCore.QTimer(self)
        self.outline_timer.setSingleShot(True)
        self.outline_timer.setInterval(500)
        self.outline_timer.timeout.connect(self.refresh_outline)

        self.symbol_dock = QtWidgets.QDockWidget(tr("Symbol pod kurzorem"), self)
        self.symbol_dock.setObjectName("symbolDock")
        self.symbol_panel = SymbolPanel()
        self.symbol_panel.goto.connect(lambda path, line: self.goto_location(path, line) if path else self.current_editor().go_to_line(line))
        self.symbol_panel.open_manual.connect(self.open_manual_at)
        self.symbol_panel.manual = self.manual
        self.symbol_dock.setWidget(self.symbol_panel)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.symbol_dock)
        self.splitDockWidget(self.outline_dock, self.symbol_dock, Qt.Orientation.Vertical)
        self.symbol_timer = QtCore.QTimer(self)
        self.symbol_timer.setSingleShot(True)
        self.symbol_timer.setInterval(250)
        self.symbol_timer.timeout.connect(self.refresh_symbol_info)

        self.agent_dock = QtWidgets.QDockWidget(tr("Agent LuxAI"), self)
        self.agent_dock.setObjectName("agentDock")
        self.agent_panel = AgentPanel(self)
        self.agent_dock.setWidget(self.agent_panel)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.agent_dock)
        self.tabifyDockWidget(self.symbol_dock, self.agent_dock)
        # Cloud LuxAI: kód uložený u účtu, dostupný z každého PC
        self.cloud_dock = QtWidgets.QDockWidget(tr("Cloud LuxAI"), self)
        self.cloud_dock.setObjectName("cloudDock")
        self.cloud_panel = CloudPanel(self)
        self.cloud_dock.setWidget(self.cloud_panel)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.cloud_dock)
        self.tabifyDockWidget(self.agent_dock, self.cloud_dock)
        self.symbol_dock.raise_()

        self.status_tc = QtWidgets.QLabel(tr("LSL: —"))
        self.status_pos = QtWidgets.QLabel(tr("Ř {0}, S {1}").format(1, 1))
        self.status_check = QtWidgets.QLabel("")
        self.statusBar().addPermanentWidget(self.status_check)
        self.statusBar().addPermanentWidget(self.status_pos)
        self.statusBar().addPermanentWidget(self.status_tc)

    def _act(self, text, slot, shortcut=None, menu=None, toolbar=None, checkable=False, icon=None):
        a = QtGui.QAction(text, self)
        if icon:
            a.setIcon(theme.icon(icon, self.theme_colors["text"]))
            a.setData(icon)
            self._icon_actions.append(a)
        if shortcut:
            a.setShortcut(QtGui.QKeySequence(shortcut))
        a.setCheckable(checkable)
        a.triggered.connect(slot)
        # Menubar je vložený přes setMenuWidget; zkratky musí patřit přímo oknu.
        a.setShortcutContext(Qt.ShortcutContext.WindowShortcut)
        self.addAction(a)
        if menu is not None:
            menu.addAction(a)
        if toolbar is not None:
            toolbar.addAction(a)
        return a

    def _build_actions(self):
        mb = QtWidgets.QMenuBar()
        self.header = HeaderBar(self)
        top = QtWidgets.QWidget()
        tl = QtWidgets.QVBoxLayout(top)
        tl.setContentsMargins(0, 0, 0, 0)
        tl.setSpacing(0)
        tl.addWidget(self.header)
        tl.addWidget(mb)
        self.setMenuWidget(top)
        self._apply_header(self.settings.value("ui/header", True, bool), initial=True)
        QtWidgets.QApplication.instance().installEventFilter(self)
        tb = self.addToolBar(tr("Hlavní"))
        tb.setObjectName("mainToolbar")
        tb.setMovable(False)
        tb.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        tb.setIconSize(QtCore.QSize(18, 18))
        self._icon_actions = []

        m = mb.addMenu(tr("&Soubor"))
        self._act(tr("Nový"), self.new_file, "Ctrl+N", m, tb, icon="new")
        self._act(tr("Otevřít…"), self.open_file_dialog, "Ctrl+O", m, tb, icon="open")
        self._act(tr("Otevřít složku…"), self.open_folder_dialog, "Ctrl+Shift+O", m)
        self.recent_menu = m.addMenu(tr("Nedávné"))
        self._act(tr("Otevřít nedávný…"), self.open_recent_dialog, "Ctrl+E", m)
        self.act_restore = self._act(tr("Při startu obnovit otevřené soubory"), lambda on: self.settings.setValue("session/restore", bool(on)), None, m, checkable=True)
        self.act_restore.setChecked(self.settings.value("session/restore", True, bool))
        self._act(tr("Uložit"), self.save_file, "Ctrl+S", m, tb, icon="save")
        self._act(tr("Uložit jako…"), self.save_file_as, "Ctrl+Shift+S", m)
        self._act(tr("Uložit vše"), self.save_all, "Ctrl+Alt+S", m)
        m.addSeparator()
        self._act(tr("Zavřít záložku"), lambda: self.close_tab(self.tabs.currentIndex()), "Ctrl+W", m)
        m.addSeparator()
        self._act(tr("Konec"), self.close, "Ctrl+Q", m)

        m = mb.addMenu(tr("&Úpravy"))
        self._act(tr("Zpět"), lambda: self._ed("undo"), "Ctrl+Z", m)
        self._act(tr("Znovu"), lambda: self._ed("redo"), "Ctrl+Shift+Z", m)
        m.addSeparator()
        self._act(tr("Hledat…"), self.show_find, "Ctrl+F", m)
        self._act(tr("Nahradit…"), self.show_replace, "Ctrl+H", m)
        self._act(tr("Najít další"), lambda: self.findbar.do_find(), "F3", m)
        self._act(tr("Přejít na řádek…"), self.goto_line_dialog, "Ctrl+G", m)
        m.addSeparator()
        self._act(tr("Zakomentovat / odkomentovat"), lambda: self._ed("toggle_comment"), "Ctrl+/", m)
        self._act(tr("Odsadit"), lambda: self._ed("indent_selection", True), "Ctrl+]", m)
        self._act(tr("Zrušit odsazení"), lambda: self._ed("indent_selection", False), "Ctrl+[", m)
        self._act(tr("Duplikovat řádek"), lambda: self._ed("duplicate_line"), "Ctrl+Shift+D", m)
        self._act(tr("Smazat řádek"), lambda: self._ed("delete_line"), "Ctrl+Shift+K", m)
        self._act(tr("Posunout řádek nahoru"), lambda: self._ed("move_line", True), "Alt+Up", m)
        self._act(tr("Posunout řádek dolů"), lambda: self._ed("move_line", False), "Alt+Down", m)
        m.addSeparator()
        self._act(tr("Doplnit"), lambda: self._ed("trigger_completion"), "Ctrl+Space", m)
        self._act(tr("Přejít na definici"), self.goto_definition, "F12", m)

        m = mb.addMenu(tr("&Spustit"))
        tb.addSeparator()
        act_run = self._act(tr("Spustit"), self.run_current, "F5", m, tb, icon="run")
        act_args = self._act(tr("Spustit s argumenty…"), self.run_with_args, "Shift+F5", m)
        self._act(tr("Přeložit…"), self.compile_current, "Ctrl+F5", m, tb, icon="build")
        act_unsafe = self._act(tr("Přeložit --unsafe do binárky…"), lambda: self.compile_current(unsafe=True), None, m)
        run_btn = tb.widgetForAction(act_run)
        if isinstance(run_btn, QtWidgets.QToolButton):
            run_btn.setObjectName("primaryButton")
            run_menu = QtWidgets.QMenu(run_btn)
            run_menu.addAction(act_args)
            run_menu.addAction(act_unsafe)
            run_btn.setMenu(run_menu)
            run_btn.setPopupMode(QtWidgets.QToolButton.ToolButtonPopupMode.MenuButtonPopup)
            self._run_btn = run_btn
        self._act(tr("Zastavit"), self.run_panel.stop, "Shift+F6", m, tb, icon="stop")
        m.addSeparator()
        self._act(tr("Zkontrolovat"), self.check_now, "F7", m, tb, icon="check")
        self.act_check = self._act(tr("Průběžná kontrola chyb"), self.toggle_check, None, m, checkable=True)
        self.act_check.setChecked(self.settings.value("check/enabled", True, bool))
        m.addSeparator()
        self._act(tr("Limit paměti programu…"), self.memory_limit_dialog, None, m)
        self._apply_memory_limit()

        m = mb.addMenu(tr("&Knihovny"))
        tb.addSeparator()
        self._act(tr("Knihovny…"), self.open_packages, "Ctrl+Shift+P", m, tb, icon="package")
        self._act(tr("Toolchain…"), self.open_toolchain_dialog, None, m, tb, icon="tool")
        self._act(tr("Znovu načíst index stdlib"), self.reload_stdlib_index, None, m)

        m = mb.addMenu(tr("&Agent"))
        self._act(tr("Otevřít agenta"), self.show_agent, "Ctrl+Shift+A", m, tb, icon="agent")
        self._act(tr("Poslat výběr agentovi…"), self.agent_with_selection, "Ctrl+Shift+E", m)
        self._act(tr("Přihlásit k LuxAI…"), self.agent_sign_in, None, m)
        self._act(tr("Odhlásit"), self.agent_sign_out, None, m)
        self._act(tr("Nová konverzace"), self.agent_new_conversation, None, m)

        m = mb.addMenu(tr("&Cloud"))
        self._act(tr("Otevřít cloud"), self.show_cloud, "Ctrl+Shift+C", m, tb, icon="cloud")
        self._act(tr("Nahrát otevřený soubor do cloudu…"), self.cloud_panel.upload_current, "Ctrl+Shift+U", m)
        self._act(tr("Stáhnout vše z cloudu"), self.cloud_panel.download_all, None, m)
        self._act(tr("Obnovit seznam cloudu"), lambda: self.cloud_panel.refresh(), None, m)

        m = mb.addMenu(tr("&Zobrazit"))
        m.addAction(self.project_dock.toggleViewAction())
        m.addAction(self.outline_dock.toggleViewAction())
        m.addAction(self.symbol_dock.toggleViewAction())
        m.addAction(self.agent_dock.toggleViewAction())
        m.addAction(self.cloud_dock.toggleViewAction())
        m.addAction(self.bottom_dock.toggleViewAction())
        self._act("Symbol", self.show_symbol_info, "Ctrl+I", m, tb, icon="info")
        m.addSeparator()
        self._act(tr("Výstup"), lambda: self.show_bottom(0), "Alt+1", m)
        self._act(tr("Problémy"), lambda: self.show_bottom(1), "Alt+2", m)
        self._act(tr("Manuál"), lambda: self.show_bottom(2), "Alt+3", m)
        m.addSeparator()
        theme_menu = m.addMenu(tr("Motiv"))
        self.theme_group = QtGui.QActionGroup(self)
        self.theme_group.setExclusive(True)
        for key, t in theme.THEMES.items():
            a = QtGui.QAction(tr(t["title"]) + ("" if t["dark"] else tr("  (světlý)")), self)
            a.setCheckable(True)
            a.setChecked(key == self.theme_name)
            a.triggered.connect(lambda _c=False, key=key: self.set_theme(key))
            self.theme_group.addAction(a)
            theme_menu.addAction(a)
        lang_menu = m.addMenu(tr("Jazyk"))
        self.lang_group = QtGui.QActionGroup(self)
        for key, title in (("cs", "Čeština"), ("en", "English")):
            a = QtGui.QAction(title, self)
            a.setCheckable(True)
            a.setChecked(key == i18n.LANG)
            a.triggered.connect(lambda _c=False, key=key: self.set_language(key))
            self.lang_group.addAction(a)
            lang_menu.addAction(a)
        m.addSeparator()
        self.act_header = self._act(tr("Horní lišta LSL IDE"), self.toggle_header, None, m, checkable=True)
        self.act_header.setChecked(self.settings.value("ui/header", True, bool))
        self.act_fullscreen = self._act(tr("Celá obrazovka"), self.toggle_fullscreen, "F11", m, checkable=True)
        self._act(tr("Režim bez rozptylování (jen editor)"), self.toggle_zen, "Ctrl+Shift+F11", m, checkable=True)
        self._act(tr("Zvětšit písmo"), lambda: self.zoom(1), "Ctrl++", m)
        self._act(tr("Zmenšit písmo"), lambda: self.zoom(-1), "Ctrl+-", m)
        self._act(tr("Písmo editoru…"), self.choose_font, None, m)

        m = mb.addMenu(tr("&Nápověda"))
        self._act(tr("Manuál k slovu pod kurzorem"), self.help_word, "F1", m)
        self._act(tr("Web lsl.lux-ai.cz"), lambda: QtGui.QDesktopServices.openUrl(QtCore.QUrl("https://lsl.lux-ai.cz/")), None, m)
        self._act(tr("O aplikaci"), self.about, None, m)
        self._update_recent_menu()

    def _apply_theme(self):
        p = self.palette_data
        app = QtWidgets.QApplication.instance()
        self.theme_colors = theme.apply(app, self.theme_name)
        for a in getattr(self, "_icon_actions", []):
            a.setIcon(theme.icon(a.data(), "#ffffff" if a.data() == "run" else self.theme_colors["text"]))
        if hasattr(self, "header"):
            self.header.set_colors(self.theme_colors)
        for i in range(self.tabs.count()):
            self.tabs.widget(i).editor.apply_palette(p)
        mono = self.editor_font
        self.run_panel.set_font(mono)
        self.run_panel.set_ansi_palette(self.theme_colors)
        self.agent_panel.set_font(mono)
        self.cloud_panel.set_font(mono)
        self.manual.set_colors(self.theme_colors, self.palette_data, mono)

    # --- toolchain ------------------------------------------------------------------
    def init_toolchain(self):
        found = tcmod.discover(self.settings.value("toolchain/path", "", str))
        if found:
            self.set_toolchain(found[0])
        else:
            self.status_tc.setText(tr("LSL: nenalezeno"))
            self.open_toolchain_dialog(first_run=True)

    def set_toolchain(self, tc):
        self.toolchain = tc
        self.checker.set_toolchain(tc)
        self.run_panel.set_toolchain(tc)
        self.manual.set_toolchain(tc)
        try:
            self.symbol_panel.reference_text = tc.run(["man", "--plain", "reference"], timeout=20).stdout if tc else ""
        except Exception:  # noqa: BLE001
            self.symbol_panel.reference_text = ""
        self.status_tc.setText(tc.label if tc else tr("LSL: nenalezeno"))
        self.status_tc.setToolTip(tc.path if tc else "")
        self.reload_stdlib_index()
        self.check_now()

    def reload_stdlib_index(self):
        if not self.toolchain:
            return
        try:
            out = self.toolchain.run(["list"], timeout=30)
            self.stdlib_index.load_from_list_output(out.stdout)
            self.statusBar().showMessage(tr('Index knihoven: {0} modulů').format(len(self.stdlib_index.modules)), 3000)
        except Exception as e:  # noqa: BLE001
            self.statusBar().showMessage(tr("Index knihoven selhal: {0}").format(e), 5000)

    def open_toolchain_dialog(self, first_run=False):
        d = ToolchainDialog(self.toolchain, self.settings, self, first_run=first_run)
        d.toolchain_selected.connect(self.set_toolchain)
        d.exec()
        if not self.toolchain:
            self.status_tc.setText(tr("LSL: nenalezeno (Knihovny → Toolchain)"))

    def open_packages(self):
        if not self.toolchain:
            self.open_toolchain_dialog(first_run=True)
            if not self.toolchain:
                return
        d = PackageManager(self.toolchain, self)
        d.open_requested = self.open_file
        d.packages_changed.connect(self.reload_stdlib_index)
        d.exec()
        self.reload_stdlib_index()

    # --- soubory ----------------------------------------------------------------------
    def current_tab(self):
        return self.tabs.currentWidget()

    def current_editor(self):
        t = self.current_tab()
        return t.editor if t else None

    def _ed(self, method, *args):
        ed = self.current_editor()
        if ed:
            getattr(ed, method)(*args)

    def new_file(self):
        tab = EditorTab(self)
        tab.editor.setPlainText(new_file_template())
        tab.editor.document().setModified(False)
        self._add_tab(tab)

    def _add_tab(self, tab):
        i = self.tabs.addTab(tab, tab.title)
        self.tabs.setCurrentIndex(i)
        tab.editor.textChanged.connect(self.outline_timer.start)
        tab.editor.setFocus()
        self.refresh_outline()
        tab.check_now()

    def open_file(self, path):
        path = str(Path(path).expanduser().resolve())
        for i in range(self.tabs.count()):
            if self.tabs.widget(i).path == path:
                self.tabs.setCurrentIndex(i)
                return True
        if not Path(path).is_file():
            self.statusBar().showMessage(tr("Soubor neexistuje: {0}").format(path), 4000)
            return False
        tab = EditorTab(self, path)
        try:
            tab.load(path)
        except OSError as e:
            QtWidgets.QMessageBox.warning(self, tr("Otevřít"), str(e))
            return False
        cur = self.current_tab()
        if cur and not cur.path and not cur.editor.document().isModified() and self.tabs.count() == 1:
            self.tabs.removeTab(0)
        self._add_tab(tab)
        self._push_recent(path)
        return True

    def open_file_dialog(self):
        start = self.settings.value("project/folder", str(Path.home()), str)
        paths, _ = QtWidgets.QFileDialog.getOpenFileNames(self, tr("Otevřít soubor LSL"), start, tr("LSL (*.lsl *.conf);;Vše (*)"))
        for p in paths:
            self.open_file(p)

    def open_folder_dialog(self):
        d = QtWidgets.QFileDialog.getExistingDirectory(self, tr("Otevřít složku projektu"), self.settings.value("project/folder", str(Path.home()), str))
        if d:
            self.open_folder(d)

    def open_folder(self, folder):
        self.fs_model.setRootPath(folder)
        self.tree.setRootIndex(self.fs_model.index(folder))
        self.settings.setValue("project/folder", folder)
        self.project_dock.setWindowTitle(tr("Projekt — {0}").format(Path(folder).name))
        self.project_dock.show()

    def _tree_open(self, index):
        path = self.fs_model.filePath(index)
        if Path(path).is_file():
            self.open_file(path)

    def _tree_menu(self, pos):
        index = self.tree.indexAt(pos)
        path = self.fs_model.filePath(index) if index.isValid() else self.fs_model.rootPath()
        menu = QtWidgets.QMenu(self)
        folder = path if Path(path).is_dir() else str(Path(path).parent)
        menu.addAction(tr("Nový soubor LSL zde…"), lambda: self._new_file_in(folder))
        if Path(path).is_file():
            menu.addAction(tr("Otevřít"), lambda: self.open_file(path))
            if path.endswith(".lsl"):
                menu.addAction(tr("Spustit"), lambda: self.run_path(path))
            menu.addAction(tr("Přejmenovat…"), lambda: self._rename(path))
            menu.addAction(tr("Smazat…"), lambda: self._delete(path))
        menu.addAction(tr("Otevřít ve správci souborů"), lambda: QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(folder)))
        menu.exec(self.tree.viewport().mapToGlobal(pos))

    def _new_file_in(self, folder):
        name, ok = QtWidgets.QInputDialog.getText(self, tr("Nový soubor"), tr("Název:"), text="program.lsl")
        if ok and name:
            p = Path(folder) / name
            if not p.exists():
                p.write_text(new_file_template(), encoding="utf-8")
            self.open_file(str(p))

    def _rename(self, path):
        name, ok = QtWidgets.QInputDialog.getText(self, tr("Přejmenovat"), tr("Nový název:"), text=Path(path).name)
        if ok and name and name != Path(path).name:
            new = str(Path(path).with_name(name))
            os.rename(path, new)
            for i in range(self.tabs.count()):
                t = self.tabs.widget(i)
                if t.path == path:
                    t.path = new
                    t.editor.file_path = new
                    self.update_tab_title(t)

    def _delete(self, path):
        if QtWidgets.QMessageBox.question(self, tr("Smazat"), tr("Smazat {0}?").format(path)) == QtWidgets.QMessageBox.StandardButton.Yes:
            os.remove(path)
            for i in range(self.tabs.count()):
                if self.tabs.widget(i).path == path:
                    self.tabs.removeTab(i)
                    break

    def save_file(self):
        t = self.current_tab()
        if not t:
            return False
        if not t.path:
            return self.save_file_as()
        t.save()
        self.update_tab_title(t)
        self.statusBar().showMessage(tr('Uloženo {0}').format(t.path), 2000)
        t.check_now()
        self.cloud_panel.on_local_saved(t.path)
        return True

    def save_file_as(self):
        t = self.current_tab()
        if not t:
            return False
        start = t.path or str(Path(self.settings.value("project/folder", str(Path.home()), str)) / "program.lsl")
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, tr("Uložit jako"), start, tr("LSL (*.lsl);;Vše (*)"))
        if not path:
            return False
        if "." not in Path(path).name:
            path += ".lsl"
        t.save(path)
        self.update_tab_title(t)
        self._push_recent(path)
        t.check_now()
        self.cloud_panel.on_local_saved(path)
        return True

    def save_all(self):
        for i in range(self.tabs.count()):
            t = self.tabs.widget(i)
            if t.path and t.editor.document().isModified():
                t.save()
                self.update_tab_title(t)
                self.cloud_panel.on_local_saved(t.path)

    def close_tab(self, index):
        t = self.tabs.widget(index)
        if t is None:
            return
        if t.editor.document().isModified():
            self.tabs.setCurrentIndex(index)
            r = QtWidgets.QMessageBox.question(
                self, tr("Neuložené změny"), tr('Uložit změny v {0}?').format(t.title),
                QtWidgets.QMessageBox.StandardButton.Save | QtWidgets.QMessageBox.StandardButton.Discard | QtWidgets.QMessageBox.StandardButton.Cancel)
            if r == QtWidgets.QMessageBox.StandardButton.Cancel:
                return
            if r == QtWidgets.QMessageBox.StandardButton.Save and not self.save_file():
                return
        self.tabs.removeTab(index)
        t.deleteLater()
        if self.tabs.count() == 0:
            self.problems.clear()
            self.outline.clear()

    def update_tab_title(self, tab):
        i = self.tabs.indexOf(tab)
        if i >= 0:
            mod = "● " if tab.editor.document().isModified() else ""
            self.tabs.setTabText(i, mod + tab.title)
            self.tabs.setTabToolTip(i, tab.path)
        self.setWindowTitle(f"{tab.title} — {APP_NAME}")

    def _tab_changed(self, _i):
        t = self.current_tab()
        if t:
            self.update_tab_title(t)
            self._fill_problems(t.editor.diagnostics)
            self.refresh_outline()
            self.update_cursor_status()

    def _push_recent(self, path):
        rec = [p for p in self.settings.value("recent", [], list) if p != path]
        rec.insert(0, path)
        self.settings.setValue("recent", rec[:30])
        self._update_recent_menu()

    def _recent_files(self):
        return [p for p in self.settings.value("recent", [], list) if Path(p).is_file()]

    def _update_recent_menu(self):
        self.recent_menu.clear()
        recent = self._recent_files()
        for i, p in enumerate(recent[:20]):
            name = Path(p).name
            a = self.recent_menu.addAction(f"&{i + 1}  {name}   ({Path(p).parent})" if i < 9 else f"{name}   ({Path(p).parent})",
                                           lambda p=p: self.open_file(p))
            a.setToolTip(p)
        if recent:
            self.recent_menu.addSeparator()
            self.recent_menu.addAction(tr("Otevřít všechny nedávné"), lambda: [self.open_file(p) for p in recent[:20]])
            self.recent_menu.addAction(tr("Vymazat seznam"), self._clear_recent)
        else:
            a = self.recent_menu.addAction(tr("(žádné soubory)"))
            a.setEnabled(False)

    def _clear_recent(self):
        self.settings.remove("recent")
        self._update_recent_menu()

    def open_recent_dialog(self):
        """Ctrl+E: rychlý výběr z nedávných souborů s filtrováním."""
        recent = self._recent_files()
        if not recent:
            self.statusBar().showMessage(tr("Žádné nedávné soubory"), 3000)
            return
        d = QtWidgets.QDialog(self)
        d.setWindowTitle(tr("Nedávné soubory"))
        d.resize(640, 420)
        lay = QtWidgets.QVBoxLayout(d)
        flt = QtWidgets.QLineEdit()
        flt.setPlaceholderText(tr("Filtr… (Enter otevře vybraný)"))
        lst = QtWidgets.QListWidget()
        lay.addWidget(flt)
        lay.addWidget(lst, 1)

        def fill():
            lst.clear()
            q = flt.text().lower()
            for p in recent:
                if q in p.lower():
                    it = QtWidgets.QListWidgetItem(f"{Path(p).name}    {Path(p).parent}")
                    it.setData(Qt.ItemDataRole.UserRole, p)
                    lst.addItem(it)
            if lst.count():
                lst.setCurrentRow(0)

        def accept():
            it = lst.currentItem()
            if it:
                self.open_file(it.data(Qt.ItemDataRole.UserRole))
                d.accept()

        flt.textChanged.connect(fill)
        flt.returnPressed.connect(accept)
        lst.itemActivated.connect(lambda _i: accept())
        fill()
        flt.setFocus()
        d.exec()

    # --- session (otevřené soubory) ---------------------------------------------------
    def save_session(self):
        tabs = []
        for i in range(self.tabs.count()):
            t = self.tabs.widget(i)
            if t.path and Path(t.path).is_file():
                c = t.editor.textCursor()
                tabs.append({"path": t.path, "line": c.blockNumber() + 1, "col": c.positionInBlock() + 1,
                             "scroll": t.editor.verticalScrollBar().value()})
        self.settings.setValue("session/tabs", json.dumps(tabs))
        cur = self.current_tab()
        self.settings.setValue("session/current", cur.path if cur and cur.path else "")

    def restore_session(self):
        try:
            tabs = json.loads(self.settings.value("session/tabs", "[]", str) or "[]")
        except ValueError:
            tabs = []
        opened = False
        for entry in tabs:
            p = entry.get("path", "")
            if p and Path(p).is_file() and self.open_file(p):
                opened = True
                ed = self.current_editor()
                ed.go_to_line(int(entry.get("line", 1)), int(entry.get("col", 1)))
                ed.verticalScrollBar().setValue(int(entry.get("scroll", 0)))
        cur = self.settings.value("session/current", "", str)
        if cur:
            for i in range(self.tabs.count()):
                if self.tabs.widget(i).path == cur:
                    self.tabs.setCurrentIndex(i)
                    break
        return opened

    # --- kontrola chyb ---------------------------------------------------------------
    def check_now(self):
        t = self.current_tab()
        if t and self.toolchain:
            self.status_check.setText(tr("kontrola…"))
            self.checker.check(t.editor.toPlainText(), t.path)

    def toggle_check(self, on):
        self.settings.setValue("check/enabled", bool(on))
        if on:
            self.check_now()
        else:
            for i in range(self.tabs.count()):
                self.tabs.widget(i).editor.set_diagnostics([])
            self.problems.clear()
            self.status_check.setText("")

    def on_check_finished(self, real_path, diags, raw):
        for i in range(self.tabs.count()):
            t = self.tabs.widget(i)
            if t.path == real_path:
                t.editor.set_diagnostics([d for d in diags if d.path == real_path or not d.path])
                if t is self.current_tab():
                    self._fill_problems(diags)
                break
        n = len(diags)
        self.status_check.setText(tr("✔ bez chyb") if n == 0 else tr("✖ {0} chyb").format(n) if n > 1 else tr("✖ 1 chyba"))
        self.status_check.setStyleSheet(f"color: {'#98c379' if n == 0 else '#ff5f5f'}")

    def _fill_problems(self, diags):
        self.problems.clear()
        for d in diags:
            it = QtWidgets.QTreeWidgetItem([d.severity, d.code, d.message, Path(d.path).name if d.path else "", str(d.line), d.help])
            it.setToolTip(3, d.path)
            it.setData(0, Qt.ItemDataRole.UserRole, (d.path, d.line, d.column))
            it.setForeground(0, QtGui.QColor("#ff5f5f" if d.severity == "error" else "#e5c07b"))
            self.problems.addTopLevelItem(it)
        for c in range(5):
            self.problems.resizeColumnToContents(c)

    def _problem_activated(self, item, _col):
        path, line, col = item.data(0, Qt.ItemDataRole.UserRole)
        self.goto_location(path, line, col)

    def goto_location(self, path, line, col=1):
        if path and Path(path).is_file():
            self.open_file(path)
        ed = self.current_editor()
        if ed:
            ed.go_to_line(line, col)

    # --- spouštění -------------------------------------------------------------------
    def _source_for_run(self):
        """Vrátí (cesta ke spuštění, skutečná cesta). Neuložený obsah jde do tmp,
        rozpracovaný soubor jako skrytá kopie vedle originálu (kvůli lokálním load)."""
        t = self.current_tab()
        if not t:
            return None, None
        text = t.editor.toPlainText()
        if t.path and not t.editor.document().isModified():
            return t.path, t.path
        if t.path and self.settings.value("run/autosave", False, bool):
            t.save()
            self.update_tab_title(t)
            return t.path, t.path
        if t.path:
            d = Path(t.path).parent
            tmp = d / f".lslide-run-{os.getpid()}-{Path(t.path).name}" if os.access(str(d), os.W_OK) else None
        else:
            tmp = None
        if tmp is None:
            self._scratch_dir.mkdir(parents=True, exist_ok=True)
            idx = self.tabs.indexOf(t)
            tmp = self._scratch_dir / f"{Path(t.path).stem if t.path else 'bez-nazvu-' + str(idx)}.lsl"
        tmp.write_text(text, encoding="utf-8")
        return str(tmp), t.path or str(tmp)

    def _apply_memory_limit(self):
        self.run_panel.memory_limit_mb = sandbox.limit_from_settings(self.settings)

    def memory_limit_dialog(self):
        """Strop adresního prostoru spuštěného programu (RLIMIT_AS). Chrání počítač
        před programem, který by alokacemi vyčerpal RAM a swap; 0 = bez limitu."""
        current = sandbox.limit_from_settings(self.settings)
        total = sandbox.total_memory_mb()
        value, ok = QtWidgets.QInputDialog.getInt(
            self, tr("Limit paměti programu"),
            tr("Nejvyšší paměť (MB) pro spuštěný program a programy spouštěné agentem.\n"
               "Při překročení skončí program chybou místo zamrznutí počítače.\n"
               "0 = bez limitu (nedoporučeno). Výchozí: {0} MB, RAM: {1} MB.").format(sandbox.default_limit_mb(), total),
            current, 0, 1 << 20, 256)
        if ok:
            self.settings.setValue(sandbox.SETTING_KEY, int(value))
            self._apply_memory_limit()

    def run_current(self):
        run_path, real = self._source_for_run()
        if run_path:
            self.run_path(run_path, real_path=real)

    def run_path(self, path, args="", real_path=None):
        if not self.toolchain:
            self.open_toolchain_dialog(first_run=True)
            return
        self.show_bottom(0)
        real = real_path or path
        self.run_panel.path_alias = {path: real} if real != path else {}
        self.run_panel.run_program(path, args, display=real, cleanup=(path if real != path and Path(path).name.startswith(".lslide-run-") else None))

    def run_with_args(self):
        run_path, real = self._source_for_run()
        if not run_path:
            return
        last = self.settings.value(f"run/args/{real}", "", str)
        args, ok = QtWidgets.QInputDialog.getText(self, tr("Argumenty programu"), tr("Argumenty (shell syntaxe):"), text=last)
        if ok:
            self.settings.setValue(f"run/args/{real}", args)
            self.run_path(run_path, args, real_path=real)

    def compile_current(self, unsafe=False):
        t = self.current_tab()
        if t and (not t.path or t.editor.document().isModified()) and not self.save_file():
            return
        path = t.path if t else None
        if not path or not self.toolchain:
            return
        out, _ = QtWidgets.QFileDialog.getSaveFileName(self, tr("Výstupní binárka"), str(Path(path).with_suffix("")))
        if out:
            self.show_bottom(0)
            self.run_panel.compile_program(path, out, unsafe=unsafe)

    def _on_screen_mode(self, on):
        """TUI program: ukázat panel Výstup a dát mu aspoň polovinu výšky okna."""
        if on:
            self.show_bottom(0)
            want = max(360, self.height() // 2)
            if self.bottom_dock.height() < want:
                self.resizeDocks([self.bottom_dock], [want], Qt.Orientation.Vertical)
            self.run_panel.view.setFocus()

    def _run_finished(self, code, output):
        if code != 0:
            diags = self.run_panel.last_diagnostics()
            if diags:
                t = self.current_tab()
                if t and any(d.path == t.path for d in diags):
                    t.editor.set_diagnostics([d for d in diags if d.path == t.path])
                    self._fill_problems(t.editor.diagnostics)

    # --- různé --------------------------------------------------------------------------
    def show_bottom(self, idx):
        self.bottom_dock.show()
        self.bottom.setCurrentIndex(idx)

    def show_find(self):
        self.findbar.show()
        ed = self.current_editor()
        if ed and ed.textCursor().hasSelection():
            self.findbar.find.setText(ed.textCursor().selectedText())
        self.findbar.find.setFocus()
        self.findbar.find.selectAll()

    def show_replace(self):
        self.show_find()
        self.findbar.replace.setFocus()

    def goto_line_dialog(self):
        ed = self.current_editor()
        if not ed:
            return
        n, ok = QtWidgets.QInputDialog.getInt(self, tr("Přejít na řádek"), tr("Řádek:"), ed.textCursor().blockNumber() + 1, 1, max(1, ed.blockCount()))
        if ok:
            ed.go_to_line(n)

    def goto_definition(self):
        ed = self.current_editor()
        if not ed:
            return
        word, dotted = ed.word_at_cursor()
        if not word:
            return
        from .syntax import imported_names, loaded_module_lists
        text = ed.toPlainText()
        if dotted:
            mod, sym = self.stdlib_index.lookup_member(loaded_module_lists(text).get(dotted), word, ed.file_path)
            if sym:
                self.open_file(mod.path)
                self.current_editor().go_to_line(sym.line)
                return
        line = ed.definition_of(word)
        imp = imported_names(text).get(word) if not dotted else None
        loaded = loaded_module_lists(text).get(word) if not dotted else None
        if line:
            ed.go_to_line(line)
        elif imp and self.stdlib_index.lookup_member([imp[0]], imp[1], ed.file_path)[1]:
            mod, sym = self.stdlib_index.lookup_member([imp[0]], imp[1], ed.file_path)
            self.open_file(mod.path)
            self.current_editor().go_to_line(sym.line)
        elif loaded and self.stdlib_index.resolve(loaded[0], ed.file_path):
            self.open_file(self.stdlib_index.resolve(loaded[0], ed.file_path).path)
        elif word in self.stdlib_index.modules:
            self.open_file(self.stdlib_index.modules[word].path)
        else:
            # lokální modul vedle souboru
            if ed.file_path:
                p = Path(ed.file_path).parent / f"{word}.lsl"
                if p.is_file():
                    self.open_file(str(p))
                    return
            self.statusBar().showMessage(tr("Definice „{0}“ nenalezena").format(word), 3000)

    def open_manual_at(self, topic, word):
        self.show_bottom(2)
        self.manual.show_topic(topic, word)

    def help_word(self):
        ed = self.current_editor()
        word = ed.word_at_cursor()[0] if ed else ""
        self.show_bottom(2)
        if word:
            self.manual.lookup(word)

    def show_cloud(self):
        self.cloud_dock.show()
        self.cloud_dock.raise_()
        if not self.cloud_panel.logged_in():
            self.agent_panel.login()
            self.cloud_panel.account_changed()

    def show_agent(self):
        self.agent_dock.show()
        self.agent_dock.raise_()
        self.agent_panel.input.setFocus()

    def agent_sign_in(self):
        self.show_agent()
        self.agent_panel.login()

    def agent_sign_out(self):
        self.agent_panel.logout()

    def agent_new_conversation(self):
        self.show_agent()
        self.agent_panel.new_conversation()

    def agent_with_selection(self):
        ed = self.current_editor()
        self.show_agent()
        if ed and ed.textCursor().hasSelection():
            sel = ed.textCursor().selectedText().replace(" ", "\n")
            self.agent_panel.input.setPlainText(tr("K tomuto kódu:") + "\n```lsl\n" + sel + "\n```\n")
            c = self.agent_panel.input.textCursor()
            c.movePosition(QtGui.QTextCursor.MoveOperation.End)
            self.agent_panel.input.setTextCursor(c)

    def refresh_symbol_info(self):
        ed = self.current_editor()
        if ed and self.symbol_dock.isVisible():
            self.symbol_panel.describe(ed, self.stdlib_index, ed.file_path)

    def show_symbol_info(self):
        self.symbol_dock.show()
        self.symbol_dock.raise_()
        ed = self.current_editor()
        if ed:
            self.symbol_panel.describe(ed, self.stdlib_index, ed.file_path)

    def refresh_outline(self):
        from .syntax import local_symbols
        self.outline.clear()
        ed = self.current_editor()
        if not ed:
            return
        for name, sig, line in local_symbols(ed.toPlainText()):
            it = QtWidgets.QListWidgetItem(("ƒ " if sig.startswith("function") else "◆ ") + sig.split(" ", 1)[1])
            it.setData(Qt.ItemDataRole.UserRole, line)
            it.setToolTip(tr('řádek {0}').format(line))
            self.outline.addItem(it)

    def update_cursor_status(self):
        ed = self.current_editor()
        if ed:
            c = ed.textCursor()
            self.status_pos.setText(tr('Ř {0}, S {1}').format(c.blockNumber()+1, c.positionInBlock()+1))

    def set_language(self, key):
        self.settings.setValue("ui/lang", key)
        i18n.set_language(key)
        QtWidgets.QMessageBox.information(self, tr("Jazyk"), tr("Změna jazyka se projeví po restartu IDE."))

    def set_theme(self, key):
        self.theme_name = key
        self.palette_data = theme.get(key)["editor"]
        self.settings.setValue("ui/theme", key)
        self._apply_theme()

    def toggle_header(self, on):
        self.settings.setValue("ui/header", bool(on))
        self._apply_header(on)

    def _apply_header(self, on, initial=False):
        """Vlastní lišta nahrazuje systémový titulek: okno je bez rámu, velikost
        se mění tažením za okraj (eventFilter) a rohovým úchytem ve stavovém řádku."""
        self.header.setVisible(on)
        was_visible = self.isVisible()
        self.setWindowFlag(Qt.WindowType.FramelessWindowHint, bool(on))
        if not initial and was_visible:
            self.show()
        self.statusBar().setSizeGripEnabled(bool(on))

    _EDGE = 6
    _L, _R, _T, _B = 1, 2, 4, 8  # bitové hodnoty Qt.Edge (PyQt6 flagy nejdou přetypovat na int)
    _CURSORS = {
        1: Qt.CursorShape.SizeHorCursor, 2: Qt.CursorShape.SizeHorCursor,
        4: Qt.CursorShape.SizeVerCursor, 8: Qt.CursorShape.SizeVerCursor,
        1 | 4: Qt.CursorShape.SizeFDiagCursor, 2 | 8: Qt.CursorShape.SizeFDiagCursor,
        2 | 4: Qt.CursorShape.SizeBDiagCursor, 1 | 8: Qt.CursorShape.SizeBDiagCursor,
    }

    def _edges_at(self, gpos):
        """Vrátí bitovou masku okrajů pod kurzorem (0 = žádný)."""
        if self.isMaximized() or self.isFullScreen():
            return 0
        r = self.frameGeometry()
        e = 0
        m = self._EDGE
        if abs(gpos.x() - r.left()) <= m:
            e |= self._L
        if abs(gpos.x() - r.right()) <= m:
            e |= self._R
        if abs(gpos.y() - r.top()) <= m:
            e |= self._T
        if abs(gpos.y() - r.bottom()) <= m:
            e |= self._B
        return e

    def _qt_edges(self, mask):
        e = Qt.Edge(0)
        for bit, edge in ((self._L, Qt.Edge.LeftEdge), (self._R, Qt.Edge.RightEdge),
                          (self._T, Qt.Edge.TopEdge), (self._B, Qt.Edge.BottomEdge)):
            if mask & bit:
                e |= edge
        return e

    def eventFilter(self, obj, ev):  # noqa: N802
        # Neošetřená výjimka v eventFilteru ukončí celý proces (PyQt6), proto try/except.
        try:
            if self.header.isVisible() and ev.type() in (QtCore.QEvent.Type.MouseMove, QtCore.QEvent.Type.MouseButtonPress) \
                    and isinstance(obj, QtWidgets.QWidget) and obj.window() is self and isinstance(ev, QtGui.QMouseEvent):
                gpos = ev.globalPosition().toPoint()
                mask = self._edges_at(gpos)
                if ev.type() == QtCore.QEvent.Type.MouseMove and not (ev.buttons() & Qt.MouseButton.LeftButton):
                    shape = self._CURSORS.get(mask)
                    if shape is not None:
                        if not self._edge_cursor:
                            QtWidgets.QApplication.setOverrideCursor(shape)
                            self._edge_cursor = True
                    elif self._edge_cursor:
                        QtWidgets.QApplication.restoreOverrideCursor()
                        self._edge_cursor = False
                elif ev.type() == QtCore.QEvent.Type.MouseButtonPress and mask and ev.button() == Qt.MouseButton.LeftButton:
                    wh = self.windowHandle()
                    if wh is not None and wh.startSystemResize(self._qt_edges(mask)):
                        return True
        except Exception as e:  # noqa: BLE001
            print(f"lsl-ide: eventFilter: {e}", file=sys.stderr)
        return super().eventFilter(obj, ev)

    def toggle_fullscreen(self, on=None):
        # Stav se bere z okna, ne z checkboxu akce: ten se může rozejít (Esc, správce oken).
        on = not self.isFullScreen() if on is None or isinstance(on, bool) and on == self.isFullScreen() else on
        if on:
            self._pre_fullscreen_maximized = self.isMaximized()
            self.setWindowState(self.windowState() | Qt.WindowState.WindowFullScreen)
        else:
            self.setWindowState(self.windowState() & ~Qt.WindowState.WindowFullScreen)
            if getattr(self, "_pre_fullscreen_maximized", False):
                self.showMaximized()
        self.act_fullscreen.blockSignals(True)
        self.act_fullscreen.setChecked(on)
        self.act_fullscreen.blockSignals(False)

    def changeEvent(self, event):  # noqa: N802
        if event.type() == QtCore.QEvent.Type.WindowStateChange and hasattr(self, "act_fullscreen"):
            self.act_fullscreen.blockSignals(True)
            self.act_fullscreen.setChecked(self.isFullScreen())
            self.act_fullscreen.blockSignals(False)
            if hasattr(self, "header"):
                self.header.set_colors(self.theme_colors)
        super().changeEvent(event)

    def toggle_zen(self, on):
        """Skryje všechny docky a toolbar; opakované stisknutí je vrátí."""
        if on:
            self._zen_state = self.saveState()
            for d in (self.project_dock, self.outline_dock, self.symbol_dock, self.bottom_dock):
                d.hide()
            for tb in self.findChildren(QtWidgets.QToolBar):
                tb.hide()
        else:
            st = getattr(self, "_zen_state", None)
            if st is not None:
                self.restoreState(st)
            for tb in self.findChildren(QtWidgets.QToolBar):
                tb.show()

    def keyPressEvent(self, event):  # noqa: N802
        if event.key() == Qt.Key.Key_Escape and self.isFullScreen():
            self.toggle_fullscreen(False)
            return
        super().keyPressEvent(event)

    def zoom(self, delta):
        size = max(6, self.editor_font.pointSize() + delta)
        self.editor_font.setPointSize(size)
        self.settings.setValue("editor/font_size", size)
        for i in range(self.tabs.count()):
            self.tabs.widget(i).editor.set_font(self.editor_font)
        self.run_panel.set_font(self.editor_font)

    def choose_font(self):
        font, ok = QtWidgets.QFontDialog.getFont(self.editor_font, self, tr("Písmo editoru"))
        if ok:
            self.editor_font = font
            self.settings.setValue("editor/font_family", font.family())
            self.settings.setValue("editor/font_size", font.pointSize())
            self.zoom(0)

    def about(self):
        QtWidgets.QMessageBox.about(
            self, tr("O aplikaci"),
            tr('<b>{0} {1}</b><br>Vývojové prostředí pro Lux Simple Lang.<br>').format(APP_NAME, __version__) +
            f"Qt: {QT_LIB}, Python {sys.version.split()[0]}<br>"
            "Toolchain: " + (self.toolchain.label if self.toolchain else tr("nenalezen")))

    def closeEvent(self, event):  # noqa: N802
        for i in range(self.tabs.count()):
            t = self.tabs.widget(i)
            if t.editor.document().isModified():
                self.tabs.setCurrentIndex(i)
                r = QtWidgets.QMessageBox.question(
                    self, tr("Neuložené změny"), tr('Uložit změny v {0}?').format(t.title),
                    QtWidgets.QMessageBox.StandardButton.Save | QtWidgets.QMessageBox.StandardButton.Discard | QtWidgets.QMessageBox.StandardButton.Cancel)
                if r == QtWidgets.QMessageBox.StandardButton.Cancel:
                    event.ignore()
                    return
                if r == QtWidgets.QMessageBox.StandardButton.Save and not self.save_file():
                    event.ignore()
                    return
        self.save_session()
        self.run_panel.stop()
        self.agent_panel.stop()
        self.checker.shutdown()
        self.settings.setValue("ui/geometry", self.saveGeometry())
        self.settings.setValue("ui/state", self.saveState())
        event.accept()


def main(argv=None):
    argv = list(sys.argv if argv is None else argv)
    QtCore.QCoreApplication.setApplicationName("lsl-ide")
    QtCore.QCoreApplication.setOrganizationName("lsl-ide")
    app = QtWidgets.QApplication(argv)
    app.setApplicationDisplayName(APP_NAME)
    settings = QtCore.QSettings("lsl-ide", settings_profile())
    i18n.set_language(settings.value("ui/lang", i18n.detect_language(), str))
    share = Path(__file__).resolve().parent.parent / "share"
    icon = QtGui.QIcon()
    for f in sorted((share / "icons").glob("*.png")):
        icon.addFile(str(f))
    if icon.isNull() and (share / "lsl-ide.png").is_file():
        icon = QtGui.QIcon(str(share / "lsl-ide.png"))
    if not icon.isNull():
        app.setWindowIcon(icon)
    win = MainWindow(files=argv[1:])
    win.show()
    return app.exec()
