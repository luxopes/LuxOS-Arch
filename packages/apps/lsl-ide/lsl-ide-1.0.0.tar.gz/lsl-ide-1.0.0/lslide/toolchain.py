"""Nalezení, verze, stažení a instalace toolchainu LSL.

Instalované LSL se hledá v tomto pořadí:
  1. cesta nastavená v IDE (Nastavení → Toolchain),
  2. `lsl` v PATH,
  3. ~/.local/bin/lsl a /usr/local/bin/lsl,
  4. lokální toolchain IDE: ~/.local/share/lsl-ide/toolchain/current/bin/lsl.
"""
import hashlib
from .i18n import tr
import json
import os
import shutil
import subprocess
import tarfile
import tempfile
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from . import sandbox

CHANNEL_URL = "https://lsl.lux-ai.cz/updates/channels/stable.json"
REGISTRY_URL = "https://lsl.lux-ai.cz/packages"
DATA_DIR = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "lsl-ide"
CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "lsl-ide"
LOCAL_TOOLCHAIN_DIR = DATA_DIR / "toolchain"
LOCAL_CURRENT = LOCAL_TOOLCHAIN_DIR / "current"
USER_STDLIB_DIR = Path.home() / ".local" / "lib" / "lsl" / "stdlib"


def base_env():
    env = dict(os.environ)
    env["NO_COLOR"] = "1"
    env.pop("CLICOLOR_FORCE", None)
    return env


@dataclass
class Toolchain:
    path: str          # absolutní cesta k binárce lsl
    kind: str          # "settings" | "path" | "user" | "system" | "ide"
    version: str = ""

    @property
    def bin_dir(self):
        return str(Path(self.path).parent)

    @property
    def label(self):
        names = {"settings": tr("vlastní cesta"), "path": "PATH", "user": "~/.local",
                 "system": "/usr/local", "ide": tr("lokální v IDE")}
        v = self.version or "?"
        return f"LSL {v} ({names.get(self.kind, self.kind)}: {self.path})"

    def tool(self, name):
        """Cesta k sesterskému nástroji (lslc, lsl-install, lsl-test…)."""
        return str(Path(self.bin_dir) / name)

    def run(self, args, timeout=120, cwd=None, input_text=None):
        # Limit adresního prostoru chrání IDE i před překladačem, který by na vadném
        # vstupu alokoval bez konce (stejný strop jako pro spuštěný program).
        return subprocess.run([self.path, *args], capture_output=True, text=True,
                              timeout=timeout, cwd=cwd, env=base_env(), input=input_text,
                              preexec_fn=sandbox.preexec(sandbox.default_limit_mb()))

    def probe_version(self):
        try:
            out = self.run(["version"], timeout=10)
            self.version = (out.stdout or out.stderr).strip().splitlines()[0] if (out.stdout or out.stderr).strip() else ""
        except Exception:
            self.version = ""
        return self.version

    def is_user_updatable(self):
        """Self-updater LSL umí ~/.local bez sudo a /usr/local s --system."""
        return os.path.realpath(self.path).startswith(str(Path.home()))


def _candidate(path, kind):
    p = Path(path)
    if p.is_file() and os.access(p, os.X_OK):
        return Toolchain(str(p), kind)
    return None


def discover(settings_path: str = ""):
    """Vrátí seznam nalezených toolchainů (bez duplicit, v pořadí priority)."""
    found = []
    seen = set()

    def add(tc):
        if tc and os.path.realpath(tc.path) not in seen:
            seen.add(os.path.realpath(tc.path))
            found.append(tc)

    if settings_path:
        add(_candidate(settings_path, "settings"))
    which = shutil.which("lsl")
    if which:
        add(_candidate(which, "path"))
    add(_candidate(Path.home() / ".local" / "bin" / "lsl", "user"))
    add(_candidate("/usr/local/bin/lsl", "system"))
    add(_candidate("/usr/bin/lsl", "system"))
    add(_candidate(LOCAL_CURRENT / "bin" / "lsl", "ide"))
    for tc in found:
        tc.probe_version()
    return found


def local_toolchains():
    """Verze LSL rozbalené uvnitř IDE (~/.local/share/lsl-ide/toolchain/lsl-*)."""
    if not LOCAL_TOOLCHAIN_DIR.is_dir():
        return []
    out = []
    for d in sorted(LOCAL_TOOLCHAIN_DIR.glob("lsl-*")):
        b = d / "bin" / "lsl"
        if b.is_file():
            out.append(d)
    return out


# --- stažení vydání -----------------------------------------------------------

def fetch_channel(url=CHANNEL_URL, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": "lsl-ide"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8"))
    if data.get("schema") != 1 or data.get("product") != "lsl":
        raise RuntimeError(tr("Neznámý formát kanálu vydání"))
    return data


def pick_artifact(channel):
    for a in channel.get("artifacts", []):
        if a.get("os") == "linux" and a.get("architecture") == "x86_64" and a.get("format") == "tar.gz":
            return a
    raise RuntimeError(tr("Kanál neobsahuje archiv pro Linux x86_64"))


def download_release(artifact, progress=None, timeout=60):
    """Stáhne tar.gz, ověří SHA-256 a rozbalí do dočasného adresáře. Vrací (root_dir, tmp_dir)."""
    tmp = Path(tempfile.mkdtemp(prefix="lsl-ide-dl-"))
    archive = tmp / os.path.basename(artifact["url"])
    req = urllib.request.Request(artifact["url"], headers={"User-Agent": "lsl-ide"})
    h = hashlib.sha256()
    total = int(artifact.get("size") or 0)
    done = 0
    with urllib.request.urlopen(req, timeout=timeout) as r, open(archive, "wb") as f:
        while True:
            chunk = r.read(65536)
            if not chunk:
                break
            f.write(chunk)
            h.update(chunk)
            done += len(chunk)
            if progress:
                progress(done, total)
    if artifact.get("sha256") and h.hexdigest() != artifact["sha256"]:
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError(tr("SHA-256 staženého archivu nesouhlasí s kanálem vydání"))
    root_name = artifact.get("archive_root") or ""
    with tarfile.open(archive) as tar:
        members = tar.getmembers()
        for m in members:
            name = m.name
            if name.startswith("/") or ".." in Path(name).parts:
                raise RuntimeError(tr('Archiv obsahuje nebezpečnou cestu: {0}').format(name))
        try:
            tar.extractall(tmp, filter="data")
        except TypeError:  # Python < 3.12
            tar.extractall(tmp)
    root = tmp / root_name if root_name and (tmp / root_name).is_dir() else None
    if root is None:
        dirs = [d for d in tmp.iterdir() if d.is_dir()]
        root = dirs[0] if dirs else tmp
    if not (root / "bin" / "lsl").is_file():
        raise RuntimeError(tr("Archiv neobsahuje bin/lsl"))
    return root, tmp


def install_local(root: Path, version: str):
    """Rozbalené vydání přesune do IDE toolchainu a přepne symlink `current`."""
    LOCAL_TOOLCHAIN_DIR.mkdir(parents=True, exist_ok=True)
    target = LOCAL_TOOLCHAIN_DIR / f"lsl-{version}"
    if target.exists():
        shutil.rmtree(target)
    shutil.move(str(root), str(target))
    switch_local(target)
    return target


def switch_local(target: Path):
    tmp_link = LOCAL_TOOLCHAIN_DIR / ".current.tmp"
    if tmp_link.is_symlink() or tmp_link.exists():
        tmp_link.unlink()
    os.symlink(target.name, tmp_link)
    os.replace(tmp_link, LOCAL_CURRENT)


def installer_command(root: Path, prefix: str, system: bool):
    """Příkaz pro bin/lsl-install: bez sudo do ~/.local, přes pkexec do /usr/local."""
    installer = str(root / "bin" / "lsl-install")
    cmd = [installer, prefix]
    if system:
        if shutil.which("pkexec"):
            cmd = ["pkexec", *cmd]
        else:
            raise RuntimeError(tr("Pro systémovou instalaci je potřeba pkexec (polkit) nebo spusťte ručně: sudo ") + " ".join(cmd))
    return cmd


def format_size(n):
    for unit in ("B", "KiB", "MiB", "GiB"):
        if n < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TiB"
