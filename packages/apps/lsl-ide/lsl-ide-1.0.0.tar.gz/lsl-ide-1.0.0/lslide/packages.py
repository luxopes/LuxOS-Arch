"""Správce knihoven LSL a toolchainu — vše přes GUI.

Používá oficiální CLI: `lsl list`, `lsl search`, `lsl check`, `lsl install`,
`lsl update NAME`, `lsl origin NAME`; katalog čte z REGISTRY/catalog.json.
Odinstalace = smazání NAME.lsl a NAME.lsl.origin v ~/.local/lib/lsl/stdlib
(CLI vlastní příkaz nemá).
"""
import json
import os
import re
import urllib.request
from pathlib import Path

from .qt import QtCore, QtGui, QtWidgets, Qt, Signal
from .i18n import tr
from .toolchain import REGISTRY_URL, USER_STDLIB_DIR, base_env
from .stdlib_index import RE_LIST_LINE


def fetch_catalog(registry=REGISTRY_URL, timeout=20):
    req = urllib.request.Request(registry.rstrip("/") + "/catalog.json", headers={"User-Agent": "lsl-ide"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8"))
    if data.get("schema") != 1:
        raise RuntimeError(tr("Nepodporované schéma katalogu"))
    return data.get("packages", [])


def read_origin(name):
    p = USER_STDLIB_DIR / f"{name}.lsl.origin"
    out = {}
    try:
        for line in p.read_text(encoding="utf-8").splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    except OSError:
        pass
    return out


class Worker(QtCore.QThread):
    done = Signal(object, str)

    def __init__(self, fn, parent=None):
        super().__init__(parent)
        self.fn = fn

    def run(self):
        try:
            self.done.emit(self.fn(), "")
        except Exception as e:  # noqa: BLE001
            self.done.emit(None, str(e))


class PackageManager(QtWidgets.QDialog):
    """Dialog: Nainstalované | Katalog | Toolchain LSL."""
    packages_changed = Signal()
    run_in_output = Signal(list, str)   # argv pro lsl, popis

    def __init__(self, toolchain, parent=None):
        super().__init__(parent)
        self.toolchain = toolchain
        self.setWindowTitle(tr("Správce knihoven LSL"))
        self.resize(900, 560)
        self.registry = os.environ.get("LSL_REGISTRY", REGISTRY_URL)
        self.catalog = []
        self.installed = []
        self._workers = []

        lay = QtWidgets.QVBoxLayout(self)
        self.tabs = QtWidgets.QTabWidget()
        lay.addWidget(self.tabs, 1)
        prow = QtWidgets.QHBoxLayout()
        self.op_label = QtWidgets.QLabel(tr("Připraveno"))
        self.op_label.setObjectName("opStatus")
        self.op_bar = QtWidgets.QProgressBar()
        self.op_bar.setRange(0, 0)
        self.op_bar.setFixedWidth(160)
        self.op_bar.setTextVisible(False)
        self.op_bar.setVisible(False)
        prow.addWidget(self.op_label, 1)
        prow.addWidget(self.op_bar)
        lay.addLayout(prow)
        self._queue_total = 0
        self._queue_done = 0
        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(110)
        self.log.setPlaceholderText(tr("Výstup příkazů lsl…"))
        lay.addWidget(self.log)
        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Close)
        btns.rejected.connect(self.reject)
        lay.addWidget(btns)

        self._build_installed_tab()
        self._build_catalog_tab()
        self.refresh_all()

    # --- záložka Nainstalované ---------------------------------------------------
    def _build_installed_tab(self):
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        top = QtWidgets.QHBoxLayout()
        self.inst_filter = QtWidgets.QLineEdit()
        self.inst_filter.setPlaceholderText(tr("Filtr…"))
        self.inst_filter.textChanged.connect(self._fill_installed)
        self.show_bundled = QtWidgets.QCheckBox(tr("Zobrazit bundled moduly"))
        self.show_bundled.setChecked(True)
        self.show_bundled.toggled.connect(self._fill_installed)
        top.addWidget(self.inst_filter, 1)
        top.addWidget(self.show_bundled)
        v.addLayout(top)
        self.inst_table = QtWidgets.QTableWidget(0, 5)
        self.inst_table.setHorizontalHeaderLabels(["Název", "Typ", tr("Verze"), tr("Stav"), tr("Cesta")])
        self.inst_table.horizontalHeader().setSectionResizeMode(4, QtWidgets.QHeaderView.ResizeMode.Stretch)
        self.inst_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.inst_table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.inst_table.itemSelectionChanged.connect(self._installed_selection)
        self.inst_table.verticalHeader().setVisible(False)
        v.addWidget(self.inst_table, 1)
        row = QtWidgets.QHBoxLayout()
        self.btn_update = QtWidgets.QPushButton(tr("Aktualizovat"))
        self.btn_update.clicked.connect(self._update_selected)
        self.btn_remove = QtWidgets.QPushButton(tr("Odinstalovat"))
        self.btn_remove.clicked.connect(self._remove_selected)
        self.btn_origin = QtWidgets.QPushButton(tr("Původ / integrita"))
        self.btn_origin.clicked.connect(self._origin_selected)
        self.btn_open = QtWidgets.QPushButton(tr("Otevřít zdroj v editoru"))
        self.btn_open.clicked.connect(self._open_selected)
        self.btn_refresh = QtWidgets.QPushButton(tr("Obnovit"))
        self.btn_refresh.clicked.connect(self.refresh_all)
        for b in (self.btn_update, self.btn_remove, self.btn_origin, self.btn_open):
            row.addWidget(b)
        row.addStretch(1)
        row.addWidget(self.btn_refresh)
        v.addLayout(row)
        self.tabs.addTab(w, tr("Nainstalované"))
        self.open_requested = None  # callback nastaví hlavní okno

    def _installed_selection(self):
        pkg = self._selected_installed()
        user = bool(pkg and pkg["kind"] == "user")
        self.btn_update.setEnabled(user)
        self.btn_remove.setEnabled(user)
        self.btn_origin.setEnabled(user)
        self.btn_open.setEnabled(pkg is not None)

    def _selected_installed(self):
        rows = self.inst_table.selectionModel().selectedRows()
        if not rows:
            return None
        return self.inst_table.item(rows[0].row(), 0).data(Qt.ItemDataRole.UserRole)

    def _fill_installed(self):
        flt = self.inst_filter.text().lower()
        show_b = self.show_bundled.isChecked()
        cat = {p["name"]: p for p in self.catalog}
        self.inst_table.setRowCount(0)
        for pkg in self.installed:
            if pkg["kind"] == "bundled" and not show_b:
                continue
            if flt and flt not in pkg["name"].lower():
                continue
            r = self.inst_table.rowCount()
            self.inst_table.insertRow(r)
            origin = read_origin(pkg["name"]) if pkg["kind"] == "user" else {}
            version, state = "", ""
            if pkg["kind"] == "bundled":
                version = self.toolchain.version if self.toolchain else ""
                state = tr("součást LSL")
            else:
                c = cat.get(pkg["name"])
                if c:
                    version = c.get("version", "")
                    if origin.get("sha256") and origin["sha256"] != c.get("sha256"):
                        state = tr("k dispozici aktualizace")
                        version = f"? → {c.get('version', '')}"
                    else:
                        state = tr("aktuální")
                else:
                    state = tr("není v katalogu") if self.catalog else ""
                if not origin:
                    state += tr(" (bez provenance)")
            items = [pkg["name"], pkg["kind"], version, state, pkg["path"]]
            for col, val in enumerate(items):
                it = QtWidgets.QTableWidgetItem(val)
                if col == 0:
                    it.setData(Qt.ItemDataRole.UserRole, pkg)
                if "aktualizace" in state:
                    it.setForeground(QtGui.QColor("#e5c07b"))
                self.inst_table.setItem(r, col, it)
        self.inst_table.resizeColumnsToContents()
        self.inst_table.horizontalHeader().setSectionResizeMode(4, QtWidgets.QHeaderView.ResizeMode.Stretch)
        self._installed_selection()

    # --- záložka Katalog --------------------------------------------------------------
    def _build_catalog_tab(self):
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        top = QtWidgets.QHBoxLayout()
        self.cat_filter = QtWidgets.QLineEdit()
        self.cat_filter.setPlaceholderText(tr("Hledat v katalogu (název, popis)…"))
        self.cat_filter.textChanged.connect(self._fill_catalog)
        self.registry_label = QtWidgets.QLabel(tr("Registr: ") + self.registry)
        top.addWidget(self.cat_filter, 1)
        top.addWidget(self.registry_label)
        v.addLayout(top)
        self.cat_table = QtWidgets.QTableWidget(0, 6)
        self.cat_table.setHorizontalHeaderLabels(["Název", tr("Verze"), tr("Popis"), tr("Licence"), tr("Velikost"), tr("Stav")])
        self.cat_table.horizontalHeader().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeMode.Stretch)
        self.cat_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.cat_table.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.ExtendedSelection)
        self.cat_table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.cat_table.verticalHeader().setVisible(False)
        v.addWidget(self.cat_table, 1)
        row = QtWidgets.QHBoxLayout()
        self.btn_install = QtWidgets.QPushButton(tr("Nainstalovat vybrané"))
        self.btn_install.clicked.connect(self._install_selected)
        self.btn_cat_refresh = QtWidgets.QPushButton(tr("Obnovit katalog"))
        self.btn_cat_refresh.clicked.connect(self.refresh_catalog)
        self.btn_config = QtWidgets.QPushButton(tr("Instalovat ze souboru (libraries.conf)…"))
        self.btn_config.clicked.connect(self._install_from_config)
        row.addWidget(self.btn_install)
        row.addWidget(self.btn_config)
        row.addStretch(1)
        row.addWidget(self.btn_cat_refresh)
        v.addLayout(row)
        self.tabs.addTab(w, tr("Katalog"))

    def _fill_catalog(self):
        flt = self.cat_filter.text().lower()
        inst = {p["name"]: p for p in self.installed}
        self.cat_table.setRowCount(0)
        for p in self.catalog:
            hay = (p.get("name", "") + " " + p.get("description", "")).lower()
            if flt and flt not in hay:
                continue
            r = self.cat_table.rowCount()
            self.cat_table.insertRow(r)
            state = tr("nenainstalováno")
            if p["name"] in inst:
                o = read_origin(p["name"])
                state = tr("nainstalováno") if o.get("sha256") == p.get("sha256") else tr("nainstalováno (jiná verze)")
            size = p.get("size", 0)
            vals = [p.get("name", ""), p.get("version", ""), p.get("description", ""), p.get("license", ""),
                    f"{size} B", state]
            for col, val in enumerate(vals):
                it = QtWidgets.QTableWidgetItem(val)
                if col == 0:
                    it.setData(Qt.ItemDataRole.UserRole, p)
                self.cat_table.setItem(r, col, it)
        self.cat_table.resizeColumnsToContents()
        self.cat_table.horizontalHeader().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeMode.Stretch)

    # --- akce -------------------------------------------------------------------------
    def log_line(self, text):
        self.log.appendPlainText(text.rstrip())

    def refresh_all(self):
        self.refresh_installed()
        self.refresh_catalog()

    def refresh_installed(self):
        if not self.toolchain:
            return

        def job():
            out = self.toolchain.run(["list"], timeout=30)
            pk = []
            for line in out.stdout.splitlines():
                m = RE_LIST_LINE.match(line.strip())
                if m:
                    pk.append({"name": m.group(1), "kind": m.group(2), "path": m.group(3).strip()})
            return pk

        def done(res, err):
            if err:
                self.log_line(f"lsl list: {err}")
                return
            self.installed = res
            self._fill_installed()
            self._fill_catalog()
            self.packages_changed.emit()

        self._spawn(job, done)

    def refresh_catalog(self):
        def done(res, err):
            if err:
                self.log_line(tr('Katalog nelze načíst: {0}').format(err))
                return
            self.catalog = res
            self._fill_catalog()
            self._fill_installed()

        self._spawn(lambda: fetch_catalog(self.registry), done)

    def _spawn(self, fn, done):
        w = Worker(fn, self)
        self._workers.append(w)
        w.done.connect(done)
        w.finished.connect(lambda: self._workers.remove(w) if w in self._workers else None)
        w.start()

    def _set_busy(self, text, busy=True, ok=None):
        """Stavový řádek nad logem: běžící operace (pruh) / výsledek (zeleně, červeně)."""
        self.op_bar.setVisible(busy)
        prefix = "⏳ " if busy else ("✔ " if ok else "✖ ")
        self.op_label.setText(prefix + text)
        color = "" if busy else ("color: #4ade80;" if ok else "color: #ff5c7a;")
        self.op_label.setStyleSheet(color)
        self.tabs.setEnabled(not busy)
        QtWidgets.QApplication.processEvents()

    def _run_lsl(self, args, then=None):
        self.log_line("$ lsl " + " ".join(args))
        counter = f" ({self._queue_done + 1}/{self._queue_total})" if self._queue_total > 1 else ""
        self._set_busy(tr("Probíhá: lsl {0}").format(" ".join(args)) + counter + " …")

        def job():
            return self.toolchain.run(args, timeout=300)

        def done(res, err):
            if err:
                self.log_line(err)
                self._set_busy(tr("Selhalo: lsl {0} — {1}").format(" ".join(args), err), busy=False, ok=False)
            else:
                self.log_line((res.stdout + res.stderr).strip() or f"(kód {res.returncode})")
                if res.returncode != 0:
                    self.log_line(f"[kód {res.returncode}]")
                    self._set_busy(tr("Selhalo: lsl {0} (kód {1})").format(" ".join(args), res.returncode), busy=False, ok=False)
                else:
                    self._set_busy(tr("Hotovo: lsl {0}").format(" ".join(args)), busy=False, ok=True)
            self.log_line(tr("[hotovo]") if not err and res.returncode == 0 else tr("[selhalo]"))
            self._queue_done += 1
            if self._queue_done >= self._queue_total:
                self._queue_total = self._queue_done = 0
            self.refresh_installed()
            if then:
                then(res, err)

        self._spawn(job, done)

    def _install_selected(self):
        rows = self.cat_table.selectionModel().selectedRows()
        names = [self.cat_table.item(r.row(), 0).text() for r in rows]
        if not names:
            return
        self._install_names(names)

    def _install_names(self, names):
        names = list(names)
        self._queue_total = len(names)
        self._queue_done = 0
        done_names = []

        def step(res=None, err=None):
            if names:
                self._run_lsl(["install", names.pop(0)], then=step)
            elif len(done_names) > 1:
                self._set_busy(tr("Hotovo: nainstalováno {0} knihoven").format(len(done_names)), busy=False, ok=True)

        step()

    def _install_from_config(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, tr("Soubor se seznamem knihoven"), str(Path.home()),
                                                        tr("Konfigurace (*.conf *.txt);;Vše (*)"))
        if path:
            self._run_lsl(["install", "--config", path])

    def _update_selected(self):
        pkg = self._selected_installed()
        if pkg and pkg["kind"] == "user":
            self._run_lsl(["update", pkg["name"]])

    def _origin_selected(self):
        pkg = self._selected_installed()
        if pkg:
            self._run_lsl(["origin", pkg["name"]])
            self._run_lsl(["check", pkg["name"]])

    def _open_selected(self):
        pkg = self._selected_installed()
        if pkg and self.open_requested:
            self.open_requested(pkg["path"])

    def _remove_selected(self):
        pkg = self._selected_installed()
        if not pkg or pkg["kind"] != "user":
            return
        p = Path(pkg["path"])
        if USER_STDLIB_DIR not in p.parents:
            QtWidgets.QMessageBox.warning(self, tr("Odinstalace"), tr("Lze odinstalovat jen knihovny z ~/.local/lib/lsl/stdlib."))
            return
        if QtWidgets.QMessageBox.question(
            self, tr("Odinstalovat knihovnu"),
            tr("Smazat {0} a jeho provenance sidecar z {1}?").format(p.name, p.parent),
        ) != QtWidgets.QMessageBox.StandardButton.Yes:
            return
        for f in (p, p.with_name(p.name + ".origin")):
            try:
                f.unlink()
                self.log_line(tr('smazáno {0}').format(f))
            except FileNotFoundError:
                pass
            except OSError as e:
                self.log_line(tr("nelze smazat {0}: {1}").format(f, e))
        self.refresh_installed()
