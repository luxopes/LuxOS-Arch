"""Kontrola chyb na pozadí: `lsl compile ZDROJ DOČASNÝ_VÝSTUP`.

Kompilace bez spuštění je jediný oficiální způsob, jak od LSL získat
diagnostiku. Zdroj se zapíše jako skrytý soubor vedle originálu (aby fungovaly
lokální `load` moduly) a po kontrole se smaže.
"""
import os
import re
import tempfile
from pathlib import Path

from .qt import QtCore, Signal
from .diagnostics import parse_diagnostics
from .toolchain import base_env


class Checker(QtCore.QObject):
    finished = Signal(str, list, str)  # real_path, diagnostics, raw output

    def __init__(self, parent=None):
        super().__init__(parent)
        self.toolchain = None
        self._proc = None
        self._pending = None
        self._tmp_src = None
        self._tmp_out = None
        self._real_path = ""
        self._unsafe_retry = False

    def set_toolchain(self, tc):
        self.toolchain = tc

    def check(self, text: str, real_path: str):
        if not self.toolchain:
            return
        self._pending = (text, real_path)
        if self._proc is None:
            self._start()

    def _start(self):
        text, real_path = self._pending
        self._pending = None
        self._real_path = real_path
        self._cleanup()
        if real_path and os.access(str(Path(real_path).parent), os.W_OK):
            d = Path(real_path).parent
            self._remove_stale(d)
            name = f".lslide-check-{os.getpid()}-{Path(real_path).name}"
            self._tmp_src = str(d / name)
        else:
            fd, self._tmp_src = tempfile.mkstemp(prefix="lslide-check-", suffix=".lsl")
            os.close(fd)
        fd, self._tmp_out = tempfile.mkstemp(prefix="lslide-out-")
        os.close(fd)
        try:
            Path(self._tmp_src).write_text(text, encoding="utf-8")
        except OSError:
            self._cleanup()
            return
        self._run(unsafe=False)

    def _run(self, unsafe):
        self._unsafe_retry = unsafe
        p = QtCore.QProcess(self)
        env = QtCore.QProcessEnvironment.systemEnvironment()
        env.insert("NO_COLOR", "1")
        p.setProcessEnvironment(env)
        p.setProcessChannelMode(QtCore.QProcess.ProcessChannelMode.MergedChannels)
        p.finished.connect(self._on_finished)
        p.errorOccurred.connect(lambda _e: self._on_finished(-1, None))
        args = ["compile"] + (["--unsafe"] if unsafe else []) + [self._tmp_src, self._tmp_out]
        cwd = str(Path(self._real_path).parent) if self._real_path else None
        if cwd:
            p.setWorkingDirectory(cwd)
        self._proc = p
        p.start(self.toolchain.path, args)

    def _on_finished(self, code, _status):
        p = self._proc
        if p is None:
            return
        try:
            out = bytes(p.readAllStandardOutput()).decode("utf-8", "replace")
        except RuntimeError:
            self._proc = None
            self._cleanup()
            return
        p.deleteLater()
        self._proc = None
        if code != 0 and not self._unsafe_retry and "unsafe" in out:
            self._run(unsafe=True)
            return
        diags = parse_diagnostics(out) if code != 0 else []
        for d in diags:
            if d.path == self._tmp_src or (self._tmp_src and d.path.endswith(Path(self._tmp_src).name)):
                d.path = self._real_path or self._tmp_src
        real = self._real_path
        self._cleanup()
        self.finished.emit(real, diags, out)
        if self._pending:
            self._start()

    @staticmethod
    def _remove_stale(directory):
        """Smaže .lslide-check-PID-* po procesech, které už neběží (např. po pádu IDE)."""
        try:
            for f in directory.glob(".lslide-check-*"):
                m = re.match(r"\.lslide-check-(\d+)-", f.name)
                if m and int(m.group(1)) != os.getpid():
                    try:
                        os.kill(int(m.group(1)), 0)
                    except ProcessLookupError:
                        f.unlink(missing_ok=True)
                    except PermissionError:
                        pass
        except OSError:
            pass

    def _cleanup(self):
        for f in (self._tmp_src, self._tmp_out):
            if f:
                try:
                    os.unlink(f)
                except OSError:
                    pass
        self._tmp_src = self._tmp_out = None

    def shutdown(self):
        if self._proc:
            p = self._proc
            self._proc = None
            try:
                p.finished.disconnect()
                p.errorOccurred.disconnect()
                p.kill()
                p.waitForFinished(500)
            except RuntimeError:
                pass
        self._cleanup()
