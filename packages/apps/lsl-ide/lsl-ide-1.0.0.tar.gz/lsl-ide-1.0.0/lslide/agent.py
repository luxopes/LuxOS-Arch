"""Coding agent LuxAI: nástroje nad projektem, smyčka tool use a panel v IDE.

Síťový požadavek běží ve vlákně (AgentWorker), nástroje se vykonávají v hlavním
vlákně (mají přístup k editorům), takže smyčka je stavový automat řízený signály:
  send → stream → (tool_calls? → vykonat → append → send) … → finish
"""
import fnmatch
import html as _html
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

from .qt import QtCore, QtGui, QtWidgets, Qt, Signal
from .i18n import tr
from . import luxai
from .luxai import LuxClient, LuxError
from .diagnostics import parse_diagnostics
from . import sandbox
from . import theme

try:
    import markdown as _markdown
except ImportError:  # pragma: no cover
    _markdown = None

CONV_DIR = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "lsl-ide" / "conversations"
MAX_TOOL_OUTPUT = 12_000
MAX_FILE_CHARS = 60_000
MAX_ITERATIONS = 24
HISTORY_CHAR_BUDGET = 90_000

SYSTEM_PROMPT = """You are the LSL coding agent inside LSL IDE. LSL (Lux Simple Lang) is NOT Python, JavaScript or LSL of Second Life. Key syntax:
- Blocks end with `end`: `function name(a, b=1):` … `end`, `class Name(Parent):` … `end`, `if x:` / `elif y:` / `else:` … `end`, `for item in list:` … `end`, `while cond:` … `end`, `loop:` … `end` (break), `try:` … `else:` … `end`, `safe:`/`unsafe:` blocks. Indentation is 4 spaces, but `end` is what closes a block.
- No `def`, `import`, `elif`-less chains or braces. Modules: `load json`, `load math as m`, `from mod load f, g`. Comments start with `#`. Strings "..." or '...', Lux strings `l"Hello {name}"`. Print is a statement: `print a, b`; `printl "x = {x}"`; `input "Prompt: "`.
- Call a function for its side effect with `call f(x)`. Errors: `Error(TypeError: "msg")`, `last_error()`. Constants True/False/None. Operators: and/or/not/in/is, `//` int division, `^` power, `~` XOR. Numbers 0x/0o/0b.
- Types: Int, Float, String, Bool, List, Tuple, Dictionary, IntArray, FloatArray, ByteArray, set(). Methods like `list.append(x)`, `str.split(",")`. `rang(n)` gives 0..n-1. `len`, `sorted`, `dedup`, `readfile`, `writefile`, `exists`.
- Standard modules (use tool lsl_modules for exact signatures): json, math, time, random, os, process, http, httpserver, env, fd, ai, bigint, tensor, cuda, system, sandbox, tui, ui, gfx, x11, wayland, display, input, css, lconf, config, configure, native, plugin, unixsock.
Rules: consult `lsl_manual` when unsure about syntax or a library. After editing code run `check_errors` on the file and fix compiler errors; run programs with `run_program` when useful. Keep tool outputs small; read only what you need. Answer in the user's language. Paths are relative to the project root unless absolute. Prefer `edit_file` for small changes and `write_file` for new files."""


def agent_log(line):
    """Diagnostický log přihlášení a agenta: ~/.cache/lsl-ide/agent.log."""
    try:
        d = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "lsl-ide"
        d.mkdir(parents=True, exist_ok=True)
        with open(d / "agent.log", "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + line + "\n")
    except OSError:
        pass


def _clip(text, limit=MAX_TOOL_OUTPUT):
    text = text if isinstance(text, str) else str(text)
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n… [truncated {len(text) - limit} chars]"


TOOL_SPECS = [
    {"name": "read_file", "description": "Read a text file (max 60k chars). Prefer this over guessing file contents.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "start_line": {"type": "integer", "description": "1-based, optional"}, "end_line": {"type": "integer"}}, "required": ["path"]}},
    {"name": "write_file", "description": "Create or overwrite a file with the given content. Open editor tabs are updated.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"]}},
    {"name": "edit_file", "description": "Replace an exact, unique text fragment in a file with new text.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "old_text": {"type": "string"}, "new_text": {"type": "string"}}, "required": ["path", "old_text", "new_text"]}},
    {"name": "list_files", "description": "List files under a directory of the project (recursive, glob filter).",
     "parameters": {"type": "object", "properties": {"path": {"type": "string", "default": "."}, "pattern": {"type": "string", "default": "*"}}}},
    {"name": "search_files", "description": "Search a text or regex in project files; returns path:line: text (max 100 hits).",
     "parameters": {"type": "object", "properties": {"query": {"type": "string"}, "pattern": {"type": "string", "default": "*.lsl"}, "regex": {"type": "boolean", "default": False}}, "required": ["query"]}},
    {"name": "current_file", "description": "Path, cursor position, selection and content of the file open in the editor (unsaved buffer).",
     "parameters": {"type": "object", "properties": {"with_content": {"type": "boolean", "default": True}}}},
    {"name": "check_errors", "description": "Compile an LSL file with the installed compiler and return diagnostics (empty = OK).",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "unsafe": {"type": "boolean", "default": False}}, "required": ["path"]}},
    {"name": "run_program", "description": "Run an LSL program with a timeout and return its output and exit code.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "args": {"type": "string", "default": ""}, "stdin": {"type": "string", "default": ""}, "timeout": {"type": "integer", "default": 20}}, "required": ["path"]}},
    {"name": "lsl_manual", "description": "Search the offline LSL manual (21 chapters + function reference). Returns the matching sections. Use for syntax, stdlib, CLI, packages.",
     "parameters": {"type": "object", "properties": {"query": {"type": "string"}, "topic": {"type": "string", "description": "optional chapter key such as 02-language-basics, 04-collections, reference"}}, "required": ["query"]}},
    {"name": "lsl_modules", "description": "List standard/installed LSL modules, or the functions of one module with signatures and doc comments.",
     "parameters": {"type": "object", "properties": {"module": {"type": "string", "description": "empty = list modules"}}}},
    {"name": "open_in_editor", "description": "Open a file in the IDE editor at a line.",
     "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "line": {"type": "integer", "default": 1}}, "required": ["path"]}},
]
WRITE_TOOLS = {"write_file", "edit_file", "run_program"}

# Ikona a český název nástroje pro kartu v transkriptu (název se překládá přes tr()).
TOOL_META = {
    "read_file": ("📄", "Čtení souboru"), "write_file": ("📝", "Zápis souboru"), "edit_file": ("✏️", "Úprava souboru"),
    "list_files": ("📁", "Výpis souborů"), "search_files": ("🔍", "Hledání v souborech"), "current_file": ("📌", "Aktuální soubor"),
    "check_errors": ("🧪", "Kontrola chyb"), "run_program": ("▶️", "Spuštění programu"), "lsl_manual": ("📖", "Manuál LSL"),
    "lsl_modules": ("📦", "Moduly stdlib"), "open_in_editor": ("↗️", "Otevření v editoru"),
}


def tool_definitions():
    return [{"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["parameters"]}} for t in TOOL_SPECS]


class AgentTools:
    """Implementace nástrojů; běží v hlavním vlákně (přístup k editorům přes main)."""

    def __init__(self, main):
        self.main = main

    # --- cesty ---------------------------------------------------------------
    def roots(self):
        r = []
        folder = self.main.settings.value("project/folder", "", str)
        if folder:
            r.append(Path(folder).resolve())
        for i in range(self.main.tabs.count()):
            p = self.main.tabs.widget(i).path
            if p:
                r.append(Path(p).resolve().parent)
        return r

    def resolve(self, path, must_exist=False):
        roots = self.roots()
        base = roots[0] if roots else Path.cwd()
        p = Path(path).expanduser()
        p = (p if p.is_absolute() else base / p).resolve()
        if not any(p == r or r in p.parents for r in roots):
            raise ValueError(f"path outside the project: {p} (allowed roots: {', '.join(str(r) for r in roots) or 'none'})")
        if must_exist and not p.exists():
            raise FileNotFoundError(str(p))
        return p

    # --- soubory -------------------------------------------------------------
    def read_file(self, path, start_line=None, end_line=None):
        p = self.resolve(path, True)
        text = self._buffer_or_disk(p)
        lines = text.splitlines()
        if start_line or end_line:
            a = max(1, int(start_line or 1))
            b = min(len(lines), int(end_line or len(lines)))
            body = "\n".join(f"{i}: {lines[i - 1]}" for i in range(a, b + 1))
            return _clip(f"{p} lines {a}-{b} of {len(lines)}\n{body}", MAX_FILE_CHARS)
        return _clip(text, MAX_FILE_CHARS)

    def _buffer_or_disk(self, p):
        for i in range(self.main.tabs.count()):
            t = self.main.tabs.widget(i)
            if t.path and Path(t.path).resolve() == p:
                return t.editor.toPlainText()
        return p.read_text(encoding="utf-8", errors="replace")

    def _apply(self, p, text):
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        for i in range(self.main.tabs.count()):
            t = self.main.tabs.widget(i)
            if t.path and Path(t.path).resolve() == p:
                ed = t.editor
                c = ed.textCursor()
                pos = c.position()
                c.beginEditBlock()
                c.select(QtGui.QTextCursor.SelectionType.Document)
                c.insertText(text)
                c.endEditBlock()
                c.setPosition(min(pos, len(text)))
                ed.setTextCursor(c)
                ed.document().setModified(False)
                self.main.update_tab_title(t)
                t.check_now()
                self._cloud_saved(p)
                return True
        self._cloud_saved(p)
        return False

    def _cloud_saved(self, p):
        panel = getattr(self.main, "cloud_panel", None)
        if panel is not None:
            panel.on_local_saved(str(p))

    def write_file(self, path, content):
        p = self.resolve(path)
        existed = p.exists()
        self._apply(p, content)
        if not existed:
            self.main.open_file(str(p))
        return f"{'updated' if existed else 'created'} {p} ({len(content)} chars, {content.count(chr(10)) + 1} lines)"

    def edit_file(self, path, old_text, new_text):
        p = self.resolve(path, True)
        text = self._buffer_or_disk(p)
        n = text.count(old_text)
        if n == 0:
            return f"error: old_text not found in {p}. Read the file and copy the fragment exactly."
        if n > 1:
            return f"error: old_text occurs {n} times in {p}; include more context so it is unique."
        self._apply(p, text.replace(old_text, new_text, 1))
        return f"edited {p}: replaced {len(old_text)} chars with {len(new_text)} chars"

    def list_files(self, path=".", pattern="*"):
        p = self.resolve(path, True)
        out = []
        for root, dirs, files in os.walk(p):
            dirs[:] = sorted(d for d in dirs if not d.startswith(".") and d not in ("__pycache__", "node_modules"))
            for f in sorted(files):
                if f.startswith(".lslide-"):
                    continue
                if fnmatch.fnmatch(f, pattern):
                    fp = Path(root) / f
                    out.append(f"{fp.relative_to(p)}  ({fp.stat().st_size} B)")
                if len(out) >= 400:
                    out.append("… (more files not listed)")
                    return "\n".join(out)
        return "\n".join(out) or "(no files)"

    def search_files(self, query, pattern="*.lsl", regex=False):
        roots = self.roots()
        if not roots:
            return "error: no project folder open"
        rx = re.compile(query if regex else re.escape(query), re.I)
        hits = []
        for root in roots[:1] + [r for r in roots[1:] if r not in roots[:1] and roots[0] not in r.parents]:
            for dirpath, dirs, files in os.walk(root):
                dirs[:] = [d for d in dirs if not d.startswith(".")]
                for f in files:
                    if not fnmatch.fnmatch(f, pattern) or f.startswith(".lslide-"):
                        continue
                    fp = Path(dirpath) / f
                    try:
                        for no, line in enumerate(fp.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
                            if rx.search(line):
                                hits.append(f"{fp}:{no}: {line.strip()[:200]}")
                                if len(hits) >= 100:
                                    return _clip("\n".join(hits) + "\n… (limit 100)")
                    except OSError:
                        pass
        return _clip("\n".join(hits) or "(no matches)")

    def current_file(self, with_content=True):
        t = self.main.current_tab()
        if not t:
            return "(no file open)"
        ed = t.editor
        c = ed.textCursor()
        info = {"path": t.path or "(unsaved, untitled)", "line": c.blockNumber() + 1, "column": c.positionInBlock() + 1,
                "modified": ed.document().isModified(), "selection": c.selectedText().replace(" ", "\n")[:4000]}
        head = json.dumps(info, ensure_ascii=False)
        if with_content:
            return _clip(head + "\n---\n" + ed.toPlainText(), MAX_FILE_CHARS)
        return head

    # --- LSL -----------------------------------------------------------------
    def _source_path(self, path):
        """Neuložené buffery kompilujeme/spouštíme z dočasné kopie vedle souboru."""
        p = self.resolve(path, True)
        for i in range(self.main.tabs.count()):
            t = self.main.tabs.widget(i)
            if t.path and Path(t.path).resolve() == p and t.editor.document().isModified():
                tmp = p.parent / f".lslide-agent-{os.getpid()}-{p.name}"
                tmp.write_text(t.editor.toPlainText(), encoding="utf-8")
                return tmp, p
        return p, p

    def check_errors(self, path, unsafe=False):
        tc = self.main.toolchain
        if not tc:
            return "error: LSL toolchain not available"
        src, real = self._source_path(path)
        fd, out = tempfile.mkstemp(prefix="lslide-agent-out-")
        os.close(fd)
        try:
            args = ["compile"] + (["--unsafe"] if unsafe else []) + [str(src), out]
            r = tc.run(args, timeout=120, cwd=str(real.parent))
            text = (r.stdout + r.stderr).replace(str(src), str(real))
            if r.returncode == 0:
                return "OK: no compiler errors"
            if not unsafe and "unsafe" in text:
                return self.check_errors(path, True) + "\n(note: the file needs --unsafe)"
            diags = parse_diagnostics(text)
            summary = "\n".join(f"{d.severity} {d.code} {Path(d.path).name}:{d.line}:{d.column}: {d.message}" + (f" (help: {d.help})" if d.help else "") for d in diags)
            return _clip(summary or text)
        finally:
            for f in (out, ):
                try:
                    os.unlink(f)
                except OSError:
                    pass
            if src != real:
                try:
                    src.unlink()
                except OSError:
                    pass

    def run_program(self, path, args="", stdin="", timeout=20):
        tc = self.main.toolchain
        if not tc:
            return "error: LSL toolchain not available"
        src, real = self._source_path(path)
        limit = sandbox.limit_from_settings(self.main.settings)
        try:
            argv = [tc.path, str(src)] + ([a for a in re.split(r"\s+", args.strip()) if a] if args else [])
            env = dict(os.environ, NO_COLOR="1")
            t0 = time.time()
            code, out, note = sandbox.run_captured(argv, input_text=stdin, timeout=max(1, min(int(timeout), 120)),
                                                   cwd=str(real.parent), env=env, limit_mb=limit)
            out = out.replace(str(src), str(real))
            elapsed = time.time() - t0
            if note == "timeout":
                return _clip(f"timeout after {timeout}s (program killed)\n{out}")
            if note == "output_limit":
                return _clip(f"output limit exceeded ({sandbox.MAX_CAPTURED_OUTPUT // 1024} KB), program killed after {elapsed:.1f}s\n{out}")
            if note == "rss":
                return _clip(f"program killed: exceeded memory limit {limit} MB after {elapsed:.1f}s\n{out}")
            if note == "low_memory":
                return _clip(f"program killed: system ran out of free memory after {elapsed:.1f}s\n{out}")
            return _clip(f"exit code {code} in {elapsed:.1f}s\n{out}")
        finally:
            if src != real:
                try:
                    src.unlink()
                except OSError:
                    pass

    def lsl_manual(self, query, topic=""):
        man = self.main.manual
        if not man.topics:
            return "error: manual not available (no toolchain)"
        if not man._cache:
            # synchronně načíst kapitoly (index na pozadí ještě neběžel)
            for key, _t in man.topics:
                if key not in man._cache:
                    try:
                        man._cache[key] = self.main.toolchain.run(["man", "--plain", key], timeout=20).stdout
                    except Exception:  # noqa: BLE001
                        man._cache[key] = ""
        keys = [k for k, _ in man.topics]
        if topic and topic not in keys:
            return "error: unknown topic. Available: " + ", ".join(keys)
        rx = re.compile(re.escape(query), re.I)
        results = []
        for key, title in man.topics:
            if topic and key != topic:
                continue
            text = man._cache.get(key) or ""
            sections = re.split(r"(?m)^(?=#{1,4}\s)", text)
            for sec in sections:
                if rx.search(sec):
                    head = sec.splitlines()[0][:120] if sec.strip() else ""
                    body = sec.strip()
                    if len(body) > 2500:
                        m = rx.search(body)
                        s0 = max(0, m.start() - 900)
                        body = ("…" if s0 else "") + body[s0:s0 + 2500] + "…"
                    results.append((key, title, head, body))
        if not results:
            return f"no match for '{query}'. Chapters: " + ", ".join(f"{k} ({t})" for k, t in man.topics)
        results.sort(key=lambda r: (r[0] == "reference", 0))
        out = []
        for key, title, head, body in results[:4]:
            out.append(f"## [{key}] {title}\n{body}")
        if len(results) > 4:
            out.append(f"… {len(results) - 4} more sections match; narrow the query or set topic.")
        return _clip("\n\n".join(out), 14_000)

    def lsl_modules(self, module=""):
        idx = self.main.stdlib_index
        if not module:
            return "\n".join(f"{m.name} ({m.kind}): {m.doc[:100]}" for m in idx.modules.values()) or "(index empty)"
        mod = idx.modules.get(module)
        if not mod:
            return f"unknown module '{module}'. Known: " + ", ".join(idx.module_names())
        lines = [f"module {mod.name} ({mod.kind}) – {mod.doc}", f"source: {mod.path}"]
        for s in mod.symbols:
            lines.append(f"  {s.signature}" + (f"  # {s.doc}" if s.doc else ""))
        return _clip("\n".join(lines))

    def open_in_editor(self, path, line=1):
        p = self.resolve(path, True)
        self.main.open_file(str(p))
        self.main.current_editor().go_to_line(int(line or 1))
        return f"opened {p}:{line}"

    def call(self, name, args):
        fn = getattr(self, name, None)
        if not fn or name.startswith("_") or name not in {t["name"] for t in TOOL_SPECS}:
            return f"error: unknown tool {name}"
        try:
            return fn(**args)
        except TypeError as e:
            return f"error: bad arguments for {name}: {e}"
        except Exception as e:  # noqa: BLE001
            return f"error: {type(e).__name__}: {e}"


class AgentWorker(QtCore.QThread):
    delta = Signal(str)
    finished_ok = Signal(dict, str, object)
    failed = Signal(str, object)  # text chyby, LuxError (nebo None)

    def __init__(self, client, body, parent=None):
        super().__init__(parent)
        self.client = client
        self.body = body
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        try:
            msg, finish, usage = self.client.chat_stream(
                self.body, lambda d, f, u: self.delta.emit(d.get("content") or ""), should_stop=lambda: self._stop)
            if self._stop:
                self.failed.emit(tr("Zastaveno uživatelem."), None)
                return
            self.finished_ok.emit(msg, finish or "", usage)
        except LuxError as e:
            self.failed.emit(e.human(), e)
        except Exception as e:  # noqa: BLE001
            self.failed.emit(f"{type(e).__name__}: {e}", None)


class LoginDialog(QtWidgets.QDialog):
    def __init__(self, client, parent=None):
        super().__init__(parent)
        self.client = client
        self.setWindowTitle(tr("Přihlášení k LuxAI"))
        self.resize(460, 320)
        self.wc = None
        self._poll = None
        lay = QtWidgets.QVBoxLayout(self)
        intro = QtWidgets.QLabel(tr("Účet LuxAI (lux-ai.cz). Spotřeba agenta se počítá do měsíčního limitu účtu."))
        intro.setWordWrap(True)
        lay.addWidget(intro)
        # Přihlášení přes web (loopback) je vypnuté na přání uživatele; zůstává heslo a e-mailový kód.
        self.btn_web = QtWidgets.QPushButton(tr("Přihlásit přes web lux-ai.cz"))
        self.btn_web.clicked.connect(self._web_connect)
        self.btn_web.hide()
        self.web_status = QtWidgets.QLabel("")
        self.web_status.hide()
        self.advanced = QtWidgets.QGroupBox(tr("Přihlášení heslem nebo kódem z e-mailu"))
        adv_lay = QtWidgets.QVBoxLayout(self.advanced)
        lay.addWidget(self.advanced)
        form = QtWidgets.QFormLayout()
        adv_lay.addLayout(form)
        self.email = QtWidgets.QLineEdit()
        self.email.setPlaceholderText("jmeno@example.cz")
        self.password = QtWidgets.QLineEdit()
        self.password.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        self.code = QtWidgets.QLineEdit()
        self.code.setPlaceholderText(tr("6 číslic z e-mailu"))
        form.addRow(tr("E-mail:"), self.email)
        form.addRow(tr("Heslo:"), self.password)
        form.addRow(tr("Kód z e-mailu:"), self.code)
        self.origin = QtWidgets.QLineEdit(client.origin)
        self.origin.setToolTip(tr("Adresa LuxAI serveru (pro testování lze změnit)"))
        form.addRow(tr("Server:"), self.origin)
        self.status = QtWidgets.QLabel("")
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        self.status.setWordWrap(True)
        adv_lay.addWidget(self.status)
        row = QtWidgets.QHBoxLayout()
        adv_lay.addLayout(row)
        self.btn_pw = QtWidgets.QPushButton(tr("Přihlásit heslem"))
        self.btn_pw.clicked.connect(self._login_password)
        self.btn_send = QtWidgets.QPushButton(tr("Poslat kód"))
        self.btn_send.clicked.connect(self._send_code)
        self.btn_code = QtWidgets.QPushButton(tr("Přihlásit kódem"))
        self.btn_code.clicked.connect(self._login_code)
        for b in (self.btn_pw, self.btn_send, self.btn_code):
            row.addWidget(b)
        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Cancel)
        btns.rejected.connect(self.reject)
        lay.addWidget(btns)

    # --- přihlášení přes web ---------------------------------------------------
    def _web_connect(self, open_browser=True):
        self.client.origin = self.origin.text().strip().rstrip("/") or luxai.DEFAULT_ORIGIN
        self._web_cleanup()
        url, self.wc = self.client.web_connect_start()
        self.web_url = url
        agent_log(f"web connect start port={self.wc.port} origin={self.client.origin}")
        if open_browser:
            self._open_browser(url)
        # href musí mít & escapované, jinak Qt rich text upraví query (challenge) a server vydá kód k jinému tajemství
        self.web_status.setText(tr("V prohlížeči se přihlaste a klikněte na „Připojit LSL IDE“. Čekám na potvrzení…") +
                                f"<br><a href='{_html.escape(url, quote=True)}'>{tr('Otevřít stránku znovu')}</a>")
        self.web_status.setOpenExternalLinks(False)
        try:
            self.web_status.linkActivated.disconnect()
        except TypeError:
            pass
        self.web_status.linkActivated.connect(lambda _l: self._open_browser(self.web_url))
        self.btn_web.setEnabled(False)
        self._poll = QtCore.QTimer(self)
        self._poll.setInterval(400)
        self._poll.timeout.connect(self._web_poll)
        self._poll.start()

    def _open_browser(self, url):
        ok = QtGui.QDesktopServices.openUrl(QtCore.QUrl(url))
        agent_log(f"openUrl -> {ok}")
        if not ok:
            import webbrowser
            try:
                ok = webbrowser.open(url, new=2)
            except Exception as e:  # noqa: BLE001
                agent_log(f"webbrowser failed: {e}")
            agent_log(f"webbrowser.open -> {ok}")
        if not ok:
            QtWidgets.QApplication.clipboard().setText(url)
            self.web_status.setText(tr("Prohlížeč se nepodařilo otevřít. Adresa je ve schránce, vložte ji do prohlížeče:") + f"<br><code>{_html.escape(url)}</code>")

    def _web_poll(self):
        wc = self.wc
        if not wc or not wc.done:
            return
        self._poll.stop()
        agent_log(f"callback received: code_len={len(wc.code)} error={wc.error!r}")
        if wc.error or not wc.code:
            self.web_status.setText(tr("Připojení se nezdařilo: {0}").format(wc.error or "?"))
            self.btn_web.setEnabled(True)
            self._web_cleanup()
            return
        try:
            user = self.client.web_connect_finish(wc)
        except LuxError as e:
            agent_log(f"token exchange failed: {e.code} {e.status} {e.detail}")
            self.web_status.setText("<b>" + tr("Výměna kódu za přihlášení selhala:") + "</b> " + e.human() +
                                    "<br>" + tr("Zkuste to znovu tlačítkem výše."))
            self.btn_web.setEnabled(True)
            self._web_cleanup()
            return
        agent_log(f"signed in as {(user or {}).get('email')}")
        self._web_cleanup()
        self.accept()

    def _web_cleanup(self):
        if self._poll:
            self._poll.stop()
            self._poll = None
        if self.wc:
            self.wc.stop()
            self.wc = None

    def reject(self):
        self._web_cleanup()
        super().reject()

    def _run(self, fn):
        self.client.origin = self.origin.text().strip().rstrip("/") or luxai.DEFAULT_ORIGIN
        self.status.setText(tr("Pracuji…"))
        QtWidgets.QApplication.processEvents()
        try:
            fn()
        except LuxError as e:
            self.status.setText(e.human())
            return False
        return True

    def _login_password(self):
        if self._run(lambda: self.client.login_password(self.email.text().strip(), self.password.text())):
            self.accept()

    def _send_code(self):
        if self._run(lambda: self.client.request_code(self.email.text().strip())):
            self.status.setText(tr("Kód odeslán, pokud účet existuje."))

    def _login_code(self):
        if self._run(lambda: self.client.login_code(self.email.text().strip(), self.code.text().strip())):
            self.accept()


class AgentPanel(QtWidgets.QWidget):
    """Dock „Agent LuxAI“: účet, model, konverzace, vstup, nástroje."""

    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.tools = AgentTools(main)
        self.client = LuxClient(main.settings.value("luxai/origin", luxai.DEFAULT_ORIGIN, str),
                                main.settings.value("luxai/token", "", str))
        # Účet přihlášený v LuxOS (~/.config/luxai/account.json) má přednost před vlastním
        # přihlášením IDE; system_token je jeho token, dokud ho IDE používá.
        self.system_token = ""
        self._rejected_system = ""      # token ze souboru, který server odmítl (čeká na nové přihlášení v LuxOS)
        self._relogin_proc = None
        self._sync_system_account()
        self.messages = []
        self.worker = None
        self.iterations = 0
        self.pending_calls = []
        self._assistant_html_pos = None
        self._stream_text = ""
        self.tool_outputs = []          # plné výstupy nástrojů pro detail (odkaz toolout:N)
        self.conversation_id = ""
        self.conversation_title = ""
        self._build()
        self._load_history_list()
        if self.client.token:
            QtCore.QTimer.singleShot(200, self.refresh_account)

    # --- UI ------------------------------------------------------------------
    def _build(self):
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(6, 4, 6, 6)
        lay.setSpacing(4)
        top = QtWidgets.QHBoxLayout()
        self.account_label = QtWidgets.QLabel(tr("Nepřihlášen"))
        self.account_label.setObjectName("hint")
        self.btn_login = QtWidgets.QToolButton()
        self.btn_login.setText(tr("Přihlásit"))
        self.btn_login.clicked.connect(self.login)
        self.btn_logout = QtWidgets.QToolButton()
        self.btn_logout.setText(tr("Odhlásit"))
        self.btn_logout.clicked.connect(self.logout)
        self.btn_logout.setVisible(False)
        top.addWidget(self.account_label, 1)
        top.addWidget(self.btn_login)
        top.addWidget(self.btn_logout)
        lay.addLayout(top)
        self.usage_bar = QtWidgets.QProgressBar()
        self.usage_bar.setRange(0, 100)
        self.usage_bar.setValue(0)
        self.usage_bar.setFormat(tr("spotřeba %p %"))
        self.usage_bar.setFixedHeight(14)
        lay.addWidget(self.usage_bar)
        row = QtWidgets.QHBoxLayout()
        self.model_box = QtWidgets.QComboBox()
        for key, title in luxai.MODELS:
            self.model_box.addItem(title, key)
        self.model_box.setCurrentIndex(max(0, self.model_box.findData(self.main.settings.value("luxai/model", "flash", str))))
        self.model_box.currentIndexChanged.connect(lambda _i: self.main.settings.setValue("luxai/model", self.model_box.currentData()))
        self.auto_approve = QtWidgets.QCheckBox(tr("Zápisy a spouštění bez potvrzení"))
        self.auto_approve.setChecked(self.main.settings.value("luxai/auto_approve", False, bool))
        self.auto_approve.toggled.connect(lambda v: self.main.settings.setValue("luxai/auto_approve", bool(v)))
        row.addWidget(self.model_box, 1)
        lay.addLayout(row)
        lay.addWidget(self.auto_approve)
        hrow = QtWidgets.QHBoxLayout()
        self.history_box = QtWidgets.QComboBox()
        self.history_box.setToolTip(tr("Starší konverzace (ukládají se automaticky)"))
        self.history_box.activated.connect(self._history_selected)
        self.btn_delete_conv = QtWidgets.QToolButton()
        self.btn_delete_conv.setText("✕")
        self.btn_delete_conv.setToolTip(tr("Smazat vybranou konverzaci"))
        self.btn_delete_conv.clicked.connect(self._delete_conversation)
        hrow.addWidget(self.history_box, 1)
        hrow.addWidget(self.btn_delete_conv)
        lay.addLayout(hrow)
        self.view = QtWidgets.QTextBrowser()
        self.view.setOpenExternalLinks(False)
        self.view.setOpenLinks(False)
        self.view.anchorClicked.connect(self._anchor)
        lay.addWidget(self.view, 1)
        self.input = QtWidgets.QPlainTextEdit()
        self.input.setPlaceholderText(tr("Zadejte úkol pro agenta… (Ctrl+Enter odešle)"))
        self.input.setFixedHeight(84)
        self.input.installEventFilter(self)
        lay.addWidget(self.input)
        brow = QtWidgets.QHBoxLayout()
        self.btn_send = QtWidgets.QPushButton(tr("Odeslat"))
        self.btn_send.setDefault(True)
        self.btn_send.clicked.connect(self.send)
        self.btn_stop = QtWidgets.QPushButton(tr("Zastavit"))
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self.stop)
        self.btn_new = QtWidgets.QPushButton(tr("Nová konverzace"))
        self.btn_new.clicked.connect(self.new_conversation)
        self.status = QtWidgets.QLabel("")
        self.status.setObjectName("hint")
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        self.status.setWordWrap(True)
        brow.addWidget(self.btn_send)
        brow.addWidget(self.btn_stop)
        brow.addWidget(self.btn_new)
        brow.addWidget(self.status, 1)
        lay.addLayout(brow)
        self._welcome()

    def eventFilter(self, obj, ev):  # noqa: N802
        if obj is self.input and ev.type() == QtCore.QEvent.Type.KeyPress and ev.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) \
                and ev.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.send()
            return True
        return super().eventFilter(obj, ev)

    def set_font(self, font):
        self.view.document().setDefaultFont(QtGui.QFont(self.font().family(), font.pointSize()))
        self.input.setFont(font)

    def _welcome(self):
        self.view.setHtml("<p style='color:#888'>" + tr("Agent LuxAI umí číst a upravovat soubory projektu, hledat v manuálu LSL, kontrolovat chyby compilerem a spouštět programy. Přihlaste se účtem LuxAI a zadejte úkol.") + "</p>")

    def _append_html(self, html):
        c = self.view.textCursor()
        c.movePosition(QtGui.QTextCursor.MoveOperation.End)
        # insertHtml nezačíná nový blok, takže hlavička „Agent“ by se nalepila za text uživatele
        if c.position() != c.block().position():
            c.insertBlock(QtGui.QTextBlockFormat(), QtGui.QTextCharFormat())
        c.insertHtml(html)
        self.view.setTextCursor(c)
        self.view.ensureCursorVisible()

    def _md(self, text):
        if _markdown:
            try:
                return _markdown.markdown(text, extensions=["fenced_code", "tables"])
            except Exception:  # noqa: BLE001
                pass
        return "<p>" + _html.escape(text).replace("\n", "<br>") + "</p>"

    def _anchor(self, url):
        s = url.toString()
        if s.startswith("goto:"):
            _, path, line = s.split(":", 2)
            self.main.goto_location(path, int(line))
        elif s.startswith("toolout:"):
            self._show_tool_output(int(s.split(":", 1)[1]))
        elif s.startswith("http"):
            QtGui.QDesktopServices.openUrl(url)

    def _show_tool_output(self, idx):
        if idx < 0 or idx >= len(self.tool_outputs):
            return
        summary, result, args = (self.tool_outputs[idx] + ({},))[:3]
        d = QtWidgets.QDialog(self)
        d.setWindowTitle(summary[:90])
        d.resize(780, 560)
        lay = QtWidgets.QVBoxLayout(d)
        tabs = QtWidgets.QTabWidget()
        out = QtWidgets.QPlainTextEdit()
        out.setReadOnly(True)
        out.setFont(self.input.font())
        out.setLineWrapMode(QtWidgets.QPlainTextEdit.LineWrapMode.NoWrap)
        out.setPlainText(result)
        tabs.addTab(out, tr("Výsledek"))
        if args:
            arg_view = QtWidgets.QPlainTextEdit()
            arg_view.setReadOnly(True)
            arg_view.setFont(self.input.font())
            arg_view.setPlainText("\n\n".join(f"{k}:\n{v}" if isinstance(v, str) and "\n" in v else f"{k}: {v}" for k, v in args.items()))
            tabs.addTab(arg_view, tr("Argumenty"))
        lay.addWidget(tabs)
        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Close)
        btns.rejected.connect(d.reject)
        lay.addWidget(btns)
        d.exec()

    def _colors(self):
        c = getattr(self.main, "theme_colors", None) or {}
        dark = theme.get(getattr(self.main, "theme_name", "")).get("dark", True)
        return {"bg": c.get("win3" if dark else "win2", "#2c313c"), "text": c.get("text", "#d7dae0"), "dim": c.get("dim", "#8b919c"),
                "accent": c.get("accent2", "#61afef"), "ok": c.get("ok", "#98c379"), "err": c.get("err", "#e06c75"),
                "warn": c.get("warn", "#e5c07b"), "border": c.get("border", "#181a1f")}

    def _tool_subject(self, name, args):
        """Hlavní argument nástroje jako HTML: cesta je klikací odkaz do editoru."""
        def file_link(path, line=None):
            p = str(path)
            label = _html.escape(Path(p).name or p)
            href = f"goto:{p}:{int(line) if line else 1}"
            return f"<a href='{href}' style='text-decoration:none'>{label}</a>" + (f":{int(line)}" if line else "")
        if name in ("read_file", "write_file", "edit_file", "check_errors"):
            extra = ""
            if name == "read_file" and (args.get("start_line") or args.get("end_line")):
                extra = f" {args.get('start_line') or 1}–{args.get('end_line') or ''}"
            if name == "check_errors" and args.get("unsafe"):
                extra = " --unsafe"
            return file_link(args.get("path", "?")) + _html.escape(extra)
        if name == "open_in_editor":
            return file_link(args.get("path", "?"), args.get("line") or 1)
        if name == "run_program":
            a = str(args.get("args") or "")
            return file_link(args.get("path", "?")) + (f" <span>{_html.escape(self._short(a, 40))}</span>" if a else "")
        if name == "search_files":
            return f"„{_html.escape(self._short(str(args.get('query', '')), 50))}“ <span>{_html.escape(str(args.get('pattern') or '*.lsl'))}</span>"
        if name == "list_files":
            return _html.escape(f"{args.get('path') or '.'}  {args.get('pattern') or '*'}".strip())
        if name in ("lsl_manual", "lsl_modules"):
            v = str(args.get("query") or args.get("module") or "")
            return f"„{_html.escape(self._short(v, 60))}“" if v else ""
        if name == "current_file":
            return "" if args.get("with_content", True) else _html.escape("(bez obsahu)")
        return _html.escape(self._short(", ".join(f"{k}={v}" for k, v in args.items()), 60))

    def _tool_status(self, name, result):
        """(text, barva) stavu podle výsledku nástroje."""
        c = self._colors()
        res = result.strip()
        if res.startswith("error") or res.startswith("timeout") or res.startswith("program killed"):
            return tr("chyba"), c["err"]
        if res.startswith("denied") or res.startswith("cancelled"):
            return tr("odmítnuto"), c["warn"]
        if name == "check_errors":
            return (tr("bez chyb"), c["ok"]) if res.startswith("OK") else (tr("chyby"), c["err"])
        if name == "run_program":
            m = re.match(r"exit code (-?\d+)", res)
            if m:
                code = int(m.group(1))
                return (tr("kód {0}").format(code), c["ok"] if code == 0 else c["err"])
            if res.startswith("output limit"):
                return tr("výstup omezen"), c["warn"]
        return tr("hotovo"), c["ok"]

    def _tool_line_html(self, idx, name, args, result):
        """Karta volání nástroje: barevný proužek, ikona, název, hlavní argument,
        stav vpravo a první řádek výsledku; odkaz otevře plný výstup."""
        c = self._colors()
        icon, label = TOOL_META.get(name, ("🛠", name))
        res = str(result).strip()
        status, status_color = self._tool_status(name, res)
        first = res.splitlines()[0] if res else ""
        first = re.sub(r"^(edited|updated|created) \S+:?\s*", r"\1: ", first)
        if name == "run_program" and res:
            body = res.splitlines()[1:]
            first = (first + "  ·  " + body[0].strip()) if body and body[0].strip() else first
        if name == "current_file" and first.startswith("{"):
            try:
                info = json.loads(first)
                first = f"{Path(str(info.get('path', ''))).name}:{info.get('line', '?')}" + (f"  ({tr('neuloženo')})" if info.get("modified") else "")
            except ValueError:
                pass
        preview = _html.escape(self._short(first, 96))
        link = f"<a href='toolout:{idx}' style='color:{c['accent']};text-decoration:none'>{tr('detail')}</a>"
        subject = self._tool_subject(name, args)
        return (f"<table width='100%' cellspacing='0' cellpadding='0' style='margin:3px 0 3px 0;'>"
                f"<tr><td width='4' style='background-color:{status_color};'></td>"
                f"<td style='background-color:{c['bg']};padding:4px 8px 4px 8px;'>"
                f"<table width='100%' cellspacing='0' cellpadding='0'><tr>"
                f"<td>{icon}&nbsp;<b style='color:{c['text']}'>{_html.escape(tr(label))}</b>"
                f"{('&nbsp;&nbsp;<span style=' + chr(39) + 'color:' + c['dim'] + chr(39) + '>' + subject + '</span>') if subject else ''}</td>"
                f"<td align='right' style='white-space:nowrap;'><span style='color:{status_color};font-size:small'>● {_html.escape(status)}</span>"
                f"&nbsp;&nbsp;<span style='font-size:small'>{link}</span></td>"
                f"</tr></table>"
                f"<div style='color:{c['dim']};font-size:small;margin-left:22px'><code>{preview}</code></div>"
                f"</td></tr></table>")

    @staticmethod
    def _short(v, n):
        v = str(v).replace("\n", "⏎")
        return v if len(v) <= n else v[:n - 1] + "…"

    # --- účet ----------------------------------------------------------------
    def _sync_system_account(self):
        """Převezme účet přihlášený v LuxOS, pokud soubor existuje; zmizí-li soubor (odhlášení
        v systému), vrátí se k vlastnímu přihlášení IDE. Vrací True, když se token změnil."""
        acc = luxai.load_system_account()
        if acc and acc["token"] != self._rejected_system:
            if acc["token"] == self.system_token and self.client.token == acc["token"]:
                return False
            self.system_token = acc["token"]
            self._rejected_system = ""
            self.client.origin = acc["origin"]
            self.client.token = acc["token"]
            self.client.user = acc["user"]
            return True
        if not acc:
            self._rejected_system = ""
        if self.system_token:
            # systémový účet už neplatí: vlastní token IDE (pokud nějaký je)
            self.system_token = ""
            self.client.origin = self.main.settings.value("luxai/origin", luxai.DEFAULT_ORIGIN, str).rstrip("/")
            self.client.token = self.main.settings.value("luxai/token", "", str)
            self.client.user = None
            return True
        return False

    def via_system(self):
        return bool(self.system_token and self.client.token == self.system_token)

    def login(self):
        # V LuxOS se přihlašuje systémová aplikace účtu; IDE pak token převezme ze souboru.
        if luxai.load_system_account() is not None and shutil.which("luxos-account"):
            self._run_system_login()
            return
        d = LoginDialog(self.client, self)
        if d.exec():
            self.system_token = ""
            self.main.settings.setValue("luxai/token", self.client.token)
            self.main.settings.setValue("luxai/origin", self.client.origin)
            self._show_account()

    def _run_system_login(self):
        if self._relogin_proc is not None:
            return
        p = QtCore.QProcess(self)
        p.finished.connect(lambda *_a: self._system_login_done())
        p.errorOccurred.connect(lambda _e: self._system_login_done())
        self._relogin_proc = p
        self.status.setText(tr("Přihlášení probíhá v okně Účet LuxAI…"))
        p.start("luxos-account", ["login"])

    def _system_login_done(self):
        if self._relogin_proc is None:
            return
        self._relogin_proc.deleteLater()
        self._relogin_proc = None
        self._rejected_system = ""
        self._sync_system_account()
        self.status.setText("")
        if self.client.token:
            self.refresh_account()
        else:
            self._show_account()

    def logout(self):
        if self.via_system():
            # Sdílený účet spravuje LuxOS; odhlášení z IDE by zneplatnilo session všem aplikacím.
            QtWidgets.QMessageBox.information(
                self, tr("Účet LuxAI"),
                tr("IDE používá účet přihlášený v LuxOS. Odhlásit se můžete v aplikaci Účet LuxAI "
                   "(příkaz luxos-account logout)."))
            return
        try:
            self.client.logout()
        except LuxError:
            pass
        self.main.settings.remove("luxai/token")
        self._show_account()

    def _session_rejected(self):
        """Server odmítl token: u účtu LuxOS nabídnout nové přihlášení, soubor zůstává."""
        if self.via_system():
            self._rejected_system = self.system_token
            self.client.token = ""
            self.client.user = None
            own = self.main.settings.value("luxai/token", "", str)
            if own and own != self.system_token:
                # IDE má i vlastní přihlášení – použít ho, dokud se v LuxOS nepřihlásí znovu
                self.system_token = ""
                self.client.origin = self.main.settings.value("luxai/origin", luxai.DEFAULT_ORIGIN, str).rstrip("/")
                self.client.token = own
                QtCore.QTimer.singleShot(0, self.refresh_account)
            self.status.setText(tr("Přihlášení účtu LuxOS vypršelo – klikněte na „Přihlásit znovu“."))
        else:
            self.client.token = ""
        self._show_account()

    def refresh_account(self):
        self._sync_system_account()
        if not self.client.token:
            self._show_account()
            return
        try:
            self.client.me()
        except LuxError as e:
            self.status.setText(e.human())
            if luxai.session_rejected(e):
                self._session_rejected()
                return
        self._show_account()

    def _show_account(self):
        u = self.client.user
        logged = bool(self.client.token and u)
        system = logged and self.via_system()
        self.btn_login.setVisible(not logged)
        self.btn_login.setText(tr("Přihlásit znovu") if self._rejected_system else tr("Přihlásit"))
        self.btn_logout.setVisible(logged and not system)
        cloud = getattr(self.main, "cloud_panel", None)
        if cloud is not None and cloud.logged_in() != getattr(cloud, "_was_logged", None):
            cloud._was_logged = cloud.logged_in()
            cloud.account_changed()
        if not logged:
            self.account_label.setText(tr("Přihlášení LuxOS vypršelo") if self._rejected_system else tr("Nepřihlášen"))
            self.account_label.setToolTip("")
            self.usage_bar.setValue(0)
            return
        name = u.get('displayName') or u.get('email') or ""
        if system:
            name = tr("Přihlášeno přes LuxOS") + ": " + name
            self.account_label.setToolTip(tr("Účet LuxAI přihlášený v systému LuxOS ({0})").format(luxai.system_account_file()))
        else:
            self.account_label.setToolTip("")
        usage = u.get("usage") or {}
        if not usage:
            # údaje ze souboru LuxOS ještě bez spotřeby (doplní /api/me)
            self.account_label.setText(name)
            self.usage_bar.setValue(0)
            return
        model = self.model_box.currentData()
        used = usage.get("fastTokens" if model == "flash" else "liteTokens", 0)
        limit = usage.get("fastLimit" if model == "flash" else "liteLimit", 1) or 1
        if usage.get("unlimited"):
            self.account_label.setText(f"{name}  ·  {used:,} " + tr("tokenů") + " · " + tr("bez limitu"))
            self.usage_bar.setValue(0)
            self.usage_bar.setFormat(f"{model}: {used:,} · " + tr("bez limitu"))
            return
        self.account_label.setText(f"{name}  ·  {used:,}/{limit:,} " + tr("tokenů"))
        self.usage_bar.setValue(min(100, int(100 * used / limit)))
        self.usage_bar.setFormat(f"{model}: {used:,}/{limit:,}")

    # --- konverzace ----------------------------------------------------------
    def new_conversation(self):
        self.stop()
        self._save_conversation()
        self.messages = []
        self.tool_outputs = []
        self.conversation_id = ""
        self.conversation_title = ""
        self.history_box.setCurrentIndex(0)
        self._welcome()

    # --- historie konverzací ------------------------------------------------------
    def _conv_path(self, cid):
        return CONV_DIR / f"{cid}.json"

    def _save_conversation(self):
        if len(self.messages) < 2:
            return
        if not self.conversation_id:
            self.conversation_id = time.strftime("%Y%m%d-%H%M%S")
        if not self.conversation_title:
            first = next((m["content"] for m in self.messages if m["role"] == "user"), "")
            self.conversation_title = first.split("\n\n[IDE context]")[0].strip().replace("\n", " ")[:70] or self.conversation_id
        try:
            CONV_DIR.mkdir(parents=True, exist_ok=True)
            data = {"id": self.conversation_id, "title": self.conversation_title, "saved": time.strftime("%Y-%m-%d %H:%M"),
                    "model": self.model_box.currentData(), "project": self.main.settings.value("project/folder", "", str),
                    "messages": self.messages, "tool_outputs": self.tool_outputs[-200:]}
            self._conv_path(self.conversation_id).write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        except OSError as e:
            agent_log(f"save conversation failed: {e}")
        self._load_history_list(select=self.conversation_id)

    def _load_history_list(self, select=""):
        self.history_box.blockSignals(True)
        self.history_box.clear()
        self.history_box.addItem(tr("Historie konverzací…"), "")
        items = []
        if CONV_DIR.is_dir():
            for f in sorted(CONV_DIR.glob("*.json"), reverse=True)[:60]:
                try:
                    d = json.loads(f.read_text(encoding="utf-8"))
                    items.append((f.stem, f"{d.get('saved', '')}  {d.get('title', f.stem)}"))
                except (OSError, ValueError):
                    continue
        for cid, label in items:
            self.history_box.addItem(label, cid)
        if select:
            i = self.history_box.findData(select)
            self.history_box.setCurrentIndex(max(0, i))
        self.history_box.blockSignals(False)

    def _history_selected(self, index):
        cid = self.history_box.itemData(index)
        if not cid or cid == self.conversation_id:
            return
        if self.worker:
            self.stop()
        self._save_conversation()
        self.load_conversation(cid)

    def load_conversation(self, cid):
        try:
            d = json.loads(self._conv_path(cid).read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            self.status.setText(tr("Konverzaci nelze načíst: {0}").format(e))
            return
        self.messages = d.get("messages") or []
        self.tool_outputs = [tuple(x) for x in d.get("tool_outputs") or []]
        self.conversation_id = d.get("id") or cid
        self.conversation_title = d.get("title") or ""
        i = self.model_box.findData(d.get("model"))
        if i >= 0:
            self.model_box.setCurrentIndex(i)
        self._render_transcript()
        self.status.setText(tr("Obnovena konverzace z {0}").format(d.get("saved", "")))
        self._load_history_list(select=self.conversation_id)

    def _render_transcript(self):
        self.view.clear()
        tool_idx = 0
        calls_by_id = {}
        for m in self.messages:
            role = m.get("role")
            if role == "system":
                continue
            if role == "user":
                text = str(m.get("content") or "").split("\n\n[IDE context]")[0]
                self._append_html(f"<div style='margin:6px 0'><b style='color:#61afef'>{tr('Vy')}</b><br>{_html.escape(text).replace(chr(10), '<br>')}</div>")
            elif role == "assistant":
                for c in m.get("tool_calls") or []:
                    calls_by_id[c.get("id", "")] = c
                if m.get("content"):
                    self._append_html(f"<div style='margin:6px 0'><b style='color:#c678dd'>{tr('Agent')}</b><br></div>")
                    self._append_html(self._md(m["content"]))
            elif role == "tool":
                call = calls_by_id.get(m.get("tool_call_id", ""), {})
                fn = call.get("function") or {}
                try:
                    args = json.loads(fn.get("arguments") or "{}")
                except ValueError:
                    args = {}
                if tool_idx >= len(self.tool_outputs):
                    self.tool_outputs.append((fn.get("name", "?"), str(m.get("content") or ""), args if isinstance(args, dict) else {}))
                self._append_html(self._tool_line_html(tool_idx, fn.get("name", "?"), args if isinstance(args, dict) else {}, m.get("content") or ""))
                tool_idx += 1

    def _delete_conversation(self):
        cid = self.history_box.currentData()
        if not cid:
            return
        try:
            self._conv_path(cid).unlink()
        except OSError:
            pass
        if cid == self.conversation_id:
            self.messages = []
            self.tool_outputs = []
            self.conversation_id = ""
            self.conversation_title = ""
            self._welcome()
        self._load_history_list()

    def _context_message(self):
        folder = self.main.settings.value("project/folder", "", str)
        t = self.main.current_tab()
        parts = [f"Project root: {folder or '(none)'}"]
        if t and t.path:
            parts.append(f"Open file: {t.path}" + (" (unsaved changes)" if t.editor.document().isModified() else ""))
            c = t.editor.textCursor()
            if c.hasSelection():
                parts.append("Selection:\n" + c.selectedText().replace(" ", "\n")[:3000])
        tc = self.main.toolchain
        parts.append(f"LSL toolchain: {tc.label if tc else 'not installed'}")
        return "\n".join(parts)

    def send(self):
        text = self.input.toPlainText().strip()
        if not text or self.worker:
            return
        self._sync_system_account()
        if not self.client.token:
            self.login()
            if not self.client.token:
                return
        self.input.clear()
        if not self.messages:
            self.messages.append({"role": "system", "content": SYSTEM_PROMPT})
            self.view.clear()
        user_content = text + "\n\n[IDE context]\n" + self._context_message()
        self.messages.append({"role": "user", "content": user_content})
        self._append_html(f"<div style='margin:6px 0'><b style='color:#61afef'>{tr('Vy')}</b><br>{_html.escape(text).replace(chr(10), '<br>')}</div>")
        self.iterations = 0
        self._request()

    def _request(self):
        self.iterations += 1
        if self.iterations > MAX_ITERATIONS:
            self._finish(tr("Dosažen maximální počet kroků agenta."))
            return
        self._trim_history()
        body = {"model": self.model_box.currentData(), "messages": self.messages, "tools": tool_definitions(),
                "tool_choice": "auto", "max_tokens": 4096}
        self.worker = AgentWorker(self.client, body, self)
        self.worker.delta.connect(self._on_delta)
        self.worker.finished_ok.connect(self._on_message)
        self.worker.failed.connect(self._on_failed)
        self.btn_send.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.status.setText(tr("Agent přemýšlí…") + f" ({self.iterations})")
        self._stream_text = ""
        self._append_html(f"<div style='margin:6px 0'><b style='color:#c678dd'>{tr('Agent')}</b><br></div>")
        self._assistant_start = self.view.textCursor().position()
        self.worker.start()

    def _trim_history(self):
        total = sum(len(json.dumps(m, ensure_ascii=False)) for m in self.messages)
        while total > HISTORY_CHAR_BUDGET and len(self.messages) > 3:
            # odstranit nejstarší výměnu po systémové zprávě
            dropped = self.messages.pop(1)
            total -= len(json.dumps(dropped, ensure_ascii=False))
            while len(self.messages) > 2 and self.messages[1]["role"] in ("tool", "assistant"):
                total -= len(json.dumps(self.messages.pop(1), ensure_ascii=False))

    def _on_delta(self, text):
        if not text:
            return
        self._stream_text += text
        c = self.view.textCursor()
        c.movePosition(QtGui.QTextCursor.MoveOperation.End)
        c.insertText(text)
        self.view.setTextCursor(c)
        self.view.ensureCursorVisible()

    def _replace_streamed(self, html):
        c = self.view.textCursor()
        c.setPosition(self._assistant_start)
        c.movePosition(QtGui.QTextCursor.MoveOperation.End, QtGui.QTextCursor.MoveMode.KeepAnchor)
        c.removeSelectedText()
        c.insertHtml(html)
        self.view.setTextCursor(c)

    def _on_message(self, msg, finish, usage):
        self.worker = None
        content = msg.get("content") or ""
        if content:
            self._replace_streamed(self._md(content))
        else:
            self._replace_streamed("")
        self.messages.append(msg)
        calls = msg.get("tool_calls") or []
        if calls:
            self.pending_calls = list(calls)
            self._run_tools()
        else:
            self._finish(tr("Hotovo."))
        if usage:
            self._bump_usage(usage)

    def _bump_usage(self, usage):
        u = self.client.user
        if not u:
            return
        total = int(usage.get("total_tokens") or 0)
        key = "fastTokens" if self.model_box.currentData() == "flash" else "liteTokens"
        u.setdefault("usage", {})[key] = int(u["usage"].get(key, 0)) + total
        self._show_account()

    def _run_tools(self):
        while self.pending_calls:
            call = self.pending_calls.pop(0)
            fn = call.get("function") or {}
            name = fn.get("name", "")
            try:
                args = json.loads(fn.get("arguments") or "{}")
                if not isinstance(args, dict):
                    args = {}
            except ValueError:
                args = {}
                result = "error: tool arguments are not valid JSON"
            else:
                result = None
            summary = self._call_summary(name, args)
            if result is None and name in WRITE_TOOLS and not self.auto_approve.isChecked():
                q = QtWidgets.QMessageBox.question(
                    self, tr("Agent chce provést akci"), summary + "\n\n" + tr("Povolit?"),
                    QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No | QtWidgets.QMessageBox.StandardButton.Cancel)
                if q == QtWidgets.QMessageBox.StandardButton.Cancel:
                    self.pending_calls = []
                    self.messages.append({"role": "tool", "tool_call_id": call.get("id", ""), "content": "cancelled by user"})
                    self._finish(tr("Zastaveno uživatelem."))
                    return
                if q == QtWidgets.QMessageBox.StandardButton.No:
                    result = "denied by user"
            if result is None:
                self.status.setText(tr("Nástroj: {0}").format(name))
                QtWidgets.QApplication.processEvents()
                result = self.tools.call(name, args)
            self.tool_outputs.append((summary, str(result), args))
            self._append_html(self._tool_line_html(len(self.tool_outputs) - 1, name, args, result))
            self.messages.append({"role": "tool", "tool_call_id": call.get("id", ""), "content": _clip(str(result))})
        self._request()

    @staticmethod
    def _call_summary(name, args):
        short = {}
        for k, v in args.items():
            v = str(v)
            short[k] = v if len(v) <= 80 else v[:77] + "…"
        return f"{name}({', '.join(f'{k}={v!r}' for k, v in short.items())})"

    def _on_failed(self, message, err=None):
        self.worker = None
        self._replace_streamed(f"<p style='color:#e06c75'>{_html.escape(message)}</p>")
        self._finish(message)
        if luxai.session_rejected(err):
            self._session_rejected()

    def _finish(self, status):
        self.btn_send.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self.status.setText(status)
        self._save_conversation()
        QtCore.QTimer.singleShot(1500, self.refresh_account) if self.client.token else None

    def stop(self):
        if self.worker:
            self.worker.stop()
        self.pending_calls = []
