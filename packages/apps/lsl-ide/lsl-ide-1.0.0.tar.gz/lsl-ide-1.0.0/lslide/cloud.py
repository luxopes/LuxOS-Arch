"""Cloudové úložiště kódu účtu LuxAI (dock „Cloud LuxAI“).

Soubory účtu leží na serveru (server/patch_lux_account.py, část 4; kvóta 128 MB
na účet). IDE je zrcadlí do lokální složky ~/.local/share/lsl-ide/cloud/<účet>/:
otevření souboru z cloudu ho stáhne do zrcadla a otevře v editoru, uložení
souboru ležícího v zrcadle ho (při zapnutém „Uložení nahrát do cloudu“)
automaticky nahraje zpět. Síťové operace běží ve vlákně, aby editor nezamrzl.
"""
import hashlib
import os
import time
from datetime import datetime, timezone
from pathlib import Path

from .qt import QtCore, QtGui, QtWidgets, Qt, Signal
from .i18n import tr
from .luxai import LuxError

CLOUD_ROOT = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "lsl-ide" / "cloud"
CLOUD_QUOTA_FALLBACK = 128 * 1024 * 1024


def human_size(n):
    n = float(n or 0)
    for unit in ("B", "kB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} GB"


def local_time(iso):
    try:
        dt = datetime.fromisoformat(str(iso).replace("Z", "+00:00")).astimezone()
        return dt.strftime("%d.%m.%Y %H:%M")
    except ValueError:
        return str(iso or "")


class CloudWorker(QtCore.QThread):
    """Spustí fn() mimo hlavní vlákno; done(výsledek) nebo failed(text chyby)."""
    done = Signal(object)
    failed = Signal(str, str)  # text chyby, kód chyby (LuxError.code nebo název výjimky)

    def __init__(self, fn, parent=None):
        super().__init__(parent)
        self.fn = fn

    def run(self):
        try:
            self.done.emit(self.fn())
        except LuxError as e:
            self.failed.emit(e.human(), e.code)
        except Exception as e:  # noqa: BLE001
            self.failed.emit(f"{type(e).__name__}: {e}", type(e).__name__)


class _Item(QtWidgets.QTreeWidgetItem):
    """Řazení: složky před soubory, pak podle názvu bez ohledu na velikost písmen."""

    def __lt__(self, other):
        key = lambda i: (i.data(0, Qt.ItemDataRole.UserRole + 1) != "dir", i.text(0).lower())  # noqa: E731
        return key(self) < key(other)


class CloudPanel(QtWidgets.QWidget):
    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.client = main.agent_panel.client
        self.files = []
        self.quota = CLOUD_QUOTA_FALLBACK
        self.used = 0
        self._workers = []
        self._busy = 0
        self._status_after = ""  # hláška, kterou má ukázat příští obnovení seznamu
        self._build()
        self.account_changed()

    # --- UI ------------------------------------------------------------------
    def _build(self):
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(6, 4, 6, 6)
        lay.setSpacing(4)
        self.account_label = QtWidgets.QLabel("")
        self.account_label.setObjectName("hint")
        self.account_label.setWordWrap(True)
        lay.addWidget(self.account_label)
        self.quota_bar = QtWidgets.QProgressBar()
        self.quota_bar.setRange(0, 100)
        self.quota_bar.setFixedHeight(14)
        lay.addWidget(self.quota_bar)

        row = QtWidgets.QHBoxLayout()
        self.btn_refresh = QtWidgets.QToolButton()
        self.btn_refresh.setText("⟳ " + tr("Obnovit"))
        self.btn_refresh.clicked.connect(lambda: self.refresh())
        self.btn_upload_current = QtWidgets.QToolButton()
        self.btn_upload_current.setText("⇧ " + tr("Nahrát otevřený soubor"))
        self.btn_upload_current.setToolTip(tr("Nahraje obsah aktuální záložky do cloudu (i neuložený)."))
        self.btn_upload_current.clicked.connect(self.upload_current)
        self.btn_upload_files = QtWidgets.QToolButton()
        self.btn_upload_files.setText(tr("Nahrát soubory…"))
        self.btn_upload_files.clicked.connect(self.upload_files)
        self.btn_download_all = QtWidgets.QToolButton()
        self.btn_download_all.setText("⇩ " + tr("Stáhnout vše"))
        self.btn_download_all.setToolTip(tr("Stáhne všechny soubory do lokální složky cloudu a otevře ji jako projekt."))
        self.btn_download_all.clicked.connect(self.download_all)
        for b in (self.btn_refresh, self.btn_upload_current, self.btn_upload_files, self.btn_download_all):
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)

        self.tree = QtWidgets.QTreeWidget()
        self.tree.setColumnCount(3)
        self.tree.setHeaderLabels([tr("Soubor"), tr("Velikost"), tr("Změněno")])
        self.tree.header().setStretchLastSection(False)
        self.tree.header().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeMode.Stretch)
        self.tree.header().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        self.tree.header().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        self.tree.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tree.itemDoubleClicked.connect(lambda item, _c: self._open_item(item))
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._context_menu)
        self.tree.itemSelectionChanged.connect(self._update_buttons)
        lay.addWidget(self.tree, 1)

        row2 = QtWidgets.QHBoxLayout()
        self.btn_open = QtWidgets.QToolButton()
        self.btn_open.setText(tr("Otevřít"))
        self.btn_open.clicked.connect(self.open_selected)
        self.btn_download = QtWidgets.QToolButton()
        self.btn_download.setText(tr("Stáhnout"))
        self.btn_download.setToolTip(tr("Stáhne vybrané soubory nebo složky do lokální složky cloudu."))
        self.btn_download.clicked.connect(self.download_selected)
        self.btn_rename = QtWidgets.QToolButton()
        self.btn_rename.setText(tr("Přejmenovat…"))
        self.btn_rename.clicked.connect(self.rename_selected)
        self.btn_delete = QtWidgets.QToolButton()
        self.btn_delete.setText(tr("Smazat…"))
        self.btn_delete.clicked.connect(self.delete_selected)
        for b in (self.btn_open, self.btn_download, self.btn_rename, self.btn_delete):
            row2.addWidget(b)
        row2.addStretch(1)
        lay.addLayout(row2)

        self.autosync = QtWidgets.QCheckBox(tr("Uložení souboru ve složce cloudu nahrát do cloudu"))
        self.autosync.setChecked(self.main.settings.value("cloud/autosync", True, bool))
        self.autosync.toggled.connect(lambda v: self.main.settings.setValue("cloud/autosync", bool(v)))
        lay.addWidget(self.autosync)
        self.status = QtWidgets.QLabel("")
        self.status.setObjectName("hint")
        self.status.setWordWrap(True)
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        lay.addWidget(self.status)

    def set_font(self, font):
        self.tree.setFont(QtGui.QFont(self.font().family(), font.pointSize()))

    # --- stav účtu -----------------------------------------------------------
    def logged_in(self):
        return bool(self.client.token and self.client.user)

    def mirror_dir(self):
        """Lokální zrcadlo cloudu pro přihlášený účet (podle id účtu, ne e-mailu)."""
        u = self.client.user or {}
        key = hashlib.sha256(str(u.get("id") or u.get("email") or "anon").encode("utf-8")).hexdigest()[:16]
        return CLOUD_ROOT / key

    def account_changed(self):
        """Volá agent po přihlášení/odhlášení."""
        logged = self.logged_in()
        for b in (self.btn_refresh, self.btn_upload_current, self.btn_upload_files, self.btn_download_all):
            b.setEnabled(logged)
        if not logged:
            self.files = []
            self.tree.clear()
            self.quota_bar.setValue(0)
            self.quota_bar.setFormat(tr("nepřihlášen"))
            self.account_label.setText(tr("Cloudové úložiště kódu (128 MB) je dostupné po přihlášení účtem LuxAI v panelu Agent."))
            self.status.setText("")
            self._update_buttons()
            return
        u = self.client.user
        self.account_label.setText(tr("Účet {0} · lokální složka: {1}").format(u.get("displayName") or u.get("email"), self.mirror_dir()))
        self.refresh()

    def _set_busy(self, text=""):
        self._busy += 1
        if text:
            self.status.setText(text)
        QtWidgets.QApplication.setOverrideCursor(Qt.CursorShape.BusyCursor)

    def _clear_busy(self, text=""):
        self._busy = max(0, self._busy - 1)
        if self._busy == 0:
            QtWidgets.QApplication.restoreOverrideCursor()
        if text:
            self.status.setText(text)

    def _spawn(self, fn, done, busy_text=""):
        w = CloudWorker(fn, self)
        self._workers.append(w)
        self._set_busy(busy_text)

        def _finish():
            if w in self._workers:
                self._workers.remove(w)

        def _done(result):
            _finish()
            self._clear_busy()
            done(result)

        def _failed(message, code):
            _finish()
            self._clear_busy(tr("Chyba: {0}").format(message))
            if code == "auth":
                self.main.agent_panel.refresh_account()
        w.done.connect(_done)
        w.failed.connect(_failed)
        w.start()
        return w

    # --- výpis ---------------------------------------------------------------
    def refresh(self, status_after=""):
        """Znovu načte seznam; status_after je hláška zobrazená po načtení (např. „Nahráno…“)."""
        self._status_after = status_after
        if not self.logged_in():
            self.account_changed()
            return
        self._spawn(self.client.cloud_list, self._fill, "" if status_after else tr("Načítám seznam souborů…"))

    def _fill(self, summary):
        self.files = list(summary.get("files") or [])
        self.quota = int(summary.get("quota") or CLOUD_QUOTA_FALLBACK)
        self.used = int(summary.get("used") or 0)
        self.quota_bar.setValue(min(100, int(100 * self.used / max(1, self.quota))))
        self.quota_bar.setFormat(f"{human_size(self.used)} / {human_size(self.quota)}  ·  {len(self.files)} " + tr("souborů"))
        collapsed = set()
        it = QtWidgets.QTreeWidgetItemIterator(self.tree)
        while it.value():
            if self._is_dir(it.value()) and not it.value().isExpanded():
                collapsed.add(self._item_path(it.value()))
            it += 1
        self.tree.clear()
        folders = {}

        def folder_item(prefix):
            if prefix in folders:
                return folders[prefix]
            parent_prefix, _, name = prefix.rpartition("/")
            parent = folder_item(parent_prefix) if parent_prefix else None
            item = _Item([name, "", ""])
            item.setData(0, Qt.ItemDataRole.UserRole, prefix)
            item.setData(0, Qt.ItemDataRole.UserRole + 1, "dir")
            item.setIcon(0, self.style().standardIcon(QtWidgets.QStyle.StandardPixmap.SP_DirIcon))
            (parent.addChild if parent else self.tree.addTopLevelItem)(item)
            item.setExpanded(prefix not in collapsed)
            folders[prefix] = item
            return item

        for f in self.files:
            prefix, _, name = f["path"].rpartition("/")
            parent = folder_item(prefix) if prefix else None
            item = _Item([name, human_size(f.get("size")), local_time(f.get("mtime"))])
            item.setData(0, Qt.ItemDataRole.UserRole, f["path"])
            item.setData(0, Qt.ItemDataRole.UserRole + 1, "file")
            item.setTextAlignment(1, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            item.setIcon(0, self.style().standardIcon(QtWidgets.QStyle.StandardPixmap.SP_FileIcon))
            local = self.mirror_dir() / f["path"]
            if local.is_file():
                item.setToolTip(0, tr("Staženo: {0}").format(local))
            (parent.addChild if parent else self.tree.addTopLevelItem)(item)
        self.tree.sortItems(0, Qt.SortOrder.AscendingOrder)
        self._update_buttons()
        self.status.setText(self._status_after or tr("Aktualizováno {0}").format(time.strftime("%H:%M:%S")))
        self._status_after = ""

    @staticmethod
    def _item_path(item):
        return item.data(0, Qt.ItemDataRole.UserRole) if item else ""

    @staticmethod
    def _is_dir(item):
        return item is not None and item.data(0, Qt.ItemDataRole.UserRole + 1) == "dir"

    def _selected(self):
        return self.tree.selectedItems()

    def _selected_files(self):
        """Cesty souborů z výběru; složky se rozbalí na jejich soubory."""
        out = []
        for item in self._selected():
            p = self._item_path(item)
            if self._is_dir(item):
                out.extend(f["path"] for f in self.files if f["path"].startswith(p + "/"))
            else:
                out.append(p)
        seen = set()
        return [p for p in out if not (p in seen or seen.add(p))]

    def _update_buttons(self):
        logged = self.logged_in()
        sel = self._selected()
        has_file = any(not self._is_dir(i) for i in sel)
        self.btn_open.setEnabled(logged and has_file)
        self.btn_download.setEnabled(logged and bool(sel))
        self.btn_rename.setEnabled(logged and len(sel) == 1)
        self.btn_delete.setEnabled(logged and bool(sel))

    def _context_menu(self, pos):
        item = self.tree.itemAt(pos)
        menu = QtWidgets.QMenu(self)
        if item and not self._is_dir(item):
            menu.addAction(tr("Otevřít"), self.open_selected)
        if item:
            menu.addAction(tr("Stáhnout"), self.download_selected)
            menu.addAction(tr("Přejmenovat…"), self.rename_selected)
            menu.addAction(tr("Smazat…"), self.delete_selected)
            menu.addSeparator()
        menu.addAction(tr("Nahrát otevřený soubor"), self.upload_current)
        menu.addAction(tr("Nahrát soubory…"), self.upload_files)
        menu.addAction(tr("Obnovit"), lambda: self.refresh())
        menu.exec(self.tree.viewport().mapToGlobal(pos))

    # --- stažení / otevření ----------------------------------------------------
    def _write_local(self, rel, content):
        local = self.mirror_dir() / rel
        local.parent.mkdir(parents=True, exist_ok=True)
        local.write_text(content, encoding="utf-8")
        return local

    def _fetch_many(self, paths):
        """Stáhne soubory do zrcadla (ve vlákně). Vrací (počet, přeskočené shodné)."""
        n, same = 0, 0
        for rel in paths:
            r = self.client.cloud_get(rel)
            local = self.mirror_dir() / rel
            if local.is_file() and local.read_text(encoding="utf-8", errors="replace") == r.get("content", ""):
                same += 1
                continue
            self._write_local(rel, r.get("content", ""))
            n += 1
        return n, same

    def _open_item(self, item):
        if item is None or self._is_dir(item):
            return
        rel = self._item_path(item)
        self._spawn(lambda: self.client.cloud_get(rel), lambda r: self._open_fetched(rel, r), tr("Stahuji {0}…").format(rel))

    def _open_fetched(self, rel, r):
        content = r.get("content", "")
        local = self.mirror_dir() / rel
        if local.is_file():
            current = local.read_text(encoding="utf-8", errors="replace")
            tab = self._tab_for(local)
            if tab is not None and tab.editor.document().isModified():
                current = tab.editor.toPlainText()
            if current != content:
                box = QtWidgets.QMessageBox(self)
                box.setIcon(QtWidgets.QMessageBox.Icon.Question)
                box.setWindowTitle(tr("Soubor se liší"))
                box.setText(tr("Lokální kopie {0} se liší od verze v cloudu.").format(local.name))
                use_cloud = box.addButton(tr("Použít verzi z cloudu"), QtWidgets.QMessageBox.ButtonRole.AcceptRole)
                box.addButton(tr("Ponechat lokální"), QtWidgets.QMessageBox.ButtonRole.RejectRole)
                box.exec()
                if box.clickedButton() is not use_cloud:
                    self.main.open_file(str(local))
                    return
                if tab is not None:
                    tab.editor.setPlainText(content)
                    tab.editor.document().setModified(False)
                    self.main.update_tab_title(tab)
        self._write_local(rel, content)
        self.main.open_file(str(local))
        self.status.setText(tr("Otevřeno z cloudu: {0}").format(rel))

    def _tab_for(self, local):
        for i in range(self.main.tabs.count()):
            t = self.main.tabs.widget(i)
            if t.path and Path(t.path).resolve() == local.resolve():
                return t
        return None

    def open_selected(self):
        for item in self._selected():
            if not self._is_dir(item):
                self._open_item(item)

    def download_selected(self):
        paths = self._selected_files()
        if paths:
            self._spawn(lambda: self._fetch_many(paths), self._downloaded, tr("Stahuji {0} souborů…").format(len(paths)))

    def download_all(self):
        paths = [f["path"] for f in self.files]
        if not paths:
            self.status.setText(tr("V cloudu nejsou žádné soubory."))
            return
        self._spawn(lambda: self._fetch_many(paths), lambda r: self._downloaded(r, open_project=True), tr("Stahuji {0} souborů…").format(len(paths)))

    def _downloaded(self, result, open_project=False):
        n, same = result
        self.status.setText(tr("Staženo {0} souborů ({1} beze změny) do {2}").format(n, same, self.mirror_dir()))
        if open_project:
            self.main.open_folder(str(self.mirror_dir()))
        self._fill_local_marks()

    def _fill_local_marks(self):
        it = QtWidgets.QTreeWidgetItemIterator(self.tree)
        while it.value():
            item = it.value()
            if not self._is_dir(item) and (self.mirror_dir() / self._item_path(item)).is_file():
                item.setToolTip(0, tr("Staženo: {0}").format(self.mirror_dir() / self._item_path(item)))
            it += 1

    # --- nahrání ---------------------------------------------------------------
    def suggest_cloud_path(self, path):
        """Cesta v cloudu pro lokální soubor: relativně ke složce cloudu nebo projektu, jinak jen název."""
        if not path:
            return "program.lsl"
        p = Path(path).resolve()
        for base in (self.mirror_dir(), Path(self.main.settings.value("project/folder", "", str) or "/nonexistent")):
            try:
                return p.relative_to(base.resolve()).as_posix()
            except ValueError:
                continue
        return p.name

    def upload_current(self):
        t = self.main.current_tab()
        if not t:
            self.status.setText(tr("Není otevřený žádný soubor."))
            return
        rel, ok = QtWidgets.QInputDialog.getText(self, tr("Nahrát do cloudu"), tr("Cesta v cloudu (složky oddělte lomítkem):"),
                                                 text=self.suggest_cloud_path(t.path))
        rel = rel.strip().strip("/") if ok else ""
        if not rel:
            return
        content = t.editor.toPlainText()
        self._spawn(lambda: self.client.cloud_put(rel, content), lambda r: self._uploaded([rel], r), tr("Nahrávám {0}…").format(rel))

    def upload_files(self):
        start = self.main.settings.value("project/folder", str(Path.home()), str)
        paths, _ = QtWidgets.QFileDialog.getOpenFileNames(self, tr("Nahrát soubory do cloudu"), start, tr("LSL (*.lsl);;Vše (*)"))
        if not paths:
            return
        pairs = [(self.suggest_cloud_path(p), p) for p in paths]

        def work():
            last = None
            for rel, p in pairs:
                last = self.client.cloud_put(rel, Path(p).read_text(encoding="utf-8", errors="replace"))
            return last
        self._spawn(work, lambda r: self._uploaded([rel for rel, _ in pairs], r), tr("Nahrávám {0} souborů…").format(len(pairs)))

    def _uploaded(self, rels, r):
        used = r.get("used") if isinstance(r, dict) else None
        note = f"  ·  {human_size(used)} / {human_size(self.quota)}" if used is not None else ""
        self.refresh(tr("Nahráno: {0}").format(", ".join(rels[:3]) + ("…" if len(rels) > 3 else "")) + note)

    def on_local_saved(self, path):
        """Hák po uložení souboru v editoru (i zápisu agentem): soubor v zrcadle jde do cloudu."""
        if not path or not self.autosync.isChecked() or not self.logged_in():
            return
        try:
            rel = Path(path).resolve().relative_to(self.mirror_dir().resolve()).as_posix()
        except (ValueError, OSError):
            return
        try:
            content = Path(path).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return
        self._spawn(lambda: self.client.cloud_put(rel, content), lambda r: self._autosynced(rel, r), tr("Nahrávám {0}…").format(rel))

    def _autosynced(self, rel, r):
        self.main.statusBar().showMessage(tr("Uloženo do cloudu: {0}").format(rel), 3000)
        self.refresh(tr("Uloženo do cloudu: {0}").format(rel))

    # --- přejmenování / mazání -------------------------------------------------
    def rename_selected(self):
        sel = self._selected()
        if len(sel) != 1:
            return
        src = self._item_path(sel[0])
        dst, ok = QtWidgets.QInputDialog.getText(self, tr("Přejmenovat v cloudu"), tr("Nová cesta:"), text=src)
        dst = dst.strip().strip("/") if ok else ""
        if not dst or dst == src:
            return

        def done(_r):
            local = self.mirror_dir() / src
            if local.exists():
                target = self.mirror_dir() / dst
                target.parent.mkdir(parents=True, exist_ok=True)
                local.replace(target)
            self.refresh(tr("Přejmenováno: {0} → {1}").format(src, dst))
        self._spawn(lambda: self.client.cloud_move(src, dst), done, tr("Přejmenovávám…"))

    def delete_selected(self):
        sel = self._selected()
        if not sel:
            return
        paths = [self._item_path(i) for i in sel]
        q = QtWidgets.QMessageBox.question(
            self, tr("Smazat z cloudu"),
            tr("Smazat z cloudu {0} položek?\n{1}\n\nLokální kopie zůstanou zachovány.").format(len(paths), "\n".join(paths[:8]) + ("\n…" if len(paths) > 8 else "")),
            QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No)
        if q != QtWidgets.QMessageBox.StandardButton.Yes:
            return

        def work():
            last = None
            for p in paths:
                last = self.client.cloud_delete(p)
            return last

        def done(_r):
            self.refresh(tr("Smazáno: {0}").format(", ".join(paths[:3]) + ("…" if len(paths) > 3 else "")))
        self._spawn(work, done, tr("Mažu…"))
