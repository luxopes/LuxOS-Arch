"""Editor kódu LSL: čísla řádků, zvýraznění, automatické odsazení a `end`,
párování závorek, doplňování, podtržení chyb, tooltips."""
import re

from .qt import QtCore, QtGui, QtWidgets, Qt, Signal
from .i18n import tr
from . import syntax
from .syntax import (LslHighlighter, Palette, KEYWORDS, BUILTINS, CONSTANTS, METHODS,
                     BLOCK_OPENERS, BLOCK_MIDDLE, RE_WORD_AT, loaded_modules, local_symbols)

INDENT = "    "
BRACKETS = {"(": ")", "[": "]", "{": "}"}
CLOSERS = {v: k for k, v in BRACKETS.items()}


class LineNumberArea(QtWidgets.QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):  # noqa: N802
        return QtCore.QSize(self.editor.gutter_width(), 0)

    def paintEvent(self, event):  # noqa: N802
        self.editor.paint_gutter(event)

    def mousePressEvent(self, event):  # noqa: N802
        self.editor.gutter_clicked(event)


class CodeEditor(QtWidgets.QPlainTextEdit):
    diagnostics_changed = Signal()
    request_help = Signal(str)
    definition_requested = Signal()

    def __init__(self, parent=None, palette=None, stdlib_index=None):
        super().__init__(parent)
        self.palette_data = palette or Palette.DARK  # výchozí, hlavní okno předává motiv
        self.stdlib_index = stdlib_index
        self.file_path = ""
        self.diagnostics = []
        self.setLineWrapMode(QtWidgets.QPlainTextEdit.LineWrapMode.NoWrap)
        self.setMouseTracking(True)
        self.setTabStopDistance(4 * self.fontMetrics().horizontalAdvance(" "))
        self.gutter = LineNumberArea(self)
        self.highlighter = LslHighlighter(self.document(), self.palette_data)
        self.blockCountChanged.connect(self._update_gutter_width)
        self.updateRequest.connect(self._update_gutter)
        self.cursorPositionChanged.connect(self._refresh_extra_selections)
        self._update_gutter_width(0)
        self._setup_completer()
        self.apply_palette(self.palette_data)

    # --- vzhled ---------------------------------------------------------------
    def apply_palette(self, p):
        self.palette_data = p
        self.highlighter.set_palette(p)
        self.setStyleSheet(
            f"QPlainTextEdit {{ background: {p['bg']}; color: {p['fg']}; "
            f"selection-background-color: {p['selection']}; border: none; }}"
        )
        self.gutter.update()
        self._refresh_extra_selections()

    def set_font(self, font: QtGui.QFont):
        self.setFont(font)
        self.setTabStopDistance(4 * self.fontMetrics().horizontalAdvance(" "))
        self._update_gutter_width(0)

    # --- gutter ---------------------------------------------------------------
    def gutter_width(self):
        digits = max(3, len(str(max(1, self.blockCount()))))
        return 14 + self.fontMetrics().horizontalAdvance("9") * digits + 12

    def _update_gutter_width(self, _):
        self.setViewportMargins(self.gutter_width(), 0, 0, 0)

    def _update_gutter(self, rect, dy):
        if dy:
            self.gutter.scroll(0, dy)
        else:
            self.gutter.update(0, rect.y(), self.gutter.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self._update_gutter_width(0)

    def resizeEvent(self, event):  # noqa: N802
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.gutter.setGeometry(QtCore.QRect(cr.left(), cr.top(), self.gutter_width(), cr.height()))

    def paint_gutter(self, event):
        p = self.palette_data
        painter = QtGui.QPainter(self.gutter)
        painter.fillRect(event.rect(), QtGui.QColor(p["gutter_bg"]))
        block = self.firstVisibleBlock()
        top = round(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bottom = top + round(self.blockBoundingRect(block).height())
        cur = self.textCursor().blockNumber()
        err_lines = {d.line: d.severity for d in self.diagnostics if d.line}
        fm = self.fontMetrics()
        w = self.gutter.width()
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                no = block.blockNumber() + 1
                sev = err_lines.get(no)
                if sev:
                    color = QtGui.QColor(p["error"] if sev == "error" else p["warning"])
                    painter.setBrush(color)
                    painter.setPen(Qt.PenStyle.NoPen)
                    r = fm.height() * 0.3
                    painter.drawEllipse(QtCore.QPointF(7 + r, top + fm.height() / 2), r, r)
                painter.setPen(QtGui.QColor(p["fg"] if no == cur + 1 else p["gutter_fg"]))
                painter.drawText(0, top, w - 8, fm.height(), Qt.AlignmentFlag.AlignRight, str(no))
            block = block.next()
            top = bottom
            bottom = top + round(self.blockBoundingRect(block).height())
        painter.end()

    def gutter_clicked(self, event):
        cursor = self.cursorForPosition(QtCore.QPoint(0, int(event.position().y())))
        line = cursor.blockNumber() + 1
        for d in self.diagnostics:
            if d.line == line:
                QtWidgets.QToolTip.showText(event.globalPosition().toPoint(), d.tooltip(), self)
                return

    # --- diagnostiky ------------------------------------------------------------
    def set_diagnostics(self, diags):
        self.diagnostics = list(diags)
        self._refresh_extra_selections()
        self.gutter.update()
        self.diagnostics_changed.emit()

    def _refresh_extra_selections(self):
        p = self.palette_data
        sels = []
        cur = QtWidgets.QTextEdit.ExtraSelection()
        cur.format.setBackground(QtGui.QColor(p["current_line"]))
        cur.format.setProperty(QtGui.QTextFormat.Property.FullWidthSelection, True)
        cur.cursor = self.textCursor()
        cur.cursor.clearSelection()
        sels.append(cur)
        sels.extend(self._bracket_selections())
        doc = self.document()
        for d in self.diagnostics:
            if not d.line:
                continue
            block = doc.findBlockByNumber(d.line - 1)
            if not block.isValid():
                continue
            sel = QtWidgets.QTextEdit.ExtraSelection()
            color = QtGui.QColor(p["error"] if d.severity == "error" else p["warning"])
            sel.format.setUnderlineStyle(QtGui.QTextCharFormat.UnderlineStyle.WaveUnderline)
            sel.format.setUnderlineColor(color)
            c = QtGui.QTextCursor(block)
            btext = block.text()
            start = max(0, min(d.column - 1, len(btext)))
            length = d.length
            if btext and start >= len(btext.rstrip()):
                # chyba za koncem řádku (např. `x = `) – podtrhneme konec kódu
                start = max(0, len(btext.rstrip()) - 1)
                length = max(1, len(btext) - start)
            c.setPosition(block.position() + start)
            if start + length > len(block.text()):
                length = max(1, len(block.text()) - start)
            if len(block.text()) == 0:
                # prázdný řádek (např. chybějící `end` na konci) – podtrhneme celý řádek
                sel.format.setBackground(QtGui.QColor(color.red(), color.green(), color.blue(), 60))
                sel.format.setProperty(QtGui.QTextFormat.Property.FullWidthSelection, True)
            else:
                c.movePosition(QtGui.QTextCursor.MoveOperation.NextCharacter, QtGui.QTextCursor.MoveMode.KeepAnchor, length)
            sel.cursor = c
            sels.append(sel)
        self.setExtraSelections(sels)

    def _bracket_selections(self):
        p = self.palette_data
        c = self.textCursor()
        doc = self.document()
        pos = c.position()
        text_before = doc.characterAt(pos - 1) if pos > 0 else ""
        text_at = doc.characterAt(pos)
        target = None
        if text_before in BRACKETS or text_before in CLOSERS:
            target = pos - 1
        elif text_at in BRACKETS or text_at in CLOSERS:
            target = pos
        if target is None:
            return []
        ch = doc.characterAt(target)
        match = self._find_matching(target, ch)
        out = []
        for i, ok in ((target, match is not None), (match, True)):
            if i is None:
                continue
            sel = QtWidgets.QTextEdit.ExtraSelection()
            sel.format.setBackground(QtGui.QColor(p["bracket"]) if ok else QtGui.QColor(p["error"]))
            sel.format.setFontWeight(QtGui.QFont.Weight.Bold)
            cc = QtGui.QTextCursor(doc)
            cc.setPosition(i)
            cc.movePosition(QtGui.QTextCursor.MoveOperation.NextCharacter, QtGui.QTextCursor.MoveMode.KeepAnchor)
            sel.cursor = cc
            out.append(sel)
        return out

    def _find_matching(self, index, ch):
        doc = self.document()
        text = self.toPlainText()
        if ch in BRACKETS:
            open_c, close_c, step, rng = ch, BRACKETS[ch], 1, range(index + 1, len(text))
        else:
            open_c, close_c, step, rng = CLOSERS[ch], ch, -1, range(index - 1, -1, -1)
        depth = 1
        in_str = None
        for i in rng:
            t = text[i]
            if step == 1:
                if in_str:
                    if t == in_str and text[i - 1] != "\\":
                        in_str = None
                    continue
                if t in "\"'":
                    in_str = t
                    continue
                if t == "#":
                    nl = text.find("\n", i)
                    if nl < 0:
                        return None
                    # přeskočit komentář
                    continue
            if t == open_c:
                depth += 1
            elif t == close_c:
                depth -= 1
                if depth == 0:
                    return i
        return None

    # --- editace ------------------------------------------------------------------
    def _line_indent(self, text):
        return text[: len(text) - len(text.lstrip(" \t"))]

    def keyPressEvent(self, event):  # noqa: N802
        key = event.key()
        mods = event.modifiers()
        if self.completer.popup().isVisible() and key in (
            Qt.Key.Key_Enter, Qt.Key.Key_Return, Qt.Key.Key_Escape, Qt.Key.Key_Tab, Qt.Key.Key_Backtab
        ):
            event.ignore()
            return
        if key == Qt.Key.Key_Tab and not (mods & Qt.KeyboardModifier.ControlModifier):
            if self.textCursor().hasSelection():
                self.indent_selection(True)
            else:
                self.insertPlainText(INDENT)
            return
        if key == Qt.Key.Key_Backtab:
            self.indent_selection(False)
            return
        if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self._smart_newline()
            return
        if key == Qt.Key.Key_Backspace and not self.textCursor().hasSelection():
            c = self.textCursor()
            col = c.positionInBlock()
            text = c.block().text()
            if col > 0 and text[:col].strip() == "" and col % len(INDENT) == 0:
                c.movePosition(QtGui.QTextCursor.MoveOperation.PreviousCharacter, QtGui.QTextCursor.MoveMode.KeepAnchor, len(INDENT))
                c.removeSelectedText()
                return
        text = event.text()
        if text and text in BRACKETS and not self.textCursor().hasSelection():
            nxt = self.document().characterAt(self.textCursor().position())
            if nxt == "" or nxt in " \n\t)]}\u2029":
                c = self.textCursor()
                c.insertText(text + BRACKETS[text])
                c.movePosition(QtGui.QTextCursor.MoveOperation.PreviousCharacter)
                self.setTextCursor(c)
                return
        if text and text in CLOSERS:
            if self.document().characterAt(self.textCursor().position()) == text:
                c = self.textCursor()
                c.movePosition(QtGui.QTextCursor.MoveOperation.NextCharacter)
                self.setTextCursor(c)
                return
        if text and text in "\"'" and not self.textCursor().hasSelection():
            c = self.textCursor()
            nxt = self.document().characterAt(c.position())
            prev = self.document().characterAt(c.position() - 1) if c.position() > 0 else ""
            if nxt == text:
                c.movePosition(QtGui.QTextCursor.MoveOperation.NextCharacter)
                self.setTextCursor(c)
                return
            if (nxt == "" or nxt in " \n\t)]},:\u2029") and prev != "\\" and not RE_WORD_AT.match(prev or " "):
                c.insertText(text * 2)
                c.movePosition(QtGui.QTextCursor.MoveOperation.PreviousCharacter)
                self.setTextCursor(c)
                return
        super().keyPressEvent(event)
        if text and text.isprintable() and not (mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier)):
            self._maybe_dedent_keyword()
            self._maybe_complete(event)
        elif self.completer.popup().isVisible() and key not in (Qt.Key.Key_Up, Qt.Key.Key_Down, Qt.Key.Key_PageUp, Qt.Key.Key_PageDown):
            self.completer.popup().hide()

    def _smart_newline(self):
        c = self.textCursor()
        block_text = c.block().text()
        col = c.positionInBlock()
        before = block_text[:col]
        after = block_text[col:]
        indent = self._line_indent(block_text)
        stripped = before.strip()
        code = stripped.split("#", 1)[0].rstrip()
        first = RE_WORD_AT.match(code.lstrip())
        first = first.group(0) if first else ""
        opens_block = code.endswith(":") and (first in BLOCK_OPENERS or first in BLOCK_MIDDLE)
        new_indent = indent + INDENT if opens_block else indent
        if code.endswith(("(", "[", "{")):
            new_indent = indent + INDENT
        c.beginEditBlock()
        insert = "\n" + new_indent
        need_end = opens_block and first in BLOCK_OPENERS and not after.strip() and not self._block_already_closed(c.block(), indent)
        if need_end:
            insert += "\n" + indent + "end"
        if after.strip() and after.lstrip()[0] in ")]}" and code.endswith(("(", "[", "{")):
            insert += "\n" + indent
        c.insertText(insert)
        if need_end or (after.strip() and after.lstrip()[0] in ")]}" and code.endswith(("(", "[", "{"))):
            c.movePosition(QtGui.QTextCursor.MoveOperation.Up)
            c.movePosition(QtGui.QTextCursor.MoveOperation.EndOfLine)
        c.endEditBlock()
        self.setTextCursor(c)
        self.ensureCursorVisible()

    def _block_already_closed(self, block, indent):
        """Heuristika: existuje pod blokem `end` se stejným odsazením dřív, než něco méně odsazeného?"""
        depth = 0
        b = block.next()
        while b.isValid():
            t = b.text()
            if not t.strip():
                b = b.next()
                continue
            ind = self._line_indent(t)
            if len(ind) < len(indent):
                return False
            if len(ind) == len(indent):
                w = RE_WORD_AT.match(t.strip())
                w = w.group(0) if w else ""
                if w == "end":
                    return depth == 0 or True
                if w in BLOCK_MIDDLE:
                    b = b.next()
                    continue
                return False
            b = b.next()
        return False

    def _maybe_dedent_keyword(self):
        c = self.textCursor()
        text = c.block().text()
        stripped = text.strip()
        if c.positionInBlock() != len(text):
            return
        if stripped in ("end", "else:", "elif", "else") or stripped.startswith("elif "):
            indent = self._line_indent(text)
            prev = c.block().previous()
            # najdeme odsazení otevíracího bloku
            target = None
            depth = 0
            while prev.isValid():
                t = prev.text()
                if t.strip():
                    w = RE_WORD_AT.match(t.strip())
                    w = w.group(0) if w else ""
                    ind = self._line_indent(t)
                    if w == "end":
                        depth += 1
                    elif w in BLOCK_OPENERS and t.rstrip().endswith(":"):
                        if depth == 0:
                            target = ind
                            break
                        depth -= 1
                prev = prev.previous()
            if target is not None and target != indent and len(indent) > len(target):
                c.beginEditBlock()
                c.movePosition(QtGui.QTextCursor.MoveOperation.StartOfBlock)
                c.movePosition(QtGui.QTextCursor.MoveOperation.EndOfBlock, QtGui.QTextCursor.MoveMode.KeepAnchor)
                pos_in = self.textCursor().positionInBlock() - len(indent)
                c.insertText(target + stripped)
                c.movePosition(QtGui.QTextCursor.MoveOperation.StartOfBlock)
                c.movePosition(QtGui.QTextCursor.MoveOperation.NextCharacter, QtGui.QTextCursor.MoveMode.MoveAnchor, len(target) + max(0, pos_in))
                c.endEditBlock()
                self.setTextCursor(c)

    def indent_selection(self, indent: bool):
        c = self.textCursor()
        start, end = c.selectionStart(), c.selectionEnd()
        doc = self.document()
        b1 = doc.findBlock(start)
        b2 = doc.findBlock(end)
        if end > start and b2.position() == end:
            b2 = b2.previous()
        c.beginEditBlock()
        b = b1
        while b.isValid():
            cc = QtGui.QTextCursor(b)
            if indent:
                cc.insertText(INDENT)
            else:
                t = b.text()
                n = len(t) - len(t.lstrip(" "))
                n = min(n, len(INDENT))
                if n:
                    cc.movePosition(QtGui.QTextCursor.MoveOperation.NextCharacter, QtGui.QTextCursor.MoveMode.KeepAnchor, n)
                    cc.removeSelectedText()
            if b == b2:
                break
            b = b.next()
        c.endEditBlock()

    def toggle_comment(self):
        c = self.textCursor()
        start, end = c.selectionStart(), c.selectionEnd()
        doc = self.document()
        b1 = doc.findBlock(start)
        b2 = doc.findBlock(end)
        if end > start and b2.position() == end:
            b2 = b2.previous()
        blocks = []
        b = b1
        while b.isValid():
            blocks.append(b)
            if b == b2:
                break
            b = b.next()
        all_commented = all((not bl.text().strip()) or bl.text().lstrip().startswith("#") for bl in blocks)
        c.beginEditBlock()
        for bl in blocks:
            t = bl.text()
            cc = QtGui.QTextCursor(bl)
            if all_commented:
                i = t.find("#")
                if i >= 0:
                    cc.setPosition(bl.position() + i)
                    n = 2 if t[i:i + 2] == "# " else 1
                    cc.movePosition(QtGui.QTextCursor.MoveOperation.NextCharacter, QtGui.QTextCursor.MoveMode.KeepAnchor, n)
                    cc.removeSelectedText()
            else:
                if t.strip():
                    ind = len(t) - len(t.lstrip())
                    cc.setPosition(bl.position() + ind)
                    cc.insertText("# ")
        c.endEditBlock()

    def duplicate_line(self):
        c = self.textCursor()
        c.beginEditBlock()
        t = c.block().text()
        c.movePosition(QtGui.QTextCursor.MoveOperation.EndOfBlock)
        c.insertText("\n" + t)
        c.endEditBlock()
        self.setTextCursor(c)

    def delete_line(self):
        c = self.textCursor()
        c.beginEditBlock()
        c.movePosition(QtGui.QTextCursor.MoveOperation.StartOfBlock)
        c.movePosition(QtGui.QTextCursor.MoveOperation.NextBlock, QtGui.QTextCursor.MoveMode.KeepAnchor)
        if not c.hasSelection():
            c.movePosition(QtGui.QTextCursor.MoveOperation.EndOfBlock, QtGui.QTextCursor.MoveMode.KeepAnchor)
        c.removeSelectedText()
        c.endEditBlock()

    def move_line(self, up: bool):
        c = self.textCursor()
        b = c.block()
        other = b.previous() if up else b.next()
        if not other.isValid():
            return
        col = c.positionInBlock()
        c.beginEditBlock()
        t1, t2 = b.text(), other.text()
        c.setPosition(min(b.position(), other.position()))
        c.setPosition(max(b.position() + b.length() - 1, other.position() + other.length() - 1), QtGui.QTextCursor.MoveMode.KeepAnchor)
        c.insertText((t1 + "\n" + t2) if up else (t2 + "\n" + t1))
        c.endEditBlock()
        target = other.position() if up else (b.position() + len(t2) + 1)
        c.setPosition(target + min(col, len(t1)))
        self.setTextCursor(c)

    def go_to_line(self, line, column=1):
        block = self.document().findBlockByNumber(max(0, line - 1))
        if not block.isValid():
            return
        c = QtGui.QTextCursor(block)
        c.movePosition(QtGui.QTextCursor.MoveOperation.NextCharacter, QtGui.QTextCursor.MoveMode.MoveAnchor, max(0, min(column - 1, len(block.text()))))
        self.setTextCursor(c)
        self.centerCursor()
        self.setFocus()

    # --- doplňování ---------------------------------------------------------------
    def _setup_completer(self):
        self.completer = QtWidgets.QCompleter(self)
        self.completer_model = QtGui.QStandardItemModel(self)
        self.completer.setModel(self.completer_model)
        self.completer.setWidget(self)
        self.completer.setCompletionMode(QtWidgets.QCompleter.CompletionMode.PopupCompletion)
        self.completer.setCaseSensitivity(Qt.CaseSensitivity.CaseSensitive)
        self.completer.setFilterMode(Qt.MatchFlag.MatchStartsWith)
        self.completer.activated.connect(self._insert_completion)
        self.completer.popup().setMinimumWidth(420)

    def _insert_completion(self, text):
        c = self.textCursor()
        prefix = self.completer.completionPrefix()
        extra = text[len(prefix):]
        item = None
        for row in range(self.completer_model.rowCount()):
            it = self.completer_model.item(row)
            if it.text() == text:
                item = it
                break
        c.insertText(extra)
        if item is not None and item.data(Qt.ItemDataRole.UserRole + 1) == "call":
            nxt = self.document().characterAt(c.position())
            if nxt != "(":
                c.insertText("()")
                c.movePosition(QtGui.QTextCursor.MoveOperation.PreviousCharacter)
        self.setTextCursor(c)

    def _current_prefix(self):
        c = self.textCursor()
        block = c.block().text()
        col = c.positionInBlock()
        i = col
        while i > 0 and (block[i - 1].isalnum() or block[i - 1] == "_" or ord(block[i - 1]) > 127):
            i -= 1
        prefix = block[i:col]
        dotted = ""
        if i > 0 and block[i - 1] == ".":
            j = i - 1
            while j > 0 and (block[j - 1].isalnum() or block[j - 1] == "_"):
                j -= 1
            dotted = block[j:i - 1]
        return prefix, dotted

    def _maybe_complete(self, event):
        text = event.text()
        if not text or not (text.isalnum() or text in "_."):
            if self.completer.popup().isVisible():
                self.completer.popup().hide()
            return
        self.trigger_completion(auto=True)

    def trigger_completion(self, auto=False):
        prefix, dotted = self._current_prefix()
        if auto and not dotted and len(prefix) < 2:
            self.completer.popup().hide()
            return
        items = self._completion_items(prefix, dotted)
        if not items:
            self.completer.popup().hide()
            return
        self.completer_model.clear()
        for name, kind, detail in items:
            it = QtGui.QStandardItem(name)
            it.setData(kind, Qt.ItemDataRole.UserRole + 1)
            if detail:
                it.setToolTip(detail)
            self.completer_model.appendRow(it)
        self.completer.setCompletionPrefix(prefix)
        popup = self.completer.popup()
        popup.setCurrentIndex(self.completer.completionModel().index(0, 0))
        rect = self.cursorRect()
        rect.setWidth(popup.sizeHintForColumn(0) + popup.verticalScrollBar().sizeHint().width() + 24)
        self.completer.complete(rect)

    def _completion_items(self, prefix, dotted):
        text = self.toPlainText()
        # slovo právě rozepsané pod kurzorem nesmí být kandidát (jinak Enter vloží jeho zbytek)
        c = self.textCursor()
        bt = c.block().text()
        col = c.positionInBlock()
        end = col
        while end < len(bt) and (bt[end].isalnum() or bt[end] == "_" or ord(bt[end]) > 127):
            end += 1
        current_word = bt[col - len(prefix):end] if prefix else ""
        out = {}
        if dotted:
            mods = loaded_modules(text)
            module = mods.get(dotted)
            if module and self.stdlib_index:
                for s in self.stdlib_index.symbols_of(module):
                    out[s.name] = ("call" if not s.signature.startswith("class") else "type", s.signature + ("\n" + s.doc if s.doc else ""))
            if not out:
                for m in METHODS:
                    out[m] = ("call", "metoda")
                for w in set(RE_WORD_AT.findall(text)):
                    if len(w) > 2 and w not in out:
                        out[w] = ("word", "")
        else:
            for k in KEYWORDS:
                out[k] = ("keyword", tr("klíčové slovo"))
            for k in CONSTANTS:
                out[k] = ("const", "")
            for b in BUILTINS:
                out[b] = ("call", tr("vestavěná funkce"))
            for name, sig, line in local_symbols(text):
                out[name] = ("call" if sig.startswith("function") else "type", tr('{0}  (řádek {1})').format(sig, line))
            mods = loaded_modules(text)
            for alias in mods:
                out[alias] = ("module", f"modul {mods[alias]}")
            if self.stdlib_index:
                for m in self.stdlib_index.module_names():
                    out.setdefault(m, ("module", tr("modul standardní knihovny")))
            for w in set(RE_WORD_AT.findall(text)):
                if len(w) > 2 and w not in out and not w[0].isdigit():
                    out[w] = ("word", "")
        items = [(n, k, d) for n, (k, d) in out.items() if n.startswith(prefix) and n != prefix
                 and not (k == "word" and n == current_word)]
        items.sort(key=lambda x: ({"call": 0, "type": 0, "module": 1, "keyword": 2, "const": 2, "word": 3}[x[1]], x[0]))
        return items[:200]

    def mousePressEvent(self, event):  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton and event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.setTextCursor(self.cursorForPosition(event.pos()))
            self.definition_requested.emit()
            return
        super().mousePressEvent(event)

    # --- tooltips ---------------------------------------------------------------------
    def event(self, ev):
        if ev.type() == QtCore.QEvent.Type.ToolTip:
            pos = ev.pos()
            c = self.cursorForPosition(pos)
            line = c.blockNumber() + 1
            col = c.positionInBlock() + 1
            for d in self.diagnostics:
                if d.line == line and (d.column <= col <= d.column + d.length or len(c.block().text()) == 0):
                    QtWidgets.QToolTip.showText(ev.globalPos(), d.tooltip(), self)
                    return True
            sig = self.signature_at_cursor(c)
            if sig:
                QtWidgets.QToolTip.showText(ev.globalPos(), sig, self)
                return True
            QtWidgets.QToolTip.hideText()
            return True
        return super().event(ev)

    _re_number_tok = re.compile(r"0[xX][0-9a-fA-F_]+|0[oO][0-7_]+|0[bB][01_]+|\d[\d_]*\.\d[\d_]*(?:[eE][+-]?\d+)?|\d[\d_]*[eE][+-]?\d+|\d[\d_]*")

    def word_at_cursor(self, c=None):
        c = c or self.textCursor()
        text = c.block().text()
        col = c.positionInBlock()
        for m in self._re_number_tok.finditer(text):
            if m.start() <= col <= m.end() and (m.start() == 0 or not (text[m.start() - 1].isalnum() or text[m.start() - 1] == "_")):
                return m.group(0), ""
        for m in RE_WORD_AT.finditer(text):
            if m.start() <= col <= m.end():
                word = m.group(0)
                dotted = ""
                if m.start() > 0 and text[m.start() - 1] == ".":
                    for mm in RE_WORD_AT.finditer(text[:m.start() - 1]):
                        if mm.end() == m.start() - 1:
                            dotted = mm.group(0)
                return word, dotted
        return "", ""

    def signature_at_cursor(self, c=None):
        word, dotted = self.word_at_cursor(c)
        if not word:
            return ""
        text = self.toPlainText()
        if dotted and self.stdlib_index:
            module = loaded_modules(text).get(dotted)
            if module:
                mod = self.stdlib_index.modules.get(module)
                s = mod.lookup(word) if mod else None
                if s:
                    return f"<code>{s.signature}</code>" + (f"<br>{s.doc}" if s.doc else "")
        for name, sig, line in local_symbols(text):
            if name == word:
                return f"<code>{sig}</code><br>" + tr("definováno na řádku {0}").format(line)
        if word in KEYWORDS:
            return tr('<b>{0}</b> — klíčové slovo LSL').format(word)
        if word in BUILTINS:
            return f"<code>{word}(…)</code> — " + tr("vestavěná funkce (F1 = manuál)")
        return ""

    def definition_of(self, word):
        for name, sig, line in local_symbols(self.toPlainText()):
            if name == word:
                return line
        return None
