"""Vzhled aplikace: barevné motivy (UI + editor), stylesheet a vektorové ikony."""
import os
from pathlib import Path

from .qt import QtCore, QtGui, QtWidgets, Qt


def _ui(win, win2, win3, border, text, dim, accent, accent2, sel, base, ok="#98c379", err="#e06c75", warn="#e5c07b"):
    return dict(win=win, win2=win2, win3=win3, border=border, text=text, dim=dim, accent=accent, accent2=accent2,
                sel=sel, base=base, ok=ok, err=err, warn=warn)


def _ed(bg, fg, gutter_bg, gutter_fg, current_line, selection, keyword, flow, constant, builtin, function,
        classname, string, lux, interp, number, comment, operator, module, error, warning, bracket, errtype):
    return dict(bg=bg, fg=fg, gutter_bg=gutter_bg, gutter_fg=gutter_fg, current_line=current_line, selection=selection,
                keyword=keyword, flow=flow, constant=constant, builtin=builtin, function=function, classname=classname,
                string=string, lux=lux, interp=interp, number=number, comment=comment, operator=operator, module=module,
                error=error, warning=warning, bracket=bracket, errtype=errtype, decorator=builtin)


THEMES = {
    "one-dark": dict(title="One Dark", dark=True,
        ui=_ui("#282c34", "#21252b", "#2c313c", "#181a1f", "#d7dae0", "#8b919c", "#528bff", "#61afef", "#3e4451", "#1e2127"),
        editor=_ed("#1e2127", "#d7dae0", "#22262e", "#5c6370", "#2a2f3a", "#3e4451", "#c678dd", "#e06c75", "#d19a66",
                   "#56b6c2", "#61afef", "#e5c07b", "#98c379", "#a5d6a7", "#e5c07b", "#d19a66", "#7f848e", "#abb2bf",
                   "#e5c07b", "#ff5f5f", "#e5c07b", "#3e4451", "#e06c75")),
    "one-light": dict(title="One Light", dark=False,
        ui=_ui("#f3f4f6", "#e9ebef", "#ffffff", "#d0d3d9", "#2c313a", "#7a8089", "#3b7ddd", "#2f6fcf", "#cfe0ff", "#fafafa",
               ok="#3f8f3e", err="#d64545", warn="#b8860b"),
        editor=_ed("#fafafa", "#383a42", "#f0f0f0", "#9d9d9f", "#eeeeee", "#d0d8ff", "#a626a4", "#e45649", "#986801",
                   "#0184bc", "#4078f2", "#c18401", "#50a14f", "#3f8f3e", "#c18401", "#986801", "#a0a1a7", "#383a42",
                   "#c18401", "#e45649", "#c18401", "#d0d8ff", "#e45649")),
    "monokai": dict(title="Monokai", dark=True,
        ui=_ui("#2d2e27", "#23241f", "#3a3b33", "#171813", "#f8f8f2", "#8f908a", "#a6e22e", "#66d9ef", "#49483e", "#272822",
               ok="#a6e22e", err="#f92672", warn="#e6db74"),
        editor=_ed("#272822", "#f8f8f2", "#2c2d26", "#75715e", "#3e3d32", "#49483e", "#f92672", "#f92672", "#ae81ff",
                   "#66d9ef", "#a6e22e", "#a6e22e", "#e6db74", "#e6db74", "#fd971f", "#ae81ff", "#75715e", "#f8f8f2",
                   "#66d9ef", "#f92672", "#e6db74", "#49483e", "#f92672")),
    "midnight-violet": dict(title="Půlnoční fialová", dark=True,
        ui=_ui("#282a36", "#21222c", "#343746", "#191a21", "#f8f8f2", "#8b8ea3", "#bd93f9", "#8be9fd", "#44475a", "#282a36",
               ok="#50fa7b", err="#ff5555", warn="#f1fa8c"),
        editor=_ed("#282a36", "#f8f8f2", "#282a36", "#6272a4", "#2f3240", "#44475a", "#ff79c6", "#ff79c6", "#bd93f9",
                   "#8be9fd", "#50fa7b", "#8be9fd", "#f1fa8c", "#f1fa8c", "#ffb86c", "#bd93f9", "#6272a4", "#f8f8f2",
                   "#8be9fd", "#ff5555", "#f1fa8c", "#44475a", "#ff5555")),
    "nord": dict(title="Nord", dark=True,
        ui=_ui("#2e3440", "#272c36", "#3b4252", "#1f232b", "#e5e9f0", "#8b93a4", "#88c0d0", "#81a1c1", "#434c5e", "#2e3440",
               ok="#a3be8c", err="#bf616a", warn="#ebcb8b"),
        editor=_ed("#2e3440", "#d8dee9", "#2e3440", "#4c566a", "#353b49", "#434c5e", "#81a1c1", "#81a1c1", "#b48ead",
                   "#88c0d0", "#88c0d0", "#8fbcbb", "#a3be8c", "#a3be8c", "#ebcb8b", "#b48ead", "#616e88", "#81a1c1",
                   "#8fbcbb", "#bf616a", "#ebcb8b", "#434c5e", "#bf616a")),
    "gruvbox-dark": dict(title="Gruvbox Dark", dark=True,
        ui=_ui("#282828", "#1d2021", "#3c3836", "#141414", "#ebdbb2", "#a89984", "#fe8019", "#83a598", "#504945", "#282828",
               ok="#b8bb26", err="#fb4934", warn="#fabd2f"),
        editor=_ed("#282828", "#ebdbb2", "#282828", "#7c6f64", "#32302f", "#504945", "#fb4934", "#fb4934", "#d3869b",
                   "#8ec07c", "#b8bb26", "#fabd2f", "#b8bb26", "#b8bb26", "#fe8019", "#d3869b", "#928374", "#ebdbb2",
                   "#fabd2f", "#fb4934", "#fabd2f", "#504945", "#fb4934")),
    "solarized-dark": dict(title="Solarized Dark", dark=True,
        ui=_ui("#073642", "#00303c", "#0b4a5a", "#00232c", "#eee8d5", "#839496", "#268bd2", "#2aa198", "#0f5a6b", "#002b36",
               ok="#859900", err="#dc322f", warn="#b58900"),
        editor=_ed("#002b36", "#93a1a1", "#002b36", "#586e75", "#073642", "#0f5a6b", "#859900", "#dc322f", "#cb4b16",
                   "#2aa198", "#268bd2", "#b58900", "#2aa198", "#2aa198", "#b58900", "#d33682", "#586e75", "#93a1a1",
                   "#b58900", "#dc322f", "#b58900", "#0f5a6b", "#dc322f")),
    "solarized-light": dict(title="Solarized Light", dark=False,
        ui=_ui("#eee8d5", "#e4ddc4", "#fdf6e3", "#d3cbb7", "#586e75", "#93a1a1", "#268bd2", "#2aa198", "#d6d0bd", "#fdf6e3",
               ok="#859900", err="#dc322f", warn="#b58900"),
        editor=_ed("#fdf6e3", "#657b83", "#fdf6e3", "#93a1a1", "#eee8d5", "#d6d0bd", "#859900", "#dc322f", "#cb4b16",
                   "#2aa198", "#268bd2", "#b58900", "#2aa198", "#2aa198", "#b58900", "#d33682", "#93a1a1", "#657b83",
                   "#b58900", "#dc322f", "#b58900", "#d6d0bd", "#dc322f")),
    "github-light": dict(title="GitHub Light", dark=False,
        ui=_ui("#f6f8fa", "#eaeef2", "#ffffff", "#d0d7de", "#24292f", "#6e7781", "#0969da", "#0550ae", "#ddf4ff", "#ffffff",
               ok="#1a7f37", err="#cf222e", warn="#9a6700"),
        editor=_ed("#ffffff", "#24292f", "#ffffff", "#8c959f", "#f6f8fa", "#ddf4ff", "#cf222e", "#cf222e", "#0550ae",
                   "#8250df", "#8250df", "#953800", "#0a3069", "#0a3069", "#953800", "#0550ae", "#6e7781", "#24292f",
                   "#953800", "#cf222e", "#9a6700", "#ddf4ff", "#cf222e")),
    "neon": dict(title="Neon", dark=True,
        ui=dict(_ui("#08111f", "#050e1b", "#0f1a30", "#1c2a45", "#e6ecf7", "#7f93b8", "#6d4cf5", "#38c8ff", "#332a88", "#060f1b",
                    ok="#4ade80", err="#ff5c7a", warn="#ffb547"),
                header=("#0e203b", "#1b295f", "#26124f")),
        editor=_ed("#060f1b", "#e6ecf7", "#060f1b", "#3f5f80", "#141a4f", "#332a88", "#e040ff", "#e040ff", "#ffb547",
                   "#38c8ff", "#38c8ff", "#c084fc", "#4ade80", "#4ade80", "#ffb547", "#ffb547", "#6b83b3", "#c7d2fe",
                   "#c084fc", "#ff5c7a", "#ffb547", "#332a88", "#ff5c7a")),
    "high-contrast": dict(title="Vysoký kontrast", dark=True,
        ui=_ui("#000000", "#0a0a0a", "#1a1a1a", "#3a3a3a", "#ffffff", "#bbbbbb", "#ffd700", "#00d7ff", "#264f78", "#000000",
               ok="#3cff3c", err="#ff4c4c", warn="#ffd700"),
        editor=_ed("#000000", "#ffffff", "#000000", "#888888", "#151515", "#264f78", "#ff7bd8", "#ff7bd8", "#ffd700",
                   "#00d7ff", "#7cc7ff", "#ffd700", "#3cff3c", "#3cff3c", "#ffd700", "#ffd700", "#9e9e9e", "#ffffff",
                   "#ffd700", "#ff4c4c", "#ffd700", "#264f78", "#ff4c4c")),
}
DEFAULT_THEME = "neon"
DARK = THEMES["one-dark"]["ui"]
LIGHT = THEMES["one-light"]["ui"]


def get(name):
    return THEMES.get(name) or THEMES[DEFAULT_THEME]


def _icon_file(name, color):
    """PNG ikona pro stylesheet (image: url(...)), uložená do cache."""
    d = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "lsl-ide" / "icons"
    d.mkdir(parents=True, exist_ok=True)
    f = d / f"{name}-{color.lstrip('#')}.png"
    if not f.exists():
        icon(name, color, 12).pixmap(24, 24).save(str(f))
    return str(f)


def stylesheet(c):
    close_icon = _icon_file("clear", c["text"])
    close_icon_hover = _icon_file("clear", c["err"])
    close_icon_dim = _icon_file("clear", c["dim"])
    hdr = c.get("header") or (c["win2"], QtGui.QColor(c["accent"]).darker(320).name(), QtGui.QColor(c["accent"]).darker(230).name())
    return f"""
    QFrame#headerBar {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {hdr[0]}, stop:0.5 {hdr[1]}, stop:1 {hdr[2]});
                        border-bottom: 1px solid {c['border']}; }}
    QFrame#headerBar QLabel {{ background: transparent; }}
    QLabel#appName {{ font-weight: 700; font-size: 15px; color: {c['text']}; }}
    QLabel#winTitle {{ color: {c['text']}; }}
    QFrame#headerBar QToolButton {{ border: none; border-radius: 12px; padding: 3px; }}
    QFrame#headerBar QToolButton:hover {{ background: {c['win3']}; }}
    QToolButton#winClose:hover {{ background: {c['err']}; }}
    QToolButton#primaryButton {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {c['accent']}, stop:1 {QtGui.QColor(c['accent']).lighter(125).name()});
                                 color: white; border: 1px solid {c['accent']}; padding: 4px 6px 4px 8px; }}
    QToolButton#primaryButton:hover {{ background: {QtGui.QColor(c['accent']).lighter(115).name()}; }}
    QToolButton#primaryButton::menu-button {{ border: none; width: 16px; }}
    QToolButton#primaryButton:disabled {{ background: {c['win3']}; color: {c['dim']}; border-color: {c['border']}; }}
    QToolButton#primaryButton QMenu {{ color: {c['text']}; }}
    QToolBar QToolButton#primaryButton {{ color: white; }}
    """ + f"""
    QMainWindow, QDialog, QWidget {{ background: {c['win']}; color: {c['text']}; }}
    QMenuBar {{ background: {c['win2']}; border-bottom: 1px solid {c['border']}; padding: 2px; }}
    QMenuBar::item {{ padding: 4px 10px; border-radius: 4px; }}
    QMenuBar::item:selected {{ background: {c['win3']}; }}
    QMenu {{ background: {c['win2']}; border: 1px solid {c['border']}; padding: 4px; }}
    QMenu::item {{ padding: 5px 24px 5px 12px; border-radius: 4px; }}
    QMenu::item:selected {{ background: {c['accent']}; color: white; }}
    QMenu::separator {{ height: 1px; background: {c['border']}; margin: 4px 8px; }}
    QToolBar {{ background: {c['win2']}; border: none; border-bottom: 1px solid {c['border']}; padding: 3px 6px; spacing: 2px; }}
    QToolBar::separator {{ width: 1px; background: {c['border']}; margin: 4px 6px; }}
    QToolButton {{ background: transparent; border: 1px solid transparent; border-radius: 5px; padding: 4px 8px; }}
    QToolButton:hover {{ background: {c['win3']}; border-color: {c['border']}; }}
    QToolButton:pressed, QToolButton:checked {{ background: {c['sel']}; }}
    QToolButton:disabled {{ color: {c['dim']}; }}
    QStatusBar {{ background: {c['win2']}; border-top: 1px solid {c['border']}; color: {c['dim']}; }}
    QStatusBar QLabel {{ padding: 0 8px; color: {c['text']}; }}
    QStatusBar::item {{ border: none; }}
    QDockWidget {{ titlebar-close-icon: none; titlebar-normal-icon: none; }}
    QDockWidget::title {{ background: {c['win2']}; padding: 5px 10px; border-bottom: 1px solid {c['border']};
                          text-align: left; font-weight: 600; }}
    QDockWidget::close-button, QDockWidget::float-button {{ background: transparent; border: none; padding: 2px; }}
    QDockWidget::close-button:hover, QDockWidget::float-button:hover {{ background: {c['win3']}; border-radius: 3px; }}
    QTabWidget::pane {{ border: none; border-top: 1px solid {c['border']}; }}
    QTabBar {{ background: {c['win2']}; }}
    QTabBar::tab {{ background: {c['win2']}; color: {c['dim']}; padding: 6px 14px; border: none;
                   border-right: 1px solid {c['border']}; border-bottom: 2px solid transparent; min-width: 60px; }}
    QTabBar::tab:selected {{ background: {c['base']}; color: {c['text']}; border-bottom: 2px solid {c['accent']}; }}
    QTabBar::tab:hover:!selected {{ background: {c['win3']}; color: {c['text']}; }}
    QTabBar::close-button {{ image: url({close_icon}); subcontrol-position: right; margin: 3px; border-radius: 3px; }}
    QTabBar::close-button:hover {{ image: url({close_icon_hover}); background: {c['win3']}; }}
    QTabBar::tab:!selected QTabBar::close-button {{ image: url({close_icon_dim}); }}
    QTabBar QToolButton {{ background: {c['win2']}; border: 1px solid {c['border']}; }}
    QTreeView, QListView, QListWidget, QTreeWidget, QTableWidget, QTableView, QTextBrowser, QPlainTextEdit {{
        background: {c['base']}; border: none; alternate-background-color: {c['win2']}; }}
    QTreeView::item, QListWidget::item {{ padding: 3px 2px; }}
    QTreeView::item:selected, QListWidget::item:selected, QTreeWidget::item:selected, QTableWidget::item:selected {{
        background: {c['sel']}; color: {c['text']}; }}
    QTreeView::item:hover, QListWidget::item:hover {{ background: {c['win3']}; }}
    QHeaderView::section {{ background: {c['win2']}; color: {c['dim']}; padding: 4px 6px; border: none;
                             border-right: 1px solid {c['border']}; border-bottom: 1px solid {c['border']}; }}
    QLineEdit, QComboBox, QSpinBox {{ background: {c['base']}; border: 1px solid {c['border']}; border-radius: 5px; padding: 4px 8px;
                   selection-background-color: {c['accent']}; }}
    QLineEdit:focus, QComboBox:focus {{ border-color: {c['accent']}; }}
    QComboBox::drop-down {{ border: none; width: 22px; }}
    QComboBox QAbstractItemView {{ background: {c['win2']}; border: 1px solid {c['border']}; selection-background-color: {c['accent']}; }}
    QPushButton {{ background: {c['win3']}; border: 1px solid {c['border']}; border-radius: 5px; padding: 5px 14px; }}
    QPushButton:hover {{ border-color: {c['accent']}; }}
    QPushButton:pressed {{ background: {c['sel']}; }}
    QPushButton:default {{ background: {c['accent']}; color: white; border-color: {c['accent']}; }}
    QPushButton:disabled {{ color: {c['dim']}; border-color: {c['border']}; background: {c['win2']}; }}
    QCheckBox, QRadioButton {{ spacing: 6px; }}
    QGroupBox {{ border: 1px solid {c['border']}; border-radius: 6px; margin-top: 12px; padding: 8px 6px 4px 6px; font-weight: 600; }}
    QGroupBox::title {{ subcontrol-origin: margin; left: 10px; padding: 0 4px; color: {c['dim']}; }}
    QProgressBar {{ border: 1px solid {c['border']}; border-radius: 5px; background: {c['base']}; text-align: center; height: 14px; }}
    QProgressBar::chunk {{ background: {c['accent']}; border-radius: 4px; }}
    QScrollBar:vertical {{ background: transparent; width: 12px; margin: 0; }}
    QScrollBar::handle:vertical {{ background: {c['sel']}; min-height: 24px; border-radius: 5px; margin: 2px 3px; }}
    QScrollBar::handle:vertical:hover {{ background: {c['dim']}; }}
    QScrollBar:horizontal {{ background: transparent; height: 12px; margin: 0; }}
    QScrollBar::handle:horizontal {{ background: {c['sel']}; min-width: 24px; border-radius: 5px; margin: 3px 2px; }}
    QScrollBar::handle:horizontal:hover {{ background: {c['dim']}; }}
    QScrollBar::add-line, QScrollBar::sub-line, QScrollBar::add-page, QScrollBar::sub-page {{ background: none; border: none; height: 0; width: 0; }}
    QSplitter::handle {{ background: {c['border']}; }}
    QMainWindow::separator {{ background: {c['border']}; width: 6px; height: 6px; }}
    QMainWindow::separator:hover, QMainWindow::separator:pressed {{ background: {c['accent']}; }}
    QSplitter::handle {{ background: {c['border']}; }}
    QSplitter::handle:horizontal {{ width: 6px; }}
    QSplitter::handle:vertical {{ height: 6px; }}
    QSplitter::handle:hover, QSplitter::handle:pressed {{ background: {c['accent']}; }}
    QToolTip {{ background: {c['win2']}; color: {c['text']}; border: 1px solid {c['border']}; padding: 5px 7px; border-radius: 4px; }}
    QCompleter QAbstractItemView, QListView#completerPopup {{ background: {c['win2']}; border: 1px solid {c['border']}; }}
    QLabel#hint {{ color: {c['dim']}; }}
    QLineEdit#runInput[running="true"] {{ border: 1px solid {c['accent2']}; background: {c['win3']}; }}
    QFrame#findbar {{ background: {c['win2']}; border-top: 1px solid {c['border']}; }}
    QFrame#runbar {{ background: {c['win2']}; }}
    """


def apply(app, theme_name):
    t = get(theme_name)
    c = t["ui"]
    app.setStyle("Fusion")
    pal = QtGui.QPalette()
    R = QtGui.QPalette.ColorRole
    pal.setColor(R.Window, QtGui.QColor(c["win"]))
    pal.setColor(R.WindowText, QtGui.QColor(c["text"]))
    pal.setColor(R.Base, QtGui.QColor(c["base"]))
    pal.setColor(R.AlternateBase, QtGui.QColor(c["win2"]))
    pal.setColor(R.Text, QtGui.QColor(c["text"]))
    pal.setColor(R.Button, QtGui.QColor(c["win3"]))
    pal.setColor(R.ButtonText, QtGui.QColor(c["text"]))
    pal.setColor(R.ToolTipBase, QtGui.QColor(c["win2"]))
    pal.setColor(R.ToolTipText, QtGui.QColor(c["text"]))
    pal.setColor(R.Highlight, QtGui.QColor(c["accent"]))
    pal.setColor(R.HighlightedText, QtGui.QColor("#ffffff" if t["dark"] else "#000000"))
    pal.setColor(R.Link, QtGui.QColor(c["accent2"]))
    pal.setColor(R.PlaceholderText, QtGui.QColor(c["dim"]))
    pal.setColor(QtGui.QPalette.ColorGroup.Disabled, R.Text, QtGui.QColor(c["dim"]))
    pal.setColor(QtGui.QPalette.ColorGroup.Disabled, R.ButtonText, QtGui.QColor(c["dim"]))
    app.setPalette(pal)
    app.setStyleSheet(stylesheet(c))
    return c


def icon(name, color="#d7dae0", size=18):
    """Jednoduché vektorové ikony kreslené QPainterem (bez závislosti na ikonové sadě)."""
    pm = QtGui.QPixmap(size * 2, size * 2)
    pm.fill(QtGui.QColor(0, 0, 0, 0))
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
    pen = QtGui.QPen(QtGui.QColor(color), 2.4)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    s = size * 2
    u = s / 24.0
    if name == "new":
        p.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(6*u, 3*u), QtCore.QPointF(14*u, 3*u), QtCore.QPointF(19*u, 8*u), QtCore.QPointF(19*u, 21*u), QtCore.QPointF(6*u, 21*u)]))
        p.drawLine(QtCore.QPointF(6*u, 21*u), QtCore.QPointF(6*u, 3*u))
        p.drawLine(QtCore.QPointF(14*u, 3*u), QtCore.QPointF(14*u, 8*u)); p.drawLine(QtCore.QPointF(14*u, 8*u), QtCore.QPointF(19*u, 8*u))
        p.drawLine(QtCore.QPointF(12.5*u, 12*u), QtCore.QPointF(12.5*u, 18*u)); p.drawLine(QtCore.QPointF(9.5*u, 15*u), QtCore.QPointF(15.5*u, 15*u))
    elif name == "open":
        p.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(3*u, 6*u), QtCore.QPointF(9*u, 6*u), QtCore.QPointF(11*u, 8.5*u), QtCore.QPointF(20*u, 8.5*u), QtCore.QPointF(20*u, 19*u), QtCore.QPointF(3*u, 19*u), QtCore.QPointF(3*u, 6*u)]))
    elif name == "save":
        p.drawRoundedRect(QtCore.QRectF(4*u, 4*u, 16*u, 16*u), 2*u, 2*u)
        p.drawRect(QtCore.QRectF(8*u, 4*u, 8*u, 5*u)); p.drawRect(QtCore.QRectF(7.5*u, 13*u, 9*u, 7*u))
    elif name == "run":
        p.setBrush(QtGui.QColor(color)); p.setPen(Qt.PenStyle.NoPen)
        p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(7*u, 4*u), QtCore.QPointF(20*u, 12*u), QtCore.QPointF(7*u, 20*u)]))
    elif name == "stop":
        p.setBrush(QtGui.QColor(color)); p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(QtCore.QRectF(5.5*u, 5.5*u, 13*u, 13*u), 2*u, 2*u)
    elif name == "build":
        p.drawLine(QtCore.QPointF(4*u, 12*u), QtCore.QPointF(20*u, 12*u))
        p.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(14*u, 6*u), QtCore.QPointF(20*u, 12*u), QtCore.QPointF(14*u, 18*u)]))
        p.drawRect(QtCore.QRectF(4*u, 5*u, 5*u, 14*u))
    elif name == "check":
        p.drawEllipse(QtCore.QRectF(3.5*u, 3.5*u, 17*u, 17*u))
        p.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(8*u, 12.5*u), QtCore.QPointF(11*u, 15.5*u), QtCore.QPointF(16.5*u, 9*u)]))
    elif name == "package":
        p.drawPolygon(QtGui.QPolygonF([QtCore.QPointF(12*u, 3*u), QtCore.QPointF(20*u, 7.5*u), QtCore.QPointF(20*u, 16.5*u), QtCore.QPointF(12*u, 21*u), QtCore.QPointF(4*u, 16.5*u), QtCore.QPointF(4*u, 7.5*u)]))
        p.drawLine(QtCore.QPointF(4*u, 7.5*u), QtCore.QPointF(12*u, 12*u)); p.drawLine(QtCore.QPointF(20*u, 7.5*u), QtCore.QPointF(12*u, 12*u)); p.drawLine(QtCore.QPointF(12*u, 12*u), QtCore.QPointF(12*u, 21*u))
    elif name == "tool":
        p.drawLine(QtCore.QPointF(5*u, 19*u), QtCore.QPointF(13*u, 11*u))
        p.drawEllipse(QtCore.QRectF(12*u, 4*u, 8*u, 8*u))
        p.drawLine(QtCore.QPointF(14*u, 8*u), QtCore.QPointF(18*u, 8*u))
    elif name == "info":
        p.drawEllipse(QtCore.QRectF(3.5*u, 3.5*u, 17*u, 17*u))
        p.drawLine(QtCore.QPointF(12*u, 11*u), QtCore.QPointF(12*u, 17*u)); p.drawPoint(QtCore.QPointF(12*u, 7.5*u))
    elif name == "logo":
        p.setPen(Qt.PenStyle.NoPen)
        g = QtGui.QLinearGradient(0, 0, s, s)
        g.setColorAt(0, QtGui.QColor("#22d3ee")); g.setColorAt(1, QtGui.QColor("#a855f7"))
        p.setBrush(g)
        p.drawRoundedRect(QtCore.QRectF(2*u, 2*u, 20*u, 20*u), 6*u, 6*u)
        pen = QtGui.QPen(QtGui.QColor("white"), 3.2); pen.setCapStyle(Qt.PenCapStyle.RoundCap); p.setPen(pen)
        p.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(8.5*u, 6.5*u), QtCore.QPointF(8.5*u, 17*u), QtCore.QPointF(16*u, 17*u)]))
    elif name == "minimize":
        p.drawLine(QtCore.QPointF(6*u, 12*u), QtCore.QPointF(18*u, 12*u))
    elif name == "maximize":
        p.drawRoundedRect(QtCore.QRectF(6*u, 6*u, 12*u, 12*u), 2*u, 2*u)
    elif name == "restore":
        p.drawRoundedRect(QtCore.QRectF(5*u, 8*u, 11*u, 11*u), 2*u, 2*u)
        p.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(9*u, 8*u), QtCore.QPointF(9*u, 5*u), QtCore.QPointF(19*u, 5*u), QtCore.QPointF(19*u, 15*u), QtCore.QPointF(16*u, 15*u)]))
    elif name == "chevron":
        p.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(7*u, 10*u), QtCore.QPointF(12*u, 15*u), QtCore.QPointF(17*u, 10*u)]))
    elif name == "agent":
        p.drawRoundedRect(QtCore.QRectF(4*u, 7*u, 16*u, 12*u), 3*u, 3*u)
        p.drawLine(QtCore.QPointF(12*u, 3.5*u), QtCore.QPointF(12*u, 7*u))
        p.drawPoint(QtCore.QPointF(9*u, 13*u)); p.drawPoint(QtCore.QPointF(15*u, 13*u))
        p.drawLine(QtCore.QPointF(9.5*u, 16.5*u), QtCore.QPointF(14.5*u, 16.5*u))
    elif name == "clear":
        p.drawLine(QtCore.QPointF(6*u, 6*u), QtCore.QPointF(18*u, 18*u)); p.drawLine(QtCore.QPointF(18*u, 6*u), QtCore.QPointF(6*u, 18*u))
    elif name == "cloud":
        # obláček: dva oblouky nahoře, rovná základna
        path = QtGui.QPainterPath()
        path.moveTo(7*u, 17*u)
        path.arcTo(QtCore.QRectF(3*u, 10*u, 8*u, 7*u), -90, -180)
        path.arcTo(QtCore.QRectF(6*u, 5*u, 10*u, 10*u), 200, -190)
        path.arcTo(QtCore.QRectF(13*u, 9*u, 8*u, 8*u), 90, -180)
        path.lineTo(7*u, 17*u)
        p.drawPath(path)
    p.end()
    ic = QtGui.QIcon(pm)
    return ic
