"""Panel Symbol: co je slovo pod kurzorem, kde je definované a kde se používá."""
import re
from pathlib import Path

from .qt import QtCore, QtGui, QtWidgets, Qt, Signal
from .i18n import tr
from .char_info import describe_position, interpolation_span, pick_position, tokenize
from .syntax import (KEYWORDS, KEYWORDS_BLOCK, BUILTINS, BUILTIN_ARITY, CONSTANTS, ERROR_TYPES, METHODS,
                     RE_FUNC_DEF, RE_CLASS_DEF, imported_names, loaded_module_lists, loaded_modules, local_symbols)

RE_NUMBER = re.compile(r"^(0[xX][0-9a-fA-F_]+|0[oO][0-7_]+|0[bB][01_]+|\d[\d_]*(\.\d[\d_]*)?([eE][+-]?\d+)?)$")


def describe_number(tok):
    t = tok.replace("_", "")
    try:
        if re.match(r"^0[xX]", t):
            v, kind = int(t, 16), tr("Int (šestnáctkový zápis)")
        elif re.match(r"^0[oO]", t):
            v, kind = int(t, 8), tr("Int (osmičkový zápis)")
        elif re.match(r"^0[bB]", t):
            v, kind = int(t, 2), tr("Int (dvojkový zápis)")
        elif "." in t or "e" in t.lower():
            v, kind = float(t), tr("Float (IEEE-754, boxovaný)")
        else:
            v, kind = int(t), tr("Int (64bitový, přetéká wrapem)")
    except ValueError:
        return tr("<p><b>Číselný literál</b></p>")
    h = tr('<p><b>Číselný literál</b> – typ {0}</p>').format(kind)
    if isinstance(v, int):
        h += tr("<p>Hodnota: <code>{0}</code><br>hex <code>{1}</code>, oct <code>{2}</code>, bin <code>{3}</code></p>").format(v, hex(v), oct(v), bin(v))
        if not -2**63 <= v < 2**63:
            h += tr("<p style='color:#e06c75'>Mimo rozsah Int64 – použijte <code>bigint</code>.</p>")
    else:
        h += tr("<p>Hodnota: <code>{0}</code></p>").format(repr(v))
    return h


KEYWORD_DOC = {
    "function": "Definice funkce: `function jmeno(param, volitelny=1):` … `end`.",
    "class": tr("Definice třídy: `class Jmeno(Rodic):` … `end`; konstruktor `function init(self, …)`, rodič přes `origin`."),
    "end": tr("Ukončuje blok otevřený `function`, `class`, `if`, `for`, `while`, `loop`, `try`, `safe`, `unsafe`."),
    "if": tr("Podmínka: `if výraz:` … `elif výraz:` … `else:` … `end`."),
    "elif": tr("Další větev podmínky `if`."), "else": tr("Poslední větev `if`, nebo záložní větev `try:`."),
    "for": tr("Smyčka přes kolekci: `for prvek in seznam:` … `end`; `rang(n)` dává 0..n-1."),
    "while": tr("Smyčka s podmínkou: `while výraz:` … `end`."),
    "loop": tr("Nekonečná smyčka `loop:` … `end`, ukončí se `break`."),
    "break": tr("Ukončí nejbližší smyčku."), "continue": tr("Skočí na další průchod smyčky."),
    "return": tr("Vrátí hodnotu z funkce (bez výrazu vrací None)."),
    "call": tr("Zavolá funkci jako příkaz a zahodí návratovou hodnotu: `call f(x)`."),
    "load": tr("Načte modul: `load json`, `load math as m`, nebo `from mod load f, g`."),
    "from": tr("Selektivní import: `from modul load jmeno as alias`."), "as": "Alias v `load … as` / `from … load … as`.",
    "try": tr("`try:` … `else:` … `end` — když v hlavní větvi nastane chyba, provede se `else`; `last_error()` vrátí text chyby."),
    "safe": tr("`safe:` blok – jako `try`, chyba se zachytí a blok tiše skončí."),
    "unsafe": tr("`unsafe:` blok – povoluje privilegované operace (vlákna, native, syscalls); překlad vyžaduje `--unsafe`."),
    "Error": tr("Vyvolá chybu: `Error(TypeError: \"zpráva\")`."),
    "del": tr("Smaže proměnnou: `del(x)`."), "pass": tr("Prázdný příkaz."),
    "print": tr("Vypíše argumenty oddělené mezerou: `print a, b`."),
    "printl": tr("Formátovaný výpis: `printl \"Ahoj {jmeno}\"`."),
    "input": tr("Přečte řádek ze stdin: `x = input \"Výzva: \"`."),
    "and": tr("Logické A (zkratové)."), "or": tr("Logické NEBO (zkratové)."), "not": "Negace / `not in`.",
    "in": tr("Test členství `x in kolekce`, nebo iterace ve `for`."), "is": tr("Identita hodnot; `is not`."),
    "ctype": tr("Deklarace C typu pro native plugin: `ctype Public …`."),
}


def kind_label(kind):
    """Popisek druhu modulu (bundled / user ze `lsl list`, local = soubor vedle programu)."""
    return tr("lokální modul") if kind == "local" else kind


def find_reference_row(reference_text, name):
    """Najde řádek tabulky `| \\`name(...)\\` | popis |` v referenci manuálu."""
    if not reference_text:
        return "", ""
    pat = re.compile(r"^\|\s*`\.?" + re.escape(name) + r"(\(|`)([^|]*)\|\s*(.*?)\s*\|?\s*$", re.M)
    m = pat.search(reference_text)
    if not m:
        return "", ""
    sig = "`" + name + m.group(1) + m.group(2).strip()
    sig = sig.rstrip("`").strip("` ")
    return sig, m.group(3).strip()


def find_reference_section(reference_text, name):
    """Nadpis sekce, ve které je řádek (např. 'Soubory (textové)')."""
    if not reference_text:
        return ""
    idx = reference_text.find("`" + name + "(")
    if idx < 0:
        idx = reference_text.find("`" + name + "`")
    if idx < 0:
        return ""
    head = reference_text[:idx]
    m = list(re.finditer(r"^#{2,4}\s+(.*)$", head, re.M))
    if not m:
        return ""
    return re.sub(r"<[^>]+>", "", m[-1].group(1)).strip()


class SymbolPanel(QtWidgets.QWidget):
    goto = Signal(str, int)  # path ('' = aktuální), řádek
    open_manual = Signal(str, str)  # topic, hledané slovo

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.view = QtWidgets.QTextBrowser()
        self.view.setOpenLinks(False)
        self.view.anchorClicked.connect(self._anchor)
        lay.addWidget(self.view)
        self.reference_text = ""
        self.manual = None  # ManualPanel, nastaví hlavní okno
        self.view.setHtml(tr("<p style='color:#888'>Postavte kurzor na funkci nebo proměnnou.</p>"))

    def reference_names(self):
        """Jména funkcí z tabulek reference (sekce built-in a metody), cache podle textu."""
        cache = getattr(self, "_ref_cache", None)
        if cache and cache[0] is self.reference_text:
            return cache[1]
        names = set()
        if self.reference_text:
            head = self.reference_text
            m = re.search(r"^## .*3\. Standardn", head, re.M)
            if m:
                head = head[:m.start()]
            names = set(re.findall(r"^\|\s*`\.?([A-Za-z_][A-Za-z0-9_]*)\(", head, re.M))
        self._ref_cache = (self.reference_text, names)
        return names

    def _anchor(self, url):
        s = url.toString()
        if s.startswith("goto:"):
            _, path, line = s.split(":", 2)
            self.goto.emit(path, int(line))
        elif s.startswith("manual:"):
            _, topic, word = s.split(":", 2)
            self.open_manual.emit(topic, word)

    def manual_links(self, word, esc, always_reference=False):
        """HTML odstavec s odkazy do kapitol manuálu, kde se slovo popisuje."""
        if not self.manual or not self.manual.topics:
            return ""
        hits = self.manual.chapters_mentioning(word)
        keys = [h[0] for h in hits]
        if always_reference and "reference" not in keys and any(k == "reference" for k, _ in self.manual.topics):
            hits.append(("reference", self.manual.title_of("reference"), 0))
        if not hits:
            return ""
        items = []
        for key, title, n in hits:
            sec = self.manual.section_for(key, word)
            label = esc(title) + (f" › {esc(sec)}" if sec else "")
            items.append(f"<li><a href='manual:{esc(key)}:{esc(word)}'>{label}</a></li>")
        return tr("<p><b>V manuálu LSL</b></p>") + "<ul style='margin-top:0'>" + "".join(items) + "</ul>"

    def describe(self, editor, stdlib_index, file_path=""):
        word, dotted = editor.word_at_cursor()
        text = editor.toPlainText()
        lines = text.splitlines()
        cursor = editor.textCursor()
        cur_line = cursor.blockNumber() + 1
        h = []
        esc = lambda s: (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))  # noqa: E731
        # bez slova u kurzoru, v řetězci a komentáři popisuje znak / operátor; slova (i ve výrazu {…} Lux String) řeší dál
        line_text, col = cursor.block().text(), cursor.positionInBlock()
        pos = pick_position(line_text, col)
        kind = next((k for k, _, s, e in tokenize(line_text) if s <= pos < e), "") if pos >= 0 else ""
        in_expr = kind == "str" and interpolation_span(line_text, pos) is not None
        if not word or kind in ("str", "com") and not in_expr:
            html, ch_title = describe_position(lines or [""], cursor.blockNumber(), col)
            if html:
                self.view.setHtml(f"<h3 style='margin:0 0 4px 0'><code>{esc(ch_title)}</code></h3>" + html)
                return
            if not word:
                return
        title = f"{dotted}.{word}" if dotted else word
        h.append(f"<h3 style='margin:0 0 4px 0'><code>{esc(title)}</code></h3>")
        if in_expr:
            h.append(tr("<p><i>Výraz uvnitř interpolace Lux String.</i></p>"))
        if RE_NUMBER.match(word):
            h.append(describe_number(word))
            self.view.setHtml("".join(h))
            return
        mods = loaded_modules(text)
        mod_lists = loaded_module_lists(text)
        kind_found = False

        # 1) modul.funkce (stdlib, balíček i lokální modul vedle souboru)
        if dotted:
            names = mod_lists.get(dotted) or []
            mod, sym = stdlib_index.lookup_member(names, word, file_path)
            if sym:
                module = next((n for n in names if stdlib_index.resolve(n, file_path) is mod), names[0])
                kind_found = True
                h.append(tr("<p><b>Funkce modulu</b> <code>{0}</code> ({1})<br>").format(esc(module), esc(kind_label(mod.kind))) +
                         f"<code>{esc(sym.signature)}</code></p>")
                if sym.doc:
                    h.append(f"<p>{esc(sym.doc)}</p>")
                h.append(tr("<p>Definice: ") + f"<a href='goto:{esc(mod.path)}:{sym.line}'>{esc(Path(mod.path).name)}:{sym.line}</a></p>")
                if mod.kind != "local":
                    h.append(self.manual_links(f"{module}.{word}", esc) or self.manual_links(word, esc))
            elif dotted == "self" or dotted in ("origin",):
                kind_found = True
                h.append(tr("<p><b>Atribut / metoda</b> objektu <code>{0}</code>.</p>").format(esc(dotted)))
                defs = [i + 1 for i, l in enumerate(lines) if re.search(r"self\." + re.escape(word) + r"\s*=", l)]
                if defs:
                    h.append(tr(tr("<p>Přiřazení: ")) + ", ".join(f"<a href='goto::{n}'>{n}</a>" for n in defs[:15]) + "</p>")
            elif word in METHODS:
                kind_found = True
                h.append(tr('<p><b>Metoda vestavěného typu</b> (String / List / Dictionary / …).</p>'))
                sig, desc = find_reference_row(self.reference_text, word)
                if desc:
                    h.append(f"<p><code>{esc(sig)}</code><br>{esc(desc)}</p>")
                h.append(self.manual_links(word, esc, always_reference=True))
        # 2) klíčové slovo / konstanta / builtin
        if not kind_found and word in KEYWORDS:
            kind_found = True
            h.append(tr('<p><b>Klíčové slovo</b>{0}</p>').format(tr(' (otevírá blok ukončený <code>end</code>)')if word in KEYWORDS_BLOCK else''))
            if word in KEYWORD_DOC:
                h.append(f"<p>{esc(tr(KEYWORD_DOC[word]))}</p>")
            h.append(self.manual_links(word, esc))
        elif not kind_found and word in CONSTANTS:
            kind_found = True
            doc = {"True": tr("Pravda (Bool)."), "False": tr("Nepravda (Bool)."), "None": tr("Prázdná hodnota."),
                   "self": tr("Instance uvnitř metody třídy."), "origin": tr("Rodičovská třída (`origin.init(...)`)."),
                   "Public": tr("Viditelnost pro `ctype`.")}.get(word, "")
            h.append(tr('<p><b>Konstanta / speciální jméno</b><br>{0}</p>').format(esc(doc)))
        elif not kind_found and word in ERROR_TYPES:
            kind_found = True
            h.append(tr("<p><b>Typ chyby</b> – použití: <code>Error(") + esc(word) + tr(": \"zpráva\")</code></p>"))
        elif not kind_found and not dotted and (word in BUILTINS or word in self.reference_names()):
            kind_found = True
            arity = BUILTIN_ARITY.get(word)
            h.append(tr("<p><b>Vestavěná funkce</b> – dostupná všude bez importu") +
                     (tr(', počet argumentů: {0}').format(arity) if arity is not None else "") + ".</p>")
            sig, desc = find_reference_row(self.reference_text, word)
            sec = find_reference_section(self.reference_text, word)
            if sig:
                h.append(f"<p><code>{esc(sig)}</code><br>{esc(desc)}</p>")
            elif not self.reference_text:
                h.append(tr("<p><i>Popis z reference není k dispozici (manuál se načte po detekci toolchainu).</i></p>"))
            if sec:
                h.append(tr("<p>Sekce reference: <i>{0}</i></p>").format(esc(sec)))
            h.append(self.manual_links(word, esc, always_reference=True))
        # 3) modul
        if not kind_found and not dotted and (word in mods or word in stdlib_index.modules):
            kind_found = True
            module = mods.get(word, word)
            loaded = word in mods
            mod = stdlib_index.resolve(module, file_path) if loaded else stdlib_index.modules.get(module)
            h.append(tr("<p><b>Modul</b> <code>") + f"{esc(module)}</code>" + (f" ({esc(kind_label(mod.kind))})" if mod else "") +
                     ("" if loaded else tr(" – <i>v tomto souboru není načten (<code>load ") + esc(module) + "</code>)</i>") + "</p>")
            if mod:
                if mod.doc:
                    h.append(f"<p>{esc(mod.doc)}</p>")
                h.append(tr("<p>Zdroj: ") + f"<a href='goto:{esc(mod.path)}:1'>{esc(mod.path)}</a></p>")
                names = ", ".join(f"<a href='goto:{esc(mod.path)}:{s.line}'>{esc(s.name)}</a>" for s in mod.symbols[:60])
                h.append(tr("<p>Funkce ({0}): {1}</p>").format(len(mod.symbols), names))
            if not mod or mod.kind != "local":
                h.append(self.manual_links(module, esc))
        # 4) lokální funkce / třída
        if not kind_found and not dotted:
            for name, sig, line in local_symbols(text):
                if name == word:
                    kind_found = True
                    what = tr("Funkce") if sig.startswith("function") else tr("Třída")
                    h.append(tr("<p><b>{0} v tomto souboru</b><br><code>{1}</code><br>").format(what, esc(sig)) +
                             tr("Definice: <a href='goto::{0}'>řádek {1}</a></p>").format(line, line))
                    doc = []
                    k = line - 2
                    while k >= 0 and lines[k].startswith("#"):
                        doc.insert(0, lines[k].lstrip("# ").rstrip())
                        k -= 1
                    if doc:
                        h.append(f"<p>{esc(' '.join(doc))}</p>")
                    if sig.startswith("function"):
                        params = sig[sig.index("(") + 1:sig.rindex(")")]
                        if params.strip():
                            h.append(tr("<p>Parametry: <code>{0}</code></p>").format(esc(params)))
                    break
        # 4b) jméno z `from modul load jmeno [as alias]` (stdlib, balíček i lokální modul)
        if not kind_found and not dotted:
            imp = imported_names(text).get(word)
            if imp:
                module, orig = imp
                mod, sym = stdlib_index.lookup_member([module], orig, file_path)
                kind_found = True
                h.append(tr("<p><b>Importováno z modulu</b> <code>{0}</code>").format(esc(module)) +
                         (f" ({esc(kind_label(mod.kind))})" if mod else "") + "<br>" +
                         (f"<code>{esc(sym.signature)}</code>" if sym else f"<code>from {esc(module)} load {esc(orig)}</code>") +
                         "</p>")
                if sym:
                    if sym.doc:
                        h.append(f"<p>{esc(sym.doc)}</p>")
                    h.append(tr("<p>Definice: ") + f"<a href='goto:{esc(mod.path)}:{sym.line}'>{esc(Path(mod.path).name)}:{sym.line}</a></p>")
        # 5) parametr / proměnná
        if not kind_found and not dotted:
            enclosing = None
            for name, sig, line in local_symbols(text):
                if sig.startswith("function") and line <= cur_line:
                    enclosing = (name, sig, line)
            params = []
            if enclosing:
                m = RE_FUNC_DEF.match(lines[enclosing[2] - 1])
                params = [p.strip().split("=")[0].strip() for p in m.group(2).split(",")] if m else []
            assigns = [i + 1 for i, l in enumerate(lines)
                       if re.match(r"^\s*" + re.escape(word) + r"\s*(=|\+=|-=|\*=|/=|%=|&=|\|=|~=|<<=|>>=)(?!=)", l)]
            loops = [i + 1 for i, l in enumerate(lines) if re.match(r"^\s*for\s+" + re.escape(word) + r"\s+in\b", l)]
            if enclosing and word in params:
                kind_found = True
                h.append(tr("<p><b>Parametr funkce</b> <code>{0}</code> ").format(esc(enclosing[0])) +
                         tr("(<a href='goto::{0}'>řádek {1}</a>)</p>").format(enclosing[2], enclosing[2]))
            elif assigns or loops:
                kind_found = True
                scope = tr("globální (mimo funkci)") if not enclosing or assigns and assigns[0] < enclosing[2] else tr('lokální ve funkci <code>{0}</code>').format(esc(enclosing[0]))
                h.append(tr('<p><b>Proměnná</b> – {0}<br>').format(scope))
                if assigns:
                    h.append(tr("První přiřazení: ") + tr("<a href='goto::{0}'>řádek {1}</a>: <code>{2}</code><br>").format(assigns[0], assigns[0], esc(lines[assigns[0]-1].strip())))
                    if len(assigns) > 1:
                        h.append(tr("Další přiřazení: ") + ", ".join(f"<a href='goto::{n}'>{n}</a>" for n in assigns[1:20]) + "<br>")
                if loops:
                    h.append(tr("Proměnná smyčky na řádcích: ") + ", ".join(f"<a href='goto::{n}'>{n}</a>" for n in loops[:20]))
                h.append("</p>")
        if not kind_found:
            local = not dotted and file_path and (Path(file_path).parent / f"{word}.lsl").is_file()
            if dotted and dotted in mod_lists:
                h.append(tr("<p><i>Jméno <code>{1}</code> se v modulu <code>{0}</code> nenašlo</i> (index obsahuje funkce a třídy).</p>").format(
                    esc(", ".join(mod_lists[dotted])), esc(word)))
            elif local:
                p = Path(file_path).parent / f"{word}.lsl"
                h.append(tr("<p><b>Lokální modul</b> vedle souboru: <a href='goto:{0}:1'>{1}</a></p>").format(esc(str(p)), esc(p.name)))
            else:
                h.append(tr("<p><i>Neznámý symbol</i> – není definován v souboru, ve stdlib ani mezi vestavěnými. ") +
                         tr("Compiler ohlásí E2001, pokud se čte před přiřazením.</p>"))
        # výskyty
        rx = re.compile(r"(?<![\w.])" + re.escape(word) + r"(?![\w])") if not dotted else re.compile(re.escape(dotted) + r"\." + re.escape(word) + r"\b")
        uses = [(i + 1, l.strip()) for i, l in enumerate(lines) if rx.search(l)]
        if uses:
            h.append(tr("<p><b>Výskyty v souboru ({0})</b></p><table cellspacing='0' cellpadding='1'>").format(len(uses)))
            for n, l in uses[:40]:
                mark = " style='font-weight:bold'" if n == cur_line else ""
                h.append(f"<tr><td align='right'><a href='goto::{n}'>{n}</a>&nbsp;</td><td{mark}><code>{esc(l[:100])}</code></td></tr>")
            if len(uses) > 40:
                h.append(tr('<tr><td></td><td>… a dalších {0}</td></tr>').format(len(uses)-40))
            h.append("</table>")
        self.view.setHtml("".join(h))
