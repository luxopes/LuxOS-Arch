"""Offline manuál: `lsl man --plain [TOPIC]` (Markdown) v QTextBrowser."""
import html as _html
import re
import subprocess

try:
    import markdown as _markdown
except ImportError:  # pragma: no cover
    _markdown = None

from .qt import QtCore, QtGui, QtWidgets, Qt, Signal
from .i18n import tr
from .toolchain import base_env


class ManualIndexer(QtCore.QThread):
    """Načte texty všech kapitol na pozadí (lsl man --plain TOPIC), aby šlo hledat zmínky."""
    done = Signal(dict)

    def __init__(self, toolchain, topics, parent=None):
        super().__init__(parent)
        self.toolchain = toolchain
        self.topics = topics

    def run(self):
        out = {}
        for key, _title in self.topics:
            try:
                out[key] = self.toolchain.run(["man", "--plain", key], timeout=20).stdout
            except Exception:  # noqa: BLE001
                out[key] = ""
        self.done.emit(out)


class ManualPanel(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.toolchain = None
        self.topics = []
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        top = QtWidgets.QHBoxLayout()
        self.topic_box = QtWidgets.QComboBox()
        self.topic_box.currentIndexChanged.connect(self._topic_changed)
        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText(tr("Hledat v kapitole… (Enter = další)"))
        self.search.returnPressed.connect(self.find_next)
        self.back_btn = QtWidgets.QToolButton()
        self.back_btn.setText("←")
        self.back_btn.setToolTip(tr("Zpět na předchozí kapitolu"))
        self.back_btn.clicked.connect(self.go_back)
        top.addWidget(self.back_btn)
        top.addWidget(self.topic_box, 2)
        top.addWidget(self.search, 1)
        lay.addLayout(top)
        self.browser = QtWidgets.QTextBrowser()
        self.browser.setOpenLinks(False)
        self.browser.anchorClicked.connect(self._link_clicked)
        self.browser.setObjectName("manualBrowser")
        self.history = []
        lay.addWidget(self.browser, 1)
        self.colors = None
        self.editor_colors = None
        self.mono = "DejaVu Sans Mono"
        self.base_pt = 11
        self._cache = {}
        self._indexer = None

    def set_toolchain(self, tc):
        self.toolchain = tc
        self._cache = {}
        self.reload_topics()

    def reload_topics(self):
        self.topic_box.blockSignals(True)
        self.topic_box.clear()
        self.topics = []
        if self.toolchain:
            try:
                out = self.toolchain.run(["man", "--plain"], timeout=15)
                for line in out.stdout.splitlines():
                    m = re.match(r"^(\S+)\s{2,}(.+)$", line)
                    if m:
                        self.topics.append((m.group(1), m.group(2)))
            except Exception:
                pass
        for key, title in self.topics:
            self.topic_box.addItem(title, key)
        self.topic_box.blockSignals(False)
        if self.topics and self.toolchain:
            self._indexer = ManualIndexer(self.toolchain, self.topics, self)
            self._indexer.done.connect(self._on_indexed)
            self._indexer.start()
        if self.topics:
            self._topic_changed(0)
        else:
            self.browser.setPlainText(tr("Manuál není dostupný (chybí toolchain LSL 0.8+)."))

    def set_colors(self, ui, editor, mono_font):
        self.colors, self.editor_colors = ui, editor
        self.mono = mono_font.family()
        self.base_pt = mono_font.pointSize()
        self.browser.document().setDefaultStyleSheet(self._css())
        self.browser.setStyleSheet(f"QTextBrowser#manualBrowser {{ padding: 6px 14px; font-size: {self.base_pt + 1}pt; }}")
        key = self.topic_box.currentData()
        if key and key in self._cache:
            self._render(self._cache[key])

    def _css(self):
        c = self.colors or {}
        e = self.editor_colors or {}
        return f"""
        body {{ color: {c.get('text', '#ddd')}; }}
        h1 {{ font-size: {self.base_pt + 9}pt; font-weight: 700; color: {c.get('accent2', '#7cc')}; margin-top: 4px; margin-bottom: 10px; }}
        h2 {{ font-size: {self.base_pt + 5}pt; font-weight: 700; color: {c.get('accent2', '#7cc')}; margin-top: 22px; margin-bottom: 6px; }}
        h3 {{ font-size: {self.base_pt + 2}pt; font-weight: 700; color: {c.get('text', '#ddd')}; margin-top: 16px; margin-bottom: 4px; }}
        h4 {{ font-size: {self.base_pt + 1}pt; font-weight: 700; color: {c.get('dim', '#999')}; margin-top: 12px; }}
        p {{ margin-top: 4px; margin-bottom: 8px; line-height: 135%; }}
        li {{ margin-bottom: 3px; }}
        a {{ color: {c.get('accent2', '#7cc')}; text-decoration: none; }}
        code {{ font-family: "{self.mono}"; color: {e.get('function', '#7cc')}; background-color: {c.get('win3', '#333')}; }}
        pre {{ font-family: "{self.mono}"; background-color: {e.get('bg', '#111')}; color: {e.get('fg', '#ddd')};
               margin: 8px 0 12px 0; padding: 8px; border: 1px solid {c.get('border', '#444')}; }}
        th {{ background-color: {c.get('win3', '#333')}; color: {c.get('text', '#ddd')}; font-weight: 700; padding: 4px 8px; text-align: left; }}
        td {{ padding: 4px 8px; }}
        blockquote {{ color: {c.get('dim', '#999')}; margin-left: 12px; }}
        hr {{ color: {c.get('border', '#444')}; }}
        """

    def _link_clicked(self, url):
        """Odkazy v manuálu: kapitola.md[#kotva], #kotva v kapitole, http(s) ven."""
        href = url.toString()
        if href.startswith(("http://", "https://", "mailto:")):
            QtGui.QDesktopServices.openUrl(url)
            return
        target, _, anchor = href.partition("#")
        target = target.strip()
        if target:
            key = re.sub(r"^(\./|\.\./)*", "", target)
            key = key.split("/")[-1]
            if key.endswith(".md"):
                key = key[:-3]
            if key == "index" or key == "":
                key = "README"
            known = {k for k, _ in self.topics}
            if key not in known:
                # např. odkaz na docs/xyz.md, který v offline manuálu není
                self.browser.setToolTip("")
                QtWidgets.QToolTip.showText(QtGui.QCursor.pos(), tr("Kapitola „{0}“ v offline manuálu není.").format(key), self.browser)
                return
            cur = self.topic_box.currentData()
            if cur:
                self.history.append((cur, self.browser.verticalScrollBar().value()))
            self.show_topic(key)
        if anchor:
            self._scroll_to_anchor(anchor)
        elif target:
            self.browser.verticalScrollBar().setValue(0)

    def go_back(self):
        if self.history:
            key, pos = self.history.pop()
            self.show_topic(key)
            self.browser.verticalScrollBar().setValue(pos)

    def _scroll_to_anchor(self, anchor):
        anchor = anchor.strip()
        self.browser.scrollToAnchor(anchor)
        # kotva podle textu nadpisu (různé slugify): zkusit najít nadpis, který se shoduje po normalizaci
        want = re.sub(r"[^\w]+", "-", anchor.lower()).strip("-")
        doc = self.browser.document()
        block = doc.begin()
        while block.isValid():
            if block.blockFormat().headingLevel():
                slug = re.sub(r"[^\w]+", "-", block.text().lower()).strip("-")
                if slug == want or slug.startswith(want) or want.startswith(slug) and len(slug) > 6:
                    c = QtGui.QTextCursor(block)
                    self.browser.setTextCursor(c)
                    self.browser.verticalScrollBar().setValue(self.browser.verticalScrollBar().maximum())
                    self.browser.ensureCursorVisible()
                    bar = self.browser.verticalScrollBar()
                    rect = self.browser.cursorRect(c)
                    bar.setValue(bar.value() + rect.top())
                    return
            block = block.next()

    def _render(self, text):
        c = self.colors or {}
        if _markdown is None:
            self.browser.setMarkdown(text)
            return
        try:
            from markdown.extensions.toc import TocExtension, slugify_unicode
            body = _markdown.markdown(text, extensions=["tables", "fenced_code", "sane_lists",
                                                        TocExtension(slugify=slugify_unicode, anchorlink=False)])
        except Exception:  # noqa: BLE001
            self.browser.setMarkdown(text)
            return
        border = c.get("border", "#444")
        # Qt neumí id= na nadpisech, potřebuje <a name=…>
        body = re.sub(r'<h([1-6]) id="([^"]+)">', lambda m: f'<h{m.group(1)}><a name="{m.group(2)}"></a>', body)
        body = body.replace("<table>", f"<table cellpadding='5' cellspacing='0' border='1' bordercolor='{border}' style='border-collapse: collapse; margin: 6px 0 12px 0;'>")
        # zvýraznění syntaxe LSL v blocích kódu
        body = re.sub(r"<pre><code(?: class=\"language-(\w+)\")?>(.*?)</code></pre>", self._code_block, body, flags=re.S)
        # inline kód (HTML entity zpět kvůli našemu escapování už řeší markdown)
        self.browser.setHtml(f"<html><body>{body}</body></html>")

    def _code_block(self, m):
        lang, code = m.group(1), m.group(2)
        raw = _html.unescape(code)
        if lang in ("lsl", None) and self.editor_colors:
            code = self._highlight_lsl(raw)
        else:
            code = _html.escape(raw)
        return f"<pre>{code}</pre>"

    _kw = None

    def _highlight_lsl(self, raw):
        from .syntax import KEYWORDS, BUILTINS, CONSTANTS
        e = self.editor_colors
        out = []
        for line in raw.split("\n"):
            code, _, comment = line.partition("#")
            pos = 0
            res = []
            for m in re.finditer(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|\b\d[\w.]*\b|[A-Za-z_]\w*', code):
                res.append(_html.escape(code[pos:m.start()]))
                t = m.group(0)
                if t[0] in "\"'":
                    res.append(f"<span style='color:{e['string']}'>{_html.escape(t)}</span>")
                elif t[0].isdigit():
                    res.append(f"<span style='color:{e['number']}'>{_html.escape(t)}</span>")
                elif t in KEYWORDS:
                    res.append(f"<span style='color:{e['keyword']}; font-weight:700'>{t}</span>")
                elif t in CONSTANTS:
                    res.append(f"<span style='color:{e['constant']}'>{t}</span>")
                elif t in BUILTINS:
                    res.append(f"<span style='color:{e['builtin']}'>{t}</span>")
                else:
                    res.append(t)
                pos = m.end()
            res.append(_html.escape(code[pos:]))
            if _ or comment:
                res.append(f"<span style='color:{e['comment']}; font-style:italic'>#{_html.escape(comment)}</span>")
            out.append("".join(res))
        return "\n".join(out)

    def _on_indexed(self, texts):
        for k, v in texts.items():
            self._cache.setdefault(k, v)

    def title_of(self, key):
        for k, t in self.topics:
            if k == key:
                return t
        return key

    def chapters_mentioning(self, word, limit=6):
        """Kapitoly manuálu, kde se slovo vyskytuje jako `word(` nebo `word` (bez reference)."""
        if not self._cache:
            return []
        rx = re.compile(r"(?<![\w.])" + re.escape(word) + r"(?![\w])")
        hits = []
        for key, title in self.topics:
            text = self._cache.get(key) or ""
            if not text or key in ("README", "CHANGELOG"):
                continue
            n = len(rx.findall(text))
            if n:
                hits.append((key, title, n))
        hits.sort(key=lambda h: (h[0] == "reference", -h[2]))
        return hits[:limit]

    def section_for(self, key, word):
        """Nadpis nejbližší sekce nad prvním výskytem slova v kapitole."""
        text = self._cache.get(key) or ""
        m = re.search(r"(?<![\w.])" + re.escape(word) + r"(?![\w])", text)
        if not m:
            return ""
        heads = list(re.finditer(r"^#{1,4}\s+(.*)$", text[:m.start()], re.M))
        return re.sub(r"<[^>]+>", "", heads[-1].group(1)).strip() if heads else ""

    def _topic_changed(self, idx):
        key = self.topic_box.itemData(idx)
        if not key:
            return
        self.show_topic(key)

    def show_topic(self, key, anchor_word=""):
        if not self.toolchain:
            return
        if key not in self._cache:
            try:
                out = self.toolchain.run(["man", "--plain", key], timeout=20)
                self._cache[key] = out.stdout
            except Exception as e:
                self._cache[key] = tr('Chyba načtení manuálu: {0}').format(e)
        text = self._cache[key]
        self._render(text)
        i = self.topic_box.findData(key)
        if i >= 0 and self.topic_box.currentIndex() != i:
            self.topic_box.blockSignals(True)
            self.topic_box.setCurrentIndex(i)
            self.topic_box.blockSignals(False)
        if anchor_word:
            self.search.setText(anchor_word)
            self.browser.moveCursor(self.browser.textCursor().MoveOperation.Start)
            self.find_next()

    def find_next(self):
        q = self.search.text()
        if not q:
            return
        if not self.browser.find(q):
            self.browser.moveCursor(self.browser.textCursor().MoveOperation.Start)
            self.browser.find(q)

    def lookup(self, word):
        """F1: zkusí najít slovo v referenci, jinak v aktuální kapitole."""
        if not self.toolchain:
            return
        if not self.topics:
            self.reload_topics()
        keys = [k for k, _ in self.topics]
        target = "reference" if "reference" in keys else (keys[0] if keys else None)
        if target:
            self.show_topic(target, word)
