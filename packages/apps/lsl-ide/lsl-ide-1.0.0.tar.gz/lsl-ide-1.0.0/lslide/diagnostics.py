"""Parser diagnostik compileru LSL.

Formát (NO_COLOR=1):
    error[E1100]: expected an expression
     --> /cesta/soubor.lsl:1:5
      |
    1 | x =
      |     ^~~~
     help: use a literal, name, collection, or function call
"""
import re
from dataclasses import dataclass, field

RE_HEAD = re.compile(r"^(error|warning|note)\[([A-Z]\d+)\]:\s*(.*)$")
RE_HEAD_NOCODE = re.compile(r"^(error|warning|note):\s*(.*)$")
RE_LOC = re.compile(r"^\s*-->\s*(.+?):(\d+):(\d+)\s*$")
RE_CARET = re.compile(r"^\s*\|\s*(\^~*)\s*$")
RE_HELP = re.compile(r"^\s*help:\s*(.*)$")
RE_RUNTIME = re.compile(r"(?:^|\s)((?:/|\./|~/)?[\w./-]+\.lsl):(\d+)(?::(\d+))?")


@dataclass
class Diagnostic:
    severity: str
    code: str
    message: str
    path: str = ""
    line: int = 0
    column: int = 0
    length: int = 1
    help: str = ""
    raw: list = field(default_factory=list)

    @property
    def title(self):
        code = f"[{self.code}] " if self.code else ""
        return f"{code}{self.message}"

    def tooltip(self):
        text = f"<b>{self.severity}</b> {self.title}"
        if self.help:
            text += f"<br><i>help:</i> {self.help}"
        return text


def parse_diagnostics(output: str):
    """Rozparsuje výstup compileru na seznam Diagnostic."""
    diags = []
    current = None
    for line in output.splitlines():
        m = RE_HEAD.match(line)
        if not m:
            m2 = RE_HEAD_NOCODE.match(line)
            if m2:
                current = Diagnostic(m2.group(1), "", m2.group(2).strip())
                diags.append(current)
                continue
        else:
            current = Diagnostic(m.group(1), m.group(2), m.group(3).strip())
            diags.append(current)
            continue
        if current is None:
            continue
        current.raw.append(line)
        m = RE_LOC.match(line)
        if m and not current.path:
            current.path = m.group(1)
            current.line = int(m.group(2))
            current.column = int(m.group(3))
            continue
        m = RE_CARET.match(line)
        if m:
            current.length = max(1, len(m.group(1)))
            continue
        m = RE_HELP.match(line)
        if m:
            current.help = m.group(1).strip()
    return diags


def find_locations(text: str):
    """Najde odkazy soubor.lsl:řádek[:sloupec] v libovolném textu (např. runtime chyby)."""
    return [(m.group(1), int(m.group(2)), int(m.group(3) or 1)) for m in RE_RUNTIME.finditer(text)]
