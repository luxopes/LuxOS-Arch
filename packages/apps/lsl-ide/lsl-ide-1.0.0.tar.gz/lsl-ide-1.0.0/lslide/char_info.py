"""Popis znaků a operátorů pod kurzorem pro panel Symbol.

Tabulky odpovídají chování compileru LSL 0.8.9 (ověřeno překladem ukázek):
`^` je mocnina, `~` je XOR / bitový NOT, `**`, `//=`, `^=`, `&&`, `||`, `<>`
a `;` jazyk nezná. Escape sekvence v řetězcích jsou jen \\n \\r \\t \\0 \\" \\' \\\\.
"""
import re
import unicodedata

from .i18n import tr
from .syntax import KEYWORDS, CONSTANTS, BLOCK_OPENERS, BLOCK_MIDDLE

# token -> (kategorie, popis); popisy jsou české zdrojové texty pro tr()
OPERATORS = {
    "+": ("Aritmetický operátor", "Sčítání čísel; u String a List spojení (`\"a\" + \"b\"`, `[1] + [2]`). Před výrazem unární plus."),
    "-": ("Aritmetický operátor", "Odčítání: `a - b`."),
    "*": ("Aritmetický operátor", "Násobení; `String * Int` text opakuje (`\"ab\" * 3` → `\"ababab\"`). List násobit nelze."),
    "/": ("Aritmetický operátor", "Dělení – výsledek je vždy Float (`7 / 2` → `3.5`)."),
    "//": ("Aritmetický operátor", "Celočíselné dělení zaokrouhlené dolů i pro záporná čísla (`7 // 2` → `3`, `-7 // 3` → `-3`); u Float vrací Float."),
    "%": ("Aritmetický operátor", "Zbytek po dělení; u kladného dělitele je nezáporný (`-7 % 3` → `2`)."),
    "^": ("Aritmetický operátor", "Mocnina (`2 ^ 10` → `1024`), pravostranně asociativní: `2 ^ 3 ^ 2` = `2 ^ 9`. Záporný Int exponent vyvolá ValueError. Pro XOR slouží `~`."),
    "&": ("Bitový operátor", "Bitový AND dvou Int (`12 & 10` → `8`). Váže silněji než porovnání: `p & MASKA != 0` je `(p & MASKA) != 0`."),
    "|": ("Bitový operátor", "Bitový OR dvou Int (`12 | 10` → `14`)."),
    "~": ("Bitový operátor", "Bitový XOR dvou Int (`12 ~ 10` → `6`)."),
    "<<": ("Bitový operátor", "Posun vlevo (`12 << 3` → `96`); posun o 64 a více dává 0, záporný posun vyvolá ValueError."),
    ">>": ("Bitový operátor", "Aritmetický posun vpravo, tedy `a // 2^b` (`12 >> 2` → `3`); o 64 a více dává 0, u záporného čísla -1."),
    "==": ("Porovnání", "Rovná se – výsledek je Bool. Pozor: `=` je přiřazení."),
    "!=": ("Porovnání", "Nerovná se – výsledek je Bool."),
    "<": ("Porovnání", "Menší než; jen pro čísla (String porovnávat pořadím nelze)."),
    "<=": ("Porovnání", "Menší nebo rovno; jen pro čísla."),
    ">": ("Porovnání", "Větší než; jen pro čísla."),
    ">=": ("Porovnání", "Větší nebo rovno; jen pro čísla."),
    "=": ("Přiřazení", "Uloží hodnotu do proměnné, prvku (`a[i] = x`) nebo atributu (`self.x = x`)."),
    "+=": ("Složené přiřazení", "`x += y` je `x = x + y`."),
    "-=": ("Složené přiřazení", "`x -= y` je `x = x - y`."),
    "*=": ("Složené přiřazení", "`x *= y` je `x = x * y`."),
    "/=": ("Složené přiřazení", "`x /= y` je `x = x / y` (výsledek Float)."),
    "%=": ("Složené přiřazení", "`x %= y` je `x = x % y`."),
    "&=": ("Složené přiřazení", "`x &= y` je `x = x & y`."),
    "|=": ("Složené přiřazení", "`x |= y` je `x = x | y`."),
    "~=": ("Složené přiřazení", "`x ~= y` je `x = x ~ y` (bitový XOR)."),
    "<<=": ("Složené přiřazení", "`x <<= y` je `x = x << y`."),
    ">>=": ("Složené přiřazení", "`x >>= y` je `x = x >> y`."),
    ".": ("Přístup k členu", "Atribut nebo metoda objektu (`text.upper()`, `self.x`), případně funkce modulu (`json.parse(s)`)."),
    ",": ("Oddělovač", "Odděluje argumenty, prvky kolekcí, hodnoty v `print a, b` a jména v `from m load f, g`."),
    ":": ("Dvojtečka", "Ukončuje hlavičku bloku, odděluje klíč a hodnotu v Dictionary a meze výřezu `a[od:do:krok]`."),
    "(": ("Závorka", "Seskupení výrazu, volání funkce nebo Tuple."),
    ")": ("Závorka", "Uzavírá `(`."),
    "[": ("Hranatá závorka", "List literál, comprehension, nebo indexace / výřez."),
    "]": ("Hranatá závorka", "Uzavírá `[`."),
    "{": ("Složená závorka", "Dictionary literál `{\"klíč\": hodnota}` nebo dict comprehension."),
    "}": ("Složená závorka", "Uzavírá `{`."),
    "![": ("RealArray literál", "`![1, 2, 3]` vytvoří RealArray s pevnou délkou – prvky lze měnit, `append`/`pop` nefungují."),
}

# zápisy z jiných jazyků, které LSL odmítne: token -> rada
UNSUPPORTED = {
    "**": "Mocnina se píše `^` (syntaxe `**` byla odstraněna ve verzi 0.6).",
    "//=": "Složené `//=` neexistuje – napište `x = x // y`.",
    "^=": "Složené `^=` neexistuje – napište `x = x ^ y`.",
    "&&": "Logické A se píše `and`.",
    "||": "Logické NEBO se píše `or`.",
    "<>": "Nerovnost se píše `!=`.",
    "!": "Negace se píše `not`; `!` je jen prefix RealArray literálu `![…]`.",
    ";": "Středník LSL nezná (E0006) – každý příkaz patří na vlastní řádek.",
    "?": "Ternární operátor neexistuje – použijte `if` … `else:` … `end`.",
    "@": "Znak `@` LSL nezná (E0006).",
    "$": "Znak `$` LSL nezná (E0006).",
    "`": "Zpětný apostrof LSL nezná (E0006).",
    "\\": "Zpětné lomítko patří jen do řetězce (escape sekvence).",
}

ESCAPES = {
    "n": "nový řádek (LF, U+000A)",
    "r": "návrat vozíku (CR, U+000D)",
    "t": "tabulátor (U+0009)",
    "0": "nulový znak (NUL, U+0000), totéž co `chr(0)`",
    "\"": "uvozovka",
    "'": "apostrof",
    "\\": "zpětné lomítko",
}

# znaky, které v kódu vypadají nevinně, ale compiler je odmítne
LOOKALIKES = {
    "\u201c": "Typografická uvozovka – řetězec v kódu potřebuje rovnou `\"`.",
    "\u201d": "Typografická uvozovka – řetězec v kódu potřebuje rovnou `\"`.",
    "\u201e": "Typografická uvozovka – řetězec v kódu potřebuje rovnou `\"`.",
    "\u2018": "Typografický apostrof – řetězec v kódu potřebuje rovný `'`.",
    "\u2019": "Typografický apostrof – řetězec v kódu potřebuje rovný `'`.",
    "\u201a": "Typografický apostrof – řetězec v kódu potřebuje rovný `'`.",
    "\u2013": "Pomlčka – pro odčítání použijte `-`.",
    "\u2014": "Dlouhá pomlčka – pro odčítání použijte `-`.",
    "\u2212": "Matematické minus – pro odčítání použijte `-`.",
    "\u00d7": "Znak násobení – v kódu použijte `*`.",
    "\u00f7": "Znak dělení – v kódu použijte `/`.",
    "\u2260": "Pro nerovnost použijte `!=`.",
    "\u2264": "Použijte `<=`.",
    "\u2265": "Použijte `>=`.",
    "\u00a0": "Nezlomitelná mezera – vypadá jako mezera, ale compiler ji odmítne (E0006).",
    "\u200b": "Mezera nulové šířky – neviditelná, compiler ji odmítne (E0006).",
    "\ufeff": "BOM / mezera nulové šířky – neviditelná, compiler ji odmítne (E0006).",
}

_TOKENS = sorted(set(OPERATORS) | set(UNSUPPORTED), key=len, reverse=True)
RE_TOKEN = re.compile(
    r"(?P<str>l?\"(?:\\.|[^\"\\])*\"?|l?'(?:\\.|[^'\\])*'?)"
    r"|(?P<com>#.*)"
    r"|(?P<word>[A-Za-z0-9_À-ɏ]+)"
    r"|(?P<op>" + "|".join(re.escape(t) for t in _TOKENS) + r")"
    r"|(?P<ws>\s+)"
    r"|(?P<other>.)")
OPEN, CLOSE = "([{", ")]}"


def tokenize(line):
    """[(druh, text, start, end)] pro jeden řádek; druhy str/com/word/op/ws/other."""
    return [(m.lastgroup, m.group(0), m.start(), m.end()) for m in RE_TOKEN.finditer(line)]


def pick_position(line, col):
    """Index znaku „pod kurzorem“: vpravo od kurzoru, na konci řádku nebo u mezery vlevo."""
    candidates = [p for p in (col, col - 1) if 0 <= p < len(line)]
    for p in candidates:
        if line[p] not in " \t":
            return p
    return candidates[0] if candidates else -1


def describe_char(ch):
    """HTML řádek s technickými údaji o znaku (Unicode, UTF-8, ord)."""
    cp = ord(ch)
    name = unicodedata.name(ch, "")
    if not name:
        name = {9: "CHARACTER TABULATION", 10: "LINE FEED", 13: "CARRIAGE RETURN", 0: "NULL"}.get(cp, "")
    utf8 = " ".join(f"{b:02X}" for b in ch.encode("utf-8", "surrogatepass"))
    shown = ch if ch.isprintable() and not ch.isspace() else "·"
    esc = _esc(shown)
    h = tr("<p><b>Znak</b> <code>{0}</code> – U+{1:04X}{2}<br>").format(esc, cp, f" {_esc(name)}" if name else "")
    h += tr("UTF-8: <code>{0}</code> ({1} B) · kategorie {2} · <code>ord()</code> = {3}</p>").format(
        utf8, len(ch.encode("utf-8", "surrogatepass")), unicodedata.category(ch), cp)
    return h


def _esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _md(s):
    """Překlad textu a převod `kód` na <code>."""
    return re.sub(r"`([^`]+)`", lambda m: f"<code>{m.group(1)}</code>", _esc(tr(s)))


def _prev_significant(tokens, idx):
    for k in range(idx - 1, -1, -1):
        if tokens[k][0] != "ws":
            return tokens[k]
    return None


def _is_operand_end(tok):
    """True, když předchozí token končí hodnotu (pak je `-`/`~` binární a `(`/`[` volání/indexace)."""
    if tok is None:
        return False
    kind, text = tok[0], tok[1]
    if kind == "str":
        return True
    if kind == "word":
        return text in CONSTANTS or text not in KEYWORDS
    return kind == "op" and text in (")", "]", "}")


def _brackets(lines):
    """Spárování závorek v celém textu mimo řetězce a komentáře: {(řádek, sloupec): (řádek, sloupec)}."""
    pairs, stack = {}, []
    for li, line in enumerate(lines):
        for kind, text, start, _ in tokenize(line):
            if kind != "op":
                continue
            if text == "![":
                start, text = start + 1, "["
            if text in OPEN:
                stack.append((text, li, start))
            elif text in CLOSE:
                want = OPEN[CLOSE.index(text)]
                if stack and stack[-1][0] == want:
                    _, ol, oc = stack.pop()
                    pairs[(ol, oc)] = (li, start)
                    pairs[(li, start)] = (ol, oc)
    return pairs


def _enclosing_bracket(tokens, idx):
    """Nejbližší neuzavřená otevírací závorka vlevo na stejném řádku."""
    depth = 0
    for k in range(idx - 1, -1, -1):
        kind, text = tokens[k][0], tokens[k][1]
        if kind != "op":
            continue
        if text in CLOSE:
            depth += 1
        elif text in OPEN or text == "![":
            if depth == 0:
                return k
            depth -= 1
    return None


def _string_details(token_text, rel, line_text):
    """Popis místa uvnitř řetězcového tokenu: escape, interpolace, uvozovky."""
    h = []
    lux = token_text.startswith("l") or re.match(r"^\s*printl\b", line_text) is not None
    body_start = 2 if token_text.startswith("l") else 1
    quote = token_text[body_start - 1]
    closed = len(token_text) > body_start and token_text.endswith(quote) and not _ends_escaped(token_text[body_start:-1])
    i = body_start
    while i < len(token_text):
        if token_text[i] == "\\" and i + 1 < len(token_text):
            if rel in (i, i + 1):
                seq, what = token_text[i:i + 2], ESCAPES.get(token_text[i + 1])
                if what:
                    h.append(tr("<p><b>Escape sekvence</b> <code>{0}</code> – {1}.</p>").format(_esc(seq), _md(what)))
                else:
                    h.append(tr("<p style='color:#e06c75'><b>Neznámá escape sekvence</b> <code>{0}</code> – compiler ohlásí E0003. "
                                "Podporované: <code>\\n \\r \\t \\0 \\\" \\' \\\\</code>.</p>").format(_esc(seq)))
                return h, lux
            i += 2
            continue
        i += 1
    if rel == 0 or (rel == 1 and token_text.startswith("l")):
        h.append(tr("<p><b>Začátek řetězce</b>") + (tr(" – prefix <code>l</code> dělá Lux String s interpolací <code>{výraz}</code>") if token_text.startswith("l") else "") + "</p>")
        if not closed:
            h.append(tr("<p style='color:#e06c75'>Řetězec není na tomto řádku uzavřen – LSL nemá víceřádkové řetězce.</p>"))
    elif closed and rel == len(token_text) - 1:
        h.append(tr("<p><b>Konec řetězce</b> (uzavírací <code>{0}</code>).</p>").format(_esc(quote)))
    elif lux and token_text[rel] in "{}":
        pair = token_text[rel:rel + 2] if token_text[rel:rel + 2] in ("{{", "}}") else token_text[rel - 1:rel + 1]
        if pair in ("{{", "}}"):
            h.append(tr("<p><b>Zdvojená závorka</b> <code>{0}</code> – vloží doslovný znak <code>{1}</code> bez interpolace.</p>").format(pair, pair[0]))
        else:
            h.append(tr("<p><b>Interpolace</b> – výraz mezi <code>{</code> a <code>}</code> se vyhodnotí a dosadí do textu.</p>"))
    return h, lux


def _ends_escaped(body):
    n = len(body) - len(body.rstrip("\\"))
    return n % 2 == 1


def interpolation_span(line_text, col):
    """Je-li sloupec uvnitř `{…}` v Lux String / printl, vrátí (start, end) výrazu, jinak None."""
    for kind, text, start, end in tokenize(line_text):
        if kind != "str" or not start <= col < end:
            continue
        lux = text.startswith("l") or re.match(r"^\s*printl\b", line_text) is not None
        if not lux:
            return None
        i, depth, open_at = (2 if text.startswith("l") else 1), 0, -1
        while i < len(text):
            ch = text[i]
            if ch == "\\":
                i += 2
                continue
            if ch == "{" and depth == 0 and text[i:i + 2] == "{{":
                i += 2
                continue
            if ch == "{":
                if depth == 0:
                    open_at = i
                depth += 1
            elif ch == "}" and depth:
                depth -= 1
                if depth == 0 and open_at < col - start < i:
                    return start + open_at + 1, start + i
            i += 1
        return None
    return None


def describe_position(lines, line_no, col):
    """HTML popis znaku/operátoru na pozici (0-based řádek a sloupec).

    Vrací (html, title); prázdné html znamená, že pozice nic zvláštního neobsahuje.
    """
    line = lines[line_no] if 0 <= line_no < len(lines) else ""
    pos = pick_position(line, col)
    if pos < 0:
        return "", ""
    ch = line[pos]
    tokens = tokenize(line)
    idx = next((k for k, t in enumerate(tokens) if t[2] <= pos < t[3]), None)
    kind, text, start, end = tokens[idx]
    h = []
    title = text if kind == "op" else ch
    if kind == "str":
        title = ch
        details, lux = _string_details(text, pos - start, line)
        h.append(tr("<p><b>Řetězcový literál</b>") + (tr(" – Lux String, výrazy ve složených závorkách se dosadí") if lux else tr(" (String, UTF-8)")) + "</p>")
        h.extend(details)
    elif kind == "com":
        h.append(tr("<p><b>Komentář</b> – text za <code>#</code> compiler ignoruje.</p>"))
        if pos == start and line_no == 0 and re.match(r"#\s*lsl:\s*requires\b", text):
            h.append(tr("<p>Hlavička <code># lsl: requires …</code> deklaruje závislosti balíčku registru.</p>"))
    elif kind == "op" and text in UNSUPPORTED and not (text == "!" and line[end:end + 1] == "["):
        h.append(tr("<p style='color:#e06c75'><b>Nepodporovaný zápis</b> <code>{0}</code></p>").format(_esc(text)))
        h.append(f"<p>{_md(UNSUPPORTED[text])}</p>")
    elif kind == "op":
        if text == "!":
            text = "!["
        cat, doc = OPERATORS[text]
        prev = _prev_significant(tokens, idx)
        operand = _is_operand_end(prev)
        if text == "-" and not operand:
            cat, doc = "Unární operátor", "Opačné číslo: `-x`."
        elif text == "+" and not operand:
            cat, doc = "Unární operátor", "Unární plus – hodnotu nemění."
        elif text == "~" and not operand:
            cat, doc = "Unární operátor", "Bitový NOT, jedničkový doplněk (`~12` → `-13`)."
        elif text == "(" and operand and prev[0] == "word":
            first = tokens[0][1] if tokens[0][0] != "ws" else (tokens[1][1] if len(tokens) > 1 else "")
            if first == "function":
                cat, doc = "Závorka", "Seznam parametrů funkce; výchozí hodnota se píše `jmeno=hodnota`."
            elif first == "class":
                cat, doc = "Závorka", "Rodičovská třída: `class Jmeno(Rodic):`."
            else:
                cat, doc = "Závorka", "Volání funkce `{0}(…)`; pojmenovaný argument se píše `jmeno=hodnota`."
                doc = tr(doc).replace("{0}", prev[1])
        elif text == "[" and operand:
            cat, doc = "Hranatá závorka", "Indexace `a[i]` (záporný index počítá od konce) nebo výřez `a[od:do:krok]`."
        elif text == "=":
            enc = _enclosing_bracket(tokens, idx)
            if enc is not None and tokens[enc][1] == "(":
                cat, doc = "Přiřazení", "Výchozí hodnota parametru nebo pojmenovaný argument volání."
        elif text == ":":
            enc = _enclosing_bracket(tokens, idx)
            first = next((t[1] for t in tokens if t[0] != "ws"), "")
            rest = "".join(t[1] for t in tokens[idx + 1:] if t[0] not in ("ws", "com"))
            if enc is not None and tokens[enc][1] in ("[", "!["):
                cat, doc = "Dvojtečka", "Mez výřezu `a[od:do:krok]`; vynechaná mez znamená začátek / konec."
            elif enc is not None and tokens[enc][1] == "{":
                cat, doc = "Dvojtečka", "Odděluje klíč a hodnotu v Dictionary."
            elif not rest and first in BLOCK_OPENERS | BLOCK_MIDDLE:
                cat = "Dvojtečka"
                doc = tr("Ukončuje hlavičku bloku `{0}`; tělo pokračuje na dalších řádcích.").replace("{0}", first)
                if first not in BLOCK_MIDDLE:
                    doc += " " + tr("Blok končí `end`.")
        elif text == "." and prev is not None and prev[0] == "word" and prev[1][:1].isdigit():
            cat, doc = "Desetinná tečka", "Odděluje celou a desetinnou část čísla Float."
        if text == "[" and not operand:
            close = _find_close(tokens, idx)
            if close is not None and any(t[0] == "word" and t[1] == "for" for t in tokens[idx + 1:close]):
                cat, doc = "Hranatá závorka", "List comprehension `[výraz for x in kolekce if podmínka]`."
        if text == "{":
            close = _find_close(tokens, idx)
            if close is not None and any(t[0] == "word" and t[1] == "for" for t in tokens[idx + 1:close]):
                doc = "Dict comprehension `{klíč: hodnota for x in kolekce}`."
        h.append(f"<p><b>{_esc(tr(cat))}</b> <code>{_esc(text)}</code></p><p>{_md(doc)}</p>")
        if text in OPEN + CLOSE or text == "![":
            bpos = start + 1 if text == "![" else pos
            match = _brackets(lines).get((line_no, bpos))
            if match:
                ml, mc = match
                h.append(tr("<p>Párová závorka: <a href='goto::{0}'>řádek {0}, sloupec {1}</a>: <code>{2}</code></p>").format(
                    ml + 1, mc + 1, _esc(lines[ml].strip()[:80])))
            else:
                h.append(tr("<p style='color:#e06c75'>Závorka nemá pár.</p>"))
    elif ch in LOOKALIKES:
        h.append(tr("<p style='color:#e06c75'><b>Zrádný znak</b></p>") + f"<p>{_md(LOOKALIKES[ch])}</p>")
    elif ch == "\t":
        h.append(tr("<p><b>Tabulátor</b> – v odsazení je povolený, ale míchání s mezerami zhoršuje čitelnost.</p>"))
    elif ch.isspace():
        return "", ""
    elif kind == "other":
        h.append(tr("<p style='color:#e06c75'><b>Neznámý znak</b> – mimo řetězec a komentář jej compiler odmítne (E0006).</p>"))
    else:
        return "", ""
    h.append(describe_char(ch))
    return "".join(h), title


def _find_close(tokens, idx):
    depth = 0
    for k in range(idx, len(tokens)):
        kind, text = tokens[k][0], tokens[k][1]
        if kind != "op":
            continue
        if text in OPEN or text == "![":
            depth += 1
        elif text in CLOSE:
            depth -= 1
            if depth == 0:
                return k
    return None
