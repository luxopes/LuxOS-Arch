"""Tabulky jazyka LSL a QSyntaxHighlighter.

Tabulky vycházejí z compiler/pure/parser.lsl a docs/developer_guides/reference.md
LSL 0.8.1. Zvýrazňovač pracuje po řádcích; víceřádkové řetězce LSL nemá.
"""
import re
from .qt import QtGui, QtCore

KEYWORDS_BLOCK = {
    "function", "class", "if", "elif", "else", "for", "while", "loop",
    "try", "safe", "unsafe", "end",
}
KEYWORDS_FLOW = {"return", "break", "continue", "pass", "call", "del"}
KEYWORDS_IMPORT = {"load", "from", "as", "ctype"}
KEYWORDS_OP = {"and", "or", "not", "in", "is"}
KEYWORDS_IO = {"print", "printl", "input", "Error"}
KEYWORDS = KEYWORDS_BLOCK | KEYWORDS_FLOW | KEYWORDS_IMPORT | KEYWORDS_OP | KEYWORDS_IO
# Slova, po nichž následuje blok ukončený `end` (řádek končí dvojtečkou).
BLOCK_OPENERS = {"function", "class", "if", "for", "while", "loop", "try", "safe", "unsafe"}
BLOCK_MIDDLE = {"elif", "else"}

CONSTANTS = {"True", "False", "None", "self", "origin", "Public"}

BUILTINS = {
    # konverze a typy
    "Int", "Float", "String", "Bool", "List", "Tuple", "Dictionary",
    "IntArray", "FloatArray", "ByteArray", "set", "sorted", "dedup", "type",
    # matematika a bity
    "min", "max", "sum", "abs", "sqrt", "round", "popcount", "trailing_zeros",
    "chr", "ord", "clock", "len", "rang", "range", "check", "help",
    # vlákna
    "cpu_count", "thread_spawn", "thread_join", "atomic_add", "atomic_xchg",
    "atomic_cas", "atomic_pause",
    # soubory a procesy
    "readfile", "writefile", "appendfile", "exists", "readbytes", "writebytes",
    "mkdir", "remove_path", "chdir", "cwd", "run", "capture", "capture_input",
    "capture_input_stream", "capture_status", "capture_stderr", "capture_stream",
    "arg", "arg_count", "exit", "last_error", "gc",
}

# Arity vestavěných funkcí podle compiler/pure/codegen.lsl (LSL 0.8.1).
BUILTIN_ARITY = {'Bool': 1, 'Int': 1, 'Float': 1, 'String': 1, 'List': 1, 'Tuple': 1, 'RealArray': 1, 'Dictionary': 1, 'len': 1, 'chr': 1, 'ord': 1, 'abs': 1, 'sqrt': 1, 'sum': 1, 'float_zeros': 1, 'float_fill': 2, 'float_sum': 1, 'float_dot': 2, 'float_axpy': 3, 'float_matmul': 5, 'type': 1, 'exit': 1, 'input': 1, 'readfile': 1, 'readbytes': 1, 'mkdir': 1, 'unlink': 1, 'rmdir': 1, 'exists': 1, 'gc': 0, 'clock': 0, 'arg_count': 0, 'last_error': 0, 'executable_path': 0, 'help': 0, 'run': 2, 'run_clean': 2, 'capture': 2, 'capture_clean': 2, 'capture_stream': 3, 'capture_stream_clean': 3, 'capture_input': 3, 'capture_input_clean': 3, 'capture_input_stream': 4, 'capture_input_stream_clean': 4, 'capture_status': 0, 'capture_stderr': 0, 'writefile': 2, 'appendfile': 2, 'writebytes': 2, 'check': 2, 'native_open': 1, 'native_size': 1, 'native_u64': 2, 'native_name_equal': 3, 'native_function': 2, 'native_call': 2, 'native_close': 1, 'atomic_add': 3, 'atomic_xchg': 3, 'atomic_cas': 4, 'atomic_pause': 0, 'thread_spawn': 1, 'thread_join': 1, 'cpu_count': 0, 'popcount': 1, 'trailing_zeros': 1}
BUILTINS |= set(BUILTIN_ARITY)

# Metody vestavěných typů (String/List/Dictionary/…); použito jen pro doplňování.
METHODS = {
    "append", "pop", "insert", "remove", "index", "count", "sort", "reverse",
    "extend", "clear", "copy", "keys", "values", "items", "get", "has",
    "split", "join", "strip", "lstrip", "rstrip", "upper", "lower", "replace",
    "startswith", "endswith", "find", "rfind", "text", "contains", "slice",
    "add", "subtract", "multiply", "floor_divide", "modulo", "power",
    "float_axpy", "float_dot", "float_fill", "float_matmul", "float_sum",
    "float_zeros", "init", "push", "shift", "trim", "lines", "chars", "bytes",
}

STDLIB_MODULES = [
    "ai", "bigint", "config", "configure", "css", "cuda", "display", "env", "fd",
    "gfx", "http", "httpserver", "input", "json", "lconf", "lux", "luxos", "math",
    "native", "os", "plugin", "process", "random", "sandbox", "system", "tensor",
    "time", "tui", "ui", "unixsock", "wayland", "x11",
]

ERROR_TYPES = {
    "ValueError", "TypeError", "KeyError", "IndexError", "IOError",
    "RuntimeError", "ZeroDivisionError", "NameError", "OverflowError",
}

_IDENT = r"[A-Za-z_À-ɏ][A-Za-z0-9_À-ɏ]*"
RE_IDENT = re.compile(_IDENT)
RE_WORD_AT = re.compile(r"[A-Za-z0-9_À-ɏ]+")
RE_FUNC_DEF = re.compile(r"^\s*function\s+(" + _IDENT + r")\s*\(([^)]*)\)")
RE_CLASS_DEF = re.compile(r"^\s*class\s+(" + _IDENT + r")")
RE_LOAD = re.compile(r"^\s*load\s+(" + _IDENT + r")(?:\s+as\s+(" + _IDENT + r"))?")
RE_FROM_LOAD = re.compile(r"^\s*from\s+(" + _IDENT + r")\s+load\s+(.+)$")


class Palette:
    """Barvy pro světlé a tmavé schéma."""

    DARK = dict(
        bg="#1e2127", fg="#d7dae0", gutter_bg="#22262e", gutter_fg="#5c6370",
        current_line="#2a2f3a", selection="#3e4451",
        keyword="#c678dd", flow="#e06c75", constant="#d19a66", builtin="#56b6c2",
        function="#61afef", classname="#e5c07b", string="#98c379", lux="#a5d6a7",
        interp="#e5c07b", number="#d19a66", comment="#7f848e", operator="#abb2bf",
        module="#e5c07b", error="#ff5f5f", warning="#e5c07b", bracket="#3e4451",
        errtype="#e06c75", decorator="#56b6c2",
    )
    LIGHT = dict(
        bg="#fafafa", fg="#383a42", gutter_bg="#f0f0f0", gutter_fg="#9d9d9f",
        current_line="#eeeeee", selection="#d0d8ff",
        keyword="#a626a4", flow="#e45649", constant="#986801", builtin="#0184bc",
        function="#4078f2", classname="#c18401", string="#50a14f", lux="#3f8f3e",
        interp="#c18401", number="#986801", comment="#a0a1a7", operator="#383a42",
        module="#c18401", error="#e45649", warning="#c18401", bracket="#d0d8ff",
        errtype="#e45649", decorator="#0184bc",
    )


def make_format(color, bold=False, italic=False):
    fmt = QtGui.QTextCharFormat()
    fmt.setForeground(QtGui.QColor(color))
    if bold:
        fmt.setFontWeight(QtGui.QFont.Weight.Bold)
    if italic:
        fmt.setFontItalic(True)
    return fmt


class LslHighlighter(QtGui.QSyntaxHighlighter):
    """Řádkový zvýrazňovač LSL: klíčová slova, řetězce, l"…{expr}", čísla, komentáře."""

    def __init__(self, document, palette=None):
        super().__init__(document)
        self.set_palette(palette or Palette.DARK)

    def set_palette(self, palette):
        self.p = palette
        p = palette
        self.f_keyword = make_format(p["keyword"], bold=True)
        self.f_flow = make_format(p["flow"], bold=True)
        self.f_import = make_format(p["keyword"])
        self.f_op = make_format(p["keyword"])
        self.f_io = make_format(p["builtin"], bold=True)
        self.f_constant = make_format(p["constant"])
        self.f_builtin = make_format(p["builtin"])
        self.f_function = make_format(p["function"])
        self.f_defname = make_format(p["function"], bold=True)
        self.f_classname = make_format(p["classname"], bold=True)
        self.f_string = make_format(p["string"])
        self.f_lux = make_format(p["lux"])
        self.f_interp = make_format(p["interp"], italic=True)
        self.f_number = make_format(p["number"])
        self.f_comment = make_format(p["comment"], italic=True)
        self.f_operator = make_format(p["operator"])
        self.f_module = make_format(p["module"])
        self.f_errtype = make_format(p["errtype"])
        self.f_escape = make_format(p["interp"], bold=True)
        self.rehighlight()

    # --- pomocné -----------------------------------------------------------
    _re_number = re.compile(
        r"\b(0[xX][0-9a-fA-F_]+|0[oO][0-7_]+|0[bB][01_]+|\d[\d_]*\.\d[\d_]*(?:[eE][+-]?\d+)?|\d[\d_]*[eE][+-]?\d+|\d[\d_]*)\b"
    )
    _re_operator = re.compile(r"(<<=|>>=|//|\*\*|==|!=|<=|>=|\+=|-=|\*=|/=|%=|&=|\|=|~=|<<|>>|[-+*/%^&|~<>=!])")
    _re_escape = re.compile(r"\\(?:[nrt0\\\"']|x[0-9a-fA-F]{2}|u\{[0-9a-fA-F]+\})")
    _re_interp = re.compile(r"\{[^{}]*\}")

    def highlightBlock(self, text):  # noqa: N802
        n = len(text)
        i = 0
        # Nejprve najdeme oblasti řetězců a komentáře, aby se nepletly s identifikátory.
        masked = list(text)
        while i < n:
            ch = text[i]
            if ch == "#":
                self.setFormat(i, n - i, self.f_comment)
                for k in range(i, n):
                    masked[k] = " "
                break
            is_lux = ch == "l" and i + 1 < n and text[i + 1] in "\"'" and (i == 0 or not RE_WORD_AT.match(text[i - 1]))
            if ch in "\"'" or is_lux:
                start = i
                if is_lux:
                    i += 1
                quote = text[i]
                i += 1
                while i < n and text[i] != quote:
                    if text[i] == "\\":
                        i += 1
                    i += 1
                end = min(i + 1, n)
                body = text[start:end]
                self.setFormat(start, end - start, self.f_lux if is_lux else self.f_string)
                for m in self._re_escape.finditer(body):
                    self.setFormat(start + m.start(), m.end() - m.start(), self.f_escape)
                if is_lux:
                    for m in self._re_interp.finditer(body):
                        self.setFormat(start + m.start(), m.end() - m.start(), self.f_interp)
                for k in range(start, end):
                    masked[k] = " "
                i = end
                continue
            i += 1
        code = "".join(masked)

        for m in self._re_operator.finditer(code):
            self.setFormat(m.start(), m.end() - m.start(), self.f_operator)
        for m in self._re_number.finditer(code):
            self.setFormat(m.start(), m.end() - m.start(), self.f_number)

        stripped = code.lstrip()
        first_word = RE_IDENT.match(stripped)
        first = first_word.group(0) if first_word else ""

        for m in RE_IDENT.finditer(code):
            word = m.group(0)
            s, ln = m.start(), m.end() - m.start()
            prev = code[s - 1] if s > 0 else ""
            nxt_idx = m.end()
            while nxt_idx < n and code[nxt_idx] == " ":
                nxt_idx += 1
            nxt = code[nxt_idx] if nxt_idx < n else ""
            if prev == ".":
                # atribut/metoda modulu nebo objektu
                if nxt == "(":
                    self.setFormat(s, ln, self.f_function)
                continue
            if word in KEYWORDS_BLOCK:
                self.setFormat(s, ln, self.f_keyword)
            elif word in KEYWORDS_FLOW:
                self.setFormat(s, ln, self.f_flow)
            elif word in KEYWORDS_IMPORT:
                self.setFormat(s, ln, self.f_import)
            elif word in KEYWORDS_OP:
                self.setFormat(s, ln, self.f_op)
            elif word in KEYWORDS_IO:
                self.setFormat(s, ln, self.f_io)
            elif word in CONSTANTS:
                self.setFormat(s, ln, self.f_constant)
            elif word in ERROR_TYPES:
                self.setFormat(s, ln, self.f_errtype)
            elif word in BUILTINS:
                self.setFormat(s, ln, self.f_builtin)
            elif nxt == "." and (word in STDLIB_MODULES or word in self._loaded_modules()):
                self.setFormat(s, ln, self.f_module)
            elif nxt == "(":
                self.setFormat(s, ln, self.f_function)

        if first == "function":
            m = RE_FUNC_DEF.match(code)
            if m:
                self.setFormat(m.start(1), len(m.group(1)), self.f_defname)
        elif first == "class":
            m = RE_CLASS_DEF.match(code)
            if m:
                self.setFormat(m.start(1), len(m.group(1)), self.f_classname)
        elif first in ("load", "from"):
            m = RE_LOAD.match(code) or RE_FROM_LOAD.match(code)
            if m:
                self.setFormat(m.start(1), len(m.group(1)), self.f_module)
                if m.lastindex and m.lastindex >= 2 and m.group(2) and first == "load":
                    self.setFormat(m.start(2), len(m.group(2)), self.f_module)

    def _loaded_modules(self):
        doc = self.document()
        cache = getattr(doc, "_lsl_loaded_modules", None)
        if cache is not None and cache[0] == doc.revision():
            return cache[1]
        mods = set()
        text = doc.toPlainText()
        for m in re.finditer(r"^\s*load\s+(" + _IDENT + r")(?:\s+as\s+(" + _IDENT + r"))?", text, re.M):
            mods.add(m.group(2) or m.group(1))
        doc._lsl_loaded_modules = (doc.revision(), mods)
        return mods


def loaded_modules(text):
    """Vrátí slovník alias -> modul pro všechna `load` v textu."""
    result = {}
    for m in re.finditer(r"^\s*load\s+(" + _IDENT + r")(?:\s+as\s+(" + _IDENT + r"))?", text, re.M):
        result[m.group(2) or m.group(1)] = m.group(1)
    return result


def local_symbols(text):
    """Funkce a třídy definované v textu: (jméno, signatura, řádek)."""
    out = []
    for no, line in enumerate(text.splitlines(), 1):
        m = RE_FUNC_DEF.match(line)
        if m:
            out.append((m.group(1), f"function {m.group(1)}({m.group(2).strip()})", no))
            continue
        m = RE_CLASS_DEF.match(line)
        if m:
            out.append((m.group(1), f"class {m.group(1)}", no))
    return out
