"""Ochrana IDE a počítače před spuštěným programem.

Program uživatele (i ten, který spouští agent) běží ve vlastní skupině procesů
s limitem adresního prostoru (RLIMIT_AS), takže pokus o alokaci nad limit skončí
chybou uvnitř programu místo vyčerpání RAM a swapu celého počítače. Nad tím běží
hlídač: pokud v systému dojde volná paměť nebo skupina procesů přeroste limit
(např. když limit nešlo nastavit), skupinu zabije. Výstup čtený agentem je
omezený počtem bajtů, aby nekonečný `print` nezaplnil paměť IDE.

`lsl program.lsl` spouští přeložený program jako podproces, proto se vždy
pracuje s celou skupinou (killpg), nikdy jen s přímým potomkem.
"""
import os
import resource
import select
import signal
import subprocess
import time

DEFAULT_LIMIT_MB = 2048          # výchozí strop, pokud je RAM dost velká
LOW_MEMORY_MB = 300              # pod tolik MB volné paměti hlídač program zabije
MAX_CAPTURED_OUTPUT = 512 * 1024  # bajtů výstupu, které agent maximálně přečte
SETTING_KEY = "run/memory_limit_mb"


def total_memory_mb():
    try:
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") // (1024 * 1024)
    except (ValueError, OSError, AttributeError):
        return 0


def default_limit_mb():
    """Polovina fyzické RAM, nejvýše DEFAULT_LIMIT_MB, nejméně 512 MB."""
    total = total_memory_mb()
    if not total:
        return DEFAULT_LIMIT_MB
    return max(512, min(DEFAULT_LIMIT_MB, total // 2))


def limit_from_settings(settings):
    """Limit v MB z nastavení (0 = bez limitu); chybějící klíč = výchozí."""
    if settings is None:
        return default_limit_mb()
    try:
        value = int(settings.value(SETTING_KEY, -1, int))
    except (TypeError, ValueError):
        value = -1
    return default_limit_mb() if value < 0 else value


def mem_available_mb():
    """MemAvailable z /proc/meminfo; -1 pokud nejde přečíst."""
    try:
        with open("/proc/meminfo", encoding="ascii", errors="replace") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) // 1024
    except (OSError, ValueError, IndexError):
        pass
    return -1


def _rss_kb(pid, page_kb):
    with open(f"/proc/{pid}/statm", "rb") as f:
        return int(f.read().split()[1]) * page_kb


def _descendants(pid):
    """Potomci pid podle /proc/<pid>/task/*/children (bez procházení celého /proc);
    OSError, když jádro soubor children nenabízí."""
    found = []
    stack = [pid]
    while stack:
        p = stack.pop()
        for tid in os.listdir(f"/proc/{p}/task"):
            with open(f"/proc/{p}/task/{tid}/children", "rb") as f:
                for child in f.read().split():
                    c = int(child)
                    found.append(c)
                    stack.append(c)
    return found


def group_rss_mb(pgid):
    """Součet RSS všech procesů ve skupině pgid (MB); 0 když nic neběží.
    Vůdce skupiny a jeho potomci se najdou přes seznam children; procházení
    celého /proc (každý proces v systému) zůstává jen jako záloha, protože
    při častém volání znatelně zdržuje hlavní vlákno IDE."""
    page_kb = os.sysconf("SC_PAGE_SIZE") // 1024
    total_kb = 0
    try:
        pids = [pgid] + _descendants(pgid)
    except (OSError, ValueError):
        pids = None
    if pids is not None:
        for pid in pids:
            try:
                total_kb += _rss_kb(pid, page_kb)
            except (OSError, ValueError, IndexError):
                continue
        return total_kb // 1024
    try:
        entries = os.listdir("/proc")
    except OSError:
        return 0
    for name in entries:
        if not name.isdigit():
            continue
        try:
            with open(f"/proc/{name}/stat", "rb") as f:
                stat = f.read()
            # pole za posledním ')' – název procesu může obsahovat mezery a závorky
            fields = stat[stat.rindex(b")") + 2:].split()
            if int(fields[2]) != pgid:  # pgrp je 5. pole v stat, tj. index 2 za názvem
                continue
            total_kb += _rss_kb(name, page_kb)
        except (OSError, ValueError, IndexError):
            continue
    return total_kb // 1024


def preexec(limit_mb):
    """Funkce pro Popen(preexec_fn=…): nastaví limity v potomkovi před exec."""
    def _apply():
        try:
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        except (ValueError, OSError):
            pass
        if limit_mb and limit_mb > 0:
            limit = int(limit_mb) * 1024 * 1024
            try:
                resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
            except (ValueError, OSError):
                pass
    return _apply


def kill_group(proc, grace=0.8):
    """SIGTERM celé skupině, po prodlevě SIGKILL. Bezpečné i pro už ukončený proces."""
    if proc is None:
        return
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError, OSError):
        pass
    try:
        proc.wait(timeout=grace)
    except subprocess.TimeoutExpired:
        pass
    except Exception:  # noqa: BLE001
        return
    if proc.poll() is None:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError, OSError):
            pass
        try:
            proc.wait(timeout=0.5)
        except Exception:  # noqa: BLE001
            pass


class Watchdog:
    """Periodická kontrola běžícího programu; vrací důvod k zabití nebo None."""

    def __init__(self, proc, limit_mb, low_memory_mb=LOW_MEMORY_MB):
        self.proc = proc
        self.limit_mb = limit_mb or 0
        self.low_memory_mb = low_memory_mb
        self.peak_mb = 0

    def check(self):
        if self.proc is None or self.proc.poll() is not None:
            return None
        rss = group_rss_mb(self.proc.pid)
        self.peak_mb = max(self.peak_mb, rss)
        # RLIMIT_AS platí pro každý proces zvlášť (lsl + přeložený program); součet RSS
        # skupiny je jen záložní pojistka pro případ, že limit nešlo nastavit.
        if self.limit_mb and rss > self.limit_mb * 1.5 + 128:
            return ("rss", rss)
        avail = mem_available_mb()
        if 0 <= avail < self.low_memory_mb:
            return ("low_memory", avail)
        return None


def run_captured(argv, input_text="", timeout=20, cwd=None, env=None, limit_mb=None,
                 max_output=MAX_CAPTURED_OUTPUT, poll_interval=0.15):
    """Spustí argv v nové skupině procesů s limity, přečte nejvýše max_output bajtů
    sloučeného stdout+stderr a vrátí (kód, text, poznámka). Poznámka je None při
    normálním konci, jinak "timeout", "output_limit", "rss" nebo "low_memory".
    Při jakémkoli přerušení je zabita celá skupina (i podproces `lsl`)."""
    limit_mb = default_limit_mb() if limit_mb is None else limit_mb
    proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            cwd=cwd, env=env, close_fds=True, start_new_session=True, preexec_fn=preexec(limit_mb))
    chunks, size, note = [], 0, None
    try:
        try:
            if input_text:
                proc.stdin.write(input_text.encode("utf-8", "replace"))
            proc.stdin.close()
        except (BrokenPipeError, OSError):
            pass
        watchdog = Watchdog(proc, limit_mb)
        deadline = time.monotonic() + max(1, timeout)
        fd = proc.stdout.fileno()
        eof = False
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                note = "timeout"
                break
            r, _, _ = select.select([fd], [], [], min(poll_interval, remaining)) if not eof else ([], [], [])
            if r:
                data = os.read(fd, 65536)
                if not data:
                    eof = True
                else:
                    keep = max(0, max_output - size)
                    chunks.append(data[:keep])
                    size += len(data)
                    if size > max_output:
                        note = "output_limit"
                        break
            if eof:
                if proc.poll() is not None:
                    break
                time.sleep(poll_interval)
            reason = watchdog.check()
            if reason:
                note = reason[0]
                break
    finally:
        if proc.poll() is None:
            kill_group(proc)
        try:
            proc.stdout.close()
        except OSError:
            pass
    code = proc.returncode if proc.returncode is not None else -1
    return code, b"".join(chunks).decode("utf-8", "replace"), note
