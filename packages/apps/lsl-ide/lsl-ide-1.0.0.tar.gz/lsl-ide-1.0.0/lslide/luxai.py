"""Klient LuxAI účtu pro coding agenta.

Přihlášení heslem nebo e-mailovým kódem proti lux-ai.cz, uložený session token,
/api/me pro měsíční spotřebu a /api/ide/chat/completions (OpenAI-kompatibilní,
tools, SSE stream) účtovaný na měsíční limit účtu. Vyžaduje serverovou část
(server/patch_lux_account.py).
"""
import json
import os
import ssl
import urllib.error
import urllib.request

from .i18n import tr

DEFAULT_ORIGIN = "https://lux-ai.cz"
CLIENT_HEADER = ("X-Lux-Client", "lsl-ide")
COOKIE = "lux_account_session"
MODELS = [("flash", "Flash (GLM 5.3) – 50 000 tokenů/měsíc"), ("lite", "Lite (GPT-OSS 20B) – 1 000 000 tokenů/měsíc")]


class WebConnect:
    """Loopback přijímač: prohlížeč po potvrzení na webu přesměruje na
    http://127.0.0.1:PORT/callback?code=…&state=… a IDE kód vymění za session."""

    def __init__(self):
        import base64
        import hashlib
        import secrets
        self.state = secrets.token_urlsafe(24)
        self.verifier = secrets.token_urlsafe(48)
        self.challenge = base64.urlsafe_b64encode(hashlib.sha256(self.verifier.encode()).digest()).rstrip(b"=").decode()
        self.code = ""
        self.error = ""
        self.done = False
        self.port = 0
        self._server = None
        self._thread = None

    def start(self):
        import threading
        from http.server import BaseHTTPRequestHandler, HTTPServer
        from urllib.parse import urlparse, parse_qs
        wc = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a):  # noqa: D102
                pass

            def do_GET(self):  # noqa: N802
                u = urlparse(self.path)
                q = parse_qs(u.query)
                ok = u.path == "/callback" and q.get("state", [""])[0] == wc.state and q.get("code", [""])[0]
                if ok:
                    wc.code = q["code"][0]
                elif u.path == "/callback":
                    wc.error = q.get("error", ["invalid_callback"])[0]
                wc.done = bool(ok or u.path == "/callback")
                body = ("<!doctype html><meta charset='utf-8'><title>LSL IDE</title>"
                        "<body style='font:16px system-ui;background:#070a12;color:#f1f6ff;display:grid;place-items:center;height:100vh;margin:0'>"
                        "<div style='text-align:center'><h2>" + ("LSL IDE připojeno k účtu LuxAI." if ok else "Připojení se nezdařilo.") +
                        "</h2><p>Toto okno můžete zavřít.</p></div>").encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        self._server = HTTPServer(("127.0.0.1", 0), Handler)
        self.port = self._server.server_address[1]
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def stop(self):
        if self._server:
            try:
                self._server.shutdown()
                self._server.server_close()
            except Exception:  # noqa: BLE001
                pass
            self._server = None


def _page_title(raw):
    """Titulek HTML stránky bez značek, nejvýše 120 znaků; jinak prázdný řetězec."""
    import html
    import re
    m = re.search(r"<title[^>]*>(.*?)</title>", raw, re.I | re.S)
    return " ".join(html.unescape(m.group(1)).split())[:120] if m else ""


def _html_error(raw, status):
    """Chyba pro odpověď, která místo JSON API vrátila webovou stránku.
    Surové HTML se do chyby nedostane, jen titulek stránky."""
    title = _page_title(raw)
    if "wedos.protection" in raw.lower() or "altcha" in raw.lower():
        return LuxError("protection", status, title)
    return LuxError("html_response", status, title)


def _looks_like_html(raw):
    head = raw.lstrip()[:200].lower()
    return head.startswith("<!doctype html") or head.startswith("<html") or "<head" in head


def system_account_file():
    """Sdílený účet LuxAI v LuxOS (zapisuje ho luxos-account, IDE ho jen čte)."""
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, "luxai", "account.json")


def load_system_account():
    """Účet přihlášený v systému LuxOS: dict {token, origin, user}, nebo None, když soubor
    chybí nebo nemá session token (systémy bez LuxOS). Soubor se nikdy nezapisuje ani nemaže."""
    try:
        with open(system_account_file(), encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict):
        return None
    token = data.get("sessionToken")
    if not isinstance(token, str) or not token.strip():
        return None
    origin = data.get("origin")
    if not isinstance(origin, str) or not origin.startswith(("https://", "http://127.0.0.1", "http://localhost")):
        origin = DEFAULT_ORIGIN
    user = data.get("user") if isinstance(data.get("user"), dict) else None
    return {"token": token.strip(), "origin": origin.rstrip("/"), "user": user}


# 403 s těmito kódy neznamená neplatnou session (chybí serverová část, ochrana WEDOS …)
_NOT_SESSION_403 = {"client", "origin", "protection", "html_response", "not_found"}


def session_rejected(err):
    """Server odmítl session token (vypršel, odhlášen jinde): 401, kód auth, nebo 403 bez jiné příčiny."""
    if not isinstance(err, LuxError):
        return False
    return err.code == "auth" or err.status == 401 or (err.status == 403 and err.code not in _NOT_SESSION_403)


class LuxError(Exception):
    def __init__(self, code, status=0, detail=""):
        super().__init__(code)
        self.code, self.status, self.detail = code, status, detail

    def human(self):
        m = {
            "invalid_credentials": tr("Neplatný e-mail nebo heslo."), "email_unverified": tr("E-mail účtu není ověřený."),
            "invalid_code": tr("Neplatný nebo prošlý kód."), "rate": tr("Příliš mnoho pokusů, zkuste to později."),
            "slow_down": tr("Počkejte minutu před dalším kódem."), "auth": tr("Nejste přihlášen k LuxAI účtu."),
            "chat_busy": tr("Na účtu už běží jiná konverzace."), "chat_rate": tr("Překročen limit požadavků, počkejte chvíli."),
            "flash_monthly_limit": tr("Měsíční limit modelu Flash je vyčerpán. Přepněte na Lite nebo počkejte na nový měsíc."),
            "monthly_limit": tr("Měsíční limit modelu Lite je vyčerpán."), "unavailable": tr("Služba není dostupná."),
            "model": tr("Model selhal: {0}").format(self.detail or self.status),
            "origin": tr("Server nepřijal požadavek IDE (chybí serverová část agenta)."),
            "client": tr("Server nepřijal požadavek IDE (chybí serverová část agenta)."),
            "not_found": tr("Endpoint agenta na serveru chybí (nasazení server/patch_lux_account.py)."),
            "network": tr("Síťová chyba: {0}").format(self.detail),
            "protection": tr("Ochrana WEDOS na serveru LuxAI zablokovala požadavek IDE bezpečnostní výzvou pro prohlížeč (HTTP {0}). "
                             "Agent nebude fungovat, dokud správce ochranu pro API nevypne.").format(self.status),
            "cloud_path": tr("Neplatná cesta v cloudu (povolené jsou složky oddělené lomítkem, bez „..“)."),
            "cloud_missing": tr("Soubor v cloudu neexistuje."), "cloud_exists": tr("Cílová cesta v cloudu už existuje."),
            "cloud_quota": tr("Cloudové úložiště je plné (128 MB na účet). Smažte nepotřebné soubory."),
            "cloud_file_too_large": tr("Soubor je pro cloud příliš velký (nejvýše 4 MB)."),
            "cloud_too_many_files": tr("Příliš mnoho souborů v cloudu (nejvýše 5000)."),
            "cloud_is_directory": tr("Na této cestě v cloudu je složka."), "cloud_is_file": tr("Nadřazená cesta v cloudu je soubor."),
            "cloud_write": tr("Zápis do cloudu selhal."),
            "bad_response": tr("Server vrátil neplatnou odpověď (HTTP {0}).").format(self.status),
            "html_response": tr("Server vrátil místo odpovědi API webovou stránku (HTTP {0}).").format(self.status) +
                             (f" {self.detail}" if self.detail else ""),
        }
        return m.get(self.code, f"{self.code} ({self.status}) {self.detail}".strip())


class LuxClient:
    def __init__(self, origin=DEFAULT_ORIGIN, token=""):
        self.origin = origin.rstrip("/")
        self.token = token
        self.user = None
        self._ctx = ssl.create_default_context()
        if self.origin.startswith("http://127.0.0.1") or self.origin.startswith("http://localhost"):
            self._ctx = None

    # --- HTTP ---------------------------------------------------------------
    def _request(self, method, path, body=None, timeout=30, stream=False):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(self.origin + path, data=data, method=method)
        req.add_header(*CLIENT_HEADER)
        req.add_header("User-Agent", "lsl-ide")
        req.add_header("Accept", "text/event-stream, application/json" if stream else "application/json")
        if data is not None:
            req.add_header("Content-Type", "application/json")
        if self.token:
            req.add_header("Cookie", f"{COOKIE}={self.token}")
        try:
            resp = urllib.request.urlopen(req, timeout=timeout, context=self._ctx)
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", "replace")
            try:
                payload = json.loads(raw)
            except ValueError:
                payload = {}
            if not isinstance(payload, dict):
                payload = {}
            if not payload and _looks_like_html(raw):
                raise _html_error(raw, e.code) from None
            code = payload.get("error") or ("not_found" if e.code == 404 else f"http_{e.code}")
            raise LuxError(code, e.code, str(payload.get("detail") or raw[:300])) from None
        except (urllib.error.URLError, OSError, TimeoutError) as e:
            raise LuxError("network", 0, str(getattr(e, "reason", e))) from None
        if stream:
            ctype = resp.headers.get("Content-Type", "")
            if "text/html" in ctype.lower():
                raise _html_error(resp.read(65536).decode("utf-8", "replace"), resp.status)
            return resp
        raw = resp.read().decode("utf-8", "replace")
        if not raw.strip():
            return {}
        try:
            return json.loads(raw)
        except ValueError:
            if _looks_like_html(raw):
                raise _html_error(raw, resp.status) from None
            raise LuxError("bad_response", resp.status, raw[:120]) from None

    # --- připojení přes web (loopback + jednorázový kód s PKCE) -----------------
    def web_connect_start(self):
        """Spustí lokální HTTP server pro callback a vrátí (url_pro_prohlížeč, WebConnect)."""
        wc = WebConnect()
        wc.start()
        url = (f"{self.origin}/ide/connect?state={wc.state}&port={wc.port}"
               f"&challenge={wc.challenge}")
        return url, wc

    def web_connect_finish(self, wc):
        """Po přijetí callbacku vymění kód za session token."""
        r = self._request("POST", "/api/ide/token", {"code": wc.code, "verifier": wc.verifier})
        self.token = r.get("sessionToken") or ""
        self.user = r.get("user")
        if not self.token:
            raise LuxError("client", 200, "server nevrátil sessionToken")
        return self.user

    # --- účet ----------------------------------------------------------------
    def login_password(self, email, password):
        r = self._request("POST", "/api/auth/password/login", {"email": email, "password": password})
        self.token = r.get("sessionToken") or ""
        self.user = r.get("user")
        if not self.token:
            raise LuxError("client", 200, "server nevrátil sessionToken")
        return self.user

    def request_code(self, email):
        return self._request("POST", "/api/auth/code/request", {"email": email})

    def login_code(self, email, code):
        r = self._request("POST", "/api/auth/code/verify", {"email": email, "code": code})
        self.token = r.get("sessionToken") or ""
        self.user = r.get("user")
        if not self.token:
            raise LuxError("client", 200, "server nevrátil sessionToken")
        return self.user

    def me(self):
        r = self._request("GET", "/api/me", timeout=15)
        self.user = r.get("user")
        return self.user

    def logout(self):
        try:
            self._request("POST", "/api/ide/logout", {})
        finally:
            self.token = ""
            self.user = None

    # --- chat ------------------------------------------------------------------
    # --- cloudové úložiště kódu (server část 4) ---------------------------------
    def cloud_list(self):
        """{files:[{path,size,mtime}], used, quota, count, fileMax}"""
        return self._request("GET", "/api/ide/cloud/list", timeout=30)

    def cloud_get(self, path):
        from urllib.parse import quote
        return self._request("GET", "/api/ide/cloud/file?path=" + quote(path, safe="/"), timeout=60)

    def cloud_put(self, path, content):
        return self._request("PUT", "/api/ide/cloud/file", {"path": path, "content": content}, timeout=120)

    def cloud_delete(self, path):
        return self._request("DELETE", "/api/ide/cloud/file", {"path": path}, timeout=60)

    def cloud_move(self, src, dst):
        return self._request("POST", "/api/ide/cloud/move", {"from": src, "to": dst}, timeout=60)

    def chat_stream(self, body, on_delta, should_stop=lambda: False, timeout=300):
        """Streamované chat completions. on_delta(delta, finish_reason, usage) se volá
        z volajícího vlákna. Vrací (assistant_message, finish_reason, usage)."""
        body = dict(body, stream=True)
        resp = self._request("POST", "/api/ide/chat/completions", body, timeout=timeout, stream=True)
        content = []
        tool_calls = {}
        usage = None
        finish = None
        buf = b""
        done = False
        try:
            while not done:
                if should_stop():
                    break
                chunk = resp.read(4096)
                if not chunk:
                    break
                buf += chunk.replace(b"\r\n", b"\n")
                while b"\n\n" in buf:
                    frame, buf = buf.split(b"\n\n", 1)
                    data = "\n".join(l[5:].strip() for l in frame.decode("utf-8", "replace").splitlines() if l.startswith("data:"))
                    if not data:
                        continue
                    if data == "[DONE]":
                        done = True
                        break
                    try:
                        ev = json.loads(data)
                    except ValueError:
                        continue
                    if ev.get("error"):
                        err = ev["error"]
                        raise LuxError("model", 200, err.get("message") if isinstance(err, dict) else str(err))
                    if ev.get("usage"):
                        usage = ev["usage"]
                    for ch in ev.get("choices") or []:
                        delta = ch.get("delta") or {}
                        if delta.get("content"):
                            content.append(delta["content"])
                        for tc in delta.get("tool_calls") or []:
                            idx = tc.get("index", 0)
                            slot = tool_calls.setdefault(idx, {"id": "", "type": "function", "function": {"name": "", "arguments": ""}})
                            if tc.get("id"):
                                slot["id"] = tc["id"]
                            fn = tc.get("function") or {}
                            if fn.get("name"):
                                slot["function"]["name"] += fn["name"]
                            if fn.get("arguments"):
                                slot["function"]["arguments"] += fn["arguments"]
                        if ch.get("finish_reason"):
                            finish = ch["finish_reason"]
                        on_delta(delta, ch.get("finish_reason"), ev.get("usage"))
        finally:
            try:
                resp.close()
            except Exception:  # noqa: BLE001
                pass
        message = {"role": "assistant", "content": "".join(content) or None}
        if tool_calls:
            message["tool_calls"] = [tool_calls[k] for k in sorted(tool_calls)]
        return message, finish, usage
