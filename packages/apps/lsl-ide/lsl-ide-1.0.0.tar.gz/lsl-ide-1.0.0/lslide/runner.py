"""Spouštění programu (`lsl soubor.lsl [args]`) a překlad (`lsl compile`) s výstupem
v panelu, vstupem pro stdin a klikacími odkazy soubor:řádek:sloupec."""
import codecs
import fcntl
import os
import pty
import re
import select
import shlex
import signal
import struct
import subprocess
import termios
from pathlib import Path

from .qt import QtCore, QtGui, QtWidgets, Qt, Signal
from .i18n import tr
from .diagnostics import find_locations, parse_diagnostics
from .toolchain import base_env
from . import sandbox


try:
    from .vendor import pyte
except ImportError:  # pragma: no cover
    pyte = None

# Klávesy → bajty pro program v režimu obrazovky (TUI); stejné sekvence posílá xterm.
_KEY_BYTES = {
    Qt.Key.Key_Up: b"\x1b[A", Qt.Key.Key_Down: b"\x1b[B", Qt.Key.Key_Right: b"\x1b[C", Qt.Key.Key_Left: b"\x1b[D",
    Qt.Key.Key_Home: b"\x1b[H", Qt.Key.Key_End: b"\x1b[F", Qt.Key.Key_PageUp: b"\x1b[5~", Qt.Key.Key_PageDown: b"\x1b[6~",
    Qt.Key.Key_Insert: b"\x1b[2~", Qt.Key.Key_Delete: b"\x1b[3~", Qt.Key.Key_Return: b"\r", Qt.Key.Key_Enter: b"\r",
    Qt.Key.Key_Backspace: b"\x7f", Qt.Key.Key_Tab: b"\t", Qt.Key.Key_Backtab: b"\x1b[Z", Qt.Key.Key_Escape: b"\x1b",
    Qt.Key.Key_F1: b"\x1bOP", Qt.Key.Key_F2: b"\x1bOQ", Qt.Key.Key_F3: b"\x1bOR", Qt.Key.Key_F4: b"\x1bOS",
    Qt.Key.Key_F5: b"\x1b[15~", Qt.Key.Key_F6: b"\x1b[17~", Qt.Key.Key_F7: b"\x1b[18~", Qt.Key.Key_F8: b"\x1b[19~",
    Qt.Key.Key_F9: b"\x1b[20~", Qt.Key.Key_F10: b"\x1b[21~", Qt.Key.Key_F11: b"\x1b[23~", Qt.Key.Key_F12: b"\x1b[24~",
}


class OutputView(QtWidgets.QPlainTextEdit):
    location_activated = Signal(str, int, int)
    key_forwarded = Signal(object)  # QKeyEvent psaný do výstupu → jde do stdin řádku
    raw_key = Signal(bytes)         # režim obrazovky: klávesa jde přímo do pty
    resized = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.forward_keys = False
        self.screen_mode = False
        self.setLineWrapMode(QtWidgets.QPlainTextEdit.LineWrapMode.WidgetWidth)
        self.setMaximumBlockCount(20000)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def keyPressEvent(self, event):  # noqa: N802
        text = event.text()
        key = event.key()
        mods = event.modifiers()
        if self.screen_mode:
            data = None
            if key in _KEY_BYTES and not (mods & Qt.KeyboardModifier.ControlModifier):
                data = _KEY_BYTES[key]
            elif mods & Qt.KeyboardModifier.ControlModifier and Qt.Key.Key_A <= key <= Qt.Key.Key_Z:
                data = bytes([key - Qt.Key.Key_A + 1])
            elif mods & Qt.KeyboardModifier.ControlModifier and key == Qt.Key.Key_Space:
                data = b"\x00"
            elif text:
                data = text.encode("utf-8")
                if mods & Qt.KeyboardModifier.AltModifier:
                    data = b"\x1b" + data
            if data:
                self.raw_key.emit(data)
                return
            super().keyPressEvent(event)
            return
        if self.forward_keys and (text and text.isprintable() or key in (Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Backspace)) \
                and not (mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier)):
            self.key_forwarded.emit(event)
            return
        super().keyPressEvent(event)

    def resizeEvent(self, event):  # noqa: N802
        super().resizeEvent(event)
        self.resized.emit()

    def term_size(self):
        """(řádky, sloupce) viditelné plochy pro velikost pty. Počítá se z celého widgetu
        (ne z viewportu), aby zobrazení/skrytí posuvníků nerozkmitalo velikost."""
        fm = self.fontMetrics()
        cw = max(1, fm.horizontalAdvance("M"))
        ch = max(1, fm.lineSpacing())
        fw = self.frameWidth() * 2
        cols = max(20, (self.width() - fw - 12) // cw - 1)
        rows = max(5, (self.height() - fw - 8) // ch)
        return rows, cols

    def mouseDoubleClickEvent(self, event):  # noqa: N802
        c = self.cursorForPosition(event.pos())
        locs = find_locations(c.block().text())
        if locs:
            path, line, col = locs[0]
            self.location_activated.emit(path, line, col)
            return
        super().mouseDoubleClickEvent(event)


class RunPanel(QtWidgets.QWidget):
    location_activated = Signal(str, int, int)
    finished = Signal(int, str)  # exit code, full output
    started = Signal()
    screen_mode_changed = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.toolchain = None
        self.proc = None
        self.master = None
        self.notifier = None
        self._poll = None
        self._buffer = []
        self._buffer_size = 0
        self._cleanup_file = None
        self.path_alias = {}
        self.memory_limit_mb = sandbox.default_limit_mb()  # nastavuje hlavní okno z nastavení
        self._watchdog = None
        self._poll_ticks = 0
        self._ansi_fmt = QtGui.QTextCharFormat()
        lay = QtWidgets.QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)
        top = QtWidgets.QHBoxLayout()
        top.setContentsMargins(6, 2, 6, 2)
        self.status = QtWidgets.QLabel(tr("Připraveno"))
        self.status.setObjectName("hint")
        self.stop_btn = QtWidgets.QToolButton()
        self.stop_btn.setText("■ " + tr("Zastavit"))
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop)
        self.clear_btn = QtWidgets.QToolButton()
        self.clear_btn.setText(tr("Vymazat"))
        self.clear_btn.clicked.connect(self.clear)
        top.addWidget(self.status, 1)
        top.addWidget(self.stop_btn)
        top.addWidget(self.clear_btn)
        lay.addLayout(top)
        self.view = OutputView()
        self.view.location_activated.connect(self.location_activated)
        self.view.key_forwarded.connect(self._forward_key)
        self.view.raw_key.connect(self._raw_key)
        self._winsize_timer = QtCore.QTimer(self)
        self._winsize_timer.setSingleShot(True)
        self._winsize_timer.setInterval(120)
        self._winsize_timer.timeout.connect(self._apply_winsize)
        self.view.resized.connect(self._winsize_timer.start)
        self.screen = None
        self.stream = None
        self._decoder = codecs.getincrementaldecoder("utf-8")("replace")
        self._render_timer = QtCore.QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.setInterval(25)
        self._render_timer.timeout.connect(self._render_screen)
        self._rendered = None      # (řádky, sloupce, x kurzoru, y kurzoru) posledního vykreslení obrazovky
        self._fmt_cache = {}       # formát znaku podle (fg, bg, bold, italics, underscore, reverse)
        self._winsize = (40, 120)
        lay.addWidget(self.view, 1)
        bottom = QtWidgets.QHBoxLayout()
        self.input = QtWidgets.QLineEdit()
        self.input.setObjectName("runInput")
        self._placeholder_idle = tr("stdin — program neběží")
        self._placeholder_run = tr("Program běží: sem napište vstup pro input a stiskněte Enter (Ctrl+D = konec vstupu)")
        self.input.setPlaceholderText(self._placeholder_idle)
        self.input.returnPressed.connect(self.send_input)
        self.input.setEnabled(False)
        self.eof_btn = QtWidgets.QToolButton()
        self.eof_btn.setText("EOF")
        self.eof_btn.setToolTip(tr("Zavřít stdin (Ctrl+D)"))
        self.eof_btn.clicked.connect(self.close_stdin)
        self.eof_btn.setEnabled(False)
        bottom.addWidget(self.input, 1)
        bottom.addWidget(self.eof_btn)
        lay.addLayout(bottom)
        QtGui.QShortcut(QtGui.QKeySequence("Ctrl+D"), self.input, self.close_stdin)

    def set_toolchain(self, tc):
        self.toolchain = tc

    def set_ansi_palette(self, c):
        """Základní ANSI barvy sladit s motivem (chyby, cesty, help compileru)."""
        base = list(self._ANSI16)
        base[1] = c["err"]; base[2] = c["ok"]; base[3] = c["warn"]; base[4] = c["accent2"]
        base[5] = c["accent"]; base[6] = c["accent2"]; base[7] = c["text"]; base[0] = c["base"]
        base[9] = QtGui.QColor(c["err"]).lighter(120).name(); base[10] = QtGui.QColor(c["ok"]).lighter(120).name()
        base[11] = QtGui.QColor(c["warn"]).lighter(120).name(); base[12] = QtGui.QColor(c["accent2"]).lighter(120).name()
        base[13] = QtGui.QColor(c["accent"]).lighter(130).name(); base[14] = QtGui.QColor(c["accent2"]).lighter(130).name()
        base[8] = c["dim"]; base[15] = "#ffffff"
        self._ANSI16 = base

    def set_font(self, font):
        # Stylesheet aplikace při polish přepíše widget font; font zadaný přes
        # stylesheet widgetu má nejvyšší prioritu, proto obojí.
        css = f'font-family: "{font.family()}"; font-size: {font.pointSize()}pt;'
        for w in (self.view, self.input):
            w.setFont(font)
        self.view.setStyleSheet(css)
        self._input_css = css
        self.input.setStyleSheet(css)
        self.view.document().setDefaultFont(font)

    def clear(self):
        self.view.clear()
        self._buffer = []

    def is_running(self):
        return self.proc is not None and self.proc.poll() is None

    def _append(self, text, color=None):
        c = self.view.textCursor()
        c.movePosition(QtGui.QTextCursor.MoveOperation.End)
        fmt = QtGui.QTextCharFormat()
        if color:
            fmt.setForeground(QtGui.QColor(color))
        for tmp, real in self.path_alias.items():
            text = text.replace(tmp, real)
        c.insertText(text, fmt)
        self.view.setTextCursor(c)
        self.view.ensureCursorVisible()

    def run_program(self, path, args="", cwd=None, unsafe=False, display=None, cleanup=None):
        if not self.toolchain:
            self._append(tr("LSL toolchain není k dispozici.\n"), "#ff5f5f")
            return
        argv = [path] + (shlex.split(args) if args else [])
        self._cleanup_file = cleanup
        shown = [display or path] + argv[1:]
        note = tr("  (neuložený obsah)") if display and display != path else ""
        self._start(argv, cwd or str(Path(path).parent), f"$ lsl {shlex.join(shown)}{note}\n")

    def compile_program(self, path, output, cwd=None, unsafe=False):
        argv = ["compile"] + (["--unsafe"] if unsafe else []) + [path, output]
        self._start(argv, cwd or str(Path(path).parent), f"$ lsl {shlex.join(argv)}\n")

    def run_cli(self, argv, cwd=None, title=None):
        """Obecné spuštění `lsl ARGV…` (balíčky, update…) do stejného panelu."""
        self._start(argv, cwd, title or f"$ lsl {shlex.join(argv)}\n")

    def run_command(self, program, argv, cwd=None, title=None):
        self._start(argv, cwd, title or f"$ {shlex.join([program, *argv])}\n", program=program)

    def _start(self, argv, cwd, banner, program=None):
        if self.is_running():
            self.stop()
        self._buffer = []
        self._buffer_size = 0
        self._ansi_fmt = QtGui.QTextCharFormat()
        self._append(banner, "#7f848e")
        env = dict(os.environ)
        env.pop("NO_COLOR", None)
        env["TERM"] = "xterm-256color"
        env["COLORTERM"] = "truecolor"
        program = program or self.toolchain.path
        try:
            master, slave = pty.openpty()
            rows, cols = self.view.term_size()
            self._winsize = (rows, cols)
            try:
                fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
            except OSError:
                pass
            self.proc = subprocess.Popen(
                [program, *argv], stdin=slave, stdout=slave, stderr=slave, cwd=cwd or None,
                env=env, close_fds=True, start_new_session=True, preexec_fn=sandbox.preexec(self.memory_limit_mb))
            os.close(slave)
        except OSError as e:
            self._append(tr('Proces se nepodařilo spustit: {0}').format(e) + '\n', "#ff5f5f")
            self.proc = None
            return
        self.master = master
        self._watchdog = sandbox.Watchdog(self.proc, self.memory_limit_mb)
        self._decoder = codecs.getincrementaldecoder("utf-8")("replace")
        self._set_screen_mode(False)
        self.notifier = QtCore.QSocketNotifier(master, QtCore.QSocketNotifier.Type.Read, self)
        self.notifier.activated.connect(self._on_output)
        self.status.setText(tr("Běží…"))
        self._set_running_ui(True)
        self.input.setFocus()
        self.started.emit()
        self._poll = QtCore.QTimer(self)
        self._poll.setInterval(150)
        self._poll.timeout.connect(self._check_exit)
        self._poll.start()
        self._poll_ticks = 0

    _re_ansi = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07]*\x07|\r")
    _re_sgr = re.compile(r"\x1b\[([0-9;]*)m|\x1b\[[0-9;?]*[A-LN-Za-ln-z]|\x1b\][^\x07]*\x07")
    _ANSI16 = ["#1e2127", "#e06c75", "#98c379", "#e5c07b", "#61afef", "#c678dd", "#56b6c2", "#abb2bf",
               "#5c6370", "#ff7b86", "#b5e890", "#ffd479", "#7cc7ff", "#dd9cff", "#7ee2f0", "#ffffff"]

    def _ansi_color(self, params, i):
        """38;5;n / 38;2;r;g;b → (QColor, kolik parametrů spotřebováno)."""
        if i + 1 < len(params) and params[i + 1] == 5 and i + 2 < len(params):
            n = params[i + 2]
            if n < 16:
                return QtGui.QColor(self._ANSI16[n]), 3
            if n < 232:
                n -= 16
                r, g, b = n // 36, (n // 6) % 6, n % 6
                return QtGui.QColor(*(0 if v == 0 else 55 + 40 * v for v in (r, g, b))), 3
            v = 8 + 10 * (n - 232)
            return QtGui.QColor(v, v, v), 3
        if i + 1 < len(params) and params[i + 1] == 2 and i + 4 < len(params):
            return QtGui.QColor(params[i + 2], params[i + 3], params[i + 4]), 5
        return None, 1

    def _append_ansi(self, text):
        """Vypíše text s podporou SGR sekvencí (barvy, tučné, kurzíva, podtržení)."""
        text = text.replace("\r\n", "\n").replace("\r", "")
        for tmp, real in self.path_alias.items():
            text = text.replace(tmp, real)
        c = self.view.textCursor()
        c.movePosition(QtGui.QTextCursor.MoveOperation.End)
        fmt = self._ansi_fmt
        pos = 0
        for m in self._re_sgr.finditer(text):
            if m.start() > pos:
                c.insertText(text[pos:m.start()], fmt)
            pos = m.end()
            if m.group(1) is None:
                continue  # jiná řídicí sekvence – ignorovat
            params = [int(x) if x else 0 for x in m.group(1).split(";")] if m.group(1) else [0]
            i = 0
            while i < len(params):
                n = params[i]
                if n == 0:
                    fmt = QtGui.QTextCharFormat()
                elif n == 1:
                    fmt.setFontWeight(QtGui.QFont.Weight.Bold)
                elif n == 2:
                    fmt.setForeground(QtGui.QColor("#8b919c"))
                elif n == 3:
                    fmt.setFontItalic(True)
                elif n == 4:
                    fmt.setFontUnderline(True)
                elif n == 7:
                    fg, bg = fmt.foreground(), fmt.background()
                    fmt.setForeground(bg if bg.style() != Qt.BrushStyle.NoBrush else QtGui.QBrush(QtGui.QColor("#1e2127")))
                    fmt.setBackground(fg if fg.style() != Qt.BrushStyle.NoBrush else QtGui.QBrush(QtGui.QColor("#d7dae0")))
                elif n == 22:
                    fmt.setFontWeight(QtGui.QFont.Weight.Normal)
                elif n == 23:
                    fmt.setFontItalic(False)
                elif n == 24:
                    fmt.setFontUnderline(False)
                elif n == 39:
                    fmt.clearForeground()
                elif n == 49:
                    fmt.clearBackground()
                elif 30 <= n <= 37:
                    fmt.setForeground(QtGui.QColor(self._ANSI16[n - 30]))
                elif 90 <= n <= 97:
                    fmt.setForeground(QtGui.QColor(self._ANSI16[n - 90 + 8]))
                elif 40 <= n <= 47:
                    fmt.setBackground(QtGui.QColor(self._ANSI16[n - 40]))
                elif 100 <= n <= 107:
                    fmt.setBackground(QtGui.QColor(self._ANSI16[n - 100 + 8]))
                elif n in (38, 48):
                    color, used = self._ansi_color(params, i)
                    if color is not None:
                        (fmt.setForeground if n == 38 else fmt.setBackground)(color)
                    i += used
                    continue
                i += 1
        if pos < len(text):
            c.insertText(text[pos:], fmt)
        self._ansi_fmt = fmt
        self.view.setTextCursor(c)
        self.view.ensureCursorVisible()

    # --- režim obrazovky (TUI) ------------------------------------------------------
    _ALT_ON = (b"\x1b[?1049h", b"\x1b[?47h", b"\x1b[?1047h")
    _ALT_OFF = (b"\x1b[?1049l", b"\x1b[?47l", b"\x1b[?1047l")

    def _set_screen_mode(self, on):
        if on and pyte is None:
            on = False
        was = self.screen is not None
        self.view.screen_mode = on
        if on != was:
            self.screen_mode_changed.emit(on)
        if on:
            rows, cols = self.view.term_size()
            self._winsize = (rows, cols)
            self.screen = pyte.Screen(cols, rows)
            self.stream = pyte.ByteStream(self.screen)
            self._rendered = None
            self.view.setLineWrapMode(QtWidgets.QPlainTextEdit.LineWrapMode.NoWrap)
            self.view.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            self.view.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            self.view.setFocus()
            self.status.setText(tr("Program v režimu terminálu – klávesy jdou přímo do programu"))
        else:
            if self.screen is not None:
                self.view.clear()
                self._ansi_fmt = QtGui.QTextCharFormat()
            self.screen = None
            self.stream = None
            self.view.setLineWrapMode(QtWidgets.QPlainTextEdit.LineWrapMode.WidgetWidth)
            self.view.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            self.view.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            if self.is_running():
                self.status.setText(tr("Běží…"))

    def _apply_winsize(self):
        if self.master is None:
            return
        rows, cols = self.view.term_size()
        if (rows, cols) == self._winsize:
            return
        self._winsize = (rows, cols)
        try:
            fcntl.ioctl(self.master, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
            if self.proc:
                os.killpg(self.proc.pid, signal.SIGWINCH)
        except (OSError, ProcessLookupError):
            pass
        if self.screen is not None:
            self.screen.resize(rows, cols)
            self._render_timer.start()

    def _raw_key(self, data):
        if self.is_running():
            try:
                os.write(self.master, data)
            except OSError:
                pass

    def _process_bytes(self, data):
        """Rozdělí data podle přepnutí alternativní obrazovky a zpracuje je v odpovídajícím režimu."""
        while data:
            markers = self._ALT_OFF if self.screen is not None else self._ALT_ON
            hit = None
            for m in markers:
                i = data.find(m)
                if i >= 0 and (hit is None or i < hit[0]):
                    hit = (i, m)
            if hit is None:
                self._consume(data)
                return
            i, m = hit
            self._consume(data[:i])
            self._set_screen_mode(self.screen is None)
            data = data[i + len(m):]

    _BUFFER_LIMIT = 4 * 1024 * 1024  # znaků výstupu držených pro diagnostiku; starší se zahazují

    def _remember(self, text):
        """Uloží výstup pro parse_diagnostics; při zaplnění zahodí nejstarší část,
        aby program s nekonečným výpisem nezaplnil paměť IDE."""
        self._buffer.append(text)
        self._buffer_size += len(text)
        if self._buffer_size > self._BUFFER_LIMIT:
            joined = "".join(self._buffer)[-self._BUFFER_LIMIT // 2:]
            self._buffer = [joined]
            self._buffer_size = len(joined)

    _GUARD_EVERY = 6  # kontrola paměti každý šestý tik pollu (~0,9 s); čtení /proc nemá brzdit vykreslování

    def _guard_memory(self):
        """Hlídač volané z pollu: zabije program, který přerostl limit nebo vyčerpal RAM."""
        if self._watchdog is None:
            return
        self._poll_ticks += 1
        if self._poll_ticks % self._GUARD_EVERY:
            return
        reason = self._watchdog.check()
        if not reason:
            return
        kind, value = reason
        sandbox.kill_group(self.proc)
        if kind == "rss":
            msg = tr("[program zastaven: překročil limit paměti {0} MB (použito {1} MB)]").format(self.memory_limit_mb, value)
        else:
            msg = tr("[program zastaven: v systému došla volná paměť (zbývalo {0} MB)]").format(value)
        self._append("\n" + msg + "\n", "#ff5f5f")
        self._watchdog = None
        self._check_exit(force=True)

    def _consume(self, data):
        if not data:
            return
        if self.screen is not None:
            self.stream.feed(data)
            self._remember(self._re_ansi.sub("", data.decode("utf-8", "replace")))
            self._render_timer.start()
        else:
            raw = self._decoder.decode(data)
            self._remember(self._re_ansi.sub("", raw))
            self._append_ansi(raw)

    def _pyte_color(self, name, default):
        if not name or name == "default":
            return default
        names = ["black", "red", "green", "yellow", "blue", "magenta", "cyan", "white"]
        if name in names:
            return QtGui.QColor(self._ANSI16[names.index(name)])
        if name.startswith("bright") and name[6:] in names:
            return QtGui.QColor(self._ANSI16[8 + names.index(name[6:])])
        if len(name) == 6:
            try:
                return QtGui.QColor("#" + name)
            except Exception:  # noqa: BLE001
                pass
        return default

    def _char_format(self, key, pal_fg, pal_bg):
        """Formát pro běh znaků se stejnými atributy; výsledek se drží v paměti,
        aby se při každém překreslení nevytvářely stovky QTextCharFormat."""
        fmt = self._fmt_cache.get(key)
        if fmt is not None:
            return fmt
        fg_name, bg_name, bold, italics, underscore, reverse = key
        fmt = QtGui.QTextCharFormat()
        fg = self._pyte_color(fg_name, pal_fg)
        bg = self._pyte_color(bg_name, pal_bg)
        if reverse:
            fg, bg = bg, fg
        fmt.setForeground(fg)
        if bg != pal_bg:
            fmt.setBackground(bg)
        if bold:
            fmt.setFontWeight(QtGui.QFont.Weight.Bold)
        if italics:
            fmt.setFontItalic(True)
        if underscore:
            fmt.setFontUnderline(True)
        if len(self._fmt_cache) > 4096:
            self._fmt_cache.clear()
        self._fmt_cache[key] = fmt
        return fmt

    def _insert_line(self, c, y, pal_fg, pal_bg):
        """Vloží řádek y obrazovky na pozici kurzoru c jako běhy znaků se stejným formátem."""
        scr = self.screen
        line = scr.buffer[y]
        cur_hidden = scr.cursor.hidden
        cx, cy = scr.cursor.x, scr.cursor.y
        run = []
        run_key = None
        for x in range(scr.columns):
            ch = line[x]
            is_cursor = (not cur_hidden and x == cx and y == cy)
            key = (ch.fg, ch.bg, ch.bold, ch.italics, ch.underscore, ch.reverse != is_cursor)
            if key != run_key:
                if run:
                    c.insertText("".join(run), self._char_format(run_key, pal_fg, pal_bg))
                    run = []
                run_key = key
            run.append(ch.data or " ")
        if run:
            c.insertText("".join(run), self._char_format(run_key, pal_fg, pal_bg))

    def _render_screen(self):
        """Překreslí obrazovku terminálu. Po prvním vykreslení se přepisují jen
        řádky, které pyte označil jako změněné (screen.dirty), plus řádky se starou
        a novou polohou kurzoru; celý dokument se staví znovu jen po změně velikosti
        nebo když počet bloků dokumentu neodpovídá obrazovce."""
        if self.screen is None:
            return
        scr = self.screen
        pal_fg = self.view.palette().color(QtGui.QPalette.ColorRole.Text)
        pal_bg = self.view.palette().color(QtGui.QPalette.ColorRole.Base)
        doc = self.view.document()
        cx, cy = scr.cursor.x, scr.cursor.y
        prev = self._rendered
        partial = (prev is not None and prev[0] == scr.lines and prev[1] == scr.columns
                   and doc.blockCount() == scr.lines)
        if partial:
            c = QtGui.QTextCursor(doc)
            c.beginEditBlock()
            rows = set(scr.dirty)
            rows.add(prev[3])
            rows.add(cy)
            for y in sorted(rows):
                if y < 0 or y >= scr.lines:
                    continue
                block = doc.findBlockByNumber(y)
                if not block.isValid():
                    continue
                c.setPosition(block.position())
                c.setPosition(block.position() + max(block.length() - 1, 0), QtGui.QTextCursor.MoveMode.KeepAnchor)
                c.removeSelectedText()
                self._insert_line(c, y, pal_fg, pal_bg)
            c.endEditBlock()
        else:
            doc.clear()
            c = QtGui.QTextCursor(doc)
            c.beginEditBlock()
            for y in range(scr.lines):
                self._insert_line(c, y, pal_fg, pal_bg)
                if y < scr.lines - 1:
                    c.insertBlock()
            c.endEditBlock()
        scr.dirty.clear()
        self._rendered = (scr.lines, scr.columns, cx, cy)
        self.view.verticalScrollBar().setValue(0)

    def _on_output(self):
        try:
            data = os.read(self.master, 65536)
        except OSError:
            data = b""
        if not data:
            self._check_exit(force=True)
            return
        self._process_bytes(data)

    def _check_exit(self, force=False):
        if self.proc is None:
            return
        code = self.proc.poll()
        if code is None and not force:
            self._guard_memory()
            return
        if code is None:
            try:
                code = self.proc.wait(timeout=0.5)
            except subprocess.TimeoutExpired:
                return
        # dočíst zbytek
        try:
            while True:
                r, _, _ = select.select([self.master], [], [], 0)
                if not r:
                    break
                data = os.read(self.master, 65536)
                if not data:
                    break
                self._process_bytes(data)
        except OSError:
            pass
        if self.screen is not None:
            self._render_screen()
            self._set_screen_mode(False)
            self._append(tr("[program opustil režim terminálu]") + "\n", "#7f848e")
        self._finish(code)

    def _finish(self, code):
        if self._poll:
            self._poll.stop()
            self._poll = None
        if self.notifier:
            self.notifier.setEnabled(False)
            self.notifier.deleteLater()
            self.notifier = None
        if self.master is not None:
            try:
                os.close(self.master)
            except OSError:
                pass
            self.master = None
        self.proc = None
        if self._cleanup_file:
            try:
                os.unlink(self._cleanup_file)
            except OSError:
                pass
            self._cleanup_file = None
        full = "".join(self._buffer)
        for tmp, real in self.path_alias.items():
            full = full.replace(tmp, real)
        color = "#98c379" if code == 0 else "#ff5f5f"
        peak = self._watchdog.peak_mb if self._watchdog else 0
        self._watchdog = None
        note = tr(" (paměť až {0} MB)").format(peak) if peak >= 64 else ""
        self._append('\n' + tr('[proces skončil s kódem {0}]').format(code) + note + '\n', color)
        self.status.setText(tr('Skončeno (kód {0})').format(code))
        self._set_running_ui(False)
        self.finished.emit(code, full)

    def _forward_key(self, event):
        """Psaní do výstupního okna během běhu přesměruje do stdin řádku."""
        self.input.setFocus()
        QtWidgets.QApplication.sendEvent(self.input, QtGui.QKeyEvent(event.type(), event.key(), event.modifiers(), event.text()))

    def _set_running_ui(self, running):
        self.stop_btn.setEnabled(running)
        self.input.setEnabled(running)
        self.eof_btn.setEnabled(running)
        self.view.forward_keys = running
        self.input.setPlaceholderText(self._placeholder_run if running else self._placeholder_idle)
        self.input.setProperty("running", running)
        self.input.style().unpolish(self.input)
        self.input.style().polish(self.input)

    def send_input(self):
        if not self.is_running():
            return
        text = self.input.text()
        try:
            os.write(self.master, (text + "\n").encode("utf-8"))
        except OSError:
            pass
        self.input.clear()

    def close_stdin(self):
        if self.is_running():
            try:
                os.write(self.master, b"\x04")
            except OSError:
                pass
            self._append(tr("[stdin zavřen]\n"), "#7f848e")

    def stop(self):
        if self.is_running():
            sandbox.kill_group(self.proc)
            self._check_exit(force=True)

    def last_diagnostics(self):
        return parse_diagnostics("".join(self._buffer))
